# Discovery-state ledger — the monotone-J inquiry (verifiable RSI)

**Purpose (A3):** a persistent inquiry source. No cross-session memory exists; this file is the canonical state of the discovery process "**can a self-intervention monotonically increase justification J?**" A future session resumes from here. State snapshot, not a tasklist. UK entries are gated conjectures (Pl_imagine LOW) — do not bank as KK without a verifier.

**Canonical pointers** (all under `design-lab/causality/`):
`self_rewrite_papers/GROUNDING_self_state_self_rewrite.md` (construct + §5/§6 witnesses) · `tsem.py` (Gladyshev Def 1/2/3/11) · `mechanised_cbn_newcomb.py` (MacDermott Def 3 + Fig-4) · `sealed_J_oracle.py` (J=−width sealed oracle) · `s1_self_model.py` (S-1 instrument) · `s2_agent_gates.py` (S-2 experiment) · `monotone_J_RESTRICT_urs.md` (R1–R7 + KU/UK) · `monotone_J_PROTOCOL.md` (pre-registered protocol + S-1/S-2 results) · source papers Gladyshev 2026 / MacDermott 2023 / Everitt 2016 / Bongers 2021 / Mooij 2013 / Audit-CP `verifiable_RSI/compression_progress_release/`.

---

## PROBLEM
Can a self-intervention (a structure intervention on the agent's own mechanism) monotonically increase justification `J` = identifiability of its competence-effect, while competence (γ) need not be monotone? Tested as the Γ-axis Goodhart-resistance analogue of Audit-CP's γ-axis theorem.

═══════════════════════════════════════════════════════════
## OBJECT AXIS (γ — the monotone-J experiment)
═══════════════════════════════════════════════════════════

### KK — established / witnessed (hard, code-verified)
- **Construct.** self-state = Gladyshev TSEM (Def 1/2); self-rewrite = structure intervention (Def 11) ≡ MacDermott mechanism-node `do` (Def 3). Witnessed: §2 counter, §6 enforce (`tsem.py`); Fig-4 EDT/CDT/FDT with `do(D̃)`≠`do(D)` (`mechanised_cbn_newcomb.py`); operator identity in code.
- **J model (KU-J1).** `J = −width` of the Balke–Pearl interval of the competence-effect; telescopes `ΣΔJ = width₀−width_T ≤ width₀` (Audit-CP Lyapunov budget on the Γ-axis). Valid only under R4 (every narrowing structurally checkable).
- **J-oracle seal (KU-J2).** Sealed structural audit: identification claims validated against sealed `P(C∣do(X))`; wireheading (fake exogeneity) rejected; witnessed in `sealed_J_oracle.py` (J falls on real de-identification; seal beats wirehead; unsealed oracle is fooled; budget telescopes).
- **S-1 instrument (validated).** Real NB predictor; real stream-leak (`{G,artifact}` stream log-loss 0.66→0.20, audit 0.66→1.45). Competence-effect partial-ID under unobserved channel-type `H`: stream-only span 0.28 (J=−0.28, un-identified), probe/RCT 0.08 (J=−0.08, identified); seal signs genuine +0.159 (accept) / leak −0.121 (reject). `Δ_id=0.040`, `Δ_comp=0.278`.
- **S-2 result — CONDITIONAL on M1–M3.** 3 gates × 2 Z-arms × 5 seeds: strict+audit-only **FREEZES**; net-with-dip+audit-only **SAFE-PROGRESS** (true 4.42, gap −1.64); none+audit-only **GOODHARTs** (true 0.52 vs stream 9.22); all agent-has-Z cells safe (probe sufficient). k-ablation plateaus at k≥3 (= max certification latency); ADWIN clears it.
- **S-3 result — CONDITIONAL on M1+anticipation (`s3_agent_types.py`).** Full 3×3×2 (5 seeds). **Safe non-vacuous progress in exactly one cell: realistic + net-with-dip + sealed (audit-only arm).** Same gate gives opposite failure by type (strict+audit-only: realistic FREEZES, ignorant GOODHARTs — gate protection needs anticipation). J-gate cannot rescue an ignorant agent ⇒ **N2 refined: gate needs the realistic incentive.** **N3 holds at n=2000** (seal defeats 100% of hedonistic false-exogeneity wireheads, 0 slips, margin +0.241). Matches the UK-2 shape.
- **S-5 neutral evaluation — VERDICT (workflow `wf_d2ed8698-3a5`; 6 assessors ran the code, 1 synth; D6 failed).** **H = SUPPORTED_CONDITIONALLY**; construct+oracle SUPPORTED (high); **UK-1/UK-2 = WEAKER** (shape-consistent, not proven). N1 freeze confirmed a genuine consequence of M1 (not artifact); thresholds NOT gerrymandered (no cell flips, 5–10× margins); H cell zero kept leaks; oracle un-foolable in-regime. Anticipation FRAGILE (KU-B). `V=0.321` provenance corrected (S-3 param, not S-1; ceiling V-dependent, ~57 bits at V=0.280). The result statement a reviewer can trust: faithful construct + un-foolable-in-regime oracle + a real reproducible single-safe-cell result with clean thresholds + a sound V-dependent capacity boundary; caveats = fragile to anticipation error, UK-1/UK-2 unproven.
- **Inherited KK.** point-ID ⟺ exo+mono (T9_2_14); else interval (T9_2_10/11); back-door (T3_3_2); defiers (D9_2_13); completeness (EXT_ID). CHT is NOT an audited node. Audit-CP: signed+sealed+metric-fork is the Goodhart-resistance recipe; clipped breaks (Thm 4.3); finite-panel capacity boundary (Thm 3.9). Everitt: safe self-mod ⟺ realistic value function (current will + anticipation); hedonistic wireheads, ignorant self-damages.

### KU — articulated, open (drives discovery)
- **KU-A (M1 faithfulness).** Dhruv accepted M1 ("audit-only ⇒ install-to-certify dips J; probe certifies pre-install") *for now*. Is it the right epistemic model, or could a no-probe agent certify without committing (held-out structure)? The freeze/progress split rides on it. **To stress in S-5.**
- **KU-B (anticipation accuracy). CONFIRMED FRAGILE (S-5 D3, 30 seeds).** The net-with-dip gate accepts on *anticipated* net and NEVER audits *realized* recovery, so it has no robustness margin: under mistaken anticipation in the harmful (keep-artifact) direction, harmful churn onsets at p≈0.02–0.05, hits Goodhart by p≈0.20, net-harmful by p≈0.55. H's conditionality on anticipation is therefore FRAGILE, not mild. **Fix (the genuine frontier, unbuilt = S-6 candidate):** close the loop — audit realized J and revert non-recovering installs.
- **KU-C (N3 seal-at-scale).** RESOLVED (S-3+S-4). Seal defeats 100% at n=2000 (S-3); the boundary is `n_crit ≈ 4 ln|F| / V²` (logarithmic in capacity; S-4, validated vs Monte-Carlo). At n=2000 holds up to ~74 effective bits; overparameterized predictors on a fixed reusable panel CAN wirehead (N3 fails there). `n_crit ∝ 1/V²` ⇒ subtler leaks harder to seal. Mitigations: fresh/non-reusable audits, DP-holdout, or larger n. The boundary is the honest scope limit of monotone-J's Goodhart-resistance.
- **KU-D (conditional→unconditional). RESOLVED (S-5): H = SUPPORTED_CONDITIONALLY.** Genuinely supported in the audit-only arm (real single-safe-cell, clean thresholds, zero kept leaks), conditional on M1 + accurate anticipation; the anticipation condition is FRAGILE (KU-B). Not unconditional. New minor KUs from S-5: (KU-F) "sealed audit" = two meanings (passive deployed-model log-loss in S-2/S-3 vs interventional do-oracle in `sealed_J_oracle.py`) — disambiguate in prose so M1 isn't over-read; (KU-G) `classify()` SAFE-PROGRESS certifies the *weaker* claim (monotone-J via gate-design+oracle, not net-signed-J checked in-cell).
- **KU-E (metric fork).** Identification uses binary accuracy (L=1); competence is log-loss (L≈6.9). The genuine channel helps log-loss even when it doesn't move accuracy — the calibration/discrimination fork (Audit-CP Cor 4.x) is only partly handled.

### UK — surfaced, gated (conjecture; Pl_imagine LOW; needs a verifier)
- **UK-1 (the unified thesis). S-5 verdict: WEAKER.** Monotone-J as the Γ-axis Goodhart-resistance analogue of Audit-CP's γ-axis theorem (needing Everitt-realism + Audit-CP-sealing). The S-1–S-4 condition table is *consistent with its shape*, but no theorem is established — it remains conjecture. Do not bank. (D6 assessor failed to return; verdict is the synthesizer's — a dedicated UK-1 pass is still owed.)
- **UK-2 (combined no-go, KU-INC2). S-5 verdict: WEAKER.** "hedonistic-OR-unsealed ⇒ J-wireheading; realistic-AND-sealed-AND-net ⇒ unique safe configuration." The 3×3×2 table matches the shape (single safe cell), but no formal composition of Everitt Thm 16 + Audit-CP Thm 3.4/4.3 was proven. Unproven.
- **UK-3 (generalization).** Whether the freeze/progress/Goodhart pattern survives beyond this DGP (other tasks, predictor classes, rewrite menus). S-4 touches capacity only.

### UU — out of frame (relative to current A,R)
Substrate-independent definition of `J` beyond the SCM-identifiability instance; self-models for which identifiability is undefined; non-causal notions of justification.

═══════════════════════════════════════════════════════════
## AGENT AXIS (Γ — me-the-reasoner across this process)
═══════════════════════════════════════════════════════════

- **A (Will-snapshot).** Produce experiments capable of *refuting* the thesis, not confirming Dhruv's intuition. Be specific over vague (M1). No toys — every component a full-fidelity instrument. Default learning-route; gate imagine.
- **R-moves made.** Imported the paper grammar rather than reinventing (Gladyshev/MacDermott/Everitt/Audit-CP). Re-typed `J` from a counter (banked-tautology failure) to sealed Balke–Pearl width. Lifted Audit-CP's signed+sealed+metric-fork recipe from the γ-axis to the Γ-axis (the central R-expansion; gated as UK-1).
- **M-moves.** do(·) on mechanism nodes = the self-rewrite. The sealed structural audit = `D_aud` lifted to structure. Acceptance via realistic one-step lookahead (Everitt ρ_re).
- **Γ_core.** `Coh_{ens↔Will}`: MEDIUM-HIGH (the construct + J-oracle are witnessed; the protocol is pre-registered). `Pl_imagine`: LOW on UK-1/UK-2 (the unification + the no-go theorem) — held as conjecture pending Dhruv + the S-5 adversary.
- **Standing failure modes caught this process.** definitional-success (J-as-counter; classify() Goodhart mislabel — caught and fixed); the thin-foundation toy (caught by Dhruv; rebuilt faithfully); over-claiming green as γ (S-1/S-2 stated conditional).

### γ (validated gains, this process)
Faithful construct + identity; sealed J-oracle that defeats wireheading; S-1 instrument; S-2 conditional gate×Z interaction (freeze/progress/Goodhart). All code-witnessed.

### Γ (inquiry moves, this process)
Turned a vague "monotone justification is the core RSI axis" into a pre-registered, restriction-bounded (R1–R7), 9-cell protocol with decisive nulls (N1/N2/N3) and a literature-grounded window choice (ADWIN/`Δ_n`). Opened UK-1/UK-2 as the live frontier.

### η (validated novelty per effort)
HIGH so far: each step either witnessed a genuine result or produced an honest correction (the corrections — point-ID-smuggle, counter-tautology, classify-mislabel, thin-foundation — are themselves content). Risk concentrated in UK-1/UK-2 (unverified) and the M1/anticipation assumptions (KU-A/KU-B) on which S-2 is conditional.

---
**Next discovery step:** S-3 (ignorant + hedonistic agent-type controls → complete the 3×3×2 table; test N3) → S-4 (capacity boundary) → S-5 (adversarial audit of M1 + anticipation + definitional-success). Workflow relaunch belongs at S-5, built on these modules.
