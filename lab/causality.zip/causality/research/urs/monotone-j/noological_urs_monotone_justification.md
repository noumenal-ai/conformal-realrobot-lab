# Noological URS — "Can a self-intervention monotonically increase justification?"

**The instrument that must pass BEFORE any experiment.** The question is FIXED (not pivoted to "safety vs progress" or anything else). No experiment is run in this artifact. Two axes kept separate (2.4) and coupled at the end. Per the updated discipline: **A4 diagnoses, A5 resolves** — "honestly open / Pl-kill / pending" is never a terminal state here; every flagged gap below carries a scheduled structure-addition.

---

## PART I — Noological axis (Γ): me-the-reasoner, and the tripwires

### A — Will-snapshot for this task
Directionality: produce a **correct test**, one whose outcome (monotone or not) is *earned by the dynamics, not entailed by the setup*. Success is **not** "the experiment shows monotone"; success is "the experiment **could** have shown non-monotone, and we measured which way it went."

Admitted constraint (A3 + the hard lesson): I am an inductive model whose dominant failure on this problem is **definitional success** — choosing a metric/setup in which the claim holds for a reason internal to the definition, then believing it. Three consecutive experiments did exactly this. `Pl_imagine` on any experiment I design is **LOW**; it is conjecture until the tripwires below pass *and* an external adversary clears it.

### The failure mode, named (so it is catchable)
**Definitional success** — signatures:
- the target quantity cannot take the failing value (justification = a non-decreasing counter ⇒ "monotone?" is `all(x ≥ x)`);
- the claimed effect is produced by an unintended factor (search scope, not the objective axis);
- the object is not the claimed object (a fixed surface *observed*, not a self *modified*).

### Pre-registration tripwires — ALL must pass before any experiment runs (A4 review gates)
- **T1 · can-fail.** Exhibit, in the same setup, a concrete self-intervention that makes justification **decrease**. No constructible decrease ⇒ the metric is a counter ⇒ reject the design.
- **T2 · null is producible.** State what a NON-monotone result looks like and confirm the setup can produce it (a landscape/policy under which the gate would be violated). Unreachable null ⇒ vacuous test.
- **T3 · one factor varied.** Every factor except the tested gate is held fixed across conditions — search scope, budget, candidate-generation, landscape. (The 2×2 lesson.)
- **T4 · real intervention.** The operator **writes** the self-mechanism (mutates the structural equations / competence map), verified; not observation of a fixed surface.
- **T5 · gate must fire.** The monotone-justification gate is **shown rejecting** at least one real degrading candidate. A gate that never fires is a counter in disguise.
- **T6 · non-vacuous change.** Accepted interventions are **measurably non-trivial** (the self actually changes — report the magnitude). Monotone-but-frozen is a *null*, not a success.
- **T7 · no ad-hoc metric.** Justification is defined from the inherited identifiability classes (below), not a free scalar; results are invariant to any remaining knobs (ablate them).

**A5 binding:** a failed tripwire is **not** "honestly open" — it is an obligation to *add the missing structure* (redefine the metric / add the gate / make the rewrite real) **before** running. No experiment proceeds on a failed tripwire.

### Γ_core
- `Coh_{ens↔Will}`: my model of "a correct experiment for this question" — MEDIUM (the tripwires are the structure I was missing), LOW until instantiated and adversary-cleared.
- `Pl_imagine`: LOW for any self-designed experiment; raised only by (human verifier + tripwires + adversary).

---

## PART II — Discovery axis (γ): the fixed question

**PROBLEM (verbatim, fixed): Can a self-intervention monotonically increase justification?** — non-trivially: the agent really changes itself, and justification really could fall.

### Justification, defined so it CAN decrease (load-bearing)
`J(M)` = the degree to which model `M`'s own competence is **causally identified** from what the agent can access, on the inherited point↔interval spectrum:
- **HIGH / point-identified** when regime→competence is exogenous + monotone (`T9_2_14`): competence certifiable to a point.
- **DEGRADED / interval-only** (`T9_2_10`, ratios `T9_2_11`) when a self-change introduces a **back-door** `Σ⇝C` (`T3_3_2` fails) or a **defier** (non-monotone response, `D9_2_13` fails): the certificate widens.

Candidate operationalizations (exact choice is KU; the **requirement** is that a confounder/defier-introducing rewrite strictly lowers it — T1): `J = −width` of the forward-witness partial-ID interval; or identified-fraction of the self-SCM; or negentropy of the posterior over self-structure.

So **a self-intervention can lower `J`** by making the post-rewrite self less identifiable. Monotone-`J` is therefore a real constraint — only **identifiability-preserving-or-improving** rewrites are admissible. That is the non-trivial content the counter erased.

### KK (inherited)
- point-ID ⟺ exo+mono (`T9_2_14`); else sharp interval (`T9_2_10`/`T9_2_11`). Identifiability is a spectrum a rewrite moves along.
- post-rewrite exo/mono is **structurally checkable**: back-door by d-separation (`T3_3_2`, `T1_2_4`); defiers by response shape (`D9_2_13`); general identifiability by do-calculus completeness (`EXT_ID_DO_CALCULUS_COMPLETE`).
- a self-intervention is `do(Σ=g(Pa))` — surgery on the mechanism.
- the prior three experiments did **not** test this (accepted retractions: counter; scope-confound; observation-not-modification).

### KU (open — what the correct experiment resolves)
- **KU1 — THE CRUX (justification-vs-change tension):** does requiring monotone-`J` force the agent to **freeze**? Every *meaningful* self-modification may carry a transient identifiability cost (the new mechanism is unverified at the instant it is installed), so strict monotone-`J` might admit only trivial/no-op rewrites. Or there may be a non-vacuous class of **identifiability-preserving** self-modifications. Genuinely open; could go either way.
- **KU2:** the admissibility gate (accept iff `J(post) ≥ J(pre)`) — does it fire on a real degrading candidate? (T5)
- **KU3:** if strict monotone-`J` freezes, does a **pre-registered relaxation** — net-monotone with a bounded re-identification dip ("you may dip while re-certifying, but must recover and net-increase") — admit non-vacuous change? This is the **same** question with an explicit tolerance, not a pivot.
- **KU4:** does the answer depend on self-model structure? Characterize the admissible-rewrite class.

### UK (surfaced; conjecture, NOT a stopping point — A5 schedules it into the experiment)
Real self-modification may *necessarily* pass through a less-identified state, so strict monotone-`J` may be impossible for non-trivial change, and the honest object may be "monotone-`J` modulo a re-identification step" (KU3). This is exactly the structure the experiment must be built to **detect** (is there a dip? is it recoverable? is the net monotone?). Marked conjecture; the experiment adjudicates — it is not a place to stop.

### UU (out of frame)
Whether `J` has a substrate-independent definition beyond the SCM-identifiability instance; whether self-models exist for which identifiability is undefined.

---

## PART III — Requirements a CORRECT experiment must satisfy (A5-resolution; derived; NOT run here)

Each requirement discharges a tripwire / KU. This is the spec to sign off before any build.

1. **Real self-modification** — an operator that rewrites `f_X`/`f_C`, changing post-rewrite identifiability structure. (T4)
2. **`J` defined to fall** — re-measured after each rewrite via the structural checks (`T3_3_2` d-sep, `D9_2_13` defier, `EXT_ID`); a rewrite that lowers `J` is exhibited. (T1, T7)
3. **A monotone-`J` gate that can reject**, shown firing on a degrading candidate. (T5, KU2)
4. **The crux measurement (KU1)** — plot `J` against cumulative **self-change magnitude**. The question is answered by whether a non-vacuous (large cumulative change) trajectory exists with monotone (or net-monotone-with-bounded-dip, KU3) `J`, **or** whether monotone-`J` ⟹ change ≈ 0 (frozen). (T2, T6)
5. **One-factor design** — vary ONLY the gate {monotone-`J`, none}; hold search scope, budget, candidate-generation, landscape fixed. No scope confound. (T3)
6. **Knob ablation + grounding** — invariant to `J`'s free parameters; identifiability claims cited to `T9_2_14`/`T9_2_10`/`T3_3_2`/`D9_2_13`/`EXT_ID` (not "CHT", which is not an audited node). (T7)
7. **Pre-register** — hypothesis (non-vacuous monotone-`J` exists), null (monotone-`J` ⟹ frozen), falsifier (either outcome decisive); run only after T1–T7 pass; then external adversarial pass.

---

**Net:** the question stays fixed; `J` is defined so monotonicity is *testable* (can fail); the real crux is the freeze tension (KU1) with a principled same-question relaxation (KU3); and the correct experiment is specified by T1–T7 without being run. The instrument's whole job is to make "monotone justification" an *earned* measurement, which is exactly what the three prior experiments skipped.
