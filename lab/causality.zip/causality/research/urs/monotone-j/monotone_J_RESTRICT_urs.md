# RESTRICT-mode URS — bounding the monotone-J experiment from the learned structure

**Mode:** RESTRICT (deductive contraction within fixed R; NO grammar expansion). Job: *learn* the now-solid structure and use it to **restrict** the admissible forms of the monotone-J experiment. Every restriction below is derivable from the fixed KK and **FIRES** (kills a candidate experiment) when violated. Companion to `noological_urs_monotone_justification.md` (T1–T7) and `self_rewrite_papers/GROUNDING_self_state_self_rewrite.md` (§6 = solid foundation). **The question stays FIXED:** *can a self-intervention monotonically increase justification J?*

This artifact does NOT resolve the J model or incentives. Those are the KU/UK-dense region (Part IV), to be resolved with Dhruv **one block at a time**. Self-generated J/incentive structure is **conjecture (Pl_imagine LOW)**, gated on his verification — not banked as KK.

---

## PART I — Γ (me-the-reasoner)

- **Will-snapshot:** produce a *correctly-restricted* experiment whose monotone/non-monotone outcome is earned, not entailed. Success ≠ "monotone holds"; success = "the restrictions make the weak versions impossible, and the residual question is genuinely open."
- **Admitted constraint (A3 + history):** my dominant failure on this problem is *definitional success* (J as a counter; smuggled point-ID; scope confounds). RESTRICT mode is the antidote: I am not inventing the J model, I am deriving what it is **not allowed to be** from fixed structure I can cite.
- **Γ_core:** `Coh_{ens↔Will}` = MEDIUM (the inheritance is concrete); `Pl_imagine` = LOW for the J-functional and the unified thesis (Part IV) — gated on Dhruv.

---

## PART II — Learned KK (the FIXED structure; the yardstick)

1. **Self-state / self-rewrite (witnessed):** `tsem.py` = Gladyshev Def 1/2/3/11 verbatim; self-rewrite = Def 11 structure intervention ≡ MacDermott Def 3 `do(mechanism node)`; witnessed on §2 counter, §6 enforce, Fig-4 EDT/CDT/FDT (`do(D̃)`≠`do(D)`), and the operator identity. **This is imported, not re-derived.**
2. **Audit-CP architecture (P3, `compression_progress_release`), re-read.** Goodhart-resistance of compression progress requires THREE things together, none weakenable:
   - **(a) Sealed audit** (Assn 2.1): the measurement distribution `D_aud` is *fixed and independent of the agent's actions*; agent may know the task family, may not query/alter the sealed sample. Formalized as MI=0 between audit panel and training history.
   - **(b) Signed/telescoping accounting** (Def 2.2): `r_t = E_{t-1} − E_t`, `Σr_t = E_0 − E_T ≤ E_0 − E_min` (Lyapunov budget, Thm 3.4). **Clipping breaks it** (Thm 4.3: clipped reward is a reward farm).
   - **(c) Metric fork + stagnation slack** (Def 3.x, Cor 4.x): `V_log` (the potential) ≠ `V_disc` (downstream). Log-loss can improve while discrimination is unchanged; `S_F(V,E,θ0,ε)=sup{E_0−E(θ): V(θ)≤V_0+ε}` bounds how much "progress" is possible during true stagnation. Vacuous for unrestricted NNs on reusable finite audits (memorization).
3. **Incentives (Everitt 2016), read.** Safe self-modification ⟺ **realistic value function**: evaluate self-rewrites with the **current** utility `u_t` (goal-preservation, Omohundro) AND **anticipate** their effect on future policy (ρ_re). Table 1: **hedonistic** (future utility u_{t+1}) → wireheads (Thm 14, u′≡1); **ignorant** (current utility, no anticipation) → indifferent/self-damages; **realistic** → resists bad self-mod (Thm 16: all self-mods stay `Q_1^re`-optimal). Modification-independence (Assn 8) of belief + utility is structural.
4. **Identifiability KK (audited Pearl DAG):** point-ID ⟺ exo+mono (T9_2_14); else sharp interval (T9_2_10/T9_2_11); back-door by d-sep (T3_3_2); defiers (D9_2_13); completeness (EXT_ID_DO_CALCULUS_COMPLETE). **CHT is NOT a node** — do not cite it.

---

## PART III — RESTRICTIONS on the admissible experiment (RESTRICT output; each FIRES on violation)

| # | Restriction | Derived from | FIRES (kills the form) when… |
|---|---|---|---|
| **R1** | **J is SEALED**: computed by an external oracle (DoWhy `identify_effect`/interval width) on the *true* post-rewrite mechanism graph — never on the agent's self-reported structure. | Audit-CP (a) | J read off a description the agent controls ⇒ unsealed ⇒ J-wireheadable. |
| **R2** | **J accounting is SIGNED**: "monotone" uses signed net ΔJ (telescoping), never clipped/`max(0,·)`. | Audit-CP (b), Thm 4.3 | the gate counts only J-increases ⇒ degrade-then-restore reward farm. |
| **R3** | **J can FALL**: J is identifiability (interval width), not `len(identified)`; a constructible rewrite must lower it (T1). | past retraction + Audit-CP | J non-decreasing by construction ⇒ "monotone?" = `all(x≥x)` ⇒ tautology (THE central past failure). |
| **R4** | **Metric fork for J**: separate "J-number narrowed" from "genuinely more identified". A rewrite that narrows the interval by adding a **structurally-unchecked assumption** (e.g. a monotone seal) is the J-analogue of calibration-without-discrimination / panel memorization. | Audit-CP (c) + point-ID-smuggle retraction | narrowing comes from an assumption not checkable on the true graph (d-sep/defier-test). |
| **R5** | **Realistic incentive**: self-rewrite acceptance is driven by a *realistic* value function (current will + anticipation), not hedonistic or ignorant. | Everitt Thm 16 | acceptance evaluates the rewrite by the *future* self's J-verdict ⇒ J-wireheading. |
| **R6** | **Real structure-rewrite**: the operator is `tsem.StructureIntervention` / mechanised-CBN `do(mechanism node)`, imported from the witnessed modules. | solid foundation | a hand-rolled "move a number" echo instead of the paper operator. |
| **R7** | **Modification-independent oracle**: the identifiability oracle depends only on the *current* graph, not the rewrite history; the agent cannot make the oracle itself more lenient. | Everitt Assn 8 + Audit-CP (a) | the J-oracle's verdict is a function the rewrite can soften. |

**Net effect:** R1–R7 make all four known weak versions un-instantiable. The residual admissible experiment is narrow: a *realistic* agent performing *imported structure-rewrites* on a mechanised CBN, with J = *sealed, signed, structurally-checkable* identifiability of the competence-effect.

---

## PART IV — KU/UK-dense region: **J model + incentives** (SURFACE, do not bank; resolve with Dhruv one-by-one)

> Everything here is GATED. Where I have a candidate, it is a conjecture I generated (Pl_imagine LOW) presented *with* the verifier (Dhruv) — not a closure.

- **KU-J1 — the J functional + telescoping. RESOLVED (Dhruv, this session).** `J = −width` of the Balke–Pearl competence-effect interval; `width∈[0,1]`, `width=0` at point-ID (T9_2_14 = the "Bayes floor"). Justification progress `ΔJ_t = width_{t−1}−width_t` telescopes to `width_0 − width_T ≤ width_0` — **the Audit-CP Lyapunov budget on the Γ-axis** (cumulative justification progress has a finite budget = initial interval width). Banked as KK *only under R4*: the budget is meaningful iff every narrowing is structurally checkable on the true graph (d-sep/defier), never a smuggled assumption — the Γ-image of Audit-CP's "budget real only if the audit can't be memorized." Identified-fraction / posterior-negentropy rejected as coarser / harder-to-seal.
- **KU-J2 — the sealed J-oracle. RESOLVED (Dhruv, this session): SEALED STRUCTURAL AUDIT.** Exogeneity/edge claims in the agent's declared graph are *validated against sealed interventional data the agent cannot query* — the literal Audit-CP `D_aud` lifted to structure. Concretely: the oracle compares the declared identification against sealed `P(C∣do(X))`; an exogeneity claim is admitted only if observational `P(C∣X)` matches the sealed interventional `P(C∣do(X))`. A fake instrument / falsely-declared exogeneity is rejected ⇒ width falls back to the honest Balke–Pearl interval ⇒ J is NOT inflated. Modification-independent (R7) because the sealed interventional data does not depend on the rewrite history. Implemented + witnessed (`sealed_J_oracle.py`): see below.
- **KU-INC1 — the will that values J (freeze-tension, incentive side).** R5 needs a *current will* that values being justified/identifiable. *Open:* is "the will values identifiability" coherent, or does it collapse to the trivial null (freeze to stay maximally identifiable)? This is KU1 (freeze) seen from the incentive side. **NEEDS Dhruv.**
- **KU-INC2 — the combined no-go.** *Candidate (conjecture):* hedonistic-OR-unsealed ⇒ J-wireheading (monotone-J vacuous); realistic-AND-sealed ⇒ non-vacuous, and the freeze-tension (KU1) is the genuine open question. *Open:* is this a *theorem* to prove (compose Everitt Thm 16 + Audit-CP Thm 3.4/4.3) or a heuristic framing? **NEEDS Dhruv.**
- **UK (grammar-level, highest Pl_imagine risk).** The synthesis: *"monotone justification is the Γ-axis (inquiry) analogue of Audit-CP's γ-axis (discovery) Goodhart-resistance, requiring Everitt-realism on the incentive side and Audit-CP-sealing on the measurement side."* I generated this; it may over-unify. **Most important block; NEEDS Dhruv before any banking.**

**Freeze-tension restatement (KU1, sharpened):** any genuine self-mod transiently *de-identifies* (the new mechanism is unverified at install ⇒ interval widens ⇒ J dips). A *realistic* agent valuing J then rejects it ⇒ possible freeze. The KU3 relaxation (net-monotone with a bounded re-identification dip) is exactly Audit-CP's **signed accounting** (you may dip while re-certifying; signed net ΔJ ≥ 0). **This is the real experimental question** once KU-J1/J2 are fixed.

---

## PART V — confidence partition (what to implement now vs. block on Dhruv)

- **DONE + WITNESSED (`sealed_J_oracle.py`):** `J = −width` (Balke–Pearl LP); the sealed structural audit (validate exogeneity against sealed `P(C∣do(X))`). Results: (T1) a real back-door rewrite lowers J `0.000 → −0.200`; (SEAL) a wireheading rewrite (falsely declare exogenous) is rejected (`obs 0.758 ≠ do 0.650`) so J stays `−0.200`, NOT inflated, whereas an unsealed oracle reports `+0.000` (fooled); (BUDGET) `Σ ΔJ = width_0 − width_T` telescopes. This validates R1/R3/R4/R6/R7 concretely. *Caveat:* the budget bound is only non-trivial for a confounded-start trajectory (the demo returned to exo ⇒ `width_0=0`).
- **HIGH-confidence (implement now, no banking risk):** R1–R7 as code-level gates; the realistic-value-function scaffold (Everitt Q^re: current-utility + anticipation).
- **BLOCKED on Dhruv (do NOT implement until resolved):** the will-valuing-J operationalization (KU-INC1), the combined-no-go status (KU-INC2), the unified thesis (UK). [KU-J1, KU-J2 RESOLVED.]
- **Sequencing:** KU-J1 ✓ → KU-J2 ✓ (J-oracle built+witnessed) → **KU-INC1 next** (incentives / freeze-tension) → KU-INC2/UK. Workflow relaunch only after the incentive structure is fixed (it determines the gate the experiment varies).
