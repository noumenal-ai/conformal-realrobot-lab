# Protocol — does the self-rewriting causal automaton's competence GROW on PHYRE?

**STATUS: DRAFT for redline. No VM launch until finalized + smoke-tested on the VM at tiny scale.** This is the γ-axis (discovery) test: the prior arc (S-1…S-5) established the Γ-axis (safety/justification); this asks whether the self-interventional causal model *actually gets better* at a hard, **external, recognized** task over self-rewrite steps. PHYRE is chosen precisely because success there is not self-graded (external validity). Parametric/open choices are flagged `[REDLINE]`. Runs on a **GCP A100 VM via the `gcp-harness`** (PHYRE cannot run on the local macOS-arm64 / Py3.9 box).

---

## 0. The question (fixed)
**Does a self-rewriting causal automaton's competence on PHYRE grow over self-rewrite steps**, exceeding (a) random and (b) a non-self-rewriting baseline — i.e. is the construct a genuine *discovery engine*, externally, not just a safety gate?

## 1. What this does and does NOT test (honest scope)
- **DOES:** the causal special properties **(1) structure-intervention self-rewrite** and **(2) counterfactual/interventional prediction** — external validity that the self-rewriting causal model learns on a recognized benchmark.
- **Does NOT (by design):** property **(3) identifiability-under-confounding** — PHYRE physics is fully observed and deterministic, so there is nothing to *identify*. The `J`/Balke–Pearl machinery sits unused here; that is the job of the **next** experiment (Dhruv's external confounded causal benchmark). PHYRE answers "does it learn?", the confounded benchmark answers "does causality give the edge?".

## 2. PHYRE primer (verify against the package on the VM before building)
- **Tiers:** `ball` (action = `(x, y, radius)`, 3 continuous dims in [0,1]) and `two_balls`. **Use `ball` first.**
- **Tasks/folds:** 25 templates; `phyre.get_fold(tier, fold_id)` → (train, dev, test) task-id lists. **Within-template** (train+test share templates) first; **cross-template** (unseen templates) is the harder stretch.
- **Simulator:** `simulator = phyre.initialize_simulator(task_ids, tier)`; `sim = simulator.simulate_action(i, action, need_featurized_objects=True)` → `sim.status` ∈ {SOLVED, NOT_SOLVED, INVALID} and `sim.featurized_objects` (per-object `(x,y,angle,diameter,one-hot type, one-hot color/role)` over time). **The featurized-object channel is load-bearing** — it gives the object-level representation in which causal structure is expressible (a pixel CNN would hide exactly the causality we want).
- **Metric:** **AUCCESS** (`phyre.Evaluator`): up to 100 attempts/task, success weighted toward fewer attempts; `evaluator.get_auccess()`. Published anchors for calibration: random ≈ low-teens AUCCESS on `ball` within-template; simple online agents higher. (Confirm exact numbers from the package/paper on the VM.)

## 3. The causal-agent ↔ PHYRE mapping (the scientific core)
- **Self-model.** A **structured forward model** over featurized objects: `(scene objects, candidate action) → predicted interaction chain → P(SOLVED)`. Its **mechanism graph** is a set of object-pair *interaction mechanisms* (e.g. "placed-ball contacts object O", "O transmits motion to goal"); each mechanism is a first-class, intervenable node (MacDermott Def 3), and the parameters inside a mechanism are learned (GPU).
- **Self-rewrite = structure intervention** (Gladyshev Def 11 / `do` on a mechanism node — the operator already built in `tsem.py`/`mechanised_cbn_newcomb.py`): as the agent observes `(action, scene, simulated trajectory, outcome)` tuples, it **edits the mechanism graph** — installs/removes/rewires an interaction mechanism it was missing. This is a **discrete structural edit**, distinct from gradient steps on a fixed architecture — that distinction is what makes the causal framing load-bearing rather than decorative (see the gradient-only control, §4).
- **Action selection = counterfactual prediction.** For a candidate action set, score `P(SOLVED)` under the current model (abduction→action→prediction), attempt the best; PHYRE returns the true outcome → a new trace → a self-rewrite. Competence = AUCCESS, measured as the model self-rewrites.
- **Competence-over-time = the learning curve:** AUCCESS (and raw solve-rate@budget) vs cumulative self-rewrite steps. **"Competence grows" = the curve rises and clears the baselines (§4).**

## 4. Baselines / controls (so "growth" is legible and the causal claim is isolated)
- **B0 random** — PHYRE's standard random-action agent (external anchor; the floor).
- **B1 frozen** — the same initial forward model, **no self-rewrites** (action selection only). Isolates that growth comes from *self-modification*, not from more attempts. Curve should be flat.
- **B2 gradient-only** `[REDLINE — strongly recommended]` — same model, self-updates by **ordinary parameter SGD** on a fixed mechanism graph (no structure interventions). If the **structure-intervention** agent beats B2, the *causal-structural* self-rewrite is load-bearing, not relabeled SGD. (This is the within-PHYRE proxy for "is causality doing work"; the definitive answer is the confounded benchmark next.)
- **External calibration:** report against published PHYRE `ball` within-template AUCCESS anchors (random; a simple online agent) so the curve is externally legible.

## 5. Pre-registration (decisive either way)
- **H_PHYRE:** the self-rewriting causal agent's AUCCESS **grows over self-rewrite steps** and exceeds **B0 (random)** and **B1 (frozen)** on `ball` within-template, by a margin beyond seed noise (5 seeds).
- **Nulls (each a clean result):** **N-flat** — curve flat / no better than B1 ⇒ self-rewrite isn't driving competence (causal machinery decorative); **N-randomfloor** — agent stuck at B0 ⇒ the structured model can't predict PHYRE physics from features at all; **N-nostructEdge** — agent ties B2 ⇒ growth is real but the *structural* self-rewrite adds nothing over SGD (causality not load-bearing *here*, deferring the edge to the confounded benchmark).
- **Falsifier:** the AUCCESS-vs-self-rewrite-step curves (agent vs B0/B1/B2), 5 seeds, on a fixed template subset, with CIs. H is supported iff agent > B1 ≥ B0 with separation; the B2 comparison adjudicates the structural-edge sub-claim.
- **Scope:** `ball` tier, within-template, a fixed subset of templates `[REDLINE: N templates]` first; cross-template is a labeled stretch goal.

## 6. Operational plan — `gcp-harness` on A100 (conforms to the harness meta-protocol)
- **VM:** `MACHINE=a2-highgpu-1g` (1×A100-40GB, bundled ⇒ `--maintenance-policy TERMINATE`, no `--accelerator`), `IMAGE_FAMILY=common-cu121-ubuntu-2204` (driver pre-baked; hard-assert `torch.cuda.is_available()`), boot disk 100GB. **Quota:** confirm `A2_CPUS` in the chosen zone before launch (`gcloud compute regions describe $REGION --format='table(quotas)'`).
- **PHYRE env (startup-script customization — the one real deviation from the stock harness):** the DL image is Python 3.10; PHYRE needs 3.8. So `conda create -y -n phyre python=3.8 && conda run -n phyre pip install phyre numpy pandas torch` (PHYRE ships `cp38` manylinux x86_64 wheels — pip-installable on the VM). All shard work runs under `conda run -n phyre`. Keep the harness's GPU-readiness wait + hard `torch.cuda` assertion (the agent's forward model trains on the A100).
- **`entry.py` contract (job-agnostic harness interface):** `python3 entry.py <JOB> --seed <S> --out <FILE>` runs ONE shard = one (agent-variant × seed) full train+eval on the fixed template subset and writes one JSON = `{auccess_curve: [...], final_auccess, solve_rate_curve, config, seed}`. **JOBS** = `{causal_selfrewrite, frozen_B1, gradient_B2, random_B0}`; **SEEDS** = 5; **WORKERS** `[REDLINE: ~4–8]` (PHYRE sim is CPU-heavy on the a2's 12 vCPUs; keep GPU-mem headroom). Resume-safe GCS streaming + status-honest accounting + EXIT-trap self-teardown per the harness.
- **CPU-vs-GPU honesty (the harness's own first checklist item):** PHYRE simulation is CPU-bound; the A100 is justified only insofar as the forward model's training/inference is GPU-heavy. If profiling shows the GPU idle, a big CPU box (`n2-standard-128`, MIGRATE, no 24h cap, far more parallel sims) is the honester machine. **Decision: start on A100 per Dhruv; profile GPU utilization in S-φ1 and switch if it sits idle.** `[REDLINE]`

## 7. Execution — sequenced checkpoints (stop for Dhruv between each)
1. **S-φ1 Env + smoke (on the VM, tiny scale).** Stand up the py3.8 conda + phyre env; confirm `simulate_action(..., need_featurized_objects=True)` returns usable object features; run B0 random on a few tasks → a valid AUCCESS; **profile GPU vs CPU utilization**. *Checkpoint: phyre runs, featurized objects usable, AUCCESS computes, machine choice confirmed.*
2. **S-φ2 Baselines.** B0 random + B1 frozen full curves, 5 seeds, the template subset. *Checkpoint: B0 matches published random anchor (external sanity); B1 flat.*
3. **S-φ3 The causal self-rewrite agent.** Full AUCCESS-vs-self-rewrite-step curve, 5 seeds. *Checkpoint: does it grow and clear B0/B1? (the core H test).*
4. **S-φ4 The structural-edge control.** B2 gradient-only; compare. *Checkpoint: does structure-intervention beat SGD? (the load-bearing-causality sub-claim).*
5. **S-φ5 Cross-template stretch** `[REDLINE: in scope for v1?]`. *Checkpoint: generalization curve.*

## 8. KK / KU / UK (the discipline; this is a γ problem-URS)
- **KK (inherited):** the structure-intervention/self-rewrite operator (built+witnessed, `tsem.py`/`mechanised_cbn_newcomb.py`); the harness meta-protocol (A100=a2-highgpu-1g, py3.8-conda phyre env, job×seed→JSON, resume-safe, self-teardown).
- **KU (open, drives the build):** **KU-φ1 (load-bearing) — the concrete self-rewrite operator on PHYRE:** how a structure intervention edits the forward model's mechanism graph, genuinely structural (a discrete causal-model edit), not relabeled SGD. This is THE design decision to lock before S-φ3. **KU-φ2** — does the featurized-object forward model predict SOLVED well enough to beat random (model-class adequacy)? **KU-φ3** — A100 justified vs CPU box (profile, S-φ1). **KU-φ4** — does competence actually grow, or plateau at random (the empirical question)?
- **UK (gated conjecture; Pl_imagine LOW):** **UK-φ1** — whether the *structural* self-rewrite gives an edge over gradient-only on PHYRE (B2 control probes it; the real test is the confounded benchmark). Do not assume causality is load-bearing on deterministic physics.

## 9. What I need from Dhruv to launch (operational prerequisites)
- **GCP `PROJECT`**, a **`GCS_BUCKET`** name (or permission to create one), and the **zone** where you hold **A2/A100 (`A2_CPUS`) quota**.
- **`gcloud` authenticated** locally (the RAPT reauth flow if your org enforces it) so `launch.sh` can dispatch.
- Redlines on §4 (B2 in/out), §5 (template subset size), §6 (workers, A100-vs-CPU), §7 (cross-template in v1?), and the lock on **KU-φ1** (the self-rewrite operator) before S-φ3.
