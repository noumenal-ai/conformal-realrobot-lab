# Grounding: self-state and self-rewrite (from the literature, before any experiment)

Extracted from the two construct-bearing papers, to recreate `self-state` and `self-rewrite` from real sources rather than reinvent them. No experiment here.

## 1. Self-STATE — Gladyshev, Alechina & Logan 2026 (Temporal SEM as computation)

**Def 1 (TSEM).** A Temporal Structural Equation Model over signature `S=(V,R,D)`: variables `V`, range `R(X)` (finite value set), domain `D(Y)⊆V` (the variables whose *previous* values determine `Y`'s *next* value), and structural equations
`F_Y : ∏_{X∈D(Y)} R(X) → 2^{R(Y)}` — "the (next) value of `Y` from the (previous) values of its domain." (Deterministic if every `F` returns a singleton.)

**Def 2 (Computation).** The dynamics is a tree of *configurations* (complete assignments `v`), root `v0`, transition `v1 →_M v2` iff `∀X: v2^X ∈ F_X(v1^{D(X)})`. So **the self IS a state machine: state = the variable-configuration `v`; the transition is "apply all the structural equations."**

Worked self-state example (their §2): one variable `X`, `R(X)={0..9}`, `F_X(X=x)= 9 if x=9 else {0, x+1}` — a counter that self-transitions by its own rule. TSEMs encode Linear-Bounded Automata (Thm 1) and, with countably many variables, are **Turing-complete** (Thm 2) — so the "self" can be any computational object.

## 2. Self-REWRITE — Gladyshev's *structure intervention* ≡ MacDermott's *mechanism node*

These are the SAME operator, from two angles. This is the key find.

**(a) Gladyshev Def 11 (Structure Intervention).** A standard intervention `do(Y^n ← y)` only resets a *value* at step `n` (and §6 notes this can't even enforce a persistent change). A **structure intervention** `do(Y^n(X⃗=x⃗) ← y)` instead **rewrites the structural equation `F_Y` itself** — the dynamic equations become `F^i_Y(X⃗=x⃗) = y'` where the intervention specifies it, else inherit `F^{i-1}`. Their words: *"Structure interventions would enable us to talk about changing transition rules in a computing device rather than a particular value, enabling us to model e.g. software patches"* — and *"structure interventions are NOT expressible in terms of standard interventions."* **This is the genuine self-rewrite: do() on the equation, not the value.** (It directly fixes the failure the adversary kept catching — "observation relabeled as modification.")

**(b) MacDermott, Everitt & Belardinelli 2023 (Mechanised Causal Bayesian Network), Def 3.** Partition variables into **object-level `V`** and **mechanism-level `Ṽ`**: each object variable `V` has a single **mechanism parent `Ṽ` whose VALUE sets the conditional `Pr(V | Pa_V)`**. The mechanism of a decision variable is its **decision rule**; an agent's policy is a tuple of decision-rule variables. So **the rule generating each variable is a first-class intervenable graph node** — `do(Ṽ = ṽ)` installs a new rule for `V`. (Functional Decision Theory, in their taxonomy, is precisely the agent that *intervenes on its decision-rule node `D̃`* rather than the decision `D`.)

**The identity:** a Gladyshev *structure intervention* on `F_Y` **is** a MacDermott *intervention on the mechanism node* `Ṽ_Y` — both install a new equation/rule for `Y`. MacDermott gives the static graph object; Gladyshev gives its temporal/computational dynamics and the "software-patch" reading.

## 3. The reflexive closure (what makes it SELF-rewrite) — Bongers, Mooij, Everitt

For the rewrite to be *self*-intervention (the agent rewrites *its own* equations), the **mechanism node `Ṽ` must itself be an output of the agent's TSEM** — the agent computes its own next rule from its own state. That closes a loop (`F` writes `Ṽ`, `Ṽ` defines `F` next step):
- **Bongers, Forré, Peters & Mooij 2021** — cyclic-SCM solution/fixed-point semantics for that feedback loop (the reflexive closure we kept flagging as N1).
- **Mooij, Janzing & Schölkopf 2013** — the dynamics→SCM bridge (how a temporal/ODE self yields an SCM at each step).
- **Everitt, Filan, Daswani & Hutter 2016** — the agent-axis layer: when does a rational agent *choose* to self-modify its policy/utility (incentives), the will/objective side of the rewrite.

## 4. Recreation + generalization plan (to confirm before any build)

- **self-state** := a TSEM configuration `v` (Gladyshev Def 1–2) — implemented as a (mechanised) causal model.
- **self-rewrite** := a *structure intervention* `do(F_Y ← F'_Y)` ≡ `do(Ṽ_Y = ṽ')` (Gladyshev Def 11 = MacDermott Def 3) — installs a new equation/rule. This is a DEFINED operator from the literature, not a hand-rolled "move a number."
- **self-INTERVENTION** := the mechanism node `Ṽ` is computed by the agent's own equations (reflexive closure; Bongers semantics) — the agent patches itself.
- **generalize**: `justification J` becomes a property of the *current mechanised graph* — the identifiability of the agent's competence-effect given the current mechanism structure (point vs interval; checkable on the graph). A self-rewrite changes the graph ⇒ changes `J` ⇒ `J` can fall (T1) for principled, literature-grounded reasons (the rewrite opened a back-door / added a mechanism edge).
- **DoWhy fit**: the mechanised graph is a DoWhy/gcm model with object + mechanism nodes; a self-rewrite = `do` on a mechanism node (install a new conditional); `J` = DoWhy's identifiability of the competence effect on the current graph.

## 5. WITNESS — PASSED (`../witness_self_rewrite_dowhy.py`, DoWhy 0.14)

The construct is no longer a claim: it reproduces a DISCRIMINATING result from Gladyshev §6.
Mechanised graph = mechanism node `Xtilde` (rule selector, MacDermott Def 3) + object nodes `X0..X5` (TSEM unroll). Constant rule `F_X(x)=1`. Goal (Gladyshev §6): enforce `X=0` for all `i>0`.
- **baseline** `{Xtilde=CONST1, X0=1}` → `111111` (DoWhy == exact TSEM oracle, cell-exact).
- **VALUE** `do(X0=0)` on the OBJECT node, rule unchanged → `011111`: the injected 0 is **erased at step 1**; a standard intervention CANNOT enforce a persistent change.
- **STRUCT** `do(Xtilde=CONST0)` on the MECHANISM node = the self-rewrite → `100000`: `X=0` for all `i>0`, **persistently**, with `X0` left at its baseline `1` (the EQUATION drove it down, not an injected value).
All three match the exact oracle; intervention purity 1.000. The discrimination (value reverts, structure persists) is exactly *"structure interventions are not expressible in terms of standard interventions"* (Gladyshev §6). A value-only look-alike fails the STRUCT row ⇒ the witness is discriminating (green≠γ satisfied).
- **Reflexive closure (generalization beyond the paper):** endogenous rule node `R_t = controller(X_{t-1})` (Bongers feedback) — the agent rewrites its OWN `F` each step; DoWhy reproduces the self-regulating `101010`/`010101` exactly. This is the self-INTERVENTION (no external `do`).

**Status:** self-state + self-rewrite are BUILT and WITNESSED in DoWhy. Next gate (NOT yet run): the FIXED question "can a self-intervention monotonically increase `J`?" with `J` = DoWhy identifiability of the competence-effect on the current mechanised graph, self-rewrite = structure intervention. Must pass T1–T7 (`../noological_urs_monotone_justification.md`) + external adversary BEFORE banking any conclusion.

## 6. SOLID FOUNDATION — paper-faithful modules (replaces the thin toy; the experiment imports THESE)

Dhruv's challenge ("did you use the SEM and self-intervention implementations from the papers?") was correct: §5's witness reproduced Gladyshev §6 (real) via MacDermott's mechanism-node encoding (real) but did NOT implement the paper machinery or reproduce a non-trivial result. Rebuilt faithfully:

- **`tsem.py`** — Gladyshev Def 1 (signature `(V,R,D)`, SET-valued `F_Y:∏R(X)→2^{R(Y)}`), Def 2 (configuration tree + `v₁→_M v₂`), Def 3 (standard `do(Y^n←y)`), Def 11 (STRUCTURE intervention with the `F^i` override-or-inherit dynamic equations) — implemented verbatim. Reproduces: (A) §2 non-deterministic counter `F_X(x)={9} if x=9 else {0,x+1}` (branches `{0,x+1}`, `9` absorbing, non-determinism present); (B) §6 — standard `do(X⁰=0)`→`0111111` (reverts, cannot enforce) vs structure `do(F_X←0)`→`1000000` (enforces `X=0 ∀i>0`). Both PASS.
- **`mechanised_cbn_newcomb.py`** — MacDermott Def 3 mechanised CBN in DoWhy. Newcomb graph `D̃→D`, `D̃→P̃→P`, `D,P→U`. Reproduces **Fig 4**: EDT=condition(D)→one-box ($989k>$11k); CDT=`do(D)` object→two-box (dominance, common-P estimator); FDT=`do(D̃)` mechanism→one-box ($989k>$11k). All match analytic oracle. **`do(D̃)` ≠ `do(D)` ⇒ opposite actions** — the strong, non-trivial witness that the mechanism-node (structure) intervention is genuinely distinct from the object-node (value) intervention.
- **identity** — Gladyshev `do(F_X←0)` and MacDermott `do(X̃=const0)` produce identical object dynamics (`1000000`). The two operators coincide IN CODE.

The J-experiment MUST import these (`tsem.TSEM`/`StructureIntervention`; the mechanised-CBN builder) so its self-rewrite IS the paper operator, not a hand-rolled echo. All under `self_rewrite_papers/`.
