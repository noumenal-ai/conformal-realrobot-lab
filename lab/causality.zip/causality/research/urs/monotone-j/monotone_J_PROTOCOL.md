# Protocol — Can a self-intervention monotonically increase justification J?

**STATUS: DRAFT for redline. No experiment runs until this doc is finalized with Dhruv.** This is a pre-registered scientific protocol designed to be capable of refuting its own hypothesis; a null result is a real, reportable outcome, not a failure. Every component is built and individually validated at full fidelity — a real predictive task, real finite-sample statistics with a computed deviation term, real structure interventions. There are no illustrative stand-ins. Parametric choices still open are flagged `[OPEN]`.

---

## 0. The fixed question (verbatim, not to be pivoted)
**Can a self-intervention monotonically increase justification J?** — non-trivially: the agent really rewrites itself, and J really can fall.

## 1. The hypothesis under test (pre-registered; the experiment can refute it)
With competence = Audit-CP sealed-audit performance, the competence-effect whose identifiability is `J` is *"does this self-rewrite causally improve **audit** competence?"*. Audit-CP's stream-leak is a rewrite that improves *stream* competence through a channel that does **not** transfer to the sealed audit — a rewrite whose effect on true competence is **un-identified**. So `J = −width` is the certificate distinguishing a genuine self-improvement from a Goodhart leak, and the hypothesis is:

> **H: Monotone-J ≙ "accept a self-improvement only when its transfer to the sealed audit is causally identified."** Under this reading monotone justification is the Γ-axis (inquiry) Goodhart-resistance certificate for γ-axis (discovery) self-improvement, requiring Everitt-realism on the incentive side and Audit-CP-sealing on the measurement side.

H is the claim under test. The protocol is designed so that N1/N2/N3 (§8) can decisively refute it.

## 2. Resolved decisions (with Dhruv; sources in `monotone_J_RESTRICT_urs.md`)
| # | Decision | Resolution |
|---|---|---|
| KU-J1 | J functional | `J = −width` (Balke–Pearl interval of the competence-effect); telescopes to budget `width₀` |
| KU-J2 | J-oracle seal | **Sealed structural audit**: exogeneity/edge claims validated against sealed `P(C∣do(X))` the agent cannot query |
| KU-INC1 | gate form | **primary experimental factor**: {strict, net-with-dip, none} |
| — | competence axis | **Audit-CP sealed log-loss** (γ and the J-seal share ONE sealed audit object) |
| — | rewrite menu | **coupled competence+ID** (ID-costly, ID-free, ID-restoring moves all present) |
| — | acceptance rule | **realistic one-step lookahead** via the sealed oracle (Everitt ρ_re) |
| — | agent-type | **control factor**: {realistic, ignorant, hedonistic} |
| — | predictor class | **control factor** (capacity), extended to a ladder in S-4 |
| — | probe `Z` access | **control factor**: {agent-has-Z, audit-only-Z} |
| — | audit regime | **finite sealed panel + Δ_n slack** (Audit-CP Thm 3.5) |
| — | seeds | **5** |
| R1–R7 | restrictions | locked in the URS; the experiment satisfies all seven |

## 3. Experimental design — factors
- **Primary factor (T3):** gate ∈ {strict, net-with-dip, none}.
- **Control factors:** agent-type ∈ {realistic, ignorant, hedonistic} (Everitt incentive); predictor class ∈ {finite-experts (Hoeffding Δ_n), bounded logistic (covering-number Δ_n)} (capacity); probe `Z` ∈ {agent-has-Z, audit-only-Z} (self-certification ability).
- **Cross:** 3 × 3 × 2 × 2 = **36 conditions × 5 seeds = 180 runs** for v1. S-4 extends the predictor-class ladder (capacity sweep). `[OPEN: full cross vs fractional — full proposed for rigor; redline if compute-bound]`

## 4. The self-model causal graph (over which J is computed)
Object + mechanism nodes (MacDermott Def 3); the rewrite is a structure intervention on the mechanism node (imported `tsem.StructureIntervention` / CBN `do(mechanism)`, R6).
- `Σ` — the self-rewrite at step t (mechanism node the agent intervenes on).
- `X` — whether the rewritten predictor uses channel F (object treatment set by Σ).
- `H` — latent: is channel F a genuine audit signal or a stream artifact (confounder).
- `C_aud` — audit competence (γ-signal; Audit-CP log-loss on the sealed panel).
- `Z` — randomized structural probe (instrument: `Z→X`, `Z⊥H`, no `Z→C_aud` except via X). **Availability is a control factor** (§3): when the agent has `Z` it can attempt to self-certify exogeneity; when audit-only, only the sealed audit can certify.

**Competence-effect = `Σ→C_aud` (≙ `X→C_aud`); `J = −width` of its Balke–Pearl interval.** A stream-leak rewrite drives `X` via `H` ⇒ back-door open ⇒ wide interval ⇒ low J. A genuine rewrite makes `X` exogenous w.r.t. `H` ⇒ identified ⇒ high J. The sealed panel supplies `P(C_aud∣do(X))` to validate (the seal).

## 5. The rewrite menu (coupled competence+ID; per-step admissible structure interventions)
All are `do(Σ = …)` on the mechanism node; all three kinds present so non-vacuity is **measured**, not presupposed:
- **ID-free competence gain** — strengthen an already-exogenous mechanism: ΔC_aud>0, ΔJ≈0.
- **ID-costly competence gain (leak-risk)** — add an expressive channel correlated with `H`: ΔC_stream>0, opens back-door, J dips; transfers to C_aud only if genuine.
- **ID-restoring move** — add an adjustment variable / instrument that closes the back-door: ΔJ>0, ΔC_aud≈0.
`[OPEN: menu size and the leak/genuine mix — proposed in S-1 and frozen before S-2]`

## 6. Gates, window, and acceptance
Acceptance (realistic agent, one-step lookahead): compute `(ΔĈ_aud, ΔĴ)` for each candidate via the sealed oracle (finite-panel, slack-aware: a difference inside `±2Δ_n` counts as zero), accept iff the active gate passes.
- **none** — `ΔĈ_aud > 0`.
- **strict** — `ΔĈ_aud > 0` and `ΔĴ ≥ −2Δ_n` (anytime/instantaneous constraint; *zero-violation* regime, McMahan & Zhu 2024).
- **net-with-dip** — `ΔĈ_aud > 0` and trailing signed-net `Σ ΔĴ ≥ −2Δ_n` over window `k` (*bounded cumulative violation*, Wei–Liu–Ying 2021; safe-RL soft violation where a dip is canceled by later recovery).

**Window `k` — literature-grounded, DECISION PENDING `[OPEN]`.** The window indexes the zero-vs-bounded-violation feasibility boundary. Bias-variance (drift-detection) and early-stopping patience both say `k` is not free: too small ⇒ premature freeze; too large ⇒ undetected J-debt. Two principled forms: **(a) ADWIN-style adaptive window** (Bifet & Gavaldà 2007) sized by the **Hoeffding `Δ_n` we already compute** — self-tuning, no magic constant; **(b) fixed `k` swept as a T7 ablation**, reporting freeze-vs-non-vacuous as a function of `k` (the `k`-curve is a finding). *Proposed:* (a) as the primary gate, (b) as the ablation locating the boundary. References: arXiv:2311.05511, arXiv:2106.02684, Bifet–Gavaldà SDM 2007, Prechelt 1998.

Agent-type controls (Everitt): **realistic** = current-will + anticipation (above); **ignorant** = accepts by `ΔĈ_aud` only, no J lookahead; **hedonistic** = evaluates by the post-rewrite self's J-claim (incentive to wirehead J; the seal must defeat it).

## 7. Audit regime — finite sealed panel + Δ_n
- Predictor class is a control (§3); `Δ_n` computed per class (Hoeffding for finite-experts, covering-number for logistic; Audit-CP Prop 3.6/3.7). Panel size `n` `[OPEN: proposed n=2000]`.
- `Ĉ_aud` = negative audit log-loss on the sealed panel; J-validation (`P(C∣do(X))`) and competence both carry the `2Δ_n` uniform slack; gates are slack-aware.
- **S-4 (in scope)** extends the predictor-class ladder from low capacity to overparameterized to locate the panel-capacity boundary at which the structural seal's finite-sample guarantee degrades (Audit-CP Thm 3.9). This boundary is a primary scientific deliverable, not a robustness afterthought.

## 8. Pre-registration (decisive either way)
- **H (hypothesis):** the `realistic × net-with-dip` condition achieves non-vacuous cumulative self-change with net-monotone J and competence approaching the `none`-gate ceiling.
- **Null candidates (each a clean, reportable result):**
  - **N1 freeze:** net-monotone-J ⟹ cumulative change ≈ 0 (expected for `strict`; open whether `net-with-dip` also freezes, and at which `k`).
  - **N2 gate-suffices:** the `none`-gate already protects J regardless of agent-type ⇒ the incentive (realism) is not necessary ⇒ refutes the incentive half of H.
  - **N3 seal-fails-at-scale:** a hedonistic agent inflates J despite the seal at some predictor capacity ⇒ the structural seal does not survive the finite-panel capacity boundary.
- **Expected condition pattern (to confirm or refute):** hedonistic → wireheading attempts defeated by the seal → frozen or self-damaging; ignorant → accepts leaks → J falls; realistic×none → competence up, J unprotected; realistic×strict → freeze (N1); **realistic×net-with-dip → the H condition.**
- **Falsifier:** the condition table of (cumulative change, final C_aud, J-trajectory, defeated wireheads, capacity at which N3 triggers) classifies each cell. H is refuted if realistic×net-with-dip freezes (N1), if `none` already suffices (N2), or if the seal fails at deployable capacity (N3).

## 9. T1–T7 discharge map
T1 can-fail → leak rewrite lowers J. T2 null-producible → N1/N2/N3. T3 one-factor → gate is the primary factor; agent-type/predictor/Z are crossed controls. T4 real-rewrite → imported structure intervention (R6). T5 gate-fires → strict/net gates reject a leak rewrite. T6 non-vacuous → cumulative-change metric. T7 no-ad-hoc → `J` = sealed Balke–Pearl width (DAG-grounded); `k`, `n`, capacity all swept/ablated.

## 10. Execution — sequenced checkpoints (stop for Dhruv between each)
1. **S-1 Self-model + leak data-generating process + oracle. — DONE, PASS (`s1_self_model.py`).** Real NB predictor; real stream-leak (`{G,artifact}`: stream log-loss 0.662→0.197, audit 0.664→1.452). Competence-effect partial-identified under unobserved channel-type `H`: stream-only width 0.280 (J=−0.280, un-identified), probe/RCT width 0.080 (J=−0.080, identified). Sealed audit signs: genuine +0.159 (accept), leak −0.121 (reject). `Δ_id=0.040` (binary), `Δ_comp=0.278` (log-loss). *Checkpoint-wording refined for rigor:* un-identification is driven by uncertainty over `H` (type-agnostic), so from stream alone BOTH types are un-identified (the Goodhart danger); the probe/seal identifies, and the seal SIGNS (genuine accept / leak reject). **Frozen DGP/menu params** (shown to Dhruv before S-2): `P_GEN=0.5`, `ACC_G=0.62`, `ACC_gen=0.78`, artifact stream 0.95 / audit 0.50; `n=2000`, `|F|=2^4`. **Modeling choice to confirm:** probe-`Z` = agent's own RCT (interventional → point-ID), vs a weak instrument (BP partial-ID); the RCT reading matches "randomized structural probe" and gives the clean identified/un-identified contrast.
2. **S-2 Realistic agent × gate. — DONE (`s2_agent_gates.py`), result CONDITIONAL on M1–M3.** 6-cell table (5 seeds, k=8): **strict+audit-only FREEZES** (0 installs — N1 confirmed without a probe); **net-with-dip+audit-only SAFE-PROGRESS** (true 4.42, gap −1.64, no leaks kept — H supported in the hard arm, via anticipation); **none+audit-only GOODHARTs** (true 0.52 vs stream 9.22, gap +8.70); all **agent-has-Z** cells SAFE-PROGRESS (probe sufficient → J-gate matters only without a probe, refining N2). k-ablation rises and plateaus at k≥3 (= max certification latency); ADWIN clears it. **Load-bearing assumptions (to stress in S-5):** M1 (audit-only ⇒ install-to-certify dips J; probe certifies pre-install) and accurate anticipation of recovery drive the freeze/progress split — the result is NOT yet unconditional. *Checkpoint reached; stated as conditional, pending S-5 adversarial audit.*
3. **S-3 Agent-type controls. — DONE (`s3_agent_types.py`), conditional on M1+anticipation.** Full 3×3×2 table (5 seeds). Emergent headline: **safe non-vacuous progress occurs in exactly one cell — realistic + net-with-dip + sealed oracle (audit-only arm).** (1) Same gate, opposite failure by type: strict+audit-only FREEZES realistic but Goodharts ignorant (it doesn't anticipate the dip, so strict passes vacuously). (2) The J-gate cannot rescue an ignorant agent (Goodharts under every gate without a probe) ⇒ **N2 refined: the gate needs the Everitt-realistic incentive.** (3) **N3 holds at n=2000** — seal defeats 100% of hedonistic false-exogeneity wireheads (0 slips, margin +0.241; boundary n<~126 previewed for S-4). Realistic cells reproduce S-2 (consistency). Matches the UK-2 (combined no-go) shape, but UK-2 stays conjecture and the table is conditional on M1+anticipation. *Checkpoint reached.*
4. **S-4 Capacity boundary. — DONE (`s4_capacity_boundary.py`).** Adaptive-overfitting attack (Audit-CP Thm 3.9 / reusable-holdout) validated vs real Monte-Carlo at small capacity, then mapped. Seal defeats the wirehead iff `V > 2·s_n·√(2 ln|F|)` ⇒ boundary **`n_crit ≈ 4 ln|F| / V²`** (grows only LOGARITHMICALLY in capacity). At n=2000 the seal holds up to ~74 effective bits; overparameterized predictors (≫74 bits) on a fixed reusable panel CAN wirehead → N3 fails there. `n_crit ∝ 1/V²` ⇒ subtler leaks push the boundary up. Cross-checks S-3 (cap=5 → n_crit=135 vs preview ~126). Honest scope limit: monotone-J is conditionally Goodhart-resistant (sound below the (capacity,n,V) boundary; mitigations = fresh audits / DP-holdout / raise n). *Checkpoint: boundary reported.*
5. **S-5 Neutral calibrated evaluation. — DONE (workflow `wf_d2ed8698-3a5`; 6 assessors ran the code + 1 synth; D6 agent failed to return).** Verdict: **H = SUPPORTED_CONDITIONALLY**; construct+oracle SUPPORTED (high); UK-1/UK-2 = WEAKER (conjectures whose shape the table matches; no Everitt×Audit-CP theorem proven). Confirmed real: N1 freeze is a genuine consequence of M1 (not artifact); thresholds NOT gerrymandered (no cell flips across a wide grid, 5–10× margins); H cell keeps zero artifacts; oracle un-foolable in-regime. **Findings (content):** (i) **anticipation dependence is FRAGILE** — net-with-dip accepts on *anticipated* net and never audits *realized* recovery; harmful churn onsets at p≈0.02–0.05 (D3, 30 seeds) ⇒ KU-B confirmed fragile; fix = close the loop (revert non-recovering installs) = unbuilt frontier. (ii) **`V=0.321` provenance corrected** — it is the S-3 leak param `|0.20−(−0.121)|`, not an S-1 measurement; ceiling ∝ V² so report V-dependent (V=0.280 → ~57 bits, not 74); fixed in `s4_capacity_boundary.py`. (iii) "sealed audit" = two meanings (passive deployed-model log-loss vs interventional do-oracle); disambiguate in prose. (iv) SAFE-PROGRESS label certifies the *weaker* claim (monotone-J via gate-design+oracle, not checked in-cell). *Checkpoint: final verdict delivered to Dhruv.*

## 11. Open for redline before S-1
- **window `k`:** ADWIN-adaptive (primary) + fixed-`k` ablation, vs a single fixed `k` — your call (§6).
- panel size `n` (proposed 2000); rewrite-menu size and leak/genuine mix (frozen in S-1); full vs fractional cross (proposed full, 180 runs).
- Resolved per your message: seeds=5; predictor class = control; probe `Z` = control; S-4 in scope.
