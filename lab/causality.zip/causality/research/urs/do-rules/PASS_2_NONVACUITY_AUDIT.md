# Pass 2 — the non-vacuity audit (against kernel-held objects)

**Move type:** act(experiment)-shaped, in-model: each S-rule is tested against
theorems the kernel already holds from `StructureDerivation.lean`. This is where
the mirror is supposed to start dying.

## S2 first (the most important, and the first casualty)

The kernel already holds **`f4_parent_pool_harmless`**: for the forward two-node
skeleton, `κ_{do(X₀=v)} ⊆ κ_obs` always, and when the intervened node's marginal
is full, the surgered support IS the observational slice — **with no premise at
all**. So in the unconfounded two-node world, S2's premise does no work: the rule
is TRUE BUT VACUOUS (its conclusion holds unconditionally). Where would the
premise bite? Only where something can differ: a THIRD variable — a latent input
shared between `Z`'s mechanism and the context. S2's content therefore does not
live in the mirror at all; it lives in the **confounded refinement**: with latent
`L`, the observational slice `κ|_{Z=z}` sees only `L`-values compatible with
`Z=z` (the `(L,Z)`-fiber), while surgery sees ALL of `supp L`. The slice and the
surgery differ exactly when the `(L,Z)` support is non-rectangular. **S2 dies as
stated; its corpse points at the real rule: the premise is the rectangularity of
the LATENT-INTERVENED interface, and the failure is graded by that defect.**

## S3 (the definitional casualty)

"Surgery on `Z` leaves the `Y`-shadow unchanged when `Z` is support-irrelevant to
`Y`" — audit: in the constructive core, surgery is `Mech.doIntervene`, and if `Z`
is not an ancestor of `Y`, `solve` at `Y` literally does not read the surgered
entries (fuel recursion consumes only ancestors). The conclusion follows by
UNFOLDING THE INTERPRETER — a definition-unfold, not a theorem (A4: ≤3-step
grade). S3-as-mirror is **definitionally true = not a rule**. Its non-degenerate
content, if any, must concern the case Pearl's `G_X̄,Z̄(W)` handles: `Z` an
ancestor of `Y` whose influence is BLOCKED by the context — blocking is a
path/interface property, and at support level "blocked" is again a rectangularity
statement about a CONDITIONAL interface. S3 folds into the same shape as S2's
refinement.

## S1 (the subsumption casualty)

"Slicing by `Z=z` preserves the `Y`-shadow when the `(Y,Z)` fiber-interface is
rectangular" — audit: this is precisely `fiberRect`/cross-closure of the
`(Y,Z)`-interface, i.e. **a clause of the five-way equivalence already in the
kernel** (measurements side). As a *rule* it adds no inferential step beyond the
theorem we have; citing it as a new do-calculus rule would be re-labeling
(sophism risk flagged: renaming an owned theorem as a "new rule" is exactly the
inflation the protocol exists to catch).

## Verdict of the audit
Prediction from Pass 1 confirmed and exceeded: S3 definitional, S1 subsumed, S2
vacuous-as-stated. **The naive mirror is dead in all three positions.** What
survives is a direction, not a rule set: every corpse points at the same organ —
premises must be about interfaces the OBSERVATIONAL layer cannot see (latent
interfaces, child-side creation, frame growth), not about the visible interfaces
Pearl's rules already govern. Pass 3 rewrites from the corpses.
