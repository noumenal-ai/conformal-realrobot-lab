# Pass 6 — THE RESTRICT (final rewrite)

**Move type: RESTRICT — chosen, not escaped-into.** A5 forbids restriction as an
exit from difficulty; this is the other kind: the adversarially-forced sharpening
of a rule-space that five passes have shown to be mostly inflation. Every cut
below names where the cut material LIVES (nothing deleted, everything relocated)
— which is what makes this a restrict and not a retreat.

## The restriction (three cuts)

**CUT 1 — the rule set restricts to SD1, SD2, SD3.** All mirror-rules (S1–S3)
and the ungated D1 are out permanently: definitional, subsumed, or
invisible-premised (Passes 2, 4). The calculus does not get a rule it cannot
apply.

**CUT 2 — rule-hood restricts to: DECIDABLE-FROM-THE-AGENT premise + EXACT
conclusion.** All graded/quantitative content (defect-bounded gaps, leakage
floors) is expelled from the rule layer and relocated to a meta-theorem layer —
"the price of applying a rule outside its premise" (approximate five-way,
Phase-B bridge). Rules license actions; meta-theorems price violations. Mixing
the layers was the sophism engine of Passes 3–4.

**CUT 3 — conclusions restrict to the declared mechanism class.** SD1/SD2
conclusions are exact within a named program class (tables at binary grain now);
outside it, the rule DOWNGRADES its conclusion to the class-free part
(existence of the created region, not its contents). No rule speaks past its
class. (This is the capacity lens entering the calculus as a side-condition —
the SCM-automata strand's first appearance inside the rules themselves.)

## The restricted calculus (the proposal, as it stands after six passes)

> **SD1 (regime certification).** One logged surgery + observed interface
> rectangularity across the logged family ⟹ every unperformed surgery on that
> node equals its observational slice. *(Consumes logged actions; Pearl has no
> such slot.)*
> **SD2 (creation).** Fiber-membership of the target value ⟹ the do-object's
> constructible part and created remainder, as computed data. *(Partial
> constructibility of do-objects; no distribution-level analogue.)*
> **SD3 (frame growth).** Decidable non-amalgamation over a cyclic cover ⟹
> licensed latent introduction carrying its completion obligation. *(Operates on
> R itself; outside Pearl's language entirely.)*

Form-level mirror of Pearl retained (premise ⟹ boundary-crossing equation);
content-level mirror abandoned — the six passes showed the genuine rules live
exactly where the distribution language cannot follow (logged self-action,
created support, frame growth). That the three survivors are one-per-corpse of
the three original mirrors is the cleanest available evidence this was forcing,
not decoration.

## Standing obligations exiting the loop (A5 ledger — the restrict's remainder)
1. SD1 soundness theorem + contrast witness (confounded variant) — buildable,
   binary grain.
2. SD2 restatement through the rule form over the F4 pair — near-free.
3. SD3 completion theorem (or its counterexample, which would attach the
   failing-cover datum to the license) — cyclic-converse programme.
4. The meta-theorem layer (graded prices) — Phase-B measurements bridge.
5. The completeness question inherited from the foundations: is
   {R1,R2,R3} ∪ {SD1,SD2,SD3} complete for the enriched problem (identification
   + logged actions + frame growth)? — the long-game flagship, untouched by the
   restrict.

**Exit state:** rule set proposed at its honest size (three), each with checkable
premise, exact scoped conclusion, named witnesses, named obligations. Ready for
Dhruv's read; nothing banked as KK.
