# Pass 4 — the sophism hunt (maximum adversarial pressure on D1–D3)

**Move type:** adversarial audit of my OWN Pass-3 candidates. Target: the three
canonical inflations — (i) re-labeling an owned theorem as a "rule", (ii) a rule
whose premise is undecidable in the setting where its conclusion matters,
(iii) a rule that is secretly about MY formalism rather than about causality.

## Attack on D1 (latent-interface rule)

**(i) Re-labeling?** Partially GUILTY as drafted. "Slice = surgery iff interface
rectangular" — the biconditional's easy direction (rectangular ⟹ equal) is the
five-way + surgery-definition composed: a theorem we own, wearing a rule costume.
What is NOT owned: the *inference direction across regimes* — using the premise
checked on OBSERVED objects to conclude an equation about an UNPERFORMED
intervention. But here the second attack lands:
**(ii) Undecidable premise where it matters.** The premise is rectangularity of
the `(L,Z)` interface — and `L` is LATENT: its support-interface is not readable
from L1 data. In the setting where D1's conclusion matters (deciding whether to
trust a slice as a surrogate for surgery), the premise is EXACTLY the thing you
cannot check. As stated, D1 is a rule whose applicability is invisible — the
support-level copy of "assume ignorability", i.e. the assumption Pearl's
back-door already makes, with no gain. **D1 as drafted is a sophism of type (ii).
It survives only if the premise is replaced by something OBSERVABLE that
certifies the latent interface** — candidates: (a) a logged auxiliary regime
(F3-style: one intervention certifies the interface for the others), or
(b) an observable defect-signature that lower-bounds the latent interface's
defect (a genuine theorem obligation, NOT owned yet). Both convert D1 into a rule
with a checkable premise; (a) is buildable now, (b) is a named conjecture.

## Attack on D2 (creation rule)

**(i) Re-labeling?** The parent/child split is owned (kernel theorems). The RULE
content — "the constructible part of an unperformed child-surgery is exactly
[computable Finset], the remainder is created" — is a genuine inference about an
unperformed act. **(ii) Premise decidability:** the fiber-membership premise is
computed from κ_obs — decidable, observable. PASSES. **(iii) About causality or
about my formalism?** The created region survives translation: in any SCM
formalism, acting on an effect realizes configurations observation cannot
exhibit. Content is substrate-portable. **D2 SURVIVES, with one honest demotion:**
its conclusion about the created remainder's CONTENTS (not just existence) needs
the mechanism class restricted (tables: computable; open classes: only bounds) —
scope-lock required.

## Attack on D3 (frame rule)

**(i) Re-labeling?** The non-gluing⟹no-joint theorem will be owned
(cyclic-converse programme); the RULE adds the frame-transformation (introduce
`L`, placed by the failing cover). The move itself is not a theorem we own — it
is a grammar operation with a soundness obligation: after introducing `L`, a
joint EXISTS (completion) — that existence is a real theorem to prove, giving
the rule genuine content. **(ii) Premise:** decidable (Graham/amalgamation
machinery, kernel-held). **(iii)** Frame growth is the CHT-identified boundary of
the field, not an artifact of my encoding. **D3 SURVIVES with its soundness
obligation named** (completion theorem: every Specker-type failure is resolvable
by one latent — provable? Vorob'ev-adjacent; if false in general, the rule's
license must carry the failing-cover data. Either way: real content.)

## Standing after the hunt
D1 dead-as-drafted (premise invisible), resurrection path (a) buildable /
(b) conjecture. D2 alive with a scope-lock. D3 alive with a named soundness
obligation. The hunt also exposed the criterion the final RESTRICT must enforce:
**a rule's premise must be checkable by the agent that would apply the rule** —
decidability in principle is not enough; decidability FROM THE AGENT'S OBSERVABLES
(plus its logged actions) is the bar. Pass 5 rebuilds the rule set under that bar.
