# Pass 5 — rebuild under the observability bar

**The bar (from Pass 4):** a rule's premise must be checkable from the applying
agent's OWN observables + its LOGGED actions. Not "decidable in principle" —
decidable from the agent's position. This is F4 feeding back into the calculus
design: the rules and the reflexive-soundness principle share one epistemic base.

## The rebuilt candidates (final shapes before the RESTRICT)

**SD1 — the regime-certification rule (D1 resurrected via route (a)).**
Premise (checkable): a LOGGED intervention `do(Z=z₀)` whose executed support
equals the observational slice at `z₀`, plus rectangularity of the OBSERVED
`(context, Z)` interface across the logged family. Conclusion (exact): for every
other value `z`, `κ_{do(Z=z)} = κ|_{Z=z}`-slice — unperformed surgeries read off
observational data, certified by ONE performed surgery. The one-shot already
holds this rule's germ (`regime_orients_executed`: one logged regime resolving
what observation cannot). Soundness proof obligation: finite, mechanism-class-
scoped. NEW relative to Pearl: the premise consumes logged-action data as a
first-class object; Pearl's rules have no slot for "what I already did".

**SD2 — the creation rule (D2, scope-locked).**
Premise (checkable from κ_obs): `w ∈` every relevant mechanism-fiber /
`w ∉` some fiber. Conclusion (exact, two-sided): the constructible part of
`κ_{do(Z=w)}` as a computed Finset, and the created remainder as a computed
hull-region — with contents guaranteed only under the declared mechanism class
(tables now; classes with structure later). NEW relative to Pearl: partial
constructibility of do-objects, with the created region handed over as data.

**SD3 — the frame rule (D3, soundness obligation attached).**
Premise (checkable from observed marginal family): pairwise-consistent,
non-gluing over a cyclic cover (decidable; Graham machinery kernel-held).
Conclusion: introduce latent `L` on the failing cover; license carries the
completion obligation (a joint exists after introduction) or, where completion
fails, the failing-cover datum itself. NEW absolutely: operates on R (the frame),
which no Pearl rule touches.

## Non-vacuity witness obligations (contrast pairs, per the discipline)
- SD1: logged-regime family where the premise holds and the unperformed-surgery
  equation is kernel-checked TRUE; a confounded variant (explicit latent in the
  mechanism, marginalized in the observables) where the premise FAILS and the
  equation FAILS. Both `decide`-grade at binary scope.
- SD2: the F4 pair already IS the witness skeleton (parent-side harmless /
  child-side creates) — needs only restating through the rule form.
- SD3: Specker triple (non-gluing, premise holds, latent completion exhibited)
  vs path cover (glues, premise fails, no license). Machinery exists.

## What deliberately did NOT survive to this pass
The graded clauses ("gap bounded by defect", "leakage ≥ five-way floor") — they
are TRUE directions but they are THEOREMS ABOUT the rules' failure modes, not
rules: a rule with an approximate conclusion licenses nothing an agent can act
on exactly, and grading premises reintroduces unobservability. Held for Pass 6's
disposition.
