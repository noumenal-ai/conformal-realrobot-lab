# Pass 7 — compound oscillation on the survivors + the cardinality oscillation

**Move type:** compound rotation (L1 support × L5 frame × L6 agency, with L3
intension in the SD2 arm) — the rules attacked IN COMPOSITION, not isolation;
then the oscillation on the NUMBER of rules itself.

## Kill: SD1 dies under joint rotation (value-selective latent coupling)

Construction (in-model, kernel-checkable at binary grain): latent `L`;
`Z = L`; `Y = if Z=1 then L else U_Y`. Observed `κ = {(0,0),(0,1),(1,1)}`.
Logged `do(Z=0)`: surgery support `= {(0,0),(0,1)}` = the slice — **SD1's premise
HOLDS**. SD1 concludes `do(Z=1) = {(1,1)}` (the slice). Truth: surgery frees `L`,
so `do(Z=1) = {(1,0),(1,1)} ≠` slice. **SD1 is UNSOUND as drafted**: one logged
value cannot certify another when the latent coupling is value-selective — the
latent hides in exactly the rows the log never visited. What remains standing:
(i) `slice ⊆ do-support` — universally true, but premise-free: a THEOREM, not a
rule; (ii) equality at the logged values themselves — true but log-definitional
(A4-trivial); (iii) the genuine content is a MISSING rule: **cross-value
transfer**, whose premise must be an *observable invariance across the logged
family* (F3-machinery generalized). Named hole, conjecture-grade. Note F3 itself
survives this kill — orientation is a weaker conclusion than value-transfer.

## Split: SD2 survives and STRENGTHENS on its child side

Rotating the latent leg against SD2: parent-side readings inherit SD1's corpse
(same latent mechanism). But the child side — SD2's original habitat — is
**latent-ROBUST**: severing the child destroys every path into it, including the
latent's; the created-region computation (`unaffected-marginals × {w}`) is exact
from observables even under confounding. The oscillation converts SD2's
scope-lock into a sharper theorem obligation: child-side creation is computable
latent-robustly; parent-side is not SD2's business (it was the dead SD1's).

## Amend: SD3 survives with an F4 gate (the phantom-latent sophism)

Rotating agency against SD3: if the marginal family was produced by the agent's
own UNLOGGED actions, pooling can manufacture non-gluing marginal families that
no single joint hosts — SD3 would then FORCE A PHANTOM LATENT to explain what is
actually the agent's own forgotten agency (frame growth as the price of unlogged
self-action — the sophism F4's corruption witness already gestures at). SD3's
premise must require F4-soundly-generated marginals (per-tag or certified
observational). Obligation: the phantom-latent witness (pooled regimes whose
pooled marginals are pairwise-consistent and non-gluing while each tagged regime
glues) — `decide`-grade, to be constructed.

## The headline the compound rotation forced

**F4 is not a rule of the calculus — it is the calculus's PRECONDITION** (its
frame rule in the Hoare sense): all surviving rules are sound only over
reflexively-sound data. The Pass-4 bar (premises decidable from the agent's
position) and F4 are one requirement seen from two sides. This was invisible to
every single-rule audit; it needed the rules composed.

## The cardinality oscillation — more or fewer? BOTH, and here is the why

**Fewer, now:** the honest post-attack count is **TWO** sound rules (SD2′
child-creation latent-robust; SD3′ frame-growth F4-gated) + **one precondition**
(F4) + **one named hole** (cross-value transfer — SD1's repair, needs an
invariance premise) . Not three: SD1 was the weak member and is dead as drafted.
Fewer ≠ loss: each removal left a theorem, a hole with a specification, or a
precondition — the material relocated, per the restrict discipline.

**More, eventually — and the rotation says where:** the count is not arbitrary.
Conjecture (the WHY): **rules ≈ boundaries of the ignorance geometry the language
can cross.** Pearl: one boundary (see/do) × three syntactic positions = 3 rules.
Ours: each rule crosses a boundary Pearl's language lacks — possible/created
(SD2′), frame/frame-grown (SD3′), logged-past/unlogged-future (the hole). A
FOURTH boundary already exists in the programme and has no rule yet:
**denotation/syntax — the structure-intervention boundary** (when does a REWRITE's
effect equal a value-do? MacDermott/Gladyshev; SiSCM's C1; our intensional
stratum). That is the next rule's habitat — flagged UU→KU, deliberately NOT
drafted this pass (it deserves its own mirror-kill-restrict loop).

**Exit state:** rule set = {SD2′, SD3′}; precondition = F4; holes = transfer rule
(spec'd), rewrite-boundary rule (flagged); the boundary-counting conjecture as
the structural explanation of cardinality. Nothing banked; three new witness
obligations (SD1-kill executed pair, phantom-latent pair, child-side
latent-robustness) — all binary-grain `decide`-able.
