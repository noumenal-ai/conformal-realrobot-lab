# Pass 3 — rewrite from the corpses (where the mirror broke IS the content)

**Move type:** act(imagine), now informed by two kill-passes. The rewrite
principle extracted from Pass 2: *Pearl's rules move expressions across the
seeing/doing boundary using premises about VISIBLE structure (graph separations).
The support calculus earns new rules only where its premises concern structure
the distribution-level language cannot state.* Three such places are already
kernel-witnessed:

## D1 — the latent-interface rule (from S2's corpse)
With a latent `L` feeding both `Z` and its context:
`κ_{do(Z=z)} = κ|_{Z=z}`-as-slice **iff the (L,Z) support-interface is
rectangular**; when non-rectangular, surgery strictly enlarges the slice, and the
enlargement is the latent fiber-defect made visible. Premise: decidable
(defect of a designated interface = 0). Conclusion: exact Finset equation.
*What it adds over Pearl:* the premise is support-level and DECIDABLE, needs no
d-separation oracle over an assumed graph — it reads the ignorance structure
directly. *Sophism check pending (Pass 4):* is this just "five-way applied at
the (L,Z) interface"? The candidate answer: no — it is an INFERENCE across the
do-boundary licensed by that theorem, i.e. a rule USING the five-way as its
soundness proof. To be forced.

## D2 — the creation rule (from the kernel's own discovery)
`f4_unlogged_corrupts` + `f4_parent_pool_harmless` split cleanly:
parent-side surgery NEVER creates support outside the observational one;
child-side surgery CAN (`(1,0) ∉ κ_obs`). The rule: `κ_{do(Z=w)}` is readable
from observational slices **iff `w` lies in every relevant mechanism-fiber**
(decidable); otherwise the surgered support contains CREATED configurations that
no amount of L1 data exhibits — and the created region is computable
(hull-style) rather than merely flagged. *What it adds over Pearl:* Pearl's R2/R3
tell you when do-expressions REDUCE to seeing-expressions; D2 tells you when the
do-object is PARTIALLY CONSTRUCTIBLE and hands you the constructible part plus
the created remainder as separate Finsets. No distribution-level analogue: the
created region has probability data only after the act.

## D3 — the frame rule (no mirror exists; the genuinely new rung)
From the foundations file (R4c): a pairwise-consistent, non-gluing marginal
family over a cyclic interface cover FORCES a latent — the observed frame `V`
cannot host any joint. As a RULE: from decidable non-amalgamation, infer
`introduce L` (frame growth) with the licensed placement read off the failing
cover. Pearl's calculus manipulates expressions over a FIXED `V` and cannot even
state this move. This is the rule the CHT note's §7-B3 hands up (factor genesis).

## The shape claim (to be attacked in Pass 4)
All three candidates share a form: **decidable support-premise ⟹ exact
conclusion about an object the L1/L2 language cannot construct** (a latent
interface / a created region / a new variable). If Pass 4 finds any of the three
premises undecidable, any conclusion inexact, or any content re-labeled from an
owned theorem, that candidate dies too.
