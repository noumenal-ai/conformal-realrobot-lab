# Pass 1 — the naive mirror (deliberately pre-adversarial)

**Move type:** act(imagine), gated; Pl_imagine deliberately UNPRUNED this pass — the
protocol is mirror-first, then force non-vacuity or fail. Everything here is a
candidate, nothing is banked.

**Pearl's rules (the objects being mirrored), on `P(y | do(x), z, w)`:**
- **R1** (insert/delete observation): drop `z` from the conditioning iff
  `Y ⊥ Z | X,W` in `G_X̄`.
- **R2** (exchange action/observation): `do(z) ↔ z` iff `Y ⊥ Z | X,W` in `G_X̄Z̲`.
- **R3** (insert/delete action): drop `do(z)` iff `Y ⊥ Z | X,W` in `G_X̄Z̄(W)`.

All three: a *graph-separation premise* licenses an *equation between
distribution-level expressions*. The mirror axis: distributions → supports,
d-separation premises → rectangularity/defect premises, equations of measures →
equations of Finsets.

## The three mirrored candidates

- **S1 (insert/delete a support observation).** Slicing the support by an
  observation `Z = z` does not change the `Y`-shadow, provided the `(Y,Z)`
  interface is rectangular over the context:
  `projY (κ |_{z}) = projY κ` when the relevant fiber defect is 0.
- **S2 (exchange surgery/slice).** The surgered support equals the observational
  slice: `κ_{do(Z=z)} = κ |_{Z=z} (as slices over the non-Z coordinates)`,
  provided the interface between `Z`'s mechanism inputs and the conditioning
  context is rectangular (support-level ignorability).
- **S3 (insert/delete a surgery).** Surgering `Z` does not change the `Y`-shadow:
  `projY (κ_{do(Z=z)}) = projY κ`, provided `Z` is support-irrelevant to `Y`
  (no admissible configuration couples them — the rectangularity of the `(Y,Z)`
  interface in the surgered support).

## Declared exit condition for this pass
Each S-rule survives only if a NON-VACUITY witness exists: a case where the premise
does real work (premise-holds ⟹ conclusion; premise-fails ⟹ conclusion-fails,
both kernel-checkable). Pass 2 runs that audit against the objects the kernel
already holds. Prediction logged before auditing (honesty anchor): I expect at
least one of these to be definitionally true (vacuous) and at least one to be
subsumed by the five-way. If all three survive unmodified, THAT is the suspicious
outcome.
