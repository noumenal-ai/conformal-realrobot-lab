# URS — The BCII Philosophy of Causation (Pearl Causal Hierarchy)

**Object.** Bareinboim, Correa, Ibeling & Icard, *On Pearl's Hierarchy and the Foundations of Causal Inference*, Tech. Report R-60 (first version Jul 2020, rev. Mar 2021; chapter in the Pearl festschrift).
**Instrument.** URT URS ⟨A, M, R, T⟩ + ignorance geometry (KK/KU/UK/UU) + measurement classes (Pl/Coh/Inv/Comp), applied to their theory **as the object**.
**Provenance.** Built from a full read of §1.1–§1.5 (pp. 1–55) + bibliography. This is an *object/problem URS*: my reasoner-state (Γ about me) is deliberately held out; §7 is the only place the Zetesis coupling appears, and it is marked as conjecture for human (Dhruv) verification.
**Fidelity key.** §1–§4 reconstruct their *explicit* commitments (page-cited). §5 KK/KU are theirs; UK/UU are my URT-reading. §6 is my typing. §7 is explicitly cross-framework structural mapping (imagine-route; verify).

---

## 0. One-line reading
Their philosophy = **ontological realism about modular mechanisms** (the SCM *is* "Nature") + a claim that the **grammar of causal questions stratifies into three irreducible expressive layers** (seeing / doing / imagining) + a **theorem (CHT)** that the strata generically do *not* collapse — from which the entire discipline of causal inference, and a human-compatible-AI telos, follow.

## 1. A — Identity / Axioms (their Will-snapshot; held fixed, not argued)
- **A1 — Mechanistic realism + reality/data dichotomy** (Locke, Hume). The world *is* a collection of modular causal mechanisms; they are generally unobservable; they emit observable traces ("data"); reality ≠ data, and the mechanisms are "there regardless of our ability to discover them." [pp. 4–5]
- **A2 — The SCM is the ground-truth object.** 𝓜 = ⟨U, V, 𝓕, P(U)⟩; "Nature" evaluates it (their word, ftn 11, p. 10); essentially any causal inquiry is an inquiry about this object. [Def. 1, p. 8]
- **A3 — Modularity / autonomy.** Each mechanism vᵢ ← fᵢ(paᵢ, uᵢ) is independently manipulable; intervention = *surgical* replacement of one mechanism, the rest invariant (inherited from Haavelmo / Strotz–Wold / Simon). [Def. 3]
- **A4 — Recursion + a temporal ordering** of mechanisms — the *only* substantive assumption the CHT requires, needed to guarantee unique valuations. The CHT is otherwise "theory-neutral." [p. 23]
- **A5 — Will-direction (telos): human-compatible AI.** Causal structure is the hallmark of human intelligence (developmental psych; children-as-scientists); connecting AI to the PCH's "fundamental dimensions of human experience" (seeing/doing/imagining) is the route to safe, robust, explainable, socially-aligned AI. [abstract; §1.5, p. 55]

> A4-honesty: A1/A2 are **axioms, not results**. Their realism is contested *in their own bibliography* — Maudlin 2019 doubts Layer-2 meaningfulness, Dawid 2000 ("Causal Inference Without Counterfactuals") doubts Layer 3. They acknowledge this (ftn 4, p. 5) and proceed. Realism is their *admitted constraint* (Will), not something the chapter discovers.

## 2. R — Grammar of structure (what is expressible; "R defines askability")
The heart of their philosophy, and the deepest URT-resonance: **the PCH is literally a stratification of askability.**
- R is three nested symbolic languages (Def. 8, p. 19): **𝓛₁ ⊊ 𝓛₂ ⊊ 𝓛₃**.
  - **𝓛₁ (seeing):** P(Y=y) — observational. "What is / how would seeing X change belief in Y?"
  - **𝓛₂ (doing):** adds P(Yₓ=y) — *one* intervention/world. "What if I do X?"
  - **𝓛₃ (imagining):** probabilities over **conjunctions of inconsistent-subscript terms** P(Yₓ=y, Z_w=z) — *multiple, mutually counter-to-fact worlds at once*. "Why / what if I had acted differently?"
- The SCM supplies the **semantics** (Defs 2/5/7); syntax (Def. 8) + semantics = the PCH (Def. 9, p. 20).
- **Ontological R-thesis (not epistemic):** "as soon as one admits a domain can be represented by an SCM (whether or not we know much about it), the hierarchy of causal concepts *already exists*." The askability-strata are a structural consequence of the ontology, prior to any agent's knowledge. [p. 5]
- **The expressiveness stakes** (their sharpest question, ftn 24, p. 20): is each higher layer *genuinely* more expressive, or is the richness an **illusion** — "our talk of causation and imagination … no more than mere figures of speech, fully reducible to lower layers"? Analogy by cardinality: ℤ⊊ℚ⊊ℝ, yet |ℤ|=|ℚ| (illusion) while |ℚ|<|ℝ| (real). *Which kind is the PCH?*
- **Collapse** (Def. 10, p. 22) formalizes the "illusion" horn: layer j collapses to i iff agreement at i forces agreement at j (every layer-j query answerable with layer-i data). 𝓜 ∼ᵢ 𝓜′ = indistinguishable given only 𝓛ᵢ — a **generalization of identifiability** (Padoa's method, ftn 25).

## 3. M — Grammar of change (their theory of intervention/becoming)
- **do(x)** = surgical mechanism-replacement: submodel 𝓜ₓ with 𝓕ₓ = {fᵢ : Vᵢ∉X} ∪ {X←x}; P(U) invariant. [Def. 3]
- **Potential response** Yₓ(u) = solution of 𝓕ₓ at unit u; Layer-2 valuation averages over P(U). [Defs 4–5]
- **Effectiveness** (Def. 6): the intervened variable is observed at its set value w.p. 1 — the meaning of a *hard* intervention, distinguished from Bayesian conditioning.
- **𝓛₃ / counterfactual M-move** = the cross-world construction: the *same* u, *multiple* submodels 𝓜ₓ,…,𝓜_w simultaneously (Def. 7) — the abduction→action→prediction structure. The cross-world *conjunction* is exactly what 𝓛₁/𝓛₂ syntactically cannot express (single subscript only). [Ex. 5, p. 17: "no conceivable experiment" reaches it.]

> URT note: their do() is precisely Pearl's interventional do — a **strict subset of URT's act(·) superclass**. Their M has *no* grammar-modifying act (no ABD-R / ABD-A); the only "change" is intra-grammar intervention. See boundary §7-B2.

## 4. T — Traces (their encounter material)
- 𝓛₁ data (observational P(V)); 𝓛₂ data (experimental/RCT P(V∣do(x))); the SCM's induced distributions.
- Their worked traces *are* the philosophy-in-action, each a Pl-witness for non-collapse (two SCMs identical below, divergent above):
  - **Drug/symptom Simpson reversal** (Ex. 2/4): 𝓛₁ says drug helps (+0.43); 𝓛₂ says drug *hurts* (−0.15).
  - **"Would S have survived?"** (Ex. 7): 𝓜 and 𝓜′ agree at 𝓛₁ **and** 𝓛₂ yet give *opposite* 𝓛₃ answers about why S died — "the best explanation … completely different depending on whether the world is like 𝓜* or 𝓜′."
  - **MD vs AI physician** (Ex. 14, pp. 52–54): 𝓛₁ prefers AI (0.9 > 0.8); 𝓛₂ prefers human MD (0.94 > 0.89, full reversal); 𝓛₃ says give patients the treatment they'd be inclined *not* to choose. Punchline: "optimal decision-making emerges from a combination of human intuitions, even when wrong, with machine capabilities."

## 5. Ignorance geometry (KK/KU/UK/UU — their theory as an ignorance-engineering move)
- **KK (established / treated as settled):**
  - PCH well-defined given an SCM (Def. 9).
  - **CHT (Thm. 1, pp. 22–23):** PCH almost-never collapses — the collapse set is **Lebesgue measure zero** over (a suitable encoding of 𝓛₃-equivalence-classes of) SCMs. ⇒ the richness is **real** (the ℝ-not-ℚ horn).
  - **Corollary 1:** to answer at layer i, need knowledge at layer i *or higher* — the formal "no causes-in, no causes-out" (Cartwright 1989).
  - 𝓛₁-constraints / Bayesian networks are **insufficient** for causal reasoning (Ex. 10; Pearl's own "probabilities … can't [express causality]" quote, p. 30). CBNs (𝓛₂-constraints = the "listening"/missing-arrow *invariances*) are the minimal carrier; do-calculus bridges layers.
- **KU (articulated open / resolved in-paper):**
  - "Does the PCH collapse for a given 𝓜*?" — articulated (Def. 10), resolved generically by the CHT (a KU→KK move *over the fixed grammar*).
  - "When *can* a layer-i quantity be inferred from layer-j<i data?" → the identification problem; partially resolved (do-calculus + CBNs under partial-SCM knowledge); left as the discipline's standing KU.
- **UK (unarticulated regularity their framing presses on — read through their text):**
  - The CHT's real force: lower-layer **discovery** cannot manufacture higher-layer answers; the missing ingredient is always **structural assumption imported from outside the data** (a causal graph). In URT terms this is an UK they *feel but do not name*: causal inference is irreducibly an **inquiry-axis (R/Γ)** act, not a discovery-axis (γ) one. They name the symptom ("additional assumptions are logically necessary," p. 27) — not the axis.
- **UU (unaskable in their grammar):**
  - Anything needing grammar **beyond the fixed 3-layer, fixed-V SCM ontology**: open-universe / variable-set growth (their own Ibeling–Icard "open-universe causal reasoning" gestures at the door but the chapter does not enter), and **the genesis of the variable inventory V itself**. The PCH presupposes V fixed; "where do the factors come from?" is UU here. (This is precisely the factor-promotion regime — see §7-B3.)

## 6. Measurement-class typing (Pl/Coh/Inv/Comp on their philosophy — my reading)
- **Pl (admissibility):** their objects (SCM, the three languages) are crisply admissible; g_Pl is nonzero **only** at the philosophical boundary "is 𝓛₃ meaningful?" (Maudlin/Dawid dissent) — crisp elsewhere.
- **Coh (composition/competition):** the layers *compete* precisely — a dataset at layer i is **non-composable** with a query at layer j>i (the "tension between layers" of Ex. 14). The non-composability is the CHT's content, not a defect.
- **Inv (robustness) — the CHT is fundamentally an Inv-class theorem.** Layer-distinctness is **robust under perturbation of the SCM** (measure-zero exceptions). "Almost-never collapse" = "the layer distinction survives generic perturbation." This is the single cleanest URT-typing of their main result.
- **Comp (coverage) — the expressiveness question is a Comp-class question.** Does adding a layer add genuine question-space coverage, or is it redundant? CHT answers Comp-**positive** (each layer covers questions the lower cannot). The nested-counterfactual "definable in 𝓛₃" result (ftn 27) is Comp-**null**: 𝓛₃ is already complete for that extension.

## 7. Coupling to the Zetesis programme — resonance & boundary (SEPARATE axis; conjecture, verify)
*Not part of their philosophy — this is the cross-framework mapping that makes UK1 actionable.*

**Resonance (why UK1 is worth inheriting):**
- Their R-thesis "the languages define which causal questions are askable" *is* URT's "R defines askability." The PCH is a worked, formal instance of a stratified R on the SCM substrate.
- **The CHT, in URT terms, is a theorem that the inquiry axis (Γ / R-growth) is irreducible to the discovery axis (γ).** Footnote 5 (p. 6) is explicit and striking: the Pearl hierarchy is *orthogonal* to computational hierarchies — "no amount of time or space for computation — and no amount of data either — will allow making inferences at higher layers" if the representation language only reaches a lower layer. That is a measure-theoretic vindication of the URT claim that you cannot climb UK→KU→KK by discovery alone; you must **expand the grammar** (import a causal graph = an R-move).
- This is the backbone D2 wanted: the **observational⊥interventional separation** = "𝓛₂ almost-never collapses to 𝓛₁"; the **"abduction collapses"** observation = 𝓛₃-irreducibility (the cross-world abduction step is the layer no 𝓛₂ experiment reaches).

**Boundary (Pl-kills — what NOT to inherit; instance-vs-axiom discipline):**
- **B1 — realism vs Will.** Their A1/A2 is mechanistic *realism*: a single agent-independent ground-truth SCM ("Nature"). URT Axiom 0 puts directionality/"truth" downstream of **Will** — no global agent-independent Truth primitive. Inheriting the CHT must **not** smuggle in their realism: in URT the "true SCM" is a *Will-snapshot / admitted constraint*, and the CHT becomes a statement about a *committed* model-class Ω, not about Nature. Port the CHT as a γ-result over a Will-fixed Ω; drop the metaphysics.
- **B2 — fixed-3-layer instance vs open R.** The PCH is a **closed, 3-level R** tied to the SCM ontology with V fixed. URT's R is open-ended (new M-classes inventable; ABD-R). Treating the PCH as URT's R-*class* is the instance-as-axiom failure. The PCH is **one** stratification of askability on **one** substrate — structurally analogous to how HC is one instance of the Inv class on Finsets. Inherit it as a Layer-3 instance-chart, never a Layer-1 axiom.
- **B3 — the UU that is your contribution.** The PCH presupposes V fixed, so **factor genesis** (where do the variables / typed factors come from?) is UU in their grammar. That is exactly the regime of factor-promotion / recursive-typed-factors (D2/D3). So the CHT does **not** subsume the contribution — it **bounds the regime below it** (fixed-V cross-layer inference) and hands the variable-genesis regime up to you. Their refs point at the door (Ibeling–Icard open-universe; the design-lab DAG's `EXT_HIERARCHICAL_ABSTRACTION`) but this chapter does not walk through it.

**Programme actions (γ targets, not part of the URS):**
1. Add a **CHT node** to `pearl_inheritance_dag_current_literature_audited.json`; this URS is its philosophical witness layer. Inherit it as D2's separation backbone (UK1: UK→KU→KK).
2. When porting, **type the CHT as an Inv-class result over a Will-fixed Ω** (B1) — not a realism claim.
3. **Scope D2's novelty to the boundary the CHT hands up** (B3): factor promotion is the variable-genesis move the PCH cannot express; the CHT covers everything *below* it.
