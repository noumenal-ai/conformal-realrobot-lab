# Constructive Causality Foundations — DISCOVERY URS (γ: the object)

Object-level foundations for (I) structure derivation and (II) self-structure-
informed action, produced by the compound oscillation logged in
`CONSTRUCTIVE_FOUNDATIONS_NOOLOGY_URS.md`. Status discipline: everything here is
**KU (in-model derivation, imagined assembly of kernel-proven pieces)** until the
one-shot lands it; each item names its witness plan. Nothing below is banked.

## I. Structure derivation — OUR foundation (the three-level stack)

**F1 — the orientation Pl-kill (support is directionless). [KU; witness schema in
hand]** No property of the bare support κ orients an edge: any finite κ with full
projections is realizable as `X → Y` AND as `Y → X` (give the child enough noise:
per-parent-value the child's noise sweeps the fiber). Finite witness:
`κ = {(0,0),(1,0),(1,1)}`; `X→Y` via `f(0,u)=0, f(1,u)=u`; `Y→X` via
`g(0,u)=u, g(1,u)=1`. **Witness plan (one-shot):** two Mechs, opposite
orientations, `decide`-equal executed supports — the orientation-blindness
executed contrast pair (the directional sibling of parity shadow-blindness).
Consequence: adjacency/d-connection is support-derivable (R4b, proven route);
orientation is NOT. Any structure-derivation foundation claiming orientation from
pure support/CI is chasing a dead leg — direction must come from an added leg:

**F2 — orientation from the intension leg (mechanism-size asymmetry). [KU;
CONJECTURE flag on soundness]** Over MechSyntax with a size measure, define the
**orientation functional**: `orient(κ) = sign(minSize(κ as X→Y) − minSize(κ as
Y→X))` — the minimal total program size realizing κ in each direction, DECIDABLE
by exhaustive search at finite types. Honest split: decidability is by
construction; *soundness* (minimal size tracks the true mechanism direction) is a
genuine open conjecture — the decidable/combinatorial cousin of
Janzing–Schölkopf's algorithmic-independence postulate (route-through sibling:
theirs is Kolmogorov/subjective — ours is executable; never claim their postulate
as home). Witness plan: a κ where the size gap is strict (tables force symmetry;
need structured programs — circuits) + the executed `minSize` computation.

**F3 — orientation from the regime leg (surgery invariance). [KU]** Across a
LOGGED family of interventions, the true orientation is the one whose
mechanism-factorization is invariant under the family's surgeries (surgery
transport is already kernel-proven; invariance-across-regimes is the Inv-class
reading of ICP, at support level: the stable factorization of the surgered
supports). Decidable over finite regime families. Witness plan: parityMech under
two surgeries; the wrong orientation's "mechanism" changes across regimes, the
right one persists.

**The stack (the foundation itself):** structure derivation =
`adjacency from the defect calculus (L1, proven route)` +
`orientation from intension (F2) OR regimes (F3)` — with F1 the theorem that this
split is FORCED, not stylistic. Prediction the stack makes: discovery procedures
using only support/CI data terminate at Markov-equivalence (known) AND their
support-level analogues terminate at the F1 kill (new, sharper: even exact
support knowledge cannot orient) — the two-leg requirement is fundamental.

## II. Self-structure-informed action — OUR foundation

**F4 — the reflexive soundness principle. [KU; assembled from three KK pieces]**
Setting: the agent's actions (do-moves) are chosen by its CURRENT structural
beliefs; the data those actions generate feeds its structure derivation — the
endogeneity loop. Principle: *derivation from self-generated data is sound iff
every self-action is either LOGGED (surgery-tagged: κ_observed decomposes as the
known mixture of surgery-images, each certified by transported rank witnesses) or
STRUCTURALLY SEALED (the channel policy-state → recorded-data is rectangular).*
When neither holds, the un-logged action channel is precisely a hidden channel
from policy to data, and the approximate five-way floor QUANTIFIES the corruption
of every downstream certificate — corruption is measured, not vibes.
- Piece 1 (KK): surgery transports rank witnesses (`Rank.doIntervene`, kernel).
- Piece 2 (KK): the seal certificate direction (non-rectangular ⟹ leakage floor;
  approximate five-way, kernel in measurements — Phase-B bridge).
- Piece 3 (KK): mixtures of surgered supports = per-tag defect calculus
  (CausalData.interventional tagging already in Architecture).
- The ASSEMBLY is the imagined content [KU]. Witness plan: a two-policy executed
  example — logged policy (certificates survive, `decide`) vs unlogged policy
  (same observed data, certificate fails; the floor computes the gap).
Consequence for SiSCM: C5's sealed-audit assumption and F4 are the same shape —
the agent auditing the WORLD and the agent auditing ITSELF need one principle.

## III. What the one-shot must land (next turn, in order)
1. MechSyntax (program class, size, denotation) — the F2 substrate; K1 settled.
2. Executed witnesses: orientation-blindness pair (F1), intensional non-collapse
   pair (from the earlier tick), both `decide`.
3. `orient` (F2, decidable def) + its soundness stated as the named conjecture.
4. F3 as a decidable invariance check over logged regime families.
5. F4 stated over Mech + logged CausalData; the quantitative clause deferred to
   the Phase-B measurements bridge (leaf-lock).
Grain discipline: F1 lands as theorem+witness; F2/F3 land as decidable defs +
witnesses + NAMED conjectures; F4 lands as definition + logged-case theorem +
witness. No claim exceeds its grain.
