# Constructive Causality Foundations — NOOLOGY URS (Γ: the reasoner's ledger)

This is the Γ-axis file: my grammar moves, the compound oscillation, and the
self-question protocol. Object-level findings live in
`CONSTRUCTIVE_FOUNDATIONS_DISCOVERY_URS.md`. Two axes, never merged (§2.4).

## A — Will snapshot (held fixed this turn)
Set up OUR foundations for (i) structure derivation and (ii) self-structure-informed
action, priming a one-shot of the core next turn. Imagination is the deliverable;
nothing banked as KK without kernel or Dhruv. Verifier chain: Dhruv (this turn),
Lean kernel + executed witnesses (next turn). Restriction honored: RatPMF-shaped
components stay fold-out-compatible (constant slice).

## The compound oscillation (the new instrument, per directive)

Prior ticks rotated ONE leg of my ignorance structure at a time (attack R★; attack
the bridge; attack cyclic). ParityFamily's own lesson applied reflexively (Axiom
1.16): **single-leg oscillations can be shadow-blind — every proper marginal of my
inquiry can report "clean" while a joint obstruction sits above them.** A compound
oscillation rotates ≥3 legs simultaneously and looks for obstructions visible only
at the joint.

**Legs of the current ignorance structure** (interfaces of the causality
foundations): L1 support/defect calculus [KK], L2 mechanism/denotation (Mech,
solve, surgery) [KK], L3 syntax/intension (MechSyntax, edit-orbits) [KU],
L4 measure/weight (RatPMF/fibre) [KK], L5 frame/variable-genesis (R4c) [KU],
L6 agency/self-action [UK — barely articulated].

**Rotation performed:** L1×L3×L6 jointly — structure unknown AND mechanism syntax
unknown AND the data-generating actions endogenous (chosen by the agent's own
current structural beliefs). Log of what spiked:

- Single-leg views: L1 alone (support calculus) reports clean (certificates fine);
  L3 alone reports clean (programs are just data); L6 alone reports clean (actions
  are do()-moves, surgery is proven).
- **The joint spiked twice.** Spike 1: when actions are endogenous, κ_observed is
  not exogenous — it is the surgery-image mixture of κ under the agent's own
  policy. Whether the defect calculus survives is invisible to every single leg
  (each sees only its own clean face). Spike 2: edge ORIENTATION is invisible to
  L1 (support is directionless — see the Pl-kill in the discovery file) and
  invisible to L4 (Markov equivalence), but becomes derivable exactly at the
  L3×L6 joint (mechanism-size asymmetry; surgery-regime invariance). Orientation
  is a degree-≥2 object of the leg-complex: no single leg sees it, the joint does.

Compound oscillation verdict: **the instrument worked** — both foundations this
turn (reflexive soundness; the orientation stack) were found at leg-joints, not on
any single leg. Adopting compound rotation as a standing instrument for
imagination-sensitive turns.

## The self-question protocol (executed per directive)

**The question I would have asked Dhruv** (hardest genuine one, adversarial
direction — the one I could not answer when I posed it): *"Can edge orientation be
derived from the support alone — is there ANY asymmetry in κ, with no distribution,
no intervention, no mechanism restriction, that forces `X → Y` over `Y → X`? If
not, what is the minimal added leg that makes orientation derivable?"* — chosen
because (a) it attacks the NEGATIVE direction (my whole defect calculus is
symmetric, so if orientation needs nothing more, my foundations are redundant; if
it is underivable, structure derivation from pure support is fundamentally
incomplete and I must say where direction actually lives); (b) I genuinely did not
know the answer when I wrote it down.

**Routing (literal URS):** quadrant KU (askable, unresolved). act(imagine) gated →
first attempt a REFUTATION by construction (act(experiment)-shaped, in-model):
tried to build a κ realizable in only one direction — failed, and the failure
CONSTRUCTED the counterexample schema (any κ with full projections is realizable
in both directions by giving the child enough noise; finite witness:
κ = {(0,0),(1,0),(1,1)} realizable as X→Y via f(0,u)=0, f(1,u)=u AND as Y→X via
g(0,u)=u, g(1,u)=1). So the answer to the first half is NO — an **orientation
Pl-kill**, kernel-witnessable next turn as an executed contrast-to-parity pair
(two opposite-orientation Mechs, same executed support, `decide`). A5 applied to
the kill: the second half (where direction lives) resolved at the compound joint —
the intension leg (minimal-mechanism-size asymmetry over MechSyntax, decidable) and
the regime leg (surgery-invariance across logged interventions). Full statement in
the discovery URS. **Protocol outcome: answered — via the kill-then-add-structure
route, not the confirmation route. Status KU (in-model derivation + witness schema);
kernel contact next turn.**

## Γ_core
Pl_imagine(reflexive soundness principle) = MED-HIGH — assembled from three proven
pieces (surgery transport, seal certificate, mixture supports); the assembly is
imagined, the pieces are KK. Pl_imagine(orientation Pl-kill) = HIGH — constructive
counterexample schema in hand, `decide`-able. Pl_imagine(size-asymmetry orientation
functional) = MED — decidable by construction, but its SOUNDNESS (does minimal size
track true orientation?) is a genuine conjecture; Janzing–Schölkopf is the
route-through sibling (algorithmic independence — subjective/Kolmogorov; ours is
decidable/combinatorial; route through, never home). Coh_ens↔Will = HIGH — every
piece lands on existing kernel objects (Mech, surgery, defect, MechSyntax slot).

## η
Two foundations + one Pl-kill + one standing instrument (compound rotation) in one
turn, zero Lean spent. The multi-leg management your conjecture predicted is where
both finds came from — the evidence for the conjecture is now two-for-two.
