# causality — PROBLEM URS (γ axis)

**Object:** the Lean 4 formalization of Pearl 2009 + 11 post-2009 extensions,
against `pearl_inheritance_dag_current_literature_audited.json` (141 nodes / 155 edges).
**Refreshed:** 2026-07-31 (previous: 2026-05-30 — two months stale).
**Substrate:** Lean `v4.31.0`, Mathlib `fabf563a`. Mathlib-only leaf-lock holds.
**Axis discipline (§2.4):** this is a *problem* URS about the object. The agent-axis
(Γ) section at the end is coupled, not merged.

> **What this file is.** A measurement instrument over the formalization's ignorance.
> It is NOT a schedule. The 2026-05-30 version was an 8-week Gantt with a sorry-budget
> burndown — canonical failure mode §2.8.1 — and its numbers decayed into fiction
> within three weeks. Removed, not updated.

---

## A — Axioms (Will snapshot, held constant)

- **A₁ Substrate lock.** One custom causality primitive: `structure SCM`. Everything
  else derived over Mathlib. **Holds.** Verified: no design-lab cross-imports.
- **A₂ Scope.** Formalize exactly the 141-node DAG. Ch. 10 actual-cause redacted per
  the DAG's own audit flag.
- **A₃ Layered counterfactual axioms.** Galles-Pearl (Layer A) primary; Halpern
  (Layer A′) derived; the A ↔ A′ bridge proved, never axiomatized. **Statement-level
  commitment not yet met — see KU₄.**
- **A₄ Honesty (review-only).** A stated Prop is not a theorem. A green build is not
  γ. A Pl-kill is content. Flags below; each carries an A5 resolution.
- **A₅ Anti-simplification.** Every A4 flag resolves by *adding structure* — now, or
  at a named step. "Open/stub/pending" is admissible only as a plan-edge carrying a
  scheduled structure-addition.

---

## Comp — coverage (obligations_resolved / obligations_total)

**Stated** (node-named `Prop` in `Conjectures/`), by DAG kind:

| Kind | Stated | Total | |
|---|---:|---:|---|
| Theorem | 33 | 41 | |
| Corollary | 5 | 12 | |
| Lemma | 2 | 5 | |
| Definition | **3** | **68** | ← the structural gap |
| Conjecture | 1 | 1 | `G2_8_2` temporal bias |
| InformalResult | 1 | 1 | `R8_4_1` instrumental inequality |
| CurrentLiteratureSynthesis | 0 | 11 | stated under non-node names in `Modern/` |
| DefinitionAnchor | 0 | 2 | redacted Ch. 10 |
| **Total** | **45** | **141** | |

**Discharged** (`Proofs/`, no `sorry`, `#print axioms` clean): **7 / 74** theorems.

```
Comp_stated     = 45/141 = 0.32
Comp_discharged =  7/74  = 0.09      ← the honest number
Comp_γ          =  7/141 = 0.05      ← discharged against the DAG
```

All 7 discharges are the Ch. 9 Probability-of-Causation cluster (`041f2c8`).
Every other cluster is 0.

---

## A4 flags → A5 resolutions

**A4-1 — The theorem layer is stated over vacuous stubs. [dominant finding]**
33 of 41 stated theorems are `∀ M : SCM, True`, or quantify over predicates
(`IsDsep`, `CondIndep`, `MarkovCompatible`, `IsBackdoor`, `IsFrontdoor`, `IsGAC`,
`IsMsep`, `IDOutput`) whose bodies are literally `True` or `False`. `IsDsep` returns
`False`, so `T1_2_4`'s first conjunct is vacuously satisfiable. These Props elaborate,
type-check, and say almost nothing. **Comp_stated = 0.32 overstates content.**

> **A5:** the resolution is one structure-addition, not many. Build the d-separation
> substrate for real — `IsDsep` as an inductive over `Quiver.Path` with collider/blocking,
> `CondIndep` via `MeasureTheory.Probability.Kernel.Disintegration`, `MarkovCompatible`
> as the factorization predicate. That single addition de-vacuifies the `DSeparation`
> **and** `Identification` clusters at once (11 + 13 nodes), because every downstream
> stub quantifies over these three. **This is the next obligation.** Do not add more
> stated Props until it lands — stating over stubs inflates Comp without moving γ.

**A4-2 — "Green" measures the wrong thing.**
`lake build Causality` succeeds, 2540 jobs, zero sorry-taint. But `Proofs/*` is in
**no `lean_lib` at all** — `CausalityFrontier` has a barrel file and no lakefile
entry. Greenness was achieved by *excluding* the unproved layer. The verification
predicate drifted from "the theorems hold" to "the catalog elaborates". The 7 Ch. 9
discharges were verified by hand (`lake env lean`); nothing automatic re-checks them,
so a conjecture-side edit can silently break every discharge with the build still green.

> **A5:** add `CausalityFrontier` as a **non-default** `lean_lib` (buildable on request,
> exempt from the warnings-are-errors posture). Cost: one lakefile stanza. This
> restores the verifier without compromising the posture.

**A4-3 — `Causality/Constructive/` is unbuilt, and carries one false docstring.**
Five files, ~35 KB, tracked since `e293f4e`, imported by nothing, in no lib, no oleans
on disk. **Corrected 2026-07-31:** an earlier revision of this file called its claims
"unverified" and reported "two `sorry`s". Both were wrong, and wrong in the same way —
asserted from docstrings and a text grep rather than from the kernel. Audited properly:

- All five files **elaborate cleanly** against the current toolchain.
- **Zero `sorry`s.** The grep matched prose reading *"stated, not proved, not
  `sorry`d"* — StructureDerivation's F2-soundness conjecture is honestly left open
  rather than stubbed, which is A5-correct behaviour, not a gap.
- `Witness.lean` runs: `#eval` emits `4, 8, 4, 0` and both `decide` theorems close.
  The executed contrast pair is real.

The genuine defects are narrower than "unverified":

1. **`Core.lean`'s docstring is false.** It claims `solve` is "structural recursion on
   `Acc`, no choice". Audited: `Causality.Constructive.Rank.solve` depends on
   `Classical.choice`. `Mech.lean`'s docstring — which says `termination_by` pulls
   choice — is the correct one. Core is the superseded generation, Mech the repair,
   and **nothing in the tree records that relationship**; a reader meeting `Core.lean`
   first is actively misled.
2. `Mech.lean` overclaims mildly: "the data (`solve`) should show NO axioms". It shows
   `propext, Quot.sound`. The load-bearing claim (no `Classical.choice`) does hold.
3. Nothing re-checks any of it — same exposure as A4-2.

> **A5:** (a) fix `Core.lean`'s docstring and add a one-line supersession note pointing
> at `Mech`; (b) wire the tree as a `lean_lib` so the audit is standing rather than
> on-demand. It is self-contained — only `Core.lean` imports `Architecture`.

**A4-4 — This file was a Gantt.** Resolved by the present rewrite (§2.8.1).

---

## Ignorance geometry — object axis

### KK — stabilized, witnessed

- `SCM` (10 fields) + 7 frontload records + `DiscoveryProblem` + `Identifiable`.
  Elaborates clean under v4.31; **zero sorry-taint** in the default lib.
- **`doIntervene`, `joint`, `Px` are closed.** The dependent-type obstruction — graph
  surgery mutates `Pa`, which changes `f`'s input type — was solved. This was the
  headline KU of the May URS and is now KK.
- **7 Ch. 9 discharges, axiom-clean** (`propext, Classical.choice, Quot.sound`; no
  `sorryAx`). Witnessed by direct elaboration, not by build success.
- **Two-layer §9.2 substrate:** `XResponseDist` (treatment-augmented joint) with exact
  marginalization `toResponse` to layer 1. Exogeneity (`D9_2_9`) and monotonicity
  (`D9_2_13`) are now *formal hypotheses* rather than substrate bake-ins; `T9_2_11` is
  the proved bridge grounding layer 1's reduced forms.
- Mathlib-only leaf-lock survives contact with the root-unify migration.
- **The constructive solution theory is real** (audited 2026-07-31, on demand):
  `Mech.Rank.solveFuel` / `solve` / `solve_spec` / `solve_unique` / `isAcyclic` /
  `doIntervene` all audit to `[propext, Quot.sound]` — **`Classical.choice`-free**.
  The fuel pattern (structural recursion on a rank bound + `solveFuel_congr`) is what
  buys this; the same theory written with `termination_by` does not.
  Not KK-in-the-build until A4-3(b) lands — KK-on-demand.

### KU — articulated, unresolved (drives discovery)

- **KU₁ (dominant).** The d-separation substrate. See A4-1. Blocks 24 nodes.
- **KU₂.** `counterfactual` — the Radon-Nikodym abduction step. Parked in
  `Frontier/Counterfactual.lean`, sorried. Needs conditioning `uDist` on the
  evidence-preimage under the solution map, with the `P(E) = 0` case handled.
- **KU₃.** `T9_4_2` — local invertibility. Needs SCM-level machinery absent from the
  substrate; correctly left sorried rather than faked.
- **KU₄.** Layer A ↔ A′ bridge — 7 sorried stubs in `AxiomEquivalence`. A₃ commits to a
  real proof, but `LayerA` and `LayerAprime` are both currently `True`-valued: the
  bridge *as stated* is a tautology. A₃ is unmet at the statement level, not merely
  unproved.
- **KU₅.** 65 of 68 definitions unstated. Definitions carry no proof obligation but do
  carry *statement* obligation — the theorems quantifying over them cannot be
  de-vacuified until they exist.
- **KU₆.** The 11 modern extensions are stated under non-node names
  (`MixedGraphs_Soundness`, …) and their reduction-to-Pearl bridges are `True → True`.
  Bridge content is the entire purpose of those files.
- **KU₇ (search-resolvable, learning route §2.3).** Prior art unchecked: has do-calculus
  been formalized in Lean/Coq/Isabelle; Mathlib's `SimpleGraph` path-predicate coverage;
  whether a kernel-Bayes-rule lemma exists for counterfactual factorization; Lean
  formalization of polynomial-ring rank for IV. *(Reclassified 2026-07-31: these sat
  under UK in the May version. Unchecked literature is not UK — it is KU resolvable by
  `act(search)`. UK is unarticulated pressure, not unread papers.)*

### UK — unarticulated pressure (drives inquiry, R-growth)

- **UK₁ — Is the measure-theoretic `SCM` the right base?** The Constructive axiom audit
  found `SCM`'s *type* is `Classical.choice`-contaminated through the
  `MeasurableSpace.pi` instance in `uDist`, independent of any proof. `Mech` (the
  measure-free skeleton) is the articulated response. Pressure toward a two-storey R:
  mechanism skeleton below, measure above. **Not yet decided.**
- **UK₂ — What should "the library is verified" mean?** A4-2 is the symptom, not the
  pressure. A posture satisfiable by moving files out of the build measures something
  other than verification. The repo-wide green count inherits this.
- **UK₃ — Orientation is not support-derivable.** From `CONSTRUCTIVE_FOUNDATIONS`: no
  property of the bare support orients an edge. Adjacency/d-connection is
  support-derivable; direction requires an added leg (intension or regime). Bears
  directly on what the Pearl-side discovery nodes can ever claim.

### UU — unaskable under current A, R

Sheaf-theoretic / j-do causality · cyclic and non-recursive SCMs (Forré-Mooij) ·
continuous-time causal dynamics · quantum causal models.

---

## Pl-kill log (boundaries; each is content)

| # | Killed | Boundary discovered |
|---|---|---|
| 1 | `SCM (U A S)` 3-type shape covers Pearl | Single-vertex collapse. Forced the indexed family `Sp : V → Type`. |
| 2 | 5 frontload typeclasses suffice | Discovery-vs-model conflation. Forced 7 records + bundle. |
| 3 | Cross-library imports are load-bearing | Subject-matter disjointness. Mathlib-only suffices at v1. |
| 4 | Typeclasses for non-canonical instances | Multiple incompatible discovery setups per model are normal. Records, not classes. |
| 5 | **A green build is progress** | Greenness was bought by excluding the unproved layer. `green ≠ γ`. |
| 6 | **Endpoint-attainment is "sharp"** | Pearl's `T9_2_10` claims a model realizes *any* value in the bounds. Endpoint attainment is strictly weaker. Found by reading source against formalization — the kernel could not have caught it. |
| 7 | **Layer-1 exogenous substrate can state `L9_2_6`** | It cannot — (9.5) needs `P(x,y)`-level objects. The kill *generated* the two-layer `XResponseDist` extension. |
| 8 | **`termination_by` well-founded recursion is axiom-free** | It pulls `Classical.choice` in this toolchain; the fuel pattern does not. **Witnessed 2026-07-31:** `Core.Rank.solve` → `[propext, Classical.choice, Quot.sound]`; `Mech.Rank.solve` → `[propext, Quot.sound]`. Forced the fuel pattern. |
| 9 | **`SCM` is choice-clean if its proofs are** | The *type* is contaminated, independent of any recursion. **Witnessed 2026-07-31:** `#print axioms Causality.SCM` (the structure itself, and `uDist`) → `Classical.choice`, via `MeasurableSpace.pi`. Forced the measure-free `Mech` skeleton. |
| 10 | **A docstring is a witness** | `Core.lean` states "no choice"; the kernel says otherwise. Two files in the same tree assert contradictory axiom facts. Doc-claims record intent, not results — and an earlier revision of *this* URS banked Core's docstring as γ. The tree needs the audit standing (A4-3b), not narrated. |

Kills 6–10 are this period's real yield; 7 and 9 produced structure rather than merely
bounding a claim. Kill 10 was self-inflicted and is recorded rather than quietly fixed:
the instrument was measuring prose.

---

## γ — discovery ledger (validated gains since 2026-05-30)

| Gain | Witness |
|---|---|
| `doIntervene` / `joint` / `Px` closed | in built env, zero sorry-taint |
| 7 Ch. 9 theorems discharged | `#print axioms`, no `sorryAx` |
| 3 fidelity defects corrected (sharpness; `C9_2_12` subject; `T9_2_14` conjuncts) | each reconstruction is now a discharged theorem — a wrong reconstruction would have failed the proof, not just the eye |
| Two-layer §9.2 substrate | exogeneity/monotonicity promoted to hypotheses |
| Kills 8, 9 (axiom audit) | `#print axioms`: `Core.solve` vs `Mech.solve`, and `Causality.SCM` itself. **Witness produced 2026-07-31** — before that the rows cited an audit nobody had run. |
| Constructive solution theory `Classical.choice`-free | the same audit |
| `Witness.lean` executed contrast pair (defect 4 vs 0) | `#eval` → `4, 8, 4, 0`; both `decide` theorems close |
| v4.31 migration survived without losing the leaf-lock | build |

**Not γ:** the 38 stated-but-vacuous Props; the green build.

---

## Γ — agent axis (coupled, not merged)

**R-moves** (grammar of structure):
- Conjecture/proof split — statements stabilized against proof iteration. Held: the
  Ch. 9 review rewrote statements *and* proofs together with no drift elsewhere.
- Cluster naming by DAG `module`, not by book chapter.
- Two-layer probability substrate (layer 1 exogenous / layer 2 joint).
- `research/` quarantine (2026-07-31) — separates the measurement instrument from the
  artifact it measures.

**M-moves** (grammar of change):
- Library split `Causality` / `CausalityFrontier`. **This M-move silently redefined the
  verification predicate** — which is why it appears as A4-2 and Pl-kill 5. Recorded
  here rather than celebrated.

**Γ_core** — ⟨Coh_{ens↔Will}, Pl_imagine⟩:
- `Coh_{ens↔Will}`: Will = "formalize all of Pearl 2009 with one custom primitive."
  The one-primitive clause **holds** — unbroken across two months and a toolchain
  migration. The "all of Pearl" clause sits at 0.05 discharged. Coherent in kind, far
  from satisfied in degree.
- `Pl_imagine`: the imagine route was taken twice, both times with a verifier present —
  the Ch. 9 substrate extension (verifier: Lean kernel + the DAG source) and the `Mech`
  skeleton (verifier: `#print axioms`). Both banked legitimately. No ungated imagine
  detected this period.

**η** — validated novelty per effort. Honest split:
- **Low** on the Pearl spine: two months, 7 discharges, theorem layer still stated over
  stubs. Effort went to migration and infrastructure.
- **High** on the two audits: the Ch. 9 fidelity review and the Constructive axiom audit
  each produced boundary knowledge (kills 6–10) that no amount of proof-grinding would
  have surfaced. **Auditing the formalization against its source outperformed extending
  it.** That is the transferable finding.
- **`Constructive/` was underrated here on first pass.** Scored as unverified orphan
  code; it is in fact the tree carrying the period's cleanest result (a
  `Classical.choice`-free solution theory with an executed witness pair). The
  misscoring came from reading docstrings instead of running the kernel — see kill 10.
  Its actual deficit is packaging, not content.

---

## Next obligation (single, named)

**Build the d-separation substrate** — `IsDsep` inductive over `Quiver.Path`,
`CondIndep` via `Kernel.Disintegration`, `MarkovCompatible` as factorization.
De-vacuifies 24 nodes across two clusters. Everything else waits: adding stated Props
over stubs raises Comp without raising γ, which is precisely the measurement error this
file exists to prevent.

Two one-line chores land alongside it: the `CausalityFrontier` lakefile stanza (A4-2)
and the `Constructive/` wire-or-park decision (A4-3).

---

## Maintenance

Update when a discharge lands, an A4 flag opens or resolves, a Pl-kill is found, or a
grammar move changes what is askable. **Do not** add a schedule. **Do not** report
stated-Prop counts as progress without the discharged count beside them. Strike through
superseded entries; never delete — the trace is the instrument.

**Evidence rule (added 2026-07-31, after kill 10).** No row enters KK or γ on the
strength of a docstring, a header, a commit message, or a text grep. Either cite a
command that was run and its output, or file it as KU. If a witness is named in the
witness column, that witness must have been produced — the 2026-07-31 revision of this
file cited `#print axioms` runs for kills 8 and 9 that had not happened, in the same
document that flags unwitnessed claims elsewhere. The instrument is not exempt from
the instrument.
