# Verification of the siSCM Forward-Witness counterexample (primary KU discharged)

Executable check of the Total Discovery URS's unified counterexample, run with **DoWhy 0.14 `gcm`** (interventional cross-check) over an **exact enumeration** of the finite exogenous space (gold standard). Scripts: `verify_mstar.py` (M\*\*), `verify_mstar_prime.py` (M\*\*′).

## Outcome: the gate caught a real defect; the fix is verified.

### M\*\* (the workflow's unified counterexample) — encoding validated, interpretation refuted
- **DoWhy validated the encoding.** With categorical/classifier mechanisms, DoWhy reproduces M\*\*'s observational (regime-A) and both interventional distributions to <1% on all configs: `do(A)=p·q`, `do(B)=(1−p)·q`. (Auto-assigned *regression* mechanisms fail — they can't represent the Boolean XOR/AND; categorical mechanisms are required.)
- **The exact enumeration refuted the interpretation.** M\*\*'s headline numbers (`W(e:X=1)=q`, marginal `p·q`) are exact, but they are the **β reading**: `do(Σ_next)` sets the *next* regime while the witnessed `C^{(t)}` reads the **factual X** (upstream of `f_Σ`), so the intervention is **structurally inert** on the witnessed competence. ⇒ `W=q` is the agent's **current competence** (a sealed (b-ii)-style certificate), **not** a forward (a) prediction of the unrun successor.
- **The genuine successor witness pulls apart:** persistent type (abduction carries ⇒ genuine L3) ⇒ `W≡0` (degenerate); fresh noise (`W=(1−p)q`, non-vacuous) ⇒ abduction inert ⇒ it is L2, not L3. **M\*\* does not exhibit a witness that is simultaneously {genuine-L3, about-the-self-mod, non-vacuous}.**

### M\*\*′ (corrected, minimal) — verified to deliver the genuine forward witness
Three structural changes, each a canonical Pearl object:
1. **persistent latent type** `U_type ~ Bern(p)` (a unit/latent ⇒ abduction carries ⇒ genuine L3);
2. **regime-type-match competence** `X(r,U_type)=1 iff r matches U_type` (drive is **downstream of the regime** ⇒ the witness is *about* the self-modification);
3. **sealed monotone competence** `C = X ∧ U_obs`, `U_obs~Bern(q)` fresh (point-ID).

Forward witness `W := C′ under do(Σ=σ_next)`, abducting `U_type` from the factual A-behaviour:
- with **σ_next = B** (a non-adaptive / risky self-proposal): **`W ∈ {0, q}` keyed by the abduced type** — type-0 ⇒ `W=0` ("adopting B would tank you, DON'T"), type-1 ⇒ `W=q`. **Genuine-L3 (abduction matters) + non-vacuous + about-the-self-mod.** ✓
- with **σ_next = optimal switch**: `W=q` regardless of type ⇒ **abduction inert (collapses to L2)**.
- **DoWhy cross-check** of M\*\*′'s competence mechanism: `do(A)=(1−p)q`, `do(B)=p·q` match exact to <1%. ✓

## The structural insight (new, surfaced by the verification)
The forward (a) witness has **genuine L3 content exactly when the self-modification's value is *type-dependent*** (risky — could be bad for the agent's actual type). For a *good/adaptive* self-mod the witness collapses to L2 (no abduction needed). **So the forward witness earns its L3 keep precisely on the risky self-modifications — which is exactly when an agent needs it.** This sharpens `𝓡★`: the "non-vacuity + genuine-L3" leg requires the construction to put the **witnessed competence causally downstream of the self-modification, with a persistent type the factual behaviour reveals.**

## Status
- **Primary KU discharged:** the unified counterexample is now executable-verified (exact enumeration + DoWhy interventional cross-check), no longer merely described. The fake-imagine tripwire is cleared **for M\*\*′** (not M\*\*).
- **Correction to the Total Discovery URS:** the existence witness for the §A theorem is **M\*\*′**, not M\*\*. The regime `𝓡★` and the six defeater-conditions stand; the unified-counterexample section (§C) must be replaced by M\*\*′, and the non-vacuity/genuine-L3 leg annotated with the type-dependent-self-mod requirement.
- **§D-4 crossover RESOLVED (graceful) — see below.**
- **Open (next):** multi-step iterability (does the witness compose over σ_t→σ_{t+1}→σ_{t+2}); and the genuinely-cyclic / synchronous "certify-while-rewriting" case (the N1 residual — needs external cyclic-SCM theory, the "while" frontier).

## §D-4 continuity crossover — RESOLVED: graceful (robust)

`verify_crossover.py`. As exact abduction–action decoupling (C4) is relaxed by a hidden confounder of strength ε between the antecedent (adopted regime, treated as a binary treatment with the abduction signal as instrument) and the outcome (successor competence), the forward witness's Balke–Pearl interval `[L,H]` for `W = P(C′=1 | do(Σ=B))`:
- is **point-identified at ε=0** (width 0; `L=H=W=0.60`);
- **widens continuously and monotonically** with ε (width ≈ 0.5·ε near 0; finite onset slope; max adjacent-step jump 0.05 — no discontinuous collapse);
- stays **sound** throughout (`L ≤ W ≤ H` at every ε; verified by exact LP).

**Verdict: GRACEFUL, not brittle.** The Balke–Pearl bound is the optimal value of an LP whose constraints (the observed `P(X,Y|Z)`) are analytic in ε, so the width is continuous in ε and →0 as ε→0. The construction is **robust to small violations of exact decoupling**: a small couple yields a small, sound interval, not a collapse. Honest caveat (= §D-3): point-identification is **knife-edge** (only exactly at ε=0); for any ε>0 the certificate is an interval, and at large coupling it widens (ε=0.5 → width 0.25). So robustness in **width** near 0, knife-edge in **kind**; the interval must be reported and is informative only while the coupling stays small.

## Iterability — RESOLVED: composes, bounded (no horizon explosion)

`verify_iterability_audit.py`, Part A. The multi-step forward witness (certify k unrun transitions ahead):
- **Decoupled:** composes cleanly, point-valued, `W_k ∈ [0,q]`, depends on the *full proposed plan* and the abduced type (all-match 4-step plan → `q`; a single mismatch → 0). It iterates.
- **Coupled (ε>0):** the k-step interval width **shrinks** with k (product of per-step retention probabilities, bounded in [0,1]) — e.g. ε=0.2: width 0.070→0.084→0.060→0.016 for k=1,2,4,8. **No horizon explosion.**
- **Structural reason:** the witness is a bounded *probability*, not a reweighting *ratio*. A likelihood-ratio witness explodes geometrically (`(b/a)^k`: 1.18→1.96→3.82 at ε=0.2); the probability witness cannot. This is exactly the P1 rollout-horizon multiplicative-compounding failure mode — **avoided by construction**.

## Adversarial vacuity audit (RESTRICT mode; Pearl-DAG KK as fixed yardstick) — ALL PASS

`verify_iterability_audit.py`, Part B. Seven probes, each grounded in a Pearl result, designed to FIRE if a program is vacuous: **P1** witness-varies (D7_1_5); **P2** do≠see (CHT/EXT_ID); **P3** abduction-matters/L3 (CHT); **P4** interval⊊[0,1] (Balke-Pearl/T9_2_10); **P5** LP-data-constrained (do-calculus completeness); **P6** generic-open-set, 200/200 random ε (CHT almost-all; OCOF/DICE); **P7** respects-CHT-non-id-boundary (kill the instrument → wide interval, not false point-ID). **All pass.** The audit bit once: P5 initially fired on a mis-designed probe (perturbed a *non-binding* cell, legitimately insensitive); diagnosed as a false positive and corrected — binding-cell perturbation moves the bounds by 0.16, data narrows [0,1] to width 0.10. Evidence the audit is a real adversary, not a rubber stamp. An independent skeptic agent (restricted to the same KK) is the external cross-check.

## ADVERSARIAL FINDING (external skeptic, restrict mode) — point-ID / genuine-L3 claim RETRACTED

The independent adversarial verifier (restricted to the Pearl-DAG KK) landed a Pl-kill that survives scrutiny — **accepted**:
1. **M★★′'s abduction is degenerate.** The factual regime perfectly reveals the type (`X = 1 − type`, invertible) ⇒ the abductive posterior is a **point mass** ⇒ `W` is bitwise-equal to the L2 query `P(C | do(Σ=B), type=t)` with the type *observed*. The "genuine-L3" label is unearned — it is L2-with-the-latent-observed. (`D7_1_5`; L3-irreducibility needs a non-degenerate posterior.)
2. **Point-identification was hypothesis-smuggled.** The monotone seal `C = X ∧ U_obs` is exactly the monotonicity `T9_2_14` uses to collapse response types into point-ID. The construction assumed the condition that delivers the conclusion.
3. **The crossover measures decoupling, not causation** (width ≡ ε/2 even at zero causal effect); **iterability is bounded because the witness decays to 0** (trivially uninformative at horizon). Real math, over-reaching interpretation.
4. **Restrict-mode KK catch:** the programs cite "CHT Thm 1," which is **not a node in the audited DAG** (still UK1 — absent). The real load-bearer is `EXT_ID_DO_CALCULUS_COMPLETE`.

### Honest corrected claim (verified — `verify_pns_honest.py`)
The genuine cross-world forward witness `PNS_fwd = P(C_{do(adopt B)}=1, C_{do(stay A)}=0)` ("adopting B would make me competent; staying would not") is an **interval** (Balke–Pearl / `T9_2_10`): widths 0.30, 0.40, 0.10, 0.45 across configs. It is a **point only under exogeneity + monotonicity (`T9_2_14`)** — the strong, non-generic condition M★★′ silently assumed.

> **The forward self-witness is achievable as a SOUND, INTERVAL-VALUED partial-identification certificate (`T9_2_10`/Balke–Pearl), NOT a point.** Point-identification holds only on the measure-zero (exogenous + monotone) knife-edge. This is the non-smuggled object, consistent with the CHT (L3 does not reduce to a point), and still a legitimate witness (a sound bound). In `𝓡★` terms: the witness lives in the **C3 (partial-ID interval) leg, not the C2 (point-ID) leg** — the unified counterexample over-claimed by routing through C2's smuggled monotonicity.

## Class-invariance (safe-RSI stage 5) — make-or-break cleared; theorem reduced to inherited lemmas

`verify_class_invariance.py`. The gated-invariance theorem (`Mₜ∈𝒢` and the gate admits only `𝒢`-candidates ⟹ `M_{t+1}∈𝒢`; induction ⟹ monotone-safe RSI) is honest only if `𝒢` = {exogeneity ∧ monotonicity} is not a frozen trap. Two demos:
- **Non-vacuous progress (Demo A):** on a regime ladder (`g=[.20,.40,.58,.74,.88]`) the gated loop climbs 0→4, monotone, **4 strict improvements**, converges to the top regime `M*`. `𝒢` admits improving, convergent trajectories — not frozen. (N1 fixed point reached constructively.)
- **The seal is the keystone (Demo B):** the tension is *"improving needs competence info, exogeneity forbids the confounded channel."* Resolved by the sealed audit — selecting via a certification sample **independent** of the live competence keeps selection ⊥ confounder (exogeneity preserved) and certification honest: sealed certified-gain ≈ **+0.0003** on equal regimes, while a **leaky** audit (certify on the selection sample) certifies a spurious **+0.1214** (winner's-curse Goodhart) and breaks exogeneity. So **exogeneity-preservation = P3's sealed-audit discipline.**

**Consequence:** the make-or-break clears, so the gated-invariance theorem is worth proving, and what remains is mostly *inherited*: **L1** soundness (T9_2_14), **L2** forward-decidability of the gate-check (mono = response shape; exo = back-door/d-sep, T3_3_2 + T1_2_4), **L3** surgery fidelity (C5), then assembly by induction. **Track coherence:** P3's sealed audit is the keystone that makes P2's safe-RSI class-invariance hold.

**Honest scope (no overclaim):** Demo A is an *existence demonstration* on a constructed landscape — it defeats "`𝒢` is necessarily frozen," not "every `𝒢`-landscape improves" nor "the gate-check is decidable for every candidate class." This probe itself warrants an adversarial pass (per the point-ID lesson above).

### Adversarial pass (JSON-only KK, no web) — make-or-break RETRACTED; clears only a weaker claim
All six attacks land — accepted:
1. **Weaker-claim substitution (central):** the program has NO structural rewrite — the "modification" is an index step `s→s+1` on a fixed, monotone-by-construction array `g`. Monotonicity is assumed, never re-checked post-rewrite. Demo A clears "`𝒢` is climbable," **not** "a modification preserves `𝒢`" (the actual stage-5 inductive step).
2. **Exogeneity untested:** Demo A has no latent confounder; it climbs true `g` directly, so exogeneity is vacuously satisfied and no back-door/d-sep check (T3_3_2/T1_2_4) is ever run. Exogeneity is exercised only in Demo B's static one-shot.
3. **Landscape-dependent (decisive):** on deceptive landscapes (`[.20,.45,.30,.70,.92]`→freezes at 0.45; `[.50,.35,.95]`→freezes at 0.50) the never-regress gate is **safe-but-stuck**. Non-vacuity is a property of the hand-picked monotone ladder.
4. **Seal is knife-edge:** a partial leak ρ yields a continuous, undetected Goodhart gain (ρ=0.1→+0.012 … ρ=1→+0.12). "Sealed" is not binary.
5. **Large-sample artifact:** the honest climb needs N=20000; at N=50 it stalls 16% of trials, N=20 → 55%. (True regress stays 0% — conservative gate — but it *stalls*.)
6. **Point-ID smuggled (same as M★★′):** the loop compares point values; point-ID needs exo+mono (T9_2_14), and Demo A prebuilds monotone `g` = assumes the condition; under exogeneity alone it is an interval (T9_2_10/T9_2_11).

### Honest reframe (what survives)
- **Safety (never-regress) is the robust core**, but it *is exactly P3's sealed-audit Goodhart-resistance, re-derived causally* (exogeneity-preservation = sealing) — and it is **conditional on a clean seal** (Attack 4). Nothing beyond P3 is established by these probes.
- **Deep finding (general, not an artifact):** a strict never-regress gate is **local-optimum-trapped** on non-monotone landscapes — it cannot cross a competence valley without a temporary regress. So **safety (never-regress) and guaranteed global progress are in fundamental tension** — you get one or the other, not both. The monotone ladder hid this by having no local optima.
- **Stage-5 (modification preserves `𝒢`) remains untested** — it requires an actual rewrite of `f_X`/`f_C` that introduces a live confounder, re-gated with a real d-separation (T3_3_2/T1_2_4) + defier (D9_2_13) check.

## New direction — monotone JUSTIFICATION (not competence) escapes the trap

`verify_justification_loop.py`. Accepting the safety-vs-progress no-go, move the monotone axis off competence (discovery, γ) and onto **justification = identified fraction of the self-SCM** (inquiry, Γ): point-ID where exo+mono hold (T9_2_14), interval-ID where confounded (T9_2_10). Self-rewrites are self-interventions that identify more of the self-structure; competence is free to be non-monotone (exploration); the agent **commits only to a certified config ≥ a floor**. On the SAME deceptive landscape that froze the never-regress loop (`g=[.20,.45,.30,.70,.92]`):
- justification monotone (1.0→2.0→2.5→3.5→4.5, never decreases);
- competence non-monotone (the .45→.30 dip = exploration);
- **commits to 0.92 = the GLOBAL optimum** (the never-regress loop froze at 0.45);
- lobotomy avoided (committed 0.92 ≥ floor 0.5); justification not gameable by exploration (it identifies the *true* surface);
- honest ceiling: 4 point-ID + 1 interval-only (the confounded config is never point-ID; ceiling < 100%).

**Resolution of the tension:** safety as *"never un-learn (monotone justification) + floored commitment"* is **both safe and reaches the global optimum** — because the monotone constraint is on self-**knowledge** (Γ), not competence (γ). The failed monotone-competence safety *forbids* the down-step exploration needed to escape a local optimum; monotone-justification safety *permits* it. This is the noological inquiry/discovery split operationalized, and it is a genuine result distinct from P3.

**Residuals (no overclaim):** (i) the demo visits exhaustively (K=5) — scaling needs info-gain-ordered exploration and an exploration-complexity bound; (ii) here rewrites VISIT (identify) but do not CHANGE the surface `g` — the genuinely-reflexive case (rewrites that *change* `g`) re-introduces lobotomy (rewrite to a trivial-but-identified self) and moving-target identification, needing the floor + justification-of-the-new-config; (iii) deserves its own external adversarial pass before banking.
