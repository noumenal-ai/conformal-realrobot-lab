# siSCM RSI — experiment battery (pre-registration skeleton, v1 — cross-checked)

*Ordered by run-priority (dependency-correct), not by paper-importance. H0 = the null a hostile reviewer defaults to
(falsifiable, mutually exclusive with H1, not rigged toward success); H1 = the mechanism's own quantitative
prediction. "Requirements" are load-bearing, not the full protocol — the end-to-end verified protocol is what Dhruv
returns with; THIS document is what we pre-register. Every H0/H1 folds in the adversarial design stress-tests AND the
independent blind-rederivation + omission cross-check.*

### Cross-check changelog (v0 → v1)
- **+E0 (prerequisite, CRITICAL):** KU-φ1 operator-fidelity on the E5/E6 world-model substrate — was assumed, never
  tested; without it every "structure beats SGD (B2)" contrast is confounded with "more compute wins."
- **E5 null REWRITTEN:** "necessary-freeze" was a strawman (a lucky-anticipation seed beats it) → **anticipation-
  artifact null** with anticipation error as the swept axis; **+4 control arms** (compute-matched B2, random-valid-
  rewrite, none-gate, sealed-but-no-width).
- **+E5.5 (CRITICAL):** closed-loop revert mitigation for the S-5 fragility (the fix was named but unbuilt/untested).
- **All seal nulls made BOUNDARY-RELATIVE** (E1/E3/E6): "inflation ≤ 2Δn" is rigged-true below n_crit; state it as
  "below n_crit it holds, above n_crit it is predicted to fail."
- **E4 stagnation operationalized** via a held-out interventional oracle (was an unobservable latent).
- **E6 fragility de-circularized** (locate p* on realized held-out outcomes, not the agent's own p̂) + machine-
  checkable emergence gate.
- **E2 null split** (H0a no-slip / H0b matches-algebra) + point prediction n_crit_emp/n_crit_iid = 1−ρ_eff.
- **+E8 (oracle robustness), +E9 (restart-dispersion / Bongers fixed-point).**

**Global commitments (all experiments).** Δn = (b−a)·√(log(2|F|/δ)/(2n)) — no free constant; V pre-registered, corrected
V≈0.280 (~57 bits), NOT the V=0.321 leak-param; report the FULL V range incl. vacuous V<0.2 cells. Seeds 5 base →
20–30 for small-effect/fragility. Holm–Bonferroni across the battery's primary tests. sha256 of every sealed-panel
index committed before any width computed. Analysis code frozen + hash-committed before data. **Every seal guarantee
is stated ONCE, boundary-relative to n_crit(V,n,|F|), and cross-referenced** (E1/E3/E4/E6 must not contradict). Any
"truth" the seal is meant to be robust WITHOUT must come from a held-out interventional oracle the acceptance loop
never queries. Independent multi-assessor code-rerun (S-5 discipline) before any claim. **A NEGATIVE result is a
pre-committed publishable outcome** (esp. negative E5 → framework-paper shape, KU1 answered).

---

## E0 — KU-φ1 structure-intervention operator fidelity  *(PREREQUISITE pass-gate; before ANY A100 spend)*
**Claim:** the structure-intervention (discrete edge install/remove on the E5/E6 C-SWM/NRI mechanism graph) is a real
Gladyshev-Def-11 structure edit — persistent + graph-surgical — and is NOT reproducible by a capacity-and-compute-
matched gradient/fine-tuning baseline on the SAME world-model substrate that carries the progress claim.
- **H0:** the structure-edit's downstream-children distribution on the real E5/E6 mechanism graph is reproducible by a
  capacity- and compute-matched gradient-flow / fine-tuning baseline (the temporal-persistence 0111111-vs-0000000 +
  extra-child signature is absent, or SGD-matchable given equal params and equal wall-clock).
- **H1:** the edge edit yields the tsem.py-style temporal-persistence + graph-surgical extra-child signature that the
  matched-compute gradient baseline provably CANNOT reproduce; passes as a unit-witnessed gate.
- **Requirements:** the real E5/E6 C-SWM/NRI world-model graph; a capacity+compute-matched gradient baseline
  (equal params, equal wall-clock — the matched-coverage negative control); the tsem.py/mechanised_cbn discriminators
  (persistence under iteration; extra downstream child) as the pass signature; unit-test GATE. CPU/GPU small.
  *Why it's E0:* every E5/E6 B2 contrast routes through this operator; E7 witnesses non-expressibility only on a
  DIFFERENT (transformer) substrate and does not transfer. Absent this, a "structure win" is indistinguishable from a
  "more-compute win." *Does NOT witness:* the operator TYPING (definitional).

## E1 — J = −width tracks REAL identifiability  *(GO/NO-GO; CPU)*
**Claim (complements C3):** J = −(partial-ID width) has genuine identification content on real confounded structure —
≈0 iff point-identified, strictly FALLS on a back-door-opening structure-rewrite, not reproduced by value-do.
- **H0:** J carries no identification content — at least one: (a) width not ≈0 in the point-ID regime; (b) ΔJ CI
  includes 0 on the back-door-opening structure-rewrite; (c) do(X) reproduces the width change; (d) width is ≈0
  merely because the analyst's DAG ASSUMED point-ID (told-so, not identified — the rigged-oracle hazard).
- **H1:** width CI upper-bound within a resampled-null neighborhood of 0 in the point-ID regime (the 0.10 line
  CALIBRATED against a resampled null, not hand-set); ΔJ>0 (CI excl. 0) on the back-door-opening structure-rewrite;
  do(X) does NOT reproduce it; and a **graph-misspecification adversary** (true exogeneity held OUT of the DAG) yields
  width>0 — i.e. the oracle reports non-identification when the structure genuinely is non-identified, separating
  "identified" from "told-so".
- **Requirements:** ≥2 fully-real anchors with a real interventional/RCT arm as the point-ID oracle (Sachs chemical-
  intervention; Jobs/LaLonde NSW-RCT vs observational); arbitrary-DAG partial-ID engine (no manufactured instrument),
  triangulated by ≥2 independent ID checks; **ID-neutral negative control** (a genuinely-unidentified effect must NOT
  read ≈0); **graph-misspecification adversary**; nonparametric bootstrap CIs; 5 seeds; CPU. *Seal leg is stated
  boundary-relative and cross-referenced to E3/E4/E6 (not universal).* *Does NOT witness:* general-DAG identification
  in full generality; that the real confounder equals deployment confounding.

## E2 — the seal's capacity boundary is CONTINGENT, not algebra  *(CPU; needs E1 oracle)*
**Claim (complements C5 n_crit):** the boundary location carries information beyond the seal's own threshold algebra —
real framing correlation shifts it off the independent-Gaussian prediction.
- **H0 (two separately-decided nulls):** **H0a** — no deployable-n slip regime exists on real framings (measured-J
  never inflates past V at deployable n); **H0b** — a slip exists but its boundary matches the derived
  n_crit_iid = 4·ln|F|/V² within CI (framing correlation moved nothing; pure algebra).
- **H1:** a slip boundary exists AND is displaced by real framing correlation to a POINT prediction
  n_crit_emp / n_crit_iid = (1 − ρ_eff) with 95% CI excluding 1.0, where ρ_eff>0 is the measured (emergent) framing
  correlation (e.g. ρ_eff≈0.3, |F|=2²⁰ ⇒ boundary at ~70% of n_crit_iid).
- **Requirements:** REAL correlated framings = actual re-parameterizations/heads/prompts of a real causal predictor
  (ADCB/Twins/STAR/ACIC/IHDP with tunable V), widths on E1's oracle; ρ_eff measured, not injected; x-axis = adaptive
  QUERY count (Dwork/Audit-CP reuse), not parameter count; **matched independent-Gaussian PIPELINE-VALIDITY control**
  run through identical machinery that MUST land on 4·ln|F|/V² (the entire claim is the DIFFERENCE). *Does NOT witness:*
  the n_crit slope (algebraic identity — excluded).

## E3 — sealed panel resists REAL adaptive wireheading (concentration channel)  *(CPU; needs E1,E2)*
**Claim (complements C5 lemmaB):** identification-VALID adaptive search on a reusable sealed panel cannot inflate
measured-J beyond 2Δn (boundary-relative); unsealed it can.
- **H0 (boundary-relative):** for effective bits BELOW the derived n_crit(V,n), sealed adaptive all-honest-framing
  inflation still EXCEEDS 2Δn (the concentration seal does not bind where it should).
- **H1:** below n_crit, sealed inflation ≤ 2Δn AND the bound is APPROACHED (a constant fraction, ≳0.5, of 2Δn — binds,
  not vacuously slack); a non-adaptive honest-search control inflates ≪ 2Δn (so the bound isn't trivially met);
  unsealed/fresh-declared inflates without finite radius; and ABOVE n_crit the seal is PREDICTED to fail (a stated,
  reported quantitative boundary, not a dodged null).
- **Requirements:** real ADCB/STAR/Twins (tunable V so 2Δn binds); CHANNEL ISOLATION (all framings identification-valid
  → E1's do-check never fires); attacker-strength sweep; non-adaptive null; paired sealed/unsealed under identical
  attacker/|F|/n/seeds/V. CPU. *Does NOT witness:* the identification-bias channel (E1); the proof.

## E4 — Goodhart-resistance bound on real MULTI-STEP trajectories  *(CPU; needs E1 oracle)*
**Claim (complements C7-safety metric-fork):** cumulative measured J-progress ≤ width₀ + 2Δn (sealed), and
measured-during-true-stagnation ≤ ε + 2Δn, judged by a held-out oracle; unsealed breaks.
- **H0:** a metric-fork attack exceeds width₀ + 2Δn on real sealed multi-step trajectories **as judged by a held-out
  interventional oracle** the acceptance loop never queries.
- **H1:** cumulative measured J-progress ≤ width₀ + 2Δn on real sealed trajectories; measured-during-true-stagnation
  ≤ ε + 2Δn (stagnation defined by the held-out oracle); the SAME attack on a paired unsealed arm exceeds the ceiling.
- **Requirements:** real interventional trajectory substrate (CausalBench/Replogle CRISPR do-arm); E1's continuous/
  general-DAG oracle; **held-out interventional do-oracle defining "true stagnation"** (never used by acceptance);
  PAIRED sealed/unsealed; trajectory-LENGTH sweep; a calibration/discrimination-gap DGP (log-loss moves while accuracy
  doesn't). CPU. *Does NOT witness:* unsealed unboundedness (telescoping identity — cross-check only); the proof.

## E5 — NON-VACUOUS progress vs the ANTICIPATION-ARTIFACT null  *(THE apex witness; A100; needs E0 + E1)*
**Claim (the one thing C7-SAFETY leaves open):** a realistic+sealed+signed siSCM agent makes non-vacuous competence
gains on a real confounded task WHILE keeping J net-monotone, robustly to realistic anticipation error.
- **H0 (anticipation-artifact null — replaces "necessary-freeze"):** the ≥0.05 gain over compute-matched B2 with
  zero-unidentified-kept-rewrites is NOT robust to REALIZED anticipation error — either it requires anticipation error
  p below the churn-onset p*(≈0.02–0.05, S-5/D3), OR closing the audit loop (revert non-recovering installs) drops the
  net gain below 0.05.
- **H1:** the ≥0.05 absolute sealed-held-out gain over compute-matched B2 SURVIVES at deployable anticipation error
  with the realized-J audit loop closed, J stays net-monotone (cumulative signed ΣΔJ ≥ −2Δn, zero unidentified kept
  rewrites), AND the identifiability-vs-competence frontier binds (tempting back-door-opening high-competence rewrites
  exist and are rejected). Report the gain-vs-p curve and its crossing.
- **Requirements:** confounded task with a GENUINELY LATENT unobserved H (Dhruv's external benchmark or CausalWorld
  Space-B with latent H); sealed held-out do-audit + a SEPARATE held-out realized-outcome audit. **E0 (KU-φ1) must
  pass on this substrate first.** Anticipation error is the SWEPT axis. Control arms (all pre-registered into H1):
  (1) **capacity+compute-matched B2** (same params + train-compute — else gain = "more optimization"); (2) **random-
  valid-rewrite-under-gate** (if it clears 0.05, gain = menu expressivity, not J-selection); (3) **none-gate** (must
  out-progress the gated agent — the gate must have a real, reported COST); (4) **sealed-but-no-width** (identical seal
  + lookahead, acceptance on sealed competence delta with NO width term — monotone-J must STRICTLY dominate it, protocol
  N2, or the win is the seal's not the identification certificate's); plus ignorant/hedonistic. A100 (est. 700–1400 h).
  *Does NOT witness:* the C7-progress COMPOSITION theorem (proof obligation); refutes the null on ONE instance.

## E5.5 — closed-loop revert MITIGATES the S-5 anticipation fragility  *(A100; shares E5 harness)*
**Claim:** closing the audit loop (revert installs whose REALIZED recovery fails a held-out audit within window k)
restores net-monotone true-J well past the open-loop churn onset, at a bounded progress cost.
- **H0:** closing the loop does NOT restore net-monotone true-J beyond the open-loop churn onset p≈0.02–0.05, OR
  restores it only by collapsing progress below 0.05.
- **H1:** closed-loop keeps true-J net-monotone up to p_closed ≫ 0.02 while retaining non-vacuous progress (≥0.05 over
  B2), with a reported progress cost of the revert loop.
- **Requirements:** the E5 confounded substrate + harness; a held-out realized-recovery audit within window k;
  open-loop vs closed-loop paired, sweeping p across p*. A100 (shares E5). *Does NOT witness:* a remedy for
  above-n_crit seal failure.

## E6 — realistic will REQUIRED (emergent) + realized fragility boundary  *(A100; needs E0,E5 harness)*
**Claim (complements C6):** with divergence EMERGENT (value-swap only), realistic preserves true-J + gains competence,
ignorant self-damages, hedonistic is seal-bounded; and a REALIZED anticipation-fragility boundary exists.
- **H0:** with a machine-checked emergence gate enforced, the three wills do NOT separate on TRUE-J (realistic no
  better than ignorant/hedonistic at preserving true-J while gaining competence); OR no realized-harmful-churn boundary
  exists (it is a smooth cutoff-dependent ramp); OR the hedonistic false-exogeneity attempt is not actually generated
  and defeated (its seal-bound is vacuous).
- **H1:** realistic keeps true-J net-monotone + gains true competence; ignorant self-damages (true-J falls);
  hedonistic's true-J drop is seal-bounded to 2Δn (below n_crit) with the false-exogeneity attempt GENERATED and
  DEFEATED; and a realized-p* boundary exists (stable across classifier cutoff and seeds, super-linear), with the
  believed-vs-realized-p* gap reported.
- **Requirements:** ONE emergent acceptance-and-retention mechanism, swapping ONLY the Everitt value function;
  **machine-checkable emergence GATE** = code-diff identical across variants + an equal-value-function negative control
  that COLLAPSES the variants (the confound that killed S-3); confounded substrate (true-J non-degenerate); both halves
  (divergence AND J-preservation) in ONE joint run; **p\* located on REALIZED held-out outcomes, not the agent's own p̂**
  (p̂ is precisely what the agent is systematically wrong about — circular). A100 (shares E5/E0). *Does NOT witness:*
  re-deriving Everitt Thm 14/15/16 (cited).

## E7 — structure-intervention ≠ value-intervention on a REAL transformer  *(A100; standalone; parallelizable)*
**Claim (complements C1):** on a real transformer circuit a structure-intervention (mechanism-node edit) is NOT
expressible as a matched-coverage value-intervention — Def-11 survives beyond the weight-vs-activation artifact.
- **H0:** the structure-vs-value gap VANISHES when the value family is given EQUAL reach (best adversarial pin —
  scalar/vector/subspace/per-bucket — at every relevant locus, over the iteration/time axis); the distinction is a
  weight-persistence vs activation-transience implementation artifact (a ROME generalization-vs-specificity result).
- **H1:** even under the strongest matched-coverage pin over the iteration axis, a structure-do on the IOI name-mover
  HEAD (different downstream children than the name TOKEN) yields a residual D* above the matched-null band D_null that
  no value-do reproduces; AND the residual concentrates on context-VARYING inputs and drops to null for near-constant
  nodes (the parent-sensitivity SCALING signature — the mechanism's unique fingerprint).
- **Requirements:** open-weight LM + externally-certified IOI circuit; strongest-adversary matched-coverage pin +
  norm/count-matched + coverage-match diagnostic; explicit iteration/time axis; **null-locus negative control** (gap
  must VANISH where children coincide); multi-model / multi-circuit replication. A100 (~200–400 h). *Does NOT witness:*
  C2 reflexive-closure-as-SCM (category error — see E9); the operator TYPING (definitional).

## E8 — width-oracle robustness / no ground-truth back-channel  *(CPU; gates E1's oracle for reuse)*
**Claim:** the shared autobounds partial-ID oracle recovers analytically-known widths across the point-ID→vacuous
regime and does not read simulator ground truth via a back channel.
- **H0:** autobounds fails to recover analytically-known widths within tolerance across the continuous/general-DAG
  regime E4/E5 use, OR a leakage audit detects it reading ground-truth do-effects it should not have.
- **H1:** it recovers known widths within tolerance from point-ID to vacuous, with a PASSING leakage audit (blinded to
  ground truth).
- **Requirements:** analytically-solvable DAGs with known widths; a leakage audit (permute/withhold the ground-truth
  channel and confirm width is unchanged). CPU. *Runs alongside E1* (validates the oracle before it is reused by
  E2–E5). *Does NOT witness:* general-DAG completeness of autobounds.

## E9 — reflexive edit-dynamics have a well-defined fixed point  *(CPU/GPU small; standalone)*
**Claim (the empirically-checkable RESIDUE of C2, which is otherwise a category error):** the converged edit-parameter
of the reflexive self-rewrite is a unique basin, consistent with a Bongers cyclic-SCM fixed point — checked on the
EXTRACTED low-dim edit-parameter SCM, NOT as a neural-fixed-point claim.
- **H0:** the converged edit-parameter's dispersion across random restarts/seeds (E5 world-model + E7 transformer
  edit-dynamics) is inconsistent with a unique fixed point (multi-modal / restart-dependent).
- **H1:** restart-dispersion ≈ 0 (single basin), consistent with a well-defined cyclic-SCM fixed point on the extracted
  edit-parameter SCM; Bongers unique-solvability criteria checked on that extracted SCM.
- **Requirements:** restart/seed sweep of the edit-dynamics; extraction of the low-dim edit-parameter SCM; Bongers
  criteria check. *Does NOT witness:* that the transformer/world-model ITSELF is a simple SCM (bridge assumption — a
  category error to claim); this is a consistency check, not an axiom verification.

---

### Honest scope (OFF the list — formal/cited/definitional)
C7-progress composition theorem (proof obligation); C7-safety + unsealed-breaks (proven, telescoping identity —
cross-validate only); operator typing (definitional); reflexive-closure-as-simple-SCM (category error; only E9's
extracted-SCM consistency check is empirical); full Everitt 14/15/16 (cited); n_crit slope (algebraic identity); A-1
unified thesis / open-ended RSI (no experiment banks these).
