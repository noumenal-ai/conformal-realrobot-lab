# siSCM RSI — empirical witness programme (adversarially hardened)

*Derived by a 15-agent design→stress-test→synthesis workflow (per-witness killer-confound hunt). Every naive
witness returned NEEDS_FIXES with a fatal proxy gap; the fixes and run-order below are what survives.*

## The root finding (why the naive programme is a toy-in-disguise)
All seven witnesses share one instrument — `sealed_J_oracle.py::bp_width`, a 16-type **binary-IV Balke–Pearl LP**.
Two fatal properties infect every downstream claim:
1. **It reads the simulator's own ground-truth SCM** (CausalWorld/PHYRE do-oracle) ⇒ identifiability is never actually
   at risk ⇒ the "confounded" task is **rigged** (W-PROGRESS falsification = RIGGED).
2. **It hard-requires a binary instrument Z with exclusion** that NO real anchor (Sachs, Jobs, CausalBench, ADCB)
   natively supplies — their real interventions give `P(C|do(X))` directly, making the IV-LP inapplicable (no Z) or
   degenerate (width→0 by fiat). So "real data" is vocabulary over a synthetic 2×2×2 toy.
3. **Instrument–theorem mismatch:** the Lean result is Manski single-arm `width = 1−p` (coverage), back-door = *less*
   coverage; `bp_width` is IV partial-ID. The empirical does not complement the proven theorem as claimed.

**Shared fix (build once):** upgrade the oracle to an **arbitrary-DAG / continuous partial-identification engine**
(`autobounds` polynomial programming; cross-checked by DoWhy `identify_effect` + Ananke) that needs **no manufactured
instrument**. Every seal/width/metric-fork/progress experiment imports this one hardened oracle.

## Strongest single witness (most paper-moving)
**W-PROGRESS (the freeze question).** The only claim the machine-checked safety spine genuinely leaves open: on a real
confounded task, is safety COMPATIBLE with progress, or does a realistic agent valuing identifiability necessarily
FREEZE? Crisp H0 (necessary-freeze): *every net-monotone-J trajectory is competence-flat — cannot beat the
gradient-only baseline B2 on the confounded arm by ≥0.05 absolute sealed success while keeping cumulative signed J above
the −2Δn floor with zero identifiability-uncertified rewrites.* **Reject H0** ⇒ non-vacuity by existence, live progress
story. **H0 holds** ⇒ C7-progress empirically negative, paper honestly becomes the framework shape (KU1 answered) — a
clean publishable result either way. Caveat: refutes *necessary-freeze on one instance*; does NOT close the C7-progress
composition theorem (stays a proof obligation).

## Run order (importance ≠ run-order; cheap go/no-go first)
1. **W-C3-BPWIDTH-REAL** — GO/NO-GO. The one experiment where the shared oracle meets real data. CPU-only, ~1 week.
   If J=−width can't be computed with genuine identification content on real confounded structure, the programme is a
   framework paper and nothing else fires. **Run first.** (Anchors: Sachs real chemical interventions; Jobs/LaLonde
   RCT-arm = point-ID sealed oracle vs observational = confounded.)
2. **W-C5-ncrit-transition** — cheapest falsifiable-beyond-algebra test. n_crit=4ln|F|/V² is an *algebraic identity* of
   the seal's own threshold; only contingent question = does adaptive search over REAL correlated framings realize the
   independent-Gaussian EVT tail. Depends on C3 oracle. CPU.
3. **C5-SEAL-adaptive-wireheading** — sealed-vs-unsealed on real ADCB/STAR/Twins. Split into (A) identification-bias
   seal [=C3 at scale] and (B) pure concentration seal [new]; only (B) is load-bearing. Reuses C3+C5-ncrit harness.
4. **W-C7SAFE-METRICFORK** — trajectory-level (multi-step telescoping) real-data safety-ceiling demo on CausalBench
   CRISPR. Much of it is algebra already covered by C3+C5; demoted. Needs the continuous/general-DAG oracle.
5. **W-PROGRESS** — apex-adjacent but ranked 5th to RUN: needs (i) **KU-phi1** (structure-intervention operator
   provably not gradient-expressible, currently UNBUILT) and (ii) a measured identifiability-vs-competence FRONTIER
   showing the gate binds on a genuine tradeoff. Most expensive (700–1400 A100-h, 3–4 wk). Run only after C3 confirms J
   has real content and KU-phi1 is unit-witnessed like tsem.py.
6. **C6-WILL-DIVERGENCE-FRAGILITY** — three Everitt wills. Killer confound = divergence-BY-CONSTRUCTION (the variants
   were hand-coded retention branches). Fix is architecturally heavy: ONE emergent acceptance mechanism swapping ONLY
   the value function; both halves (divergence AND J-preservation) in one joint run on a confounded substrate. Shares
   W-PROGRESS's A100 harness. Highest engineering risk.
7. **W-C1C2-structfid** — construct fidelity on a transformer. Current design re-derives a mundane ROME
   weight-vs-activation artifact, NOT the Gladyshev Def-11 distinction; all three operationalizations share the
   confound. Salvage: add an iteration/time axis + matched-coverage value ops, anchor solely on IOI. C2 neural-fixed-
   point is a category error — cut or reduce to checking Bongers criteria on the extracted edit-parameter SCM.
   Standalone (open-weight LMs), runs whenever A100 is idle. Least paper-moving.

## Shared infrastructure (build once)
- **One hardened width oracle** — autobounds arbitrary-DAG partial-ID (no manufactured instrument), cross-checked by
  DoWhy + Ananke; built in C3, imported everywhere. Install+validate `autobounds`, `ananke` (currently fail to import).
- **One causal-benchmark battery** (public, CPU, offline): Sachs (bnlearn, real chemical do), Jobs/LaLonde-Dehejia-
  Wahba (DoWhy; RCT vs observational), ACIC2016 + IHDP + Twins (CEVAE/aciccomp; λ confounding knob), CausalBench/
  Replogle Perturb-seq (>2e5 real CRISPRi do), ADCB (tunable γ sets true width V). One loader + one pre-registered
  binarization/estimand + one hash-committed sealed split.
- **One GCP A100 harness** (gcp-harness: a2-highgpu-1g, TERMINATE, resume-safe GCS) for the TWO GPU tracks only —
  PHYRE/CausalWorld world-model (W-PROGRESS+C6) and transformer (C1C2). The entire causal-benchmark spine (C3, both
  C5s, C7-safety) is **CPU-only** (16-var LP is ms) on n2-standard-128.
- **One structure-intervention operator (KU-phi1)** — the single most load-bearing UNBUILT artifact. Discrete edge
  install/remove on a C-SWM/NRI mechanism graph, provably not expressible by gradient flow, unit-witnessed like tsem.py
  (temporal persistence 0111111 vs 0000000 + graph-surgical extra-child) BEFORE any GPU run. Every "structure-edit beats
  SGD" (B2) control routes through it.
- **One adaptive-wireheading attacker** (CMA-ES + Optuna-TPE + optional LLM-guided), x-axis = number of adaptive
  QUERIES against the reusable panel (Dwork/Audit-CP quantity), framings = REAL correlated model outputs not Gaussian.
- **One pre-registration discipline** — OSF thresholds, seeds (5 base → 20–30 for fragility), exact
  Δn=(b−a)√(log(2|F|/δ)/2n) (no free constant), full V range reported (incl. vacuous V<0.2 cells), sha256 of sealed
  panels before any run, S-5-style multi-assessor code-rerun before any claim.

## NOT empirically witnessable (stays formal / cited / definitional — honest)
- The **C7-progress composition theorem** (UK-2, non-vacuous progress ∀ admissible rewrite classes) — proof obligation
  (compose Everitt Thm16 + Audit-CP 3.4/3.5/4.3 + Pearl ID). Experiment refutes necessary-freeze by existence, never
  proves general non-emptiness.
- **C7-safety + unsealed-breaks** — already machine-checked; unsealed unboundedness is a telescoping identity (Ĵ=n,
  J≡0). Experiments cross-validate the ceiling as a side-check only. Do NOT re-witness formally.
- **The operator typing** (a weight/edge edit *deserves* the name "structure intervention") — construct-definitional
  (Gladyshev Def 11 / MacDermott Def 3). Experiments show it non-vacuous, cannot force the naming.
- **Reflexive-closure-as-SCM** — positing a transformer's edit-dynamics ARE a Bongers simple-SCM is a bridge
  assumption; restart-dispersion≈0 verifies no SCM axiom. C2 as neural-fixed-point is a category error.
- **Full Everitt Thm 14/15/16** — cited framework posture (only everitt16_safety_core is derived).
- **n_crit's slope-1 in |F| and 1/V²** — algebraic identity of the seal's own threshold; only the contingent
  real-correlated-search-realizes-EVT question is empirical.
- **A-1 unified thesis / open-ended RSI** — no experiment banks these; a positive progress result witnesses ONE bounded
  safe trajectory.

## FIRST-RUN SPEC — W-C3-BPWIDTH-REAL, Stage E1 (go/no-go)
GOAL: prove J=−(partial-ID width) has genuine identification content on real confounded structure before any GPU dollar.
- **Data (fully real):** (1) Sachs 2005 protein-signaling — 11 nodes, ~7466 single-cell flow cytometry, observational +
  real chemical-intervention conditions (bnlearn); confounded pair pre-registered from the 17-edge consensus DAG in a
  sealed envelope by Dhruv before any width is computed. (2) Jobs/LaLonde-Dehejia-Wahba — NSW RCT arm = point-identified
  sealed oracle vs PSID/CPS observational = confounded (DoWhy bundled).
- **Oracle:** autobounds (arbitrary-DAG, no manufactured instrument) primary; cross-check vs `bp_width` scipy-HiGHS on
  any binary-coarsened sub-instance (agree 1e-3) + DoWhy `identify_effect` + Ananke for the independent point-ID verdict.
  Structure-intervention (open back-door H→X) as a DoWhy gcm mechanism-node intervention on real fitted mechanisms.
- **Metrics / pass conditions:** (a) width in point-ID regime (Jobs RCT arm; Sachs intervened protein) — pass iff
  bootstrap 95% CI lower bound ≤0.10 (near 0); (b) ΔJ = width_after − width_before for the back-door-opening rewrite —
  pass iff CI excludes 0 and is positive; (c) value-vs-structure discrimination — do(X) must NOT reproduce the width
  change; (d) seal integrity — false-exogeneity rewrite width vs honest partial-ID width within 2Δn while naive-unsealed
  = 0.
- **Seeds/stats:** 5 seeds (resampled panels), B=2000 nonparametric bootstrap per width, sealed panel n=2000 (Δn≈0.02).
- **Compute:** CPU-only, laptop-feasible (O(1e4) small LP solves, minutes–hours). No A100.
- **Decision:** all four pass ⇒ the shared oracle is real; green-light the GPU spine. Any fail ⇒ the programme is a
  framework paper; report honestly.
