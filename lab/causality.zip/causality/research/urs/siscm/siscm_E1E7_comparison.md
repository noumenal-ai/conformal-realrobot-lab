# siSCM E1–E7 — comparison: Dhruv's DoWhy package vs my v1 cross-check

*Dhruv's `siscm_dowhy_E1_E7` is a RUNNABLE DoWhy implementation built on my **v0** skeleton (it ships `docs/original_E1_E7_prereg_skeleton.md` = my v0, pre-cross-check). My **v1** is the adversarially cross-checked hypothesis set. So the comparison is: his executable v0 implementation vs my v1 rigor additions. They are largely COMPLEMENTARY — his code is the execution substrate; v1 is the hypothesis hardening.*

## Headline
Three independent derivations now exist (my design workflow, the blind re-derivation, and Dhruv's implementation) and they CONVERGE on the core. Most important: **Dhruv independently avoided the single biggest risk the cross-check found** — the binary-IV Balke–Pearl `bp_width` trap. His `PartialIDOracle` is stratified Manski + DoWhy `identify_effect`, instrument-free, and explicitly "does not manufacture instruments and does not silently treat latent backdoors as point-ID." That was the #1 fatal proxy across all seven of my naive witnesses; his code never had it.

## Where his package is strong / independently caught the cross-check
1. **Instrument-free Manski oracle** (`partial_id.py`) — no manufactured binary IV, no simulator-ground-truth read. Solves the cross-check's root finding by construction.
2. **E1 point-ID tightened** — his design note flags my v0 "width CI lower-bound ≤0.10" as "mathematically too weak" and pre-registers the stronger **CI upper-bound ≤0.10** (`e1: point_id_width_ci_upper`). Same weakness the cross-check found, fixed independently.
3. **E3 bound-approach ratio** (`bound_approach_ratio ≥ 0.10`) — the cross-check's "the 2Δn bound must BIND, not be vacuously slack." Independently added.
4. **E5/E6 fail-closed + KU-φ1 gate** — E5 blocks unless the endpoint supplies `ku_phi1_witness` (passed) + `trajectory`/`rewrites`/`rewrite_evaluation`; primary contrast is **B2 gradient-only** (not B1-frozen). Honest — refuses to emit a claim without the real endpoint.
5. **Held-out latent-H audit** — `latent_h is used only by the held-out audit; not passed to the model context`. Exactly the cross-check's "genuinely latent unobserved H" (E5) + "held-out interventional oracle" (E4).
6. **Global commitments implemented, not just stated** — Δn = (b−a)√(log(2|F|/δ)/2n) exact (`hoeffding_delta`), Holm–Bonferroni, salted-SHA-256 sealed panels, "synthetic never silently substituted" (Plan-B gated + marked non-claim-bearing), real loaders (Sachs bnlearn, LaLonde NSW RCT vs PSID/CPS, CausalBench K562, CausalWorld Space-B, ARC-TGI).
7. **A sophism-audit harness I did not build** — `audit/judge_prompt`, `make_judge_packets`, `audit_sophisms`, `validate_outputs_schema`, `verify_results`, an output schema, GCP CPU+A100 Docker/startup. This is real execution + review infrastructure.
8. **E7 has the iteration axis + strongest-adversary pin** (min over `value_loci` of `distance_to_structure`) + fail-closed local runner.

**Net: his package is the executable, honestly-gated substrate. On the biggest risk (the oracle) he was ahead of me.**

## What v1 adds that his v0-based code is MISSING (the merge list)
| From v1 | Status in his package | Severity |
|---|---|---|
| **E0 — KU-φ1 matched-compute operator-fidelity as an EXPERIMENT** | His E5 *gates* on `ku_phi1_witness`, but the endpoint SELF-CERTIFIES it — there is no experiment that witnesses the structure-edit against a **compute-matched gradient baseline** on the world-model graph. So "structure beats SGD (B2)" stays confounded with "more compute." | CRITICAL |
| **E5 anticipation-artifact null + anticipation-error SWEEP** | His E5 null is the v0 one (gain≥0.05 over B2, J≥−2Δn, zero uncertified, frontier>0). No sweep of anticipation error p, no robustness to realized error (S-5 p≈0.02–0.05). The cross-check's #1 E5 finding — his apex inherits the strawman-null weakness. | CRITICAL |
| **E5 control arms** — compute-matched B2, random-valid-rewrite, none-gate, **sealed-but-no-width (N2)** | Has B2-gradient + frontier-rejected>0; missing the four discriminators that separate *J-guided selection* from more-compute / menu-expressivity / the-seal-alone. | CRITICAL |
| **E5.5 — closed-loop revert mitigation** | Absent. The S-5 fragility fix ("revert non-recovering installs") is neither built nor tested. | CRITICAL |
| **Boundary-relative seal nulls** (E3, E6-hedonistic, E1 false-exog leg) | E3 tests "sealed inflation ≤2Δn" globally (rigged-true below n_crit); the bound-approach ratio partly mitigates but the ABOVE-n_crit failure regime is never tested. | MAJOR |
| **E2 point prediction (1−ρ_eff) + matched-Gaussian pipeline-validity control** | E2 uses nondirectional `rel_shift>0.05` (generic ESS shrinkage satisfies it) and computes `mean_framing_overlap` but never uses it as a point prediction; no i.i.d.-Gaussian control that MUST land on 4ln\|F\|/V², so a shift could be estimator bias. | MAJOR |
| **E6 machine-checkable emergence gate + p\* on REALIZED outcomes** | E6 asserts `acceptance_mechanism_shared:true` (endpoint trusted, not code-verified) and locates p\* on the model's own `p_hat` — the circularity the cross-check flagged (p̂ is what the agent is wrong about); no equal-value-function collapse negative control (the S-3 confound). | MAJOR |
| **E7 null-locus control + parent-sensitivity signature + multi-circuit replication + matched-null band** | E7 has iteration axis + min-over-loci pin, but no locus-where-children-coincide control (gap must VANISH there), no parent-sensitivity scaling, single model/circuit, hand-set 0.05/0.10 thresholds instead of a matched-null band D_null. | MAJOR |
| **E8 — width-oracle robustness / no ground-truth back-channel** | No experiment validates the Manski oracle recovers analytically-known widths or audits for leakage (smoke test checks plumbing only). | MAJOR |
| **E9 — restart-dispersion / Bongers fixed-point** | Absent (C2's only empirical residue). | MINOR |

## New finding from reading his code (neither v0 nor the cross-check had this)
**His oracle conflates two different "widths."** In point-ID the width is the bootstrap **CI width** of the adjusted ATE (a *statistical* quantity → 0 as n→∞); in partial-ID it is the **Manski structural interval** (a *structural* quantity that does NOT shrink with n). So E1's `structure_width_increase` (ΔJ>0) partly rides the statistical→structural **mode-switch** triggered by the latent-marker in the DOT graph, not purely a data-driven identification fact — and "width≈0 at point-ID" is "tight CI," not a structural 0. FIX (for both of us): report the point-ID width as a **structural** singleton-set width (cf. the Lean `IDProblem` model where `PointIdentified` = the identified SET is a singleton, and `width` = its diameter), OR report CI-width and structural-width as two separate quantities so a reviewer cannot say the identification signal is the oracle's mode-switch.

## Bottom line
The merged protocol = **his runnable, honestly-gated implementation** (keep the Manski oracle, fail-closed E5–E7, held-out latent-H, the judge/audit harness, all global commitments) **+ v1's rigor additions** (E0 as a real matched-compute experiment; E5's anticipation-artifact null + 4 arms; E5.5; boundary-relative seal nulls; E2 point-prediction + Gaussian control; E6 emergence-gate + realized-p\*; E7 controls; E8; E9) **+ the CI-vs-structural-width fix**. Neither set alone is submission-grade; together they are strong. His code is where we execute; v1 is what we harden the endpoint contract against before we do.
