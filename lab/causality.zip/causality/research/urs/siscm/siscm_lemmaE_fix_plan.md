# Lemma-E fix — implementation plan (defeating the A2 circularity demolition)

**Root cause (demolition A2/A4d, MAJOR):** `thm16_realistic : accepts realistic → endorsedByWill`, and `endorsedByWill` is **defeq** to the lemma's conclusion `ΔJ ≥ −slack`. So `lemmaE_realistic_preserves := E.thm16_realistic` is a bare `X→X` projection; Everitt Thm 16's real content (accepted rewrites are **u₁-optimal**) is absent.

**Fix principle (green≠γ; A4):** introduce a predicate `realisticOptimal` that is Everitt's *actual* conclusion (u₁-non-decrease) and is **NOT defeq** to `endorsedByWill` (the J-constraint). Then the realistic clause becomes a genuine **two-step composition** through a bridge `optimal_endorses`, and `thm16_realistic` is no longer the conclusion. The bridge is the **will-design** content (why u₁-preservation forces J-preservation), and it must be *discharged by a concrete instance*, not only assumed.

## Type scaffold (hand to the writer)
```
-- u₁ : the agent's ORIGINAL utility, modification-independent (graph functional)  [Everitt Assn 8]
-- realisticOptimal s s' := u₁ s'.graph ≥ u₁ s.graph          -- Everitt-16 conclusion (u₁ non-decrease)
-- endorsedByWill   s s' := J s'.graph ≥ J s.graph − slack    -- the net-with-dip J-constraint (UNCHANGED)
-- KEY: realisticOptimal is u₁-about; endorsedByWill is J-about ⇒ NOT defeq.

structure EverittModel (Jg : Justification Graph) (slack : ℝ) where
  accepts        : AgentType → State Graph History → State Graph History → Prop
  u₁             : Graph → ℝ                                   -- original utility (modIndep)
  slack_nonneg   : 0 ≤ slack
  -- Everitt Thm 16 [IMPORT]: realistic agent's accepted rewrites are u₁-optimal (non-decreasing).
  thm16_realistic : ∀ s s', accepts AgentType.realistic s s' → u₁ s'.graph ≥ u₁ s.graph
  -- The WILL-DESIGN bridge [the real content]: utility-preservation ⇒ J-preservation within slack.
  --   (This is where "the will values J" lives; modIndep is what lets it be stated on graphs.)
  will_couples_J : ∀ g g', u₁ g' ≥ u₁ g → Jg.J g' ≥ Jg.J g − slack
  -- Everitt Thm 15 [IMPORT]: ignorant unprotected (∃ accepted-unendorsed ignorant rewrite).
  thm15_ignorant_unprotected : ∃ s s', accepts AgentType.ignorant s s' ∧ ¬ (Jg.J s'.graph ≥ Jg.J s.graph − slack)

-- bridge (NON-defeq: applies will_couples_J)
def optimal_endorses (E) {s s'} (h : E.u₁ s'.graph ≥ E.u₁ s.graph) : Jg.J s'.graph ≥ Jg.J s.graph − slack :=
  E.will_couples_J _ _ h

-- THE realistic lemma: genuine two-step  (thm16 : realistic→u₁-nondecrease ; then bridge to J)
theorem lemmaE_realistic_preserves (E) {s s'} (h : E.accepts realistic s s') :
    Jg.J s'.graph ≥ Jg.J s.graph − slack :=
  optimal_endorses E (E.thm16_realistic s s' h)
```

## Proof obligations (the writer MUST achieve all)
1. **Non-defeq check (defeats A2):** `thm16_realistic`'s type (`… → u₁ s'.graph ≥ u₁ s.graph`) is NOT defeq to `endorsedByWill`/the conclusion. The writer must VERIFY this in Lean (e.g. an `example` asserting the defeq must FAIL to typecheck, or show the two Props are distinct). The realistic lemma must be a **two**-step composition (`optimal_endorses (thm16_realistic h)`), not a one-step projection.
2. **Concrete discharge (defeats "just more assumptions"):** provide a concrete `EverittModel` instance with a real will-design (e.g. `u₁ := Jg.J`, the justification-first will) in which `will_couples_J` is **PROVED** (`fun g g' h => by linarith [slack_nonneg]`), not assumed — demonstrating the bridge is provable and the model non-vacuous, with `thm16_realistic`/`thm15` also satisfied.
3. **Hedonistic faithfulness (defeats A5):** add `thm14_hedonistic : accepts hedonistic s s' → (∀ s'', O.Jhat s''.graph ≤ O.Jhat s'.graph)` tying `AgentType.hedonistic` + `SealedOracle`, and re-derive the seal-bound THROUGH the agent machinery (so `AgentType.hedonistic` is not a dead constructor). The `2Δn` arithmetic is preserved.
4. **Range fields (defeats A4a):** either USE `J_nonpos`/`J_ge_neg_one` (e.g. an absolute-floor corollary `J s'.graph ≥ -1` consuming `J_ge_neg_one`) or strike them and move the range to a comment. No decorative hypotheses.
5. **modIndep honesty (defeats A4b):** keep `endorsedByWill_modIndep` but label it "holds **by construction** (u₁,J are graph functionals)"; its load-bearing role is that it licenses stating `will_couples_J` on graphs.
6. **Green + axiom-clean:** `lake env lean` rc=0; `#print axioms` on every theorem shows only `[propext, Classical.choice, Quot.sound]`, NO `sorryAx`; no `sorry`/`admit`/`axiom`/`native_decide`/check-disabling `set_option`.
