# Tameness transfer: does the TLT routing-compression design law port to the siSCM rewrite tree?

`verify_tameness.py`. Tests whether the rewrite engine's per-candidate forward-witness scores satisfy TLT's load-bearing `hlin` condition (score-differences in a finite-dimensional space ⇒ finite VC ⇒ the routing-compression design law applies). Honest to the adversarial retraction: the surviving witness is **interval-valued** (Balke–Pearl PNS, the C3 leg), not a point — so the check is run on the interval object too.

## Result — the transfer holds iff the SEM competence is polynomial (o-minimal) in the latent type

**Part A (governance = argmax over candidate witnesses):**
- **affine** competence (degree 1): 1 route alternation ≤ Davenport–Schinzel cap `n−1=3`; score-difference `s_i−s_j` fits degree-1 to residual `1.8e−15` ⇒ lives in `span{1,t}` (dim 2). **`hlin` holds, finite VC. TAME.**
- **quadratic** competence (degree 2): 0 alternations ≤ `λ₂ = 2n−1 = 7`; residual `2.8e−15` ⇒ `span{1,t,t²}` (dim 3). **`hlin` holds. TAME.**
- **sine** competence (non-o-minimal): alternations grow `3 → 13 → 51 → 204` with frequency `ω = 5,20,80,320` (≈ linear in ω); no fixed finite degree fits (degree-12 residual `1.17`). **Unbounded VC, `hlin` FAILS. WILD.**

**Part B (the honest interval witness):** Balke–Pearl PNS bounds `[L(t),H(t)]` with genuine widths (affine: 0.06/0.12/0.24). Affine SEM → 1 alternation (tame); sine SEM → 19 (unbounded in ω). The interval **endpoints** are LP-optimal values of the (polynomial) `P(C|do r,t)`, hence semialgebraic in `t` for a polynomial SEM (tame) and oscillatory for sine (wild). **The retraction to interval-valued does not break the transfer** — tameness is about the score *form*, not point-vs-interval identification.

## Verdict

`hlin`/tameness **transfers ⇔ the siSCM competence is a polynomial (o-minimal) function of the latent type.** In that regime the per-candidate witness scores have finite-dimensional differences, the argmax governance has finite VC (DS-bounded), the point and interval witnesses both inherit it, and **TLT's routing-compression design law ports** — the rewrite tree is a TLT mux-cascade. For non-o-minimal (sine) competence the transfer fails (infinite VC). This matches TLT's *formalized* safe side (polynomial ⇒ finite-dim ⇒ finite VC); the sine/wild side is TLT's prose-only o-minimality boundary (not itself formalized there — it sits with the deferred task R7).

## What this buys (Dhruv's framing), and the honest scope

- **"The highest node can be a compressed tree of the SEM layer's counterfactuals with argmax governance."** Yes — *conditional on the polynomial (tame) SEM*: the root rewrite-node = argmax governance over the candidate counterfactual witnesses = a finite-VC TLT mux-cascade carrying the (interval) counterfactual at each node.
- **"The compressed tree gives us the L3 node and a way to design, write and read to it."** Yes, in the tame regime: **read** = which argmax cell the abduced type lands in (an FO-decidable convex cell for affine scores, a semialgebraic cell for quadratic — TLT's `affineArgmaxCell_FO` / `quadraticArgmaxCell_SO_semialgebraic` geometry); **write** = set the SEM's competence/prototype scores; **design** = the polynomial degree sets expressivity (TLT's depth/width/degree hierarchy). Caveat: each read returns a sound **interval** (Balke–Pearl), not a point.

## Open (not claimed verified)
- The **tameness transfer is verified**; the **full design-law port** (instantiating TLT's `temperedDesignLawCertificate` legs on the rewrite selector, matching `hlin`/`WellBehavedVC` to the witness) is the next step, not done here.
- The **logical/metaprogram spine** — "second-order logic / metaprogram compression to the tree via argmax" — is TLT's deferred task **R7** (the Engelfriet–Maneth MSO tree-transduction equivalence of `CascadePolyFunctor`), absent from the repo. That is the shared frontier: closing R7 would give both TLT and this rewrite tree their logical characterization.
