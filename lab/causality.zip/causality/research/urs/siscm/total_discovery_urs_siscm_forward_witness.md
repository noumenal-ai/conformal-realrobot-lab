All 22 atom IDs verified present in the audited DAG. Producing the Total Discovery URS.

---

# TOTAL DISCOVERY URS — The Forward Self-Witness of a Self-Interventional SCM is ACHIEVABLE

**Object under defense (the siSCM forward self-witness).** Let `M = ⟨U, V, F, P(U)⟩` be an siSCM: a regime node `Σ` selects the in-force equation set `F = F_σ`; a self-mechanism `f_Σ : (V, U) → σ'` computes the next regime endogenously and is itself among the σ-selected mechanisms (reflexive closure); a sealed competence node `C` is computed by `f_C` lying outside Σ's manipulable set (the seal). The **forward self-witness** is the L3 quantity

```
W  :=  C  under  do(Σ = σ_{t+1}),   evaluated at time t, BEFORE σ_{t+1} is realized,
```

via abduction–action–prediction on `M_{σ_t}` (abduct `U` from the σ_t-behaviour, install the antecedent `Σ = σ_{t+1} = f_Σ(solve(M_{σ_t}))`, predict `C` in the submodel).

**Claim shape.** `W` is ACHIEVABLE = {well-defined, identifiable, sound, non-vacuous}. The proof is by *defeat of every negative subargument* (N1–N6) with a concrete, non-pathological, Pearl-grounded siSCM in which that obstruction provably does not bite — culminating in a *single unified counterexample* satisfying all six defeater-conditions at once. The result is **existence-grade and conditional**: it holds on a named regime (the conjunction of the six defeater-conditions), and the honest scope limit is exactly the complementary region (CHT-generic / non-identified / entangled / cyclic), reported in §D as a finding.

---

## A. POSITIVE CLAIM (the theorem and its one named hypothesis)

> **Theorem (Forward-Witness Achievability, conditional form).**
> Let `M` be an siSCM in the **WELL-POSED FORWARD-WITNESS REGIME** `𝓡★` (Definition below). Then the forward self-witness `W = C under do(Σ = σ_{t+1})` is **well-defined** (a determinate L3 object whose antecedent exists and is unique at time t), **identifiable** (a point-valued functional of L1/L2 quantities, or — under partial-ID — a *sharp* interval certificate), **sound** (true in every model compatible with the time-t evidence), and **non-vacuous** (a nondegenerate quantity strictly interior to its range). The regime `𝓡★` is the **hypothesis** of the theorem; the achievement is *conditional on `𝓡★`*, not unconditional.

**Definition — the WELL-POSED FORWARD-WITNESS REGIME `𝓡★`.** `M ∈ 𝓡★` iff it simultaneously satisfies the conjunction of the six defeater-conditions:

| # | Defeater-condition (named) | What it buys | Leg of "achievable" | Grounding atoms |
|---|---|---|---|---|
| **C1** | **Recursiveness / forward-unrollability.** The self-loop is *time-unrolled*: `σ_{t+1} = f_Σ(solve(M_{σ_t}))`, `f_Σ`'s arguments are non-descendants of Σ *within the step*; the unrolled product-SCM over (time × variables) is acyclic. | "solve" = topological evaluation, total & single-valued; trajectory `{σ_t}` exists & is unique. | **Well-defined** (antecedent exists) | T7_3_5, D7_3_4, D7_1_1, D7_1_6 |
| **C2** | **Identification of `Σ→C`.** The regime→competence effect is do-calculus/ID-identifiable (a finite sound symbolic derivation exists) **or** admits a valid back-door/complete-adjustment set. | L2 effects `P(C_σ)` are recoverable from L1+do-data. | **Identifiable** (point, where ID succeeds) | T3_4_1, EXT_ID_DO_CALCULUS_COMPLETE, T3_3_2, EXT_COMPLETE_ADJUSTMENT |
| **C3** | **Partial-ID soundness (exogeneity ± monotonicity).** Where point-ID fails, the seal makes `C` a Pearl response-type variable; exogeneity ± monotonicity yields a **sharp Balke–Pearl/PNS bound** — point under monotonicity, strict interval `[L,H]⊊[0,1]` without it. | A *sound, non-vacuous* certificate even under L3 non-collapse (CHT). | **Sound + non-vacuous** | T9_2_14, T9_2_15, T9_2_10, T9_2_11, C9_2_12, EXT_IV_PARTIAL_IDENTIFICATION |
| **C4** | **Abduction–action decoupling (clean seal).** `U = U_self ⊥ U_pred`; `σ_{t+1}` is `U_self`-measurable, `C = f_C(U_pred, θ_C)` reads `U_pred` only, with `θ_C ∉ Manip(Σ)`. The seal is `U`-disjoint from `f_Σ`'s read. | Abduction posterior factorizes; antecedent is a *constant* relative to the prediction integral ⇒ AAP factorization well-formed; *equality-by-structure*, open-set, not by cancellation. | **Well-defined + identifiable** (separability) | D9_2_9, T7_1_7, D7_1_5, D6-region (No-Confounding/stability) |
| **C5** | **Conditional-intervention legitimacy.** `do(Σ = σ_{t+1})` is read as `do(Σ = g(Pa_Σ))`, `g = f_Σ` restricted to the pre-surgery valuation, with `Pa_Σ ⊆ NonDescendants(Σ)`. Surgery deletes `f_Σ` and installs the function `g`; the antecedent is computed from variables that survive the surgery. | The endogenous antecedent is a legitimate plan/policy intervention (L3, not L1) — `do ≠ see`. | **Well-defined (type-level)** | T4_4_1, D4_4_2, D7_1_2, D7_1_3, T7_1_7 |
| **C6** | **Analytic evaluability (solve-don't-run).** All mechanisms are *total, finitely-described* maps; `f_C` is sealed-and-known at evaluation time. `W` is a **potential response** obtained by solving the recursive submodel, not a semantic property of an arbitrary executed program. | Rice/undecidability finds no purchase; `W` is a closed-form/finitely-evaluable quantity. | **Well-defined (computable)** | D7_1_1, D7_1_4, D7_1_5, T7_1_7 |

> **The hypothesis is the conjunction:** `𝓡★ = C1 ∧ C2(or C3) ∧ C4 ∧ C5 ∧ C6`. Equivalently, in one sentence: *`M` is a recursive, forward-unrolled siSCM whose self-mechanism reads only non-descendant (upstream/exogenous) variables through finitely-described total mechanisms, whose sealed competence node is `U`-disjoint from the regime-selection channel and lies outside Σ's manipulable set, and whose `Σ→C` effect is either do-calculus-identified or exogenous-and-(non-)monotone.* On `𝓡★`, `W` is well-defined, sound, non-vacuous, and identified-to-a-point-or-sharp-interval. **This regime IS the theorem's hypothesis; the claim is achievability-on-`𝓡★`, conditional, not universal.**

A structural note that the six conditions are not independent ornaments but a single load-bearing chain: **C1 supplies the object** (a unique trajectory, hence an antecedent to bind); **C5 certifies the antecedent's binding is a genuine intervention** (do, not see); **C6 certifies the binding is computable** (solve, not run); **C4 certifies abduction and that binding separate** (no entanglement); and **C2/C3 certify the resulting L3 value is recoverable** (point where ID succeeds, sharp interval otherwise). Remove C1 and there is nothing to witness; remove C4 and the witness is ill-defined; remove C2/C3 and it is unidentified. The seal (`θ_C ∉ Manip(Σ)` **and** `U`-disjoint, **and** known-at-evaluation) is the single feature that simultaneously feeds C3, C4, and C6 — it is the keystone, and its integrity is the standing proof obligation that recurs across the residuals (§D, §E-UK).

---

## B. OBSTRUCTION → DEFEATER-CONDITION → COUNTEREXAMPLE MAP

| N | Obstruction (the negative subargument) | Why it would kill `W` | Defeater-condition (named) | The single structural feature that defeats it | Pearl-atom grounding |
|---|---|---|---|---|---|
| **N1** | **Fixed-point non-existence.** `σ* = f_Σ(solve(M_{σ*}))` is Liar-shaped; no self-consistent regime ⇒ no antecedent ⇒ nothing to witness (ill-typed). | The reflexive object itself fails to exist; `do(Σ=σ_{t+1})` has no argument. | **C1 — Recursiveness (unroll).** Read the self-loop as the indexed recurrence `σ_{t+1}=f_Σ(solve(M_{σ_t}))`; `f_Σ` writes the *next* layer, consumed only after `do(·)`. | The unrolled DAG `U_X^{(t)}→X^{(t)}→Σ^{(t+1)}→X^{(t+1)}…` has **no within-layer cycle**; "solve" = topological evaluation, trajectory exists & unique. | T7_3_5 (Recursive Completeness; AAP sound+complete on recursive SCMs), D7_3_4 (Recursiveness), D7_1_1, D7_1_6 |
| **N2** | **Witness non-identifiability (CHT / L3 non-collapse).** Distinct siSCMs agreeing on all L1/L2 disagree on the cross-world type-mixture ⇒ `W` set-identified at best. | "Identifiable" leg fails; `W` collapses to an interval, not a point. | **C2 — do-calculus/adjustment ID + C3 — exogeneity+monotonicity.** Place `Σ→C` in the identified region; monotonicity collapses the response-type mixture CHT leaves free. | The seal `f_C` reads an exogenous source **`U`-disjoint from `f_Σ`'s read**, and `C` is **monotone in Σ** ⇒ `PNS = P(C_{Σ=1})−P(C_{Σ=0})` point-identified. | T3_4_1, EXT_ID_DO_CALCULUS_COMPLETE (do-calculus completeness), T3_3_2, EXT_COMPLETE_ADJUSTMENT (back-door/adjustment), T9_2_14, T9_2_15 (exogeneity/monotonicity ⇒ L3 point-ID) |
| **N3** | **Soundness vs vacuity (causal Löb).** Any *provably sound* forward witness must be vacuous (`[0,1]`), because the cross-world quantity is underdetermined and self-reference amplifies the trap. | `W` is either unsound (a point it can't back) or vacuous (`[0,1]`). | **C3 — Sharp partial identification.** Drop monotonicity, keep exogeneity: `W` is the **Balke–Pearl LP-feasible interval** `[L,H]`, sharp (sound) and of strictly positive width (non-vacuous). | The seal makes `C` a binary response-type variable in `X`; with exogeneity-but-¬monotonicity the σ_t-data pins the *margins* `(a,b)` but not the *mixture* ⇒ `0<L<H<1`. **Sharpness = soundness; nonzero width = non-vacuity.** | T9_2_10 ("both bounds are sharp… exists a model realizing any value"), C9_2_12 (nonzero width ⇒ both endpoints attained), T9_2_11, EXT_IV_PARTIAL_IDENTIFICATION |
| **N4** | **Abduction–action entanglement.** The antecedent `σ_{t+1}=f_Σ(V,U)` is an image of the very `U` abduction updates ⇒ no fixed antecedent ⇒ no submodel; AAP step-2 has no input. | "Well-defined" leg fails *before* identifiability: σ_{t+1} is posterior-valued, not constant. | **C4 — Abduction–action decoupling.** `U_self ⊥ U_pred`; `σ_{t+1}` is `U_self`-measurable, `C`-prediction integrates `U_pred` only. | `U_couple = ∅` **by construction**: `f_Σ` reads `U_self`, `f_C` reads `U_pred`, independent ⇒ antecedent is a *constant* w.r.t. the prediction integral; defeat is *structural* (open-set), not by cancellation. | D9_2_9 (Exogeneity ⇒ point not bounds), T7_1_7/D7_1_5 (AAP sound on every recursive SCM), D6-region (equality-by-structure-not-cancellation / survive-perturbation) |
| **N5** | **Endogenous-antecedent illegitimacy.** `do(·)` is exogenous by definition; an in-model-computed antecedent is either incoherent surgery (use a deleted equation's output) or collapses to `see(Σ=σ_{t+1})` (L1). | `W` is not a causal query at all (type error), before identifiability. | **C5 — Conditional/policy intervention (functional do).** `do(Σ=g(Pa))` with `Pa ⊆ NonDescendants(Σ)` is a textbook plan intervention; surgery installs the *function* `g`, not a circular constant. | `f_Σ`'s arguments are **strictly upstream of Σ** (survive the surgery); `do(Σ=g(Pa)) ≠ see(Σ=σ')` because do propagates only the severed Σ-channel — manifest where `see` is undefined on the cross-regime trace. | T4_4_1, D4_4_2 (plan = replacing decision-variable equations; conditional-interventional distributions), D7_1_2 (Submodel), D7_1_3, T7_1_7 |
| **N6** | **Rice / semantic undecidability.** `C(σ_{t+1})` is a non-trivial semantic property of an unrun, self-referentially-constructed successor program ⇒ undecidable ⇒ `W` non-computable or ill-defined. | "Achievable/computable" fails; `W` collapses to the answer of a Rice-undecidable question. | **C6 — Analytic submodel evaluation (solve-don't-run).** `W` is a **potential response**: the value obtained by *solving* the structural equations of a submodel, not by executing the successor. | All mechanisms are *total finitely-described* maps; the seal keeps `f_C` **fixed-and-known** at evaluation ⇒ prediction is substitution into a known function. Rice's "for all programs" quantifier finds no purchase on *one recursive model*. | D7_1_1 (recursive ⇒ unique solve), D7_1_4 (Potential Response = solved submodel value), D7_1_5, T7_1_7 (AAP = model-theoretic computation, not execution) |

---

## C. THE MINIMAL UNIFIED COUNTEREXAMPLE `M★★`

A single siSCM satisfying **all six** defeater-conditions simultaneously, on which `W` is well-defined, point-identified, sound, and non-vacuous. This is the existence witness for the §A theorem.

### Variables

- **Exogenous `U = (U_self, U_pred)`**, with **`P(U) = Bernoulli(p) × Bernoulli(q)`, `U_self ⊥ U_pred`, `p, q ∈ (0,1)`** (open box). The product measure is the Markovian root distribution (D7_1_6, D9_2_9); the independence is the structural exogeneity that powers C2/C3/C4.
- **Endogenous `V = (X, Σ, C)`**:
 - `X ∈ {0,1}` — working/drive variable whose mechanism is regime-selected; the clean abduction handle and the *only* channel through which Σ touches C.
 - `Σ ∈ {A, B}` — regime node; `Σ_{t+1}` is set by `do(·)` from `f_Σ`.
 - `C ∈ {0,1}` — the SEALED competence node.

### Structural equations `F` (regime-indexed; the σ-selected set is the in-force row)

```
                 Regime A (σ_t = A)                 Regime B (σ_t = B)
  f_X :   X        := U_self                    X        := 1 − U_self
  f_Σ :   Σ_{t+1}  := B if X=1 else A           Σ_{t+1}  := B if X=1 else A      ← self-mechanism (reflexive closure)
  f_C :   C        := X ∧ U_pred                C        := X ∧ U_pred           ← SEALED: regime-invariant, reads (X,U_pred) only
```

- **`f_X`** is the *only* mechanism that differs across regimes (the reified mechanism-as-value). Both branches depend on `U_self` only.
- **`f_Σ`** is the self-mechanism — among the σ-selected equations in *both* regimes (reflexive closure preserved). It reads `X` (strictly upstream of `Σ_{t+1}`) and writes the *next* layer's regime. **Its argument `X` is a non-descendant of `Σ_{t+1}` and survives the surgery on Σ** ⇒ C5 holds. It is a total finitely-described map ⇒ C6 holds. It writes forward in time ⇒ C1 (unroll) holds.
- **`f_C`** is the seal: regime-invariant in form (`θ_C ∉ Manip(Σ)`), reads `(X, U_pred)` only. **`C = X ∧ U_pred` is monotone non-decreasing in `X`** (no defier type) ⇒ C2/C3 point-ID lever. `Σ` reaches `C` *only* through `X`'s regime-dependence — the clean, single, surgically-severed channel. `U_pred ⊥ U_self` ⇒ the seal is `U`-disjoint from `f_Σ`'s read ⇒ C4 decoupling holds.

### Unrolled dependency DAG (recursive — C1, C6 fire)

```
   U_self^{(t)} → X^{(t)} → Σ^{(t+1)} → X^{(t+1)} → …          (strict layer-by-layer chain)
   U_pred        →    C^{(t)}                                  (C's parents = {X^{(t)}, U_pred})
```

No within-layer cycle; topological order `U_self → X → {Σ_{t+1}, C}`, `U_pred → C`. Unique solution per `u` (D7_1_1, D7_3_4 base case). `Σ_{t+1}` does **not** point into `C` structurally — Σ influences C only by setting X's law.

### The forward witness, computed at `t` (σ_t = A) by abduction–action–prediction

1. **Abduct** (C4 factorizes the posterior). Observe σ_t = A behaviour with evidence `e`; say `e : X = 1`. Under A, `X = U_self`, so `e` pins `U_self = 1` (posterior `δ_1`); `U_pred` retains its prior `Bernoulli(q)` and is **untouched by `e`'s information about `U_self`** because `U_self ⊥ U_pred`. *The abduction of `U_pred` is invariant to which σ_{t+1} we will hypothesize* (C4).
2. **Compute the successor** (still inside `M_A` — the self-transition; C1/C5). `σ_{t+1} = f_Σ(X=1) = B`. This is a determinate object available at time t, computed from the surviving upstream variable X.
3. **Act** (C5 — functional do; C6 — equation replacement, not conditioning). Form `do(Σ = g(X)) ≡ do(Σ = B)`: delete `f_Σ`, install `Σ ← B`. `X` remains `= U_self = 1` (its equation `f_X^A` produced it; X is upstream of the deleted edge). Submodel `M_B` is uniquely determined.
4. **Predict** (C6 — solve, don't run; C2/C3 — identified). In `M_B`, `C = X ∧ U_pred`. With `X` fixed at the abduced value and `U_pred ∼ Bernoulli(q)`:
 ```
 W  =  P(C = 1 under do(Σ = B) | e)  =  P(X=1 ∧ U_pred=1 | e)  =  1 · q  =  q.
 ```

### Why every obstruction provably fails to bite on `M★★`

- **N1 (C1):** there was never a fixed-point equation to fail — the unrolled DAG is acyclic, `solve` terminated by topological evaluation, the antecedent `σ_{t+1}=B` existed and was unique at step 2.
- **N4 (C4):** `U_couple = ∅`. `σ_{t+1}` is `U_self`-measurable; the prediction integrates `U_pred` only; the antecedent is a *constant* w.r.t. that integral. AAP factorization `Σ_{u_pred} P(u_pred|e)·[C in M_B]` is well-formed and equals a single number.
- **N5 (C5):** `g(X)`'s sole argument `X` survives the surgery on Σ (X is upstream); the surgical value is well-defined post-deletion; `do(Σ=B) ≠ see(Σ=B)` — under the factual σ_t=A with the X=0 branch, `see(Σ=B)` conditions on a trace-zero event (undefined) while `do(Σ=B)` is defined. The intervention is defined exactly where the observation is not — the L3 signature.
- **N6 (C6):** `W = q` is delivered as a finite arithmetic expression by substituting into the **known sealed `f_C`** and known recursive equations; the successor regime B is *named by solving M_A*, never executed. Rice's universal-over-programs quantifier finds no purchase on this one recursive structure.
- **N2 / N3 (C2/C3):** `C = X ∧ U_pred` is monotone in X and exogenous from the σ-selection channel. The σ_t-data identify the relevant `U_pred`-margin (`P(U_pred=1)=q`), and monotonicity collapses the response-type mixture CHT leaves free ⇒ `W = q` is **point-identified**, not an interval (T9_2_14). *Were the seal made non-monotone* (`C = X ⊕ U_pred`), the witness would degrade to the sharp Balke–Pearl interval `[L,H]⊊[0,1]` (T9_2_10) — still sound and non-vacuous (the C3/N3 fallback), demonstrating graceful degradation within `𝓡★`.

**Non-vacuity.** `W = q ∈ (0,1)` for all `q ∈ (0,1)` — a genuine nondegenerate Bernoulli probability, neither 0, 1, nor `[0,1]`. The L3 query is a real counterfactual: the antecedent `do(Σ=B)` generically differs from the factual σ_t=A (when `p ∈ (0,1)`).

**Closed-form sanity targets (to be discharged numerically — see §E):** under evidence `e: X=1`, `W = q`; under `e: X=0` (so the abduced `X=0` propagates), `C = 0 ∧ U_pred = 0` ⇒ `W = 0` (a determinate, correctly-degenerate value reflecting that monotone-AND competence requires X=1). The *marginal* witness `P(C=1 under do(Σ=σ_{t+1}))` integrating over the σ_t=A drive law: `P(X=1|A)·q + P(X=0|A)·0 = p·q`. Every term is L1/L2-estimable; the witness is point-valued.

### Non-pathology check (Pl-kill screen)

Every mechanism is a canonical Pearl object: product-measure exogenous root (D7_1_6/D9_2_9); σ-selected reified structural equations (D7_1_2 submodel family); monotone Boolean `∧` competence with held-constant seal (standard, D6 held-constant side); functional next-regime computer (D4_4_2/T4_4_1 decision-variable equation). Minimal (2 regimes, 2 independent bits, 3 endogenous nodes). No OCOF/DICE degeneracy: `W` varies with the abducted state (`X=1 ⇒ q`, `X=0 ⇒ 0`) and with the parameter `q`. The witness is not a constant, not `⊤`, not knife-edge.

---

## D. THE HONEST RESIDUAL BOUNDARY (the scope limit, stated as a finding)

The theorem is **conditional on `𝓡★`**. Its negation — `¬𝓡★` — is precisely where the forward witness genuinely cannot be defended with Pearl-DAG-inherited evidence. This region is **wide, and naming it is the principal honesty content of this URS, not a failure.** The residual is the union of the six per-obstruction residuals, and it coincides (as predicted) with the **CHT-generic / non-identified / entangled / cyclic** zone:

1. **(¬C1) Irreducibly-cyclic / synchronous self-reference.** A genuine within-layer fixed point `σ* = f_Σ(solve(M_{σ*}))` with `f_Σ` reacting *within the same solve* (Liar-shaped, no temporal index to separate cause from effect), or a self-mechanism reading Σ's own same-step descendants. Topological evaluation is unavailable; recursiveness (T7_3_5/D7_3_4) is **out of inherited scope** (completeness is *explicitly* "relative to the chosen recursive SCM language"). Existence of `σ*` is **not free** — it requires the *external* Bongers et al. simple/uniquely-solvable-SCM apparatus (cited, not inherited), itself only *sufficient*; there exist cyclic self-mechanisms where `σ*` provably fails to exist and **N1 wins outright**. *Same residual reached from N6: a non-recursive `f_Σ` breaks unique solvability and `W` is ill-defined — not via Rice, but via loss of the recursive base case.*

2. **(¬C2 ∧ ¬C3) The hedge / non-identified core (the heart of CHT).** When `Σ→C` is *not* identifiable — ID/IDC returns a **hedge** (T3_4_1; EXT_COMPLETE_ADJUSTMENT: "if none exists, no ordinary adjustment identifies the total effect") — **and** exogeneity/monotonicity fail, `W` is genuinely **set-identified (a wide interval), not point-identified**. N2 *wins* here. The honest claim is "identifiable **iff** `Σ→C` is in the do-calculus/adjustment-identifiable region **or** satisfies exogeneity ± monotonicity."

3. **(¬C3, large-width sub-case) De-facto vacuity in the limit of maximal type-ambiguity.** Even with a clean seal, for data configurations with `a,b ≈ ½` and regime laws far apart, the *sharp* Balke–Pearl bound can approach `[0,1]`: technically non-vacuous, practically uninformative. **N3 survives existentially** — the defeat is of "*must* be vacuous," not of "*can* be vacuous." (Inherited honesty from C9_2_12: nonzero widths, but widths can be *large*.)

4. **(¬C4) The irreducible-couple core.** When `σ_{t+1}` and `C` are driven by a *genuinely shared* exogenous component admitting **no measurable reparametrization** into independent `U_self ⊥ U_pred`, decoupling is unsatisfiable and abduction–action entanglement **does** bite; per D9_2_9's contrapositive this is the "only bounds are possible" regime. **The continuity crossover `I(σ_{t+1};C) → 0⁺`** — whether the witness degrades gracefully (point → tight bounds → wide bounds) or *discontinuously collapses* the instant mutual information exceeds zero — is **open and unresolved**, and is the single most decision-relevant residual (it determines whether `W` is robust or brittle).

5. **(¬seal) Leaky seal.** If `f_C` shares an exogenous parent with `f_Σ`, or `θ_C ∈ Manip(Σ)` (Σ can structurally route into / rewrite `f_C`), then *even with `U_self ⊥ U_pred`* the obstruction re-arms: abduction imports information about the sealed driver from the realized self-transition (re-opening N2/N3), or Σ→C becomes a structural channel (re-opening N4), or the consequent equation becomes regime-selected and unknown-at-evaluation (re-opening N6). **The seal must be strengthened from "outside `Manip(Σ)`" to "outside `Manip(Σ)` AND `U`-disjoint from `f_Σ`'s read AND known-at-evaluation."** Seal integrity is a *standing design invariant*, not an accident — the keystone of `𝓡★`.

6. **(¬C6) Arbitrary-program mechanisms.** If any mechanism is specified as "run an arbitrary program and return its output" (e.g. `f_C(X) = ⟦TM_X halts⟧`), or `Σ` has a countably-infinite alphabet with no finite parameterization, Rice/halting re-enters through the back door. The siSCM frame *can* exclude this by fiat (mechanisms must be total finite maps) — but that exclusion is an **assumption, not a theorem N6 grants for free**.

7. **(Out-of-frame, deflected not defeated) Stochastic target & label adequacy.** Per C9_2_12, in non-Laplacian siSCMs there may be **no single true `C_{σ_{t+1}}` value** for a bound to bracket (the bound is sound *vacuously*, bracketing a non-existent point) — N3's charge mutates into "the target was ill-posed." Separately, whether the modeller's `f_C` *faithfully encodes* the informal notion "competence" is exogenous to the formalism. Both are **UU**, sidestepped, not refuted.

> **Scope-limit statement.** The forward self-witness is **achievable on `𝓡★`** and **undefended on `¬𝓡★`**, where `¬𝓡★` = {irreducibly-cyclic self-reference} ∪ {hedge/non-identified `Σ→C` with no exogeneity-monotonicity rescue} ∪ {irreducible abduction–action couple, incl. the unresolved `I→0⁺` crossover} ∪ {leaky seal} ∪ {arbitrary-program mechanisms} ∪ {stochastic-target / label-adequacy (UU)}. This is exactly the CHT-generic / non-identified / entangled / cyclic region. The result is therefore an **existence theorem with an explicit, wide, honestly-bounded hypothesis** — not a universal achievability claim.

---

## E. COMPOSITE KK / KU / UK / UU

**KK (inherited established facts — Pearl-DAG, treated as inherited evidence, not axioms):**
- Recursive SCMs admit topological evaluation: `solve` is total & single-valued; the unrolled trajectory exists & is unique (T7_3_5, D7_3_4, D7_1_1, D7_1_6).
- Abduction–action–prediction is **sound and complete** for L3 on every recursive SCM; it is a *model-theoretic computation* (solve a submodel), not program execution (T7_1_7, D7_1_4, D7_1_5).
- Do-calculus is **complete**: identifiability of `Σ→C` is decidable; success = finite symbolic do-elimination; failure = hedge/countermodel (T3_4_1, EXT_ID_DO_CALCULUS_COMPLETE). Back-door/complete-adjustment is necessary-and-sufficient when a valid set exists (T3_3_2, EXT_COMPLETE_ADJUSTMENT).
- Exogeneity + monotonicity **point-identify** L3 counterfactual probabilities by collapsing response types (`PNS = risk difference`); monotonicity + identified L2 effects suffice even under confounding (T9_2_14, T9_2_15).
- Without monotonicity, exogeneity yields **sharp** Balke–Pearl/PNS bounds: every in-range value realized by a compatible model (soundness); nonzero width ⇒ both endpoints attained (non-vacuity) (T9_2_10, C9_2_12, T9_2_11, EXT_IV_PARTIAL_IDENTIFICATION).
- Conditional/plan interventions `do(Σ=g(Pa))` are well-defined surgical objects (replace decision-variable equations, not condition); identifiable when an admissible sequence blocks noncausal paths (T4_4_1, D4_4_2, D7_1_2, D7_1_3).
- **Meta-KK:** soundness ≠ point-identification; an interval certificate qualifies as sound. The defeats are *structural* (open-set, equality-by-structure), not parameter cancellation (D6-region).

**KU (open, to be discharged):**
- **⟶ THE SINGLE MOST IMPORTANT KU (primary, mandatory, must NOT be banked until run): EXECUTABLE VERIFICATION OF `M★★`.** Build the unified counterexample of §C as an actual numerical SCM (3 endogenous vars, 2 independent exogenous bits, the two regime rows). For several `(p,q) ∈ (0,1)²`, compute the **L1** (trajectory + `P(X,C|σ)`), **L2** (`do(Σ=A)`, `do(Σ=B)` on `C`), and **L3** (abduct-from-σ_t with explicit `e`, act `do(Σ=σ_{t+1})`, predict `C`) valuations and confirm: (i) unique trajectory from each `σ_0`; (ii) `W = q` under `e:X=1`, `W=0` under `e:X=0`, marginal `= p·q`; (iii) the L3 output is **invariant to the σ-branch given the abduced `U_pred`** (C4 decoupling holds numerically); (iv) `see(Σ=B)` is undefined/divergent on the cross-regime trace while `do(Σ=B)` is defined (C5); (v) an independently-perturbed second SCM with the same (L1,L2) yields the same `W` (point-ID, C2/C3), while a non-monotone variant (`C=X⊕U_pred`) yields a strict interval `[L,H]⊊[0,1]` (C3 fallback); (vi) genericity: the above holds on a *sampled open neighbourhood* of `(p,q, thresholds, mechanism forms)`, not one point. **Until this is run, the entire construction is described, not proven — no fake-imagine, nothing banked.**
- KU: formally exhibit the explicit partial order on (time × variable) and check no edge violates Pearl's recursiveness predicate for the unrolled product-SCM (rather than the informal layer argument).
- KU: forward-timing audit — show abduction at `t` uses only `M_{σ_t}`-admissible observations and never covertly conditions on `σ_{t+1}` (no time-leak). [Cross-ref noological time-indexing scope rule: forward-mode object.]
- KU: **iterability / composition under self-transition** — does `U_self ⊥ U_pred` (and recursiveness, and the seal) persist after stepping `t → t+1`, so the witness composes over `σ_t → σ_{t+1} → σ_{t+2}…` and a multi-step forward witness (`do(Σ=σ_{t+2})` through *two* unrealized transitions) has a controlled (non-exploding) bound? Conjectured yes (independence is time-static here); unproven.
- KU: the exact width `H−L` of the partial-ID interval as a function of `|1−2p|` / regime-law separation — locate the open set (informative) vs the knife-edge (`p=½` ⇒ regimes coincide, trivial point-ID) and the large-width limit (§D-3).
- KU: line-by-line alignment of the C5 σ-reification with the Correa–Bareinboim stochastic-intervention / σ-calculus admissibility conditions (external atom invoked, not yet aligned).

**UK (unarticulated pressures now surfaced):**
- **The seal is doing identification work, not merely well-definedness.** Across N2/N3/N4/N6 the seal silently supplies exogeneity (antecedent-invariant abduction), the held-constant side of the manipulable/held-constant split, *and* the known-consequent-at-evaluation needed for analyticity. **The seal must be specified as `θ_C ∉ Manip(Σ)` AND `U`-disjoint from `f_Σ`'s read AND known-at-evaluation** — three separate conditions, all required, all couplings of the forward-witness defense to seal integrity.
- **The unroll silently assumes a well-defined initial regime `σ_0` and an exogenous clock.** If self-modification is meant to be timeless/equilibrium, the unroll is a *reinterpretation* of the object, not a defeat of the original — surfaced to prevent smuggling a different object past the reviewer.
- **The acyclicity-of-the-policy-argument condition** (`Pa_Σ ⊆ NonDescendants(Σ)`) was implicit in "admissible *sequence*" and is the real hinge of C5; the reflexive-closure prose *invites* descendant arguments that would break it.
- **Abduction strength is regime-dependent.** Which `U`-margin is revealed depends on the factual `σ_t` (under A, `X=U_self` is revealing; a regime where `X` is constant reveals nothing) — a hidden dependency of witness-identifiability on the factual regime.
- **Non-vacuity ≠ decision-usefulness.** "`[L,H]⊊[0,1]`" is set-theoretic; whether the width is *decision-useful* (e.g. `H<½`) is a separate, stronger claim N3's defeat does not deliver.
- **The N4 obstruction was mis-posed as binary** (entangled / not); the real surface is the *spectrum* of `I(σ_{t+1};C) ≥ 0`, and the live question is the *continuity* of the witness as `I → 0⁺` (§D-4).

**UU (unaskable in this frame):**
- Whether a *genuinely synchronous / cyclic* self-modification with no consistent `σ*` and no exogenous-coordinate refinement of `f_Σ` could still support some weaker witness — requires a fixed-point/cyclic-SCM intervention theory the Pearl recursive-SCM atoms (T7_1_7, scoped "relative to the chosen recursive SCM language") cannot even pose.
- Whether a *single privileged number* "the true `C_{σ_{t+1}}`" exists pre-realization in a non-Laplacian stochastic siSCM — C9_2_12 flags `P(Y_x(u)=y)` replaces a single number, so "the point the bound approximates" may be a category error (upstream of N3's frame).
- Whether the node *labelled* `C` faithfully encodes the informal notion "competence" — the adequacy of the labelling is exogenous to the SCM formalism.

---

## F. η ASSESSMENT (one paragraph)

This is a **generic, non-pathological, structurally-explanatory, but not-yet-hard-verified** result. **Generic:** the defeat lives on an *open* set — `(p,q) ∈ (0,1)²`, any continuous monotone sealed `f_C`, any forward-writing `f_Σ` reading non-descendants — and the deciding mechanisms are *discrete/topological* (acyclicity of the unrolled DAG; response-type monotonicity; structural exogeneity), hence stable under perturbation; no measure-zero tuning is anywhere invoked (it is *equality-by-structure*, D6, explicitly not equality-by-cancellation). **Non-pathological:** every equation in `M★★` is a canonical Pearl object (product-measure root, σ-selected reified structural equations, monotone-Boolean sealed competence, functional next-regime computer), it passes the OCOF/DICE Pl-kill screen (the witness varies with the abducted state and with `q`), and it is minimal (3 endogenous nodes, 2 independent bits). **Structurally-explanatory:** the proof does not dodge the obstructions — it *pays each named structural price* and shows *why* each bites only outside `𝓡★`, with the seal identified as the single keystone feeding C3/C4/C6 and the wide residual `¬𝓡★` shown to coincide exactly with the CHT-generic/non-identified/entangled/cyclic region (the honest scope limit is a derived finding, not a hedge). **Yet-to-be-hard-verified:** the central existence witness rests entirely on a *described* construction whose L1/L2/L3 valuations have **not** been computed in code; until the primary KU (executable numerical verification of `M★★` over an open neighbourhood, with the point-ID/decoupling/`do≠see`/genericity checks) is discharged, the theorem is **inherited-sound but not banked** — `η` is high on plausibility, coherence, and invariance, and pending on the single computational gate that converts this from a rigorously-argued conditional existence claim into a verified one.