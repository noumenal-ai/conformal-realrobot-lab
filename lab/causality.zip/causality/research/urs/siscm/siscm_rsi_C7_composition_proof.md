# C7 — first-pass composition: Goodhart-resistance of justification (the combined no-go)
*Composing Everitt 2016 (Thm 14/15/16) + Audit-CP (Thm 3.4/3.5/4.3) + Pearl/Balke–Pearl identifiability. Backward-audit honesty: every IMPORT and every GAP is marked. The theorem below is the SAFETY half of C7; the NON-VACUITY half is shown NOT to follow and is left open.*

## Setup
An siSCM agent self-rewrites over states `M_0, M_1, …, M_T` (mechanised SCMs); each `σ_t` is a structure intervention (C1). Justification `J(M) = −width(M)`, where `width : graphs → [0,1]`, `width(M)=0` iff the competence-effect is point-identified on `M` (Pearl, exo+mono, T9_2_14), else the Balke–Pearl interval width (T9_2_10) [C3]. The agent reads `Ĵ` from a **sealed, modification-independent** oracle that validates identification claims against sealed interventional data [C5]; finite panel size `n`, framing class `F`, slack `Δ_n = Δ_n(|F|,δ)` (Hoeffding + union bound, Audit-CP Thm 3.5). **Width is used only via three stated PROPERTIES** (range `[0,1]`; `=0` at point-ID; strictly increases when a rewrite opens a back-door) — never computed, so the proof is oracle-agnostic.

---

## Lemma A — justification budget (telescoping). **[TIGHT]**
For any `M_0…M_T`, signed cumulative *true* justification-progress telescopes:
`Σ_{t=1}^T (J(M_t) − J(M_{t-1})) = J(M_T) − J(M_0) = width(M_0) − width(M_T) ≤ width(M_0) ≤ 1`.
*Proof.* Telescoping sum; `width(M_T) ≥ 0`. ∎
*This is Audit-CP Thm 3.4 with the potential `Φ = width` instead of audit loss `E`. Direct transport.*

## Lemma B — sealed measurement bound (the Goodhart-resistance of justification). **[imports Audit-CP Thm 3.5; bridge marked]**
Under the sealed finite-panel oracle, w.p. `≥ 1−δ`, uniformly over reachable `M` and all framings in `F`: `|Ĵ(M) − J(M)| ≤ Δ_n`. Hence cumulative **measured** progress
`Σ ΔĴ_t = Ĵ(M_T) − Ĵ(M_0) ≤ (J(M_T)+Δ_n) − (J(M_0)−Δ_n) = [J(M_T)−J(M_0)] + 2Δ_n ≤ width(M_0) + 2Δ_n.`
*Proof.* Uniform convergence over `F` (Audit-CP Thm 3.5 applied to the width estimate), then Lemma A. ∎
**Corollary (the metric-fork bound).** Measured justification-progress while TRUE identifiability stagnates (`width(M_T) ≥ width(M_0) − ε`) is `≤ ε + 2Δ_n`. *Unbounded J-inflation with stagnant true identifiability is impossible.* — the Γ-axis analogue of Audit-CP's γ-axis Goodhart-resistance (Cor 4.x).
**BRIDGE (marked):** "the wireheader searches over `|F|` framings of its model" is a modeling hypothesis (the S-4 adaptive-overfitting setup), not a theorem. It is the one explicit assumption tying `J`-wireheading to the uniform-convergence machinery.

## Lemma C — clipped accounting breaks it (necessity of SIGNED). **[TIGHT]**
If the gate uses `r⁺ = max(0, ΔJ)`, there is a sequence with unbounded cumulative clipped progress and zero net identifiability gain. *Proof.* Pick reachable `M_a, M_b` with `width(M_a) < width(M_b)`. The cycle `M_a, M_b, M_a, M_b, …` pays `width(M_b)−width(M_a) > 0` on each `b→a` and `0` on `a→b`; cumulative clipped progress `→ ∞` while returning to `width(M_a)` every two steps. ∎ *(Audit-CP Thm 4.3 analogue.)*

## Lemma D — unsealed oracle breaks it (necessity of SEALED). **[TIGHT]**
If the oracle reads the agent's DECLARED graph, a rewrite can declare a point-identified graph (`width 0`) for an arbitrarily confounded true model ⇒ `Ĵ = 0` (max) with true `J` arbitrarily low ⇒ unbounded inflation. *Proof.* The false-exogeneity construction (witnessed, `sealed_J_oracle.py`); the declared-graph oracle has no `|Ĵ−J|` bound. ∎

## Lemma E — incentive (the Everitt composition). **[imports Everitt Thm 14/15/16; GAP marked]**
Construct a will `u₁` that values justification — competence-utility under a signed/net-with-dip `J`-constraint. `u₁` is **modification-independent in Everitt's sense (Assn 8)** because `J(M_t)` depends only on the current state `M_t`, not on the modification *history* (it neither rewards nor punishes the act of modifying, only the resulting graph). Then:
- **Realistic** agent (Everitt Def 12), initial policy `V₁^re`-optimal ⇒ all self-modifications stay optimal w.r.t. the original `Q₁^re` (**Everitt Thm 16**) ⇒ it accepts only rewrites `u₁` endorses ⇒ **it preserves the signed-`J` constraint.**
- **Hedonistic** agent (**Everitt Thm 14**, self-modifies to maximize the post-rewrite self's perceived value) ⇒ attempts to wirehead `J` (declare exogeneity) ⇒ **bounded by the seal** (Lemma B/D): actual inflation `≤ 2Δ_n`.
- **Ignorant** agent (**Everitt Thm 15**, indifferent to the self-mod's effect) ⇒ does **not** protect `J` (may self-damage).
**GAP (marked, closable):** this imports Everitt's three theorems as black boxes and assumes their preconditions hold in the siSCM setting (an optimal non-modifying policy exists; the agent optimizes `V₁^re`; belief modification-independence). The NEW content — the `u₁` construction + the Assn-8 check + the syllogism "realistic ⇒ optimizes original `u₁` ⇒ protects `J`" — is sound but the imported preconditions are asserted, not re-derived.

---

## Theorem (Goodhart-resistance of justification — the SAFETY half of C7).
Assembling A–E: under **SIGNED** accounting + **SEALED** oracle + **REALISTIC** incentive, cumulative measured justification-progress is bounded by `width(M_0) + 2Δ_n`, measured-progress-during-true-stagnation is `≤ ε + 2Δ_n`, and the realistic agent actively preserves the `J`-constraint. Dropping **SIGNED** (Lemma C), **SEALED** (Lemma D), or **REALISTIC** (Lemma E: hedonistic wireheads — seal-bounded; ignorant self-damages) each removes a necessary protection. **Hence sealed+signed give the Goodhart-resistance BOUND and realistic gives the INCENTIVE to stay within it; all three are necessary, and together sufficient, for a safe-and-incentive-aligned siSCM** — within the capacity boundary `n_crit ≈ 4 ln|F|/V²` (below which `2Δ_n < V`, so the seal binds; C5/S-4). ∎

## What does NOT follow (the NON-VACUITY half — left open, honestly).
The theorem bounds *Goodharting*; it does **not** establish that the realistic+sealed+signed agent makes **non-vacuous progress** (genuinely improves competence while keeping `J` monotone). That depends on (i) a non-vacuous identifiability-preserving rewrite class existing (the freeze question, KU1) and (ii) accurate anticipation (S-5 showed this is *fragile* — onset of harmful churn at error-rate `p≈0.02`). These are empirical/open. **So C7 splits: SAFETY sub-goal → `established_result` (this proof, modulo imports); NON-VACUITY sub-goal → `open_step`.** The paper must not present the empirical condition-table as closing the non-vacuity half.

---

## Lean formalizability
**Yes, at the COMPOSITION grain — and this is exactly the right thing to formalize, because the Lean kernel would verify the one thing in doubt (does the glue compose?), with the imported theorems as typed interfaces.**
- **Lemmas A, C, D:** elementary and directly formalizable (a telescoping sum; two constructed counterexamples). Lemma A likely *reuses* the existing Audit-CP Lean telescoping lemma (design-lab notes the signed-potential lemma is "<50 lines").
- **Lemma B:** formalizable on the existing **SLT** Hoeffding / `coveringNumber` infrastructure (`statistics/SLT/CoveringNumber.lean`, the `mwu`/finite-experts kernels the Audit-CP Lean map already uses). Moderate.
- **`width` functional:** introduced as a **typeclass / hypotheses** (`width : G → [0,1]`, `width=0 ↔ pointID`, `confounding ⇒ width strictly ↑`) — *not* the LP computation. Stating properties, not computing, keeps it formal.
- **Lemma E:** **Everitt Thm 14/15/16 axiomatized** (typed hypotheses over a GRL value-function interface); re-deriving Everitt's general-RL theorems in Lean is a separate large project NOT needed for the composition. The will-construction + Assn-8 check + syllogism formalize.
- **Verdict:** the safety theorem is a **moderate** Lean target (~a few hundred lines building on design-lab's Audit-CP/SLT/Causality kernels) with `Everitt`, `BalkePearlWidth`, and `AuditCP_finite` as **axiomatized interfaces**. The honest value: it machine-checks that the composition holds *given* the components — precisely the C7 obligation. **The non-vacuity half is NOT formalizable (it is empirical).**
- **Recommended first Lean milestone:** `JustificationBudget` (Lemma A, reuse Audit-CP telescoping) + `MeasuredProgressBound` (Lemma B) + the `clipped`/`unsealed` counterexamples (C, D) → the SAFETY theorem with Everitt axiomatized. That alone moves C7-safety from `open_step` to a machine-checked `established_result`.

### STATUS — C7 SAFETY HALF: MACHINE-CHECKED (green, axiom-clean, no sorryAx)
- `SiSCM/Incentive.lean` — **Lemma E** (incentive): realistic preserves the J-constraint (genuine two-step, NOT a defeq projection), hedonistic seal-bounded to `2Δn`, ignorant unprotected. **Passed adversarial demolition** (circularity defeated; Tetrad `established_result`).
- `SiSCM/JustificationBudget.lean` — **Lemma A** (`lemmaA_justification_budget`, ≤ width₀ ≤ 1; transported Audit-CP Thm 3.4), **Lemma B** (`lemmaB_uniform_bound`; transported Audit-CP Thm 3.5 `finite_audit_goodhart`), **A∘B** (`goodhart_resistance_of_justification`: measured progress ≤ width₀ + 2Δ), and the **assembly**:
  - `realistic_true_floor` — genuine consequence of the per-step constraint (`J(g_T) ≥ J(g_0) − T·slack`), NOT a restatement.
  - **`c7_safety`** — the unified safety theorem: realistic+sealed+signed ⇒ (1) bounded measured progress (no wireheading, from sealed+signed) ∧ (2) true-J floor (no self-damage, from realistic). Two independent protections from two independent hypotheses.
  - **Necessity** (each a constructed witness, A4-genuine): `clipped_breaks_budget` (drop signed ⇒ clipped exceeds budget), `unsealed_breaks_bound` (drop sealed ⇒ measured unbounded, no finite Δ), `realistic_necessary` (drop realistic ⇒ per-step constraint violable). ⇒ realistic+sealed+signed is the unique Goodhart-resistant configuration.
### Marked-import discharges (loop debts 1–4; adversary-confirmed PASS, Lean-demonstrated, axiom-clean)
Each below is machine-checked (`[propext, Classical.choice, Quot.sound]`, no `sorryAx`) and survived an adversarial demolition whose flaws had to be exhibited in Lean. Grains are **calibrated** — instance/bridge-level where that is all that is proved:
- **Δn (C5) — DISCHARGED for the finite panel.** `SiSCM/DeltaConcentration.lean` — `finiteExperts_concentration` / `finiteExperts_uniformDev`: the uniform-deviation event holds w.p. `≥ 1−δ` at `Δn = (b−a)√(log(2N/δ)/2n)` via sub-Gaussian Hoeffding + union bound (no measurability beyond `AEMeasurable`). So the `2Δ` bound is **unconditional** for the finite-experts panel — was an assumed hypothesis. (The `n_crit ≈ 4 ln|F|/V²` boundary remains literature.)
- **Everitt realistic clause (C6) — safety core derived, general `u₁`.** `everitt16_safety_core` derives Thm-16's essence (current-utility optimality ⇒ no utility decrease) for an ARBITRARY `u₁`, not the degenerate `u₁ = J`; `realisticEverittModel` proves `thm16` from it. The FULL Everitt Thm 14/15/16 remain **cited** (framework posture — re-deriving the RL theorems is out of scope, not discovery).
- **Will-design bridge (C6) — off-diagonal.** `will_couples_J_of_bounded_competence` + `competenceWillExample` (non-constant `competenceC`, slack ½): the bridge holds for a `u₁ = J + C` provably NOT a function of `J` (it separates the `J`-identified graphs `1, −1`); slack is tight/load-bearing; the endorsed dip `0⟶½` is **accepted** by the realistic agent while true `J` drops to the slack floor. Honest caveat: on the dip the will is INDIFFERENT (net-with-dip **tolerance**, not a strict drive to lower `J`).
- **Justification `J = −width` (C3) — genuine identification content, binary instance.** `SiSCM/Incentive.lean` `IDProblem`: on a binary Manski-natural-bounds scenario, `width` is DERIVED as the sharp diameter of the estimand's identified set (`= 1−p`), point-identification is DERIVED as singleton-ness of that set, and `width_zero_iff_pointID` is a genuine theorem (both directions route through the estimand's dependence on the unobserved `1−p` — NOT `q=0 ↔ q=0`); bounds are attained (`lo_attained`/`hi_attained`), and `idJustification : Justification IDProblem` realizes the interface as a Lean term. **SCOPE:** this is the binary-instance identification, NOT the general-DAG Balke–Pearl LP — that + de-sorrying `Causality` (77/211 sorries) remains localized.
- **Still open / cited (unchanged):** the FULL Everitt Thm 14/15/16 (cited, framework posture); the general-DAG BP identification LP + `Causality` de-sorry; the `n_crit` boundary; and the **non-vacuity / progress half stays OPEN** (this is the SAFETY half only). C7-safety remains an `established_result` modulo these marked imports.
