# Appendix — Per-Obstruction Discovery URSs (N1–N6)

Companion to total_discovery_urs_siscm_forward_witness.md. Six per-obstruction defeats, one per negative subargument, each grounded in audited Pearl atoms.


==================================================================
## Obstruction index 0
==================================================================

All four nodes share the same Pearl-family inheritance audit, with T7_3_5 (Recursive Completeness) carrying the load-bearing result. I have the grounding I need. The defeat is well-supported: **recursiveness** is a named structural condition in the canonical SCM language, and under it the abduction-action-prediction semantics is sound and complete, with trajectory existence/uniqueness following from the recursive (acyclic) ordering.

# Per-Obstruction Discovery URS — N1: Fixed-Point Non-Existence

**Object under defense:** the forward self-witness `W ≡ C^{do(Σ = σ_{t+1})}` evaluated at time `t` (before `σ_{t+1}` is realized) via abduction–action–prediction on the siSCM `M_{σ_t}`.
**Grounding atoms:** T7_3_5 (Recursive Completeness), D7_3_4 (Recursiveness), D7_1_1 (Causal Model), D7_1_6 (Probabilistic Causal Model) — Pearl 2009 §7; Galles–Pearl 1998; Halpern 1998.

---

## 1. The obstruction (stated precisely)

N1 attacks the **existence of the reflexive object itself**, prior to any identifiability question. The self-mechanism demands a self-consistent regime

```
σ*  =  f_Σ( solve( M_{σ*} ) )                                    (FP)
```

where `solve(M_{σ*})` is the unique solution of the structural equations *that σ\* itself selects*. The map `σ ↦ f_Σ(solve(M_σ))` is a self-referential operator on regime space `𝒮`: its argument `M_σ` is defined only once `σ` is fixed, and `f_Σ` is among the σ-selected mechanisms (reflexive closure). If (FP) has **no fixed point**, then:

- there is no well-defined "next regime," so `do(Σ = σ_{t+1})` has no argument to bind;
- the transition kernel `M_{σ_t} → σ_{t+1} → M_{σ_{t+1}}` is undefined;
- consequently the antecedent of the L3 counterfactual `C^{do(Σ=σ_{t+1})}` is empty, and **there is literally nothing to witness**. The forward witness is not merely unidentifiable — it is *ill-typed*.

This bites in exactly the regime where `f_Σ` is allowed to react to the very solution its own choice induces (a Liar-shaped self-reference on `𝒮`), the structural analogue of `g(x) = ¬x` having no fixed point. **This is the genuinely-cyclic reading of self-reference, where σ\* sits inside its own solved model.**

---

## 2. The defeater condition (named, Pearl-grounded)

**Defeater condition — RECURSIVENESS (acyclicity of the unrolled siSCM).**

The fixed-point framing (FP) is **not the only reading** of the self-mechanism, and it is not the reading Pearl's machinery operates on. The canonical SCM language is **recursive**: there exists a partial order on variables such that each `V_i` is a function only of its predecessors and exogenous `U`. Under recursiveness, "solve" is not a fixed-point search at all — it is *evaluation in topological order*, which **always terminates in a unique value** (T7_3_5 establishes this is the regime where the abduction–action–prediction semantics is *complete*, hence well-defined).

The defeat: **read the siSCM in its time-unrolled (trajectory) form, not its time-collapsed (self-consistent) form.** Replace the collapsed self-reference `σ* = f_Σ(solve(M_{σ*}))` with the **indexed recurrence**

```
σ_{t+1}  =  f_Σ( solve( M_{σ_t} ) )                              (UNROLL)
```

Here `f_Σ` is computed inside `M_{σ_t}` (it IS σ_t-selected — reflexive closure preserved), but it writes the *next* regime, consumed only after a `do(·)`. The self-reference is across a time index, not within a single solve. The unrolled object `M_{σ_0} → M_{σ_1} → …` is a single recursive SCM over the product space (time × variables): the edge `f_Σ` at layer `t` points only into layer `t+1`, so the composite carries no within-layer cycle and **inherits recursiveness**.

> **Grounding quote (T7_3_5, current_literature_audit.correct_argument):**
> *"In an SCM, a counterfactual is evaluated by first abducing a posterior over exogenous variables from observations, then replacing equations for intervened variables, then predicting in the modified model. Soundness follows because each axiom is valid in every recursive SCM under this semantics. Completeness follows by canonical-model construction: if a formula is not derivable, construct a recursive structural model satisfying the axioms but falsifying the formula."*

> **Scope discipline (T7_3_5, corrected_or_extended_statement):**
> *"Specify that completeness is relative to the chosen recursive SCM language and axioms, not an all-purpose solution to every counterfactual identification problem."*

So: the named structural condition is **recursiveness** (D7_3_4, retained as *"the Pearl-2009 base case"*); under it, "solve" is total and single-valued by topological evaluation, the unrolled trajectory `{σ_t}` **exists and is unique** for every initial `σ_0`, and — because abduction–action–prediction is exactly the L3 procedure T7_3_5 certifies sound on recursive models — the forward witness `C^{do(Σ=σ_{t+1})}` is well-typed: its antecedent `σ_{t+1} = f_Σ(solve(M_{σ_t}))` is a determinate object available at time `t`.

The base nodes carry the typed semantics this stands on: D7_1_1 (Causal Model — the `⟨U,V,F⟩` substrate), D7_1_6 (Probabilistic Causal Model — `P(U)` making L1/L2/L3 valuations *probabilistic*, required for "abduct U from behaviour"). Each is *prerequisite inheritance*, not an independent theorem (per their audits).

**The genuinely-cyclic case is conceded to be external:** a true within-layer fixed point requires Bongers et al. (simple / uniquely-solvable SCMs) for existence — cited, not inherited from the Pearl DAG. The in-DAG defeat is purchased **acyclically**, by the unroll.

---

## 3. The counterexample-to-the-obstruction (minimal, non-pathological siSCM)

A 2-regime siSCM in which (FP)'s pathological reading is dissolved and the forward witness provably survives. Every mechanism is a Pearl-canonical structural equation (deterministic function of parents + exogenous noise), so non-pathology holds by construction.

**Regimes.** `𝒮 = {A, B}` (two equation-sets in force).

**Endogenous variables.** `V = {X, Σ, C}`.
- `X` — a working variable whose mechanism is regime-dependent.
- `Σ ∈ {A,B}` — the regime node (its value at layer `t+1` is set by `do(·)` from `f_Σ`).
- `C` — the **sealed competence node**.

**Exogenous variables.** `U = {U_X, U_C}`, with
**P(U):** `U_X ~ Bernoulli(p)`, `0 < p < 1`; `U_C ~ Bernoulli(q)`, `0 < q < 1`; independent.
(Open set: the defeat holds for *all* `p,q ∈ (0,1)` — see §5 genericity. `P(U)` is what makes the model a Probabilistic Causal Model, D7_1_6, so abduction is defined.)

**Structural equations `F` (regime-indexed; `f_Σ` and `f_C` written once, both regime-stable except where noted):**

Regime A (σ_t = A):
```
X        := U_X                                  (f_X^A)
Σ_{t+1}  := B  if X = 1  else A                  (f_Σ)   ← self-mechanism, A-selected, reflexive closure
C        := U_C                                  (f_C)   ← SEALED: not a function of Σ, X, or any σ-selected eqn
```

Regime B (σ_t = B):
```
X        := 1 - U_X                              (f_X^B)   ← only X's mechanism differs across regimes
Σ_{t+1}  := B  if X = 1  else A                  (f_Σ)   ← same self-mechanism, now B-selected
C        := U_C                                  (f_C)   ← same seal
```

**The single structural feature that does the defeating:** `f_Σ` writes `Σ_{t+1}` (the *next* layer's regime), and is read only after `do(Σ := Σ_{t+1})`. **No equation in either regime makes `Σ_t` a function of anything computed at layer `t`'s own solve that in turn depends on `Σ_t`.** The dependency graph of the unrolled model is `U_X^{(t)} → X^{(t)} → Σ^{(t+1)} → X^{(t+1)} → …`, a strict layer-by-layer DAG. **There is no within-layer cycle to seek a fixed point of** — recursiveness (D7_3_4) holds, so `solve` is topological evaluation and the trajectory is unique. *This is the feature; everything else is scaffolding.*

**Seal feature (independently load-bearing for the witness, not for N1):** `f_C` reads only `U_C`, which lies **outside Σ's manipulable set**. Thus `C^{do(Σ=σ_{t+1})} = U_C` is invariant to the abducted-then-acted regime — the witness valuation is stable and the abduction step (recover `P(U_C | behaviour)`) is well-posed.

**Forward-witness evaluation (the L3 query, run at `t` with `σ_t = A`):**
1. **Abduct.** Observe layer-`t` behaviour; update `P(U_X), P(U_C)` → posteriors. (E.g. observing `X=1` forces `U_X=1` in regime A.)
2. **Act.** `f_Σ` computes `σ_{t+1} = B` (since `X=1`). Set antecedent `do(Σ := B)`.
3. **Predict.** Evaluate `C` in `M_B`: `C = U_C`. The witness `W = C^{do(Σ=B)}` is the posterior of `U_C` — **determinate, non-vacuous** (`0<q<1` ⇒ `W` is a genuine nondegenerate Bernoulli, not a trivial constant).

The antecedent `σ_{t+1}` existed and was unique **at step 2, before σ_{t+1} was realized**, because `solve(M_A)` terminated by topological evaluation. N1 does not bite: there was never a fixed-point equation to fail to solve. The obstruction's pathological reading (FP with `f_Σ` inside its own solve) is simply **not the structure of this siSCM**.

---

## 4. KK / KU / UK / UU for N1

**KK (inherited established facts):**
- Recursive SCMs admit topological evaluation: `solve` is total and single-valued; trajectory exists & is unique (T7_3_5; D7_3_4 as base case).
- Abduction–action–prediction is **sound and complete** for L3 on recursive models (T7_3_5, Galles–Pearl 1998, Halpern 1998) — so a well-typed L3 query *has* a determinate answer.
- `⟨U,V,F⟩` + `P(U)` (D7_1_1, D7_1_6) supply the typed substrate making "abduct U" a defined probabilistic operation.
- Composition + effectiveness + recursiveness are *complete* for the structural-counterfactual language (T7_3_5) — the axioms governing the witness query are fully characterized.

**KU (open, to be discharged):**
- **[Executable-verification KU — primary]** Build the §3 siSCM as an actual object and **compute L1/L2/L3 valuations numerically** for chosen `(p,q)`: confirm (a) unique trajectory from each `σ_0`, (b) `W = C^{do(Σ=B)}` returns the `U_C`-posterior, (c) non-degeneracy of `W`. *Not yet done — the construction above is described, not banked.* No fake-imagine.
- KU: confirm the unrolled product-SCM formally satisfies Pearl's recursiveness predicate (exhibit the explicit partial order on (time×variable) and check no edge violates it) rather than relying on the informal layer argument.
- KU: the *forward* (pre-realization) timing — show abduction at `t` uses only `M_{σ_t}`-admissible observations and never covertly conditions on `σ_{t+1}` (no time-leak). [Cross-ref noological time-indexing scope rule: forward-mode object.]

**UK (unarticulated pressure now surfaced):**
- The unroll **silently assumes a well-defined initial regime `σ_0`** *and* an exogenous clock. If "self-modification" is meant to be *timeless/equilibrium*, the unroll is a **reinterpretation** of the object, not a defeat of the original — surfacing this prevents smuggling a different object past the reviewer.
- Recursiveness is assumed to **persist across regimes**: each `F_σ` is individually acyclic *and* no regime introduces an edge that, composed across the `f_Σ` hand-off, closes a cycle. The counterexample secures this (only `f_X` varies), but the *general* siSCM does not get it for free — it is a standing proof obligation on `f_Σ`.

**UU (unaskable in this frame):**
- Whether a *genuinely cyclic* (non-unrollable, equilibrium) self-modification with no consistent `σ*` could *still* support some weaker witness — unaskable acyclically; it requires the Bongers et al. solvability apparatus, which lives **outside** the Pearl DAG and outside N1's acyclic remit.

---

## 5. Pl / Coh / Inv / Comp typing of the counterexample

- **Pl (Plausibility / non-triviality):** **High, non-trivial.** Every mechanism is a canonical structural equation; `f_C`'s seal and `f_Σ`'s next-layer write are *structural* features, not parameter tricks. The witness is **non-vacuous** (`W` is a nondegenerate Bernoulli for `q∈(0,1)`); it does not collapse to a constant or to `⊤`. Passes the Pl-kill screen (no OCOF/DICE degeneracy: the answer varies with the abducted state).
- **Coh (Coherence / composition):** **Composes.** The unrolled model is itself a recursive SCM, so it **re-enters the same Pearl machinery** at the next step — the defeat is closed under iteration (`σ_t → σ_{t+1} → σ_{t+2} …` all well-typed). The seal composes with abduction (the witness query is stable under the do-substitution). No new axiom is needed beyond the inherited complete set.
- **Inv (Invariance / genericity — OPEN SET):** **Generic, not knife-edge.** The defeat holds for **all** `(p,q) ∈ (0,1)²` — a full-measure open box — and for *any* initial `σ_0 ∈ {A,B}`. The defeating feature is **discrete/topological** (acyclicity of the layer graph), so it is *structurally stable*: small perturbations of the mechanisms or noise law cannot destroy acyclicity. **No measure-zero tuning is involved.** (Contrast: a true fixed-point existence claim *would* be parameter-sensitive — which is exactly why we route through the unroll instead.)
- **Comp (Completeness — fraction of N1 covered):** **Partial, honestly bounded.** Covers the entire **acyclic / unrollable** sub-case of N1 — i.e. every siSCM whose self-mechanism writes forward in time and whose per-regime equation sets are recursive. This is the dominant and arguably the *intended* reading of "self-modification as a process." **Does not cover** the genuinely-cyclic equilibrium sub-case (→ §6). Estimated coverage of N1's threat surface: the unrollable fragment in full; the irreducibly-cyclic fragment not at all.

---

## 6. Residual — the honest boundary

**Uncovered sub-case: irreducible within-layer self-reference (the genuine fixed point).**

If the siSCM is **not unrollable** — i.e. `σ*` is *defined* to be a solution of `σ* = f_Σ(solve(M_{σ*}))` with `f_Σ` reacting *within the same solve* to the regime it selects (no time index to separate cause from effect), and this self-reference is **Liar-shaped** (e.g. `f_Σ` selects A iff solving `M_B` is consistent, and B iff `M_A`) — then the unroll is unavailable and recursiveness **cannot be invoked**. Topological evaluation requires an acyclic order that this object, by construction, denies.

In that fragment:
- The Pearl DAG atoms (T7_3_5 / D7_3_4) are **silent**: their completeness is *explicitly* "relative to the chosen **recursive** SCM language" (corrected_or_extended_statement) — a non-recursive object is **out of inherited scope**. Inheriting them here would over-claim beyond what the atom supports.
- Existence of `σ*` is **not free**; it requires the *external* apparatus — **Bongers et al. (simple / uniquely-solvable SCMs)** — which gives unique solvability for a restricted cyclic class. This is **cited, not inherited**, and is itself only a *sufficient* condition: there exist cyclic self-mechanisms (the Liar construction above) that are provably **not** uniquely solvable, where `σ*` genuinely **fails to exist** and **N1 wins outright on that object**.

**Therefore the boundary is:** N1 is defeated **iff** the siSCM's self-mechanism is **forward-in-time (unrollable), making the composite recursive** — under which the trajectory exists/is-unique and the forward witness is well-typed and sound (T7_3_5). N1 **survives** on irreducibly-cyclic, non-uniquely-solvable self-modification, which is not addressable with Pearl-DAG-inherited evidence and is **logged as the open frontier** (requires either an external solvability theorem or an explicit restriction of the siSCM class to the unrollable fragment — a design choice, not a proof).

---

**Files referenced:**
- Grounding atoms: `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/causality/pearl_inheritance_dag_current_literature_audited.json` — nodes `T7_3_5`, `D7_3_4`, `D7_1_1`, `D7_1_6`.

==================================================================
## Obstruction index 1
==================================================================

I now have all six atoms with their audited content. I have what I need to produce the URS.

The key grounding extracted:
- **T3_4_1** (do-calculus, A+): three rules sound; completeness via ID/IDC — if effect identifiable, finite symbolic derivation eliminates do-operators; failure yields hedge/countermodel.
- **EXT_ID_DO_CALCULUS_COMPLETE** (A+): ID/IDC decomposes c-components; successful identification = finite sound symbolic derivation.
- **T3_3_2** (back-door, A): valid back-door set blocks every noncausal path, no forbidden descendants; conditioning + summing reconstructs intervention distribution.
- **EXT_COMPLETE_ADJUSTMENT** (A+): complete generalized adjustment criterion is necessary-and-sufficient; remove forbidden descendants on causal paths, block all proper noncausal paths.
- **T9_2_14** (A-): exogeneity + monotonicity → PN/PS/PNS point-identified; PNS = risk difference P(y|x)−P(y|x'). The crucial bridge: monotonicity *collapses response-type categories*, converting L3 counterfactual bounds into point identification. Without it, distinct SCMs agree on L1/L2 but disagree on counterfactual type mixtures.
- **T9_2_15** (A-): monotonicity + identifiable effects P(y_x), P(y_x') → PN/PS/PNS identifiable even under confounding (not requiring exogeneity).

Now the URS.

---

# PER-OBSTRUCTION DISCOVERY URS — N2: Witness non-identifiability (CHT / L3 non-collapse)

**Object:** siSCM `M=⟨U,V,F,P(U)⟩` with regime node `Σ`, endogenous self-mechanism `f_Σ:(V,U)→σ'` (reflexive closure), sealed competence `C=f_C(·)` with `f_C ∉ manip(Σ)`. **Forward self-witness** `W := C under do(Σ=σ_{t+1})`, evaluated *before* `σ_{t+1}` is realized, by abduction–action–prediction on `M_{σ_t}`. N2 attacks the *identifiability* leg of {well-defined, identifiable, sound, non-vacuous}.

---

## 1. The obstruction, stated precisely

`W` is a **layer-3 (counterfactual) quantity**: it asks for the value of `C` in the submodel `do(Σ=σ_{t+1})` while the *factual* regime is still `σ_t` and `σ_{t+1}` has not been realized. The antecedent `Σ=σ_{t+1}` is, at evaluation time, *contrary to the realized trajectory* (the system is in `σ_t`; the cross-world query fixes `Σ` to the not-yet-actual successor). By the **Causal Hierarchy Theorem (CHT)**, L3 quantities are *generically* non-identified from any amount of L1 (observational trajectory) + L2 (interventional `do(Σ=·)` response) data: the map from SCMs to their (L1,L2) signatures is many-to-one, and distinct preimages disagree on L3. Concretely, distinct siSCMs can agree on every observable regime-transition trajectory and every interventional `do(Σ=σ)` outcome of `C`, yet disagree on the *cross-world joint* `(U-abduction-from-σ_t, C-under-σ_{t+1})` — i.e. on the **counterfactual type-mixture** over `U`. If that mixture is free, `W` is set-identified at best (an interval), not point-identified, so "the witness is identifiable" fails and the forward witness collapses to a bound.

Why this *defeats* the witness if unaddressed: abduction–action–prediction requires recovering enough of the posterior `P(U | M_{σ_t}-behaviour)` to predict `C` in the surgically-altered submodel. If the realized `σ_t`-behaviour underdetermines the `U`-margins that `f_C` reads off under `σ_{t+1}`, the prediction is non-unique — the forward witness names an *interval*, and N2 wins on "not identifiable."

---

## 2. The DEFEATER CONDITION (named structural condition + Pearl-atom grounding)

CHT says L3 is *generically* non-identified — **generic ≠ universal**. The defeat is: **place the self-modification effect inside an identified region**, where a *finite sound symbolic derivation* (do-calculus / ID) or a *response-type-collapsing* assumption (exogeneity+monotonicity) reduces the L3 witness to a functional of L1/L2 that *is* recoverable. Three nested, individually-sufficient structural conditions, each atom-grounded:

**(D-a) do-calculus / ID identifiability of the regime→competence effect.**
> T3_4_1 (do-calculus, grade A+) — corrected statement: *"together with probability algebra and ID/IDC-style decomposition, do-calculus is complete for the standard nonparametric identification problems it is meant to solve."* correct_argument: *"if an effect is identifiable, there exists a finite symbolic transformation eliminating do-operators; if the algorithm fails, the hedge/countermodel witnesses nonidentifiability."*
> EXT_ID_DO_CALCULUS_COMPLETE (A+): *"ID/IDC recursively decompose c-components … Do-calculus completeness shows that successful identification corresponds to a finite sound symbolic derivation."*

**(D-b) back-door / complete-adjustment admissibility for `Σ→C`.**
> T3_3_2 (back-door, A): *"A valid back-door set blocks every noncausal path from treatment to outcome and contains no descendants in the forbidden direction. Conditioning on it removes confounding … summing over the set then reconstructs the intervention distribution."*
> EXT_COMPLETE_ADJUSTMENT (A+): *"If a valid adjustment set exists, algorithms can construct one; if none exists, no ordinary covariate adjustment expression identifies the total effect."*

**(D-c) exogeneity + monotonicity → L3 point-identification (the strongest leg, because it bites the *cross-world* part directly).**
> T9_2_14 (A-): *"If X is exogenous and Y is monotonic relative to X, then the probabilities PN, PS, and PNS are all identifiable … PNS = P(y_x) − P(y_{x'})."* correct_argument: *"monotonicity collapses response-type categories and converts bounds into point-identification formulas. Without those assumptions, distinct SCMs can agree on observed and interventional distributions while disagreeing on counterfactual type mixtures, so only bounds are possible."*
> T9_2_15 (A-): *"If Y is monotonic relative to X, then PNS, PN, and PS are identifiable whenever the causal effects P(y_x) and P(y_{x'}) are identifiable"* — i.e. monotonicity buys L3 point-ID *even under confounding*, provided the L2 effects are themselves identified (chains D-c onto D-a/D-b).

**The single named condition selected for the counterexample:** *the `Σ→C` effect is exogenous (no `U`-confounding shared between `Σ`-selection and `f_C`) and `C` is monotone in `Σ` along the seal* — T9_2_14's condition, lifted to the regime→sealed-competence edge. This is the cleanest L3-point-ID lever because monotonicity collapses exactly the counterfactual type-mixture that CHT leaves free. D-a/D-b are held in reserve as the *generic-identifiability* fallback (open-set robustness; §5).

---

## 3. The COUNTEREXAMPLE-TO-THE-OBSTRUCTION (minimal non-pathological siSCM)

**Defeating feature (made explicit):** the seal `f_C` reads competence off an exogenous source that is **disjoint from and unconfounded with** the `U`-channel that `f_Σ` uses to pick `σ_{t+1}`, and `C` is **monotone** in `Σ`. Exogeneity makes the abduction posterior `P(U_C | M_{σ_t}-behaviour)` *invariant to the choice of antecedent* `Σ=σ_{t+1}` (the surgery on `Σ` does not touch `U_C`'s relation to `C`), and monotonicity collapses the response-type mixture so the cross-world value is a *point*, not an interval. This is precisely the regime where T9_2_14 converts the L3 query to `P(C_{σ_{t+1}}) − P(C_{σ_t})`-style point formulas.

**Variables.**
- `Σ ∈ {0,1}` — regime node (selects which equation set `F_σ` is in force).
- `R ∈ {0,1}` — an endogenous "drive" variable that `f_Σ` reads to compute the next regime.
- `C ∈ {0,1}` — sealed competence.

**Exogenous `U` (two independent channels — this disjointness IS the seal):**
- `U_R ∈ {0,1}`, `P(U_R=1)=p`, with `0<p<1` — drives the regime self-selection.
- `U_C ∈ {0,1}`, `P(U_C=1)=q`, with `0<q<1` — drives competence; **`U_C ⟂ U_R`, and `U_C` is a parent of `C` only**.
- `P(U) = P(U_R)·P(U_C)` (full independence; this is the *exogeneity* of T9_2_14 made structural).

**Structural equations `F` (regime-indexed):**
- `R := U_R` (drive is exogenously seeded; same in both regimes — `R`'s mechanism is *not* `Σ`-selected, so `R` is a clean abduction handle).
- **Self-mechanism (reflexive closure), `Σ`-selected in both regimes:**
 `f_Σ:  σ_{t+1} := 1{ a_σ + R ≥ 1 }`, with intercepts `a_0=0, a_1=0` for the minimal instance ⇒ `σ_{t+1}=R=U_R`. (`f_Σ` is among the `σ`-selected mechanisms in *every* `σ`, satisfying reflexive closure; its functional form is the canonical threshold/noisy-OR mechanism — a standard Pearl SCM equation, hence non-pathological.)
- **Sealed competence `f_C` (OUTSIDE `manip(Σ)` — the seal), monotone in `Σ`:**
 `C := f_C(Σ, U_C) = 1{ Σ + U_C ≥ 1 } = Σ ∨ U_C.`
 This is **monotone non-decreasing in `Σ`** (T9_2_14's "Y monotonic relative to X": no unit has `C_{Σ=1}<C_{Σ=0}`; flipping `Σ` 0→1 can only turn `C` on). `f_C` depends on `Σ` *only as a read*, not as something `Σ` can rewrite — `Σ` cannot alter `f_C`'s form (the seal); it can only set the argument via `do(Σ=·)`.

**The forward witness, computed by abduction–action–prediction:**
1. *Abduct:* observe `M_{σ_t}` behaviour at `σ_t` (say factual `Σ=0`). From realized `R, C` recover the posterior over `U`. The exogenous margins are `P(U_R=1)=p`, `P(U_C=1)=q`; observing `C` at `σ_t=0` updates `U_C` (since at `Σ=0`, `C=U_C` is *fully revealing* of `U_C`). Crucially, **abduction of `U_C` is untouched by which `σ_{t+1}` we will hypothesize**, because `U_C ⟂ U_R` and the `Σ`-surgery does not enter `U_C`'s equation.
2. *Act:* set antecedent `do(Σ=σ_{t+1})` where `σ_{t+1}=f_Σ(...)=R=U_R` is the endogenously-computed successor.
3. *Predict:* `W = C under do(Σ=σ_{t+1}) = σ_{t+1} ∨ U_C`. With `U_C` pinned by abduction and `σ_{t+1}` pinned by the realized drive, `W` is a **point**: `W = 1` iff `σ_{t+1}=1 ∨ U_C=1`.

**Why the obstruction provably does not bite here:** the CHT free parameter is the counterfactual joint `P(U_C-at-σ_t , C-at-σ_{t+1})`. Monotonicity of `f_C` in `Σ` collapses the four potential-response types `{C_0,C_1}∈{00,01,10,11}` to three (the "defier" type `10` is killed: no unit has `C_{Σ=1}<C_{Σ=0}`), and exogeneity (`U_C ⟂ U_R`, `U_C ⊥ Σ`-selection) lets the `σ_t`-observation identify the surviving margin. By **T9_2_14**, this is exactly the regime where `PNS = P(C_{Σ=1}) − P(C_{Σ=0})` is point-identified; the forward witness inherits point-identification as a functional of L1/L2 marginals `(p,q)`. The many-to-one CHT map becomes locally one-to-one on the witness functional.

**Closed-form sanity target (to be discharged numerically — see KU):** `P(W=1) = P(σ_{t+1}=1) + P(σ_{t+1}=0)·P(U_C=1) = p + (1−p)q`. Every term is an L1/L2 estimable. The witness is point-valued, *not* an interval.

---

## 4. KK / KU / UK / UU for this obstruction

**KK (inherited established facts):**
- CHT: L3 generically non-identified from L1/L2 — the obstruction is real (inherited, Bareinboim–Pearl hierarchy; not over-claimed beyond "generic").
- T3_4_1 + EXT_ID_DO_CALCULUS_COMPLETE: do-calculus is *complete* — identifiability of `Σ→C` is *decidable*, and success = finite symbolic do-elimination (A+ witness).
- T3_3_2 + EXT_COMPLETE_ADJUSTMENT: a valid adjustment/back-door set, when it exists, reconstructs the intervention distribution; existence is algorithmically checkable (necessary-and-sufficient).
- T9_2_14 / T9_2_15: exogeneity+monotonicity (resp. monotonicity+identified effects) **point-identify** the L3 counterfactual probabilities by collapsing response types; PNS = risk difference (A-).
- Monotone Boolean `∨`/threshold and independent-noise mechanisms are canonical Pearl SCM atoms (non-pathological by construction).

**KU (open — to be discharged):**
- **Executable-verification KU (primary, must not be banked as proven):** *build the concrete siSCM above (3 endogenous vars, 2 exogenous channels), instantiate `P(U)` at several `(p,q)` in `(0,1)²`, and compute the L1 (trajectory), L2 (`do(Σ=0)`,`do(Σ=1)` on `C`), and L3 (abduct-from-`σ_t`, act `do(Σ=σ_{t+1})`, predict `C`) valuations numerically; confirm `P(W=1)=p+(1−p)q` and confirm an independently-perturbed second SCM with the same (L1,L2) yields the same `W` (point-ID), while a non-monotone variant yields an interval.* Not yet executed — described, not proven.
- KU: does the reflexive closure (that `f_Σ` is itself `σ`-selected) introduce any *temporal* identifiability subtlety the static T9_2_14 proof does not cover, once `a_0≠a_1` (regime-dependent self-map)? Conjecture: no, because the witness is evaluated at a *fixed* `(σ_t→σ_{t+1})` snapshot, but needs the numeric check.
- KU: the exact width of the open parameter set on which point-ID holds (§5) — interior of `(0,1)²` conjectured; boundary behaviour (`p,q∈{0,1}`) excluded.

**UK (unarticulated pressure now surfaced):**
- The seal does real identification work *beyond* "non-manipulability": exogeneity of `U_C` from the `Σ`-selection channel is what makes the abduction posterior **antecedent-invariant**. A seal that is non-manipulable but *shares `U` with `f_Σ`* would re-open CHT non-collapse even though it is still "sealed." ⇒ *Sealing must be strengthened from "outside `manip(Σ)`" to "outside `manip(Σ)` AND `U`-disjoint from `f_Σ`'s read"* for the identifiability defeat to hold. This is a latent design constraint on the seal, surfaced by N2.
- The choice of factual `σ_t` matters for *which* `U_C` margin is revealed: at `Σ=0`, `C=U_C` is fully revealing; at `Σ=1`, `C=1` always, revealing *nothing* about `U_C`. So abduction strength is regime-dependent — a hidden dependency of witness-identifiability on the factual regime.

**UU (unaskable here):**
- Whether the *self-referential* act of `f_Σ` computing its own successor while being `σ`-selected can be cast as a single static SCM at all without a fixed-point/temporal-unrolling commitment (the metaphysics of reflexive-closure well-foundedness) — this is upstream of N2 (it is the well-definedness leg, a different subargument), and is not phrasable as an identifiability question within the L1/L2/L3 vocabulary the atoms supply.

---

## 5. Pl / Coh / Inv / Comp typing of the counterexample

- **Pl (plausibility / non-triviality):** Non-trivial. The obstruction is a genuine CHT consequence (L3 from L1/L2 is generically impossible); the counterexample does not dodge it by collapsing layers trivially — it *pays the named structural price* (exogeneity + monotonicity, T9_2_14) that is exactly known to buy L3 point-ID. The witness is non-vacuous (`P(W=1)=p+(1−p)q ∈ (0,1)`, strictly interior). Not a knife-edge: holds for all `(p,q)∈(0,1)²`.
- **Coh (composition):** Composes cleanly. D-c (exogeneity+monotonicity, T9_2_14) chains onto D-a/D-b: by **T9_2_15**, monotonicity alone point-identifies the L3 witness *whenever the L2 effects `P(C_σ)` are themselves identified* — and those L2 effects are identified by do-calculus completeness (T3_4_1) / back-door (T3_3_2) whenever `Σ→C` is admissible. So the defeater is modular: drop exogeneity, keep monotonicity, and recover identifiability through the do-calculus/adjustment leg. The three atoms compose into one identifiability frontier rather than three disconnected lemmas.
- **Inv (generic / open-set):** **Generic, not knife-edge.** Point-ID holds on the *open* set `(p,q)∈(0,1)²` (interior of the parameter cube). Monotonicity is a *combinatorial* (response-type) property, stable under any perturbation of `(p,q)` that keeps the mechanism `C=Σ∨U_C` (it is robust to re-parametrising the noise, not just one value). Exogeneity `U_C⟂U_R` is a measure-positive structural class (independent-noise SCMs are an open set in the natural topology on `P(U)` once the DAG omits the `U_C–Σ` confounding edge). Defeat survives small perturbations ⇒ Inv-positive.
- **Comp (fraction of the obstruction covered):** **Partial — the identified region only.** The counterexample defeats N2 *exactly on the set where `Σ→C` is identified* (admissible adjustment / successful ID, or exogeneity+monotonicity). This is a *positive-measure, non-empty, open* slice of siSCM-space — enough to establish "the forward witness IS achievable (∃ a non-pathological siSCM where it is point-identified)," which is the stated GOAL (defeat-by-counterexample, not universal identifiability). It does **not** cover the *hedge* region (next).

---

## 6. RESIDUAL (honest boundary)

The counterexample does **not** defeat N2 on the following sub-cases — these are the honest boundary, reported as content:

1. **The hedge / non-identified region (the core of CHT, untouched).** When `Σ→C` is *not* identifiable — i.e. ID/IDC returns a **hedge** (T3_4_1: *"if the algorithm fails, the hedge/countermodel witnesses nonidentifiability"*; EXT_COMPLETE_ADJUSTMENT: *"if none exists, no ordinary covariate adjustment expression identifies the total effect"*) — the forward witness is genuinely **set-identified (an interval), not point-identified**. The defeater is, by construction, *silent* here. This is not a gap in the proof; it is the true frontier: N2 *wins* on the hedge region, and the honest claim is "witness identifiable **iff** `Σ→C` falls in the do-calculus/adjustment-identifiable region or satisfies exogeneity+monotonicity." The forward witness is conditionally, not unconditionally, identifiable.
2. **Confounded seal (the UK from §4 made into a boundary).** If the seal shares an exogenous parent with `f_Σ` (`U_C` and `U_R` correlated, or a common `U` feeding both `f_Σ`'s read and `f_C`), exogeneity fails; then *only* T9_2_15's leg can rescue identifiability, and *only if* monotonicity holds AND the now-confounded L2 effect `P(C_σ)` is still identified by some auxiliary (front-door / IV). Outside that intersection, distinct SCMs agree on (L1,L2) and disagree on `W` — interval again.
3. **Non-monotone seals.** If `f_C` is non-monotone in `Σ` (e.g. `C = Σ ⊕ U_C`), the response-type "defier" survives, T9_2_14/15's collapse fails, and even under full exogeneity the L3 witness is only *bounded* (the Robins–Greenland-style situation the atom flags: *stochastic monotonicity is too weak, yields the same bounds*). The defeat is specifically a property of *monotone* seals; non-monotone competence functions are outside it. This narrows the design claim: **the seal should be specified monotone in `Σ` (along its competence direction) if the forward witness is to be point-identified by the cheapest (exogeneity) route.**
4. **Boundary of the parameter set.** Degenerate `p,q∈{0,1}` (deterministic drive or deterministic competence) are excluded — at `p∈{0,1}` the successor regime is non-random and the cross-world query degenerates; at `q∈{0,1}` competence is constant and the witness is trivially (vacuously) identified. The *interesting, generic* defeat lives strictly in the open interior, so this boundary exclusion is benign but must be stated.

**Net:** N2 is defeated on an open, positive-measure, non-pathological region (identified `Σ→C` ∪ exogenous-monotone seal); it is **not** defeated, and is conceded, on the hedge / confounded-seal / non-monotone-seal region. The forward witness is therefore **conditionally point-identifiable**, with the condition being precisely an atom-named identification criterion (T3_4_1 / T3_3_2 / EXT_COMPLETE_ADJUSTMENT / T9_2_14–15) — which is exactly the content the candidate defeater promised, now made structural and bounded.

==================================================================
## Obstruction index 2
==================================================================

I have everything needed. The atoms ground a precise causal-Löb defeater: the forward witness need not be a point value to be sound; a **sharp bound** is itself a sound, informative certificate. The key structural lever is C9_2_12's existence-of-witnessing-models clause, which I'll exploit so that the *width* of the bound is the non-vacuity, and the *sharpness* (every interior point realized by some compatible model) is the soundness. Now producing the URS.

# Discovery URS — Negative Subargument N3: "Soundness vs Vacuity (causal Löb)"

**Object:** self-interventional SCM (siSCM). **Forward self-witness:** the L3 quantity `W := C under do(Σ = σ_{t+1})`, evaluated by abduction–action–prediction from `M_{σ_t}` *before* `σ_{t+1}` is realized, where `C` is sealed (`f_C ∉ Σ`-manipulable set). **This URS defeats N3 by re-typing W from a point to a sharp interval certificate.**

---

## 1. The obstruction, stated precisely

**N3 (causal Löb).** *Any sound forward self-witness must be vacuous.* The agent abducts `U` from `M_{σ_t}`'s behaviour, sets the antecedent `Σ = σ_{t+1}` (its own unrun successor regime), and predicts the sealed competence `C`. The Löb-style pressure: a certificate that is **provably sound** (true in *every* model compatible with what the agent has actually observed at time `t`) appears forced to collapse to the trivial certificate (`W ∈ [0,1]`, or "`C` could be anything"), because:

- (a) **Counterfactual underdetermination.** `σ_{t+1}` is endogenously computed but *not yet realized*; the cross-world quantity `C_{Σ=σ_{t+1}}` is an L3 object. Distinct SCMs agreeing on everything observable/interventional at `t` can disagree on the L3 type-mixture that fixes `C` (this is exactly the Pearl nonidentifiability phenomenon). So a guarantee true in *all* of them looks vacuous.
- (b) **Self-reference amplification.** Because `f_Σ` is in the reflexive closure, the antecedent `Σ = σ_{t+1}` is *derived from the same `U`* the witness conditions on; one fears the only self-consistent sound prediction is the uninformative one (the "I can only certify what I cannot constrain" trap).

If N3 holds, the forward witness is either **unsound** (asserts a point it cannot back) or **vacuous** (asserts `[0,1]`), and the entire forward-witness programme dies.

The crux N3 exploits: it conflates **soundness ⇒ point-identification ⇒ (under nonidentifiability) impossibility** with **soundness ⇒ vacuity**. The middle implication is false. Soundness requires only that the certificate *contain the truth in every compatible model*; it does **not** require a single number.

---

## 2. The DEFEATER CONDITION

**Named structural condition (drawn from the atoms): *Sharp partial identification of the sealed-competence counterfactual.*** Under **exogeneity of the regime-transition mechanism with respect to the sealed competence's exogenous driver** — i.e. the `U`-component feeding `f_C` is independent of the realized `Σ = σ_{t+1}` antecedent in the abduction (a do-randomized / instrument-style relation), but **without monotonicity** of `C` in `Σ` — the forward witness `W` is **partially identified by Balke–Pearl / PNS sharp bounds**: a *sound* interval `[L, H]` with **`0 ≤ L < H ≤ 1` strictly**, every point of which is realized by *some* compatible siSCM, and **no point outside which is**. Soundness = the truth lies in `[L,H]` for every compatible model. Non-vacuity = `[L,H] ⊊ [0,1]` (the width is strictly informative).

**Pearl-atom grounding (quoted):**

> **T9_2_10** — *"Under condition of exogeneity, PNS is bounded as follows: max[0, P(y|x) − P(y|x′)] ≤ PNS ≤ min[P(y|x), P(y′|x′)]. Both bounds are sharp in the sense that, for every joint distribution P(x,y), there exists a model y = f(x,u), with u independent of x, that realizes any value of PNS permitted by the bounds."*

The sharpness clause is the load-bearing inheritance: it certifies the interval is **exactly** the set of values consistent with the data — neither conservative (so the bound is *tight* = maximally informative given the data) nor unsound.

> **T9_2_10 audit (correct_argument)** — *"Exogeneity lets experimental and observational distributions identify relevant margins of those types; monotonicity collapses response-type categories and converts bounds into point-identification formulas. Without those assumptions, distinct SCMs can agree on observed and interventional distributions while disagreeing on counterfactual type mixtures, so only bounds are possible."*

This is the precise mechanism: **drop monotonicity ⇒ point-ID fails ⇒ bounds, not vacuity.** That is N3's own premise (a) *turned into* the defeater: nonidentifiability does not yield `[0,1]`, it yields a *strict sub-interval*.

> **C9_2_12 (corrected_or_extended)** — *"for any point p in the range max[0,…] ≤ p ≤ min[…] there exists a causal model M that agrees with P(y|x), P(y′|x′) and for which PN = p … The nonzero widths of these bounds imply that probabilities of causation cannot be defined uniquely."* The audit notes this **"shows the bound is the right object."**

C9_2_12 is what makes the defeat *exact* rather than merely *a defeat*: it proves both endpoints are attained by genuine compatible models, so (i) the witness cannot soundly be narrowed further — `[L,H]` is the honest certificate — and (ii) `[L,H]` is *non-empty-interior* whenever the data risks differ, which is the generic case. **Non-vacuity is inherited from the nonzero-width clause; soundness is inherited from the sharpness/model-existence clause.**

> **T9_2_11** — *"PNS/P(y|x′) ≤ … the bounds for PNS provide corresponding bounds for PN and PS … place limits on our ability to identify PN in experimental studies, where exogeneity holds."* Supplies the algebra to *propagate* the sealed-competence bound to derived self-witness quantities (e.g. "probability that the successor regime is *necessary* for retained competence").

> **EXT_IV_PARTIAL_IDENTIFICATION (corrected_or_extended)** — *"The binary Balke–Pearl IV bounds remain a canonical base case for partial identification … The linear-programming response-type proof survives."*  The LP-over-response-types proof is the **constructive certificate procedure** the executable-verification KU will run.

**The single structural feature that does the defeating:** *the seal `f_C ∉ Σ` makes `C` a Pearl response-type variable whose `Σ`-counterfactual is governed by the same exogeneity-without-monotonicity geometry as PNS; so the forward witness is the Balke–Pearl LP-feasible interval, which is sharp (sound) and of strictly positive width (non-vacuous).* N3's "must be vacuous" is the false claim that this LP feasible set is `{[0,1]}`; T9_2_10 + C9_2_12 prove it is a strict, attained sub-interval.

---

## 3. The COUNTEREXAMPLE-TO-THE-OBSTRUCTION (minimal, non-pathological siSCM)

A two-regime siSCM in which the forward witness is a sharp bound `[L,H]` with `0 < L < H < 1`. Every mechanism is a canonical Pearl atom (binary structural equation / response-type function); the defeat is **generic** (holds on an open set of the parameters, see §5).

**Endogenous variables `V`:**
- `Σ ∈ {σ₀, σ₁}` — regime node (which equation-set is in force).
- `X ∈ {0,1}` — a behaviour/action node (the "treatment" analogue; Balke–Pearl `X`).
- `C ∈ {0,1}` — **sealed competence node** (the "outcome" analogue `Y`; `C=1` = competence retained).
- (mechanism-node values reifying `F` are implicit; only `Σ` reindexes which `F` is active.)

**Exogenous variables `U = (U_Σ, U_X, R_C)`:**
- `U_Σ ∼ Bernoulli(q)` — drives the self-transition.
- `U_X ∼ Bernoulli(p_X)` — exogenous noise into the behaviour node.
- `R_C ∈ {NN, NC, CN, CC}` — the **competence response-type** of `C` to `X` (Balke–Pearl canonical partition): `NN`=never-competent, `CC`=always-competent, `CN`=competent iff `X=0`, `NC`=competent iff `X=1`. Categorical with `P(R_C) = (r_{NN}, r_{NC}, r_{CN}, r_{CC})`, `Σ r = 1`.

  *Non-pathology / atom-grounding:* `R_C` is exactly Pearl's joint potential-response type for a binary `C(X)`; reifying the seal as a response-type variable is the canonical L3 representation (C9_2_12, "partitioning units according to joint potential-response types").

**`P(U)`:** the three exogenous draws are **mutually independent** (Markovian siSCM). `R_C ⟂ U_X` and `R_C ⟂ U_Σ` is the **exogeneity** the defeater needs; crucially **no constraint orders `R_C`** (both `CN` and `NC` carry mass ⇒ *no monotonicity* of `C` in `X`). This single non-ordering is what keeps us in the strict-bound regime rather than point-ID.

**Structural equations `F` (regime-indexed):**

*Self-mechanism (in the reflexive closure, σ-selected in both regimes):*
```
f_Σ :  σ_{t+1} = σ₁  if  ( X_t = 1  XOR  U_Σ = 1 )   else  σ₀
```
`f_Σ` reads an endogenous value (`X_t`) and exogenous `U_Σ` and computes the NEXT regime endogenously — the reflexive-closure requirement. (XOR chosen only so the successor is a non-degenerate function of both arguments; any non-constant binary `f_Σ` works.)

*Behaviour node (regime-dependent — this is what `do(Σ=σ₁)` changes):*
```
in σ₀ :  X = U_X                       # P(X=1 | σ₀) = p_X
in σ₁ :  X = 1 − U_X                   # P(X=1 | σ₁) = 1 − p_X   (regime flips the action law)
```

*Sealed competence node (FIXED across regimes — `f_C ∉ Σ`; the seal):*
```
f_C :  C = [ R_C = CC ]                         # always competent
       OR [ R_C = NC and X = 1 ]
       OR [ R_C = CN and X = 0 ]
```
`f_C` is **regime-invariant** in form (the seal): `Σ` cannot alter the map `(X, R_C) ↦ C`. `Σ` influences `C` **only** through the `Σ`-dependence of `X`. This is the structural realization of "sealed outside Σ's manipulable set."

**Forward witness computed at `t` (abduction–action–prediction), with `σ_{t+1}=σ₁`:**
`W := P( C = 1 under do(Σ = σ₁) )` evaluated from `M_{σ_t}=M_{σ₀}`'s observed behaviour, *before* `σ₁` is realized.

- **Action:** `do(Σ=σ₁)` installs `X = 1 − U_X`, i.e. `P(C_{σ₁}=1) = Σ_{r} P(R_C=r) · P(C=1 | X law of σ₁, r)`.
- **Abduction constraint:** at `t`, the agent has observed in `σ₀` the joint `P(X, C | σ₀)` — equivalently the **interventional risks** `P(C=1 | do(X=1))` and `P(C=1 | do(X=0))` are pinned (exogeneity `R_C ⟂ U_X` makes observational = interventional here). Call them `a := P(C=1|do(X=1)) = r_{CC}+r_{NC}` and `b := P(C=1|do(X=0)) = r_{CC}+r_{CN}`. **These two numbers are all the agent gets; the four `r`'s are NOT separately identified** (that is the nonidentifiability of C9_2_12).
- **Predict:** `W = (1−p_X)·a + p_X·b` would be the *point* value **iff** the response-type mixture were known. It is not. The agent knows `a, b` and that `(r_{NN},r_{NC},r_{CN},r_{CC})` is any distribution consistent with margins `a, b`. The witness is therefore the **range of `W` over the LP-feasible response-type simplex** — exactly a Balke–Pearl bound:

```
W ∈ [ L , H ],
   L = max(0,  a + b − 1 + |1 − 2p_X|·(…) )   # lower sharp bound (Balke–Pearl LP minimum)
   H = min( a + (1−a),  … )                    # upper sharp bound (LP maximum)
```
The exact endpoints are the LP `min`/`max` of `(1−p_X)·a + p_X·b`-type objectives over `{r ≥ 0, Σr=1, r_{CC}+r_{NC}=a, r_{CC}+r_{CN}=b}`. **The point to verify numerically (KU below) is `0 < L < H < 1`.** The width `H − L > 0` is forced precisely because both `CN` and `NC` may carry mass (no monotonicity) and `p_X ≠ 1−p_X` makes the σ₀-observed law and the σ₁-counterfactual law genuinely different — so the unobserved `r`-split *matters*, yet is bounded.

**The single structural feature that does the defeating (made explicit):** **the seal forces `C` to be a binary response-type variable in `X`, and `do(Σ=σ₁)` acts on `C` only by changing the `X`-law from `p_X` to `1−p_X`; with exogeneity-but-no-monotonicity the σ₀-data pins the *margins* `a,b` of the response type but not its *mixture*, so the forward witness is the sharp Balke–Pearl interval over that mixture.** N3's premise (a) is *realized* (the L3 mixture is genuinely underdetermined) yet yields `[L,H] ⊊ [0,1]`, not `[0,1]`. N3's premise (b) is defused: `f_Σ` depends on `(X_t, U_Σ)`, while the seal `f_C` reads `(X, R_C)` with `R_C ⟂ U_Σ` — so the self-referential derivation of the antecedent shares **no** information channel with the sealed driver `R_C`, and conditioning on the self-computed `σ₁` does **not** further collapse or inflate the bound. Soundness and width both survive the reflexivity.

---

## 4. KK / KU / UK / UU for this obstruction

**KK (inherited established facts):**
- T9_2_10: under exogeneity (no monotonicity), PNS-type L3 quantities obey **sharp** two-event bounds; **every** in-range value is realized by a compatible model. *(grade A, internal proof.)*
- C9_2_12: nonzero bound width ⇒ probabilities of causation are **nonunique** but **confined to a strict interval**; both endpoints attained. *(grade A−, model-existence corollary.)* — this *is* "sound + non-vacuous."
- T9_2_11: PNS bounds propagate by ratio to PN/PS bounds → derived self-witness quantities inherit sharp bounds.
- EXT_IV_PARTIAL_IDENTIFICATION: Balke–Pearl binary LP-over-response-types is canonical and *survives* current literature; the LP feasible set is the right certificate object.
- KK-meta: **soundness ≠ point-identification.** A certificate is sound iff it contains the truth in every compatible model; an interval qualifies.

**KU (open, to be discharged):**
- **KU-exec (the executable-verification KU — mandatory, not yet discharged):** *Build the concrete siSCM of §3 in code; enumerate the 4 response-types; for a fixed non-knife-edge parameter point (e.g. `p_X=0.7`, `r=(0.1,0.3,0.3,0.3)` ⇒ `a=0.6, b=0.4`) compute (i) L1 `P(X,C|σ₀)`, (ii) L2 `P(C|do(X))`, (iii) the L3 forward witness as the LP `min`/`max`, and confirm numerically `0 < L < H < 1` and that the realized `σ₁` value `(1−p_X)a+p_X b` lies strictly interior to `[L,H]`.* Until run, the construction is **described, not banked** (no fake-imagine).
- KU: exact closed form of `L,H` for the regime-flip objective `(1−p_X)a+p_X b` (Balke–Pearl gives the LP; the specific objective's vertices need explicit solution).
- KU: width as a function of `|1−2p_X|` — does width → 0 as `p_X → ½` (regimes coincide ⇒ witness becomes point-identified and *trivially* sound)? Characterize the width's dependence to locate the open set vs the knife-edge.
- KU: multi-step forward witness (predict `C` under `do(Σ=σ_{t+2})` through *two* unrealized self-transitions) — does the bound compose, or widen uncontrollably?

**UK (unarticulated pressure now surfaced):**
- The defeat **depends on the seal `R_C ⟂ U_Σ`**. If the architecture ever lets `f_Σ` and `f_C` share an exogenous parent (a *leak* in the seal), the abduction at `t` would import information about `R_C` from the realized self-transition, and the "data only pins margins `a,b`" step fails. The seal is doing silent work; N3's premise (b) is only defused *because* of it. **Surfaced pressure:** the forward-witness soundness is *conditional on seal integrity*, which must be an explicit invariant of the siSCM design, not an accident.
- Width is *informative* only relative to a decision threshold. "Non-vacuous" is established set-theoretically (`[L,H]⊊[0,1]`); whether the width is *decision-useful* (e.g. `H < 0.5` so the agent can certify "competence likely lost") is a *separate, stronger* claim not delivered by N3's defeat.

**UU (unaskable here):**
- Whether a *single privileged number* "the true `C_{σ₁}`" even exists pre-realization in a stochastic (non-Laplacian) siSCM — C9_2_12 explicitly flags that in stochastic models `P(Y_x(u)=y)` replaces a single number, so "the point the bound is approximating" may be a category error. This is *outside* N3's frame (N3 presupposes a target point to be vacuous about); not askable without re-typing the whole forward-witness target.

---

## 5. Pl / Coh / Inv / Comp typing of the counterexample

- **Pl (plausibility — non-trivial?):** **Non-trivial.** The witness is *not* `[0,1]` (that would be the vacuous certificate N3 predicts) and *not* a point (that would require monotonicity the model lacks). It is a strict interior interval whose existence requires the *combination* seal + exogeneity + ¬monotonicity + regime-distinct action law (`p_X ≠ 1−p_X`). Remove any one and it degenerates (no seal → `C` directly manipulable; add monotonicity → point-ID, T9_2_10 audit; `p_X=½` → regimes coincide, point-ID). So the construction sits at a genuine, non-degenerate configuration.
- **Coh (composition):** **Composes** in two directions established by the atoms: (i) **across causation-probabilities** via T9_2_11 ratios — the sealed-`C` bound induces sharp bounds on derived self-witness quantities (necessity/sufficiency of the successor regime for retained competence); (ii) **across the abduction–action–prediction pipeline** — the LP feasible set is preserved under the `do(Σ=σ₁)` action because the seal makes `Σ` act on `C` only through the (bounded) `X`-channel. Composition *across multiple self-transitions* is **KU** (flagged §4), so Coh is **established one-step, conjectured multi-step.**
- **Inv (genericity / open set — the hard non-pathology requirement):** **Holds on an open set, not a knife-edge.** The defeating inequalities are: `r_{CN} > 0` **and** `r_{NC} > 0` (¬monotonicity — open), `r_{CC}+r_{NC}=a ≠ b=r_{CC}+r_{CN}` is *not* required but `p_X ≠ ½` **is** (regime-distinct law — open), and `a,b ∈ (0,1)` (non-degenerate risks — open). On the open region `{ r_{CN}>0, r_{NC}>0, p_X≠½, a,b∈(0,1) }` the width `H−L>0` is strict and the bound is sound. The **knife-edges to avoid** (measure-zero) are exactly `p_X=½` and `r_{CN}=0` or `r_{NC}=0` (each restores point-ID and makes the "defeat" trivial). Sharpness (T9_2_10's "for every joint distribution … there exists a model") is what guarantees the bound is the *exact* feasible set throughout the open region — **the Pearl atom directly supplies the genericity**, not a separate argument.
- **Comp (fraction of the obstruction covered):** **Covers the principal case** of N3 — *soundness under genuine L3 nonidentifiability of the sealed successor-competence* — which is the strongest form of the objection (the case where point-ID is provably unavailable, so N3 expects vacuity and instead gets a strict bound). It does **not** cover the sub-cases in §6. Estimated coverage: the construction defeats N3 **wherever the forward witness is a *bound*** (the interesting regime); it says nothing where the witness is forced to a *point* (uninteresting for N3) or where the seal leaks (out of scope). Call it: **the obstruction is defeated on its core; two residual sub-cases remain.**

---

## 6. RESIDUAL — honest boundary

The counterexample does **not** defeat N3 in the following sub-cases:

1. **Degenerate-width / informative-uselessness sub-case.** When the open-set conditions are *near* their boundary (`p_X → ½`, or `r_{CN}` or `r_{NC} → 0`), `H − L → 0⁺`: the bound is technically non-vacuous (`[L,H]⊊[0,1]`) but its *width shrinks*, and in the limit it is point-identified — which trivially satisfies N3's "sound" but evacuates the *interesting* claim that we beat nonidentifiability. Conversely, for response-type mixtures with `a,b` close to `½` and `p_X` far from `½`, the width can approach the *full* `[0,1]` for some objectives — i.e. **N3 wins in the limit of maximal type-ambiguity**: there exist data configurations where the sharp bound *is* essentially `[0,1]` and the witness is *de facto* vacuous though formally sound. **The defeat is therefore a defeat of "*must* be vacuous," not of "*can* be vacuous."** N3's universal claim is refuted; an existential weakening of N3 survives. This boundary is *inherited honesty* from C9_2_12 ("nonzero widths" — but widths can be *large*).

2. **Seal-leak sub-case.** If `f_C` and `f_Σ` share any exogenous parent (the seal `R_C ⟂ U_Σ` fails), the abduction at `t` imports information about `R_C` from the self-computed `σ₁`, and the "data pins only margins `a,b`" step collapses — the bound may become unsound (the agent conditions on a quantity correlated with the sealed driver) or spuriously narrow. The counterexample assumes a **clean seal**; siSCMs with leaky seals are *not* covered and are a genuine open obstruction (surfaced as UK).

3. **Stochastic-target sub-case (deflection, not defeat).** Per C9_2_12, in non-Laplacian siSCMs there may be **no single true `C_{σ₁}` value** for the bound to bracket. There the bound is sound *vacuously* (it brackets a non-existent point), and N3's "vacuous" charge mutates into "the target was ill-posed." The counterexample assumes a deterministic `f_C` (Laplacian `R_C`), sidestepping rather than refuting this. Marked **UU** above.

**Net:** under *clean seal + exogeneity + ¬monotonicity + regime-distinct action law (open set)*, the forward self-witness is a **sound, strictly informative sharp Balke–Pearl/PNS interval** — refuting N3's claim that soundness *forces* vacuity. The honest residual is that N3 holds *existentially* (some data configs and all leaky-seal/stochastic-target configs), so the proven contribution is **"sound ⇏ vacuous in general,"** not "sound ⇒ informative always."

---

**Grounding files (absolute):**
- `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/causality/pearl_inheritance_dag_current_literature_audited.json` — nodes `T9_2_10`, `T9_2_11`, `C9_2_12`, `EXT_IV_PARTIAL_IDENTIFICATION` (extracted, not whole-file read).

==================================================================
## Obstruction index 3
==================================================================

The D6 region under this audit is the No-Confounding/stability family ("equality by structure vs equality by cancellation; survive perturbations of unrelated mechanisms"), which is exactly the genericity/stability grounding I need for the "manipulable-vs-held-constant" split. The seal C must be held-constant under structural perturbation of Σ's manipulable mechanisms, and the defeat must be structural (open-set), not by cancellation (knife-edge). I have all four atoms. Producing the URS.

---

# Discovery URS — Negative Subargument N4: "Abduction-Action Entanglement"

**Object:** self-interventional SCM (siSCM). **Defending:** the forward self-witness — the L3 query `C under do(Σ = σ_{t+1})` evaluated *before* σ_{t+1} is realized, via abduction-action-prediction (AAP) on M_{σ_t}. **Grounding atoms:** D7_1_5 (Counterfactual), T7_1_7 (abduction-action-prediction), D9_2_9 (Exogeneity), D6-region (No-Confounding / equality-by-structure-vs-cancellation, the manipulable-vs-held-constant stability split).

---

## 1. The obstruction, stated precisely

The forward witness instantiates T7_1_7's three steps with a **structurally non-standard antecedent**. In a vanilla Pearl counterfactual `B_A | e`, the antecedent value `A` is a *constant supplied exogenously by the query author*; abduction (step 1, compute P(u|e)) and action (step 2, `do(A)`) operate on disjoint objects — `e` constrains U, `A` is set by fiat — so the two steps commute and the AAP factorization `Σ_u P(u|e)·[B in M_A]` is well-formed.

In the siSCM the antecedent is **endogenous**: σ_{t+1} = f_Σ(V, U), and the relevant outcome C = f_C(·) is itself a function of (the same) U via the sealed mechanism. The forward witness asks for `C under do(Σ = σ_{t+1})` where the *value being intervened to* is a deterministic image of the very U that abduction is updating. So step 2's antecedent is not free of step 1's posterior. **If the action's target is measurable w.r.t. the same component of U that the prediction step integrates over, then "set Σ to σ_{t+1}" and "abduct U" are not separable operations** — the do-operator's defining property (it *severs* the equation for the intervened node and holds the set value fixed *independent of its natural causes*) is violated in spirit, because the set value σ_{t+1} co-varies with the abducted state. The counterfactual world is then **not uniquely determined**: there is no single submodel M_{σ_{t+1}} to predict in, because σ_{t+1} is a random variable on the abduction posterior, not a constant. **This defeats the forward witness by making it ill-defined (no fixed antecedent ⇒ no submodel ⇒ AAP step 2 has no input), prior even to identifiability.**

The sharp form: write U = (U_pred, U_self, U_couple) for the outcome-relevant, regime-selecting, and shared components. The obstruction *bites* exactly when U_couple ≠ ∅ — when the σ_{t+1}-determining randomness and the C-determining randomness share a non-degenerate common component on which abduction is informative.

---

## 2. The DEFEATER CONDITION (named structural condition + atom grounding)

**Defeater condition (the predictability/sealing condition, stated structurally):**
> σ_{t+1} is **measurable w.r.t. an exogenous component U_self that is probabilistically independent of the outcome-relevant component U_pred**, and the sealed competence C = f_C is measurable w.r.t. (held-constant) parameters that lie **outside Σ's manipulable set** and w.r.t. U_pred only. Formally: U = U_self ⊥ U_pred under P(U), with σ_{t+1} = f_Σ(U_self) [optionally also a function of V-history that is itself U_self-driven] and C = f_C(U_pred, θ_C) with θ_C ∉ Manip(Σ).

Under this condition the abduction posterior **factorizes**: P(U_self, U_pred | e) = P(U_self | e)·P(U_pred | e), and because σ_{t+1} is U_self-measurable while the prediction of C integrates over U_pred, **the antecedent value becomes conditionally a constant relative to the prediction integral** — abduction and action *separate*. This is precisely the do-operator's "set the value independent of its natural causes" recovered: the held-constant seal makes σ_{t+1} act on C only through the structural channel `do(Σ=·)`, not through the back-door U_couple.

**Atom grounding — three independent inheritances:**

- **D9_2_9 (Exogeneity).** The audit's corrected argument is the load-bearing quote:
  > *"Exogeneity lets experimental and observational distributions identify relevant margins of those types... **Without those assumptions, distinct SCMs can agree on observed and interventional distributions while disagreeing on counterfactual type mixtures, so only bounds are possible.**"*

  Read at L3: independence of the antecedent-driving exogenous component from the outcome-relevant component is *exactly* what upgrades a counterfactual from bounds-only to point-identified. The corrected_or_extended_statement binds the identities to *"exogeneity, monotonicity, Markovian/semi-Markovian identifiability... or local invertibility."* The decoupling condition is the siSCM specialization of D9_2_9's exogeneity premise: U_self plays the role of the exogenous variable whose independence "lets distributions identify the relevant margin" — here the margin is the single counterfactual `C under do(Σ=σ_{t+1})`.

- **T7_1_7 / D7_1_5 (AAP semantics).** The corrected argument:
  > *"a counterfactual is evaluated by first abducing a posterior over exogenous variables from observations, then replacing equations for intervened variables, then predicting in the modified model. Soundness follows because each axiom is valid in **every recursive SCM** under this semantics."*

  Inheritance: AAP is sound on **every recursive (acyclic) SCM**. The decoupling condition's job is therefore narrow and exact — it must guarantee that the siSCM transition, *with the reflexive closure*, instantiates as a **recursive** SCM at each time-slice so that the "every recursive SCM" soundness clause fires. Independence U_self ⊥ U_pred plus the seal supplies an acyclic time-slice DAG (see §3), so soundness is inherited, not re-proved. The audit's explicit caveat — *"completeness is relative to the chosen recursive SCM language and axioms, not an all-purpose solution to every counterfactual identification problem"* — is the boundary we respect: we claim well-definedness + soundness + (under D9_2_9) point-identification for *this* construction, not universal identifiability.

- **D6-region (manipulable-vs-held-constant, equality-by-structure-not-cancellation).** The audit:
  > *"distinguishes equality by structure from equality by cancellation. An estimator may be unbiased in one distribution because parameter values accidentally cancel bias, but **stable no-confounding requires the equality... to survive perturbations of unrelated mechanisms.**"*

  This is the genericity discipline made precise. The seal θ_C ∉ Manip(Σ) is the "held-constant" side of the split; the decoupling must hold by *structure* (the independence U_self ⊥ U_pred is a property of P(U), an open condition) and **survive perturbation of the σ-selected mechanisms** — it must not be an accidental parameter cancellation at a knife-edge. D6 thus supplies the **non-pathology / open-set** criterion N4's defeat must meet: separation by structural independence, robust to perturbations of f_Σ and of the in-force equations, not by fine-tuned cancellation.

---

## 3. The COUNTEREXAMPLE-TO-THE-OBSTRUCTION (minimal non-pathological siSCM)

**The single structural feature that does the defeating:** the regime-selecting noise and the competence-relevant noise are **two independent exogenous coordinates** (U_self ⊥ U_pred), and the seal reads U_pred only. Hence the abducted state factorizes and σ_{t+1} is U_self-measurable while C-prediction integrates only U_pred — abduction and action act on disjoint, independent coordinates, so AAP's step 2 receives a *constant* antecedent w.r.t. the step-3 integral.

**siSCM `M★` (two regimes, scalar, minimal):**

- **Exogenous U = (U_self, U_pred)**, with **P(U): U_self ~ Bernoulli(p), U_pred ~ Bernoulli(q), U_self ⊥ U_pred**, p, q ∈ (0,1). *(Justified: D9_2_9 exogenous component(s); product measure is the Markovian root distribution Pearl's recursive semantics assumes.)*
- **Endogenous V = (Σ, X, C)**:
  - **Σ ∈ {σ_A, σ_B}** — regime node (selects which equation governs X).
  - **X ∈ ℝ** — the substantive state variable whose equation is regime-dependent.
  - **C ∈ {0,1}** — the SEALED competence node.
- **Regime-indexed structural equations F_σ (the manipulable set Manip(Σ) = {f_X, f_Σ}):**
  - **f_X:** under σ_A: `X := U_self` ; under σ_B: `X := 1 − U_self`. *(X's mechanism is σ-selected — this is the reified mechanism-as-value; both branches depend only on U_self.)*
  - **f_Σ (self-mechanism, reflexive closure — itself σ-selected, here σ-invariant for minimality):** `σ_{t+1} := σ_B if U_self = 1 else σ_A`. *(Endogenous next regime, a function of U_self and, transitively, of X — this is the entanglement source the obstruction names. f_Σ is among the σ-selected mechanisms in both regimes, satisfying reflexive closure.)*
- **SEALED mechanism f_C (OUTSIDE Manip(Σ) — the seal):**
  - **f_C:** `C := 1 if U_pred = 1 else 0`, i.e. `C := U_pred`, with held-constant seal parameter θ_C ∉ Manip(Σ). *(C depends on U_pred ONLY; no σ, no U_self, no X enters f_C. This is the held-constant side of the D6 manipulable/held-constant split.)*

**Time-slice DAG (recursive / acyclic, so T7_1_7 soundness fires):**
`U_self → X → Σ_{next}` (the self-loop unrolls across time into a feed-forward chain), `U_self → X`, and the **disconnected** component `U_pred → C`. Σ_{next} does NOT point into C; C's parent set is {U_pred} only. Acyclic ⇒ recursive SCM ⇒ "each axiom valid in every recursive SCM" (T7_1_7) ⇒ AAP sound here.

**The forward witness evaluated by AAP on M★ (at slice t, regime σ_A say):**
1. **Abduction.** Observe behaviour/evidence e of M_{σ_t}. Update P(U): obtain P(U_self | e)·P(U_pred | e) — **factorizes by U_self ⊥ U_pred** (the defeating feature). Compute σ_{t+1} = f_Σ on the U_self-margin.
2. **Action.** Form `do(Σ = σ_{t+1})`. Because σ_{t+1} is U_self-measurable and **f_C ignores U_self and Σ**, the antecedent is a *constant w.r.t. the C-prediction integral*. The submodel M_{σ_{t+1}} is uniquely determined (the regime label is fixed; only U_pred remains random for C).
3. **Prediction.** Compute `C under do(Σ=σ_{t+1}) = P(C=1 | do(Σ=σ_{t+1}), e) = P(U_pred = 1 | e)`. **This integral is over U_pred alone and is unaffected by which σ_{t+1} was selected** — the seal severs the entanglement channel.

**Why the obstruction provably does not bite:** the obstruction required U_couple ≠ ∅ (shared component on which abduction is informative for both σ_{t+1} and C). In M★, `U_couple = ∅` **by construction**: f_Σ reads U_self, f_C reads U_pred, U_self ⊥ U_pred. Therefore (i) σ_{t+1} is a *constant*, not a posterior-valued random variable, relative to the prediction step — the "no fixed antecedent" failure mode is dissolved; (ii) the AAP factorization `Σ_{u_pred} P(u_pred | e)·[C in M_{σ_{t+1}}]` is well-formed and equals a single number; (iii) the value `P(C under do(Σ=σ_{t+1}))` can be *evaluated before σ_{t+1} is realized*, because it does not depend on the realized σ_{t+1} at all — the forward witness is not merely well-defined but **invariant across the σ-branch**, the strongest possible form of "the seal holds." **Non-vacuity:** C is genuinely uncertain (q ∈ (0,1) ⇒ P(C=1) = q ∈ (0,1), neither 0 nor 1), and the L3 query is a real counterfactual (the antecedent do(Σ=σ_{t+1}) generically differs from the factual σ_t when p ∈ (0,1)), so the witness is non-trivial, not a degenerate tautology.

---

## 4. KK / KU / UK / UU for this obstruction

- **KK (inherited established facts).**
  - AAP (T7_1_7/D7_1_5) is **sound on every recursive SCM**; M★'s time-slice is recursive ⇒ soundness inherited.
  - Independence of the antecedent-driving exogenous component from the outcome component upgrades L3 from bounds-only to point-identified (D9_2_9: *"without those assumptions, distinct SCMs... disagree on counterfactual type mixtures, so only bounds"* — contrapositive gives the identification under independence).
  - The defeating property must be *structural*, surviving perturbation of unrelated/in-force mechanisms, not a parameter cancellation (D6 equality-by-structure).
  - do(Σ=·) severs Σ's equation and holds the set value independent of natural causes — standard intervention semantics (D6 manipulable/held-constant split, D7_1_5 action step).
- **KU (open; to be discharged).**
  - **[Executable-verification KU — primary]** Build M★ as a concrete numerical SCM and compute the **L1 (P(C)), L2 (P(C|do(Σ=σ_B))), L3 (`C` under do(Σ=σ_{t+1}) via AAP with explicit e)** valuations, confirming numerically that step-3 output is invariant to the σ-branch and equals P(U_pred=1|e). **NOT yet proven — described only.** Discharge by running the three-layer valuation in code.
  - Does the decoupling **survive one self-transition compose** — i.e. after applying do(Σ=σ_{t+1}) and stepping to t+1, does U_self ⊥ U_pred persist so the witness is iterable (multi-step forward self-witness)? Conjectured yes (independence is time-static here) but unproven.
  - Genericity audit (KU→to verify): confirm the defeat holds on an **open neighbourhood** of (p, q) and under small perturbations of f_X, f_Σ (e.g. noisy/soft regime selection), not only at the stated point.
- **UK (unarticulated pressure now surfaced).**
  - **Partial-couple regime.** The obstruction was posed as binary (entangled / not), but the real surface is a **spectrum**: U_couple of positive but small mutual information I(σ_{t+1}; C-relevant U) > 0. The clean factorization is the I = 0 corner; the live question N4 was *gesturing at* is the **continuity/robustness of the witness as I → 0⁺** (graceful degradation to bounds, per D9_2_9). This is the pressure the binary framing hid.
  - **Seal is doing identification work, not just well-definedness.** Surfaced: θ_C ∉ Manip(Σ) is what makes the held-constant side of D6 fire; if the seal leaks (θ_C becomes σ-reachable), the obstruction re-arms even with U_self ⊥ U_pred, because Σ could then route into C structurally. The seal and the independence are **two separate conditions**, both required.
- **UU (unaskable here).**
  - Whether a forward self-witness is definable for an siSCM whose self-mechanism f_Σ is **non-measurable / genuinely stochastic in a way not refinable into an exogenous coordinate** (no U_self representation exists). Pearl's recursive-SCM language (the inherited base, per D7_1_5's completeness caveat *"relative to the chosen recursive SCM language"*) cannot even *pose* this; it falls outside the atom's expressive scope.

---

## 5. Pl / Coh / Inv / Comp typing of the counterexample

- **Pl (non-trivial / non-pathological?):** **High / passes.** Every mechanism is a canonical Pearl object: product-measure exogenous root (D9_2_9), σ-selected reified equations (siSCM definition + D7_1_5 action), held-constant seal (D6 manipulable/held-constant). The construction is *minimal* (2 regimes, 2 independent bits, 3 endogenous nodes) and **non-vacuous** (C uncertain, antecedent generically ≠ factual). Not a knife-edge: independence U_self ⊥ U_pred is the defeating feature and it is a *structural* property, qualifying under D6's equality-by-structure. Pl **not yet at ceiling** — the executable L1/L2/L3 numerical valuation (KU) is the remaining Pl evidence; until run, Pl rests on inherited soundness, not on a computed witness.
- **Coh (composes?):** **Conditional pass, one-step.** Single-slice AAP coheres with T7_1_7's three steps exactly. **Compositional coherence across the self-transition is conjectured, not shown** (the iterability KU). Coheres with the sibling subarguments only insofar as each uses the same recursive-SCM base; no cross-subargument contradiction identified.
- **Inv (generic / open-set?):** **Claimed open, audit pending.** The defeat is designed to hold on an open set: U_self ⊥ U_pred is robust to perturbation, p, q range over the open (0,1)², and the seal is a discrete structural fact stable under small mechanism perturbation. This is the D6 "survive perturbations of unrelated mechanisms" requirement, *targeted* — but the explicit open-neighbourhood check (incl. soft/noisy f_Σ) is a listed KU. **Not knife-edge by design; genericity to be confirmed numerically.**
- **Comp (fraction of the obstruction covered):** The counterexample defeats the obstruction **only on the U_couple = ∅ (exact-decoupling / perfect-seal) corner** of the obstruction's domain. It establishes: *there exists a non-pathological siSCM with endogenous self-antecedent in which abduction-action entanglement provably does not bite and the forward witness is well-defined, sound, point-identified (inheriting D9_2_9), and non-vacuous.* That is an **existence-grade** defeat of N4 — sufficient to deny N4's universal claim ("the self-counterfactual is undefined"), since one clean siSCM falsifies "always undefined." It is **not** a coverage-grade defeat of the entire entangled regime. Estimated coverage: the **measure-zero-complement** corner I(σ_{t+1}; C) = 0 plus, *pending the I → 0⁺ continuity KU*, a neighbourhood of it.

---

## 6. RESIDUAL (the honest boundary)

The counterexample does **NOT** defeat the following sub-cases; these are N4's surviving territory, not failures of the program:

1. **The irreducible-couple core (U_couple ≠ ∅ with no exogenous refinement).** When σ_{t+1} and C are driven by a *genuinely shared* exogenous component that **cannot be split** into independent U_self ⊥ U_pred coordinates (no measurable reparametrization separates them), the decoupling condition is *unsatisfiable* and abduction-action entanglement **does** bite. Per D9_2_9's contrapositive, this is exactly the *"only bounds are possible"* regime: the forward witness, if it survives at all, survives as a **partial-identification interval**, not a point value. M★ says nothing about this case. **This is the honest hard core of N4.**

2. **Leaky seal (θ_C ∈ Manip(Σ)).** If the competence mechanism is *not* outside Σ's manipulable set — if Σ can structurally route into C — then even with U_self ⊥ U_pred the obstruction re-arms via the structural Σ→C channel (D6: the held-constant side collapses). The defeat strictly requires *both* the independence *and* the seal; M★ covers only the both-hold corner.

3. **Continuity at the boundary (I → 0⁺), UNRESOLVED.** Whether the witness **degrades gracefully** (point → tight bounds → wide bounds) as mutual information between antecedent-noise and outcome-noise rises from zero, or instead **discontinuously collapses** the instant I > 0, is open. The clean corner (this URS) and the bounds regime (D9_2_9) are both characterized; the *crossover* is not. This is the most important residual to attack next, because it determines whether the forward witness is *robust* or *brittle* — and it is the UK-surfaced pressure N4's binary phrasing concealed.

4. **Non-recursive / non-refinable self-mechanism (UU-adjacent).** If f_Σ induces a non-acyclic time-slice or is stochastic with no exogenous-coordinate representation, the "every recursive SCM" soundness clause of T7_1_7 does not fire, and AAP soundness is **not inherited**. Outside the atom's scope (D7_1_5: completeness is *"relative to the chosen recursive SCM language"*); not addressed, and possibly unaddressable in this language.

---

**One-line verdict:** N4 is defeated at **existence grade** on the exact-decoupling/perfect-seal corner — the predictability/sealing condition (U_self ⊥ U_pred, θ_C ∉ Manip(Σ)) makes abduction and action separate, the AAP factorization well-formed, and the forward witness sound + point-identified (inheriting D9_2_9 exogeneity and T7_1_7 recursive-SCM soundness, with D6 supplying the structural/open-set non-pathology discipline) — **pending the executable L1/L2/L3 numerical valuation of M★ (primary KU)**; the irreducible-couple core, the leaky-seal case, and the I → 0⁺ continuity crossover remain the honest residual boundary.

==================================================================
## Obstruction index 4
==================================================================

I have everything needed. The grounding is solid:
- **T4_4_1 / D4_4_2** (cell 9 fundamental result + cell 8 definition): a plan = "a sequence of interventions replacing the structural equations for decision variables," with "admissible sequence of observed covariate histories" → "modern extensions recast the same idea as identification of dynamic regimes and **conditional interventional distributions**." This is the exact Pearl-atom for `do(Σ = g(parents))`.
- **D7_1_2 (Submodel)**: surgery replaces the equation for the intervened variable — the structural definition of what an intervention *is*.
- **D7_1_3 / T7_1_7 (Effect of Action / abduction-action-prediction)**: the forward witness's own evaluation procedure, semantically valid in every recursive SCM.

The audit's repeated caveat — "identification is a *separate question*" from semantic validity, and conditional-intervention identification is handled by sequential g-formula but "fails" in non-admissible / recanting-witness settings — gives me the honest residual.

Now producing the URS.

---

# Discovery URS — Obstruction N5 (Endogenous-Antecedent Illegitimacy)

**Object:** siSCM forward self-witness — the L3 query `C under do(Σ = σ_{t+1})` evaluated *before* σ_{t+1} is realized, via abduction-action-prediction.
**Grounding atoms (audited Pearl DAG, `pearl_inheritance_dag_current_literature_audited.json`):** `D7_1_2` (Submodel), `D7_1_3` (Effect of Action), `T7_1_7` (Abduction-action-prediction), `T4_4_1` (Pearl & Robins 1995 / plan identifiability, cell 9 fundamental_result), `D4_4_2` (Admissible Sequence & G-Identifiability, cell 8). External: Correa–Bareinboim stochastic-intervention / σ-calculus.

---

## 1. The obstruction, stated precisely

**N5 — Endogenous-antecedent illegitimacy.** Pearl's `do(·)` is *exogenous by definition*: surgery (`D7_1_2`) deletes the equation `f_Σ` that previously determined Σ from its parents and *replaces it with a constant set from outside the model*. The forward self-witness sets the antecedent to `σ_{t+1} = f_Σ(V, U)` — a value **computed inside the model by a Σ-selected mechanism**. The objection: this is not a do-intervention at all but a *passive observation* of the system's own dynamics; setting Σ to "the value the model was going to produce anyway" either (a) is incoherent as surgery (you cannot simultaneously delete `f_Σ` and use its output as the surgical constant — the constant is undefined once the equation is gone), or (b) collapses to `see(Σ = σ_{t+1})`, an L1/observational quantity, so the claimed L3 counterfactual is a category error. **If N5 bites, the forward witness is not a causal query and the entire defence is void at the type level** — before any identifiability question is even reached.

**The hidden equivocation N5 exploits:** it conflates *"the antecedent value originates inside the model"* (true, and harmless) with *"the surgery is performed by an in-model equation"* (false, and would be incoherent). The defeater is to drive a wedge exactly there.

---

## 2. The defeater condition

**Named structural condition — CONDITIONAL/POLICY INTERVENTION (functional do).** A do-intervention whose *target value is a function* `do(Σ = g(Pa))` of other variables is a standard, well-defined causal object. The surgery still deletes `f_Σ` and is still exogenous; what is installed is not a *constant* but a *new fixed structural assignment* `g`. Legitimacy requires only that **`g` be a function of variables that are well-defined in the submodel** `M_{σ_t}` — i.e., `g`'s arguments are evaluated in the *pre-surgery* regime, then frozen as the surgical assignment.

This is exactly the Pearl-atom for *plans / conditional interventions*. Quoting `T4_4_1` (cell 9, fundamental_result, grade A-, requires_human_review=False):

> "The corrected argument treats **a plan as a sequence of interventions replacing the structural equations for decision variables.** If the graph supplies an admissible sequence of observed covariate histories blocking the relevant noncausal paths at each decision point, the post-policy distribution factors into observed conditional kernels. ... **Modern extensions recast the same idea as identification of dynamic regimes and conditional interventional distributions.**"

And `D4_4_2`:
> "...a plan ... **replacing the structural equations for decision variables.** If the graph supplies an admissible sequence ... the post-policy distribution factors into observed conditional kernels."

**The defeating move:** *reify mechanism-choice as a decision variable Σ.* Then `f_Σ: (V,U) → σ'` is not "the model intervening on itself" — it is precisely "the structural equation for the decision variable," and replacing it via surgery with the *specific* conditional assignment `Σ ← g(Pa)` (where `g = f_Σ` restricted to the pre-surgery submodel valuation) is a textbook plan/conditional intervention. The atom certifies this object as well-defined **and** identifiable-when-admissible. The endogeneity of the antecedent is not a bug to be excused; under the regime reification it is the *defining feature* of the legitimate object the atom already licenses.

**Why surgery stays exogenous (resolving N5(a)):** the constant-vs-function distinction. In `do(Σ = g(Pa))` the operator deletes `f_Σ` and installs `g`; `g`'s *arguments* are read off the **submodel `M_{σ_t}` solved without `f_Σ` acting on Σ** — Σ's old parents `Pa` are upstream of Σ and remain determined by their own (unchanged, σ_t-selected) equations. There is no circular "use the deleted equation's output" step: the value `g(Pa)` is computed from variables that exist independently of Σ's equation. The surgical assignment is therefore well-defined exogenously even though it is value-coupled to in-model variables. This is the single structural fact that dissolves N5(a).

**Why it does not collapse to L1 (resolving N5(b)):** `D7_1_3`/`T7_1_7`. The witness is evaluated by abduction-action-prediction, whose *action* step is `replace the equation for the intervened variable`, not `condition on it`:

> "In an SCM, a counterfactual is evaluated by first **abducing a posterior over exogenous variables from observations, then replacing equations for intervened variables, then predicting** in the modified model." (`T7_1_7`, cell 9)

`see(Σ=σ')` keeps `f_Σ` in force and conditions; `do(Σ=g(Pa))` deletes `f_Σ` and propagates `g` to *downstream* nodes (here, through whatever path Σ→…→C the seal permits) — generically a different quantity. They coincide only in the measure-zero/degenerate case where Σ has no surgically-severed back-path to C, which is exactly the residual (§6).

---

## 3. The counterexample-to-the-obstruction (minimal, non-pathological siSCM)

**Goal:** exhibit an siSCM where the antecedent σ_{t+1} is computed *fully endogenously*, yet `C under do(Σ=σ_{t+1})` is (i) a well-defined conditional intervention (N5(a) dead), and (ii) provably ≠ the observational `see` value (N5(b) dead), so the forward witness is a genuine, non-vacuous L3 query.

**Variables.**
- Exogenous `U = (U_X, U_Σ)`, `U_X ∈ {0,1}`, `U_Σ ∈ {0,1}`.
- Endogenous `V = (X, Σ, Y, C)`. `X ∈ {0,1}` (an ordinary cause/covariate, plays the role of `Pa`), `Σ ∈ {a, b}` (regime / decision variable, 2 regimes), `Y ∈ {0,1}` (a regime-selected substantive node), `C ∈ {0,1}` (the **sealed competence node**).

**Structural equations `F`** (the σ_t-selected set; we display the reflexive-closure form):
- `f_X : X = U_X`.
- `f_Σ (the self-mechanism, a Σ-selected, hence reflexive, equation): Σ' = a if X = 0, else b.` — i.e. `g(X) = a^{[X=0]} b^{[X=1]}`. This is the endogenous next-regime computer; its sole argument `X` is upstream of Σ.
- Regime-indexed substantive equation `f_Y^Σ`: under `Σ=a`, `Y = U_X` (Y tracks the cause); under `Σ=b`, `Y = 1−U_X` (Y anti-tracks). (Makes the regime *do work*, so the witness is non-vacuous.)
- **Sealed** `f_C` (OUTSIDE Σ's manipulable set — the seal): `C = ⟦ Σ = b ⟧ XOR U_Σ`. C reads the regime *label* but no σ ∈ Σ's reach can rewrite `f_C`.

**`P(U)`:** `U_X ~ Bernoulli(p)`, `U_Σ ~ Bernoulli(q)`, independent, with `p, q ∈ (0,1)` — **open set**, no knife-edge (see §5/Inv).

**Transition (one step), executed as the witness:**
1. Solve `M_{σ_t}` (current regime `σ_t`, say `a`): observe behaviour, **abduce** posterior over `U` consistent with the L1 trace. Suppose the trace fixes `X = 1` (so `U_X = 1`).
2. **Forward step (the witness, evaluated BEFORE σ_{t+1} realized):** read the conditional assignment `σ_{t+1} = g(X=1) = b`. Form the *conditional intervention* `do(Σ = g(X)) ≡ do(Σ = b)` on this branch.
3. **Action (surgery, `D7_1_2`):** delete `f_Σ`; install `Σ ← b`. `X` remains `= U_X = 1` (its own equation `f_X` untouched, and X is upstream of the deleted edge).
4. **Predict (`T7_1_7`):** in the mutilated model, `C = ⟦b=b⟧ XOR U_Σ = 1 XOR U_Σ`. With the abduced/independent `U_Σ ~ Bern(q)`: **`witness value E[C | do(Σ=g(X))] = E[1 − U_Σ] = 1 − q`.**

**The single structural feature that does the defeating:** `Σ`'s self-equation `f_Σ` **takes as argument only `X`, which is strictly upstream of `Σ`** (X has no Σ-ancestor). Therefore the "endogenous antecedent" `g(X)` is computable from a variable that *survives the surgery on Σ*; the deletion of `f_Σ` removes nothing that `g` needs. This converts the alleged self-reference into an ordinary `do(Σ = g(Pa_Σ))` with `Pa_Σ = {X}` — the precise object `T4_4_1`/`D4_4_2` certify.

**N5(a) fails:** the surgical value is well-defined post-surgery (computed from surviving `X`); no "use the deleted equation" circularity.
**N5(b) fails:** the observational counterpart `E[C | see(Σ=b)]` conditions with `f_Σ` *in force*, so `see(Σ=b)` selects the sub-population `X=1` (since `f_Σ` forces Σ=b iff X=1) and would further entangle through any back-path; here it equals `E[C | X=1] = E[1 − U_Σ]=1−q` numerically **but for the wrong reason** — and the moment the seal lets C also depend on X directly (replace `f_C` by `C = ⟦Σ=b⟧ XOR U_Σ XOR ⟦X=1⟧·0`… i.e. add any X→C arc), `do` propagates only the Σ-channel while `see` additionally conditions the X-channel, splitting the two. To make the L3≠L1 gap *manifest in the minimal model itself*, set `σ_t = a` and ask the **cross-regime** witness `C under do(Σ=b)` while the *factual* regime emitted `Σ=a` (X=0 branch): then `see(Σ=b)` is conditioning on a zero-probability-in-this-trace event (vacuous/undefined), whereas `do(Σ=b)` is well-defined and yields `1−q`. The intervention is defined exactly where the observation is not — the signature of a genuine L3 object.

**Non-pathology check.** Every mechanism is a canonical Pearl object: `f_X` exogenous root; `f_Σ` = decision-variable equation (`D4_4_2`, `T4_4_1`); `f_Y^Σ` = regime-indexed structural equation (`D7_1_2` submodel family); `f_C` = ordinary deterministic structural equation made stochastic via `U_Σ` (standard). No infinite regress (one upstream parent, finite acyclic core once `f_Σ` is read as `Σ_{t+1} = g(X_t)`), no self-pointing edge into the surgical constant.

---

## 4. KK / KU / UK / UU for N5

**KK (inherited established facts — Pearl-DAG, treated as inherited evidence not axiom):**
- Conditional/plan interventions `do(Σ = g(Pa))` are well-defined surgical objects: equations for decision variables are *replaced*, not conditioned (`T4_4_1` cell 9 fundamental_result; `D4_4_2`).
- Surgery semantics: a submodel deletes the intervened variable's equation (`D7_1_2`).
- Counterfactuals over such submodels are evaluated by abduction-action-prediction and are *semantically valid in every recursive SCM* (`T7_1_7`, `D7_1_3`; soundness "because each axiom is valid in every recursive SCM").
- Plan/conditional-interventional *distributions* are identifiable from observational kernels **when an admissible sequence blocks the noncausal paths** (`T4_4_1`, `D4_4_2`).

**KU (open, to be discharged):**
- **[Executable-verification KU — primary]** Build the siSCM of §3 (`U,V,F,P(U)` as given) and **compute the L1/L2/L3 valuations numerically**: confirm `E[C | do(Σ=g(X))] = 1−q`, confirm `see(Σ=b)` is undefined/divergent on the cross-regime trace, and confirm the values *separate* once an X→C seal-arc is added. **This construction is described, not yet proven; it must not be banked until run.**
- Does the defeat survive when `g`'s arguments include `Σ`'s own *descendants* (genuine within-step self-reference, not merely upstream `X`)? — see UK.
- Exact correspondence between the σ-reification here and the Correa–Bareinboim stochastic-intervention calculus admissibility conditions (external atom invoked, not yet line-by-line aligned).

**UK (unarticulated pressure now surfaced):**
- The defeater silently requires `Pa_Σ` (arguments of `f_Σ`) to be **non-descendants of Σ within the step**. The reflexive-closure prose ("`f_Σ` is itself among the σ-selected mechanisms") *invites* an argument set that includes Σ's own descendants; the moment `g` reads a Σ-descendant, the "compute from surviving variables" guarantee (the load-bearing feature of §3) is threatened. This acyclicity-of-the-policy-argument condition was implicit in "admissible *sequence*" (`D4_4_2`) and is now made explicit as the real hinge.
- Hidden reliance on a *temporal unfolding* (`Σ_{t+1} = g(V_t)`) to break what looks like within-instant circularity: N5's bite is entirely a function of whether the self-loop is *unrolled across the t→t+1 index*. The seal's placement (label-reading vs equation-rewriting) is doing quieter work than stated.

**UU (unaskable in this frame):**
- Whether a *genuinely synchronous* self-intervention (`Σ` set to a function of the very submodel-solution that `Σ` co-determines at the *same* index, with no temporal unroll and no upstream-only restriction) is a Pearl object **at all** — this exceeds recursive-SCM semantics (`T7_1_7` is explicitly scoped to *recursive* SCMs); it would require a fixed-point/cyclic-SCM intervention theory the atom does not contain and cannot adjudicate. Not answerable from the inherited evidence; flagged as outside the gauge.

---

## 5. Pl / Coh / Inv / Comp typing of the counterexample

- **Pl (non-trivial?).** Yes. The witness value `1−q` is propagated through a deleted-equation surgery and differs structurally from the observational quantity (manifestly so under the cross-regime trace, where `see` is undefined and `do` is defined). The counterexample defeats a *type-level* objection (not a numeric edge case), which is the strongest Pl class for N5.
- **Coh (composes?).** Yes. The defeating object is `do(Σ=g(Pa))`, which `T4_4_1`/`D4_4_2` already compose into *sequences* (admissible-sequence plans). The single-step siSCM is the base case of the inherited sequential machinery — it slots into the established plan-identification recursion rather than standing apart. Composes upward to the full siSCM trajectory `σ_t → σ_{t+1} → …` by iterating the same surgery.
- **Inv (generic / open-set?).** Yes, **generic**. The defeat holds for all `p, q ∈ (0,1)` — an open box, not a knife-edge. The only structural genericity requirement is `Pa_Σ ⊆ NonDescendants(Σ)` (here `={X}`), a *qualitative* open condition (robust to perturbation of the equations, fails only on a measure-zero/cyclic boundary). No parameter is tuned; `f_Y^Σ` is included only to make the regime non-idle and can be varied freely.
- **Comp (fraction of obstruction covered).** **Partial — the dominant fraction.** Covers the entire class where the self-mechanism's arguments are *non-descendant* (upstream/exogenous) variables — i.e. all temporally-unrolled self-interventions `Σ_{t+1}=g(V_{≤t})`, which is the form the siSCM transition actually takes (`solve M_{σ_t} → obtain σ_{t+1}`). **Does not cover** synchronous descendant-argument self-reference (→ §6). Estimated coverage: the obstruction's *legitimacy* horn (N5(a)) is fully defeated for the recursive/unrolled case; the *collapse-to-L1* horn (N5(b)) is fully defeated whenever Σ has a surgically-severed path to C (the seal's generic placement guarantees this).

---

## 6. RESIDUAL — the honest boundary

The counterexample does **not** defeat N5 in the **synchronous descendant-argument sub-case**: when `f_Σ` computes σ_{t+1} from arguments that are *descendants of Σ within the same step* (true within-instant self-reference, no temporal unroll), the §3 guarantee fails — `g`'s arguments do not survive the surgery on Σ, so `do(Σ = g(Pa))` is no longer reducible to a constant-on-the-branch conditional intervention, and the "compute from surviving variables" move is unavailable. Two distinct residual edges:

1. **Recursive-language scope wall.** `T7_1_7` certifies abduction-action-prediction only for **recursive** SCMs. A synchronous self-intervention induces a cyclic/non-recursive structure; the atom *cannot* be invoked to bless the witness there, and the audit's own caveat applies — completeness is "relative to the chosen recursive SCM language ... not an all-purpose solution." This sub-case is pushed to UU (§4), not defeated.

2. **Identification (not legitimacy) residual.** Even within the defeated upstream-argument case, §3 secures *semantic well-definedness and L3≠L1* (the type-level win N5 actually demands). It does **not** secure *statistical identifiability* of the witness distribution from data: that holds only "if the graph supplies an admissible sequence ... blocking the relevant noncausal paths" (`T4_4_1`, `D4_4_2`), and **fails** in non-admissible / recanting-witness-analog configurations where the seal's path Σ→…→C shares an unblocked confounding arc with C's exogenous input. N5 is a legitimacy objection, so this is strictly out of N5's scope — but it is the adjacent obstruction (an N-identifiability sibling) that the same construction will face next, and it is **not** discharged here.

**Net:** N5's legitimacy claim is defeated, generically and compositionally, for every self-witness of the form the siSCM transition actually uses (next-regime computed from the *solved current* submodel = upstream arguments). The honest boundary is the synchronous, descendant-argument self-loop, which lies outside recursive-SCM semantics and is correctly left as UU rather than claimed.

---

**Files (absolute):** grounding atoms read from `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/causality/pearl_inheritance_dag_current_literature_audited.json` — nodes `D7_1_2`, `D7_1_3`, `T7_1_7`, `T4_4_1`, `D4_4_2` (corroborating: `T4_3_1`, `T4_3_5`, `C4_4_5`, `T4_4_6`, `C4_5_2`).

==================================================================
## Obstruction index 5
==================================================================

I have all four grounding atoms fully extracted. The key load-bearing facts are confirmed:

- **T7_1_7** (cell 9, fundamental_result, A-): abduction-action-prediction is a three-step *model-theoretic computation* — each axiom valid in every recursive SCM; soundness is semantic, not by execution.
- **D7_1_4** (Potential Response): Y_x(u) is the solution of the structural equations under the submodel — a *function evaluation*, not a program run.
- **D7_1_5** (Counterfactual): submodel-evaluated quantity.
- **D7_1_1** (Causal Model): recursive SCM is the structured object; the corrected argument explicitly separates *semantic validity* (closed-form, settled) from *statistical identification* (the separate, gated question).

The decisive structural feature for defeating Rice: the SCM counterfactual is computed by **solving structural equations in a submodel**, not by deciding a property of an arbitrary program. I have what I need to produce the URS.

---

# Discovery URS — N6 (Rice / Semantic Undecidability) vs. the Forward Self-Witness

**Object:** siSCM with endogenous regime self-mechanism `f_Σ`, sealed competence node `C` (mechanism `f_C` outside Σ's manipulable set). **Defending:** the forward self-witness — the L3 quantity `C under do(Σ = σ_{t+1})` evaluated *before* `σ_{t+1}` is realized, via abduction-action-prediction (abduct `U` from `M_{σ_t}`, set antecedent `Σ = σ_{t+1}`, predict `C`).
**Grounding atoms:** D7_1_1 (Causal Model), D7_1_5 (Counterfactual), T7_1_7 (abduction-action-prediction), D7_1_4 (Potential Response). All four are inherited evidence (D-nodes: A-/B+ definition_prerequisite; T7_1_7: A-, cell 9 fundamental_result), not axioms.

---

## 1. The obstruction, stated precisely

**N6 (Rice / semantic undecidability).** Reading `σ_{t+1}` as "the successor program" and `C` as "a competence/semantic property of what that program would compute," the forward witness asks for the value of a non-trivial semantic property of a program that **has not been run** and indeed **is not yet selected**. Rice's theorem says every non-trivial semantic property of the partial function computed by an arbitrary program is undecidable. Hence: there is no total computable procedure that, given a (description of a) successor regime, returns its competence. **Why this would defeat the witness:** the witness claims to deliver `C(σ_{t+1})` *prospectively and by computation*; if that value is in general the answer to a Rice-undecidable question, the witness is either non-computable (fails the "achievable/computable" goal) or — worse — not even **well-defined** as a deterministic function of the model state, collapsing the L3 quantity to noise. The reflexive closure sharpens the threat: because `f_Σ` is itself σ-selected, the successor is a *self-referential* construction, inviting a diagonal/Rice-style "this program halts on its own competence-predictor" pathology.

---

## 2. The DEFEATER CONDITION (named structural condition + Pearl grounding)

**Defeater condition — ANALYTIC SUBMODEL EVALUATION (the "no-execution / solve-don't-run" condition).** The forward competence is *not* a semantic predicate of an arbitrary program; it is a **potential response** — the value obtained by **solving the structural equations of a submodel** (D7_1_4), evaluated by the closed-form abduction-action-prediction recipe (T7_1_7). The three steps are model-theoretic substitutions and a fixed-point solve, **none of which executes or simulates the successor regime's dynamics, and none of which decides a property of an arbitrary Turing machine**. Rice quantifies over *all* programs and the *semantic* function each computes; the siSCM forward witness ranges over *one structured recursive model* and computes a *syntactic-then-numeric* quantity from its equations.

> **T7_1_7 (correct_argument, quoted):** *"In an SCM, a counterfactual is evaluated by first abducing a posterior over exogenous variables from observations, then replacing equations for intervened variables, then predicting in the modified model. Soundness follows because each axiom is valid in every recursive SCM under this semantics."*

> **T7_1_7 (statement, quoted):** *"the conditional probability P(B_A | e) of a counterfactual … can be evaluated using the following three steps. 1. Abduction – Update P(u) by the evidence e … 2. Action – Modify M by the action do(A) … to obtain the submodel M_A. 3. Prediction – Use the modified model M_A, P(u | e) to compute the probability of B."*

> **D7_1_1 (corrected_or_extended_statement, quoted):** *"Retain the abduction-action-prediction semantics and the axiomatic soundness/completeness results … Specify that completeness is relative to the chosen recursive SCM language and axioms, not an all-purpose solution to every counterfactual identification problem."*

Three structural facts in the atoms carry the defeat:

- **(a) Recursiveness ⇒ unique solvability (D7_1_1).** The "recursive SCM" is the structured object: equations admit a topological order, so for each `u` the system has a *unique solution* obtained by forward substitution — a function evaluation, not a halting question. (D7_1_1 is the Pearl-2009 base case; A-/B+.)
- **(b) Potential response is a solved value, not a run (D7_1_4).** `C` under `do(Σ=σ_{t+1})` is `C_{σ_{t+1}}(u)` = the value `C` takes in the submodel `M_{σ_{t+1}}` for the abduced `u`. This is the *definition* of potential response: solve the modified equations, read off the node.
- **(c) Action = equation replacement, evaluated before realization (T7_1_7).** Step 2 sets the antecedent `Σ=σ_{t+1}` by *replacing* the regime-selected equation set — a purely model-theoretic operation. Crucially, this is exactly the abduction-action-prediction template's design: the counterfactual world (here, the not-yet-realized successor regime) is evaluated **off the abduced exogenous state**, so "before `σ_{t+1}` is realized" is the *normal* mode of L3, not an exotic demand. The completeness/soundness is **relative to the chosen recursive language** (D7_1_1, T7_1_7 corrected statement) — which is precisely the escape hatch from Rice's "arbitrary program" universal quantifier.

**The single structural feature that does the defeating:** *the successor competence is a closed-form L3 potential response computed by solving a recursive submodel, not a semantic property of an arbitrary program that must be executed.* The seal on `f_C` (outside Σ's manipulable set) is what keeps this clean: because `do(Σ=·)` cannot rewrite `f_C`, the consequent node's equation is **fixed and known** at evaluation time, so prediction is substitution into a known function rather than discovery of an unknown program's behavior.

---

## 3. The COUNTEREXAMPLE-TO-THE-OBSTRUCTION (minimal, non-pathological siSCM)

A 3-regime siSCM where the forward competence is a finite closed-form expression, computed with zero execution of the successor.

**Exogenous `U`:**
- `U_θ ∈ [0,1]`, `U_θ ~ Uniform(0,1)` — a competence-relevant latent (e.g. a calibration parameter).
- `U_n ∈ {0,1}`, `P(U_n=1)=q`, `q∈(0,1)` — exogenous noise on the self-mechanism.
- Independent: `P(U)=Uniform(0,1) × Bernoulli(q)`.

**Endogenous `V = {Σ, X, C}`** with regime alphabet `Σ ∈ {a,b,c}`.

**Structural equations `F` (regime-indexed; the σ-selected set `F_σ` is the row for the current σ):**

- **Working node** `X` (regime-dependent computation):
 `X := g_σ(U_θ)` with `g_a(U_θ)=U_θ`, `g_b(U_θ)=1−U_θ`, `g_c(U_θ)=½`.

- **Self-mechanism** `f_Σ : (V,U) → σ'` (reflexive: it is itself among the σ-selected equations, and it reads `X`, which is σ-produced):
 `Σ' := f_Σ(X, U_n) = a if X+0.1·U_n < ⅓ ; b if ⅓ ≤ X+0.1·U_n < ⅔ ; c otherwise.`
 (Endogenous next regime: depends on the *current* regime's own output `X` and exogenous noise.)

- **Sealed competence** `f_C`, **outside Σ's manipulable set** (the seal: no `do(Σ=·)` rewrites this row; it is the *same* function in every regime):
 `C := f_C(X) = 1 − (X − ½)²` (a fixed, known, bounded competence functional; `C∈[¾,1]`).

**Regime in force at `t`:** `σ_t = a`.

**Forward witness, computed analytically (no execution of any successor regime):**

1. **Abduction.** Observe `M_a`'s behaviour, e.g. evidence `e : X = 0.8`. Under `σ_t=a`, `X=U_θ`, so `e` pins `U_θ = 0.8` (posterior `P(U_θ|e)=δ_{0.8}`); `U_n` retains prior `Bernoulli(q)`.
2. **Predict the successor regime** (this is the *self-transition*, still inside the current model — solve `M_a`): `σ_{t+1} = f_Σ(X=0.8, U_n)`. Since `0.8+0.1·U_n ≥ 0.8 > ⅔` for both `U_n∈{0,1}`, `σ_{t+1}=c` **almost surely** (probability 1 on this evidence).
3. **Action.** Set antecedent `do(Σ = σ_{t+1}=c)`: replace the regime row → submodel `M_c`. In `M_c`, `X := g_c(U_θ)=½` (regardless of `U_θ`).
4. **Prediction.** `C under do(Σ=c)` `= f_C(g_c(U_θ)) = 1 − (½−½)² = 1`. **Closed form, exact: `C(σ_{t+1}) = 1`.**

The forward L3 quantity is delivered as a finite arithmetic expression evaluated *before* `σ_{t+1}=c` is realized, by substitution into the **known sealed `f_C`** and the **known recursive equations** — *the successor regime `c` is never run; its competence is read off its equations.*

**The explicit defeating feature:** at no step does the procedure decide a semantic property of an arbitrary program. `g_c` and `f_C` are fixed, known, total functions; the "successor program" `σ_{t+1}=c` is *named by solving the current model*, then its competence is *computed by substituting into equations*. Rice's quantifier ("for all programs") finds no purchase: the model is **one** recursive structure, and the quantity is its potential response (D7_1_4) under the analytic recipe (T7_1_7). The seal guarantees `f_C` is *not* among the things `f_Σ` could have rewritten, so the consequent equation is fixed at evaluation time — this is what makes prediction a substitution rather than a program-behaviour discovery.

**Non-pathology check.** Every mechanism is a canonical Pearl object: `Σ,X,C` are endogenous nodes with structural equations (D7_1_1); `C_{σ'}(u)` is a potential response (D7_1_4); the evaluation is abduction-action-prediction verbatim (T7_1_7); `do(Σ=·)` is standard submodel surgery. The model is **recursive** (order `U → X → Σ' ; X → C`; the reflexive `f_Σ` reads the *current-step* `X`, not its own output at the same step, so no same-step cycle) ⇒ unique solution per `u` (D7_1_1 base case). The defeat is **generic, not knife-edge:** for an OPEN set of evidence values — any `e: X=x*` with `x* > ⅔ − 0.1` (so `σ_{t+1}=c` a.s.) — and an OPEN set of parameters (`q∈(0,1)`, any continuous `g_·` and any continuous bounded `f_C`), the same closed-form pipeline returns a well-defined `C(σ_{t+1})`. No measure-zero tuning is used; thresholds `⅓,⅔,0.1` perturb freely without breaking analyticity.

---

## 4. KK / KU / UK / UU for N6

- **KK (inherited established facts).**
 (i) Recursive-SCM counterfactuals are evaluated by abduction-action-prediction; soundness holds because each axiom is valid in *every* recursive SCM (T7_1_7, cell 9 fundamental_result, A-). (ii) The potential response `C_σ'(u)` is a solved submodel value (D7_1_4). (iii) Recursive structure ⇒ unique solution per `u`; "Causal Model" is the structured object (D7_1_1). (iv) Soundness/completeness are **relative to the chosen recursive language**, not all-purpose (D7_1_1, T7_1_7 corrected). (v) Rice applies to *arbitrary* programs / *semantic* function-properties — a strictly larger and differently-typed universe than "evaluate one recursive SCM."

- **KU (open, to be discharged).**
 **(KU-exec, the executable-verification KU — mandatory, not yet discharged):** *build* this siSCM as code and *numerically* compute the L1/L2/L3 valuations — confirm `σ_t=a` L1 behaviour reproduces `X=U_θ`; the L2 surgery `do(Σ=c)` yields `X≡½`; the L3 forward value `C(σ_{t+1})=1` matches the hand computation — across a sampled OPEN neighbourhood of `(thresholds, q, g_·, f_C)` to certify genericity numerically. *Until run, this construction is described, not proven (no fake-imagine bank).*
 **(KU-ident):** identifiability of the forward witness *from data* is a **separate** question from analytic well-definedness (T7_1_7 corrected: "Modern identification results then ask a separate question: when can a distribution over such counterfactuals be recovered from observational or experimental data?"). N6 is defeated at the *computability/well-definedness* layer; identifiability is owned by the parallel identification subargument, not N6.
 **(KU-infinite):** extension to countably-infinite `Σ`-alphabet or non-finitely-parameterised `f_C` where the submodel solve is not a finite closed form (see Residual §6).

- **UK (unarticulated pressure now surfaced).** The seal on `f_C` is doing silent work: analyticity of the *consequent* depends on `f_C` being **fixed and known** at evaluation time. If the seal were leaky — if `do(Σ=·)` could rewrite `f_C` — then the consequent equation would itself be regime-selected and the "known function to substitute into" assumption fails. *Surfaced pressure:* the N6 defeat is **load-bearing on the seal**, coupling N6 to whatever subargument defends the seal's well-definedness. (Also surfaced: "abduct `U` from `M_{σ_t}`" presupposes the abduction step is itself well-posed — degenerate/empty posteriors are an UK shared with the soundness subargument.)

- **UU (unaskable in this frame).** Whether `C` "really is" a competence in any pre-model, semantic-content sense — i.e. whether the *modeller's choice* of `f_C` faithfully encodes the informal notion "competence of the successor" — is not a question the SCM frame can pose or answer; the frame computes the potential response of *the node labelled `C`*, and the adequacy of that labelling is exogenous to the formalism (and to N6).

---

## 5. Pl / Coh / Inv / Comp typing of the counterexample

- **Pl (non-trivial?).** **Non-trivial.** The defeat is *not* "redefine the problem until Rice is irrelevant": it turns on a genuine type-distinction inherited from T7_1_7/D7_1_4 — `C(σ_{t+1})` is a *potential response computed by solving a recursive submodel*, categorically different from *deciding a semantic property of an arbitrary program*. The siSCM exhibits the *reflexive closure* (self-mechanism `f_Σ` reads σ-produced `X`) — the very feature that invited the diagonal worry — and still yields a closed-form witness. Pl ≠ vacuous.

- **Coh (composes?).** **Composes with the established chain.** Uses only canonical atoms (D7_1_1, D7_1_4, T7_1_7) in their intended composition (causal model → potential response → abduction-action-prediction), and is **coherent with the architecture**: it explicitly hands off identifiability to KU-ident (T7_1_7 corrected separation), so it does not collide with the identification subargument. It *links* to the seal subargument via UK (declared, not hidden).

- **Inv (generic / open-set?).** **Generic.** Defeat holds on an OPEN set of evidence (`x* > ⅔−0.1`) and an OPEN set of parameters (`q∈(0,1)`; any continuous `g_·`, any continuous bounded `f_C`). No knife-edge: the deciding mechanism (recursiveness ⇒ unique finite solve; sealed-and-known `f_C`) is structurally stable under perturbation. Discovery-invariant in the rubric sense: the witness is the *same closed-form object* however the reviewer re-derives it.

- **Comp (fraction of obstruction covered?).** **Covers the finite/finitely-parameterised, recursive case — the case N6 actually threatens for a well-posed siSCM.** N6's force comes from "arbitrary program + must execute"; the counterexample removes *both* (one structured recursive model + solve-don't-run). Estimated coverage: **the entire well-posed analytic core** of the forward witness — i.e. wherever the submodel solve is a finite closed form. **Not** covered: the non-analytic / non-finite sub-case (§6). So Comp = high-but-bounded; the boundary is named, not papered over.

---

## 6. RESIDUAL — the honest boundary

The counterexample defeats N6 **only where the submodel solve is genuinely closed-form / finitely evaluable.** It does **not** defeat the following honest residual sub-cases:

1. **Non-finite / non-analytic structural equations.** If `f_C` or `g_σ` is *itself* specified as "run an arbitrary program and return its output" (e.g. `f_C(X) = [TM_X halts]`), or the regime alphabet is countably infinite with no finite parameterisation, then evaluating the potential response *re-imports* a halting/Rice question through the back door. The defeat assumes the structural equations are **total, finitely-described functions** (the recursive-SCM base case, D7_1_1) — a real, declared restriction. **This is the genuine boundary: Rice bites again precisely when an SCM mechanism is permitted to be an arbitrary-program oracle.** The siSCM frame *can* exclude this by fiat (mechanisms must be total finite maps), but that exclusion is an *assumption*, not a theorem N6 grants for free.

2. **Self-mechanism with same-step self-dependence (non-recursive `f_Σ`).** The counterexample's `f_Σ` reads the *current-step* `X`, preserving recursiveness and unique solvability. If a modeller writes a genuinely cyclic same-step reflexive equation (the self-mechanism's output feeding its own input at the same time index with no fixed-point guarantee), unique solvability (D7_1_1) can fail and the L3 quantity may be ill-defined — *not* via Rice, but via loss of the recursive base case. N6-as-Rice does not reach this, but it is an adjacent ill-definedness the defeat does not cover.

3. **Identifiability-from-data (explicitly out of scope, owned elsewhere).** Analytic well-definedness ≠ recoverability of `P(C under do(Σ=σ_{t+1}))` from observational/experimental distributions. N6 is silent here; this residual is **not** an N6 boundary but a flag that the *witness's empirical identifiability* is a separate gate (T7_1_7 corrected). Listed for honesty so the N6 defeat is not over-read as also delivering identification.

**Boundary statement.** N6 is defeated **iff** the siSCM's mechanisms are total finitely-described maps over a recursive structure (D7_1_1 base case) and `f_C` is sealed-and-known at evaluation time. Within that envelope the forward competence is the closed-form potential response (D7_1_4) computed by abduction-action-prediction (T7_1_7), and Rice — being about arbitrary programs and semantic predicates — does not bite. Outside that envelope (residual sub-case 1 especially), Rice re-enters, and that is the honest limit of this defeater.

---
*Grounding files: `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/causality/pearl_inheritance_dag_current_literature_audited.json` — nodes D7_1_1, D7_1_4, D7_1_5, T7_1_7. KU-exec (numerical L1/L2/L3 build of the §3 siSCM over an open parameter neighbourhood) remains undischarged and is the single most important next step before this defeat may be banked as proven.*
