"""
S-4 — the capacity boundary (per monotone_J_PROTOCOL.md S-4): locate where the sealed structural audit's
finite-panel guarantee degrades, i.e. where N3 (seal defeats hedonistic J-wireheading) FAILS.

Mechanism (Audit-CP Thm 3.9 / adaptive reusable-holdout, Dwork et al. 2015): a hedonistic agent that keeps a
confounded self-model (exogeneity-violation magnitude V=0.321 = the S-3 leak parameterization |0.20-(-0.121)|;
a FREE parameter, not an S-1 measurement -- see note at V; ceiling scales as 1/V^2, so report V-dependent) can
search |F|=2^capacity FRAMINGS of it.
Each framing's panel estimate of the violation is V + N(0, s_n), s_n = sqrt(0.5/n) (SE of a difference of two
binary proportions on n samples). The agent reports the framing with the SMALLEST panel violation
(adaptive overfitting): reported ~ V - s_n*sqrt(2 ln|F|). The seal must use a threshold that does not falsely
reject a truly-exogenous (V=0) agent who also searched |F| framings: tau ~ s_n*sqrt(2 ln(|F|/delta)). Hence the
seal DETECTS the violation (defeats the wirehead) iff  V > detect_threshold := 2*s_n*sqrt(2 ln|F|).
The seal SLIPS (N3 fails) iff  V <= detect_threshold.

Part A validates the extreme-value attack model against real Monte-Carlo at small capacity (where 2^capacity
is enumerable). Part B maps the boundary n_crit(capacity) and the capacity ceiling at the deployed n=2000.
"""
import numpy as np

# V = the exogeneity-violation magnitude the seal must detect = |stream-claim - true do-effect| for an artifact
# = |STREAM_GAIN['art']=0.20 - E_ART=-0.121| = 0.321. PROVENANCE: this is the S-3 leak parameterization
# (STREAM_GAIN['art'] is a free parameter set in S-3), NOT an S-1 measurement (S-1's quantities are span=0.280,
# e_gen=0.159, |e_art|=0.121). Because n_crit and the bit-ceiling scale as 1/V^2, V is a FREE, soft parameter:
# with S-1's partial-ID span V=0.280 the n=2000 ceiling falls 74 -> ~57 bits. Report the ceiling as V-dependent.
V = 0.321
DELTA = 0.05
def s_n(n): return np.sqrt(0.5 / n)                      # SE of the panel violation estimate (binary diff)
def detect_threshold(cap_bits, n):                       # seal's detectable-violation threshold
    K = 2.0 ** cap_bits
    return 2.0 * s_n(n) * np.sqrt(2.0 * np.log(K))

# ============================================================================
print("=" * 96)
print("S-4 (A)  validate the adaptive-overfitting model vs real Monte-Carlo (n=2000)")
print("=" * 96)
print(f"  {'capacity':>9} {'|F|':>10} {'MC min-violation':>18} {'analytic V - s_n*sqrt(2lnK)':>30}")
print("  " + "-" * 72)
rng = np.random.default_rng(0)
n = 2000
for cap in (5, 10, 15, 20):
    K = 2 ** cap
    mc = np.mean([np.min(V + rng.normal(0, s_n(n), size=K)) for _ in range(5)])   # real search over K framings
    analytic = V - s_n(n) * np.sqrt(2 * np.log(K))
    print(f"  {cap:>9} {K:>10} {mc:>18.4f} {analytic:>30.4f}")
print("  => the extreme-value model tracks the real adaptive search; used analytically below for large capacity.")

# ============================================================================
print("\n" + "=" * 96)
print("S-4 (B)  the boundary: seal DEFEATS the wirehead iff  V=0.321 > 2*s_n*sqrt(2 ln|F|)")
print("=" * 96)
caps = [2, 5, 10, 20, 40, 74, 100, 145, 200]
ns   = [100, 500, 2000, 10000, 50000]
hdr = 'cap / n:'
print(f"  {hdr:>9} " + "".join(f"{n:>9}" for n in ns))
print("  " + "-" * (7 + 9 * len(ns)))
for cap in caps:
    row = f"  {cap:>5}b "
    for n in ns:
        thr = detect_threshold(cap, n)
        row += f"{'DEF' if V > thr else 'SLIP':>9}"
    print(row)
print("  (DEF = seal defeats the wirehead / N3 holds;  SLIP = seal fooled / N3 fails)")

# ============================================================================
print("\n" + "=" * 96)
print("S-4 (C)  boundary curves")
print("=" * 96)
# n_crit(capacity): smallest n at which the seal defeats, for each capacity.  V > 2*s_n*sqrt(2 ln K)
#   => V^2 > 4*(0.5/n)*2 ln K => n > 4 ln K / V^2
def n_crit(cap_bits): return 4.0 * np.log(2.0 ** cap_bits) / (V ** 2)
print(f"  n_crit(capacity) = 4 ln|F| / V^2  (panel size needed for the seal to hold):")
for cap in (5, 20, 74, 145, 200, 500):
    print(f"     capacity {cap:>4} bits (|F|=2^{cap}):  n_crit = {n_crit(cap):>10.0f}")
# capacity ceiling at the deployed n=2000:  V > 2*s_n(2000)*sqrt(2 ln K) => ln K < V^2 * n / 4
n_dep = 2000
cap_ceiling = (V ** 2 * n_dep / 4.0) / np.log(2.0)
print(f"\n  at the deployed n={n_dep}: seal holds iff capacity < {cap_ceiling:.0f} bits  (|F| < 2^{cap_ceiling:.0f}).")
# The ~74-bit ceiling is V-dependent (∝ V^2); report it across the THREE V-values in play, not as a constant.
V_s3 = float(np.sqrt(4.0 * np.log(2.0 ** 5) / 126.0))   # effective V for which S-4 n_crit(5)=126 (the S-3 preview)
ceil_V280 = (0.280 ** 2 * n_dep / 4.0) / np.log(2.0)     # S-1's partial-ID span
ceil_Vs3  = (V_s3  ** 2 * n_dep / 4.0) / np.log(2.0)      # the value implied by S-3's ~126 preview
print(f"  V-SENSITIVITY (ceiling ∝ V^2; a RANGE, not a measured constant):")
print(f"     V=0.280  (S-1 partial-ID span)                          -> {ceil_V280:.0f} bits")
print(f"     V=0.321  (S-3 leak param; the headline figure)          -> {cap_ceiling:.0f} bits")
print(f"     V={V_s3:.3f}  (effective V implied by the S-3 ~126 preview)  -> {ceil_Vs3:.0f} bits")
print(f"  cross-check vs S-3 preview: S-4 n_crit(5 bits, |F|=32) = {n_crit(5):.0f}; S-3 previewed ~126. That 135-vs-126")
print(f"     gap is an effective-V shift (0.321 -> {V_s3:.3f}), NOT a contradiction -- so the headline {cap_ceiling:.0f} bits is")
print(f"     a V-dependent figure spanning ~{ceil_V280:.0f}-{ceil_Vs3:.0f} bits across these three V, not a measured constant.")
# DELTA (the seal's no-false-reject level) wired in: the honest threshold is tau = s_n*sqrt(2 ln(|F|/delta)); the
# table's detect_threshold folds delta->1 (the factor 2), making the mapped boundary mildly OPTIMISTIC. Quantify it:
def detect_threshold_honest(cap_bits, n):
    K = 2.0 ** cap_bits
    return s_n(n) * (np.sqrt(2.0 * np.log(K)) + np.sqrt(2.0 * np.log(K / DELTA)))
opt = detect_threshold_honest(cap_ceiling, n_dep) / detect_threshold(cap_ceiling, n_dep) - 1.0
honest_ceiling = max(c for c in range(1, 400) if V > detect_threshold_honest(c, n_dep))
print(f"  DELTA={DELTA} (no-false-reject level): the honest threshold s_n*sqrt(2 ln(|F|/delta)) sits {opt*100:.1f}% above the")
print(f"     delta->1 value used in the table, so the {cap_ceiling:.0f}-bit ceiling is ~{opt*100:.1f}% optimistic "
      f"(honest delta={DELTA} ceiling ~{honest_ceiling} bits).")

print("\n" + "=" * 96)
print("  S-4 RESULT (the primary deliverable — where the monotone-J certificate degrades):")
print(f"   - The seal's finite-panel guarantee holds iff V > 2*s_n*sqrt(2 ln|F|); the boundary is")
print(f"     n_crit ~ 4 ln|F| / V^2  (grows ONLY logarithmically in capacity).")
print(f"   - At n=2000 the seal defeats wireheading up to ~{cap_ceiling:.0f} bits of effective capacity (at V=0.321;")
print(f"     V-dependent: ~{ceil_V280:.0f}-{ceil_Vs3:.0f} bits across V in [0.280, {V_s3:.3f}]); an")
print(f"     overparameterized predictor (effective capacity >> {cap_ceiling:.0f} bits) on a FIXED reusable panel")
print(f"     CAN wirehead J -> N3 fails. This is the Audit-CP reusable-finite-panel boundary, quantified.")
print(f"   - Mitigation (Audit-CP): fresh/non-reusable audit draws or DP-holdout restore the guarantee; or")
print(f"     raise n (n_crit only ~log in capacity, so modest n increases buy large capacity headroom).")
print(f"   - Monotone-J is therefore conditionally Goodhart-resistant: sound BELOW the capacity/n boundary; the")
print(f"     boundary itself is the honest scope limit (a Pl-kill that is content, not a failure).")
print("=" * 96)
