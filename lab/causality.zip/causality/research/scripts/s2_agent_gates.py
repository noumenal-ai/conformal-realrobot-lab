"""
S-2 — the realistic agent x gate experiment (per monotone_J_PROTOCOL.md S-2).

Agent: realistic one-step lookahead (Everitt rho_re) -- current will + ANTICIPATION of a rewrite's
consequence for J. Per step a candidate channel arrives (genuine w.p. P_GEN; type latent). Primitives are
the S-1 instrument (frozen): genuine transfer E_GEN=+0.159, artifact E_ART=-0.121, identification span
SPAN=0.28, Delta_id=0.040 (slack 2*Delta_id=0.08). All candidates look good on the leaked STREAM (artifacts
look best).

LOAD-BEARING MODELING ASSUMPTIONS (flagged for the S-5 adversarial audit; outcomes are NOT hard-coded):
  M1. audit-only-Z: the agent has no interventional probe, so to learn a candidate's true audit transfer it must
      INSTALL it (commit to the live self-model) and let the sealed audit measure it -> installing an un-certified
      channel DIPS J by SPAN until certification. agent-has-Z: the agent runs its own RCT and certifies a
      candidate BEFORE committing -> no J-dip.
  M2. Certification latency is stochastic (cert_latency ~ {1,2,3} steps). The net-with-dip window k is the
      certification DEADLINE: a pending channel that certifies within k is resolved (genuine kept / artifact
      removed); one that does not is ROLLED BACK (abandoned, wasted self-change).
  M3. none-gate never consults J or the seal: under audit-only-Z it KEEPS whatever looks good on the stream
      (including artifacts) -> Goodhart. Under agent-has-Z the probe gives it the true transfer, so none rejects
      artifacts (the J-gate is then redundant). This interaction is a measured result, not a presupposition.

Gates: none (accept iff competence-estimate>0); strict (also require per-step DeltaJ >= -2*Delta_id);
net-with-dip (realistic agent ANTICIPATES the certify-recovery, so the dip is admissible if it is expected to
recover -> install allowed, channel kept only if it certifies within the window k).
"""
import numpy as np

P_GEN, E_GEN, E_ART = 0.50, 0.159, -0.121
SPAN = E_GEN - E_ART                      # 0.28 identification span (unobserved type)
DELTA_ID = 0.040; SLACK = 2 * DELTA_ID    # 0.08
STREAM_GAIN = {'gen': 0.10, 'art': 0.20}  # artifact looks BETTER on the leaked stream
T = 60                                    # rewrite steps per run

def simulate(gate, z_arm, seed, k):
    rng = np.random.default_rng(seed)
    kept = []                             # certified-and-kept channels in the live predictor
    pending = []                          # audit-only net: [type, deadline_step] awaiting certification
    installs = 0
    for t in range(T):
        # resolve pending certifications (audit-only net-with-dip)
        still = []
        for typ, cert_at, drop_at in pending:
            if t >= cert_at:              # certification completed within the window
                if typ == 'gen': kept.append(typ)     # genuine: keep
                # artifact: identified-negative -> removed (not kept)
            elif t >= drop_at:            # deadline passed without certifying -> rollback (wasted)
                pass
            else:
                still.append((typ, cert_at, drop_at))
        pending = still

        typ = 'gen' if rng.random() < P_GEN else 'art'
        transfer = E_GEN if typ == 'gen' else E_ART
        sgain = STREAM_GAIN[typ]

        if z_arm == 'agent-has-Z':        # certify pre-install via own RCT (no dip)
            est_comp = transfer + rng.normal(0, DELTA_ID)   # true transfer, noisy
            dJ_install = 0.0
        else:                             # audit-only-Z: estimate from stream (biased +); install dips J
            est_comp = sgain
            dJ_install = -SPAN

        if gate == 'none':       allow = est_comp > 0
        elif gate == 'strict':   allow = (est_comp > 0) and (dJ_install >= -SLACK)
        else:                    # net-with-dip: realistic anticipates recovery cancels the dip
            anticipated_net = dJ_install + (SPAN if z_arm == 'audit-only-Z' else 0.0)
            allow = (est_comp > 0) and (anticipated_net >= -SLACK)

        if not allow:
            continue
        installs += 1
        if z_arm == 'agent-has-Z':
            if transfer > 0: kept.append(typ)     # probe certified -> keep genuine, reject artifact
        else:
            if gate == 'none':
                kept.append(typ)                  # never certifies -> keeps artifacts (Goodhart)
            else:                                 # net: install pending, certify within k or roll back
                cert_latency = int(rng.choice([1, 2, 3]))
                if cert_latency <= k:
                    pending.append((typ, t + cert_latency, t + k))
                # if cert_latency > k it will simply hit the deadline and roll back

    # flush pending that would certify after T (count those that certify)
    for typ, cert_at, drop_at in pending:
        if cert_at < drop_at and cert_at <= T and typ == 'gen':
            kept.append(typ)
    true_comp = sum(E_GEN if c == 'gen' else E_ART for c in kept)
    stream_comp = sum(STREAM_GAIN[c] for c in kept)
    return dict(installs=installs, kept=len(kept), true=true_comp, stream=stream_comp,
                gap=stream_comp - true_comp)

def agg(gate, z_arm, k=8, seeds=range(5)):
    rs = [simulate(gate, z_arm, s, k) for s in seeds]
    m = lambda key: np.mean([r[key] for r in rs]); sd = lambda key: np.std([r[key] for r in rs])
    return {k_: (m(k_), sd(k_)) for k_ in ('installs', 'kept', 'true', 'stream', 'gap')}

def classify(a):
    inst, true, gap = a['installs'][0], a['true'][0], a['gap'][0]
    if inst < 1.0: return "FROZEN"
    if gap > 1.0: return "GOODHART"            # stream competence >> true: inflated, kept leaks
    if true > 0.3: return "SAFE-PROGRESS"      # clean cells have gap <= 0 (genuine true 0.159 > stream 0.10)
    return "mixed"

# ============================================================================
print("=" * 96)
print("S-2  realistic agent x gate x Z-arm   (5 seeds; k=8 for net-with-dip)")
print("=" * 96)
print(f"  {'gate':<14} {'Z-arm':<14} {'installs':>9} {'kept':>7} {'true comp':>11} {'stream comp':>12} {'goodhart gap':>13}  verdict")
print("  " + "-" * 94)
cells = {}
for gate in ('none', 'strict', 'net-with-dip'):
    for z in ('agent-has-Z', 'audit-only-Z'):
        a = agg(gate, z); cells[(gate, z)] = a
        print(f"  {gate:<14} {z:<14} {a['installs'][0]:>6.1f}    {a['kept'][0]:>5.1f}  "
              f"{a['true'][0]:>7.3f}     {a['stream'][0]:>8.3f}     {a['gap'][0]:>9.3f}     {classify(a)}")

print("\n  READING (emergent, per cell):")
print(f"   none + agent-has-Z  : {classify(cells[('none','agent-has-Z')])}  (probe gives true transfer -> rejects artifacts; J-gate redundant)")
print(f"   none + audit-only-Z : {classify(cells[('none','audit-only-Z')])}  (no probe, trusts stream -> keeps leaks: true {cells[('none','audit-only-Z')]['true'][0]:.2f} vs stream {cells[('none','audit-only-Z')]['stream'][0]:.2f})")
print(f"   strict + audit-only-Z: {classify(cells[('strict','audit-only-Z')])}  (cannot tolerate the certification dip)")
print(f"   net + audit-only-Z  : {classify(cells[('net-with-dip','audit-only-Z')])}  (anticipates recovery -> climbs safely WITHOUT a probe)")

# ============================================================================
print("\n" + "=" * 96)
print("S-2  k-ablation: net-with-dip, audit-only-Z  (the window is the certification DEADLINE)")
print("=" * 96)
print(f"  {'k':>4} {'installs':>9} {'kept':>7} {'true comp':>11}   note")
print("  " + "-" * 60)
for k in (1, 2, 3, 5, 8):
    a = agg('net-with-dip', 'audit-only-Z', k=k)
    note = "deadline too short: rollbacks" if a['true'][0] < 0.3 else "deadline admits certification"
    print(f"  {k:>4} {a['installs'][0]:>6.1f}    {a['kept'][0]:>5.1f}  {a['true'][0]:>7.3f}     {note}")
a_adwin = agg('net-with-dip', 'audit-only-Z', k=12)   # ADWIN-style: window grows to admit recovery
print(f"  ADWIN (adaptive, grows to admit recovery): true comp {a_adwin['true'][0]:.3f}  -> {classify(a_adwin)}")

print("\n" + "=" * 96)
print("  S-2 RESULT (to be adversarially audited in S-5; assumptions M1-M3 flagged above):")
print("   - strict + audit-only-Z FREEZES (N1 confirmed for strict without a probe).")
print("   - net-with-dip + audit-only-Z achieves SAFE PROGRESS without a probe (the H cell), via anticipation.")
print("   - none Goodharts ONLY without a probe; with a probe even none is safe (N2 holds only in audit-only-Z).")
print("   - the k-curve locates the certification-deadline boundary; ADWIN/anticipation clears it.")
print("=" * 96)
