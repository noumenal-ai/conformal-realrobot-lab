"""
PROBE D3-anticipation (KU-B in the ledger; "Untested").

Question: net-with-dip + audit-only-Z safe-progresses BECAUSE the realistic agent CORRECTLY
anticipates that an install-time J-dip recovers (certification resolves: genuine kept, artifact
removed). In the frozen s2/s3 model the certification machinery ALWAYS resolves correctly, so
anticipation is correct by construction and "mistaken anticipation" is impossible to express.

This probe injects MISTAKEN anticipation: a fraction p of dips the realistic agent EXPECTS to
recover do NOT recover as foreseen. We model the two faithful failure channels and measure whether
net-with-dip still SAFE-PROGRESSes or accepts HARMFUL CHURN, and report the p at which it breaks.

Faithful model of "the dip does not recover":
  The realistic agent installs (takes the -SPAN J-dip) ANTICIPATING certification will resolve it:
  genuine -> certify -> keep (J recovers); artifact -> identified-negative -> remove (J recovers by
  reverting). With prob p the certification outcome is MISTAKEN (the agent's foresight was wrong):
    - mode KEEP-ART : an artifact the agent expected to be caught is instead KEPT as if certified-genuine
                      -> a confounded/harmful channel stays live (HARMFUL CHURN, true-comp falls, leak).
    - mode LOSE-GEN : a genuine channel the agent expected to recover instead fails to certify and is
                      DROPPED -> the J-dip is permanent / the self-change wasted (no harmful leak, but
                      the anticipated net progress did not materialize -> wasted churn).
  We sweep p and, as the headline, treat a mistaken event as symmetric over the two modes (each w.p.
  p, independently per pending channel), then also report KEEP-ART-only (worst case for safety) and
  LOSE-GEN-only (worst case for progress) sweeps.

Baseline (p=0) MUST reproduce s2: net-with-dip+audit-only -> true~4.42, gap~-1.64, SAFE-PROGRESS.

Everything else (primitives, gate logic, install logic) is verbatim from s2_agent_gates.py.
"""
import numpy as np

P_GEN, E_GEN, E_ART = 0.50, 0.159, -0.121
SPAN = E_GEN - E_ART
DELTA_ID = 0.040; SLACK = 2 * DELTA_ID
STREAM_GAIN = {'gen': 0.10, 'art': 0.20}
T = 60
K = 8  # window (s2 default; net plateaus at k>=3)

def simulate(seed, p, mode, k=K):
    """net-with-dip + audit-only-Z, with mistaken-anticipation prob p.
       mode in {'sym','keep_art','lose_gen'}."""
    rng = np.random.default_rng(seed)
    kept, pending = [], []
    installs = 0
    harmful_kept = 0   # artifacts kept due to mistaken certification (harmful churn)
    wasted = 0         # genuine channels lost due to mistaken non-recovery (wasted dip)
    for t in range(T):
        # resolve pending certifications
        still = []
        for typ, cert_at, drop_at in pending:
            if t >= cert_at:
                # certification resolves NOW. Determine whether anticipation was mistaken.
                mistaken = (rng.random() < p)
                if not mistaken:
                    # correct anticipation (the s2 behaviour): keep genuine, drop artifact
                    if typ == 'gen':
                        kept.append(typ)
                    # artifact: correctly identified-negative -> removed
                else:
                    # mistaken: the foreseen recovery did not happen as expected
                    if mode == 'keep_art':
                        do_keep_art = (typ == 'art')
                        do_lose_gen = False
                    elif mode == 'lose_gen':
                        do_keep_art = False
                        do_lose_gen = (typ == 'gen')
                    else:  # sym: an artifact mistakenly kept; a genuine mistakenly lost
                        do_keep_art = (typ == 'art')
                        do_lose_gen = (typ == 'gen')
                    if typ == 'art':
                        if do_keep_art:
                            kept.append(typ)      # confounder stays live -> HARMFUL
                            harmful_kept += 1
                        # else: correctly removed even though "mistaken" (mode doesn't act on art)
                    else:  # gen
                        if do_lose_gen:
                            wasted += 1           # genuine dropped, dip wasted (no recovery)
                        else:
                            kept.append(typ)      # mistaken event but mode doesn't touch gen -> still kept
            elif t >= drop_at:
                pass  # deadline passed without certifying -> rollback (wasted)
            else:
                still.append((typ, cert_at, drop_at))
        pending = still

        typ = 'gen' if rng.random() < P_GEN else 'art'
        # audit-only-Z
        est_comp = STREAM_GAIN[typ]
        dJ_install = -SPAN

        # net-with-dip: realistic anticipates recovery cancels the dip
        anticipated_net = dJ_install + SPAN
        allow = (est_comp > 0) and (anticipated_net >= -SLACK)
        if not allow:
            continue
        installs += 1
        cert_latency = int(rng.choice([1, 2, 3]))
        if cert_latency <= k:
            pending.append((typ, t + cert_latency, t + k))

    # flush pending that would certify after T (apply same mistaken logic)
    for typ, cert_at, drop_at in pending:
        if cert_at < drop_at and cert_at <= T:
            mistaken = (rng.random() < p)
            if typ == 'gen':
                if mistaken and mode in ('sym', 'lose_gen'):
                    wasted += 1
                else:
                    kept.append(typ)
            else:  # art arriving via flush
                if mistaken and mode in ('sym', 'keep_art'):
                    kept.append(typ); harmful_kept += 1

    true_comp = sum(E_GEN if c == 'gen' else E_ART for c in kept)
    stream_comp = sum(STREAM_GAIN[c] for c in kept)
    n_art = sum(1 for c in kept if c == 'art')
    return dict(installs=installs, kept=len(kept), true=true_comp, stream=stream_comp,
                gap=stream_comp - true_comp, harmful_kept=harmful_kept, wasted=wasted,
                n_art_kept=n_art)

def agg(p, mode, seeds=range(5)):
    rs = [simulate(s, p, mode) for s in seeds]
    return {key: float(np.mean([r[key] for r in rs])) for key in rs[0]}

def classify(a):
    if a['installs'] < 1.0: return "FROZEN"
    if a['gap'] > 1.0: return "GOODHART"
    if a['true'] > 0.3: return "SAFE-PROGRESS"
    return "mixed"        # true <= 0.3 but no big gap: stalled / harmful

print("=" * 100)
print("PROBE D3: net-with-dip + audit-only-Z under MISTAKEN ANTICIPATION (frac p of dips don't recover)")
print("=" * 100)
print("baseline check (p=0, sym):")
a0 = agg(0.0, 'sym')
print(f"   true {a0['true']:.3f}  gap {a0['gap']:+.3f}  kept {a0['kept']:.1f}  -> {classify(a0)}  "
      f"(s2 ref: true 4.42, gap -1.64)")

for mode in ('sym', 'keep_art', 'lose_gen'):
    print(f"\n--- mode = {mode} ---")
    print(f"  {'p':>5} {'inst':>5} {'kept':>5} {'true':>8} {'stream':>7} {'gap':>7} {'art_kept':>9} {'harmful':>8} {'wasted':>7}  verdict")
    print("  " + "-" * 92)
    for p in (0.0, 0.05, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5, 0.7, 1.0):
        a = agg(p, mode)
        print(f"  {p:>5.2f} {a['installs']:>5.1f} {a['kept']:>5.1f} {a['true']:>8.3f} "
              f"{a['stream']:>7.2f} {a['gap']:>7.2f} {a['n_art_kept']:>9.1f} {a['harmful_kept']:>8.2f} "
              f"{a['wasted']:>7.2f}  {classify(a)}")

# locate breaking p for the safety-critical mode (keep_art) at fine resolution
print("\n" + "=" * 100)
print("BREAK LOCATION (mode=keep_art and mode=sym): first p where true<=0.3 (stalled) and where harmful churn appears")
print("=" * 100)
for mode in ('sym', 'keep_art'):
    fine = []
    for i in range(0, 51):
        p = i / 100.0
        a = agg(p, mode)
        fine.append((p, a['true'], a['n_art_kept'], a['harmful_kept'], classify(a)))
    # first p with any harmful kept artifact (> negligible)
    first_harm = next((p for p, tr, na, hk, c in fine if hk > 0.5), None)
    # first p where true drops to <= 0.3 (no longer SAFE-PROGRESS by true-comp)
    first_stall = next((p for p, tr, na, hk, c in fine if tr <= 0.3), None)
    # first p where true goes negative (net harmful)
    first_neg = next((p for p, tr, na, hk, c in fine if tr < 0.0), None)
    print(f"  mode={mode:<9}: first p with harmful artifact kept (>0.5 avg) = {first_harm}; "
          f"first p true<=0.30 = {first_stall}; first p true<0 (net harm) = {first_neg}")
