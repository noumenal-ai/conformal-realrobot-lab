"""
ITERABILITY of the siSCM forward witness  +  ADVERSARIAL VACUITY AUDIT (noological-urs RESTRICT mode).
Fixed KK = the audited Pearl DAG. No grammar expansion: every check cites an established Pearl result and
FIRES if a program is vacuous (tautological / degenerate / falsely-identified / knife-edge).
"""
import warnings; warnings.filterwarnings("ignore")
import numpy as np, copy
from scipy.optimize import linprog
from itertools import product

# ---------- reused exact machinery (Balke-Pearl IV bounds + confounded ground truth) ----------
TYPES = list(product([0, 1], repeat=4))
def Xr(t, z): return t[0] if z == 0 else t[1]
def Yr(t, x): return t[2] if x == 0 else t[3]
def bp_bounds(P):                       # bounds on W=P(Y_{X=1}=1) from observed P[z][x][y]
    A, b = [], []
    for z in (0, 1):
        for x in (0, 1):
            for y in (0, 1):
                A.append([1.0 if (Xr(t, z) == x and Yr(t, x) == y) else 0.0 for t in TYPES]); b.append(P[z][x][y])
    A.append([1.0] * 16); b.append(1.0)
    c = np.array([1.0 if t[3] == 1 else 0.0 for t in TYPES])
    lo = linprog(c, A_eq=A, b_eq=b, bounds=[(0, 1)] * 16, method="highs")
    hi = linprog(-c, A_eq=A, b_eq=b, bounds=[(0, 1)] * 16, method="highs")
    return (lo.fun, -hi.fun) if (lo.success and hi.success) else None
def gt(eps, base=0.30, effect=0.30, cs=0.8):
    def pX1(z, h): return (1 - eps) * z + eps * h
    def pY1(x, h): return min(1, max(0, base + effect * x + eps * cs * (h - 0.5)))
    P = [[[0., 0.], [0., 0.]] for _ in range(2)]
    for z in (0, 1):
        for h in (0, 1):
            for x in (0, 1):
                px = pX1(z, h) if x else 1 - pX1(z, h)
                for y in (0, 1):
                    P[z][x][y] += 0.25 * px * (pY1(x, h) if y else 1 - pY1(x, h))
        s = sum(P[z][x][y] for x in (0, 1) for y in (0, 1))
        for x in (0, 1):
            for y in (0, 1): P[z][x][y] /= s
    trueW = sum(0.5 * min(1, max(0, base + effect + eps * cs * (h - 0.5))) for h in (0, 1))
    return P, trueW

# ================================ PART A — ITERABILITY ================================
print("=" * 88); print("PART A  — ITERABILITY of the multi-step forward witness (sigma_t -> ... -> sigma_{t+k})"); print("=" * 88)
def match(s, t): return 1 if s == t else 0
def Wk_dec(seq, typ, q): return q if all(match(s, typ) for s in seq) else 0.0   # competence = survive ALL k matches, then luck
p, q = 0.4, 0.7
print("  (1) DECOUPLED composition (exact, point-valued):")
for typ in (0, 1):
    for seq, lab in [([typ] * 4, "all-match plan"), ([typ, typ, 1 - typ, typ], "one mismatch @step3")]:
        print(f"      abduced type={typ}  plan={seq} [{lab}] -> W_4 = {Wk_dec(seq, typ, q):.3f}")
print("      => composes cleanly; point-valued; depends on the FULL plan AND the abduced type; bounded in [0,q].")
print("  (2) COUPLED width(k): single-step retention interval [a,b] (Balke-Pearl at strength eps), survival = prod_k:")
for eps in (0.10, 0.20):
    a, b = bp_bounds(gt(eps)[0])
    print(f"      eps={eps}: per-step retention [a,b]=[{a:.3f},{b:.3f}] (width {b-a:.3f})")
    for k in (1, 2, 4, 8):
        lo, hi = (a ** k) * q, (b ** k) * q
        print(f"          k={k}: W_k in [{lo:.4f},{hi:.4f}]  width={hi-lo:.4f}")
print("      => width SHRINKS with k (product of probabilities, bounded in [0,1]).  NO horizon explosion.")
print("  (3) CONTRAST — the failure mode AVOIDED (a likelihood-RATIO witness explodes geometrically):")
for eps in (0.10, 0.20):
    a, b = bp_bounds(gt(eps)[0])
    print(f"      eps={eps}: ratio (b/a)^k  ->  k=1:{(b/a):.2f}  k=4:{(b/a)**4:.2f}  k=8:{(b/a)**8:.2f}")
print("      => the RATIO explodes; our PROBABILITY witness does not. Iterability holds *because* the witness is a")
print("         bounded probability, not a reweighting ratio (cf. P1 rollout-horizon multiplicative compounding).")

# ============================ PART B — ADVERSARIAL VACUITY AUDIT ============================
print(); print("=" * 88); print("PART B  — ADVERSARIAL VACUITY AUDIT  (RESTRICT mode; Pearl-DAG KK as the fixed yardstick)"); print("=" * 88)
fired = []
def check(name, passed, kk):
    tag = "PASS (not vacuous)" if passed else "FIRE !! VACUOUS"
    if not passed: fired.append(name)
    print(f"  [{tag:18}] {name}\n        KK: {kk}")

# P1 — the witness must VARY (else tautology)
vals = {Wk_dec(seq, typ, q) for typ in (0, 1) for seq in ([0, 0, 0, 0], [1, 1, 1, 1], [0, 1, 0, 1])}
check("P1  witness varies with type & plan", len(vals) > 1,
      "a counterfactual that never varies with its antecedent is not a causal effect (D7_1_5 Counterfactual)")

# P2 — do != see (genuine intervention, not conditioning)
P, trueW = gt(0.3)
PXY = [[sum(0.5 * P[z][x][y] for z in (0, 1)) for y in (0, 1)] for x in (0, 1)]
see1 = PXY[1][1] / (PXY[1][0] + PXY[1][1])
check("P2  do(X=1) != see(X=1)", abs(trueW - see1) > 1e-3,
      "if do=see the quantity is L1, not L2/L3 (CHT Thm 1; EXT_ID_DO_CALCULUS_COMPLETE)")

# P3 — abduction MATTERS (genuine L3, not L2): risky self-mod witness keys on the abduced type
risky = {Wk_dec([1], typ, q) for typ in (0, 1)}
check("P3  abduction matters (L3 content, not L2)", len(risky) > 1,
      "L3 does not reduce to L2 generically (CHT Thm 1)")

# P4 — interval strictly inside [0,1] at small coupling (informative, not vacuous)
a, b = bp_bounds(gt(0.10)[0])
check("P4  interval ⊊ [0,1] at small coupling", (b - a) < 0.5 and a > 0.0 and b < 1.0,
      "a [0,1] Balke-Pearl bound is vacuous (EXT_IV_PARTIAL_IDENTIFICATION; T9_2_10 sharpness)")

# P5 — the LP is GENUINELY CONSTRAINED by the data. Two correct sub-tests (the earlier probe perturbed the
#   Z=0,X=1 cell, NON-BINDING here since X=1 is rare under Z=0 -> a FALSE-POSITIVE; diagnosed and corrected):
#   (5a) the data narrows the trivial [0,1] substantially; (5b) perturbing a BINDING cell (Z=1,X=1) moves bounds.
P0, _ = gt(0.20); b0 = bp_bounds(P0)
narrow = (b0[1] - b0[0]) < 0.5
Pp = copy.deepcopy(P0); Pp[1][1][1] = min(1, Pp[1][1][1] + 0.08); Pp[1][1][0] = max(0, Pp[1][1][0] - 0.08)
s = sum(Pp[1][x][y] for x in (0, 1) for y in (0, 1))
for x in (0, 1):
    for y in (0, 1): Pp[1][x][y] /= s
b1 = bp_bounds(Pp)
moves = b1 is not None and abs(b1[0] - b0[0]) + abs(b1[1] - b0[1]) > 1e-3
print(f"        [diag] width(0.20)={b0[1]-b0[0]:.3f} (<<1 => narrows [0,1]); binding-cell perturb moved bounds by "
      f"{(abs(b1[0]-b0[0])+abs(b1[1]-b0[1])) if b1 else 0:.3f}")
check("P5  LP genuinely constrained (data narrows [0,1] AND a binding-cell perturbation moves the bounds)",
      narrow and moves,
      "identification is a function of the observed distribution (do-calculus completeness; T9_2_10 sharpness)")

# P6 — GENERIC on an open set (not a knife-edge)
rng = np.random.default_rng(0); ok = 0; N = 200
for _ in range(N):
    e = rng.uniform(0.01, 0.30); bb = bp_bounds(gt(e)[0])
    if bb and 0 < (bb[1] - bb[0]) < 0.99: ok += 1
check(f"P6  generic on an OPEN set ({ok}/{N} random eps give informative bounds)", ok > 0.95 * N,
      "the CHT 'almost-all / measure-zero exceptions' standard; OCOF/DICE non-pathology screen")

# P7 — RESPECTS the CHT non-identification boundary (kill the instrument => MUST return a wide interval)
Pn, _ = gt(0.30)
avg = [[sum(0.5 * Pn[z][x][y] for z in (0, 1)) for y in (0, 1)] for x in (0, 1)]   # symmetrize over z => Z carries no info
Pnoiv = [[[avg[x][y] for y in (0, 1)] for x in (0, 1)] for _ in (0, 1)]
bw = bp_bounds(Pnoiv)
check("P7  respects CHT non-id boundary (no instrument => wide interval, not false point-ID)",
      bw is not None and (bw[1] - bw[0]) > 0.3,
      "L3/L2 do not reduce from lower-layer data without identifying structure (CHT Thm 1; EXT_ID)")

print()
print("AUDIT RESULT:", "ALL PROBES PASS — no vacuity detected." if not fired
      else f"VACUITY FOUND in: {fired}  (Pl-kill — content).")
