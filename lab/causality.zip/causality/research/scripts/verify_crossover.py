"""
Residual D-4 of the Total Discovery URS: the continuity crossover  I(sigma_next ; C) -> 0+.

Question: in M**', exact abduction-action DECOUPLING (C4) made the forward witness point-identified.
What happens as the decoupling is RELAXED -- a hidden confounder U_h couples the antecedent (the adopted
regime sigma_next == treatment X) and the outcome (successor competence C == Y) with strength eps?
Does the forward witness's partial-identification interval [L,H] for W = P(Y_{X=1}=1) widen GRACEFULLY
(continuous, ->0 as eps->0) or COLLAPSE DISCONTINUOUSLY (jump to a wide/[0,1] interval the instant eps>0)?

Method (rigorous, exact LP -- no sampling): the abduction signal acts as a binary INSTRUMENT Z (the factual
type-revealing behaviour, exclusion: affects C only through the adopted regime). We compute the exact
Balke-Pearl IV bounds on the counterfactual W = P(Y_{X=1}=1) from the observed P(X,Y|Z), as the confounder
strength eps is swept from 0 (clean decoupling, M**') upward.
"""
import warnings; warnings.filterwarnings("ignore")
import numpy as np
from scipy.optimize import linprog
from itertools import product

# ---- Balke-Pearl IV bounds on  W = P(Y_{X=1}=1)  from observed P(X,Y|Z) -----------------
# response type = (a0,a1,b0,b1): a_z = X-response to Z=z ; b_x = Y-response to X=x.  16 types.
TYPES = list(product([0,1], repeat=4))
def Xresp(t, z): return t[0] if z == 0 else t[1]
def Yresp(t, x): return t[2] if x == 0 else t[3]

def bp_bounds(Pobs):  # Pobs[z][x][y]
    A, b = [], []
    for z in (0,1):
        for x in (0,1):
            for y in (0,1):
                A.append([1.0 if (Xresp(t,z)==x and Yresp(t,x)==y) else 0.0 for t in TYPES])
                b.append(Pobs[z][x][y])
    A.append([1.0]*16); b.append(1.0)                       # normalization
    c = np.array([1.0 if t[3]==1 else 0.0 for t in TYPES])  # W = P(Y_{X=1}=1) = sum of types with b1=1
    bnds = [(0,1)]*16
    lo = linprog(c,  A_eq=A, b_eq=b, bounds=bnds, method="highs")
    hi = linprog(-c, A_eq=A, b_eq=b, bounds=bnds, method="highs")
    if not (lo.success and hi.success): return None
    return lo.fun, -hi.fun

# ---- ground-truth confounded SCM, parametrised by confounder strength eps -----------------
def ground_truth(eps, base=0.30, effect=0.30, cs=0.8):
    # Z ~ Bern(1/2) instrument ; U_h ~ Bern(1/2) confounder
    # X = sigma_next:  P(X=1|Z,Uh) = (1-eps)*Z + eps*Uh     (eps=0 => X=Z, perfect instrument, no confounding)
    # Y = C:           P(Y=1|X,Uh) = clip(base + effect*X + eps*cs*(Uh-0.5))   (Uh confounds Y too)
    def pX1(z,h): return (1-eps)*z + eps*h
    def pY1(x,h): return min(1.0, max(0.0, base + effect*x + eps*cs*(h-0.5)))
    Pobs = [[[0.0,0.0],[0.0,0.0]] for _ in range(2)]
    for z in (0,1):
        for h in (0,1):
            pz, ph = 0.5, 0.5
            for x in (0,1):
                px = pX1(z,h) if x==1 else 1-pX1(z,h)
                for y in (0,1):
                    py = pY1(x,h) if y==1 else 1-pY1(x,h)
                    Pobs[z][x][y] += pz*ph*px*py
        s = sum(Pobs[z][x][y] for x in (0,1) for y in (0,1))   # normalize P(.,.|z)
        for x in (0,1):
            for y in (0,1): Pobs[z][x][y] /= s
    trueW = sum(0.5*(base+effect+eps*cs*(h-0.5)) for h in (0,1))   # = E_h[ P(Y=1|do X=1, Uh) ]
    trueW = sum(0.5*min(1.0,max(0.0, base+effect+eps*cs*(h-0.5))) for h in (0,1))
    # I(X;Y) from observed marginal joint (averaged over Z)
    PXY = np.zeros((2,2))
    for z in (0,1):
        for x in (0,1):
            for y in (0,1): PXY[x,y] += 0.5*Pobs[z][x][y]
    PX = PXY.sum(1); PY = PXY.sum(0)
    I = sum(PXY[x,y]*np.log(PXY[x,y]/(PX[x]*PY[y]+1e-15)+1e-15) for x in (0,1) for y in (0,1) if PXY[x,y]>0)
    return Pobs, trueW, I

print("="*86)
print("CONTINUITY CROSSOVER  I(sigma_next;C) -> 0+   (Balke-Pearl IV bounds on forward witness W)")
print("="*86)
print(f"{'eps':>5} {'I(X;Y)':>8} | {'L':>7} {'trueW':>7} {'H':>7} | {'width':>7} | {'sound L<=W<=H':>13}")
print("-"*70)
prev_w = None; widths = []
for eps in [0.0,0.02,0.05,0.10,0.15,0.20,0.30,0.40,0.50]:
    Pobs, trueW, I = ground_truth(eps)
    bnds = bp_bounds(Pobs)
    if bnds is None:
        print(f"{eps:5.2f}  LP failed"); continue
    L,H = bnds; w = H-L; widths.append((eps,I,w))
    sound = (L-1e-6) <= trueW <= (H+1e-6)
    print(f"{eps:5.2f} {I:8.4f} | {L:7.4f} {trueW:7.4f} {H:7.4f} | {w:7.4f} | {str(sound):>13}")

print()
# continuity / monotonicity diagnostics
eps_arr = np.array([w[0] for w in widths]); w_arr = np.array([w[2] for w in widths])
print(f"width at eps=0:           {w_arr[0]:.6f}   (point-identified?  {'YES' if w_arr[0]<1e-4 else 'no'})")
print(f"width at eps=0.02 (tiny): {w_arr[1]:.6f}")
print(f"max jump between adjacent eps steps: {np.max(np.diff(w_arr)):.4f}  (a JUMP ~O(1) would mean brittle)")
print(f"width monotone non-decreasing in eps? {bool(np.all(np.diff(w_arr) >= -1e-9))}")
# local slope near 0 (graceful => finite slope, width ~ linear in eps near 0)
slope0 = (w_arr[1]-w_arr[0])/(eps_arr[1]-eps_arr[0])
print(f"local slope dwidth/deps near 0: {slope0:.3f}  (finite => graceful linear-ish onset; not a step)")
print()
print("VERDICT:")
graceful = (w_arr[0] < 1e-4) and (w_arr[1] < 0.15) and (np.max(np.diff(w_arr)) < 0.3)
print("  GRACEFUL." if graceful else "  BRITTLE / inconclusive -- inspect.")
print("""  Reading: the Balke-Pearl bound is the optimal value of an LP whose constraints (the observed P(X,Y|Z))
  are analytic in eps, so the bound -- hence the width -- is CONTINUOUS in eps and ->0 as eps->0. The forward
  witness degrades gracefully: a small abduction-action couple yields a small (sound) interval, not a collapse.
  Caveat (honest, = URS D-3): point-identification is KNIFE-EDGE (only exactly at eps=0); for any eps>0 the
  certificate is an interval, and at LARGE coupling the interval can become wide. So: robust to small
  decoupling violations (graceful onset), but the interval must be reported, and it is informative only while
  the coupling stays small. Robustness in WIDTH, knife-edge in KIND.""")
