# Honest recomputation: the forward-witness cross-world content is PNS-type
#   PNS_fwd = P( C_{do(adopt B)} = 1 , C_{do(stay A)} = 0 )   ("competent if I adopt B, not if I stay").
# Pearl DAG KK: under exogeneity it is an INTERVAL (T9_2_10 sharp bounds); a POINT only under monotonicity (T9_2_14).
print("alpha=P(C|do B), beta=P(C|do A) | PNS interval [LB,UB] (T9_2_10) width | monotone point (T9_2_14)")
print("-"*86)
for a,b in [(0.70,0.30),(0.60,0.50),(0.90,0.20),(0.55,0.45)]:
    LB=max(0.0,a-b); UB=min(a,1.0-b); mono=a-b
    print(f"  alpha={a:.2f} beta={b:.2f}        | [{LB:.3f},{UB:.3f}]  width={UB-LB:.3f}          | {mono:.3f}")
print()
print("VERDICT (honest): the genuine forward witness 'adopting B would make me competent (and staying would not)'")
print("is an INTERVAL (T9_2_10) in general; it is a POINT only under monotonicity (T9_2_14) -- which is exactly")
print("the monotone seal M**' silently assumed. Drop that crutch and the point-identified headline reverts to a")
print("sound but interval-valued certificate. Achievable = interval, not point; point only on the measure-zero")
print("(exogenous + monotone) knife-edge. This is consistent with the CHT intuition (L3 doesn't reduce to a point).")
