"""
tsem.py  -- a FAITHFUL implementation of Gladyshev, Alechina & Logan 2026,
"Temporal Causal Models as a Model of Computation" (arXiv:2605.06292).

Implements the paper's definitions VERBATIM (not a hand-rolled echo):
  Def 1  TSEM:  signature S=(V,R,D); structural equations F_Y : prod_{X in D(Y)} R(X) -> 2^{R(Y)}  (SET-valued).
  Def 2  Computation: tree of configurations; v1 ->_M v2 iff for all X, v2[X] in F_X(v1|D(X)).
  Def 3  (standard/atomic) intervention do(Y^n <- y): fixes a VALUE at step n only.
  Def 11 STRUCTURE intervention do(Y^n(X=x) <- y): rewrites the structural EQUATION via dynamic
         equations F^i (override at the specified step, INHERIT F^{i-1} otherwise).

Then it REPRODUCES two results from the paper as a witness of fidelity:
  (A) the Section-2 non-deterministic counter  F_X(x) = {9} if x=9 else {0, x+1};
  (B) the Section-6 example: F_X(x)=1; a STANDARD intervention cannot enforce X=0 for all i>0,
      but a STRUCTURE intervention (rewrite F_X to constant 0) does -- the paper's exact claim
      that "structure interventions are not expressible in terms of standard interventions".
"""
from itertools import product

# ============================================================================
# Def 1  --  TSEM
# ============================================================================
class TSEM:
    """Signature S=(V,R,D) + structural equations F (Def 1)."""
    def __init__(self, V, R, D, F):
        self.V = list(V)                 # variables
        self.R = {y: frozenset(R[y]) for y in V}   # range function R(Y)
        self.D = {y: tuple(D[y]) for y in V}       # domain function D(Y) (vars whose PREVIOUS values determine Y)
        self.F = dict(F)                 # F[Y] : tuple(parent values in D(Y) order) -> frozenset(subset of R(Y))

    def _parents(self, config, y):
        return tuple(config[x] for x in self.D[y])

    # ---- Def 2: the transition relation v1 ->_M v2 (set of successor configs) ----
    def successors(self, config):
        """All v2 with v2[X] in F_X(v1|D(X)) for every X (Def 2)."""
        per_var = [sorted(self.F[y](self._parents(config, y))) for y in self.V]
        return [dict(zip(self.V, combo)) for combo in product(*per_var)]

    # ---- Def 2: the computation tree C (reachable configs by depth) ----
    def computation(self, v0, depth):
        """Returns levels[0..depth]; each level is the SET of configs reachable at that step."""
        levels = [[dict(v0)]]
        frontier = [dict(v0)]
        for _ in range(depth):
            nxt, seen = [], set()
            for c in frontier:
                for s in self.successors(c):
                    key = tuple(sorted(s.items()))
                    if key not in seen:
                        seen.add(key); nxt.append(s)
            levels.append(nxt); frontier = nxt
        return levels

# ============================================================================
# Def 3  --  standard / atomic intervention  do(Y^n <- y)   (fixes a VALUE at step n)
# ============================================================================
def standard_intervention_run(M, v0, depth, interventions):
    """interventions: dict {(Y, n): y}. Deterministic single-successor run (we take the
    deterministic branch; for the Sec-6 example F returns singletons so the run is a path)."""
    traj = [dict(v0)]
    # apply step-0 interventions to the initial config
    cur = dict(v0)
    for (Y, n), y in interventions.items():
        if n == 0: cur[Y] = y
    traj[0] = cur
    for i in range(1, depth + 1):
        prev = traj[-1]
        nxt = {}
        for y in M.V:
            vals = sorted(M.F[y](tuple(prev[x] for x in M.D[y])))
            nxt[y] = vals[0]                      # deterministic branch
        for (Y, n), val in interventions.items():  # Def 3: override the VALUE at step i only
            if n == i: nxt[Y] = val
        traj.append(nxt)
    return traj

# ============================================================================
# Def 11  --  STRUCTURE intervention  do(Y^n(X=x) <- y)   (rewrites the EQUATION)
# ============================================================================
class StructureIntervention:
    """Def 11. overrides: dict {(Y, n, input_tuple): frozenset(new values)}.
    Dynamic equation F^i_Y(input): the override with the largest n' <= i if present, else original F
    (override at step n', INHERIT for later steps -- exactly Def 11's F^i = F^{i-1} otherwise)."""
    def __init__(self, M, overrides):
        self.M = M
        self.ov = {}
        for (Y, n, inp), val in overrides.items():
            self.ov.setdefault((Y, inp), {})[n] = frozenset(val)

    def F_i(self, Y, i, input_tuple):
        steps = self.ov.get((Y, input_tuple))
        if steps:
            applicable = [n for n in steps if n <= i]
            if applicable:
                return steps[max(applicable)]
        return self.M.F[Y](input_tuple)            # inherit the original equation

    def run(self, v0, depth):
        """Computation under the dynamic equations: C^I(i) = prod_X F^i_X(C^I(i-1)|D(X)) for i>0."""
        traj = [dict(v0)]
        for i in range(1, depth + 1):
            prev = traj[-1]; nxt = {}
            for y in self.M.V:
                inp = tuple(prev[x] for x in self.M.D[y])
                nxt[y] = sorted(self.F_i(y, i, inp))[0]   # deterministic branch
            traj.append(nxt)
        return traj


# ============================================================================
# WITNESS (A) -- Section-2 non-deterministic counter
# ============================================================================
def witness_counter():
    print("=" * 84)
    print("WITNESS (A): Gladyshev Sec.2 counter   F_X(x) = {9} if x=9 else {0, x+1}")
    print("=" * 84)
    R = {"X": set(range(10))}
    F = {"X": (lambda t: frozenset({9}) if t[0] == 9 else frozenset({0, t[0] + 1}))}
    M = TSEM(["X"], R, {"X": ["X"]}, F)
    levels = M.computation({"X": 0}, depth=6)
    for i, lv in enumerate(levels):
        vals = sorted({c["X"] for c in lv})
        print(f"   step {i}:  reachable X in {vals}")
    # the paper's stated dynamics: branch to {0, x+1} until 9, which is absorbing
    succ0 = sorted({c["X"] for c in M.successors({"X": 0})})
    succ9 = sorted({c["X"] for c in M.successors({"X": 9})})
    ok = (succ0 == [0, 1]) and (succ9 == [9])
    print(f"   F_X(0) = {succ0}  (expect [0, 1]);   F_X(9) = {succ9}  (expect [9], absorbing)")
    print(f"   non-determinism present (|successors(0)|=2): {len(M.successors({'X':0})) == 2}")
    print(f"   >>> counter reproduced: {ok}")
    return ok

# ============================================================================
# WITNESS (B) -- Section-6: standard CANNOT enforce X=0 for i>0; structure CAN
# ============================================================================
def section6_trajectories(depth=6):
    """The Sec-6 example F_X(x)=1, returning (free, standard-do, structure-do) X-trajectories.
    Reusable (no printing) so the identity check can consume the structure trajectory."""
    R = {"X": {0, 1}}
    F = {"X": (lambda t: frozenset({1}))}          # constant rule F_X(x)=1
    M = TSEM(["X"], R, {"X": ["X"]}, F)
    free = [c["X"] for c in [lvl[0] for lvl in M.computation({"X": 1}, depth)]]
    std  = [c["X"] for c in standard_intervention_run(M, {"X": 1}, depth, {("X", 0): 0})]
    # STRUCTURE intervention: rewrite F_X so that for input x in {0,1}, F_X(x)={0}, from step 0 on
    si = StructureIntervention(M, {("X", 0, (0,)): {0}, ("X", 0, (1,)): {0}})
    struct = [c["X"] for c in si.run({"X": 1}, depth)]
    return free, std, struct

def witness_section6(depth=6):
    print("\n" + "=" * 84)
    print("WITNESS (B): Gladyshev Sec.6   F_X(x)=1.  Goal: enforce (X=0) in C(i) for all i>0.")
    print("=" * 84)
    free, std, struct = section6_trajectories(depth)

    print(f"   free run            X_0..X{depth} = {''.join(map(str, free))}   (F_X=1 => all 1)")
    print(f"   standard do(X^0=0)  X_0..X{depth} = {''.join(map(str, std))}   (0 then REVERTS to 1: cannot enforce)")
    print(f"   structure do(F_X<-0)X_0..X{depth} = {''.join(map(str, struct))}   (X=0 for all i>0: ENFORCED)")

    std_post    = std[1:]                       # X_i for i>0
    struct_post = struct[1:]
    std_fails    = any(x == 1 for x in std_post)        # standard does NOT keep X=0
    struct_works = all(x == 0 for x in struct_post)     # structure DOES keep X=0
    ok = std_fails and struct_works
    print(f"   standard fails to enforce X=0 for i>0 : {std_fails}")
    print(f"   structure enforces X=0 for i>0        : {struct_works}")
    print(f"   >>> Sec.6 'structure != standard' reproduced: {ok}")
    return ok, struct

if __name__ == "__main__":
    a = witness_counter()
    b, _ = witness_section6()
    print("\n" + "=" * 84)
    print(f"TSEM FIDELITY (Gladyshev): counter={a}  section6={b}  ALL={'PASS' if a and b else 'FAIL'}")
    print("=" * 84)
