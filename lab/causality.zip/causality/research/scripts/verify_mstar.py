"""
Executable verification of the unified counterexample M** for the siSCM forward self-witness.
Authoritative layer: EXACT enumeration over the finite exogenous space (U_self, U_pred) in {0,1}^2.
Cross-check layer:    DoWhy gcm (categorical/classifier mechanisms -> fit -> interventional_samples).

M** (matches the Total Discovery URS table):
  exogenous  U_self ~ Bern(p),  U_pred ~ Bern(q),  independent
  regime     Sigma in {0=A, 1=B}      (factual regime at t is A=0)
  f_X        X = U_self XOR Sigma          (A: X=U_self ; B: X=1-U_self)
  f_Sigma    Sigma_next = X                (B if X=1 else A)            -- the reflexive self-mechanism
  f_C        C = X AND U_pred              (SEALED: reads (X,U_pred), regime-invariant in form)
Forward self-witness  W := C under do(Sigma=Sigma_next), abducting from the factual A-behaviour.
"""
import warnings
warnings.filterwarnings("ignore")

def pr(us, up, p, q):
    return (p if us else 1 - p) * (q if up else 1 - q)

def exact(p, q):
    PX1 = p
    PC1 = sum(pr(us, up, p, q) for us in (0, 1) for up in (0, 1) if ((us ^ 0) & up))
    def doC1(s):
        return sum(pr(us, up, p, q) for us in (0, 1) for up in (0, 1) if (((us ^ s) & up) == 1))
    L2A, L2B = doC1(0), doC1(1)
    beta = {1: q, 0: 0.0}                  # current-C reading (URS): intervention inert on witnessed C
    beta_marg = PX1 * q
    persistent = {1: 0.0, 0: 0.0}          # genuine-L3 successor, persistent type: degenerate
    fresh = {1: (1 - p) * q, 0: p * q}     # successor, fresh noise: == L2, abduction inert
    return dict(PX1=PX1, PC1=PC1, L2A=L2A, L2B=L2B, beta=beta, beta_marg=beta_marg,
                persistent=persistent, fresh=fresh)

print("=" * 90)
print("EXACT ENUMERATION over (U_self,U_pred) in {0,1}^2  (gold standard, no sampling)")
print("=" * 90)
hdr = f"{'(p,q)':>11} | {'L1 P(C)':>8} {'L2 do(A)':>9} {'L2 do(B)':>9} | {'beta X=1':>9} {'beta marg':>9} | {'persist':>8} {'fresh X=1':>9}"
print(hdr); print("-" * len(hdr))
grid = [(0.3, 0.7), (0.5, 0.5), (0.2, 0.9), (0.8, 0.4), (0.6, 0.6)]
for p, q in grid:
    r = exact(p, q)
    print(f"({p:.2f},{q:.2f}) | {r['PC1']:8.4f} {r['L2A']:9.4f} {r['L2B']:9.4f} | "
          f"{r['beta'][1]:9.4f} {r['beta_marg']:9.4f} | {r['persistent'][1]:8.4f} {r['fresh'][1]:9.4f}")

print()
print("CHECK (iv) do != see :  factual regime A=0 w.p.1 => P(Sigma=B)=0 => see(Sigma=B) conditions on a")
print("           probability-zero event (UNDEFINED) while do(Sigma=B) is defined. do != see holds.  [C5 ok]")
for p, q in [(0.3, 0.7)]:
    andB = sum(pr(us, up, p, q) for us in (0,1) for up in (0,1) if (((us ^ 1) & up) == 1))
    xorB = sum(pr(us, up, p, q) for us in (0,1) for up in (0,1) if (((us ^ 1) ^ up) == 1))
    print(f"CHECK (v)  (p,q)=({p},{q}): AND-seal do(B)P(C=1)={andB:.4f} (monotone in X -> response-type collapse -> point-ID);"
          f" XOR-seal={xorB:.4f} (non-monotone -> Balke-Pearl interval if ID'd from L1 alone)")

print()
print("=" * 90)
print("FINDING (why this gate matters):")
print("=" * 90)
print("""  The URS headline numbers are EXACT and reproduce: W(e:X=1)=q, W(e:X=0)=0, marginal=p*q.
  But they are the BETA reading: do(Sigma_next) sets the NEXT regime while the witnessed C^{(t)} reads the
  FACTUAL X (upstream of f_Sigma) -> the intervention is STRUCTURALLY INERT on the witnessed C. So W=q is the
  agent's CURRENT competence given evidence -- a sealed (b-ii)-style certificate -- NOT a forward (a) L3
  prediction of the unrun successor. The genuine successor witness pulls apart:
    PERSISTENT type (abduction carries => genuine L3):  W = 0 identically            => DEGENERATE / vacuous
    FRESH noise (non-degenerate = (1-p)q):  abduction is INERT                       => it is L2, not L3
  => M** as written does NOT exhibit a witness that is simultaneously {genuine-L3, about-the-self-mod,
     non-vacuous}. The arithmetic checks out; the INTERPRETATION (a forward (a) witness) does not.""")

print()
print("=" * 90)
print("DoWhy gcm CROSS-CHECK of L1 + L2 (categorical/classifier mechanisms)")
print("=" * 90)
try:
    import numpy as np, pandas as pd, networkx as nx
    import dowhy.gcm as gcm
    print("dowhy version:", __import__("dowhy").__version__)
    rng = np.random.default_rng(0)
    N = 400_000
    allok = True
    for p, q in [(0.3, 0.7), (0.8, 0.4), (0.2, 0.9)]:
        sig = rng.integers(0, 2, N)
        us = (rng.random(N) < p).astype(int)
        up = (rng.random(N) < q).astype(int)
        X = (us ^ sig); C = (X & up)
        # categorical dtype => gcm assigns CLASSIFIER FCMs (correct for Boolean XOR / AND)
        data = pd.DataFrame({"Sigma": sig.astype(str), "X": X.astype(str), "C": C.astype(str)}).astype("category")
        G = nx.DiGraph([("Sigma", "X"), ("X", "C")])
        scm = gcm.StructuralCausalModel(G)
        gcm.auto.assign_causal_mechanisms(scm, data)
        gcm.fit(scm, data)
        obs = gcm.draw_samples(scm, num_samples=N).astype(str)
        l1 = (obs.loc[obs["Sigma"] == "0", "C"] == "1").mean()   # observational restricted to regime A (Sigma=0)
        sA = gcm.interventional_samples(scm, {"Sigma": lambda x: "0"}, num_samples_to_draw=N)
        sB = gcm.interventional_samples(scm, {"Sigma": lambda x: "1"}, num_samples_to_draw=N)
        dA = (sA["C"].astype(str) == "1").mean(); dB = (sB["C"].astype(str) == "1").mean()
        ex = exact(p, q)
        m = lambda a, b: abs(a - b) < 0.01
        good = m(l1, ex['PC1']) and m(dA, ex['L2A']) and m(dB, ex['L2B']); allok = allok and good
        print(f"  (p,q)=({p},{q}):  L1 {l1:.4f}/{ex['PC1']:.4f}  |  do(A) {dA:.4f}/{ex['L2A']:.4f}  |  "
              f"do(B) {dB:.4f}/{ex['L2B']:.4f}   [{'MATCH' if good else 'MISMATCH'}]   (dowhy/exact)")
    print("  =>", "DoWhy reproduces M**'s L1 + interventional L2 to <1% on all configs (encoding validated)."
          if allok else "Some DoWhy estimates did NOT match -- investigate.")
    print("  (L3 forward witness stays on exact enumeration: gcm counterfactuals need invertible/additive-noise")
    print("   mechanisms; the Boolean-AND seal is non-invertible, so the abduction is computed exactly above.)")
except Exception as e:
    import traceback; print("DoWhy step error:", repr(e)); traceback.print_exc()
    print("(Exact enumeration above is authoritative and stands regardless.)")
