"""
S-1 — the self-model instrument (full fidelity; not an illustrative reduction).

Per monotone_J_PROTOCOL.md S-1:
  (A) a REAL predictive task + REAL predictor (Naive Bayes, closed form) exhibiting Audit-CP's actual stream-leak:
      adding an ARTIFACT channel LOWERS stream log-loss but RAISES audit log-loss.
  (B) the competence-effect of a rewrite (does USING a candidate channel improve audit competence) and its
      partial identification. The confounder is the channel's latent TYPE H in {genuine, artifact}, which the
      agent CANNOT observe from the (leaked) stream. So from stream alone the effect is set-identified to the
      H-span [e_artifact, e_genuine] (Manski/Balke-Pearl partial-ID under an unobserved confounder, T9_2_10).
      A randomized structural probe = the agent intervening on X itself (its own RCT) -> point-identifies
      (up to finite-sample slack). Probe access is the control {agent-has-Z, audit-only-Z}.
  (C) the sealed structural audit: it measures the rewrite's true transfer P(C|do(X)) on the sealed panel and
      SIGNS the identified effect -- genuine = positive transfer (accept), leak = non-positive (reject) -- which
      is the certificate the monotone-J gate consumes. Plus the two distinct Delta_n terms (identification vs
      competence) computed correctly.

S-1 CHECKPOINT: from STREAM alone the audit-effect is UN-identified (low J = -span) for ANY high-stream
rewrite -- the Goodhart danger zone; the agent cannot tell genuine from leak. The probe (or the seal)
IDENTIFIES it (high J ~ -2*Delta_id); the sealed audit then SIGNS it. This is precisely the certificate
monotone-J needs, and the un-identification is type-agnostic (it is uncertainty over H, not over sign).
"""
import warnings; warnings.filterwarnings("ignore")
import numpy as np

rng = np.random.default_rng(0)

# ---------- DGP (real predictive task) ----------
P_GEN   = 0.50          # P(a candidate channel is genuine vs artifact)
ACC_G   = 0.62          # WEAK base feature G (so a real channel can actually move audit accuracy)
ACC_gen = 0.78          # genuine channel: P(f=Y) on stream AND audit (consistent + strong -> transfers, helps)
ACC_art_stream = 0.95   # artifact channel LEAKED on the stream
ACC_art_audit  = 0.50   # artifact channel is NOISE on the sealed audit (does NOT transfer)

def gen(N, channel_types, regime):
    Y = rng.integers(0, 2, N)
    def feat(a): return np.where(rng.random(N) < a, Y, 1 - Y)
    cols = [feat(ACC_G)]
    for t in channel_types:
        acc = ACC_gen if t == 'gen' else (ACC_art_stream if regime == 'stream' else ACC_art_audit)
        cols.append(feat(acc))
    return np.stack(cols, 1).astype(float), Y

# ---------- real predictor: Naive Bayes (closed form), fit on STREAM, evaluated on AUDIT ----------
def fit_nb(Xf, y):
    py1 = np.clip(y.mean(), 1e-6, 1 - 1e-6)
    pf = {c: (Xf[y == c].sum(0) + 1) / ((y == c).sum() + 2) for c in (0, 1)}
    return py1, pf
def nb_proba(Xf, model):
    py1, pf = model
    lo = np.log(py1 / (1 - py1)) + Xf @ (np.log(pf[1]) - np.log(pf[0])) + (1 - Xf) @ (np.log(1 - pf[1]) - np.log(1 - pf[0]))
    return 1 / (1 + np.exp(-lo))
def logloss(p, y): p = np.clip(p, 1e-3, 1 - 1e-3); return float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)))
def acc(p, y):     return float(np.mean((p > 0.5) == y))
def train_eval(channel_types, n_stream=20000, n_eval=50000, eval_regime='audit'):
    Xs, ys = gen(n_stream, channel_types, 'stream'); model = fit_nb(Xs, ys)
    Xe, ye = gen(n_eval, channel_types, eval_regime); p = nb_proba(Xe, model)
    return logloss(p, ye), acc(p, ye)

# ============================================================================
print("=" * 92)
print("S-1 (A)  REAL stream-leak on a REAL predictor (Audit-CP failure mode)")
print("=" * 92)
ll_s0, _ = train_eval([], eval_regime='stream'); ll_a0, a0 = train_eval([], eval_regime='audit')
ll_s1, _ = train_eval(['art'], eval_regime='stream'); ll_a1, _ = train_eval(['art'], eval_regime='audit')
print(f"  predictor {'{G}':<12} : stream log-loss {ll_s0:.3f}   audit log-loss {ll_a0:.3f}")
print(f"  predictor {'{G,artifact}':<12} : stream log-loss {ll_s1:.3f}   audit log-loss {ll_a1:.3f}")
leak = (ll_s1 < ll_s0 - 1e-3) and (ll_a1 > ll_a0 + 1e-3)
print(f"  => artifact channel LOWERS stream log-loss ({ll_s1:.3f}<{ll_s0:.3f}) but RAISES audit log-loss "
      f"({ll_a1:.3f}>{ll_a0:.3f}): stream-leak reproduced on a real predictor: {leak}")

_, a1g = train_eval(['gen'], eval_regime='audit')   # audit accuracy with a genuine channel
_, a1a = train_eval(['art'], eval_regime='audit')   # audit accuracy with an artifact channel
e_gen, e_art = a1g - a0, a1a - a0
print(f"\n  audit accuracies (real):  a0={a0:.3f}  a1|genuine={a1g:.3f}  a1|artifact={a1a:.3f}")
print(f"  true competence-effect (transfer):  genuine {e_gen:+.3f} (helps)   artifact {e_art:+.3f} (leak)")

# ============================================================================
print("\n" + "=" * 92)
print("S-1 (B)  Identification of the rewrite's competence-effect   (J = -width)")
print("=" * 92)
# The confounder is the latent channel TYPE H, UNOBSERVED by the agent from the leaked stream (both genuine and
# artifact look predictive there). So from stream alone the effect is set-identified to the H-span.
span = e_gen - e_art                                  # [e_art, e_gen] partial-ID width under unobserved H
J_streamonly = -span
# A randomized structural probe = the agent intervenes on X itself (own RCT) -> point-ID up to finite slack.
delta, n, m_channels = 0.05, 2000, 4
N_F = 2 ** m_channels
Delta_id = 1.0 * np.sqrt(np.log(2 * N_F / delta) / (2 * n))   # identification: BINARY outcome (L=1)
J_probe = -2 * Delta_id
print(f"  audit-only-Z (stream only, H unobserved): effect set-identified to [{e_art:+.3f},{e_gen:+.3f}]  "
      f"width {span:.3f}  -> J = {J_streamonly:+.3f}  (UN-identified)")
print(f"  agent-has-Z  (probe = own RCT, intervene on X): point-identified up to 2*Delta_id  "
      f"width {2*Delta_id:.3f}  -> J = {J_probe:+.3f}  (identified)")
print(f"  => the probe narrows the identification interval by {span - 2*Delta_id:+.3f} (un-identified -> identified)")

# ============================================================================
print("\n" + "=" * 92)
print("S-1 (C)  Sealed structural audit signs the identified effect + the two Delta_n terms")
print("=" * 92)
print(f"  sealed audit measures the true transfer P(C|do(X)) per rewrite:")
print(f"     genuine rewrite {e_gen:+.3f}  (> 0  -> ACCEPT)        leak rewrite {e_art:+.3f}  (<= 0  -> REJECT)")
print(f"  => a leak's stream-claimed gain is rejected because the sealed audit shows it does not transfer.")
Lf = np.log(1 / 1e-3)                                  # clipped log-loss range
Delta_comp = Lf * np.sqrt(np.log(2 * N_F / delta) / (2 * n))
print(f"\n  Delta_id   (identification, binary outcome L=1)        = {Delta_id:.3f}   (J gate slack 2*Delta_id={2*Delta_id:.3f})")
print(f"  Delta_comp (competence, log-loss L={Lf:.2f})              = {Delta_comp:.3f}   (competence gate slack 2*Delta_comp={2*Delta_comp:.3f})")
print(f"  |F|=2^{m_channels}={N_F}, n={n}, delta={delta}  (Audit-CP Prop 3.6, Hoeffding + union bound)")

ok = leak and (J_streamonly < J_probe - 0.05) and (e_gen > 0) and (e_art <= 1e-9)
print("\n" + "=" * 92)
print(f"  S-1 INSTRUMENT VALIDATED: {'PASS' if ok else 'REVIEW'}")
print(f"   - real stream-leak on a real predictor                                    : {leak}")
print(f"   - stream-only effect UN-identified (J={J_streamonly:+.3f}); probe identifies (J={J_probe:+.3f}) : {J_streamonly < J_probe - 0.05}")
print(f"   - sealed audit signs the effect: genuine accept (+), leak reject (<=0)     : {e_gen > 0 and e_art <= 1e-9}")
print("=" * 92)
