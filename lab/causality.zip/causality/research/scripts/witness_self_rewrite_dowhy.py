"""
WITNESS: the DoWhy model IS the self-state + self-rewrite construct.

Construct (grounded, GROUNDING_self_state_self_rewrite.md):
  * self-STATE  = a Gladyshev TSEM (Def 1-2): state = variable configuration; transition = apply
                  the structural equations. Here the unrolled state is X0 -> X1 -> ... -> XT.
  * self-REWRITE = a STRUCTURE intervention (Gladyshev Def 11) == a MacDermott mechanism-node
                  intervention (Def 3): the object variable X has a MECHANISM NODE Xtilde whose
                  *value* selects X's rule F_X. do(Xtilde = rule') installs a new equation for X.

WITNESS (a DISCRIMINATING result from Gladyshev sec.6): with the constant rule F_X(x)=1,
  * a STANDARD VALUE intervention do(X^0 = 0) is ERASED at the next step (X reverts to 1) --
    "standard interventions cannot enforce a persistent change";
  * a STRUCTURE intervention do(F_X <- 0), i.e. do(Xtilde = CONST0) on the mechanism node,
    enforces X = 0 for ALL i>0 -- "structure interventions are NOT expressible as standard ones".
A model that only supports value interventions on object nodes CANNOT produce the structure row;
reproducing it witnesses that DoWhy genuinely carries the mechanism-node (structure) operator.

Discipline: green != gamma. The DoWhy interventional output is cross-checked, cell by cell, against
an EXACT TSEM oracle (pure-Python deterministic Def 1-2 dynamics). PASS only if they agree AND the
structure-vs-value discrimination is exhibited.
"""
import warnings; warnings.filterwarnings("ignore")
import numpy as np, pandas as pd, networkx as nx
from dowhy import gcm

T = 5                      # unroll X0..XT
CONST1, CONST0 = "CONST1", "CONST0"   # the two rules (mechanism-node values)

# ---------------------------------------------------------------------------
# 0.  The TSEM rule and the EXACT oracle (Gladyshev Def 1-2 dynamics, deterministic)
# ---------------------------------------------------------------------------
def apply_rule(rule, prev):           # F_X : depends on the mechanism value `rule` (ignores prev: constant rule)
    return "1" if rule == CONST1 else "0"

def oracle(rule, x0, T=T):            # exact TSEM trajectory  (ground truth)
    traj = [x0]
    for _ in range(T):
        traj.append(apply_rule(rule, traj[-1]))
    return traj

# ---------------------------------------------------------------------------
# 1.  Build the MECHANISED graph in DoWhy (MacDermott Def 3): mechanism node Xtilde + object nodes X_t
# ---------------------------------------------------------------------------
G = nx.DiGraph()
for t in range(1, T + 1):
    G.add_edge("Xtilde", f"X{t}")     # the mechanism (rule) governs every transition  -> structure-intervenable
    G.add_edge(f"X{t-1}", f"X{t}")    # the transition reads the previous state (TSEM domain D(X) = {X})

# ---------------------------------------------------------------------------
# 2.  Exhaustive training data from the TSEM (both rules, both initial states) -> exact mechanisms
# ---------------------------------------------------------------------------
rng = np.random.default_rng(0)
rows = []
for _ in range(8000):
    rule = rng.choice([CONST1, CONST0])
    x0   = rng.choice(["0", "1"])
    traj = oracle(rule, x0)
    rows.append({"Xtilde": rule, **{f"X{t}": traj[t] for t in range(T + 1)}})
data = pd.DataFrame(rows).astype("object")   # object dtype -> gcm.auto assigns CLASSIFIER mechanisms

scm = gcm.StructuralCausalModel(G)
gcm.auto.assign_causal_mechanisms(scm, data)
gcm.fit(scm, data)

# ---------------------------------------------------------------------------
# 3.  Helper: run a DoWhy intervention, return the (deterministic) trajectory + its purity
# ---------------------------------------------------------------------------
def dowhy_traj(interventions, n=4000):
    iv = {k: (lambda v: (lambda _x: v))(val) for k, val in interventions.items()}
    s = gcm.interventional_samples(scm, iv, num_samples_to_draw=n)
    traj, purity = [], []
    for t in range(T + 1):
        col = f"X{t}"
        if col in interventions:
            traj.append(interventions[col]); purity.append(1.0)
        else:
            vc = s[col].value_counts(normalize=True)
            traj.append(str(vc.index[0])); purity.append(float(vc.iloc[0]))
    return traj, min(purity)

# ---------------------------------------------------------------------------
# 4.  THE WITNESS  -- three scenarios, DoWhy vs exact oracle
# ---------------------------------------------------------------------------
print("=" * 90)
print("WITNESS: self-state (TSEM) + self-rewrite (structure intervention == mechanism-node do) in DoWhy")
print("Rule F_X(x)=1 (constant). Goal (Gladyshev sec.6): enforce X=0 for all i>0.")
print("=" * 90)

scenarios = [
    ("baseline free-run   F=const1, X0=1",
     {"Xtilde": CONST1, "X0": "1"},                 oracle(CONST1, "1")),
    ("VALUE  do(X0=0)     F=const1  [object-node]",
     {"Xtilde": CONST1, "X0": "0"},                 oracle(CONST1, "0")),
    ("STRUCT do(Xtilde=CONST0)      [mechanism-node = self-rewrite]",
     {"Xtilde": CONST0, "X0": "1"},                 oracle(CONST0, "1")),
]

all_match = True
print(f"\n  {'scenario':<46}  {'DoWhy X0..XT':<16}  {'exact oracle':<16}  match  purity")
print("  " + "-" * 92)
rowtraj = {}
for name, iv, ora in scenarios:
    dw, pur = dowhy_traj(iv)
    m = (dw == ora); all_match &= m
    rowtraj[name.split()[0]] = dw
    print(f"  {name:<46}  {''.join(dw):<16}  {''.join(ora):<16}  {'OK ' if m else 'XX '}   {pur:.3f}")

# ---------------------------------------------------------------------------
# 5.  The discrimination (the content of the witness)
# ---------------------------------------------------------------------------
value_post  = rowtraj["VALUE"][1:]     # X1..XT under the value intervention
struct_post = rowtraj["STRUCT"][1:]    # X1..XT under the structure intervention
value_enforces_0  = all(x == "0" for x in value_post)
struct_enforces_0 = all(x == "0" for x in struct_post)

print("\n  DISCRIMINATION (X_i for i>0):")
print(f"    VALUE  do(X0=0)        -> X1..XT = {''.join(value_post)}   enforces X=0 for all i>0 ? {value_enforces_0}")
print(f"    STRUCT do(Xtilde=0)    -> X1..XT = {''.join(struct_post)}   enforces X=0 for all i>0 ? {struct_enforces_0}")

witness = all_match and (not value_enforces_0) and struct_enforces_0
print("\n" + "=" * 90)
print("  oracle cross-check (all scenarios, cell-exact):", "PASS" if all_match else "FAIL")
print("  value intervention FAILS to enforce X=0 (reverts):", "PASS" if not value_enforces_0 else "FAIL")
print("  structure intervention ENFORCES X=0 for all i>0 :", "PASS" if struct_enforces_0 else "FAIL")
print("  >>> WITNESS (Gladyshev sec.6 'structure != standard intervention') :",
      "REPRODUCED" if witness else "NOT REPRODUCED")
print("=" * 90)

# ---------------------------------------------------------------------------
# 6.  GENERALIZATION (beyond the paper): make the rewrite SELF-intervention (reflexive closure).
#     The mechanism node is ENDOGENOUS -- computed by the agent's own equation from its state
#     (Bongers feedback semantics). No external do(): the agent patches its OWN rule each step.
# ---------------------------------------------------------------------------
print("\n" + "-" * 90)
print("GENERALIZATION: reflexive closure -- the mechanism node is computed by the agent ITSELF")
print("  controller:  Xtilde_{t+1} = CONST0 if X_t==1 else CONST1   (self-patch toward 0 when high)")
print("-" * 90)

Gs = nx.DiGraph()
Gs.add_edge("X0", "R1")
for t in range(1, T + 1):
    Gs.add_edge(f"R{t}", f"X{t}")          # endogenous rule node R_t governs X_t
    Gs.add_edge(f"X{t-1}", f"X{t}")
    if t < T:
        Gs.add_edge(f"X{t}", f"R{t+1}")    # ... and the agent computes next rule from its own state

def controller(prev):  return CONST0 if prev == "1" else CONST1
def self_oracle(x0, T=T):
    traj = [x0]; rules = []
    for _ in range(T):
        r = controller(traj[-1]); rules.append(r); traj.append(apply_rule(r, traj[-1]))
    return traj, rules

rows = []
for _ in range(8000):
    x0 = rng.choice(["0", "1"]); traj, rules = self_oracle(x0)
    d = {"X0": x0}
    for t in range(1, T + 1):
        d[f"R{t}"] = rules[t-1]; d[f"X{t}"] = traj[t]
    rows.append(d)
sdata = pd.DataFrame(rows).astype("object")
sscm = gcm.StructuralCausalModel(Gs)
gcm.auto.assign_causal_mechanisms(sscm, sdata); gcm.fit(sscm, sdata)

for x0 in ["1", "0"]:
    s = gcm.interventional_samples(sscm, {"X0": lambda _x: x0}, num_samples_to_draw=4000)
    dw = [x0] + [str(s[f"X{t}"].value_counts(normalize=True).index[0]) for t in range(1, T + 1)]
    ora, _ = self_oracle(x0)
    print(f"  X0={x0}:  DoWhy self-trajectory = {''.join(dw)}   exact = {''.join(ora)}   match={dw==ora}")
print("  => the rule node is endogenous (the agent rewrites its own F each step); DoWhy reproduces")
print("     the self-regulating dynamics exactly. This is the self-INTERVENTION (reflexive) closure.")
