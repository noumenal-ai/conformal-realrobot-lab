# New direction: monotone JUSTIFICATION (self-identification), competence free to be NON-MONOTONE.
# Tested on the SAME deceptive landscape that froze the never-regress-competence loop. Adversarial checks baked in.
import numpy as np
rng = np.random.default_rng(0)
g = np.array([.20, .45, .30, .70, .92])      # true competence per config; deceptive (local opt at idx 1)
K = len(g); confounded = {2}                  # config 2 is confounded -> only INTERVAL-identifiable (honest ceiling)
N_aud, floor = 4000, 0.50

identified, intervals = {}, {}
just_traj, comp_traj = [], []
for theta in range(K):                         # explore the self-config space (exhaustive here; info-gain-ordered in general)
    comp_traj.append(g[theta])                 # competence WHILE exploring (transient, may dip)
    est = (rng.random(N_aud) < g[theta]).mean()
    if theta in confounded:
        intervals[theta] = (max(0, est-0.18), min(1, est+0.18))   # confounded -> interval (T9_2_10)
    else:
        identified[theta] = est                                    # exo+mono -> point (T9_2_14)
    just_traj.append(len(identified) + 0.5*len(intervals))         # justification: point=1, interval=0.5

committable = {t: v for t, v in identified.items() if v >= floor}  # commit only to a CERTIFIED, floored config
commit = max(committable, key=committable.get)

print("competence path (exploration):", [f"{c:.2f}" for c in comp_traj])
print("justification path           :", just_traj)
print("monotone justification?        ", all(just_traj[i+1] >= just_traj[i]-1e-9 for i in range(len(just_traj)-1)))
print("non-monotone competence?       ", any(comp_traj[i+1] < comp_traj[i]-1e-9 for i in range(len(comp_traj)-1)), "(the .45->.30 dip = exploration)")
print(f"committed config {commit}: competence {g[commit]:.2f}   |   reached GLOBAL optimum {g.max():.2f}? {abs(g[commit]-g.max())<1e-9}")

# contrast: the prior never-regress-COMPETENCE loop on the SAME landscape
s = 0
for _ in range(K):
    cands = [s] + ([s+1] if s+1 < K else [])
    best = max(cands, key=lambda c: g[c])
    if g[best] > g[s]: s = best
print(f"prior never-regress-competence loop committed to {g[s]:.2f}  (FROZE at local optimum)")

print("--- adversarial checks (baked in) ---")
print(f"lobotomy avoided? committed competence {g[commit]:.2f} >= floor {floor}: {g[commit] >= floor}")
print(f"justification ceiling (honest): {len(identified)} point-ID + {len(intervals)} interval-only "
      f"(config {confounded} confounded -> NEVER point-ID; ceiling < 100%)")
print(f"justification gameable by exploration? NO -- it identifies the TRUE g (exploration cannot fake the surface).")
print(f"  [residual: if a rewrite CHANGES g (not just visits), lobotomy/moving-target re-enters -> next crux.]")
