"""
M**'  — corrected unified counterexample, designed to fix the defect the gate found in M**.

Defect found: in M** the witnessed C was UPSTREAM of / decoupled from the self-modification, so the
forward witness was just current competence (beta reading), and the genuine successor witness either
degenerated (persistent noise -> 0) or lost its L3 content (fresh noise -> L2).

Fix (three structural changes, each a canonical Pearl object):
  1. a PERSISTENT latent TYPE  U_type ~ Bern(p)   (a standard unit/latent; makes abduction carry => genuine L3)
  2. competence depends on REGIME-TYPE MATCH:  X(r, U_type) = 1 iff regime r matches the type
     (so the witnessed drive is DOWNSTREAM of the regime => the witness is about the self-modification)
  3. sealed monotone competence  C = X AND U_obs,  U_obs ~ Bern(q) fresh   (the seal, monotone => point-ID)

Forward self-witness:  W := C' under do(Sigma = sigma_next), abducting U_type from the factual A-behaviour.
We test TWO self-mechanisms to expose the structure:
  (a) sigma_next = B   (a NON-adaptive / risky self-proposal)        -> genuine L3, non-vacuous, type-dependent
  (b) sigma_next = optimal switch (A if drive-on else B)            -> non-vacuous but abduction-INERT (=L2)
The contrast is the lesson: the forward witness has genuine L3 content exactly when the self-mod's value is
TYPE-DEPENDENT (could be bad for the agent's actual type) -- which is exactly when a forward witness is needed.
"""
import warnings; warnings.filterwarnings("ignore")

def X(r, t):   # drive on iff regime r matches type t   (A=0, B=1)
    return 1 if r == t else 0
def C(r, t, o):
    return X(r, t) & o

def forward_witness(p, q, sigma_next_rule):
    """Exact. factual regime A=0. abduct U_type from X^t; predict C' under do(Sigma=sigma_next)."""
    out = {}
    for eX in (0, 1):                      # evidence: observed drive X^t under regime A
        t = 1 - eX                         # X^t = X(A=0, t) = [t==0] = 1 - t   => t = 1 - eX  (abduction, invertible)
        snext = sigma_next_rule(eX)        # the agent's self-proposed successor regime
        W = sum((q if o == 1 else 1 - q) * C(snext, t, o) for o in (0, 1))   # integrate fresh U_obs'
        out[eX] = (t, snext, W)
    return out

print("=" * 92)
print("M**'  EXACT forward self-witness  (factual regime A=0; abduct U_type; predict successor C')")
print("=" * 92)
for label, rule in [("(a) sigma_next = B  [non-adaptive/risky proposal]", lambda eX: 1),
                    ("(b) sigma_next = switch-if-drive-off  [adaptive]", lambda eX: 0 if eX == 1 else 1)]:
    print(f"\n{label}")
    print(f"   {'evidence X^t':>12} {'abduced type':>12} {'successor':>10} {'W=P(C''=1|e)':>14}")
    for p, q in [(0.3, 0.7), (0.6, 0.4)]:
        fw = forward_witness(p, q, rule)
        for eX in (1, 0):
            t, sn, W = fw[eX]
            print(f"   (p,q)=({p},{q})  X^t={eX}   U_type={t}      Sigma'={'B' if sn==1 else 'A'}     W={W:.3f}")
        vals = {fw[1][2], fw[0][2]}
        genuineL3 = len(vals) > 1                     # W depends on the abducted type => abduction matters
        nonvac = any(0 < v < 1 for v in vals)
        print(f"      -> genuine-L3 (abduction matters)? {genuineL3} ;  non-vacuous? {nonvac} ;  "
              f"about-the-self-mod? True (C' is downstream of Sigma')")

print()
print("VERDICT:")
print("  (a) W in {0, q} keyed by the ABDUCED type  => genuine L3 + non-vacuous + about-the-self-mod.")
print("      The witness correctly says: a type-0 agent adopting B drops to W=0 (DON'T); a type-1 agent gets q.")
print("  (b) W = q regardless of type => abduction inert (collapses to L2): a GOOD (type-corrective) self-mod")
print("      needs no L3 content. The forward (a) witness earns its L3 keep precisely on RISKY self-mods.")

print()
print("=" * 92)
print("DoWhy gcm CROSS-CHECK of M**' competence mechanism (interventional P(C=1 | do(regime)))")
print("=" * 92)
print("  exact:  P(C=1|do A) = P(type=0)*q = (1-p)q ;  P(C=1|do B) = P(type=1)*q = p*q")
try:
    import numpy as np, pandas as pd, networkx as nx
    import dowhy.gcm as gcm
    print("  dowhy version:", __import__("dowhy").__version__)
    rng = np.random.default_rng(1); N = 400_000
    ok = True
    for p, q in [(0.3, 0.7), (0.6, 0.4)]:
        typ = (rng.random(N) < p).astype(int)
        sig = rng.integers(0, 2, N)
        uo = (rng.random(N) < q).astype(int)
        Xv = (typ == sig).astype(int)
        Cv = (Xv & uo)
        data = pd.DataFrame({"Type": typ.astype(str), "Sigma": sig.astype(str),
                             "X": Xv.astype(str), "C": Cv.astype(str)}).astype("category")
        G = nx.DiGraph([("Type", "X"), ("Sigma", "X"), ("X", "C")])
        scm = gcm.StructuralCausalModel(G)
        gcm.auto.assign_causal_mechanisms(scm, data); gcm.fit(scm, data)
        sA = gcm.interventional_samples(scm, {"Sigma": lambda x: "0"}, num_samples_to_draw=N)
        sB = gcm.interventional_samples(scm, {"Sigma": lambda x: "1"}, num_samples_to_draw=N)
        dA = (sA["C"].astype(str) == "1").mean(); dB = (sB["C"].astype(str) == "1").mean()
        exA, exB = (1 - p) * q, p * q
        m = lambda a, b: abs(a - b) < 0.01
        good = m(dA, exA) and m(dB, exB); ok = ok and good
        print(f"  (p,q)=({p},{q}):  do(A) {dA:.4f}/{exA:.4f}  |  do(B) {dB:.4f}/{exB:.4f}   [{'MATCH' if good else 'MISMATCH'}]")
    print("  =>", "DoWhy reproduces M**' interventional competence to <1% (mechanism validated)." if ok
          else "MISMATCH -- investigate.")
except Exception as e:
    import traceback; print("  DoWhy error:", repr(e)); traceback.print_exc()
