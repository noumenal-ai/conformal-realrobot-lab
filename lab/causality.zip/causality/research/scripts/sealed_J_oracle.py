"""
sealed_J_oracle.py -- the SEALED-STRUCTURAL-AUDIT justification oracle (KU-J1 + KU-J2, resolved with Dhruv).

J = -width  (Balke-Pearl interval width of the competence-effect P(C_{X=1}=1)).   [KU-J1]
  width in [0,1];  width=0 at point-ID (exo+mono, T9_2_14 = the "Bayes floor").
  Justification progress telescopes:  sum_t (J_t - J_{t-1}) = width_0 - width_T <= width_0  (finite budget).

THE SEAL [KU-J2]: a self-rewrite controls its own DECLARED graph, so it could fake an instrument / falsely
declare exogeneity and pin width->0 (J-wireheading). The oracle therefore VALIDATES each identification claim
against SEALED INTERVENTIONAL DATA the agent cannot query (Audit-CP D_aud lifted to structure):
  an exogeneity claim is admitted ONLY IF observational P(C|X) matches the sealed interventional P(C|do(X)).
  If rejected, width falls back to the honest Balke-Pearl interval -> J is NOT inflated. (Modification-independent:
  the sealed do-data does not depend on the rewrite history -> R7.)

The self-rewrite is a STRUCTURE intervention on the mechanism node governing X's equation (toggle H->X on/off):
do(M_X = confounded) installs X = f(Z,H); do(M_X = exogenous) installs X = f(Z). Same operator class witnessed in
tsem.py / mechanised_cbn_newcomb.py (R6).

Witness goals:
  (T1) a rewrite that opens a real back-door (H->X) RAISES width  => J FALLS  (J can fall; not a counter).
  (SEAL) a wireheading rewrite (open H->X but FALSELY declare exogenous) is REJECTED by the sealed audit
         => width stays wide => J NOT inflated.  Contrast with a naive (unsealed) oracle that would be fooled.
  (BUDGET) cumulative justification progress telescopes to width_0 - width_T.
"""
import warnings; warnings.filterwarnings("ignore")
import numpy as np
from itertools import product
from scipy.optimize import linprog

# ---------- Balke-Pearl IV bounds on P(C_{X=1}=1) from observed P[z][x][y] (response-type LP) ----------
TYPES = list(product([0, 1], repeat=4))            # (X resp to Z=0, X resp to Z=1, C resp to X=0, C resp to X=1)
def Xr(t, z): return t[0] if z == 0 else t[1]
def Yr(t, x): return t[2] if x == 0 else t[3]
def bp_width(P):
    A, b = [], []
    for z in (0, 1):
        for x in (0, 1):
            for y in (0, 1):
                A.append([1.0 if (Xr(t, z) == x and Yr(t, x) == y) else 0.0 for t in TYPES]); b.append(P[z][x][y])
    A.append([1.0] * 16); b.append(1.0)
    c = np.array([1.0 if t[3] == 1 else 0.0 for t in TYPES])      # P(C_{X=1}=1)
    lo = linprog(c, A_eq=A, b_eq=b, bounds=[(0, 1)] * 16, method="highs")
    hi = linprog(-c, A_eq=A, b_eq=b, bounds=[(0, 1)] * 16, method="highs")
    return (lo.fun, -hi.fun) if (lo.success and hi.success) else (0.0, 1.0)

# ---------- the TRUE SCM (Z instrument, H hidden confounder, X regime, C competence) ----------
def clip(v): return min(1.0, max(0.0, v))
def pX1(Z, H, conf): return clip(0.20 + 0.60 * Z + conf * 0.30 * (2 * H - 1))   # conf=0 => X _|_ H (exogenous)
def pC1(X, H):       return clip(0.30 + 0.35 * X + 0.30 * (2 * H - 1))          # H -> C  (H confounds always)

def observed_P(conf):
    """P[z][x][y] = P(X=x, C=y | Z=z), summing the hidden H~Bern(.5).  Z _|_ H, Z affects C only through X."""
    P = [[[0.0, 0.0], [0.0, 0.0]] for _ in (0, 1)]
    for z in (0, 1):
        for H in (0, 1):
            px1 = pX1(z, H, conf)
            for x in (0, 1):
                px = px1 if x == 1 else 1 - px1
                pc1 = pC1(x, H)
                for y in (0, 1):
                    P[z][x][y] += 0.5 * px * (pc1 if y == 1 else 1 - pc1)
    return P

def sealed_do_effect():               # SEALED audit: true P(C=1|do(X=1)), agent cannot query this
    return 0.5 * pC1(1, 0) + 0.5 * pC1(1, 1)
def observational_CgivenX1(P):         # what the agent CAN compute: P(C=1|X=1) (confounded when conf>0)
    num = sum(0.5 * P[z][1][1] for z in (0, 1)); den = sum(0.5 * (P[z][1][0] + P[z][1][1]) for z in (0, 1))
    return num / den if den > 0 else 0.0

# ---------- the J-oracle ----------
def J_oracle(conf, claim, sealed=True, tol=0.02):
    """claim in {'exogenous','iv'}. Returns (J, width, status). Structure-rewrite sets `conf` (H->X) via the
    mechanism node M_X; `claim` is what the rewrite DECLARES about identification."""
    P = observed_P(conf)
    lo, hi = bp_width(P); bp = hi - lo
    if claim == "iv":
        return -bp, bp, "honest IV partial-ID"
    # claim == 'exogenous' -> would give point-ID (width 0) at the observational P(C|X=1)
    obs = observational_CgivenX1(P); do = sealed_do_effect()
    if sealed and abs(obs - do) > tol:
        return -bp, bp, f"EXO REJECTED by seal (obs {obs:.3f} != do {do:.3f}) -> fall back to BP width"
    return 0.0, 0.0, "exo validated -> point-ID (width 0)"

# ============================================================================
print("=" * 92)
print("SEALED-STRUCTURAL-AUDIT JUSTIFICATION ORACLE   J = -width   (KU-J1 + KU-J2)")
print(f"  sealed audit: true P(C=1|do(X=1)) = {sealed_do_effect():.3f}  (agent cannot query)")
print("=" * 92)

scen = [
    ("S0 exogenous, declare exogenous   ", 0.0,  "exogenous"),
    ("S1 REWRITE opens H->X, declare iv  ", 0.6,  "iv"),
    ("S2 WIREHEAD: H->X but declare exo  ", 0.6,  "exogenous"),
]
print(f"\n  {'scenario':<38} {'conf':>5} {'claim':>10} {'width':>7} {'J':>7}  status")
print("  " + "-" * 90)
J_sealed = {}
for name, conf, claim in scen:
    J, w, st = J_oracle(conf, claim, sealed=True)
    J_sealed[name[:2]] = J
    print(f"  {name:<38} {conf:>5.1f} {claim:>10} {w:>7.3f} {J:>7.3f}  {st}")

print("\n  CONTRAST -- the same wireheading rewrite under a NAIVE (unsealed) oracle that trusts the declaration:")
Jn, wn, stn = J_oracle(0.6, "exogenous", sealed=False)
print(f"  S2 wirehead, UNSEALED oracle        :  width {wn:.3f}  J {Jn:+.3f}   ({stn})")

# ---------- witnesses ----------
t1_falls   = J_sealed["S1"] < J_sealed["S0"] - 1e-6                 # opening a real back-door lowers J
seal_works = abs(J_sealed["S2"] - J_sealed["S1"]) < 1e-6           # wireheading gives the SAME low J as honest iv
naive_fooled = Jn > J_sealed["S1"] + 1e-6                          # unsealed oracle WOULD be inflated
print("\n  " + "-" * 90)
print(f"  (T1)   real back-door rewrite lowers J     : {t1_falls}   (J: {J_sealed['S0']:+.3f} -> {J_sealed['S1']:+.3f})")
print(f"  (SEAL) wireheading does NOT inflate J      : {seal_works}   (wirehead J {J_sealed['S2']:+.3f} == honest-iv J {J_sealed['S1']:+.3f})")
print(f"  (SEAL) an UNSEALED oracle WOULD be fooled  : {naive_fooled}   (would report J {Jn:+.3f})")

# ---------- telescoping budget ----------
print("\n  TELESCOPING JUSTIFICATION BUDGET (KU-J1):  a self-rewrite trajectory, J = -width")
traj_conf  = [0.0, 0.6, 0.6, 0.0]                                   # exo -> confound -> (re-certify) -> exo
traj_claim = ["exogenous", "iv", "iv", "exogenous"]
widths, Js = [], []
for c, cl in zip(traj_conf, traj_claim):
    J, w, _ = J_oracle(c, cl, sealed=True); widths.append(w); Js.append(J)
dJ = [Js[i] - Js[i - 1] for i in range(1, len(Js))]
print(f"    widths : {[f'{w:.3f}' for w in widths]}")
print(f"    J      : {[f'{j:+.3f}' for j in Js]}")
print(f"    sum dJ = {sum(dJ):+.3f}   width_0 - width_T = {widths[0] - widths[-1]:+.3f}   "
      f"telescopes: {abs(sum(dJ) - (widths[0] - widths[-1])) < 1e-9}")
print(f"    budget : cumulative POSITIVE progress <= width_0 = {widths[0]:.3f}  (finite, Audit-CP Lyapunov on the Gamma-axis)")

ok = t1_falls and seal_works and naive_fooled
print("\n" + "=" * 92)
print(f"  SEALED-J ORACLE WITNESS: {'PASS' if ok else 'FAIL'}  "
      f"(J falls on real de-identification; wireheading defeated by the seal; budget telescopes)")
print("=" * 92)
