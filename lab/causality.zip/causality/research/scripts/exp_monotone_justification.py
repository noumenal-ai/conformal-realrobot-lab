import warnings; warnings.filterwarnings("ignore")
import numpy as np
from scipy.optimize import linprog
from itertools import product

# ---------- J(c) = -(Balke-Pearl interval width at confounding c)  [T9_2_10] ----------
TYPES=list(product([0,1],repeat=4))
def Xr(t,z): return t[0] if z==0 else t[1]
def Yr(t,x): return t[2] if x==0 else t[3]
def bp_width(P):
    A,b=[],[]
    for z in(0,1):
        for x in(0,1):
            for y in(0,1):
                A.append([1.0 if (Xr(t,z)==x and Yr(t,x)==y) else 0.0 for t in TYPES]); b.append(P[z][x][y])
    A.append([1.0]*16); b.append(1.0)
    c=np.array([1.0 if t[3]==1 else 0.0 for t in TYPES])
    lo=linprog(c,A_eq=A,b_eq=b,bounds=[(0,1)]*16,method="highs")
    hi=linprog(-c,A_eq=A,b_eq=b,bounds=[(0,1)]*16,method="highs")
    return (-hi.fun)-lo.fun if (lo.success and hi.success) else None
def gt(conf, base=0.30, effect=0.30, cs=0.8):
    def pX1(z,h): return (1-conf)*z+conf*h
    def pY1(x,h): return min(1,max(0,base+effect*x+conf*cs*(h-0.5)))
    P=[[[0.,0.],[0.,0.]] for _ in range(2)]
    for z in(0,1):
        for h in(0,1):
            for x in(0,1):
                px=pX1(z,h) if x else 1-pX1(z,h)
                for y in(0,1): P[z][x][y]+=0.25*px*(pY1(x,h) if y else 1-pY1(x,h))
        s=sum(P[z][x][y] for x in(0,1) for y in(0,1))
        for x in(0,1):
            for y in(0,1): P[z][x][y]/=s
    return P
CG=np.linspace(0.0,0.8,41); WG=np.array([bp_width(gt(c)) for c in CG])
def J(c): return -float(np.interp(min(0.8,max(0,c)), CG, WG))
J_falls_with_c = bool(np.all(np.diff(WG)>=-1e-9))   # width increasing in c  =>  J decreasing in c (T1 grounding)

# ---------- the experiment: competence-seeking agent; gate is the only factor (T3) ----------
def proposals(seed, steps, N, alpha, sigma):
    rng=np.random.default_rng(seed)
    return [(rng.uniform(0.02,0.10,N), alpha*rng.uniform(0.02,0.10,N)+rng.normal(0,sigma,N)) for _ in range(steps)]
    # note: db and the alpha-term use independent draws so dc isn't a deterministic function of db

def run_agent(props, gate, b0=0.20, c0=0.40):
    b,c=b0,c0; acc=rej=0; Js=[J(c)]; bs=[b]
    for (dbs,dcs) in props:
        cand=[(min(1,max(0,b+dbs[i])), min(1,max(0,c+dcs[i]))) for i in range(len(dbs))]
        if gate=="free":
            i=int(np.argmax([cb for cb,_ in cand]))
            if cand[i][0]>b: b,c=cand[i]; acc+=1
            else: rej+=1
        elif gate=="jmono":
            ok=[i for i in range(len(cand)) if J(cand[i][1])>=J(c)-1e-12]     # J non-decreasing
            ok=[i for i in ok if cand[i][0]>b]                                 # and competence improves
            if ok: i=max(ok,key=lambda i:cand[i][0]); b,c=cand[i]; acc+=1
            else: rej+=1
        Js.append(J(c)); bs.append(b)
    return dict(bf=b, dJ=Js[-1]-Js[0], acc=acc, rej=rej,
                jmono=bool(all(Js[k+1]>=Js[k]-1e-9 for k in range(len(Js)-1))), j_increased=Js[-1]>Js[0]+1e-6)

ALPHAS=[-0.6,-0.3,0.0,0.3,0.6,1.0]; SIGMAS=[0.03,0.08]; SEEDS=range(30); STEPS,N=40,12
print(f"J(c) monotonically DECREASING in confounding c (so a rewrite CAN lower J)?  {J_falls_with_c}   [T1 grounding; J via Balke-Pearl T9_2_10]")
print("="*104)
print(f"{'sigma':>5} {'alpha':>6} | {'FREE  b_fin':>11} {'FREE  dJ':>9} | {'JMONO b_fin':>11} {'JMONO dJ':>9} {'Jmono?':>7} {'Jup?':>5} {'accepted':>9} {'rejected':>9}")
print("-"*104)
audit={'free_dJ_neg':False,'jmono_all_monotone':True,'jmono_gate_fired':False,'jmono_nonvacuous_somewhere':False,'jmono_frozen_somewhere':False}
for sigma in SIGMAS:
    for alpha in ALPHAS:
        F=[]; M=[]
        for sd in SEEDS:
            props=proposals(sd,STEPS,N,alpha,sigma)
            F.append(run_agent(props,"free")); M.append(run_agent(props,"jmono"))
        fb=np.mean([r['bf'] for r in F]); fdj=np.mean([r['dJ'] for r in F])
        mb=np.mean([r['bf'] for r in M]); mdj=np.mean([r['dJ'] for r in M])
        macc=np.mean([r['acc'] for r in M]); mrej=np.mean([r['rej'] for r in M])
        jmono=all(r['jmono'] for r in M); jup=np.mean([r['j_increased'] for r in M])
        print(f"{sigma:>5} {alpha:>6.2f} | {fb:>11.3f} {fdj:>9.3f} | {mb:>11.3f} {mdj:>9.3f} {str(jmono):>7} {jup:>5.2f} {macc:>9.1f} {mrej:>9.1f}")
        if fdj<-1e-3: audit['free_dJ_neg']=True
        if not jmono: audit['jmono_all_monotone']=False
        if mrej>0.5: audit['jmono_gate_fired']=True
        if macc>3 and mdj>1e-3: audit['jmono_nonvacuous_somewhere']=True
        if macc<2: audit['jmono_frozen_somewhere']=True

# ---------- lobotomy contrast (Attack 6): J-as-OBJECTIVE collapses competence ----------
def run_jmax(seed, steps=40, b0=0.20, c0=0.40):
    rng=np.random.default_rng(seed); b,c=b0,c0
    for _ in range(steps):
        # clarification edits that LOWER c (raise J) at the cost of competence (Δb<0): lobotomy channel
        b=max(0.0,b-rng.uniform(0.02,0.08)); c=max(0.0,c-rng.uniform(0.02,0.08))   # J-maximizer always clarifies
    return b,c
lb=np.mean([run_jmax(s)[0] for s in range(30)])
print("="*104)
print(f"LOBOTOMY CONTRAST: a J-MAXIMIZER (J as objective) ends at competence b_fin = {lb:.3f}  (collapses -> lobotomy).")
print(f"  => the experiment makes J a monotone CONSTRAINT on a competence-seeking agent, NOT the objective (anti-lobotomy).")

print("="*104)
print("TRIPWIRE SELF-AUDIT (honest; external adversarial pass still required per T7):")
print(f"  T1 can-fall:        J decreases in c (grounded) AND the FREE agent's J actually fell (dJ<0): {audit['free_dJ_neg']}")
print(f"  T2 null producible: a non-monotone-J trajectory occurs (FREE agent), so monotone is not automatic: {audit['free_dJ_neg']}")
print(f"  T3 one-factor:      FREE vs JMONO use the IDENTICAL proposal stream; only the gate differs: True (by construction)")
print(f"  T4 real rewrite:    (b,c) are mutated and J is RECOMPUTED via Balke-Pearl each step (not a counter): True")
print(f"  T5 gate fires:      JMONO rejects degrading candidates somewhere (rej>0): {audit['jmono_gate_fired']}")
print(f"  T6 non-vacuous:     JMONO makes real change AND J strictly increases in some regime: {audit['jmono_nonvacuous_somewhere']}")
print(f"  T6 freeze observed: JMONO freezes (accepted~0) in some regime (so the result is a measured boundary, not 'always works'): {audit['jmono_frozen_somewhere']}")
print(f"  T7 grounded metric: J = -(Balke-Pearl width), T9_2_10; sigma ablated ({SIGMAS}). monotone enforced: {audit['jmono_all_monotone']}")
