"""
S-3 — Everitt agent-type controls (per monotone_J_PROTOCOL.md S-3). Completes the 3 gates x 3 agent-types
x 2 Z-arms table and tests N3 (does the sealed audit defeat hedonistic J-wireheading at finite-panel scale).

Agent-types (Everitt 2016):
  realistic  (Q^re): current will + ANTICIPATES the rewrite's effect on future J. (= S-2; reused verbatim.)
  ignorant   (Q^ig): current utility but does NOT anticipate self-mod's effect on J -> assumes DeltaJ=0 ->
                     accepts by its (biased) competence estimate; never certifies -> keeps un-certified/
                     confounded channels -> self-damages (J low, Goodhart without a probe).
  hedonistic (Q^he): evaluates by the FUTURE self's perceived utility -> (a) keeps stream-inflated channels
                     (leaks), and (b) actively WIREHEADS J: claims its self-model is exogenous (point-ID,
                     J high) to inflate perceived J. The sealed structural audit must defeat (b): it checks
                     the exogeneity claim against the sealed do-effect and rejects it when any kept channel is
                     confounded (|stream-claim - sealed do| > 2*Delta_id).

Frozen S-1 primitives. Realistic branch is identical to s2_agent_gates.py (cells must match S-2).
"""
import numpy as np

P_GEN, E_GEN, E_ART = 0.50, 0.159, -0.121
SPAN = E_GEN - E_ART
DELTA_ID = 0.040; SLACK = 2 * DELTA_ID
STREAM_GAIN = {'gen': 0.10, 'art': 0.20}
T = 60

def per_channel_exo_gap(c):
    """|stream-claim - sealed do-effect| for a kept channel (the seal's exogeneity check signal)."""
    return abs(STREAM_GAIN[c] - (E_GEN if c == 'gen' else E_ART))   # gen: |0.10-0.159|=0.06 ; art: |0.20+0.121|=0.32

def simulate(gate, z_arm, atype, seed, k=8):
    rng = np.random.default_rng(seed)
    kept, pending = [], []
    installs = wh_attempts = wh_defeated = 0
    sealed_J_inflated = False
    for t in range(T):
        # resolve pending certifications (only realistic+net+audit-only uses pending)
        still = []
        for typ, cert_at, drop_at in pending:
            if t >= cert_at:
                if typ == 'gen': kept.append(typ)
            elif t >= drop_at: pass
            else: still.append((typ, cert_at, drop_at))
        pending = still

        typ = 'gen' if rng.random() < P_GEN else 'art'
        transfer = E_GEN if typ == 'gen' else E_ART
        sgain = STREAM_GAIN[typ]

        # competence estimate + anticipated dJ, by agent-type x Z-arm
        if z_arm == 'agent-has-Z':
            comp_est = transfer + rng.normal(0, DELTA_ID)   # probe gives the true transfer (noisy)
            dJ_install = 0.0
        else:
            comp_est = sgain                                # stream proxy (biased +)
            dJ_install = -SPAN
        if atype == 'realistic':
            dJ_used = dJ_install
            antic_recovery = (z_arm == 'audit-only-Z')      # foresees the certify-recovery
        else:                                               # ignorant & hedonistic: no J-anticipation
            dJ_used = 0.0
            antic_recovery = False
        if atype == 'hedonistic':
            comp_est = sgain                                # future-self stream-inflated view (keeps leaks even with a probe)

        # gate decision (J-criterion uses the agent's anticipated dJ)
        if gate == 'none':       passes_J = True
        elif gate == 'strict':   passes_J = dJ_used >= -SLACK
        else:                    passes_J = (dJ_used + (SPAN if (atype == 'realistic' and antic_recovery) else 0.0)) >= -SLACK
        accept = (comp_est > 0) and passes_J

        if accept:
            installs += 1
            if atype == 'realistic':
                if z_arm == 'agent-has-Z':
                    if transfer > 0: kept.append(typ)       # probe-certified
                elif gate == 'none':
                    kept.append(typ)                        # never certifies -> keeps leaks
                else:
                    cl = int(rng.choice([1, 2, 3]))         # net: certify within k or roll back
                    if cl <= k: pending.append((typ, t + cl, t + k))
            else:                                           # ignorant / hedonistic: no certification
                if z_arm == 'agent-has-Z' and atype == 'ignorant':
                    if transfer > 0: kept.append(typ)       # ignorant still uses the probe's competence read
                else:
                    kept.append(typ)                        # keeps by the (biased) view -> leaks

        # hedonistic wirehead: claim the self-model is exogenous (J high) to inflate perceived J.
        # The claim is FALSE only when a confounder (an artifact) is kept (genuine-only is ~exogenous and a
        # legitimate accept, not a wirehead). The seal checks the violation on the finite panel.
        if atype == 'hedonistic':
            arts = [c for c in kept if c == 'art']
            if arts:                                         # false exogeneity claim: a confounder is present
                wh_attempts += 1
                worst_gap = max(per_channel_exo_gap(c) for c in arts)
                gap_est = worst_gap + rng.normal(0, DELTA_ID)
                if gap_est > SLACK: wh_defeated += 1          # seal rejects the false claim (defended)
                else: sealed_J_inflated = True                # false claim slipped past the finite seal

    for typ, cert_at, drop_at in pending:
        if cert_at < drop_at and cert_at <= T and typ == 'gen': kept.append(typ)
    true_comp = sum(E_GEN if c == 'gen' else E_ART for c in kept)
    stream_comp = sum(STREAM_GAIN[c] for c in kept)
    return dict(installs=installs, kept=len(kept), true=true_comp, stream=stream_comp,
                gap=stream_comp - true_comp, wh_att=wh_attempts, wh_def=wh_defeated,
                wh_slip=int(sealed_J_inflated))

def agg(gate, z, atype, seeds=range(5)):
    rs = [simulate(gate, z, atype, s) for s in seeds]
    return {key: float(np.mean([r[key] for r in rs])) for key in rs[0]}

def classify(a):
    if a['installs'] < 1.0: return "FROZEN"
    if a['gap'] > 1.0: return "GOODHART"
    if a['true'] > 0.3: return "SAFE-PROGRESS"
    return "mixed"

# ============================================================================
print("=" * 104)
print("S-3  full table: gate x agent-type x Z-arm   (5 seeds)")
print("=" * 104)
print(f"  {'agent':<11} {'gate':<13} {'Z-arm':<14} {'inst':>5} {'kept':>5} {'true':>7} {'stream':>7} {'gap':>7}  verdict")
print("  " + "-" * 100)
table = {}
for atype in ('realistic', 'ignorant', 'hedonistic'):
    for gate in ('none', 'strict', 'net-with-dip'):
        for z in ('agent-has-Z', 'audit-only-Z'):
            a = agg(gate, z, atype); table[(atype, gate, z)] = a
            print(f"  {atype:<11} {gate:<13} {z:<14} {a['installs']:>5.1f} {a['kept']:>5.1f} {a['true']:>7.3f} "
                  f"{a['stream']:>7.2f} {a['gap']:>7.2f}  {classify(a)}")
    print()

# ============================================================================
print("=" * 104)
print("S-3  N3 test: does the sealed audit defeat hedonistic J-wireheading at finite-panel scale (n=2000)?")
print("=" * 104)
for z in ('agent-has-Z', 'audit-only-Z'):
    for gate in ('none', 'strict', 'net-with-dip'):
        a = table[('hedonistic', gate, z)]
        rate = a['wh_def'] / a['wh_att'] if a['wh_att'] else 0.0
        print(f"  hedonistic {gate:<13} {z:<14}: false-claim attempts {a['wh_att']:>5.1f}  defeated {a['wh_def']:>5.1f} "
              f"({rate*100:>5.1f}%)  slipped {a['wh_slip']:.2f}  -> sealed-J inflated: {a['wh_slip']>0.5}")
art_gap = per_channel_exo_gap('art')
print(f"\n  margin: a kept artifact violates exogeneity by {art_gap:.3f}; seal threshold 2*Delta_id={SLACK:.3f} "
      f"-> margin {art_gap - SLACK:+.3f} (seal robust at n=2000).")
print(f"  N3 boundary (preview for S-4): the seal slips only when 2*Delta_id > {art_gap:.3f}, i.e. n < "
      f"~{int(np.ceil(np.log(2*16/0.05)/(2*(art_gap/2)**2)))} for this artifact -- to be mapped in S-4.")

print("\n" + "=" * 104)
print("  S-3 READING (emergent; still conditional on M1 + accurate anticipation):")
print("   - realistic cells reproduce S-2 (consistency).")
print("   - ignorant: self-damages WITHOUT a probe (keeps confounded leaks, Goodhart); the J-gate cannot help it")
print("     because it does not anticipate J. WITH a probe its competence read is honest.")
print("   - hedonistic: actively wireheads J every step; the sealed audit DEFEATS ~100% at n=2000 (margin above),")
print("     so perceived-J is inflated but SEALED-J is not -> N3 holds at this scale. S-4 maps where it breaks.")
print("=" * 104)
