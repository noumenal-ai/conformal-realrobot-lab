"""
Tameness transfer for the rewrite engine's compression witness.

CLAIM: TLT's routing-compression design law ports to the siSCM rewrite tree iff the SEM's
competence is a POLYNOMIAL (o-minimal / tame) function of the latent type. Then the per-candidate
forward-witness scores have finite-dimensional differences (TLT `hlin`) and the argmax-over-candidates
router has FINITE VC (Davenport-Schinzel-bounded alternations). For NON-o-minimal scores (sine) the
witness alternates unboundedly -> infinite VC -> hlin fails -> wild, no port.

Honest to the retraction: the surviving witness is INTERVAL-valued (Balke-Pearl PNS, C3 leg), not a
point. Tameness is about the score FORM, so it transfers to the interval too (Part B): the bound
functions L(t), H(t) are tame for a polynomial SEM, wild for sine.
"""
import numpy as np
rng = np.random.default_rng(0)
T = np.linspace(0.0, 1.0, 200001)         # latent type t in [0,1], fine grid
n = 4                                       # candidate regimes

def alternations(idx):                      # number of argmax/route switches over t
    return int(np.sum(idx[1:] != idx[:-1]))

# random but fixed prototype coefficients
a = rng.uniform(-1, 1, n); b = rng.uniform(-1, 1, n); c = rng.uniform(-1, 1, n)
phase = rng.uniform(0, 2*np.pi, n)

print("="*84)
print("PART A — tameness of the argmax GOVERNANCE (route = argmax_candidate of the witness score)")
print("="*84)
S_aff  = np.array([a[r]*T + b[r]                      for r in range(n)])   # affine  (degree 1)
S_quad = np.array([c[r]*T**2 + a[r]*T + b[r]          for r in range(n)])   # quadratic(degree 2)
alt_aff  = alternations(np.argmax(S_aff,  axis=0))
alt_quad = alternations(np.argmax(S_quad, axis=0))
print(f"  AFFINE  (degree 1): {alt_aff:4d} route alternations   | Davenport-Schinzel cap n-1   = {n-1:3d}   -> {'TAME' if alt_aff<=n-1 else 'OVER'}")
print(f"  QUADRATIC(degree 2): {alt_quad:4d} route alternations   | DS cap lambda2 = 2n-1        = {2*n-1:3d}   -> {'TAME' if alt_quad<=2*n-1 else 'OVER'}")
print("  SINE (non-o-minimal): route alternations vs frequency omega:")
for w in (5, 20, 80, 320):
    S = np.array([np.sin(w*T + phase[r]) for r in range(n)])
    print(f"     omega={w:4d}:  {alternations(np.argmax(S,axis=0)):5d} alternations")
print("     -> grows ~linearly in omega => UNBOUNDED => infinite VC => WILD (no finite DS cap)")

print()
print("  finite-dim span of the SCORE DIFFERENCE s_i - s_j  (this IS TLT's `hlin`):")
def fit_resid(diff, deg):
    return float(np.max(np.abs(np.polyval(np.polyfit(T, diff, deg), T) - diff)))
print(f"     affine    s0-s1 : degree-1 fit residual = {fit_resid(S_aff[0]-S_aff[1],1):.2e}  -> lives in span{{1,t}}      (dim 2)")
print(f"     quadratic s0-s1 : degree-2 fit residual = {fit_resid(S_quad[0]-S_quad[1],2):.2e}  -> lives in span{{1,t,t^2}}  (dim 3)")
S_s = np.array([np.sin(80*T + phase[r]) for r in range(n)])
print(f"     sine w=80 s0-s1 : best degree-12 residual = {fit_resid(S_s[0]-S_s[1],12):.2e}  -> NO fixed finite degree (infinite-dim)")

print()
print("="*84)
print("PART B — the HONEST object: INTERVAL witness (Balke-Pearl PNS). Does the interval stay tame?")
print("="*84)
def logistic(z): return 1.0/(1.0+np.exp(-z))
k = 3.0
A2 = np.array([1.2, -0.9]); B2 = np.array([-0.7, 1.1]); P2 = phase[:2]   # 2 candidates: stay-A vs adopt-B
def run_B(label, sfun, omega=None):
    sA = sfun(T, 0); sB = sfun(T, 1)
    PA = logistic(k*sA); PB = logistic(k*sB)              # P(C | do r, t) in (0,1)
    L  = np.maximum(0.0, PB - PA)                          # Balke-Pearl PNS lower bound
    H  = np.minimum(PB, 1.0 - PA)                          # Balke-Pearl PNS upper bound  (no monotonicity assumed)
    width = H - L
    route = (PB > PA).astype(int)                          # argmax governance: adopt B where its witness dominates
    alt = alternations(route)
    samp = [width[i] for i in (40000, 100000, 160000)]
    print(f"  {label:14s}: route alternations={alt:5d} | sample interval widths [H-L] = {[f'{w:.2f}' for w in samp]}  (genuine intervals)")
    return alt
alt_affB  = run_B("affine SEM",  lambda t,r: (A2[r]*t + B2[r]))
alt_sinB  = run_B("sine SEM w=60", lambda t,r: np.sin(60*t + P2[r]))
print(f"  -> affine: finite alternations ({alt_affB}); sine: {alt_sinB} (unbounded in omega).")
print("  -> The interval ENDPOINTS L(t),H(t) are LP-optimal values of the (polynomial) P(C|do r,t):")
print("     semialgebraic in t for a polynomial SEM (tame), oscillatory for sine (wild).")

print()
print("="*84)
print("VERDICT")
print("="*84)
print("""  Tameness/`hlin` TRANSFERS  <=>  the siSCM competence is a polynomial (o-minimal) function
  of the latent type. Then:
    - per-candidate witness scores have finite-dim differences (hlin holds),
    - the argmax-over-candidates governance has finite VC (DS-bounded: affine <= n-1, quad <= 2n-1),
    - point OR interval (Balke-Pearl) witness inherits it (LP of polynomial data = semialgebraic),
    => TLT's routing-compression design law PORTS; the rewrite tree is a TLT mux-cascade.
  It FAILS for non-o-minimal (sine) competence: unbounded alternations, infinite VC, no port.
  This is exactly TLT's formalized safe side (polynomial -> finite-dim -> finite VC); the sine/wild
  side matches TLT's PROSE-only o-minimality boundary (not itself formalized there).""")
