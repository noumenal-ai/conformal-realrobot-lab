"""
mechanised_cbn_newcomb.py -- a FAITHFUL implementation of MacDermott, Everitt & Belardinelli 2023,
"Characterising Decision Theories with Mechanised Causal Graphs" (arXiv:2307.10987), in DoWhy.

Def 3 (Mechanised CBN): variables partition into OBJECT-level V and MECHANISM-level Vtilde; each object
variable V has a single mechanism parent Vtilde whose VALUE sets Pr(V | Pa_V). The mechanism of a decision
variable is its DECISION RULE.

Newcomb's problem (Fig 1c / Fig 4) as a mechanised graph:
    Dtilde -> D        (the decision-rule node sets the decision)
    Dtilde -> Ptilde   (the predictor reads the agent's decision RULE: 99% accurate)
    Ptilde -> P        (the prediction mechanism sets the prediction / opaque-box contents)
    D -> U,  P -> U     (utility from decision + prediction)            [no D->P edge: decision doesn't cause prediction]

WITNESS (the discriminating result, Fig 4): the SAME graph, three operations, three different recommended actions:
    EDT  = CONDITION on D        -> one-box
    CDT  = do(D)   [OBJECT node]  -> two-box
    FDT  = do(Dtilde) [MECHANISM node] -> one-box
do(Dtilde) != do(D) giving OPPOSITE recommendations witnesses that the mechanism-node (structure) intervention is
genuinely distinct from the object-node (value) intervention -- the basis of the self-rewrite operator. Each
DoWhy number is cross-checked against an exact analytic oracle.
"""
import warnings; warnings.filterwarnings("ignore")
import numpy as np, pandas as pd, networkx as nx
from dowhy import gcm

ACC = 0.99                      # predictor accuracy
PAYOFF = {("one","predict_one"):1_000_000, ("one","predict_two"):0,
          ("two","predict_one"):1_001_000, ("two","predict_two"):1_000}
def util(D, P): return np.array([PAYOFF[(d,p)] for d,p in zip(D,P)], float)

# ---------------------------------------------------------------------------
# Build the mechanised CBN in DoWhy and fit it to the generating distribution
# ---------------------------------------------------------------------------
G = nx.DiGraph([("Dtilde","D"), ("Dtilde","Ptilde"), ("Ptilde","P")])

rng = np.random.default_rng(0)
def gen(N):
    dt = rng.choice(["rule_one","rule_two"], N)                          # decision-rule prior 50/50
    D  = np.where(dt=="rule_one","one","two")                            # Dtilde -> D (deterministic)
    match = rng.random(N) < ACC                                          # predictor reads the RULE, 99% right
    pt = np.where((dt=="rule_one")==match, "pred_one", "pred_two")       # Dtilde -> Ptilde
    P  = np.where(pt=="pred_one","predict_one","predict_two")            # Ptilde -> P (deterministic)
    return pd.DataFrame({"Dtilde":dt,"D":D,"Ptilde":pt,"P":P}).astype("object")

data = gen(60_000)
scm = gcm.StructuralCausalModel(G)
gcm.auto.assign_causal_mechanisms(scm, data)
gcm.fit(scm, data)

def EU_from(df, fixedD=None):
    D = df["D"].to_numpy() if fixedD is None else np.array([fixedD]*len(df))
    return util(D, df["P"].to_numpy()).mean()

# ---------------------------------------------------------------------------
# The three operations
# ---------------------------------------------------------------------------
N = 200_000
obs = gcm.draw_samples(scm, N)                            # observational distribution P(V)
# do(D) severs Dtilde->D and there is no D->P edge, so P _|_ do(D): the interventional P-distribution is the
# SAME for do(D=one) and do(D=two). We draw it ONCE and evaluate both actions on common P (the dominance margin
# is exactly the $1000 transparent box, which is otherwise swamped by Monte-Carlo noise on the $1M opaque box).
_cdt_P = gcm.interventional_samples(scm, {"D": (lambda _x: "one")}, num_samples_to_draw=N)["P"].to_numpy()

def edt(d):                                               # condition on D=d
    sub = obs[obs["D"]==d]
    return util(sub["D"].to_numpy(), sub["P"].to_numpy()).mean()
def cdt(d):                                               # do(D=d) on the OBJECT node, evaluated on common P
    return util(np.array([d]*len(_cdt_P)), _cdt_P).mean()
def fdt(dt):                                              # do(Dtilde=dt) on the MECHANISM node
    s = gcm.interventional_samples(scm, {"Dtilde": (lambda v: (lambda _x: v))(dt)}, num_samples_to_draw=N)
    return EU_from(s)

# ---------------------------------------------------------------------------
# Exact analytic oracle (ground truth)
# ---------------------------------------------------------------------------
def oracle():
    # EDT: condition on D=one => Dtilde=rule_one => P=predict_one w.p. ACC
    edt_one = ACC*PAYOFF[("one","predict_one")] + (1-ACC)*PAYOFF[("one","predict_two")]
    edt_two = ACC*PAYOFF[("two","predict_two")] + (1-ACC)*PAYOFF[("two","predict_one")]
    # CDT: do(D=d) severs Dtilde->D; P ~ prior over Dtilde (50/50) => P=predict_one w.p. 0.5
    cdt_one = 0.5*PAYOFF[("one","predict_one")] + 0.5*PAYOFF[("one","predict_two")]
    cdt_two = 0.5*PAYOFF[("two","predict_one")] + 0.5*PAYOFF[("two","predict_two")]
    # FDT: do(Dtilde=dt) sets D AND P (via Ptilde)
    fdt_one = ACC*PAYOFF[("one","predict_one")] + (1-ACC)*PAYOFF[("one","predict_two")]
    fdt_two = ACC*PAYOFF[("two","predict_two")] + (1-ACC)*PAYOFF[("two","predict_one")]
    return {"EDT":(edt_one,edt_two), "CDT":(cdt_one,cdt_two), "FDT":(fdt_one,fdt_two)}

# ---------------------------------------------------------------------------
# Run + report
# ---------------------------------------------------------------------------
print("="*92)
print("WITNESS: MacDermott Fig 4 -- EDT / CDT / FDT on Newcomb in a mechanised CBN (DoWhy)")
print("="*92)
ora = oracle()
rows = [
    ("EDT  condition(D)        ", edt("one"),  edt("two"),  ora["EDT"], "one"),
    ("CDT  do(D)   [object]    ", cdt("one"),  cdt("two"),  ora["CDT"], "two"),
    ("FDT  do(Dtilde)[mechanism]", fdt("rule_one"), fdt("rule_two"), ora["FDT"], "one"),
]
print(f"\n  {'operation':<27} {'E[U|one-box]':>14} {'E[U|two-box]':>14}   {'action':>7}  {'oracle match':>12}")
print("  " + "-"*86)
allok = True
verdict = {}
for name, u_one, u_two, (o_one, o_two), expect in rows:
    action = "one" if u_one > u_two else "two"
    tol_o = max(0.03*abs(o_one), 2000); tol_t = max(0.03*abs(o_two), 2000)
    match = abs(u_one-o_one) < tol_o and abs(u_two-o_two) < tol_t and action==expect
    allok &= match; verdict[name.split()[0]] = action
    print(f"  {name:<27} {u_one:>14,.0f} {u_two:>14,.0f}   {action+'-box':>7}  {'OK' if match else 'XX':>12}")
print(f"\n  oracle: EDT one={ora['EDT'][0]:,.0f}/two={ora['EDT'][1]:,.0f}  "
      f"CDT one={ora['CDT'][0]:,.0f}/two={ora['CDT'][1]:,.0f}  "
      f"FDT one={ora['FDT'][0]:,.0f}/two={ora['FDT'][1]:,.0f}")

three_way = verdict.get("EDT")=="one" and verdict.get("CDT")=="two" and verdict.get("FDT")=="one"
print("\n" + "="*92)
print(f"  EDT one-box / CDT two-box / FDT one-box  (Fig 4 three-way distinction): {'REPRODUCED' if three_way else 'NOT'}")
print(f"  do(Dtilde) [mechanism] != do(D) [object]  -> OPPOSITE actions: "
      f"{verdict.get('FDT')} vs {verdict.get('CDT')}   (witnesses the structure-intervention operator)")
print(f"  all DoWhy values match analytic oracle: {allok}")
print("="*92)

# ---------------------------------------------------------------------------
# IDENTITY: Gladyshev structure intervention (rewrite F)  ==  MacDermott mechanism-node do
# ---------------------------------------------------------------------------
print("\n" + "-"*92)
print("IDENTITY CHECK: Gladyshev structure intervention on F_X  ==  MacDermott do(mechanism node)")
print("-"*92)
import tsem
DEPTH = 6
# Gladyshev side: Sec-6 structure intervention rewriting F_X=1 -> F_X=0 (object trajectory, i>0 enforced)
_, _, gladyshev_struct = tsem.section6_trajectories(DEPTH)
# MacDermott side: object X_t governed by mechanism node Xtilde in {const1, const0}; do(Xtilde=const0)
#   installs F_X=const0. X_0 = initial (=1); for t>0, X_t = 1 if mechanism==const1 else 0.
def macdermott_mechanism_do(mechanism, depth, x0=1):
    return [x0] + [(1 if mechanism == "const1" else 0)] * depth
macd_struct = macdermott_mechanism_do("const0", DEPTH)     # do(Xtilde = const0)
print(f"   Gladyshev  structure do(F_X<-0) : {''.join(map(str, gladyshev_struct))}")
print(f"   MacDermott do(Xtilde = const0)  : {''.join(map(str, macd_struct))}")
identical = gladyshev_struct == macd_struct
print(f"   >>> SAME object dynamics (the two operators coincide): {identical}")
print("="*92)
