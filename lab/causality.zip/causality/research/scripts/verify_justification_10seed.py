import numpy as np, json
g = [.20, .45, .30, .70, .92]; K = len(g); confounded = {2}; floor = 0.5
comp_trajs, just_trajs, commits = [], [], []
for sd in range(10):
    rng = np.random.default_rng(sd)
    order = list(rng.permutation(K))              # seed-dependent EXPLORATION ORDER
    identified, intervals, comp, just = {}, {}, [], []
    for theta in order:
        comp.append(g[theta])                     # competence while exploring (non-monotone)
        est = (rng.random(4000) < g[theta]).mean()
        (intervals if theta in confounded else identified).__setitem__(theta, est)
        just.append(len(identified) + 0.5*len(intervals))   # justification (point=1, interval=0.5)
    committable = {t: identified[t] for t in identified if identified[t] >= floor}
    commit = max(committable, key=committable.get)
    comp_trajs.append([round(c,3) for c in comp]); just_trajs.append(just); commits.append(g[commit])
# never-regress reference (fixed order, local +1 candidates) -> freezes at local optimum
s = 0; nr = [g[0]]
for _ in range(K-1):
    best = max([s] + ([s+1] if s+1 < K else []), key=lambda c: g[c])
    if g[best] > g[s]: s = best
    nr.append(round(g[s],3))
out = {"comp": comp_trajs, "just": just_trajs, "commits": commits, "never_regress": nr,
       "all_commit_global": all(abs(c-0.92) < 1e-9 for c in commits),
       "all_just_monotone": all(all(j[i+1] >= j[i]-1e-9 for i in range(len(j)-1)) for j in just_trajs),
       "any_comp_nonmonotone": any(any(c[i+1] < c[i]-1e-9 for i in range(len(c)-1)) for c in comp_trajs)}
print(json.dumps(out))
import sys; print(f"\nall commit to global optimum 0.92? {out['all_commit_global']}", file=sys.stderr)
print(f"all justification monotone (10/10)? {out['all_just_monotone']}", file=sys.stderr)
print(f"competence non-monotone (exploration)? {out['any_comp_nonmonotone']}", file=sys.stderr)
print(f"never-regress reference path: {nr} (frozen at 0.45)", file=sys.stderr)
