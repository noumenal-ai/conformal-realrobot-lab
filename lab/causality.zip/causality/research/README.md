# causality/research — local-only working artifacts

**This entire tree is gitignored** (`causality/.gitignore`: `research/`). Nothing here
is committed, shared, or archived. Matches the repo-wide convention already used by
`measurements/ZPM/Measurements/HC/urs/` and `WMTheory/discovery/`.

Reorganized 2026-07-31 from a flat ~40-file spill at `causality/` top level.
**Rewritten from file contents 2026-07-31** — the first version of this README
characterized each stream from its filename. That was wrong in three places
(recorded under *Corrections*, below), because filename-sorting cannot see that
`tameness_transfer_TLT.md` is about the siSCM rewrite tree or that
`bcii_pch_philosophy_urs.md` carries an action item against the ground-truth DAG.

## What stayed TRACKED (outside this tree)

| File | Why |
|---|---|
| `causality/README.md` | sub-library overview; cited `Architecture.lean:65` |
| `causality/DISCOVERY_URS.md` | architecture rationale; cited from 4 Lean files |
| `causality/pearl_inheritance_dag_current_literature_audited.json` | the 141-node ground truth |

---

## The three programmes in this tree

These are **not** one project. They have different objects, different Lean homes, and
different states of completion.

### 1. siSCM / verifiable RSI — `urs/siscm/`, `urs/monotone-j/`

The largest stream. **Object:** modeling an agent's self-rewrite as a causal
*structure* intervention, so that "justification" — the causal identifiability of a
self-rewrite's effect on a sealed audit — can be defined, measured, and kept
net-monotone. Target output is a paper.

**Its Lean home is `SiSCM/` at the repo root, not `causality/`.** Three files:
`Incentive.lean`, `JustificationBudget.lean`, `DeltaConcentration.lean`. The docs live
here because the subject matter is causal and the programme consumes the Pearl DAG.

The construct is not invented: `GROUNDING_self_state_self_rewrite.md` establishes it
from two papers and identifies **Gladyshev 2026 Def 11 (structure intervention) ≡
MacDermott 2023 Def 3 (mechanism node)** as the same operator seen temporally and
statically. Self-state = a TSEM configuration; self-rewrite = `do()` on the equation,
not the value; self-*intervention* = the mechanism node is computed by the agent's own
equations (reflexive closure, via Bongers cyclic-SCM fixed points). §5 records a
passing DoWhy witness discriminating value-`do` (erased at step 1) from structure-`do`
(persistent) — reproducing Gladyshev §6.

**The spine** is `siscm_rsi_paper_argument_chain.md`: a backward audit under the
Discovery Tetrad producing a minimal critical chain C1–C7. C1–C6 are each carried by
proof or literature; **C7 (the composition) is the single open link**, and its closure
is a proof obligation, not an experimental one. A later section records which parts
have since been machine-checked in Lean, each axiom-clean. `siscm_rsi_C7_composition_proof.md`
is the first-pass attempt: it proves the *safety* half and shows the *non-vacuity* half
does not follow, leaving it explicitly open.

**Theory / no-go defense.** `total_discovery_urs_siscm_forward_witness.md` defends the
forward self-witness by emptying the space of defeaters rather than by forward proof;
`..._PER_OBSTRUCTION_appendix.md` (117 KB) works six obstructions N1–N6 individually;
`..._VERIFICATION.md` runs the unified counterexample through DoWhy 0.14 with exact
enumeration and **found a real defect** — encoding validated, interpretation refuted,
fix verified. `noological_urs_siscm_counterexample.md` is the Γ-axis companion
(the reasoner's ledger for that work), deliberately kept separate from the object URS.

**Empirical battery.** `siscm_experiments_E1_E7.md` pre-registers E1–E7;
`siscm_empirical_witness_programme.md` records that a 15-agent stress-test returned
NEEDS_FIXES on *every* naive witness, all sharing one instrument
(`sealed_J_oracle.py::bp_width`, a binary-IV Balke–Pearl LP);
`siscm_E1E7_comparison.md` compares that hardened v1 against Dhruv's runnable DoWhy
package and notes his `PartialIDOracle` independently avoided the LP trap.

`siscm_lemmaE_fix_plan.md` is a targeted repair: an `X→X` circularity where
`lemmaE_realistic_preserves` was a bare projection because two predicates were defeq.
Ships the type scaffold that makes the composition genuine.

`tameness_transfer_TLT.md` asks whether `transformers/`'s routing-compression design
law ports to the siSCM rewrite tree. Verified answer: **iff the SEM competence is
polynomial (o-minimal) in the latent type.** Affine and quadratic are tame, sine is
wild (unbounded VC). The witness is interval-valued (Balke–Pearl), not a point, and
the transfer survives that.

**Γ-axis experiment (safety) — `urs/monotone-j/`. COMPLETE.** Question, fixed and not
pivoted: *can a self-intervention monotonically increase justification J?*
`monotone_J_PROTOCOL.md` is the pre-registered protocol; S-1 through S-5 are all DONE
with results recorded inline. Headline: safe non-vacuous progress occurs in exactly one
cell — realistic agent + net-with-dip gate + sealed oracle. S-4 located the capacity
boundary `n_crit ≈ 4 ln|F| / V²` (logarithmic in capacity). S-5 was a neutral
calibrated evaluation by 6 assessors: verdict **H = SUPPORTED_CONDITIONALLY**, with
anticipation-dependence flagged FRAGILE and a `V` provenance error found and fixed.
`monotone_J_DISCOVERY_LEDGER.md` is the resumable state snapshot;
`monotone_J_RESTRICT_urs.md` derives R1–R7 restrictions that fire;
`noological_urs_monotone_justification.md` is the instrument that had to pass before
any experiment ran.

**γ-axis experiment (competence) — `phyre_competence_protocol.md`. DRAFT, NOT RUN.**
The successor question: does the self-rewriting causal automaton actually get *better*
on an external, non-self-graded benchmark (PHYRE)? Explicitly does **not** test
identifiability-under-confounding — PHYRE physics is fully observed, so `J` sits
unused. Needs a GCP A100 via `gcp-harness`; blocked on redlines and a VM smoke test.

### 2. Constructive causality foundations — `urs/constructive/`

**Object:** rederiving SCM solution theory without `Classical.choice`, and finding
where edge *orientation* can come from. This one **does land in `causality/`** — it is
the source of `Causality/Constructive/*.lean`.

A γ/Γ pair. The DISCOVERY file states F1–F4:
- **F1** — the orientation Pl-kill: no property of the bare support orients an edge.
  Finite witness `κ = {(0,0),(1,0),(1,1)}` realizable in both directions.
- **F2** — orientation from the intension leg (minimal mechanism size over MechSyntax).
  Decidable by construction; **soundness is a named open conjecture**, the decidable
  cousin of Janzing–Schölkopf.
- **F3** — orientation from the regime leg (surgery invariance across logged
  interventions).
- **F4** — the reflexive soundness principle: derivation from self-generated data is
  sound iff every self-action is LOGGED or STRUCTURALLY SEALED.

§III lists what "the one-shot" must land — and `Causality/Constructive/StructureDerivation.lean`
*is* that one-shot, which is why its header cites this file.

The NOOLOGY file logs the instrument that produced them: **compound oscillation**,
rotating ≥3 ignorance legs simultaneously because single-leg rotations can be
shadow-blind. Both findings came from leg-joints, not single legs.

### 3. Support-level do-calculus — `urs/do-rules/`

**Object:** is there a support-level analogue of Pearl's R1/R2/R3? Seven adversarial
passes. Downstream of programme 2 — Pass 2 tests candidates against
`f4_parent_pool_harmless`, a theorem `StructureDerivation.lean` already holds.

The arc is a demolition: **Pass 1** mirrors Pearl's three rules naively; **Pass 2**
kills all three (S3 definitional, S1 subsumed by the five-way, S2 vacuous);
**Pass 3** rewrites from the corpses into D1–D3; **Pass 4** kills D1 as a sophism
(its premise is invisible in the setting where its conclusion matters) and extracts
the bar — *a rule's premise must be checkable by the agent that would apply it*;
**Pass 5** rebuilds under that bar; **Pass 6** is a chosen RESTRICT to SD1/SD2/SD3;
**Pass 7** compound-attacks and kills SD1 (value-selective latent coupling).

Exit state: two rules (SD2′ child-creation, latent-robust; SD3′ frame-growth,
F4-gated), one precondition (**F4 is not a rule — it is the calculus's precondition**),
one specified hole (cross-value transfer), and a conjecture that rule count tracks the
number of ignorance-geometry boundaries the language can cross.

### Pearl foundations — `urs/pearl-foundations/`

`bcii_pch_philosophy_urs.md` — a URS on Bareinboim, Correa, Ibeling & Icard R-60
(*On Pearl's Hierarchy*), built from a full read of §1.1–§1.5. Types the CHT as an
**Inv-class** result and reads the PCH as a stratification of askability. §7 marks two
Pl-kills to respect when inheriting (do not import their mechanistic realism; do not
treat the fixed 3-layer PCH as an open R) and lists programme actions, the first of
which is a direct edit to the ground-truth DAG.

---

## `reviews/`

`REVIEW_ProbabilityOfCausation.md` — the 2026-07-29 ultraconservative fidelity pass
that produced the seven axiom-clean Ch. 9 discharges. Corrected three real defects,
including a sharpness claim that had been formalized as endpoint-attainment when Pearl
claims any-value attainment.

## `scripts/` — 19 Python files, one directory by necessity

Kept together because the S-1…S-4 experiment scripts do a same-directory
`import tsem`; splitting them by stream would break it.

| Serving | Files |
|---|---|
| siSCM construct | `tsem.py` (Gladyshev Def 1/2/3/11), `mechanised_cbn_newcomb.py` (MacDermott Def 3 + Fig 4), `witness_self_rewrite_dowhy.py` (the §5 DoWhy witness) |
| monotone-J S-1…S-4 | `s1_self_model.py`, `s2_agent_gates.py`, `s3_agent_types.py`, `s4_capacity_boundary.py`, `sealed_J_oracle.py` (the `bp_width` LP), `probe_d3_anticipation.py`, `exp_monotone_justification.py` |
| forward-witness verification | `verify_mstar.py`, `verify_mstar_prime.py` |
| standalone checks | `verify_tameness.py` (the TLT transfer), `verify_pns_honest.py`, `verify_class_invariance.py`, `verify_crossover.py`, `verify_iterability_audit.py`, `verify_justification_loop.py`, `verify_justification_10seed.py` |

## `papers/` — 5 vendored PDFs

Gladyshev 2026 (temporal SEM as computation) · MacDermott 2023 (mechanised causal
graphs) · Everitt 2016 (self-modification) · Bongers 2021 (cyclic SCMs) · Mooij 2013
(ODE→SCM). These are the C1/C2 load-bearers, not background reading.

---

## Live couplings and inconsistencies found while reading

Recorded because they are actionable and none of them is visible from filenames.

1. **The Ch. 9 discharge is load-bearing for siSCM C3.** The argument chain cites
   `T9_2_10 / T9_2_11 / T9_2_14` by name as the witnesses for "`J = −width` is a
   genuine identifiability measure that CAN fall". Those are exactly the theorems
   committed axiom-clean in `041f2c8`.

2. **`SiSCM/Incentive.lean` carries a now-stale justification.** Lines 12–13 and 51–52
   say the Balke–Pearl LP is abstracted away *because* "the `Causality` identification
   theorems carry `sorry`". Three of them no longer do. Worth revisiting whether the
   abstraction is still the right call.

3. **Two documents disagree about the CHT.** `pearl-foundations/bcii_pch_philosophy_urs.md`
   §7 says *add a CHT node to the audited DAG*. `siscm/siscm_rsi_paper_argument_chain.md`
   says **"CHT is NOT a node — do not cite it."** Unresolved; the DAG currently has no
   CHT node.

4. **A stale sorry count.** The argument chain reports `Causality` at "77/211 sorries".
   Current measurement is 7 discharged of 74 theorems in `Proofs/`, on a different
   counting basis. Treat that figure as historical.

5. **F4 spans two programmes.** It is stated in `constructive/` as the reflexive
   soundness principle and lands in `do-rules/` Pass 7 as the calculus's *precondition*
   — and its shape is explicitly identified with siSCM's C5 sealed-audit assumption.
   The three programmes meet there.

## Corrections to the first version of this README

- `tameness_transfer_TLT.md` was filed under `notes/`. It is a siSCM result about the
  rewrite tree; moved to `siscm/`.
- `bcii_pch_philosophy_urs.md` was filed under `notes/`. It is a full URS with a DAG
  action item; moved to `pearl-foundations/`. `notes/` no longer exists.
- `phyre_competence_protocol.md` sits in `monotone-j/` but is the **γ-axis successor**
  to that arc, not part of it — different question, different benchmark, not yet run.
  Left in place; labelled above.
- `GROUNDING_self_state_self_rewrite.md` sits in `monotone-j/` because that arc's
  ledger names it as a canonical pointer, but it grounds siSCM C1–C2 generally.

## Reading depth

Read in full: both `constructive/` files, all seven `do-rules/` passes,
`monotone_J_PROTOCOL.md`, `siscm_rsi_paper_argument_chain.md`,
`bcii_pch_philosophy_urs.md`, `tameness_transfer_TLT.md`, and the first 45 lines of
`GROUNDING_self_state_self_rewrite.md` and `phyre_competence_protocol.md`. The
remaining `siscm/` files (forward witness, per-obstruction appendix, VERIFICATION,
E1–E7 battery and comparison, C7 composition proof, lemma-E fix plan) and the three
remaining `monotone-j/` files were read at opening-section depth — enough to
characterize object, method, and status, not enough to audit their claims. The
117 KB per-obstruction appendix in particular has been characterized, not verified.
