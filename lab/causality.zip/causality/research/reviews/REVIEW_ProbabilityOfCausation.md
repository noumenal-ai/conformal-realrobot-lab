# Fidelity Review — Probability of Causation (Pearl Ch. 9 cluster)

Reviewer pass 2026-07-29, against `causality/pearl_inheritance_dag_current_literature_audited.json`
(fields: `statement_excerpt_best_effort`, `goal_statement_compact`,
`current_literature_audit.{corrected_or_extended_statement, correct_argument}`).
Files under review: `Causality/Conjectures/ProbabilityOfCausation.lean`,
`Causality/Proofs/ProbabilityOfCausation.lean`. Posture: ultraconservative —
source outranks convenience; every deviation documented.

**Excerpt-garbling caveat.** The JSON statement excerpts are PDF extractions that
lost primes/overbars/inequality glyphs (e.g. 9.30's denominator prints as
`P(x, y)` where the book has `P(x', y')`). Where a glyph was lost, the
reconstruction was anchored on (i) the equation-number structure of the excerpt,
(ii) the excerpt's own internal algebra (e.g. the (9.31) expansion pins (9.29)'s
form), and (iii) machine-checked algebra on the substrate — each reconstructed
identity is now a discharged Lean theorem, so a wrong reconstruction would have
failed the proof, not just the eye.

## 1. Per-node verdict table

| Node | Source statement (compressed) | Lean formalization | Verdict |
|---|---|---|---|
| `T9_2_10` | Under exogeneity `max[0, P(y\|x) − P(y\|x')] ≤ PNS ≤ min[P(y\|x), P(y'\|x')]` (9.9); both bounds sharp: for every joint `P(x,y)` a model `y = f(x,u)`, `u ⫫ x`, realizes **any** value of PNS permitted by the bounds | Validity conjunct unchanged (`max 0 (pY1−pY0) ≤ pns ≤ min pY1 (1−pY0)`, the correct exogenous specialization with `P(y\|x)=pY1`, `P(y\|x')=pY0`, `P(y'\|x')=1−pY0`). Sharpness conjunct **strengthened**: ∀ marginal pair `(a,b) ∈ [0,1]²`, ∀ `p` in the Fréchet interval, ∃ `ResponseDist` with those marginals and `pns = p` (Conjectures:277) | **CORRECTED** (sharpness was endpoint-attainment only — strictly weaker than the source's any-value claim; replaced by the any-value form, which implies the old one). The `P(x,y)`-quantification reduces to `(a,b)`: under exogeneity PNS depends on `P(x,y)` only through the conditionals, `P(x)` free — documented in docstring |
| `T9_2_11` | Under exogeneity `PN = PNS/P(y\|x)` (9.11), `PS = PNS/P(y'\|x')` (9.12); hence PNS bounds yield PN bounds (9.13) | **Added** (was listed in the module table but had no Prop): on the layer-2 joint, `Exogenous j → pn = pns/pY1 ∧ ps = pns/(1−pY0)` with definedness guards `0 < pxy`, `0 < pxy'` (Conjectures:293). Proved (Proofs:78) | **EXTENDED** (missing node formalized). Note: on the layer-1 substrate the ratio identities are definitional (exogeneity baked in), so the honest home of 9.11/9.12's content is the layer-2 reduction theorem, which is what was formalized. The 9.13 bounds' sharpness content is carried by `C9_2_12` |
| `C9_2_12` | For **PN**: for any point `p` in the range `max[0,P(y_x)−P(y_{x'})]/P(y_x) ≤ p ≤ min[P(y_x),P(y'_{x'})]/P(y_x)` (9.14) there exists a causal model agreeing with `P(y_x), P(y_{x'})` with `PN = p` | Restated to the source's form: ∀ `(a,b)`, `0 < a`, ∀ `p` in the PN interval, ∃ `ResponseDist` with those experimental marginals and `pn = p` (Conjectures:341). Old Prop (PNS two-witness nonuniqueness) retained **verbatim** as aux `C9_2_12_pns_witness` (Conjectures:351), explicitly marked not-a-DAG-node. Both proved (Proofs:155, 165) | **CORRECTED** (adjudication of known question (a)): the source's corollary is about PN and is an any-point statement, not a two-witness PNS statement. The PN form is now the node; PN-nonuniqueness follows at e.g. `a=b=1/2` where the interval is `[0,1]`. Guard `0 < a` = definedness of PN's denominator `P(y_x)` |
| `T9_2_14` | Under exogeneity + monotonicity PN, PS, PNS **all** identifiable: `PNS = P(y\|x) − P(y\|x')` (9.21), `PN = (P(y\|x)−P(y\|x'))/P(y\|x)` (9.22, excess risk ratio), `PS = (P(y\|x)−P(y\|x'))/(1−P(y\|x'))` (9.23) | Extended from PNS-only to all three conjuncts: `pns = pY1−pY0 ∧ (0 < pY1 → pn = (pY1−pY0)/pY1) ∧ (pY0 < 1 → ps = (pY1−pY0)/(1−pY0))` (Conjectures:305). Proved (Proofs:112) | **CORRECTED/EXTENDED** (adjudication of known question (d)): the PN/PS identification conjuncts the source demands were missing. Guards are Pearl's implicit definedness conditions made explicit (ultraconservative: guard rather than lean on Lean's `x/0 = 0`) |
| `T9_2_15` | Under monotonicity (no exogeneity), PNS, PN, PS identifiable whenever `P(y_x)`, `P(y_{x'})` are: `PNS = P(y_x) − P(y_{x'})` (9.28), `PN = (P(y) − P(y_{x'}))/P(x,y)` (9.29), `PS = (P(y_x) − P(y))/P(x',y')` (9.30) | Refined from stub on the layer-2 joint (arbitrary X-dependence, matching the source's no-exogeneity setting): the three identities with `P(y_x) = toResponse.pY1`, `P(y_{x'}) = toResponse.pY0`, observational `py`, `pxy`, `pxy'`; guards on the two conditionals (Conjectures:322). Proved (Proofs:124) | **EXTENDED** (stub → refined + proved) with one **DEVIATION-DOCUMENTED** component: Pearl's antecedent "whenever the causal effects are identifiable" is a meta-level clause about estimating `P(y_x)` from data; on the substrate those are the potential-outcome marginals, so the formalized content is the identity layer that makes the claim true. Documented in the docstring |
| `C9_2_16` | Positive Markovian model + monotonic `Y_x` ⇒ PN/PS/PNS given by (9.28)–(9.30) with `P(y_x)` from parent adjustment (9.35) | Not formalized; marked "not yet stated (needs Markovian parent-adjustment layer)" in the coverage table | **OUT OF SCOPE — DOCUMENTED** (see §4) |
| `L9_2_6` | `PNS = P(x,y)·PN + P(x',y')·PS` (9.5); **assumption-free** in the source (consistency only) | Refined from stub: stated on the layer-2 joint with arbitrary `X`–`(Y₀,Y₁)` dependence — no exogeneity — guarded only by `0 < pxy`, `0 < pxy'` (definedness of the two conditionals, which Pearl leaves implicit) (Conjectures:261). Proved (Proofs:40) | **CORRECTED/EXTENDED** (adjudication of known question (e)): the lemma genuinely needs `P(x,y)`-level objects, so the substrate was extended with the treatment-augmented joint `XResponseDist` rather than leaving the node stubbed or restricting to the exogenous product case. The pure layer-1 substrate is untouched |
| `L9_2_7` | PN invariant under a randomized downstream inhibitor (`z = y ∧ q`, `q ⫫ {X,Y,Y_x}`) | Not formalized; marked in coverage table | **OUT OF SCOPE — DOCUMENTED** (see §4) |
| `L9_2_8` | PS invariant under independent alternative downstream causes (`z = y ∨ r`) | Not formalized; marked in coverage table | **OUT OF SCOPE — DOCUMENTED** (see §4) |
| `D9_2_1` (PN) | `PN = P(y'_{x'} \| x, y)` (JSON excerpt empty; audit: retain as Pearl-2009 base-case definition prerequisite) | Layer 2: genuine conditional `pn = P(X=1,Y₀=0,Y₁=1)/P(x,y)` — conditioning event `{X=1, Y₁=1}` by consistency, target `{Y₀=0}` (Conjectures:230). Layer 1: exogenous reduced form `pns/pY1` (Conjectures:136), with docstring deriving it from the conditional via `T9_2_11` | **EXTENDED** (was not formalized at all). Division convention handled: docstrings state `x/0 = 0`; every Prop guards the denominator |
| `D9_2_2` (PS) | `PS = P(y_x \| x', y')` | Layer 2: `ps = P(X=0,Y₀=0,Y₁=1)/P(x',y')` (Conjectures:236). Layer 1: reduced `pns/(1−pY0)` (Conjectures:143) | **EXTENDED** (same treatment as D9_2_1) |
| `D9_2_3` (PNS) | `PNS = P(y_x, y'_{x'})` | `pns = P(Y₁=1, Y₀=0)` — the "helped" cell (layer 1, Conjectures:128); joint-layer twin (Conjectures:213) | **FAITHFUL** (pre-existing; joint-layer twin added so layer-2 Props can state it) |
| `D9_2_9` (Exogeneity) | Pearl (9.10): `P(y_x, y_{x'} \| x) = P(y_x, y_{x'})`, i.e. `(Y₀,Y₁) ⫫ X` | `Exogenous : Prop` on layer 2: product form — every cell factors as `P(X=x)·P(Y₀=y0,Y₁=y1)` (Conjectures:244). Docstring records equivalence with the conditional form whenever `P(x) > 0` and why product form is the convention-free rendering | **EXTENDED** (adjudication of known question (b)): the previous docstring-only "baked into the substrate" treatment was honest for layer-1 statements but insufficient once L9_2_6/T9_2_11 exist; exogeneity is now a formal hypothesis on layer 2, and `T9_2_11` + `toResponse` are the proved bridge that grounds layer 1's baking-in |
| `D9_2_13` (Monotonicity) | Functional: `y_{x'}(u) ≤ y_x(u)` for all `u` (with Pearl's footnote symmetrizing under complementation) | `MonotoneResponse`: zero mass on the harmed type `P(Y₀=1, Y₁=0) = 0` (layer 1 Conjectures:149; layer 2 twin Conjectures:249) | **FAITHFUL / DEVIATION-DOCUMENTED**: the for-all-`u` functional form is rendered distributionally (almost-sure, zero harmed mass) — the version the §9.2 identification results actually consume; nuance now stated in the docstring. On a distribution-only substrate this is the maximal faithful rendering |
| `T9_4_2` | Markovian model with known functions, locally invertible ⇒ every counterfactual identifiable from `P(y)` | Deliberate stub `∀ _M : SCM, True` (Conjectures:329); sorried discharge retained (Proofs:153) | **STUB RETAINED — DOCUMENTED** (see §4) |
| `EXT_IV_PARTIAL_IDENTIFICATION` | Balke–Pearl IV bounds canonical; modern covariate/imperfect-instrument extensions; LP response-type proof survives | Not in this cluster file; recorded next refinement at `Conjectures.Modern.PartialIdentification` (header docstring) | **OUT OF SCOPE — DOCUMENTED** (see §4) |

Adjudication of known question (c) in full: the Lean bounds `max 0 (pY1−pY0) ≤ pns ≤ min pY1 (1−pY0)`
are exactly the exogenous (9.9) forms — the T9_2_10 excerpt contains only the two-term forms; the
four-term `P(x,y)`-bearing bounds are the combined experimental+observational (Tian–Pearl, §9.2.4)
results, which are a *different* node family not in this cluster's scope. "Sharp" as previously
formalized (endpoint attainment) did NOT match the source's meaning ("realizes any value of PNS
permitted by the bounds") — corrected as above; endpoint attainment is now a corollary of the
stated form.

## 2. Edits made

`causality/Causality/Conjectures/ProbabilityOfCausation.lean` (355 lines; rewritten in place):

- :8–105 — module docstring: two-layer substrate description, division-convention policy,
  fidelity-review record, coverage table extended with a `Lean` status column (the old table
  claimed 19 nodes "covered" while only 6 had Props — an overclaim, now annotated per node).
- :130–143 — layer-1 `pn`, `ps` added (exogenous reduced forms, `noncomputable`, docstrings
  derive them from D9_2_1/D9_2_2 via T9_2_11 and state the `x/0 = 0` convention).
- :145–148 — D9_2_13 docstring: functional-vs-almost-sure rendering documented.
- :179–250 — layer-2 substrate `XResponseDist` added: structure (:179), `pxMarg` (:192),
  `rMarg` (:196), `toResponse` exact marginalization (:202), `pns` (:213), `py` (:217),
  `pxy` (:221), `pxy'` (:224), `pn` (:230), `ps` (:236), `Exogenous` = D9_2_9 (:244),
  `MonotoneResponse` (:249).
- :261 — `L9_2_6` refined from `∀ _M : SCM, True` stub to the guarded (9.5) identity on layer 2.
- :277 — `T9_2_10` sharpness conjunct strengthened to any-value attainment (validity conjunct
  byte-identical to the pre-review form).
- :293 — `T9_2_11` added.
- :305 — `T9_2_14` extended with the (9.22)/(9.23) conjuncts, guarded.
- :322 — `T9_2_15` refined from stub to the guarded (9.28)–(9.30) identities on layer 2.
- :329 — `T9_4_2` stub unchanged.
- :341 — `C9_2_12` restated as the PN any-point statement (9.14); :351 — old PNS statement
  preserved verbatim as `C9_2_12_pns_witness` (aux, non-node).

`causality/Causality/Proofs/ProbabilityOfCausation.lean` (183 lines; rewritten in place):

- :29–37 — three `private` rfl projection helpers for `toResponse`.
- :40 `L9_2_6_proved` (new proof, was sorry), :47 `T9_2_10_proved` (validity proof unchanged;
  sharpness re-proved via the single Fréchet construction `mk4 (1−b−p) p (b−a+p) (a−p)`),
  :78 `T9_2_11_proved` (new), :112 `T9_2_14_proved` (extended), :124 `T9_2_15_proved`
  (new proof, was sorry), :153 `T9_4_2_proved` (deliberate sorry retained),
  :155 `C9_2_12_proved` (re-proved for the PN form via T9_2_10-sharpness at `pns = p·a`),
  :165 `C9_2_12_pns_witness_proved` (pre-review proof body, verbatim).
- :175–181 — `#print axioms` for all seven discharged theorems.

Protocol compliance notes: the three previously-proved Props (`T9_2_10`, `C9_2_12`, `T9_2_14`)
were edited post-proof under this review's write authority; each replacement is a strict
strengthening (new statement implies old; old `C9_2_12` additionally preserved verbatim under
the aux name) and every strengthened statement was re-proved in the same session — nothing
proved was weakened or deleted. Stubs `T9_2_15`/`L9_2_6` were refined-and-proved (sanctioned);
`T9_4_2` retained. No other cluster file touched (grep confirms these two files are the only
ones referencing the cluster's names). `noncomputable` markers on the four `pn`/`ps` defs are
compilation metadata (ℝ division), not statement content.

## 3. Build + axiom-audit transcript

```
$ lake build Causality
✔ [2537/2540] Built Causality.Conjectures.ProbabilityOfCausation (2.5s)
✔ [2538/2540] Built Causality.Conjectures.Modern.CounterfactualID (2.0s)
✔ [2539/2540] Built Causality (2.0s)
Build completed successfully (2540 jobs).        # zero warnings (warningAsError := true)

$ lake env lean causality/Causality/Proofs/ProbabilityOfCausation.lean
causality/Causality/Proofs/ProbabilityOfCausation.lean:153:8: warning: declaration uses `sorry`
                                                  # = T9_4_2_proved, the deliberate stub
'Causality.Pearl.L9_2_6_proved' depends on axioms: [propext, Classical.choice, Quot.sound]
'Causality.Pearl.T9_2_10_proved' depends on axioms: [propext, Classical.choice, Quot.sound]
'Causality.Pearl.T9_2_11_proved' depends on axioms: [propext, Classical.choice, Quot.sound]
'Causality.Pearl.T9_2_14_proved' depends on axioms: [propext, Classical.choice, Quot.sound]
'Causality.Pearl.T9_2_15_proved' depends on axioms: [propext, Classical.choice, Quot.sound]
'Causality.Pearl.C9_2_12_proved' depends on axioms: [propext, Classical.choice, Quot.sound]
'Causality.Pearl.C9_2_12_pns_witness_proved' depends on axioms: [propext, Classical.choice, Quot.sound]
```

No `sorryAx` in any discharged theorem.

## 4. Judged unfixable here / out of scope, with reasons

- **`T9_4_2` (local invertibility).** Requires the `SCM` primitive's counterfactual semantics
  (known structural functions, unobserved `U`, invertibility of the `u ↦ v` map) — an entirely
  different substrate from finite response-type tables. Refining it on the current substrate
  would either trivialize it or misstate it. Stub retained per protocol.
- **`C9_2_16` / `C9_2_17` (Markovian / semi-Markovian monotonic identification).** Consume
  parent-adjustment (9.35) resp. back-door/front-door identification of `P(y_x)` — graph-level
  machinery living in the Identification cluster. Formalizing them here without that layer would
  duplicate or fake the adjustment content. Marked "not yet stated" in the coverage table
  (fixing the table's prior silent overclaim).
- **`L9_2_7` / `L9_2_8` (cascade invariance).** Quantify over an added downstream variable
  (`z = y ∧ q`, `z = y ∨ r`) with independence side conditions — need a substrate with a third
  endogenous layer. An `XResponseDist`-style extension is mechanical but is new-node work, not
  fidelity repair of the reviewed discharge; left unstated and documented.
- **`EXT_IV_PARTIAL_IDENTIFICATION` (Balke–Pearl LP layer).** The JSON classifies it as a
  modern extension node; it needs an instrument-augmented substrate (compliance types /
  16-cell joint) and the LP feasible-set argument. Already recorded as the next refinement at
  `Conjectures.Modern.PartialIdentification`; importing it into this Ch. 9 cluster file would
  violate the module⇄cluster correspondence.
- **Residual flag (minor, no action).** Layer-1 `T9_2_10`/`C9_2_12` quantify over marginal
  pairs `(a,b)` rather than over full joints `P(x,y)`; the reduction (PNS/PN depend on
  `P(x,y)` only through the conditionals under exogeneity, `P(x)` free) is stated in the
  docstrings. A skeptic wanting the quantification literally over layer-2 exogenous joints can
  route through `toResponse` + `T9_2_11`; the pieces are all present and proved.
