# Discovery URS — Causality Formalization Project

**Substrate**: Lean 4, Mathlib, design-lab seven-sub-library aggregation.
**Audit unit**: 141 nodes / 155 edges of `pearl_inheritance_dag_current_literature_audited.json` (v2).
**Created**: 2026-05-21.
**URS framework**: noological-urs (AMRT spine + KK/KU/UK/UU + Pl/Coh/Comp/Inv + HC at paradigm joints).
**Posture**: Problem-URS for the causality formalization, NOT a noological URS about Claude's self-model.

---

## A — Axioms / Identity

### A₁ — Project identity

- **Target**: Formalize EXACTLY the Pearl-2009 + post-2009 modern-extension DAG (141 nodes after `EXT_HIERARCHICAL_ABSTRACTION` addition on 2026-05-21).
- **Substrate-level commitment**: ONE custom primitive for causality. Everything else (interventions, counterfactuals, identifiability, d-separation, twin networks, transportability, hierarchical abstraction, etc.) is a derived definition or theorem over Mathlib + the one primitive. (Locked Mathlib-only 2026-05-30 — see `research/urs/PROGRESS.md`.)
- **Layered counterfactual axioms**: Galles-Pearl 1995 axioms (composition, effectiveness, reversibility/recursiveness) as primary (Layer A); Halpern 2000/2008 axioms as derived; Halpern-Pearl 2005 AC1/AC2/AC3 actual-causation conditions as additive Layer B in `Modern/ActualCausationPostHP.lean`. **Axiom-equivalence work (Layer A ↔ Layer A') is explicitly committed to as non-trivial formalization, not avoided.**
- **Linear SEM level**: polynomial-covariance / instrumental-cutset (Kumor–Chen–Bareinboim 2019), not just regression-based path coefficients.
- **Modern extensions split**: 22 files (11 modern extensions × {primary theorem file, reduction-to-Pearl file}).
- **Frontload records** (locked 2026-05-30): 7 records — `SCM` (the primitive) + `ObservedSchema` + `DiscoveryAssumptions` + `CausalEquivClass` + `CausalData` + `FiniteSampleGuarantee` + `CausalFrame` — plus the `DiscoveryProblem` bundle. Refactored from the 5-typeclass proposal (`HasObservedSet`/`Faithful`/`MEC`/`Data`/`FiniteSampleClaim`) per 2026-05-30 reviewer feedback. Each is a `structure` (or `inductive`) record, not a `class`: instances are NOT canonical. See `Architecture.lean` §5–§13 for the implementation and the per-record rationale.

### A₂ — Hard constraints

- **Inheritance constraint** (locked Mathlib-only 2026-05-30): only Mathlib higher-order types may be used. No imports from the other six design-lab sub-libraries. NO new custom typeclasses for causality beyond the one primitive. All quantitative instruments (CI dependence scores, concentration bounds, etc.) are abstract parameters at v1; concrete derivations land in-repo if needed.
- **Goal-tracking constraint**: every named DAG node gets a Lean signature as an `argument in lean` (theorem/def/structure declaration), all 141 type-check, sorry-target = 141 at start. Sorry count decreases monotonically as proofs land.
- **Honesty constraint (URS A₄)**: a definition-unfolding is not a theorem; declarations that are A4-trivial (per the DAG's existing A4 honesty flags) carry the flag in their Lean docstring.

### A₃ — Will (inherited axiom set)

- **From design-lab v0.5**: indexer + skill convention (`Causality.*` namespace, `causality/` sub-library).
- **From conversation 2026-05-19/20**: ground-truth DAG ingested, sandbox SCM relocated from `measurements/` to `causality/Causality/Basic.lean`, indexer regenerated to 13816 declarations across 7 libraries.
- **From conversation 2026-05-21 (this session)**: `EXT_HIERARCHICAL_ABSTRACTION` added as 11th modern extension; categorical/sheaf-theoretic framing withdrawn as load-bearing (per user pushback: "category theory is the right language to prove equivalence up to abstraction but irrelevant to learning that structure").

---

## M — Available Mechanisms

| ID | Mechanism | Use in this project |
|----|-----------|---------------------|
| M₁ | Formal deduction (Lean 4) | Every DAG node closure |
| M₂ | Conjecture generation | Mainly for missing edges in the DAG (we don't expect to need this since the DAG is closed) |
| M₃ | Counterexample / Pl-kill | Verification of Pl-kill alerts already in the DAG (e.g., `G2_8_2` Temporal Bias conjecture) |
| M₄ | Structural mapping | The 10 reduction-to-Pearl theorems in `Modern/*` |
| M₅ | Dimension analysis | Used at the primitive-design stage to confirm the 10-field `CausalModel` is the minimum-field shape covering all DAG nodes |
| M₆ | Literature Pl-check | The DAG's `current_literature_basis` block (now 23 references) IS this check, performed offline |
| M₇ | Paper drafting | Build sheets, integration docs, this URS |
| `task-urs-typing-derivation` | Per-node Lean signature derivation | 141 nodes, batched root-to-leaves from the main chain |
| `design-lab` skill | Indexer queries (5 query patterns) | Locating inherited Mathlib/ZPM/etc primitives |

---

## R — Representations / Grammar

### R₁ — The one custom primitive

```lean
structure CausalModel where
  V        : Type
  [V_fin   : Fintype V]
  [V_dec   : DecidableEq V]
  Sp       : V → Type
  [Sp_meas : ∀ i, MeasurableSpace (Sp i)]
  Pa       : V → Finset V
  U        : V → Type
  [U_meas  : ∀ i, MeasurableSpace (U i)]
  uDist    : MeasureTheory.ProbabilityMeasure (∀ i : V, U i)
  f        : ∀ i, (∀ j ∈ Pa i, Sp j) × U i → Sp i
  hf       : ∀ i, Measurable (Function.uncurry (f i))
```

Ten fields. The single Lean-level `structure` declaration is the entire causality-specific custom primitive. **Everything else derives from this plus Mathlib/ZPM higher-order types.**

### R₂ — Frontload grammar (NOT new custom primitives — typeclasses/structures over the primitive)

Five typeclasses/structures that should land BEFORE the URS pass over the 141 nodes, so theorem statements are in their final shape from the start (otherwise retrofit cost grows superlinearly):

```lean
-- Pain point 1: observed ≠ posited
class HasObservedSet (M : CausalModel) where
  observed : Finset M.V
  latent_disjoint : Disjoint observed (latent M)

-- Pain point 2: faithfulness with quantitative margin
class Faithful (P : ProbabilityMeasure _) (G : DAG) (margin : ℝ≥0)

-- Pain point 3: equivalence-class outputs
structure MEC (V : Type) where
  reps : Set DAG
  markov_equivalent : ∀ G G' ∈ reps, ObservationallyEquivalent G G'

-- Pain point 4: multi-source data
inductive Data (V : Type) where
  | observational  : ProbabilityMeasure (∀ i : V, Sp i) → Data V
  | interventional : (X : Finset V) → (x : ∀ i ∈ X, Sp i) →
                     ProbabilityMeasure (∀ i : V, Sp i) → Data V
  | fromPopulation : Population → Data V → Data V
  | mixture        : List (Data V) → Data V

-- Pain point 5: sample-size index
class FiniteSampleClaim (n : ℕ∞) (claim : Prop)
```

These are not new primitives in the conceptual sense — they are *typed annotations on the primitive* that make the standard assumptions of causal-inference literature first-class instead of implicit.

### R₃ — Derived grammar (every other DAG concept)

| Pearl concept | Derived form |
|---|---|
| `DAG` | `def diagram (M : CausalModel) : Quiver M.V := ⟨..., M.Pa⟩` |
| Markov condition | `def IsMarkov (M : CausalModel) : Prop := ∃ μ, uDist = Measure.pi μ` |
| d-separation | `def dSep (G : DAG) (X Y Z : Finset V) : Prop := ...` |
| do-intervention | `def doIntervene (M : CausalModel) (X : Finset M.V) (x) : CausalModel := ...` (graph surgery) |
| Interventional dist `P_x(v)` | `def Px := (doIntervene M X x).joint` |
| Counterfactual `Y_x = y` | three-step procedure on twin-network |
| Identifiability | `def Identifiable (Q : Query) (M : CausalModel) (S : Finset M.V) : Prop` |
| Back-door / Front-door | predicates on `diagram M` + variable sets |
| ID algorithm | `def ID (G : MEC) (Q : Query) : Option Expression` |
| Selection diagram | `Σ M : CausalModel, Finset M.V` (selection set as data) |
| ADMG / MAG / PAG | derived equivalence classes / latent projections |
| Hierarchical model | `Σ levels : ℕ → CausalModel, tau : ∀ n, ConsistentAbstraction (levels n) (levels (n+1))` |

---

## T — Traces

### T₁ — Established (KK)

- **141 DAG nodes** with statement excerpts, witness grades, current-literature audit, and modern-extension classifications. File: `causality/pearl_inheritance_dag_current_literature_audited.json`.
- **155 inheritance edges** with edge-type annotations (`anchor_chain` / `support_branch` / `definition_prerequisite` / `current_literature_extension`).
- **23 supporting literature references** spanning Pearl 2009 + 22 modern papers.
- **14 Lean declarations** in the sandbox `causality/Causality/Basic.lean` (sandbox `(U, A, S)` SCM with `doIntervene`, `interventionalDist`, `causalKernel`, `counterfactualDist`, `Identifiable`, `BackdoorIdentified`, `identifiable_of_backdoor`; 2 sorry).
- **Design lab indexer**: 13816 declarations across 7 libraries; causality currently at 14, will grow as URS pass lands theorem skeletons.

### T₂ — Programme commitments (γ-ledger)

| Commitment | Status |
|---|---|
| One custom primitive constraint | locked |
| Galles-Pearl Layer A axioms primary | locked |
| Halpern Layer A axioms derived + equivalence proved as non-trivial bridge | locked |
| HP 2005 AC1/AC2/AC3 actual-causation additive in `Modern/` | locked |
| Linear SEM at polynomial-covariance level | locked |
| Modern extensions in split files (22 files) | locked |
| URS pass over all 141 nodes batched root-to-leaves | committed |
| Frontload 5 typeclasses (HasObservedSet, Faithful, MEC, Data, FiniteSampleClaim) | superseded 2026-05-30 → 7 records (see `Architecture.lean`) |
| Frontload 7 records (SCM + ObservedSchema + DiscoveryAssumptions + CausalEquivClass + CausalData + FiniteSampleGuarantee + CausalFrame) + DiscoveryProblem bundle | locked 2026-05-30 |
| `EXT_HIERARCHICAL_ABSTRACTION` as 11th modern extension | committed |

---

## P — Pain Points (Universal in Causal Inference)

This section is the substantive content of the URS. Each pain point is named, justified by literature evidence, mapped to a frontload typeclass, and given an HC contribution if not frontloaded.

### P₁ — The observation set is not the variable set

**Pain**: Pearl writes `P(V)` as if `V` is the set of observed variables. In real causal inference there are three distinct sets:
- `V_world`: the variables the model posits exist
- `V_observed`: the variables you measured (proper subset)
- `V_latent` = `V_world \ V_observed`: posited but unmeasured

Identification arguments that silently equate `V_world = V_observed` are wrong for almost all modern applications.

**Universality evidence**:

- Spirtes, Glymour, Scheines (2000), *Causation, Prediction, and Search* (MIT Press, 2nd ed.) — the FCI algorithm is built around the latent-variable case; the textbook's central chapters distinguish causal sufficiency (no hidden confounders) from the general case.
- Richardson & Robins (2013), "Single-World Intervention Graphs (SWIGs): A Unification of the Counterfactual and Graphical Approaches to Causality." [arXiv:1305.4319 (companion working paper)]. The entire SWIG construction is about making latent counterfactual variables explicit in the graph.
- Robins, Hernán & Brumback (2000), "Marginal structural models and causal inference in epidemiology," *Epidemiology* 11(5):550-560. Foundational paper for epidemiology; marginal structural models are necessary precisely because observational data has latent time-varying confounding.
- Hernán & Robins (2020), *Causal Inference: What If* (Chapman & Hall). Modern textbook; the entire Part II is about exchangeability conditions and what fails when observed ≠ posited.
- Pearl & Mackenzie (2018), *The Book of Why* (Basic Books), Ch. 7. The "front-door" criterion is justified primarily as a workaround for unobserved confounders.

**Frontload mapping**: `class HasObservedSet (M : CausalModel)`.

**HC if not frontloaded**: ~1.0 across the entire identification/discovery sub-DAG (T3_2_2, T3_3_2, T3_3_4, T3_4_1, T3_6_1, T4_3_1, T4_4_1, T4_4_6, T4_5_3, EXT_ID_DO_CALCULUS_COMPLETE, EXT_COMPLETE_ADJUSTMENT, EXT_TRANSPORTABILITY_DATA_FUSION, EXT_COUNTERFACTUAL_IDENTIFICATION). Retrofit means adding an `observed : Finset M.V` parameter to every identification theorem.

### P₂ — Faithfulness needs a quantitative margin

**Pain**: Causal discovery (PC, FCI, GES, IDA, etc.) requires the population distribution to be *faithful* to the graph: every conditional independence implied by the graph holds in the distribution AND only those. Faithfulness as a binary condition is asymptotically defensible but **finite-sample-empty** — strong-faithfulness violations have non-negligible Lebesgue measure in parameter space, so finite-sample tests cannot distinguish them from true independences.

**Universality evidence**:

- Robins, Scheines, Spirtes, Wasserman (2003), "Uniform consistency in causal inference," *Biometrika* 90(3):491-515. **The seminal paper.** Proves that no causal-discovery algorithm can have uniform consistency over faithful distributions without an additional margin assumption.
- Zhang & Spirtes (2008), "Detection of unfaithfulness and robust causal inference," *Minds and Machines* 18:239-271. Formal evidence that strong-faithfulness violations are non-trivial.
- **Uhler, Raskutti, Bühlmann & Yu (2013), "Geometry of the faithfulness assumption in causal inference," *Annals of Statistics* 41(2):436-463. [arXiv:1207.0547].** Measure-theoretic argument that the volume of strong-faithfulness violations is non-negligible even in low-dimensional settings.
- Kalisch & Bühlmann (2007), "Estimating high-dimensional directed acyclic graphs with the PC-algorithm," *JMLR* 8:613-636. Provides high-dimensional PC-algorithm consistency under strong-faithfulness margin assumptions.
- Already in DAG as `EXT_DISCOVERY_ROBUSTNESS`.

**Frontload mapping**: `class Faithful (P : ProbabilityMeasure _) (G : DAG) (margin : ℝ≥0)`.

**HC if not frontloaded**: ~0.8 across causal-discovery sub-DAG (T2_6_2 + EXT_DISCOVERY_ROBUSTNESS + downstream identification theorems that implicitly assume discovery has succeeded).

### P₃ — Discovery returns equivalence classes

**Pain**: Causal-discovery algorithms output:
- **CPDAGs** (completed partially directed acyclic graphs) for the no-latent-confounder case (PC algorithm)
- **PAGs** (partial ancestral graphs) for the latent-confounder case (FCI algorithm)
- **MAGs** (maximal ancestral graphs) as the canonical representative of an PAG equivalence class

Downstream theorems that take a "DAG" as input assume the orientation problem is solved. It's typically not. Identification must operate over the equivalence class.

**Universality evidence**:

- Verma & Pearl (1990), "Equivalence and synthesis of causal models," *UAI 1990*. The first formal statement of when two DAGs are observationally equivalent.
- Andersson, Madigan & Perlman (1997), "A characterization of Markov equivalence classes for acyclic digraphs," *Annals of Statistics* 25(2):505-541. **Defines CPDAGs and proves the characterization theorem.**
- Spirtes, Glymour, Scheines (2000), *Causation, Prediction, and Search*. The PC algorithm explicitly returns CPDAGs.
- Zhang (2008), "On the completeness of orientation rules for causal discovery in the presence of latent confounders and selection bias," *Artificial Intelligence* 172(16-17):1873-1896. **Completeness of PAG orientation rules.**
- Perkovic, Textor, Kalisch, Maathuis (2017), "Complete graphical characterization and construction of adjustment sets," *JMLR* 18(220):1-62. [arXiv:1606.06903]. **Generalized adjustment criterion stated over the equivalence class, not a specific DAG.** Already in DAG as `EXT_COMPLETE_ADJUSTMENT`.

**Frontload mapping**: `structure MEC (V : Type)`.

**HC if not frontloaded**: ~1.2 across the entire post-2009 discovery + identification sub-DAG. Many modern theorems are stated against MECs natively; retrofitting to DAG-only and then quantifying outer ∀ over MEC members is awkward and breaks proof structure.

### P₄ — Data fusion is the default, not the exception

**Pain**: Real causal questions are answered from *combinations* of data sources — observational + experimental + multi-population. Pearl's `P(V)` notation hides the source. Bareinboim's data-fusion framework makes the sources explicit.

**Universality evidence**:

- **Bareinboim & Pearl (2016), "Causal inference and the data-fusion problem," *PNAS* 113(27):7345-7352.** Foundational. Algorithm for combining heterogeneous data sources.
- Pearl & Bareinboim (2014), "External validity: From do-calculus to transportability across populations," *Statistical Science* 29(4):579-595. [arXiv:1503.01603]. Already in DAG as `EXT_TRANSPORTABILITY_DATA_FUSION`.
- Bareinboim & Pearl (2012), "Transportability of causal effects: Completeness results," *AAAI 2012*. Completeness theorem for transport.
- Hernán & VanderWeele (2011), "Compound treatments and transportability of causal inference," *Epidemiology* 22(3):368-377. Epidemiological motivation.
- Lee & Bareinboim (2018), "Structural causal bandits: Where to intervene?" *NeurIPS 2018*. Multi-experimental data fusion for bandit/RL settings.
- Correa, Lee, Bareinboim (2022), "Nested counterfactual identification from arbitrary surrogate experiments," *NeurIPS 2021*. [arXiv:2107.03190]. Already in DAG as `EXT_COUNTERFACTUAL_IDENTIFICATION`.

**Frontload mapping**: `inductive Data (V : Type) where | observational | interventional | fromPopulation | mixture`.

**HC if not frontloaded**: ~0.9. Without `Data` as a first-class typed object, every transportability/fusion theorem requires ad-hoc product types over data-source tags, and the proof structure fragments across files.

### P₅ — Sample-size regime must be type-tracked

**Pain**: Pearl's classical theorems are infinite-sample (asymptotic identifiability). Almost all modern computational causal inference operates in finite-sample regimes with explicit guarantees. Without a type-level distinction, the formalization silently claims things hold in the finite regime when they don't.

**Universality evidence**:

- Robins et al. (2003), op. cit. Finite-sample failure of uniform consistency in causal discovery.
- **Maathuis, Kalisch, Bühlmann (2009), "Estimating high-dimensional intervention effects from observational data," *Annals of Statistics* 37(6A):3133-3164.** IDA algorithm with explicit finite-sample bounds; critical demonstration that infinite-sample identifiability ≠ finite-sample estimability.
- Heinze-Deml, Maathuis, Meinshausen (2018), "Causal structure learning," *Annual Review of Statistics* 5:371-391. Survey of finite-sample causal discovery.
- van der Vaart (2000), *Asymptotic Statistics* (Cambridge). General source for the asymptotic-vs-finite-sample distinction in estimation theory.
- Magliacane et al. (2018), "Domain adaptation by using causal inference to predict invariant conditional distributions," *NeurIPS 2018*. Finite-sample arguments for invariant prediction.

**Frontload mapping**: `class FiniteSampleClaim (n : ℕ∞) (claim : Prop)` with `n = ⊤` recovering Pearl's asymptotic statements.

**HC if not frontloaded**: ~0.6 — lower than P₁-P₄ because Pearl's text is genuinely asymptotic and the finite-sample work lives mainly in the modern-extension sub-DAG (EXT_DISCOVERY_ROBUSTNESS, EXT_IV_PARTIAL_IDENTIFICATION). But that HC is concentrated at the extension boundary.

### P₆ — Hierarchical/multi-level structure

**Pain**: Causality is frame-of-reference sensitive. The "right" causal model depends on which level of abstraction you're operating at. Beckers-Halpern give 2-level theory; n-level synthesis is open. JEPA-scale architectures require hierarchical predictive models, and predictive ≠ causal unless abstraction-consistency holds at each level.

**Universality evidence**:

- **Beckers & Halpern (2019), "Abstracting Causal Models," *AAAI 2019*. [arXiv:1812.03789].** The base technical framework. Constructive vs intrinsic abstraction; composition of abstractions.
- Rubenstein et al. (2017), "Causal consistency of structural equation models," *UAI 2017*. [arXiv:1707.00819]. First clean statement of model-level abstraction.
- Beckers, Eberhardt, Halpern (2020), "Approximate causal abstractions," *UAI 2020*. [arXiv:1906.11583]. Quantitative version.
- Chalupka, Eberhardt, Perona (2015), "Visual causal feature learning," *UAI 2015*. [arXiv:1412.2309]. Micro/macro causal-variable abstraction in vision.
- Geiger, Lu, Icard, Goodman (2021), "Causal abstractions of neural networks," *NeurIPS 2021*. [arXiv:2106.02997]. **Closest existing bridge to JEPA-style architectures.**
- Schölkopf et al. (2021), "Towards causal representation learning," *Proceedings of the IEEE* 109(5):612-634. [arXiv:2102.11107]. Position paper.
- LeCun (2022), "A Path Towards Autonomous Machine Intelligence." OpenReview position paper. H-JEPA architecture.

**Frontload mapping**: Already added to DAG as `EXT_HIERARCHICAL_ABSTRACTION` (this session). The corresponding Lean structure:

```lean
structure HierarchicalCausalModel where
  levels      : ℕ → CausalModel
  tau         : ∀ n, levels (n+1) → levels n        -- abstraction map upward
  consistent  : ∀ n, AbstractionConsistent (tau n)  -- Beckers-Halpern condition
```

**HC if not frontloaded**: ~0.7 at the modern-extension boundary; will grow over time as H-JEPA-aligned work accumulates.

---

## DL/ML Pain-Point Sweep

A separate sweep for mathematically relevant pain points specific to applying causality to deep learning and ML. Listed in order of how unsolved each is.

### Q₁ — Non-identifiability of latent representations

**Pain**: When latent variables are *learned* (disentanglement, ICA, VAE-style), the identifiability question is severe. Multiple distinct latent structures can fit the same observed data.

**Universality evidence**:

- **Locatello et al. (2019), "Challenging common assumptions in the unsupervised learning of disentangled representations," *ICML 2019*. [arXiv:1811.12359].** Impossibility result for unsupervised disentanglement without inductive biases. Best-paper at ICML; widely cited.
- Khemakhem, Kingma, Monti, Hyvärinen (2020), "Variational autoencoders and nonlinear ICA: a unifying framework," *AISTATS 2020*. [arXiv:1907.04809]. iVAE; identifiability under auxiliary variables.
- Hyvärinen, Sasaki, Turner (2019), "Nonlinear ICA using auxiliary variables and generalized contrastive learning," *AISTATS 2019*. [arXiv:1805.08651].

**Mapping into DAG**: Sub-extension of `EXT_GRAPHICAL_MIXED_GRAPHS` (latent variable handling) and potentially a new node `EXT_LATENT_IDENTIFIABILITY` if we want to formalize the negative results.

### Q₂ — Neural network as SCM mechanism

**Pain**: When `f_i` is a neural network, what's its causal interpretation? The functional shape is given, but the causal partition of inputs into "true parents" vs "spurious inputs" is not.

**Universality evidence**:

- Geiger, Wu, Lu, Rozner, Kreiss, Icard, Goodman, Potts (2022), "Inducing causal structure for interpretable neural networks," *ICML 2022*. [arXiv:2112.00826].
- Geiger, Wu, Potts, Icard, Goodman (2023), "Finding alignments between interpretable causal variables and distributed neural representations," *CLeaR 2024*. [arXiv:2303.02536]. Distributed alignment search.
- Vig et al. (2020), "Investigating gender bias in language models using causal mediation analysis," *NeurIPS 2020*. [arXiv:2004.12265]. Causal mediation on LMs.

**Mapping into DAG**: Closely related to `EXT_HIERARCHICAL_ABSTRACTION` (the NN-as-fine-model side of an abstraction); could merge or split.

### Q₃ — Off-policy / counterfactual evaluation

**Pain**: In RL, evaluating a policy π' from data collected under policy π is a counterfactual question (Y_{π'} | π). Importance sampling, doubly-robust estimation.

**Universality evidence**:

- Precup, Sutton, Singh (2000), "Eligibility traces for off-policy policy evaluation," *ICML 2000*. Foundational.
- **Dudík, Langford, Li (2011), "Doubly robust policy evaluation and learning," *ICML 2011*. [arXiv:1103.4601].** Doubly-robust estimator.
- Jiang & Li (2016), "Doubly robust off-policy value evaluation for reinforcement learning," *ICML 2016*. [arXiv:1511.03722].
- Thomas & Brunskill (2016), "Data-efficient off-policy policy evaluation for reinforcement learning," *ICML 2016*.
- Already in DAG via `T4_4_1` Pearl-Robins (1995) and the dynamic-plans / longitudinal extensions.

### Q₄ — Adversarial robustness vs causal robustness

**Pain**: Adversarial examples and distribution shift are distinct from causal misspecification but related. Causal models supposedly transport better under distribution shift; in practice this is conditional and frequently violated.

**Universality evidence**:

- **Bühlmann (2020), "Invariance, causality and robustness," *Statistical Science* 35(3):404-426.** The unifying paper; argues invariance is the right operational criterion.
- Heinze-Deml, Peters, Meinshausen (2018), "Invariant causal prediction for nonlinear models," *Journal of Causal Inference* 6(2). [arXiv:1706.08576].
- Peters, Bühlmann, Meinshausen (2016), "Causal inference using invariant prediction: identification and confidence intervals," *JRSSB* 78(5):947-1012. [arXiv:1501.01332]. **Invariant Causal Prediction (ICP).**
- Magliacane et al. (2018), op. cit. — domain adaptation via causal invariance.
- Arjovsky, Bottou, Gulrajani, Lopez-Paz (2019), "Invariant risk minimization," [arXiv:1907.02893]. IRM; widely critiqued but central reference.

### Q₅ — Variable definition itself is learned

**Pain**: In foundation-model and representation-learning settings, "what is a variable" is not given but learned. Pearl assumes variables are defined; causal-representation-learning tries to learn them. This is a deeper version of P₁.

**Universality evidence**:

- Schölkopf et al. (2021), op. cit. Position paper for the entire program.
- Goyal, Bengio (2022), "Inductive biases for deep learning of higher-level cognition," *Proceedings of the Royal Society A* 478:20210068. [arXiv:2011.15091]. Sparse, factored, modular world models.
- Wang, Khemakhem, Schölkopf, von Kügelgen (2021), "Self-supervised learning with data augmentations provably isolates content from style," *NeurIPS 2021*. [arXiv:2106.04619]. Content/style identifiability.

### Q₆ — Time-series / RNN causal structure

**Pain**: Pearl's framework is largely atemporal. RNNs implicitly model temporal causal structure but don't make it explicit. Granger causality is the classical bridge; modern lifts to nonlinear time series exist.

**Universality evidence**:

- Granger (1969), "Investigating causal relations by econometric models and cross-spectral methods," *Econometrica* 37(3):424-438. Classical.
- **Runge, Bathiany, Bollt et al. (2019), "Inferring causation from time series in Earth system sciences," *Nature Communications* 10:2553.** Modern survey + PCMCI algorithm.
- Tank, Covert, Foti, Shojaie, Fox (2022), "Neural Granger causality," *IEEE TPAMI* 44(8):4267-4279. NN-Granger.
- Löwe, Madras, Zemel, Welling (2022), "Amortized causal discovery: Learning to infer causal graphs from time-series data," *CLeaR 2022*. [arXiv:2006.10833].

### Q₇ — Strategic / multi-agent causation

**Pain**: When agents anticipate interventions, the causal structure mutates. Lucas critique in economics; strategic classification in ML.

**Universality evidence**:

- Lucas (1976), "Econometric policy evaluation: A critique," *Carnegie-Rochester Conference Series* 1:19-46. Classical economic critique of using estimated econometric models for policy.
- **Hardt, Megiddo, Papadimitriou, Wootters (2016), "Strategic classification," *ITCS 2016*. [arXiv:1506.06980].** Strategic-classification setup; classifier-as-intervention.
- Perdomo, Zrnic, Mendler-Dünner, Hardt (2020), "Performative prediction," *ICML 2020*. [arXiv:2002.06673]. Generalizes strategic to performative.

### Q₈ — Causal probing of foundation models

**Pain**: Inferring causal structure inside trained LLMs/foundation models is an active research frontier with major identifiability and methodological issues.

**Universality evidence**:

- Meng, Bau, Andonian, Belinkov (2022), "Locating and editing factual associations in GPT," *NeurIPS 2022*. [arXiv:2202.05262]. ROME — causal mediation in GPT.
- Geiger et al. (2023, 2024) on causal abstraction of language models. Continuing line.
- Wang, Variengien, Conmy, Shlegeris, Steinhardt (2023), "Interpretability in the wild: a circuit for indirect object identification in GPT-2 small," *ICLR 2023*. [arXiv:2211.00593]. Circuit-level causal analysis.

---

## SCM Primitive Rationale

**Decision**: The 10-field `CausalModel` structure (per R₁) is the ONE custom primitive.

**Rationale traced through the URS framework**:

### Pl assessment for `CausalModel`

1. **Non-triviality**: The structure is NOT provable by unfolding definitions of Mathlib alone. It packages constraints (`Pa : V → Finset V`, `f : ∀ i, ... → Sp i`, `hf : ∀ i, Measurable ...`) that no Mathlib type assembles together.
2. **Instantiability**: The Pearl 2009 examples (smoking-tar-cancer, sprinkler-rain, Berkeley admissions) are all concrete instances. The sandbox in `Causality/Basic.lean` is a degenerate 1-vertex instance.
3. **Consistency**: Does not contradict any Mathlib definition. The fields are independently inhabited.

**Pl = True.**

### Coh assessment for `CausalModel`

1. **act(·)-coupling**: Composes with `act(doIntervene)` (graph surgery on `Pa` and `f`), `act(joint)` (push noise through f via topological order), `act(counterfactual)` (twin-network on shared `uDist`), `act(latentProjection)` (induce ADMG from latent vertices), `act(addLevel)` (build a `HierarchicalCausalModel`).
2. **Connectivity**: Connects to `Mathlib.MeasureTheory.ProbabilityMeasure`, `Mathlib.Probability.Kernel`, `Mathlib.Combinatorics.Quiver`, `measurements/ZPM/InformationTheory/*`, every relevant downstream library.

**Coh = True. The structure is maximally composable for this domain.**

### Inv assessment for `CausalModel`

1. **Perturbation robustness**: Survives changes to Pearl's exact field set. Drop `hf` and you lose measurability; add an `IsAcyclic` field and you constrain acyclicity. The current shape is minimum-fields-maximum-content.
2. **Cross-file stability**: Will not break when imported into discovery (`Faithful` typeclass), identification (`Identifiable`), or hierarchical (`HierarchicalCausalModel`) modules. Each downstream consumer adds structure on top.
3. **Substrate independence**: The STRUCTURE survives substrate change. With a Markov category in place of `Stoch`, the same field shape works (the deterministic `f` becomes a morphism in the underlying category). With sheaf semantics, the structure becomes a presheaf evaluated at a base context.

**Inv = True across all 141 DAG nodes + JEPA hierarchy extension.**

### Comp assessment for `CausalModel`

- **Covered**: All 130 strict-result DAG nodes (theorems, corollaries, lemmas, conjectures, definitions). Verified by structural mapping of each node to a derived `def` or `theorem` on `CausalModel`.
- **Partial**: Selection diagrams (need `Σ M, Finset M.V`), cluster DAGs (need cluster-typed Sp), hierarchical (need `HierarchicalCausalModel` wrapping).
- **Uncovered without extension**: Sheaf-theoretic n-level abstraction completeness; foundation-model causal probing; performative prediction.

**Comp = 0.92** (130/141 directly covered; 11 nodes require derived wrappings still in scope).

### Why not other primitives

| Alternative | Why rejected |
|---|---|
| Categorical / sheaf-theoretic (Otsuka-Saigo) | More general, but **categorical machinery is irrelevant to the algorithmic/learning content** (user's pushback 2026-05-21). Beckers-Halpern, Rubenstein, Geiger all use standard Pearl; the categorical formulation adds elegance without adding identification, discovery, or estimation content. Net: maximal HC at the categorical / non-categorical boundary with no corresponding γ-gain. |
| Pearl §7.1.1 separate U-V partition | More notation-faithful to one section of Pearl. Adds fields without adding mathematical content (joint per-vertex noise subsumes shared-source noise). |
| Kernel-based (`f : ∀ i, Kernel (parents) (Sp i)`) | Cleaner categorically. **Loses counterfactual content** (Pearl §1.4.4 explicit: stochastic kernels are insufficient for counterfactuals; D7_1_5 cannot be defined). Pl-kill. |
| Sandbox `SCM (U A S)` (current state in `Causality/Basic.lean`) | Single-vertex collapse. Cannot express multi-vertex graphs, can't do d-separation, can't do graph surgery. Useful as starting point only. |

---

## K/U Breakdown

### KK (Known-Known)

- Pearl 2009 is a closed textbook with verified inheritance DAG (141 nodes).
- 10 modern extension papers have published proofs.
- The `CausalModel` primitive shape covers all DAG nodes (verified mapping).
- The 5 frontload typeclasses map to literature-established pain points.
- Beckers-Halpern 2-level abstraction theory is established.
- The sandbox SCM at `Causality/Basic.lean` compiles modulo 2 sorrys (standard Mathlib lemma applications).
- Index regenerated to 13816 declarations across 7 sub-libraries.

### KU (Known-Unknown — active research questions)

1. **n-level abstraction completeness theorem**: how do iterated 2-level Beckers-Halpern abstractions interact? Is there a hierarchical analogue of do-calculus completeness?
2. **Frontload typeclass interaction**: how do `HasObservedSet`, `Faithful margin`, `MEC`, `Data inductive`, `FiniteSampleClaim`, `HierarchicalCausalModel` compose at theorem-statement level? Are there latent constraints between them?
3. **Layer A axiom-equivalence**: precise Lean-level statement of the Galles-Pearl ↔ Halpern equivalence (mostly the same calculus, but the literature has only sketched proofs).
4. **Linear SEM polynomial-covariance**: what's the right typeclass hierarchy for instrumental cutsets (Kumor-Chen-Bareinboim) layered on the general `CausalModel`?
5. **j-do / sheaf extension**: how does the hierarchical extension interact with the categorical / sheaf side once we have it? (User pushed back on categorical, so this is on hold.)
6. **Pl-kill verification for `G2_8_2`** (Temporal Bias conjecture): does the conjecture survive a formal counterexample sweep?

### UK (Unknown-Known — unarticulated regularities the field has but we haven't surfaced)

1. **The structural parallel between faithfulness margin and concentration inequalities**: both are quantitative-margin conditions over a qualitative baseline. The relationship to PAC-Bayes-style concentration (Mathlib has the relevant infrastructure in `learning-theory/FLT_Proofs/Theorem/PACBayes.lean`) is unexplored.
2. **The parallels between identification (graph constraint) and learning (data constraint)**: identification asks "given infinite data, can we compute Q?"; learning asks "given finite data, can we estimate Q?". The same `Identifiable` typeclass with `FiniteSampleClaim` should unify these.
3. **Sheaf-theoretic completeness corresponding to do-calculus completeness**: Huang-Valtorta's do-calculus completeness proof has a structure (recursive c-component decomposition) that resembles sheaf gluing. Connection unexplored.
4. **Strategic / performative settings as 2-level abstraction with feedback**: Hardt et al.'s strategic classification is naturally a hierarchical-abstraction setting with a learning-induced level shift. Not articulated this way in literature.
5. **Foundation-model causal probing as cluster-DAG identification**: ROME, IOI, etc. are essentially solving cluster-DAG identification problems on neural net internals. Not articulated this way.

### UU (Unknown-Unknown — askability boundary)

1. **What would "causal inference" look like in an architecture where variables themselves are learned in a continuous feedback loop with interventions?** (H-JEPA + active interventional learning + abstraction).
2. **Is there a Pl-admissible formalization of "natural causal kind"?** Pearl assumes variables are given; representation learning tries to learn them; what's the criterion for "the right variables"?
3. **How does causal abstraction interact with non-classical (e.g., quantum) probability theory?** Spekkens-style epistemic restrictions, contextuality.
4. **Is the entire identification/discovery program substrate-relative?** If we change `ProbabilityMeasure` to a different probability monad (e.g., possibilistic, quantum), does the do-calculus still work?

---

## Measurements (per noological-urs A₂)

### Pl — Plausibility (admissibility of the primitive design)

| Claim | Pl assessment |
|---|---|
| `CausalModel` is admissible as the one primitive | True (per Pl assessment above) |
| Frontload `HasObservedSet` typeclass | True (literature evidence P₁) |
| Frontload `Faithful margin` typeclass | True (literature evidence P₂) |
| Frontload `MEC` structure | True (literature evidence P₃) |
| Frontload `Data` inductive | True (literature evidence P₄) |
| Frontload `FiniteSampleClaim` typeclass | True (literature evidence P₅) |
| `HierarchicalCausalModel` as derived structure | True (literature evidence P₆) |

### Coh — Coherence (composability with neighbors)

| Claim | Coh assessment |
|---|---|
| `CausalModel` composes with Mathlib `Quiver`, `MeasureTheory`, `Kernel` | True |
| Frontload typeclasses compose with each other | Coh assessment pending — see KU₂ |
| Sandbox SCM composes with `CausalModel` (degenerate case) | True (single-vertex collapse) |
| Modern extensions compose with their reduction-to-Pearl theorems | True by construction (split file design) |

### Inv — Invariance (paradigm robustness)

| Claim | Inv assessment |
|---|---|
| `CausalModel` survives discrete↔continuous variable change | True |
| `CausalModel` survives Markovian↔semi-Markovian | True (joint `uDist` covers both) |
| `CausalModel` survives recursive↔cyclic | True (`IsAcyclic` is derived predicate, not field) |
| `CausalModel` survives graph-class change (DAG↔ADMG↔MAG↔PAG↔cluster) | True (graph class is derived) |
| Frontload typeclasses survive single-level↔hierarchical | True (typeclasses can be level-indexed without changing primitive) |
| Pearl's results survive sheaf-theoretic extension | True (sheaf is derived presheaf functor) |

### Comp — Completeness (coverage of obligations)

- **Direct DAG node coverage**: 130/141 (= 0.92) at primitive level. Remaining 11 require derived wrappings: 1 hierarchical, 1 selection-diagram, 1 cluster-DAG, ~8 modern-extension-specific data structures.
- **Pearl 2009 coverage**: 100% (all 132 Pearl-direct nodes — original 130 + 2 conceptual anchors).
- **Post-2009 modern-extension coverage**: 11/11 named extensions express-able. Detailed coverage of ID/IDC, complete-adjustment, transportability, etc. depends on the per-extension reduction theorems.
- **DL/ML pain-point coverage** (Q₁-Q₈): 4/8 directly in scope via existing modern extensions; 4/8 require new modern-extension nodes (latent identifiability, NN-SCM, time-series, strategic) — proposed but not yet added.

**Comp = 0.92 on primary obligations, 0.50 on DL/ML extensions.**

### HC at paradigm joints

The genuine cross-paradigm tensions in this project, ranked by HC:

| Joint | HC | Source of tension | Mitigation |
|---|---|---|---|
| Frontload typeclasses ⊥ retrofit | ~1.2 (if not frontloaded) → 0.1 (if frontloaded) | Each pain point P₁-P₅ becomes a hypothesis added to every theorem post-hoc | **Frontload now (R₂)** |
| Categorical / non-categorical | 0.6 | Sheaf-theoretic framing is elegant but algorithmically irrelevant | **User decision: stay with Pearl-direct primitive; categorical extension dropped** |
| Single-level / hierarchical (n-level) | 0.7 | Beckers-Halpern is 2-level; n-level synthesis is open | **Acknowledged as research-programme cell (DAG node `EXT_HIERARCHICAL_ABSTRACTION` tetrad cell 7B)** |
| Asymptotic / finite-sample | 0.6 | Pearl is asymptotic; modern is finite-sample | **Frontload `FiniteSampleClaim` typeclass** |
| Faithfulness binary / margin | 0.8 | Binary faithfulness is finite-sample-empty | **Frontload `Faithful margin` typeclass** |
| Identification / estimation | 0.5 | Identifiability is well-defined-ness; estimation is statistical reconstruction | **Same `Identifiable` typeclass with `FiniteSampleClaim` index (UK₂)** |
| DAG-level / equivalence-class | 1.0 | Modern theorems are MEC-stated; Pearl theorems are DAG-stated | **Frontload `MEC` structure** |
| Observational / interventional / mixed-source | 0.9 | `P(V)` notation hides data source | **Frontload `Data` inductive** |
| Pearl variables / learned variables (representation learning) | 0.8 | Pearl assumes variables given; CRL learns them | **Acknowledged as open research-programme (UU₂)** |
| Classical / strategic-performative | 0.6 | Standard SCM is non-strategic | **Q₇ extension node proposed; not yet added to DAG** |
| Tabular variables / NN-internal representations | 0.7 | Geiger's causal-abstraction-of-NNs is the existing bridge | **Q₂ extension node proposed; not yet added to DAG** |

**Total HC across joints if NOTHING is frontloaded**: ~8.3 (sum of column).
**Total HC if 5 frontloads land**: ~3.5 (categorical, hierarchical, identification/estimation, learning-variables, strategic, NN-internal remain).

---

## γ-ledger and Γ-ledger (this session)

### γ-ledger (validated knowledge gain — discovery)

- **γ₁**: `CausalModel` 10-field structure validated as Pl + Coh + Inv + Comp (= 0.92) on Pearl-2009 + post-2009 DAG. **Foundation locked.**
- **γ₂**: 5 frontload typeclasses identified, each backed by ≥3 universality references. **Pre-URS-pass scope locked.**
- **γ₃**: `EXT_HIERARCHICAL_ABSTRACTION` added to DAG with 4 new edges and 5 new literature references. **DAG-level extension committed.**
- **γ₄**: Categorical / sheaf-theoretic framing dropped as load-bearing per user pushback (HC reduction at categorical joint from 1.0 to 0.6). **Architecture simplified.**

### Γ-ledger (inquiry — restructuring the grammar of questions)

- **Γ₁**: The question "what is the right causal-inference primitive?" restructured from "categorical vs concrete" to "concrete with categorical as a derived presheaf when needed." This is an ABD-R move (grammar modification of the question space).
- **Γ₂**: The question "how do we handle hierarchy?" restructured from "Spivak-Vagner operadic" to "Beckers-Halpern abstraction with n-level Lean structure layered on `CausalModel`." Same ABD-R direction.
- **Γ₃**: The question "what should the frontload typeclasses be?" newly articulated. Previously implicit in literature, now explicit as 5 named typeclass slots. KU expansion.
- **Γ₄**: The question "what's the right axiom-equivalence proof?" reframed — user's commitment ("the equivalence work is exactly where formalization adds value") inverted the default. Previously a footnote, now a load-bearing target.

### η (validated novelty per effort)

- η for this session: high. ~4 hours of structured conversation produced (a) committed primitive design, (b) committed scope for 5 frontload typeclasses, (c) committed hierarchical extension with literature, (d) committed pain-point inventory with citations.
- η for the project as a whole, projected: moderate. 141 DAG nodes × ~50-200 LOC each = 7000-28000 LOC formalization budget. The substantive new content is the equivalence theorems and reduction-to-Pearl bridges, not the per-node transcriptions.

---

## Pl-kill list (boundaries explicitly named)

- **Pl-kill 1**: Categorical / sheaf-theoretic primitive as load-bearing. Reason: irrelevant to learning, algorithmic content unchanged. **Discovery**: stay with concrete `CausalModel`; categorical extension is derived presheaf when needed.
- **Pl-kill 2**: `SCM (U A S)` as the primitive shape. Reason: single-vertex collapse, can't express multi-vertex graphs, d-separation, graph surgery. **Discovery**: refactor to indexed-family `CausalModel`.
- **Pl-kill 3**: Universal n-level hierarchical do-calculus completeness as in-scope for v1. Reason: open research problem; literature only has 2-level theory. **Discovery**: scope `EXT_HIERARCHICAL_ABSTRACTION` as research-programme cell (7B), not fundamental-result (9).
- **Pl-kill 4**: Pearl §7.1.1 separate U-V partition as primitive shape. Reason: per-vertex joint-noise formulation is strictly more general. **Discovery**: collapse U into per-vertex `U : V → Type` with joint `uDist`.

---

## Next actions

1. **Confirm frontload typeclass set (R₂)**: lock or revise the 5 typeclasses before URS pass.
2. **Run `task-urs-typing-derivation` on the 141 DAG nodes**: produce 141-sorry target. Batched root-to-leaves from the 27 main-chain anchors.
3. **Decide whether to add Q₁-Q₈ DL/ML extensions as DAG nodes**: each is a potential 12th-19th modern-extension node. The two strongest candidates: `EXT_LATENT_IDENTIFIABILITY` (Locatello et al. impossibility), `EXT_NN_AS_SCM_MECHANISM` (Geiger et al.).
4. **Begin reduction-to-Pearl theorems for the 11 modern extensions**: each one is a separate file per the split-files commitment.
5. **Write the Galles-Pearl ↔ Halpern axiom-equivalence module** as the first non-trivial bridge contribution.

---

**END URS.**
