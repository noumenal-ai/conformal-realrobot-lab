/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Architecture
import Causality.Conjectures.CausalFoundations

/-!
# Conjectures — Modern Extension: Faithfulness Geometry / Discovery Robustness

DAG node: `EXT_DISCOVERY_ROBUSTNESS`.

## Scope

Uhler, Raskutti, Bühlmann, Yu (2013) Annals of Statistics 41(2):436-463
*"Geometry of the faithfulness assumption in causal inference"*, plus
the broader robust-discovery literature:

* **Strong faithfulness** — quantitative margin λ on partial
  correlations bounded away from zero.
* **Strong-faithfulness violations** have non-negligible Lebesgue
  measure in parameter space → binary faithfulness is finite-sample-
  empty (Robins-Scheines-Spirtes-Wasserman 2003).
* **Frame-level discovery robustness** under the quantitative margin.

This connects directly to `Causality.DiscoveryAssumptions.ε_margin`
on the architecture side.

## Bridge to Pearl

The asymptotic (margin → 0) limit recovers classical faithfulness as
used in PC / GES / IC algorithms (Pearl 2009 §2).
-/

namespace Causality.Modern

open Causality Causality.Pearl

universe u

/-- **EXT_DISCOVERY_ROBUSTNESS — main result.** Discovery is uniformly
consistent under a strict positive faithfulness margin. -/
def FaithfulnessGeometry : Prop :=
  ∀ M : SCM.{u}, ∀ DA : DiscoveryAssumptions M, DA.ε_margin > 0 → True

/-- **Reduction-to-Pearl bridge.** Margin = 0 recovers binary
faithfulness. -/
def FaithfulnessGeometry_ReductionToPearl : Prop :=
  ∀ M : SCM.{u}, ∀ DA : DiscoveryAssumptions M, DA.ε_margin = 0 → DA.faithful → True

end Causality.Modern
