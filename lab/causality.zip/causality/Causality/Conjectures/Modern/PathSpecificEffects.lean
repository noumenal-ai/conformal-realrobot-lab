/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Architecture
import Causality.Conjectures.DirectEffects

/-!
# Conjectures — Modern Extension: Path-Specific Effects

DAG node: `EXT_MEDIATION_PATH_SPECIFIC_EFFECTS`.

## Scope

Post-Pearl mediation analysis:

* **Pearl 2001** — Direct and indirect effects via natural effects.
* **Avin-Shpitser-Pearl 2005** — Path-specific effects identification.
* **VanderWeele 2015** — Mediation interactions, four-way decomposition.
* **Robins-Richardson 2010** — Interventional effects when natural
  effects are not identified.
* **Didelez-Dawid-Geneletti 2006** — Separable effects.

## Bridge to Pearl

Path-specific effects with a single direct path recover the Pearl Ch 4
direct-effect criterion (T4_5_3, C4_5_2).
-/

namespace Causality.Modern

open Causality Causality.Pearl

universe u

/-- **Path-specific effect predicate** (Avin-Shpitser-Pearl 2005). Stub. -/
def PathSpecificIdentified (_M : SCM.{u}) (_X _Y : Finset (SCM.V _M)) : Prop := True

/-- **EXT_MEDIATION_PATH_SPECIFIC_EFFECTS — main result.** Graphical
characterization of identifiable path-specific effects. -/
def PathSpecificEffects : Prop :=
  ∀ M : SCM.{u}, ∀ X Y : Finset M.V, PathSpecificIdentified M X Y → True

/-- **Reduction-to-Pearl bridge.** Single direct path → Ch 4 direct effect. -/
def PathSpecificEffects_ReductionToPearl : Prop :=
  ∀ M : SCM.{u}, ∀ X Y : Finset M.V, PathSpecificIdentified M X Y → Causality.Pearl.T4_5_3.{u}

end Causality.Modern
