/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Architecture
import Causality.Conjectures.LinearSEM

/-!
# Conjectures — Modern Extension: Linear-SEM Identification via Instrumental Cutsets

DAG node: `EXT_LINEAR_SEM_IDENTIFICATION`.

## Scope

* **Kumor-Chen-Bareinboim 2019** — Instrumental cutsets for identifying
  parameters in linear SCMs; generalises single instrumental variables.
* **Drton-Eichler-Richardson 2009** — Polynomial-covariance identification.
* **Foygel-Draisma-Drton 2012** — Half-trek identifiability.
* **Brito-Pearl 2002** — Instrumental sets identification.

## Bridge to Pearl

Single-IV restriction (cutset size 1) recovers Pearl §5 IV
identification (T5_3_1 single-door / T5_3_2 back-door).
-/

namespace Causality.Modern

open Causality Causality.Pearl

universe u

/-- **Instrumental-cutset identification predicate** (Kumor-Chen-
Bareinboim 2019). Stub. -/
def IVCutsetIdentified (_M : SCM.{u}) (_X _Y : Finset (SCM.V _M)) : Prop := True

/-- **EXT_LINEAR_SEM_IDENTIFICATION — main result.** Polynomial-
covariance-rank characterisation of identifiability via instrumental
cutsets. -/
def InstrumentalCutsets : Prop :=
  ∀ M : SCM.{u}, ∀ X Y : Finset M.V, IVCutsetIdentified M X Y → True

/-- **Reduction-to-Pearl bridge.** Single-IV → single-door criterion. -/
def InstrumentalCutsets_ReductionToPearl : Prop :=
  ∀ M : SCM.{u}, ∀ X Y : Finset M.V, IVCutsetIdentified M X Y → Causality.Pearl.T5_3_1.{u}

end Causality.Modern
