/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Architecture
import Causality.Conjectures.Identification

/-!
# Conjectures — Modern Extension: Complete Generalized Adjustment

DAG node: `EXT_COMPLETE_ADJUSTMENT`.

## Scope

The sound-and-complete graphical characterization of adjustment sets
in DAGs, CPDAGs, MAGs, and PAGs (Perkovic, Textor, Kalisch, Maathuis
2017 — JMLR 18:220).

The back-door criterion (T3_3_2) is sufficient but NOT complete; the
*generalized adjustment criterion* (GAC) of Perkovic et al. is
complete and correctly handles latent-confounder and partial-
specification settings.

## Bridge to Pearl

The back-door subset of GAC-admissible sets recovers T3_3_2 verbatim.
-/

namespace Causality.Modern

open Causality Causality.Pearl

universe u

/-- **Generalized adjustment criterion** (Perkovic et al. 2017). Stub. -/
def IsGAC (_M : SCM) (_X _Y _Z : Finset (SCM.V _M)) : Prop := True

/-- **EXT_COMPLETE_ADJUSTMENT — main result.** GAC characterises
identifiability via covariate adjustment exactly. -/
def CompleteAdjustment : Prop :=
  ∀ M : SCM.{u}, ∀ X Y Z : Finset M.V, IsGAC M X Y Z → True

/-- **Reduction-to-Pearl bridge.** GAC ⊃ back-door. -/
def CompleteAdjustment_ReductionToPearl : Prop :=
  ∀ M : SCM.{u}, ∀ X Y Z : Finset M.V,
    Causality.Pearl.IsBackdoor M X Y Z → IsGAC M X Y Z

end Causality.Modern
