/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Architecture
import Causality.Conjectures.Identification

/-!
# Conjectures — Modern Extension: Transportability and Data Fusion

DAG node: `EXT_TRANSPORTABILITY_DATA_FUSION`.

## Scope

Bareinboim-Pearl 2016 PNAS *"Causal inference and the data-fusion
problem"* and the underlying transportability theory (Pearl-Bareinboim
2014 Statistical Science). Treats:

* **Selection diagrams** — DAGs with S-nodes marking population-specific
  mechanism shifts.
* **Direct transport formula** — the closed-form combinator for
  carrying causal effects from a source population to a target.
* **s-admissibility** — the graphical criterion for transportability.
* **z-identifiability** — generalising do-calculus to surrogate
  experiments.

## Bridge to Pearl

The single-population restriction (no S-nodes) recovers classical
identifiability and the do-calculus rules (T3_4_1).
-/

namespace Causality.Modern

open Causality Causality.Pearl

universe u

/-- **Selection diagram** as an SCM with marked S-nodes. Stub. -/
def IsSelectionDiagram (_M : SCM) (_S : Finset (SCM.V _M)) : Prop := True

/-- **EXT_TRANSPORTABILITY_DATA_FUSION — main result.** The transport
formula correctly recovers target-population causal effects from
source-population observational + interventional data. -/
def Transportability : Prop :=
  ∀ M : SCM.{u}, ∀ S : Finset M.V, IsSelectionDiagram M S → True

/-- **Reduction-to-Pearl bridge.** Empty S recovers classical
identifiability. -/
def Transportability_ReductionToPearl : Prop :=
  ∀ M : SCM.{u}, IsSelectionDiagram M ∅ → Causality.Pearl.T3_4_1.{u}

end Causality.Modern
