/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Architecture
import Causality.Conjectures.DSeparation

/-!
# Conjectures — Modern Extension: Mixed Graphs (ADMG / MAG / PAG / CPDAG)

DAG node: `EXT_GRAPHICAL_MIXED_GRAPHS`.

## Scope

Generalisations of Pearl's DAG semantics to the richer graph classes
required for latent-confounder, selection-bias, and partial-
specification settings:

* **ADMG** — Acyclic Directed Mixed Graph (Richardson 2003)
* **MAG**  — Maximal Ancestral Graph (Richardson-Spirtes 2002)
* **PAG**  — Partial Ancestral Graph (Zhang 2008)
* **CPDAG** — Completed PDAG (Andersson-Madigan-Perlman 1997)
* **Cluster DAG** — Anand-Ribeiro-Tian-Bareinboim 2023

The unifying primitive on the formalization side is
`Causality.CausalEquivClass` (one constructor per kind via
`EquivClassKind`).

## Bridge to Pearl

m-separation in ADMG/MAG restricts to d-separation when the graph has
no bidirected edges — this is the reduction-to-Pearl bridge theorem.
-/

namespace Causality.Modern

open Causality Causality.Pearl

universe u

/-- **m-separation in mixed graphs** (Richardson-Spirtes 2002). Stub. -/
def IsMsep (M : SCM) (_X _Y _Z : Finset M.V) : Prop := True

/-- **EXT_GRAPHICAL_MIXED_GRAPHS — main result.** m-separation soundly
characterises CI in the mixed-graph class, generalising T1_2_4. -/
def MixedGraphs_Soundness : Prop :=
  ∀ M : SCM.{u}, ∀ X Y Z : Finset M.V, IsMsep M X Y Z → True

/-- **Reduction-to-Pearl bridge.** In the bidirected-free subclass,
m-separation collapses to d-separation, recovering T1_2_4. -/
def MixedGraphs_ReductionToPearl : Prop :=
  ∀ M : SCM.{u}, ∀ X Y Z : Finset M.V,
    IsMsep M X Y Z ↔ Causality.Pearl.IsDsep M X Y Z

end Causality.Modern
