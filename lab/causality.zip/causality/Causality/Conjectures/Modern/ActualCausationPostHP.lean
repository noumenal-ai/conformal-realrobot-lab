/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Architecture
import Causality.Conjectures.CounterfactualSemantics

/-!
# Conjectures — Modern Extension: Actual Causation (Post-HP, Layer B)

DAG node: `EXT_ACTUAL_CAUSATION_POST_HP`.

## Scope and provenance

The Halpern-Pearl 2005 AC1/AC2/AC3 actual-causation conditions, as
revised through:

* **Halpern 2008** — Defaults, normality, actual causes.
* **Halpern 2015** — A modification of the Halpern-Pearl definition.
* **Halpern 2016** — *Actual Causality* (monograph).
* **Hitchcock 2007, 2017** — Counterfactual semantics for actual causation.
* **Beckers-Vennekens 2018** — Variables vs equations approach.

## Layer B (additive)

Per DISCOVERY_URS A₁: Layer B (actual causation) sits *additively*
above Layer A (counterfactual semantics) — it adds AC1/AC2/AC3 over
the recursive SCM semantics fixed by Layer A's Galles-Pearl axioms
(`Conjectures.AxiomEquivalence.LayerA`).

## Relation to redacted Ch 10

The Pearl 2009 Chapter 10 candidates (sustenance, causal beam, ...)
are *redacted* per the audit (see
`Conjectures.Redacted.ActualCauseCh10`). This file formalises the
*post-HP* line as the formalization target.
-/

namespace Causality.Modern

open Causality Causality.Pearl

universe u

/-! ## AC1 / AC2 / AC3 -/

/-- **AC1 — Actual-world holding.** `X = x` and `Y = y` in the actual
world. Stub. -/
def AC1 (_M : SCM) : Prop := True

/-- **AC2 — Counterfactual contrast.** A witness `(W, x')` such that
intervening in `X` would change `Y`. Stub. -/
def AC2 (_M : SCM) : Prop := True

/-- **AC3 — Minimality.** No proper subset of `X` already satisfies
AC1 ∧ AC2. Stub. -/
def AC3 (_M : SCM) : Prop := True

/-- **EXT_ACTUAL_CAUSATION_POST_HP — main result.** Actual cause
definition over Layer A. -/
def ActualCausationPostHP : Prop :=
  ∀ M : SCM.{u}, AC1 M ∧ AC2 M ∧ AC3 M → True

end Causality.Modern
