/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Architecture

/-!
# Conjectures — Modern Extension: Hierarchical Causal Abstraction

DAG node: `EXT_HIERARCHICAL_ABSTRACTION` (added 2026-05-21).

## Scope

Multi-scale interventional semantics via abstraction maps between SCMs:

* **Rubenstein-Weichwald-Bongers-Mooij-Janzing-Grosse-Wentrup-Schölkopf
  2017** — *Causal Consistency of Structural Equation Models* (UAI).
* **Beckers-Halpern 2019** — *Abstracting Causal Models* (AAAI).
* **Chalupka-Eberhardt-Perona 2017** — Causal feature learning.
* **Anand-Ribeiro-Tian-Bareinboim 2023** — Cluster DAGs and partial
  specification.

Connects directly to the architecture-side `HierarchicalCausalModel`
hook in `Architecture.lean §15` and to the `CausalFrame.level`
field.

## Bridge to Pearl

The single-level (`level = 0`) case recovers single-SCM Pearl
semantics — no hierarchy, no abstraction map.
-/

namespace Causality.Modern

open Causality

universe u

/-- **Abstraction-consistency predicate** (Beckers-Halpern 2019). Stub. -/
def IsAbstractionConsistent (_HCM : HierarchicalCausalModel.{u}) : Prop := True

/-- **EXT_HIERARCHICAL_ABSTRACTION — main result.** Beckers-Halpern
abstraction consistency: high-level interventions commute with the
abstraction map. -/
def HierarchicalAbstraction : Prop :=
  ∀ HCM : HierarchicalCausalModel.{u}, IsAbstractionConsistent HCM → True

/-- **Reduction-to-Pearl bridge.** Single-level case recovers Pearl
single-SCM semantics. -/
def HierarchicalAbstraction_ReductionToPearl : Prop :=
  ∀ HCM : HierarchicalCausalModel.{u}, (∀ n, HCM.levels n = HCM.levels 0) → True

end Causality.Modern
