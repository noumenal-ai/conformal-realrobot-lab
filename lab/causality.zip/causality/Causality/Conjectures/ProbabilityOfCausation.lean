/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Architecture

/-!
# Conjectures — Probability of Causation (Chapter 9)

DAG module: `probability_of_causation` (11 theorems) + 8 chapter-9
definitions = 19 nodes.

Pearl 2009 §9: the probabilities of necessity (PN), sufficiency (PS),
and necessity-and-sufficiency (PNS); sharp bounds; identification
under exogeneity / monotonicity; the local-invertibility identification
of counterfactuals (T9_4_2).

## Substrate (refined 2026-07-29 per the catalog protocol; fidelity
review same day)

Two layers.

**Layer 1 — `ResponseDist`** (exogenous marginal substrate): a joint law
over the two binary potential outcomes `(Y₀, Y₁)`. Exogeneity is baked
in — under it the experimental quantities `P(y | do(x))` ARE the
potential-outcome marginals, so "from experimental effects" reads "from
the marginals", and `P(y | x) = P(y | do(x))`. This is the §9.2.3
setting (Tian–Pearl bounds); PN and PS appear in their exogenous
reduced forms `pns / pY1` and `pns / (1 - pY0)`, justified by `T9_2_11`
on layer 2. Carries `T9_2_10`, `C9_2_12`, `T9_2_14`.

**Layer 2 — `XResponseDist`** (treatment-augmented joint): a joint law
over `(X, Y₀, Y₁)`, with consistency `Y = Y_X` definitional (observed
outcome read as `Y₁` on `{X = true}` and `Y₀` on `{X = false}`). Here
PN and PS are genuine conditional counterfactual queries (D9_2_1,
D9_2_2), exogeneity (D9_2_9) is a hypothesis — the product form of
`(Y₀, Y₁) ⫫ X` — rather than a substrate fact, and `L9_2_6` /
`T9_2_15` hold WITHOUT exogeneity, matching Pearl's actual assumption
set for those results. Carries `L9_2_6`, `T9_2_11`, `T9_2_15`.

The IV/Balke–Pearl LP is the recorded next refinement
(`Conjectures.Modern.PartialIdentification`). These Props carry the
adaptive-metrology G5 width interface: sharp bounds = width validity +
sharpness; nonidentifiability = width > 0; monotonic identification =
the floor collapse under regime (assumption-set) extension.

**Division convention.** Lean/Mathlib set `x / 0 = 0`. Every Prop whose
content involves `pn` or `ps` guards the relevant denominator
(`0 < pY1`, `pY0 < 1`, `0 < pxy`, `0 < pxy'`), so no stated claim rests
on the convention.

## Fidelity-review record (2026-07-29)

- `T9_2_10` sharpness strengthened from endpoint attainment to Pearl's
  actual claim: EVERY value of PNS permitted by the bounds is realized
  by some model with the given experimental marginals (endpoint
  attainment is the special case at the two interval ends).
- `C9_2_12` restated to match the source: Corollary 9.2.12 is about PN
  (not PNS) and asserts every point of the PN interval (9.14) is
  attained; the earlier PNS-nonuniqueness Prop is retained verbatim as
  the auxiliary `C9_2_12_pns_witness` (not a DAG node).
- `T9_2_14` extended with the PN (9.22) and PS (9.23) identification
  conjuncts, denominator-guarded; previously only the PNS conjunct
  (9.21) was stated.
- `T9_2_11` added (listed as covered but had no Prop).
- `L9_2_6` refined from stub on layer 2 — assumption-free as in the
  source, guarded only by definedness of the two conditionals.
- `T9_2_15` refined from stub on layer 2 (eqs. (9.28)–(9.30); no
  exogeneity assumption, matching the source).
- `D9_2_1`, `D9_2_2`, `D9_2_9` formalized (layer 2 proper forms; layer
  1 carries the exogenous reduced PN/PS).

## DAG nodes covered

| id | kind | title | Lean |
|---|---|---|---|
| `D9_2_1` | Definition | Probability of Necessity, PN | `XResponseDist.pn` (+ reduced `ResponseDist.pn`) |
| `D9_2_2` | Definition | Probability of Sufficiency, PS | `XResponseDist.ps` (+ reduced `ResponseDist.ps`) |
| `D9_2_3` | Definition | Probability of Necessity and Sufficiency, PNS | `ResponseDist.pns`, `XResponseDist.pns` |
| `D9_2_4` | Definition | Probability of Disablement, PD | not yet stated |
| `D9_2_5` | Definition | Probability of Enablement, PE | not yet stated |
| `D9_2_9` | Definition | Exogeneity | `XResponseDist.Exogenous` |
| `D9_2_13` | Definition | Monotonicity | `ResponseDist.MonotoneResponse`, `XResponseDist.MonotoneResponse` |
| `D9_4_1` | Definition | Local Invertibility | not yet stated |
| `L9_2_6` | Lemma | PNS-PN-PS decomposition | Prop (refined, layer 2) |
| `L9_2_7` | Lemma | PN invariance under inhibitors | not yet stated (needs downstream-cascade substrate) |
| `L9_2_8` | Lemma | PS invariance under alternative causes | not yet stated (needs downstream-cascade substrate) |
| `T9_2_10` | Theorem | Sharp PNS bounds under exogeneity | Prop (refined, layer 1) |
| `T9_2_11` | Theorem | PN/PS/PNS relations under exogeneity | Prop (refined, layer 2) |
| `C9_2_12` | Corollary | Nonidentifiability of PN from experimental effects alone | Prop (refined, layer 1) + aux `C9_2_12_pns_witness` |
| `T9_2_14` | Theorem | Identifiability under Exogeneity and Monotonicity | Prop (refined, layer 1) |
| `T9_2_15` | Theorem | Identification under monotonicity plus identifiable effects | Prop (refined, layer 2) |
| `C9_2_16` | Corollary | Markovian monotonic identification | not yet stated (needs Markovian parent-adjustment layer) |
| `C9_2_17` | Corollary | Semi-Markovian monotonic identification | not yet stated (needs semi-Markovian layer) |
| `T9_4_2` | Theorem | Local invertibility identifies counterfactuals | deliberate stub |
-/

namespace Causality.Pearl

open Causality

universe u

/-! ## Layer 1: binary response-type distributions (§9.2, exogenous case) -/

/-- A joint law over the two binary potential outcomes: `r y0 y1 = P(Y₀ = y0, Y₁ = y1)`.
The four cells are Pearl's response types (doomed / helped / harmed / saved read off
the pairs). Under exogeneity this is the whole §9.2 state of nature. -/
structure ResponseDist where
  /-- Cell probability `P(Y₀ = y0, Y₁ = y1)`. -/
  r : Bool → Bool → ℝ
  /-- Cells are nonnegative. -/
  nonneg : ∀ y0 y1, 0 ≤ r y0 y1
  /-- Total mass one. -/
  sum_one : r false false + r false true + r true false + r true true = 1

namespace ResponseDist

/-- Experimental marginal `P(Y₁ = 1) = P(y | do(x))` under exogeneity. -/
def pY1 (d : ResponseDist) : ℝ := d.r false true + d.r true true

/-- Experimental marginal `P(Y₀ = 1) = P(y | do(x'))` under exogeneity. -/
def pY0 (d : ResponseDist) : ℝ := d.r true false + d.r true true

/-- **D9_2_3 (refined).** PNS `= P(Y₁ = 1, Y₀ = 0)`: treatment is necessary and
sufficient — the "helped" cell. -/
def pns (d : ResponseDist) : ℝ := d.r false true

/-- **D9_2_1 (exogenous reduced form).** Pearl's PN is the conditional counterfactual
`P(y'_{x'} | x, y)` — the probability that `y` would not have occurred without `x`,
given that `x` and `y` did occur. Under exogeneity it reduces to
`PNS / P(y | x) = pns / pY1` (Theorem 9.2.11); this substrate carries the reduced
form. The genuine conditional definition is `XResponseDist.pn`; `T9_2_11` proves
the reduction. Lean convention `x / 0 = 0`: Props about `pn` guard `0 < pY1`. -/
noncomputable def pn (d : ResponseDist) : ℝ := d.pns / d.pY1

/-- **D9_2_2 (exogenous reduced form).** Pearl's PS is the conditional counterfactual
`P(y_x | x', y')`. Under exogeneity it reduces to
`PNS / P(y' | x') = pns / (1 - pY0)` (Theorem 9.2.11); this substrate carries the
reduced form. The genuine conditional definition is `XResponseDist.ps`; `T9_2_11`
proves the reduction. Lean convention `x / 0 = 0`: Props about `ps` guard `pY0 < 1`. -/
noncomputable def ps (d : ResponseDist) : ℝ := d.pns / (1 - d.pY0)

/-- **D9_2_13 (refined).** Monotonicity: no "harmed" response type,
`P(Y₀ = 1, Y₁ = 0) = 0`. Pearl's functional form (`y_{x'}(u) ≤ y_x(u)` for all `u`)
is rendered distributionally as zero mass on the harmed cell — the almost-sure
version, which is what the §9.2 identification results consume. -/
def MonotoneResponse (d : ResponseDist) : Prop := d.r true false = 0

/-- Constructor from the four cells. -/
def mk4 (a00 a01 a10 a11 : ℝ) (h00 : 0 ≤ a00) (h01 : 0 ≤ a01) (h10 : 0 ≤ a10)
    (h11 : 0 ≤ a11) (hsum : a00 + a01 + a10 + a11 = 1) : ResponseDist where
  r := fun y0 y1 => match y0, y1 with
    | false, false => a00
    | false, true => a01
    | true, false => a10
    | true, true => a11
  nonneg := by
    intro y0 y1
    cases y0 <;> cases y1
    · exact h00
    · exact h01
    · exact h10
    · exact h11
  sum_one := hsum

end ResponseDist

/-! ## Layer 2: treatment-augmented joint over `(X, Y₀, Y₁)` -/

/-- A joint law over treatment and both potential outcomes:
`q x y0 y1 = P(X = x, Y₀ = y0, Y₁ = y1)`. Consistency (`Y = Y_X`) is definitional:
the observed outcome is read as `Y₁` on `{X = true}` and as `Y₀` on `{X = false}`
(see `py`, `pxy`, `pxy'`). On this layer PN and PS are genuine conditional
counterfactual queries (D9_2_1, D9_2_2), exogeneity (D9_2_9) is a hypothesis rather
than a substrate fact, and `L9_2_6` / `T9_2_15` are stated without exogeneity,
matching Pearl's assumption set. -/
structure XResponseDist where
  /-- Cell probability `P(X = x, Y₀ = y0, Y₁ = y1)`. -/
  q : Bool → Bool → Bool → ℝ
  /-- Cells are nonnegative. -/
  nonneg : ∀ x y0 y1, 0 ≤ q x y0 y1
  /-- Total mass one. -/
  sum_one :
    q false false false + q false false true + q false true false + q false true true +
      q true false false + q true false true + q true true false + q true true true = 1

namespace XResponseDist

/-- Treatment marginal `P(X = x)`. -/
def pxMarg (j : XResponseDist) (x : Bool) : ℝ :=
  j.q x false false + j.q x false true + j.q x true false + j.q x true true

/-- Response-type marginal `P(Y₀ = y0, Y₁ = y1)`. -/
def rMarg (j : XResponseDist) (y0 y1 : Bool) : ℝ :=
  j.q false y0 y1 + j.q true y0 y1

/-- Marginalize treatment away, landing on the layer-1 substrate. Exact — no
information about `(Y₀, Y₁)` is lost, which is why layer-1 statements about
marginal quantities transfer. -/
def toResponse (j : XResponseDist) : ResponseDist where
  r := j.rMarg
  nonneg := by
    intro y0 y1
    show 0 ≤ j.q false y0 y1 + j.q true y0 y1
    exact add_nonneg (j.nonneg _ _ _) (j.nonneg _ _ _)
  sum_one := by
    simp only [rMarg]
    linarith [j.sum_one]

/-- **D9_2_3 (joint layer).** `PNS = P(Y₁ = 1, Y₀ = 0)`. -/
def pns (j : XResponseDist) : ℝ := j.q false false true + j.q true false true

/-- Observational outcome probability `P(y) = P(Y = 1)`; by consistency `Y = Y₁`
on `{X = true}` and `Y = Y₀` on `{X = false}`. -/
def py (j : XResponseDist) : ℝ :=
  j.q false true false + j.q false true true + j.q true false true + j.q true true true

/-- Observational joint `P(x, y) = P(X = 1, Y = 1)` (consistency: `= P(X = 1, Y₁ = 1)`). -/
def pxy (j : XResponseDist) : ℝ := j.q true false true + j.q true true true

/-- Observational joint `P(x', y') = P(X = 0, Y = 0)` (consistency: `= P(X = 0, Y₀ = 0)`). -/
def pxy' (j : XResponseDist) : ℝ := j.q false false false + j.q false false true

/-- **D9_2_1 (Probability of Necessity).** `PN = P(y'_{x'} | x, y)`: by consistency
the conditioning event is `{X = 1, Y₁ = 1}` and the target is `{Y₀ = 0}`, so
`PN = P(X = 1, Y₀ = 0, Y₁ = 1) / P(x, y)`. Lean convention `x / 0 = 0`: Props
about `pn` guard `0 < pxy` (definedness of the conditional). -/
noncomputable def pn (j : XResponseDist) : ℝ := j.q true false true / j.pxy

/-- **D9_2_2 (Probability of Sufficiency).** `PS = P(y_x | x', y')`: by consistency
the conditioning event is `{X = 0, Y₀ = 0}` and the target is `{Y₁ = 1}`, so
`PS = P(X = 0, Y₀ = 0, Y₁ = 1) / P(x', y')`. Lean convention `x / 0 = 0`: Props
about `ps` guard `0 < pxy'` (definedness of the conditional). -/
noncomputable def ps (j : XResponseDist) : ℝ := j.q false false true / j.pxy'

/-- **D9_2_9 (Exogeneity).** `(Y₀, Y₁) ⫫ X`, in product form: every cell factors
as `P(X = x) · P(Y₀ = y0, Y₁ = y1)`. Pearl states (9.10) in conditional form
`P(y_x, y_{x'} | x) = P(y_x, y_{x'})`; the product form is equivalent whenever
`P(x) > 0` and is the convention-free rendering. Under this hypothesis the
observational conditionals coincide with the experimental quantities, which is
what licenses layer 1's identification of the two. -/
def Exogenous (j : XResponseDist) : Prop :=
  ∀ x y0 y1, j.q x y0 y1 = j.pxMarg x * j.rMarg y0 y1

/-- **D9_2_13 (joint layer).** Monotonicity: zero mass on the harmed response
type, `P(Y₀ = 1, Y₁ = 0) = 0` — jointly over both treatment arms. -/
def MonotoneResponse (j : XResponseDist) : Prop := j.rMarg true false = 0

end XResponseDist

/-! ## Conjectures -/

/-- **L9_2_6 (PNS-PN-PS decomposition, Pearl eq. (9.5)).**
`PNS = P(x, y) · PN + P(x', y') · PS`. Assumption-free in the source — it follows
from consistency alone, with NO exogeneity — hence stated on the layer-2 joint,
where arbitrary dependence between `X` and `(Y₀, Y₁)` is allowed. The two
positivity guards are exactly the definedness conditions of the conditional
probabilities PN and PS (Pearl leaves them implicit). -/
def L9_2_6 : Prop :=
  ∀ j : XResponseDist, 0 < j.pxy → 0 < j.pxy' →
    j.pns = j.pxy * j.pn + j.pxy' * j.ps

/-- **T9_2_10 (Sharp PNS bounds under exogeneity, Pearl §9.2 eq. (9.9) / Tian–Pearl).**
Validity: every response distribution's PNS lies in the Fréchet interval
`[max 0 (pY1 - pY0), min pY1 (1 - pY0)]` — the exogenous specialization of (9.9),
with `P(y|x) = pY1`, `P(y|x') = pY0`, `P(y'|x') = 1 - pY0`.
Sharpness, in Pearl's stated sense: for every consistent pair of experimental
marginals, EVERY value of PNS permitted by the bounds is realized by an explicit
response distribution (a model `y = f(x, u)` with `u ⫫ x`) — so the interval IS
the identified set and its length is the identification width. Endpoint attainment
is the special case at the two ends. Pearl quantifies over "every joint
distribution `P(x, y)`"; under exogeneity PNS depends on `P(x, y)` only through
the conditionals `(P(y|x), P(y|x')) = (a, b)`, and `P(x)` is free, so the
marginal-pair quantification is the faithful reduction. -/
def T9_2_10 : Prop :=
  (∀ d : ResponseDist,
      max 0 (d.pY1 - d.pY0) ≤ d.pns ∧ d.pns ≤ min d.pY1 (1 - d.pY0)) ∧
  (∀ a b p : ℝ, 0 ≤ a → a ≤ 1 → 0 ≤ b → b ≤ 1 →
    max 0 (a - b) ≤ p → p ≤ min a (1 - b) →
    ∃ d : ResponseDist, d.pY1 = a ∧ d.pY0 = b ∧ d.pns = p)

/-- **T9_2_11 (PN/PS/PNS relations under exogeneity, Pearl eqs. (9.11)–(9.12)).**
Under exogeneity, `PN = PNS / P(y|x)` and `PS = PNS / P(y'|x')`, where under
exogeneity `P(y|x) = P(Y₁ = 1) = pY1` and `P(y'|x') = 1 - pY0` are the
experimental marginals of the treatment-marginalized law. This is the theorem
that licenses layer 1's reduced forms `ResponseDist.pn` / `ResponseDist.ps`. The
guards `0 < pxy`, `0 < pxy'` are the definedness conditions of the conditionals
(equivalently `P(x) > 0` and `P(y|x) > 0`, resp. `P(x') > 0` and `P(y'|x') > 0`).
The corresponding PN/PS bounds Pearl derives from (9.9) via (9.11)–(9.12) —
his (9.13) — are carried by `C9_2_12`, which asserts their sharpness. -/
def T9_2_11 : Prop :=
  ∀ j : XResponseDist, j.Exogenous →
    (0 < j.pxy → j.pn = j.toResponse.pns / j.toResponse.pY1) ∧
    (0 < j.pxy' → j.ps = j.toResponse.pns / (1 - j.toResponse.pY0))

/-- **T9_2_14 (Identifiability under Exogeneity and Monotonicity, Pearl
eqs. (9.21)–(9.23)).** Under monotonicity the identified interval collapses to a
point and all three quantities are identified from the experimental marginals:
PNS equals the risk difference `pY1 - pY0` (9.21); PN equals the excess risk
ratio `(pY1 - pY0) / pY1` (9.22), guarded by `0 < pY1`; PS equals
`(pY1 - pY0) / (1 - pY0)` (9.23), guarded by `pY0 < 1`. The PNS collapse is the
floor drop under regime (assumption-set) extension. -/
def T9_2_14 : Prop :=
  ∀ d : ResponseDist, d.MonotoneResponse →
    d.pns = d.pY1 - d.pY0 ∧
    (0 < d.pY1 → d.pn = (d.pY1 - d.pY0) / d.pY1) ∧
    (d.pY0 < 1 → d.ps = (d.pY1 - d.pY0) / (1 - d.pY0))

/-- **T9_2_15 (Identification under monotonicity plus identifiable effects, Pearl
eqs. (9.28)–(9.30)).** If `Y` is monotonic relative to `X` — NO exogeneity
assumed — then PNS, PN, PS are determined by the causal effects
`P(y_x) = toResponse.pY1`, `P(y_{x'}) = toResponse.pY0` together with the
observational quantities `P(y)`, `P(x, y)`, `P(x', y')`:
`PNS = P(y_x) - P(y_{x'})` (9.28); `PN = (P(y) - P(y_{x'})) / P(x, y)` (9.29);
`PS = (P(y_x) - P(y)) / P(x', y')` (9.30). Pearl's antecedent "whenever the
causal effects are identifiable" is a meta-level clause about estimating
`P(y_x), P(y_{x'})` from data; on this substrate those quantities are the
potential-outcome marginals, and the formalized content is the identity layer
that makes his claim true. Guards as in D9_2_1/D9_2_2. -/
def T9_2_15 : Prop :=
  ∀ j : XResponseDist, j.MonotoneResponse →
    j.pns = j.toResponse.pY1 - j.toResponse.pY0 ∧
    (0 < j.pxy → j.pn = (j.py - j.toResponse.pY0) / j.pxy) ∧
    (0 < j.pxy' → j.ps = (j.toResponse.pY1 - j.py) / j.pxy')

/-- **T9_4_2 (Local invertibility identifies counterfactuals).** -/
def T9_4_2 : Prop := ∀ _M : SCM.{u}, True

/-- **C9_2_12 (Nonidentifiability of PN from experimental effects alone, Pearl
eq. (9.14)).** For any experimental marginals `(a, b) = (P(y_x), P(y_{x'}))` with
`0 < a` and ANY point `p` of the PN interval
`[max 0 (a - b) / a, min a (1 - b) / a]` (Pearl's (9.13)/(9.14) under
exogeneity), there is a causal model — a response distribution, i.e. a model
`y = f(x, u)` with `u ⫫ x` — agreeing with those experimental effects whose PN
equals `p`. Hence experimental effects alone leave PN nonunique whenever the
interval is nondegenerate (e.g. `a = b = 1/2` yields the full interval `[0, 1]`):
the identification width is strictly positive without further assumptions. The
guard `0 < a` is the definedness condition of PN's denominator `P(y_x)`. -/
def C9_2_12 : Prop :=
  ∀ a b p : ℝ, 0 < a → a ≤ 1 → 0 ≤ b → b ≤ 1 →
    max 0 (a - b) / a ≤ p → p ≤ min a (1 - b) / a →
    ∃ d : ResponseDist, d.pY1 = a ∧ d.pY0 = b ∧ d.pn = p

/-- Auxiliary (NOT a DAG node; retained from the pre-review formalization as the
minimal-witness corollary of `C9_2_12` / `T9_2_10`-sharpness). Two response
distributions with identical experimental marginals and different PNS: the
marginals leave the counterfactual quantity nonunique — identification width
strictly positive without further assumptions (the G5 width interface). -/
def C9_2_12_pns_witness : Prop :=
  ∃ d₁ d₂ : ResponseDist,
    d₁.pY1 = d₂.pY1 ∧ d₁.pY0 = d₂.pY0 ∧ d₁.pns ≠ d₂.pns

end Causality.Pearl
