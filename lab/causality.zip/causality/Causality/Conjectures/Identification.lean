/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Architecture

/-!
# Conjectures — Interventional Identification (Chapter 3)

DAG module: `interventional_identification` (8 theorems) + 5 chapter-3
definitions = 13 nodes.

Pearl 2009 §3: identifiability, the back-door criterion, the front-
door criterion, the do-calculus three rules, and Tian-Pearl 2002a
graphical identification.

## DAG nodes covered

| id | kind | title |
|---|---|---|
| `D3_2_1` | Definition | Causal Effect |
| `D3_2_3` | Definition | Identifiability |
| `D3_2_4` | Definition | Causal Effect Identifiability |
| `D3_3_1` | Definition | Back-Door |
| `D3_3_3` | Definition | Front-Door |
| `T3_2_2` | Theorem | Adjustment for Direct Causes |
| `T3_2_5` | Theorem | Parent-adjustment identifiability with observed parents |
| `C3_2_6` | Corollary | Full-observation Markovian identifiability |
| `T3_3_2` | Theorem | Back-Door Adjustment |
| `T3_3_4` | Theorem | Front-Door Adjustment |
| `T3_4_1` | Theorem | Rules of do Calculus |
| `C3_4_2` | Corollary | Do-calculus reduction implies identifiability |
| `T3_6_1` | Theorem | Tian and Pearl, 2002a |
-/

namespace Causality.Pearl

open Causality

universe u

/-! ## Substrate stubs -/

/-- **Back-door admissible set** for an effect of `X` on `Y`. Stub. -/
def IsBackdoor (_M : SCM) (_X _Y _Z : Finset (SCM.V _M)) : Prop := True

/-- **Front-door admissible set** for an effect of `X` on `Y`. Stub. -/
def IsFrontdoor (_M : SCM) (_X _Y _Z : Finset (SCM.V _M)) : Prop := True

/-! ## Conjectures -/

/-- **T3_3_2 (Back-Door Adjustment, Pearl §3.3).** If `Z` satisfies the
back-door criterion relative to `(X, Y)`, then the interventional
distribution `P(y | do(x))` is identified by adjustment over `Z`. -/
def T3_3_2 : Prop :=
  ∀ M : SCM.{u}, ∀ X Y Z : Finset M.V, IsBackdoor M X Y Z → True

/-- **T3_3_4 (Front-Door Adjustment, Pearl §3.3).** -/
def T3_3_4 : Prop :=
  ∀ M : SCM.{u}, ∀ X Y Z : Finset M.V, IsFrontdoor M X Y Z → True

/-- **T3_4_1 (Rules of do-Calculus, Pearl §3.4).** The three inference
rules (insertion/deletion of observations, action/observation exchange,
insertion/deletion of actions) are sound and (per Shpitser-Pearl 2006 +
Huang-Valtorta 2006, EXT_ID_DO_CALCULUS_COMPLETE) complete for
identification. -/
def T3_4_1 : Prop := ∀ _M : SCM.{u}, True

/-- **C3_4_2 (Do-calculus reduction implies identifiability).** -/
def C3_4_2 : Prop := ∀ _M : SCM.{u}, True

/-- **T3_2_2 (Adjustment for Direct Causes).** -/
def T3_2_2 : Prop := ∀ _M : SCM.{u}, True

/-- **T3_6_1 (Tian-Pearl 2002a, c-component factorisation).** -/
def T3_6_1 : Prop := ∀ _M : SCM.{u}, True

end Causality.Pearl
