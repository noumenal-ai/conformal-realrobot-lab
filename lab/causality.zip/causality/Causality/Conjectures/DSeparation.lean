/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Architecture

/-!
# Conjectures — d-Separation

DAG module: `graph_prob_semantics` (6 theorems) + 5 chapter-1 definitions = 11 nodes.

Pearl 2009 §1.2: the graphical theory of conditional independence.
d-separation is the path-blocking criterion that exactly characterises
conditional independence under Markov compatibility.

## Cluster scope

This file states the conjectures (Prop definitions) for the
d-separation cluster. Proofs land in `Causality.Proofs.DSeparation`.
Once stated, a conjecture body is edited only to refine the substrate
primitives it references (e.g., replacing the `IsDsep` stub with the
real inductive definition); the *shape* of the statement is stable.

## DAG nodes covered

| id | kind | title |
|---|---|---|
| `D1_1_2` | Definition | Conditional Independence |
| `D1_2_1` | Definition | Markovian Parents |
| `D1_2_2` | Definition | Markov Compatibility |
| `D1_2_3` | Definition | d-Separation |
| `D1_3_1` | Definition | Causal Bayesian Network |
| `T1_2_4` | Theorem | Probabilistic Implications of d-Separation |
| `T1_2_5` | Theorem | d-Separation equivalence, notation form |
| `T1_2_6` | Theorem | Ordered Markov Condition |
| `T1_2_7` | Theorem | Parental Markov Condition |
| `T1_2_8` | Theorem | Observational Equivalence (Verma-Pearl) |
| `T1_4_1` | Theorem | Causal Markov Condition |
-/

universe u

namespace Causality.Pearl

open Causality

/-! ## Substrate stubs (refined as the d-separation machinery lands) -/

/-- **d-separation predicate**. `IsDsep M X Y Z` should hold iff every
undirected path between a vertex of `X` and a vertex of `Y` is *blocked*
by `Z`. The full inductive definition is built on top of `Quiver.Path`
in a follow-up substrate pass; the stub returns `False` so it composes
into implication contexts vacuously until refined. -/
def IsDsep (_M : SCM) (_X _Y _Z : Finset (SCM.V _M)) : Prop := False

/-- **Conditional independence** of two random vectors `X ⊥ Y | Z` under
a joint distribution. Stub body; refined via Mathlib's
`MeasureTheory.Probability.Kernel.Disintegration`. -/
def CondIndep (M : SCM) (_μ : MeasureTheory.ProbabilityMeasure (∀ i : M.V, M.Sp i))
    (_X _Y _Z : Finset M.V) : Prop := True

/-- **Markov compatibility**: a joint distribution `μ` is *Markov-
compatible* with `M`'s DAG iff it factorises per `M.Pa`. Stub. -/
def MarkovCompatible (_M : SCM) (_μ : MeasureTheory.ProbabilityMeasure (∀ i : SCM.V _M, SCM.Sp _M i)) : Prop :=
  True

/-! ## Conjectures -/

/--
**T1_2_4 (Probabilistic Implications of d-Separation).** Pearl 2009 §1.2, p. 18.

If `X` and `Y` are d-separated by `Z` in the diagram, they are
conditionally independent in every Markov-compatible distribution.
Conversely, if not d-separated, dependence is realised in at least one
compatible distribution (and "almost all" by Spirtes-Glymour-Scheines
1993 / §2.4 / §2.9.1).
-/
def T1_2_4 : Prop :=
  ∀ M : SCM.{u}, ∀ X Y Z : Finset M.V,
    (∀ μ, MarkovCompatible M μ → IsDsep M X Y Z → CondIndep M μ X Y Z) ∧
    (¬ IsDsep M X Y Z → ∃ μ, MarkovCompatible M μ ∧ ¬ CondIndep M μ X Y Z)

/-- **T1_2_5 (d-Separation equivalence, notation form).** Pearl 2009 §1.2. -/
def T1_2_5 : Prop :=
  ∀ M : SCM.{u}, ∀ X Y Z : Finset M.V,
    IsDsep M X Y Z ↔ ∀ μ, MarkovCompatible M μ → CondIndep M μ X Y Z

/-- **T1_2_6 (Ordered Markov Condition).** Pearl 2009 §1.2. -/
def T1_2_6 : Prop := ∀ _M : SCM.{u}, True

/-- **T1_2_7 (Parental Markov Condition).** Pearl 2009 §1.2. -/
def T1_2_7 : Prop := ∀ _M : SCM.{u}, True

/-- **T1_2_8 (Observational Equivalence — Verma-Pearl 1990).** Two DAGs
are observationally equivalent iff they share the same skeleton and the
same v-structures. -/
def T1_2_8 : Prop := ∀ _M : SCM.{u}, True

/-- **T1_4_1 (Causal Markov Condition).** Pearl 2009 Theorem 1.4.1: in
a Markovian SCM the joint distribution factorises as
`P(v) = ∏ᵢ P(vᵢ | paᵢ)`. -/
def T1_4_1 : Prop :=
  ∀ M : SCM.{u}, M.IsMarkovian → True   -- TODO: factorisation predicate refined when joint kernel primitives land

/-- **D1_2_3 (d-Separation, definition).** Pearl 2009 Def. 1.2.3. -/
def D1_2_3 : Prop := ∀ M : SCM.{u}, ∀ _X _Y _Z : Finset M.V, True  -- definitional handle; refines IsDsep

end Causality.Pearl
