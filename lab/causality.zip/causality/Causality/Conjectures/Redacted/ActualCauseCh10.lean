/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/

/-!
# Redacted — Pearl 2009 Chapter 10 Actual-Cause Material

DAG module: `actual_cause` (2 anchor nodes) + 7 chapter-10 definitions
= 9 nodes. **REDACTED from strict theorem-level formalization** per
the DAG's `redaction.redacted` audit flag and the DISCOVERY_URS A₁
commitment.

## Why redacted

The Pearl-2009 actual-cause definitions (sustenance, causal beam,
natural beam, contributory cause, probability of actual causation) and
the Halpern-Pearl 2005 actual-causation definition documented in
Chapter 10 are *open*: the literature (Halpern 2008, 2015, 2016;
Hitchcock 2007, 2017; Beckers-Vennekens 2018; Halpern-Hitchcock 2015)
shows the chapter-10 candidates fail on canonical examples
(forest-fire / disjunction, voting, late preemption, double prevention,
Bogus Prevention, …) and that no canonical post-HP definition is yet
agreed.

Per the URS we treat these nodes as *documentation only*: they are
preserved in this file as comments, not as Lean Prop definitions or
theorem statements. The corresponding *post-HP* material that we DO
formalize lives in `Modern/ActualCausationPostHP.lean` and reduces
the AC1/AC2/AC3 Halpern-Pearl 2005 conditions to additive Layer-B
content over Layer A.

## DAG nodes covered (commented-only)

| id | kind | title |
|---|---|---|
| `CA10_3_3_actual_cause` | DefinitionAnchor | Actual cause |
| `CA10_4_2_hp_actual_causation` | DefinitionAnchor | Actual causation (Halpern-Pearl 2005) |
| `D10_2_1` | Definition | Sustenance |
| `D10_3_1` | Definition | Causal Beam |
| `D10_3_2` | Definition | Natural Beam |
| `D10_3_3` | Definition | Actual Cause |
| `D10_3_4` | Definition | Contributory Cause |
| `D10_3_5` | Definition | Probability of Actual Causation |
| `D10_4_2` | Definition | Actual Causation (Halpern-Pearl 2005) |

These would, if undredacted, look like:

```
-- def CA10_3_3_actual_cause : Prop := ...
-- def CA10_4_2_hp_actual_causation : Prop := ...
-- def D10_2_1 : Prop := ...   -- sustenance
-- def D10_3_1 : Prop := ...   -- causal beam
-- def D10_3_2 : Prop := ...   -- natural beam
-- def D10_3_3 : Prop := ...   -- actual cause
-- def D10_3_4 : Prop := ...   -- contributory cause
-- def D10_3_5 : Prop := ...   -- probability of actual causation
-- def D10_4_2 : Prop := ...   -- HP 2005 actual causation
```

For the post-HP version we DO formalize, see
`Causality.Conjectures.Modern.ActualCausationPostHP`.
-/

-- This file declares no Lean entities; it is documentation only.
