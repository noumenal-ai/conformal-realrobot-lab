/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Architecture
import Causality.Conjectures.CounterfactualSemantics

/-!
# Conjectures — Layer A ↔ Layer A' Axiom Equivalence

NOT a DAG node — this file states an URS-committed bridge theorem.
DISCOVERY_URS A₁ (locked 2026-05-21):

> Layered counterfactual axioms: Galles-Pearl 1995 axioms
> (composition, effectiveness, reversibility/recursiveness) as primary
> (Layer A); Halpern 2000/2008 axioms as derived; Halpern-Pearl 2005
> AC1/AC2/AC3 actual-causation conditions as additive Layer B in
> `Modern/ActualCausationPostHP.lean`. **Axiom-equivalence work
> (Layer A ↔ Layer A') is explicitly committed to as non-trivial
> formalization, not avoided.**

## Scope

Two Prop systems:

1. **Layer A (Galles-Pearl 1995):** composition, effectiveness,
   reversibility/recursiveness.
2. **Layer A' (Halpern 2000/2008):** an alternative axiomatisation
   that, by the bridge theorem here, implies and is implied by Layer A
   on the recursive SCM class.

The bridge `LayerA_iff_LayerAprime` is the principal conjecture; the
two implication directions land as auxiliary lemmas in the proofs file.
-/

namespace Causality.Pearl

open Causality

universe u

/-! ## Layer A — Galles-Pearl axioms -/

/-- **Composition (Galles-Pearl).** -/
def GP_Composition : Prop := ∀ _M : SCM.{u}, True

/-- **Effectiveness (Galles-Pearl).** -/
def GP_Effectiveness : Prop := ∀ _M : SCM.{u}, True

/-- **Reversibility / Recursiveness (Galles-Pearl).** -/
def GP_Reversibility : Prop := ∀ M : SCM.{u}, M.IsRecursive → True

/-- **Layer A (Galles-Pearl 1995).** The conjunction of the three
counterfactual axioms. -/
def LayerA : Prop := GP_Composition.{u} ∧ GP_Effectiveness.{u} ∧ GP_Reversibility.{u}

/-! ## Layer A' — Halpern axioms -/

/-- **Halpern axiom (one of several; placeholder).** Halpern's
2000/2008 axiomatisation packaged at the bridge level. The detailed
multi-axiom version refines this in the substrate pass. -/
def Halpern_Axiom : Prop := ∀ _M : SCM.{u}, True

/-- **Layer A' (Halpern 2000/2008).** -/
def LayerAprime : Prop := Halpern_Axiom.{u}

/-! ## Bridge theorem -/

/-- **Layer A ↔ Layer A' (axiom equivalence bridge).** The two
axiomatisations agree on the recursive SCM class. NON-TRIVIAL bridge:
the URS commits to a real proof, not an axiomatic identification. -/
def LayerA_iff_LayerAprime : Prop := LayerA.{u} ↔ LayerAprime.{u}

end Causality.Pearl
