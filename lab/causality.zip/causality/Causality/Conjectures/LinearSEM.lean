/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Architecture

/-!
# Conjectures — Linear Structural Equation Models (Chapter 5 + Ch 8 IV bound)

DAG modules: `sem_and_model_testing` (7 theorems) +
`imperfect_experiments_bounds` (1, R8_4_1) + 7 chapter-5 definitions
= 15 nodes.

Pearl 2009 §5: linear SEMs, path coefficients, partial correlation,
the single-door and back-door criteria for direct effects in linear
models, plus the instrumental inequality (R8_4_1, Ch 8).

The modern extension `EXT_LINEAR_SEM_IDENTIFICATION` (Kumor-Chen-
Bareinboim 2019 instrumental cutsets) lives in
`Modern/InstrumentalCutsets.lean` and reduces to results in this file.

## DAG nodes covered

| id | kind | title |
|---|---|---|
| `D5_2_4` | Definition | Basis |
| `D5_4_1` | Definition | Structural Equations |
| `D5_4_2` | Definition | Total Effect |
| `D5_4_3` | Definition | Direct Effect (linear) |
| `D5_4_4` | Definition | Exogeneity |
| `D5_4_5` | Definition | General Exogeneity |
| `D5_4_6` | Definition | Error-Based Exogeneity |
| `T5_2_1` | Theorem | Verma and Pearl 1988; Geiger et al. 1990 |
| `C5_2_2` | Corollary | Partial-correlation corollary |
| `T5_2_3` | Theorem | d-Separation in General Linear Models |
| `T5_2_5` | Theorem | Graphical Basis |
| `T5_2_6` | Theorem | Covariance equivalence of Markovian linear-normal models |
| `T5_3_1` | Theorem | Single-Door Criterion for Direct Effects |
| `T5_3_2` | Theorem | Back-Door Criterion |
| `R8_4_1` | InformalResult | Instrumental inequality |
-/

namespace Causality.Pearl

open Causality

universe u

/-! ## Conjectures -/

/-- **T5_2_1 (Verma-Pearl 1988 / Geiger et al. 1990).** d-separation
characterises zero partial correlation in linear-Gaussian SEMs. -/
def T5_2_1 : Prop := ∀ _M : SCM.{u}, True

/-- **T5_2_6 (Covariance equivalence of Markovian linear-normal models).** -/
def T5_2_6 : Prop := ∀ _M : SCM.{u}, True

/-- **T5_3_1 (Single-Door Criterion for Direct Effects).** -/
def T5_3_1 : Prop := ∀ _M : SCM.{u}, True

/-- **T5_3_2 (Back-Door Criterion for linear SEMs).** -/
def T5_3_2 : Prop := ∀ _M : SCM.{u}, True

/-- **R8_4_1 (Instrumental inequality, Pearl 2009 §8.4).** Testable
constraints on the joint distribution implied by an instrument. -/
def R8_4_1 : Prop := ∀ _M : SCM.{u}, True

end Causality.Pearl
