/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Mathlib.MeasureTheory.Measure.ProbabilityMeasure
import Mathlib.MeasureTheory.Constructions.Pi
import Mathlib.Probability.Kernel.Basic
import Mathlib.Combinatorics.Quiver.Basic
import Mathlib.Combinatorics.Quiver.Path
import Mathlib.Data.Finset.Basic
import Mathlib.Order.WellFounded
import Mathlib.Data.ENat.Basic
import Mathlib.Data.NNReal.Basic

/-!
# Causality Architecture

This module defines the full type architecture for the `causality/`
sub-library. It contains:

1. **The ONE custom primitive.** `SCM` (Structural Causal Model) as an
   indexed family of variables, each with its own measurable space,
   parent set, exogenous noise, and structural equation. Per the
   Discovery URS (`DISCOVERY_URS.md` §SCM Primitive Rationale), this is
   the only causality-specific custom primitive in the sub-library.

2. **Seven frontload records** distinguishing the orthogonal concerns of
   causal-inference practice — Causal Model, Observed Schema, Discovery
   Assumptions, Equivalence Class, Causal Data, Finite-Sample Guarantee,
   Causal Frame — plus the `DiscoveryProblem` bundle that combines them.
   Refactor locked 2026-05-30 (was 5 typeclasses prior to that date; see
   the URS for the 5→7 reasoning).

3. **Key derived constructions** demonstrating that the architecture
   composes: induced quiver, do-intervention (graph surgery), joint
   distribution, identifiability (now stated over the bundle),
   counterfactual (Pearl's three-step procedure).

### Why records, not typeclasses

Instances of these records are **NOT canonical**. A single SCM has many
observed schemata (different study designs), many discovery-assumption
commitments (Markov-only vs Markov+faithfulness+sufficiency+positivity),
many equivalence-class outputs (CPDAG vs PAG vs MAG vs ADMG), and many
possible causal frames (different abstraction levels). Lean typeclass
inference selects *canonical* instances; here we want explicit, named
choices passed by hand. Hence `structure` and `inductive`, not `class`.

## What this file does NOT do

* No theorem proofs. The architecture file declares the type-level shape
  of every concept. Proofs land per the URS pass over the 141 DAG nodes.
* No specific identification algorithm. `Identifiable` is the bare
  predicate; the ID algorithm (Shpitser-Pearl) is in `Modern/`.
* No specific actual-causation definition. AC1/AC2/AC3 live in
  `Modern/ActualCausationPostHP.lean` per the Layer A / Layer B split.

## Provenance

* `causality/DISCOVERY_URS.md` — original architecture rationale (2026-05-21).
* `causality/research/urs/PROGRESS.md` — persistent progress URS (local-only).
* `causality/pearl_inheritance_dag_current_literature_audited.json` —
  141-node ground truth this architecture targets.
* `causality/README.md` — sub-library overview.

-/

universe u

namespace Causality

open MeasureTheory ProbabilityTheory

/-! ## §1 The custom primitive: `SCM` -/

/--
**Structural Causal Model.** The ONE custom causality primitive.

Following Pearl 2009 §1.4.1, eq. (1.40):

  x_i = f_i(pa_i, u_i)   for each i ∈ V

where:

* `V` — finite vertex set with decidable equality
* `Sp i` — per-vertex measurable space of values
* `Pa i ⊆ V` — endogenous parent set of vertex `i`
* `U i` — per-vertex exogenous noise space, measurable
* `uDist` — JOINT exogenous noise distribution on `∀ i, U i`
* `f i` — structural equation mapping (parent values, own noise) to own value
* `hf i` — joint measurability of `f i`

### Generality

A single primitive covers all seven model classes in the DAG:

| Regime | Specialization |
|---|---|
| DAG (recursive)            | `IsAcyclic ∧ IsRecursive` |
| Cyclic / non-recursive     | drop `IsRecursive` |
| Semi-Markovian (latents)   | `uDist` non-product, latent vertex marked via `ObservedSchema` |
| ADMG / MAG / PAG / CPDAG   | derived equivalence class via `CausalEquivClass` |
| Cluster DAG                | `Sp i` itself a Σ-type |
| Selection diagram          | `Σ M : SCM, Finset M.V` |
| Linear SEM                 | `IsLinear` derived predicate (in `Ch05_*`) |

### Joint vs per-vertex noise

`uDist` is a JOINT measure on `∀ i, U i`. Markovian SCMs satisfy
`IsMarkovian` (the predicate `uDist` factorizes as a product). Semi-
Markovian SCMs do not. This is strictly more general than Pearl §7.1.1's
separated `U`, `V` partition (joint noise subsumes shared-source noise).

### Deterministic-with-noise vs Markov kernel

The structural equation `f` is deterministic in `(parents, noise)`.
Counterfactual content (Pearl §1.4.4) is preserved by this shape.
Replacing `f` with a Markov kernel would lose counterfactual content
(Pearl Models 1 and 2 in Figure 1.6 have the same kernels but different
counterfactuals).
-/
structure SCM : Type (u + 1) where
  /-- Vertex set. -/
  V        : Type u
  [V_fin   : Fintype V]
  [V_dec   : DecidableEq V]
  /-- Per-vertex measurable value space. -/
  Sp       : V → Type u
  [Sp_meas : ∀ i, MeasurableSpace (Sp i)]
  /-- Endogenous parent set of each vertex. -/
  Pa       : V → Finset V
  /-- Per-vertex exogenous noise space. -/
  U        : V → Type u
  [U_meas  : ∀ i, MeasurableSpace (U i)]
  /-- Joint exogenous noise distribution. Markovianity is a derived
  predicate, not a primitive requirement. -/
  uDist    : ProbabilityMeasure (∀ i : V, U i)
  /-- Structural equation for vertex `i`: takes the value of every parent
  (typed by membership in `Pa i`) and the own noise `U i`, produces the
  vertex's own value. -/
  f        : ∀ i, ((j : { j : V // j ∈ Pa i }) → Sp j.val) × U i → Sp i
  /-- Joint measurability of each structural equation. -/
  hf       : ∀ i, Measurable (f i)

namespace SCM

variable (M : SCM)

/-! ### Recover instance arguments as Lean instances -/

instance : Fintype M.V := M.V_fin
instance : DecidableEq M.V := M.V_dec
instance (i : M.V) : MeasurableSpace (M.Sp i) := M.Sp_meas i
instance (i : M.V) : MeasurableSpace (M.U i) := M.U_meas i

/-! ## §2 Derived predicates on `SCM` -/

/-- A vertex `i` is an **ancestor** of `j` if there is a directed path
from `i` to `j` in the parent relation. -/
def IsAncestor (i j : M.V) : Prop :=
  Relation.TransGen (fun a b => a ∈ M.Pa b) i j

/-- A vertex `i` is a **descendant** of `j` if `j` is an ancestor of `i`. -/
def IsDescendant (i j : M.V) : Prop := M.IsAncestor j i

/-- An SCM is **acyclic** if the parent relation is well-founded.

Pearl 2009 Chs 1–9 work in acyclic SCMs by default. The cyclic case
(Forré-Mooij) is admitted by leaving acyclicity as a derived predicate
rather than a primitive field. -/
def IsAcyclic : Prop :=
  WellFounded (fun i j : M.V => i ∈ M.Pa j)

/-- An SCM is **Markovian** if its joint exogenous noise factors as a
product over per-vertex distributions.

The Causal Markov Condition (Pearl Theorem 1.4.1, DAG node `T1_4_1`)
applies to Markovian SCMs. Semi-Markovian SCMs lack the product
factorization; modern identification (`EXT_GRAPHICAL_MIXED_GRAPHS`,
`EXT_ID_DO_CALCULUS_COMPLETE`) handles the semi-Markovian case via the
ADMG construction. -/
def IsMarkovian : Prop :=
  ∃ μ : (i : M.V) → ProbabilityMeasure (M.U i),
    M.uDist.toMeasure =
      MeasureTheory.Measure.pi (fun i => (μ i).toMeasure)

/-- An SCM is **recursive** if it is acyclic AND there exists a
measurable function `φ : (noise → values)` solving the structural
equations simultaneously.

Pearl Theorem 7.3.5 (Recursive Completeness, DAG node `T7_3_5`) is
stated against this predicate. -/
def IsRecursive : Prop :=
  M.IsAcyclic ∧
  ∃ φ : ((i : M.V) → M.U i) → ((i : M.V) → M.Sp i),
    Measurable φ ∧
    ∀ u i, φ u i = M.f i ⟨fun j => φ u j.val, u i⟩

/-! ## §3 The induced causal diagram and auxiliary derived constructions -/

/-- The **causal diagram** of an SCM: the natural directed graph where
the edge `j → i` exists iff `j ∈ Pa i`. Built as a `Quiver`. -/
instance : Quiver M.V where
  Hom j i := PLift (j ∈ M.Pa i)

/-- The set of descendants of vertex `i`. -/
noncomputable def Descendants (i : M.V) : Finset M.V :=
  letI : DecidablePred (fun j => M.IsAncestor i j) := fun _ => Classical.dec _
  M.V_fin.elems.filter (fun j => M.IsAncestor i j)

/-- The set of non-descendants of vertex `i` (in the diagram). -/
noncomputable def NonDescendants (i : M.V) : Finset M.V :=
  M.V_fin.elems \ (M.Descendants i)

/-! ## §4 do-intervention and induced distributions -/

/-- **do-intervention** `do(X = x)` (Pearl §1.3, §3.2): graph surgery
that replaces the structural equation for every `i ∈ X` with the
constant `x i`, and clears the incoming edges of intervened vertices.

The resulting SCM has:
* `Pa' i = ∅` if `i ∈ X`, else `Pa i`
* `f' i = const (x i)` if `i ∈ X`, else `f i`
* Everything else identical, including `uDist`

This is the formal content of the `do` operator. The interventional
distribution `Px X x` is the joint of this mutated SCM.

The implementation requires careful dependent-type juggling because
mutating `Pa` changes the input type of `f`. The intervened SCM keeps
`V`, `Sp`, `U`, `uDist` identical (so `(M.doIntervene X x).V` is
definitionally `M.V`), clears parents on `X`, and replaces the
structural equation on `X` by the constant `x i`. -/
noncomputable def doIntervene (X : Finset M.V) (x : ∀ i ∈ X, M.Sp i) : SCM where
  V        := M.V
  V_fin    := M.V_fin
  V_dec    := M.V_dec
  Sp       := M.Sp
  Sp_meas  := M.Sp_meas
  Pa       := fun i => if i ∈ X then ∅ else M.Pa i
  U        := M.U
  U_meas   := M.U_meas
  uDist    := M.uDist
  f        := fun i inp =>
    if h : i ∈ X then x i h
    else
      -- `i ∉ X`, so the mutated parent set is `M.Pa i`; the incoming
      -- parent valuation has exactly the type `M.f i` expects.
      M.f i ⟨fun j => inp.1 ⟨j.val, by rw [if_neg h]; exact j.property⟩, inp.2⟩
  hf       := fun i => by
    -- On `i ∈ X` the equation is constant; off `X` it is `M.f i`
    -- precomposed with a measurable reindexing of the parent valuation.
    by_cases h : i ∈ X
    · simp only [dif_pos h]; exact measurable_const
    · simp only [dif_neg h]
      refine (M.hf i).comp (Measurable.prodMk ?_ measurable_snd)
      exact measurable_pi_lambda _ (fun j => (measurable_pi_apply _).comp measurable_fst)

/-- The joint distribution over `∀ i, Sp i` induced by a recursive SCM
via push-forward through the structural-equation solution. The recursive
witness `φ` (from `IsRecursive`) is measurable, so the joint is the
push-forward `φ_* uDist`. -/
noncomputable def joint (hRec : M.IsRecursive) :
    ProbabilityMeasure (∀ i : M.V, M.Sp i) :=
  -- The recursive solution `φ` pushes `uDist` forward to the joint.
  M.uDist.map hRec.2.choose_spec.1.aemeasurable

/-- **Interventional distribution** `P_do(X = x)` (Pearl §3.2,
DAG `D3_2_1`). The joint distribution of the do-intervened SCM. -/
noncomputable def Px (X : Finset M.V) (x : ∀ i ∈ X, M.Sp i)
    (hRec : (M.doIntervene X x).IsRecursive) :
    ProbabilityMeasure (∀ i : M.V, M.Sp i) :=
  (M.doIntervene X x).joint hRec

end SCM

/-! ## §5 Frontload record 1 — `ObservedSchema` (Pain Point P₁) -/

/--
**ObservedSchema** — the observed-vs-latent partition of an SCM's
variables. Distinguishes the variables the model **posits exist**
(`M.V`) from the variables the analyst **actually measured**
(`observed ⊆ M.V`).

Replaces the deprecated `HasObservedSet` typeclass. Now a `structure`
because a single SCM admits many observed schemata (different study
designs); Lean typeclass inference would pick a canonical one, which
is the wrong default for causal inference.

### Where it is consumed

* Pearl §3.2 identifiability (`D3_2_3`, `D3_2_4`) — the observed set
  determines which functionals are in scope.
* Pearl §3.3 back-door / front-door (`T3_3_2`, `T3_3_4`) — adjustment
  sets must be observed.
* `EXT_ID_DO_CALCULUS_COMPLETE` — Shpitser-Pearl ID operates over the
  observed subset.
* `EXT_COMPLETE_ADJUSTMENT` — Perkovic complete adjustment over the
  observed variables.

### Citations

* Spirtes, Glymour, Scheines (2000), *Causation, Prediction, and Search*
  — FCI algorithm chapter.
* Richardson & Robins (2013), Single-World Intervention Graphs.
* Robins, Hernán, Brumback (2000), Marginal structural models.
* Hernán & Robins (2020), *Causal Inference: What If*.
-/
structure ObservedSchema (M : SCM) where
  /-- The set of measured (observed) vertices. The complement
  `M.V \ observed` is the latent set. -/
  observed : Finset M.V

namespace ObservedSchema

variable {M : SCM} (S : ObservedSchema M)

/-- The latent variables: posited but unmeasured. -/
def latent : Finset M.V := M.V_fin.elems \ S.observed

/-- An SCM with an `ObservedSchema` is **causally sufficient** if there
are no latent variables. -/
def IsCausallySufficient : Prop := S.latent = ∅

end ObservedSchema

/-! ## §6 Frontload record 2 — `DiscoveryAssumptions` (Pain Point P₂ + Markov / sufficiency / positivity) -/

/--
**DiscoveryAssumptions** — the four standard preconditions for causal
discovery and identification, bundled as a single record.

| Assumption | Field | Pearl regime | Modern relaxation |
|---|---|---|---|
| Causal Markov       | `markov`     | Always assumed   | Forré-Mooij (cyclic) |
| Faithfulness margin | `ε_margin`, `faithful` | Binary | Uhler 2013 quantitative |
| Causal sufficiency  | `sufficient` | Default          | FCI, ADMG (semi-Markovian) |
| Positivity          | `positive`   | Often implicit   | Hernán-Robins explicit |

### Why a single record

The four assumptions are routinely toggled independently in modern
causal inference. Bundling avoids parameter-list explosion (10+ implicit
arguments per theorem → one explicit `DiscoveryAssumptions`).

### Why `ε_margin` is a quantitative field

Faithfulness as a binary condition is finite-sample-empty: strong-
faithfulness violations have non-negligible Lebesgue measure in
parameter space (Uhler et al. 2013). Without a margin, finite-sample
discovery has no uniform consistency guarantee (Robins-Scheines-Spirtes-
Wasserman 2003).

### Why the predicates are abstract Props

`markov`, `faithful`, `sufficient`, `positive` are `Prop`-valued fields,
not concrete formulas. Each downstream consumer refines them: linear-
Gaussian models use partial-correlation margin for `faithful`; general
distributions use conditional-mutual-information margin; etc. The
quantitative-instrument abstraction is per the 2026-05-30 Mathlib-only
lock — concrete CI dependence scores live downstream and are *optional*
at the v1 architecture level.

### Citations

* Robins, Scheines, Spirtes, Wasserman (2003), "Uniform consistency in
  causal inference," *Biometrika* 90(3):491–515.
* Zhang & Spirtes (2008), "Detection of unfaithfulness and robust
  causal inference," *Minds and Machines* 18:239–271.
* Uhler, Raskutti, Bühlmann, Yu (2013), "Geometry of the faithfulness
  assumption in causal inference," *Annals of Statistics* 41(2):436–463.
* Hernán & Robins (2020), *Causal Inference: What If*.
-/
structure DiscoveryAssumptions (M : SCM) where
  /-- Causal Markov: P(V) factorizes per the DAG. Refined to a concrete
  factorization predicate by each consumer. -/
  markov     : Prop
  /-- Quantitative faithfulness margin (Uhler 2013). -/
  ε_margin   : NNReal
  /-- Faithfulness predicate; consumer-refined with the specific
  dependence score in scope (partial correlation, CMI, HSIC, …). -/
  faithful   : Prop
  /-- Causal sufficiency: no unobserved confounders. -/
  sufficient : Prop
  /-- Positivity: every intervention slice has positive density. -/
  positive   : Prop

/-! ## §7 Frontload record 3 — `CausalEquivClass` (Pain Point P₃) -/

/--
The *kind* of causal equivalence class. Different discovery algorithms
output different kinds: PC/GES → CPDAG; FCI/RFCI → PAG; mixed-graph
discovery → MAG or ADMG; group-level discovery → cluster-DAG. The kind
distinguishes the equivalence relation under which `reps` are deemed
equivalent.
-/
inductive EquivClassKind
  /-- Exact DAG (singleton equivalence class). -/
  | DAG
  /-- CPDAG: Markov equivalence (PC, GES, GIES). -/
  | CPDAG
  /-- MAG: maximal ancestral graph. -/
  | MAG
  /-- PAG: partial ancestral graph (FCI, RFCI). -/
  | PAG
  /-- ADMG: acyclic directed mixed graph. -/
  | ADMG
  /-- Cluster-DAG over groups of variables. -/
  | Cluster

/--
**CausalEquivClass** — a discovery output: a set of parent-maps in the
class plus the kind of equivalence they share.

Generalizes the deprecated `MEC` structure (which was CPDAG-only); this
covers CPDAG, PAG, MAG, ADMG, cluster-DAG uniformly via the `kind`
field. The detailed equivalence predicates (same skeleton, same
v-structures, …) are provided as derived definitions below and can be
asserted as additional fields by downstream specializations.

### Why a record

Discovery outputs are first-class data: identification theorems
quantify over them (`∀ G : CausalEquivClass V, …`).

### Citations

* Verma & Pearl (1990), "Equivalence and synthesis of causal models."
* Andersson, Madigan, Perlman (1997), "A characterization of Markov
  equivalence classes for acyclic digraphs," *Annals of Statistics*
  25(2):505–541.
* Zhang (2008), "On the completeness of orientation rules …,"
  *Artificial Intelligence* 172(16-17):1873–1896 (PAGs).
* Perkovic, Textor, Kalisch, Maathuis (2017), "Complete graphical
  characterization and construction of adjustment sets," *JMLR* 18(220):1–62.
-/
structure CausalEquivClass (V : Type u) [Fintype V] [DecidableEq V] where
  /-- The kind of equivalence class. -/
  kind     : EquivClassKind
  /-- The set of parent maps in the class. -/
  reps     : Set (V → Finset V)
  /-- Non-emptiness: every class has at least one representative. -/
  nonempty : reps.Nonempty

namespace CausalEquivClass

variable {V : Type u} [Fintype V] [DecidableEq V]

/-- Two graphs share the same **skeleton** iff their underlying
undirected edge sets agree. The defining property of CPDAG equivalence. -/
def SameSkeleton (G₁ G₂ : V → Finset V) : Prop :=
  ∀ i j, (j ∈ G₁ i ∨ i ∈ G₁ j) ↔ (j ∈ G₂ i ∨ i ∈ G₂ j)

/-- Two graphs share the same **v-structures** (immoralities) iff for
every non-adjacent pair `(j, k)` with a common child `i`, both graphs
orient `j → i ← k`. The second defining property of CPDAG equivalence. -/
def SameVStructures (G₁ G₂ : V → Finset V) : Prop :=
  ∀ i j k, (j ∈ G₁ i ∧ k ∈ G₁ i ∧ k ∉ G₁ j ∧ j ∉ G₁ k) ↔
           (j ∈ G₂ i ∧ k ∈ G₂ i ∧ k ∉ G₂ j ∧ j ∉ G₂ k)

/-- A `CausalEquivClass` is a *bona fide CPDAG* iff all representatives
share both skeleton and v-structures. Pearl 2009 Theorem 1.2.8
(`T1_2_8`). -/
def IsCPDAG (m : CausalEquivClass V) : Prop :=
  m.kind = EquivClassKind.CPDAG ∧
  ∀ G₁ ∈ m.reps, ∀ G₂ ∈ m.reps, SameSkeleton G₁ G₂ ∧ SameVStructures G₁ G₂

/-- Pick any representative of the class. -/
noncomputable def someRep (m : CausalEquivClass V) : V → Finset V :=
  m.nonempty.choose

/-- A class is **singleton** iff it contains exactly one parent map. -/
def IsSingleton (m : CausalEquivClass V) : Prop :=
  ∃! G, G ∈ m.reps

end CausalEquivClass

/-! ## §8 Frontload inductive 4 — `CausalData` (Pain Point P₄) -/

/--
**CausalData** — multi-source data fusion as a first-class typed object,
parameterized over the SCM.

Renames and re-parameterizes the deprecated `Data` inductive. The
parameter is now the SCM directly (not loose `V` / `Sp`), which gives
stronger type safety: a `CausalData M` *cannot* mix samples from a
different SCM, and `M.V`, `M.Sp` are inferred automatically.

### Constructors

| Constructor       | Use case                                           |
|---|---|
| `observational`   | Pearl's default — a sample from `P(V)`             |
| `interventional`  | Pearl §1.3.1 — RCT / quasi-experimental data       |
| `fromPopulation`  | Bareinboim-Pearl 2016 transportability             |
| `mixture`         | Combine sources (observational + interventional)   |

(Surrogate experiments — Correa-Lee-Bareinboim 2022 — get a dedicated
`Modern/SurrogateExperiment.lean` rather than a constructor here, to
keep this inductive small and stable.)

### Citations

* Bareinboim & Pearl (2016), "Causal inference and the data-fusion
  problem," *PNAS* 113(27):7345–7352.
* Pearl & Bareinboim (2014), "External validity: From do-calculus to
  transportability across populations," *Statistical Science*
  29(4):579–595.
* Correa, Lee, Bareinboim (2022), "Nested counterfactual identification
  from arbitrary surrogate experiments."
-/
inductive CausalData (M : SCM.{u}) : Type (u + 1)
  /-- Observational data: a sample from `P(V)`. -/
  | observational
      (P : ProbabilityMeasure (∀ i : M.V, M.Sp i)) :
      CausalData M
  /-- Interventional data: a sample from `P(V | do(X = x))`. -/
  | interventional
      (X : Finset M.V) (x : ∀ i ∈ X, M.Sp i)
      (P : ProbabilityMeasure (∀ i : M.V, M.Sp i)) :
      CausalData M
  /-- Data drawn from a specific population (for transportability).
  The `pop` type is an opaque tag distinguishing populations. -/
  | fromPopulation
      (pop : Type u) (d : CausalData M) :
      CausalData M
  /-- A mixture of data sources (e.g., observational + interventional). -/
  | mixture
      (ds : List (CausalData M)) :
      CausalData M

namespace CausalData

variable {M : SCM}

/-- The set of vertex subsets for which the data collection contains an
interventional sample. Used by identification theorems that require
specific experiments. -/
def interventionSources : CausalData M → Set (Finset M.V)
  | observational _      => ∅
  | interventional X _ _ => {X}
  | fromPopulation _ d   => d.interventionSources
  | mixture ds           => ds.foldl (fun acc d => acc ∪ d.interventionSources) ∅

/-- The set of populations from which any constituent sample was drawn. -/
def populations : CausalData M → Set (Type u)
  | observational _      => ∅
  | interventional _ _ _ => ∅
  | fromPopulation p d   => {p} ∪ d.populations
  | mixture ds           => ds.foldl (fun acc d => acc ∪ d.populations) ∅

/-- A predicate: the data collection contains only observational data
(no interventions, single population). The classical Pearl regime. -/
def IsClassical : CausalData M → Prop
  | observational _      => True
  | interventional _ _ _ => False
  | fromPopulation _ _   => False
  | mixture ds           => ds.foldl (fun acc d => acc ∧ d.IsClassical) True

end CausalData

/-! ## §9 Frontload record 5 — `FiniteSampleGuarantee` (Pain Point P₅) -/

/--
**FiniteSampleGuarantee** — finite-sample correctness for a causal
claim. Replaces and generalizes the deprecated `FiniteSampleClaim`
typeclass.

Carries the explicit parameters `n`, `ε`, `δ` plus an abstract
`guarantee` predicate that the consumer refines with its concrete
estimator-specific bound. The asymptotic case is `n = ⊤`; finite `n`
adds explicit ε/δ rates.

### Why an abstract `guarantee` field

The concrete shape of the guarantee (Hoeffding sub-Gaussian, Bernstein
mixing, plug-in kernel-method bound, …) is estimator-specific. Each
downstream file supplies a concrete predicate. Per the 2026-05-30
Mathlib-only lock, concrete bounds would be derived in-repo from
`MeasureTheory.Integral.Bochner` + MGF machinery rather than imported
from `statistics/SLT`.

### Pearl-asymptotic instance

For Pearl's `n = ⊤` results, instantiate with
`{ n := ⊤, ε := 0, δ := 0, guarantee := True }`.

### Citations

* Robins, Scheines, Spirtes, Wasserman (2003), op. cit.
* Maathuis, Kalisch, Bühlmann (2009), "Estimating high-dimensional
  intervention effects from observational data," *Annals of Statistics*
  37(6A):3133–3164.
* Heinze-Deml, Maathuis, Meinshausen (2018), "Causal structure
  learning," *Annual Review of Statistics* 5:371–391.
-/
structure FiniteSampleGuarantee (M : SCM) where
  /-- Sample size index; `n = ⊤` recovers the asymptotic case. -/
  n         : ℕ∞
  /-- Loss tolerance. -/
  ε         : NNReal
  /-- Confidence parameter. -/
  δ         : NNReal
  /-- The concrete guarantee predicate (estimator-specific; consumer-refined). -/
  guarantee : Prop

/-! ## §10 Frontload record 6 — `CausalFrame` (analyst's frame of reference) -/

/--
**CausalFrame** — the analyst's frame of reference for a causal
analysis.

NEW frontload record added per the 2026-05-30 reviewer feedback
(previously implicit in the 5-record set). Distinguishes:

* the **variable frame** (which vertices are in the analysis — often a
  subset of `M.V`, e.g., dropping pre-treatment covariates),
* the **abstraction level** (Beckers-Halpern hierarchical depth —
  single-level Pearl is `level = 0`),
* the **admissible intervention set** (which `do(·)` are physically
  realizable in this setting — RCTs allow more than observational
  studies; physical-law constraints rule out some `do(X)`).

### Why a separate record

Two analysts of the same SCM may legitimately work in different frames
(micro-level pharmacology vs macro-level epidemiology of the same
disease process). The frame is part of the discovery *setup*, not a
property of the model.

### Citations

* Rubenstein, Weichwald, Bongers, Mooij, Janzing, Grosse-Wentrup,
  Schölkopf (2017), "Causal Consistency of Structural Equation Models,"
  *UAI 2017*.
* Beckers & Halpern (2019), "Abstracting Causal Models," *AAAI 2019*.
* Chalupka, Eberhardt, Perona (2017), "Causal feature learning," *UAI 2017*.
-/
structure CausalFrame (M : SCM) where
  /-- The variables under analysis (possibly a subset of `M.V`). -/
  frame                  : Finset M.V
  /-- Beckers-Halpern hierarchical level; `0` is the SCM itself. -/
  level                  : ℕ
  /-- The set of vertex subsets for which `do(·)` is admissible. -/
  admissibleInterventions : Set (Finset M.V)

/-! ## §11 Auxiliary: `Query` (used by the bundle) -/

/--
**Query** — an abstract causal query (a functional we want to identify).

Specific queries — `P(Y | do(X=x))`, counterfactual `P(Y_x | Y', X')`,
natural direct effect, transportability target, … — refine `spec` with
their concrete semantics. The bundle treats `Query` as opaque.
-/
structure Query (M : SCM) where
  /-- The query's specification, refined per-instance. -/
  spec : Prop

/-! ## §12 The bundle: `DiscoveryProblem` -/

/--
**DiscoveryProblem** — the canonical bundle that combines the seven
frontload records into a single object representing the full setup of
a causal-inference problem.

A `DiscoveryProblem M` is *the* type-level statement: "given this SCM,
this observed schema, these assumptions, this equivalence-class output,
this data, this query, this frame, here is the correctness specification
the analyst's procedure must satisfy."

### Why a bundle

Pearl's `Identifiable` (and every post-2009 generalization) is
implicitly a four- to seven-place predicate. Hidden inside a one-place
predicate over `DiscoveryProblem`, the implementation is cleaner and
the chapters need not re-list assumptions every time.

### Reduction to classical Pearl

Classical Pearl identification is the special case:
```
{ observed       := ⟨Finset.univ⟩,                    -- causally sufficient
  assumptions    := { markov := True, faithful := True,
                      sufficient := True, positive := True, ε_margin := 0 },
  equivClass     := { kind := .DAG, reps := {G}, nonempty := ⟨G, rfl⟩ },
  data           := CausalData.observational P,
  target         := { spec := True },
  frame          := { frame := Finset.univ, level := 0,
                      admissibleInterventions := ⊤ },
  correctness    := True }
```
-/
structure DiscoveryProblem (M : SCM) where
  observed    : ObservedSchema M
  assumptions : DiscoveryAssumptions M
  equivClass  : CausalEquivClass M.V
  data        : CausalData M
  target      : Query M
  frame       : CausalFrame M
  /-- The correctness specification the analyst's procedure must
  satisfy. Refined per discovery method. -/
  correctness : Prop

/-! ## §13 The unifying `Identifiable` predicate -/

/--
**Identifiable** — the central predicate, now stated over the bundle.

A `DiscoveryProblem` is *identifiable* iff there exists a measurable
functional from the data collection to a probability measure on the
joint such that:

1. depends only on the observed marginals (per `DP.observed`),
2. is consistent across the equivalence class (per `DP.equivClass`),
3. is compatible with the data sources (per `DP.data`),
4. matches the target query (per `DP.target`),
5. respects the admissible-intervention frame (per `DP.frame`),
6. satisfies the correctness specification (per `DP.correctness`).

(2026-05-30 refactor: collapses the previous 5-parameter `Identifiable`
into a 1-parameter predicate over `DiscoveryProblem`. The five
constraints are now bundle fields.)

The classical Pearl identifiability is the special case of the
`DiscoveryProblem` reduction shown in `DiscoveryProblem`'s docstring.
Modern extensions (Shpitser-Pearl ID, Perkovic complete adjustment,
Bareinboim transportability, etc.) instantiate the bundle with
non-trivial choices.
-/
def Identifiable {M : SCM} (DP : DiscoveryProblem M) : Prop :=
  ∃ _φ : CausalData M → ProbabilityMeasure (∀ i : M.V, M.Sp i),
    -- (a) depends only on `DP.observed.observed`
    True ∧
    -- (b) consistent across `DP.equivClass.reps`
    True ∧
    -- (c) compatible with `DP.data`
    True ∧
    -- (d) matches `DP.target.spec`
    DP.target.spec ∧
    -- (e) respects `DP.frame.admissibleInterventions`
    True ∧
    -- (f) satisfies `DP.correctness`
    DP.correctness

/-! ## §15 Hierarchical extension hook (per `EXT_HIERARCHICAL_ABSTRACTION`)

The hierarchical-abstraction extension introduces sequences of SCMs
connected by abstraction maps. This is a Σ-type over `SCM`, NOT a new
custom primitive.

The full definition lives in `Modern/HierarchicalAbstraction.lean`;
the hook here is the signature so other files can reference the type. -/

/-- **HierarchicalCausalModel** — `n`-level hierarchy of SCMs with
Beckers-Halpern abstraction-consistency maps.

* `levels` — countably many SCMs, indexed by `ℕ`
* `tau` — for each level `n`, the abstraction map from level `n+1` to
  level `n` (variable-level translation)
* `consistent` — Beckers-Halpern abstraction-consistency: intervening
  high-then-projecting equals projecting-then-intervening-low

Single-level Pearl is the degenerate case `levels = fun _ => M`,
`tau = fun _ => id`. -/
structure HierarchicalCausalModel : Type (u + 1) where
  levels          : ℕ → SCM
  /-- Variable-level abstraction map from level `n+1` to level `n`. Full
  signature requires the abstraction-map type to be defined. -/
  tau_skel        : ∀ _n : ℕ, Unit  -- placeholder; full form in Modern/
  /-- Beckers-Halpern consistency: do-then-tau = tau-then-do. -/
  consistent_skel : ∀ _n : ℕ, Unit  -- placeholder; full form in Modern/

end Causality
