/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Constructive.Mech
import Causality.Constructive.RatPMF
import Mathlib.Data.Fintype.Pi

/-!
# The first executed SCM witness (contrast pair)

A three-node mechanism skeleton, literally executed: `parityMech` couples node 2 to
its parents (`X₂ = X₀ + X₁` in `Fin 2`); `freeMech` reads fresh noise instead. The
executable joint (`RatPMF.map` through `solve`), its support, and the inline
rectangularity defect are computed by `#eval` and certified by `decide` — kernel
proofs that ARE executions. Contrast pair per the witness discipline: the coupled
model exhibits defect 4, the free model defect 0.

Scope lock: the defect here is computed inline (hull card minus support card); its
identification with `measurements`' `hcCombPi` happens at the Phase-B bridge (the
causality leaf-lock forbids that import here).
-/

namespace Causality.Constructive.Witness

open Causality.Constructive

/-- Coupled skeleton: `X₀ = U₀`, `X₁ = X₀ + U₁`, `X₂ = X₀ + X₁`. -/
def parityMech : Mech where
  V := Fin 3
  Sp := fun _ => Fin 2
  Pa := fun i => match i with | 0 => ∅ | 1 => {0} | 2 => {0, 1}
  U := fun _ => Fin 2
  f := fun i => match i with
    | 0 => fun inp => inp.2
    | 1 => fun inp => inp.1 ⟨0, by decide⟩ + inp.2
    | 2 => fun inp => inp.1 ⟨0, by decide⟩ + inp.1 ⟨1, by decide⟩

/-- Free skeleton: same graph minus the coupling — `X₂ = U₂`. -/
def freeMech : Mech where
  V := Fin 3
  Sp := fun _ => Fin 2
  Pa := fun i => match i with | 0 => ∅ | 1 => {0} | 2 => ∅
  U := fun _ => Fin 2
  f := fun i => match i with
    | 0 => fun inp => inp.2
    | 1 => fun inp => inp.1 ⟨0, by decide⟩ + inp.2
    | 2 => fun inp => inp.2

/-- The shared rank witness (both graphs descend along `0 → 1 → 2`). -/
def rk : Mech.Rank parityMech := ⟨fun i => i.val, by decide⟩
def rkF : Mech.Rank freeMech := ⟨fun i => i.val, by decide⟩

/-- Uniform executable noise on `(Fin 2)³`. -/
def noise : RatPMF (Fin 3 → Fin 2) :=
  RatPMF.uniform Finset.univ Finset.univ_nonempty

/-- The executable joint: noise pushed through the constructed solution. -/
def jointP : RatPMF (Fin 3 → Fin 2) := noise.map (fun (u : Fin 3 → Fin 2) i => rk.solve u i)
def jointF : RatPMF (Fin 3 → Fin 2) := noise.map (fun (u : Fin 3 → Fin 2) i => rkF.solve u i)

/-- Inline support-defect: hull (product of coordinate projections) minus support. -/
def defect (p : RatPMF (Fin 3 → Fin 2)) : ℕ :=
  (Fintype.piFinset (fun i => p.support.image (fun g => g i))).card - p.support.card

#eval jointP.support.card  -- expect 4
#eval jointF.support.card  -- expect 8
#eval defect jointP        -- expect 4
#eval defect jointF        -- expect 0

/-! Boundary discovered while landing this file: ℚ-valued (distribution-level) facts
are ⟨exec⟩-witnessable (compiled `#eval`) but hit the kernel's Rat-reduction wall
under `decide`; support-level facts are fully ⟨decide⟩-certifiable. The
support↔distribution split, reappearing at the witness layer. -/

/-- Support computed mechanism-side (ℚ-free): the image of the solution operator
over all noise configurations. -/
def suppP : Finset (Fin 3 → Fin 2) := Finset.univ.image (fun (u : Fin 3 → Fin 2) => fun i => rk.solve u i)
def suppF : Finset (Fin 3 → Fin 2) := Finset.univ.image (fun (u : Fin 3 → Fin 2) => fun i => rkF.solve u i)

/-- Inline support-defect on a bare support. -/
def defectS (s : Finset (Fin 3 → Fin 2)) : ℕ :=
  (Fintype.piFinset (fun i => s.image (fun g => g i))).card - s.card

/-- ⟨decide⟩ witness, coupled member: the executed parity skeleton has support 4
inside a full hull — defect 4. A kernel proof that IS an execution. -/
theorem parity_defect_executed : defectS suppP = 4 := by decide

/-- ⟨decide⟩ witness, contrast member: cutting the mechanism coupling drives the
executed defect to zero. -/
theorem free_defect_executed : defectS suppF = 0 := by decide

end Causality.Constructive.Witness
