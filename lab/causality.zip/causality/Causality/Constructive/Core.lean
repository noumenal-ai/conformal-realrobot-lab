/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Architecture

/-!
# The constructive core: SCM solution theory without choice

The constructive rederivation of the SCM's solution theory. `Causality.Architecture`
follows Pearl in treating recursiveness as an *existence* (`IsRecursive` asserts `∃ φ`)
and extracts the solution — hence the joint distribution — by `Classical.choice`
(`joint` uses `hRec.2.choose`). Constructively that is inadmissible: the graph `G`
cannot be waved away by a choice-style assumption. This file replaces the existential
with **data**:

* `Rank M` — the constructive articulation of "G is a DAG": a rank function on the
  vertices under which every parent strictly descends. This is the object Pearl's
  "assume the model is recursive" hides.
* `Rank.solve` — the solution operator, an explicit recursion on the rank witness
  (structural recursion on `Acc`, no choice).
* `Rank.solve_spec` — the fixed-point equation: `solve` genuinely solves the
  structural equations (Pearl's eq. 1.40, made a theorem about a constructed object).
* `Rank.solve_unique` — uniqueness: *any* pointwise solution agrees with `solve`;
  hence the classical `choose`-extracted solution is the constructed one.
* `Rank.measurable_solve` — measurability of the solution operator, by rank induction.
* `Rank.isRecursive` — the classical predicate `IsRecursive` is *discharged* by the
  witness: existence is a corollary of construction, never an axiom.
* `Rank.jointC` — the joint distribution as a pushforward through the constructed
  solution: choice-free where `Architecture.joint` is choice-extracted.
* `Rank.jointC_eq_joint` — the bridge: the classical joint (any `choose`-extraction)
  EQUALS the constructive one. The choice in `Architecture` is eliminable.
* `Rank.doIntervene` — surgery preserves the rank witness (parents only shrink), so
  interventional solution theory is constructive with the SAME rank: `PxC`.

The classical/constructive boundary, stated honestly: `Rank M → M.IsAcyclic` is a
theorem (`Rank.isAcyclic`); the converse `IsAcyclic → Rank` requires extracting ranks
from a wellfoundedness Prop and is deliberately NOT taken as primitive — on finite
`V` it is realizable by decidable search, a scheduled construction at the boundary,
not an assumption.
-/

universe u

namespace Causality
namespace Constructive

open MeasureTheory

/-- **The constructive articulation of the DAG.** A rank function under which every
parent strictly descends. This is `G`-as-data: where the classical development
asserts wellfoundedness (a `Prop`) and extracts by choice, `Rank` carries the
topological structure explicitly. -/
structure Rank (M : SCM.{u}) : Type u where
  /-- The rank (topological height) of each vertex. -/
  rank : M.V → ℕ
  /-- Every parent has strictly smaller rank. -/
  parents_lt : ∀ i : M.V, ∀ j ∈ M.Pa i, rank j < rank i

namespace Rank

variable {M : SCM.{u}}

/-- **The solution operator.** Explicit recursion on the rank witness: the value at
`i` is the structural equation applied to the (recursively solved) parents and the
own noise. Compiles to structural recursion on `Acc` over `Nat.lt` — no choice. -/
def solve (R : Rank M) (u : ∀ i, M.U i) (i : M.V) : M.Sp i :=
  M.f i ⟨fun j => solve R u j.val, u i⟩
termination_by R.rank i
decreasing_by exact R.parents_lt i j.val j.property

/-- **The fixed-point equation** (Pearl eq. 1.40 as a theorem about a constructed
object): `solve` solves every structural equation simultaneously. -/
theorem solve_spec (R : Rank M) (u : ∀ i, M.U i) (i : M.V) :
    R.solve u i = M.f i ⟨fun j => R.solve u j.val, u i⟩ := by
  rw [solve]

/-- **Uniqueness of solutions.** Any family solving the structural equations
pointwise agrees with the constructed solution. Rank induction; no choice. -/
theorem solve_unique (R : Rank M) (φ : (∀ i, M.U i) → ∀ i, M.Sp i)
    (hφ : ∀ u i, φ u i = M.f i ⟨fun j => φ u j.val, u i⟩)
    (u : ∀ i, M.U i) (i : M.V) : φ u i = R.solve u i := by
  induction hi : R.rank i using Nat.strong_induction_on generalizing i with
  | _ n ih =>
    subst hi
    rw [hφ u i, R.solve_spec u i]
    exact congrArg (fun p => M.f i (p, u i)) (funext fun j =>
      ih (R.rank j.val) (R.parents_lt i j.val j.property) j.val rfl)

/-- **Measurability of the solution operator**, by strong induction on rank: each
coordinate is the (measurable) structural equation composed with measurable
projections and the (inductively measurable) parent solutions. -/
theorem measurable_solve (R : Rank M) (i : M.V) :
    Measurable (fun u => R.solve u i) := by
  induction hi : R.rank i using Nat.strong_induction_on generalizing i with
  | _ n ih =>
    subst hi
    have hrw : (fun u => R.solve u i)
        = fun u => M.f i ⟨fun j => R.solve u j.val, u i⟩ :=
      funext fun u => R.solve_spec u i
    rw [hrw]
    exact (M.hf i).comp
      (Measurable.prodMk
        (measurable_pi_lambda _ fun j =>
          ih (R.rank j.val) (R.parents_lt i j.val j.property) j.val rfl)
        (measurable_pi_apply i))

/-- The full solution map `u ↦ (i ↦ solve u i)` is measurable. -/
theorem measurable_solveMap (R : Rank M) :
    Measurable (fun u i => R.solve u i) :=
  measurable_pi_lambda _ fun i => R.measurable_solve i

/-- **The rank witness discharges acyclicity**: the parent relation embeds in `<`
on ranks, which is well-founded. Constructive (Nat's wellfoundedness is
structural). -/
theorem isAcyclic (R : Rank M) : M.IsAcyclic :=
  Subrelation.wf (fun {i j} h => R.parents_lt j i h)
    (InvImage.wf R.rank Nat.lt_wfRel.wf)

/-- **The classical predicate is a corollary of the construction**: existence of a
measurable simultaneous solution, witnessed — never assumed. -/
theorem isRecursive (R : Rank M) : M.IsRecursive :=
  ⟨R.isAcyclic, fun u i => R.solve u i, R.measurable_solveMap,
    fun u i => R.solve_spec u i⟩

/-- **The constructive joint distribution**: the pushforward of the exogenous joint
through the constructed solution operator. Choice-free where `Architecture.joint`
is choice-extracted. -/
noncomputable def jointC (R : Rank M) : ProbabilityMeasure (∀ i : M.V, M.Sp i) :=
  M.uDist.map R.measurable_solveMap.aemeasurable

/-- **The bridge: the choice is eliminable.** For any recursiveness witness, the
classical `joint` (defined by `choose`-extraction in `Architecture`) equals the
constructive `jointC`: by uniqueness, whatever `choose` picked IS the constructed
solution. -/
theorem jointC_eq_joint (R : Rank M) (hRec : M.IsRecursive) :
    M.joint hRec = R.jointC := by
  have hsolve : hRec.2.choose = fun u i => R.solve u i :=
    funext fun u => funext fun i =>
      R.solve_unique hRec.2.choose (fun v k => hRec.2.choose_spec.2 v k) u i
  unfold SCM.joint jointC
  congr 1

/-- **Surgery preserves the rank witness.** `doIntervene` only clears parent sets,
so the SAME rank function witnesses acyclicity of the intervened model. The
interventional solution theory is therefore constructive with no new data. -/
def doIntervene (R : Rank M) (X : Finset M.V) (x : ∀ i ∈ X, M.Sp i) :
    Rank (M.doIntervene X x) where
  rank := R.rank
  parents_lt := by
    intro i j hj
    have hj' : j ∈ (if i ∈ X then (∅ : Finset M.V) else M.Pa i) := hj
    by_cases hX : i ∈ X
    · rw [if_pos hX] at hj'
      exact absurd hj' (Finset.notMem_empty j)
    · rw [if_neg hX] at hj'
      exact R.parents_lt i j hj'

/-- **The constructive interventional distribution** `P(V | do(X = x))`:
the constructive joint of the surgically modified model, using the transported
rank witness. No choice anywhere in the chain above the measure theory. -/
noncomputable def PxC (R : Rank M) (X : Finset M.V) (x : ∀ i ∈ X, M.Sp i) :
    ProbabilityMeasure (∀ i : M.V, M.Sp i) :=
  (R.doIntervene X x).jointC

end Rank

end Constructive
end Causality
