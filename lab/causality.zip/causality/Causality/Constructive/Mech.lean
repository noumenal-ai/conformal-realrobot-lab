/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Order.RelClasses

/-!
# Mech — the measure-free mechanism skeleton (the constructive base)

The base of the SCM tower: vertices, parent sets, value and noise sorts, and the
structural equations — NO measure theory, NO measurable-space instances. The axiom
audit of `Constructive/Core.lean` showed the classical `SCM`'s *type* is contaminated
by `Classical.choice` through the `MeasurableSpace.pi` instance in its `uDist` field;
`Mech` is the factored-out skeleton on which the solution theory audits clean.

The second audit finding: `termination_by` well-founded recursion itself pulls
`Classical.choice` in this toolchain, while structural recursion is axiom-free. The
solution operator here is therefore written in the FUEL pattern — structural
recursion on a rank bound — with the fuel-invariance lemma making the choice of
fuel irrelevant.

Everything in this file targets a clean `#print axioms`: the data (`solve`) should
show NO axioms; the specification lemmas at most `propext/Quot.sound` (funext).
-/

universe u

namespace Causality
namespace Constructive

/-- **The mechanism skeleton.** Vertices, parent sets, value sorts, noise sorts,
structural equations. The constructive base of an SCM: everything an SCM is,
before any measure or measurability is imposed. -/
structure Mech : Type (u + 1) where
  /-- Vertex set. -/
  V : Type u
  [V_fin : Fintype V]
  [V_dec : DecidableEq V]
  /-- Per-vertex value sort. -/
  Sp : V → Type u
  /-- Endogenous parent set of each vertex. -/
  Pa : V → Finset V
  /-- Per-vertex exogenous noise sort. -/
  U : V → Type u
  /-- Structural equation for vertex `i`. -/
  f : ∀ i, ((j : { j : V // j ∈ Pa i }) → Sp j.val) × U i → Sp i

namespace Mech

variable (M : Mech.{u})

instance : Fintype M.V := M.V_fin
instance : DecidableEq M.V := M.V_dec

/-- **The constructive articulation of the DAG**: a rank function under which every
parent strictly descends. `G`-as-data. -/
structure Rank (M : Mech.{u}) : Type u where
  /-- The rank (topological height) of each vertex. -/
  rank : M.V → ℕ
  /-- Every parent has strictly smaller rank. -/
  parents_lt : ∀ i : M.V, ∀ j ∈ M.Pa i, rank j < rank i

variable {M}

namespace Rank

/-- **The fuel solution operator**: structural recursion on a fuel bound dominating
the rank. Axiom-free by construction (no well-founded machinery). -/
def solveFuel (R : Rank M) (u : ∀ i, M.U i) :
    (fuel : ℕ) → (i : M.V) → R.rank i < fuel → M.Sp i
  | fuel + 1, i, h =>
    M.f i ⟨fun j => R.solveFuel u fuel j.val
      (lt_of_lt_of_le (R.parents_lt i j.val j.property) (Nat.lt_succ_iff.mp h)), u i⟩

/-- **Fuel invariance**: the solution does not depend on the fuel bound. -/
theorem solveFuel_congr (R : Rank M) (u : ∀ i, M.U i) :
    ∀ (n m : ℕ) (i : M.V) (hn : R.rank i < n) (hm : R.rank i < m),
      R.solveFuel u n i hn = R.solveFuel u m i hm := by
  intro n
  induction n with
  | zero => exact fun m i hn _ => absurd hn (Nat.not_lt_zero _)
  | succ n' ih =>
    intro m i hn hm
    match m with
    | 0 => exact absurd hm (Nat.not_lt_zero _)
    | m' + 1 =>
      show M.f i _ = M.f i _
      exact congrArg (fun p => M.f i (p, u i))
        (funext fun j => ih m' j.val _ _)

/-- **The solution operator**: fuel instantiated at the canonical bound. -/
def solve (R : Rank M) (u : ∀ i, M.U i) (i : M.V) : M.Sp i :=
  R.solveFuel u (R.rank i + 1) i (Nat.lt_succ_self _)

/-- **The fixed-point equation** (Pearl eq. 1.40 as a theorem about a constructed
object): `solve` solves every structural equation simultaneously. -/
theorem solve_spec (R : Rank M) (u : ∀ i, M.U i) (i : M.V) :
    R.solve u i = M.f i ⟨fun j => R.solve u j.val, u i⟩ := by
  show R.solveFuel u (R.rank i + 1) i _ = _
  rw [solveFuel]
  exact congrArg (fun p => M.f i (p, u i))
    (funext fun j => R.solveFuel_congr u _ _ j.val _ _)

/-- **Uniqueness**: any pointwise solution agrees with the constructed one.
Structural induction on fuel; no choice. -/
theorem solve_unique (R : Rank M) (φ : (∀ i, M.U i) → ∀ i, M.Sp i)
    (hφ : ∀ u i, φ u i = M.f i ⟨fun j => φ u j.val, u i⟩)
    (u : ∀ i, M.U i) (i : M.V) : φ u i = R.solve u i := by
  suffices h : ∀ (n : ℕ) (k : M.V), R.rank k < n → φ u k = R.solve u k from
    h (R.rank i + 1) i (Nat.lt_succ_self _)
  intro n
  induction n with
  | zero => exact fun k hk => absurd hk (Nat.not_lt_zero _)
  | succ n' ih =>
    intro k hk
    rw [hφ u k, R.solve_spec u k]
    exact congrArg (fun p => M.f k (p, u k))
      (funext fun j => ih j.val
        (lt_of_lt_of_le (R.parents_lt k j.val j.property) (Nat.lt_succ_iff.mp hk)))

/-- **The rank witness discharges acyclicity** of the parent relation. -/
theorem isAcyclic (R : Rank M) : WellFounded (fun i j : M.V => i ∈ M.Pa j) :=
  Subrelation.wf (fun {i j} h => R.parents_lt j i h)
    (InvImage.wf R.rank Nat.lt_wfRel.wf)

/-- **Surgery on the skeleton**: replace the mechanisms on `X` by constants and
clear their parents. The mechanism-level `do(X = x)`. -/
def _root_.Causality.Constructive.Mech.doIntervene
    (M : Mech.{u}) (X : Finset M.V) (x : ∀ i ∈ X, M.Sp i) : Mech.{u} where
  V := M.V
  V_fin := M.V_fin
  V_dec := M.V_dec
  Sp := M.Sp
  Pa := fun i => if i ∈ X then ∅ else M.Pa i
  U := M.U
  f := fun i inp =>
    if h : i ∈ X then x i h
    else M.f i ⟨fun j => inp.1 ⟨j.val, by rw [if_neg h]; exact j.property⟩, inp.2⟩

/-- **Surgery preserves the rank witness**: the same rank function works. -/
def doIntervene (R : Rank M) (X : Finset M.V) (x : ∀ i ∈ X, M.Sp i) :
    Rank (M.doIntervene X x) where
  rank := R.rank
  parents_lt := by
    intro i j hj
    have hj' : j ∈ (if i ∈ X then (∅ : Finset M.V) else M.Pa i) := hj
    by_cases hX : i ∈ X
    · rw [if_pos hX] at hj'
      exact absurd hj' (Finset.notMem_empty j)
    · rw [if_neg hX] at hj'
      exact R.parents_lt i j hj'

end Rank

end Mech

end Constructive
end Causality
