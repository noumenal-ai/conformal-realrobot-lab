/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Constructive.Mech
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Finset.Prod

/-!
# Structure derivation: the constructive core (F1–F4)

The one-shot of `research/urs/constructive/CONSTRUCTIVE_FOUNDATIONS_DISCOVERY_URS.md` §III, at the grain
locked there. Binary (two-node, `Fin 2`) scope throughout — the general Fintype
core is the named next obligation; every claim here is kernel-decided on executed
objects, none exceeds its grain.

* **MechSyntax (K1):** `UProg`, a minimal unary program language with `eval`
  (denotation) and `size` — the intension substrate.
* **Intensional non-collapse (executed pair):** `progId` and `progNegNeg` are
  denotationally EQUAL (`decide`) — so the Mechs they induce have identical
  executed supports — yet syntactically distinct with different sizes. The
  intensional stratum is real: L1-visible objects agree, the syntax layer does not.
* **F1 — the orientation Pl-kill (executed pair):** `fwdWitness` (X₀ → X₁) and
  `bwdWitness` (X₁ → X₀) have EQUAL executed supports (`decide`): the bare support
  is directionless. The directional sibling of parity shadow-blindness.
* **F2 — the orientation functional:** `realizableFwd/Bwd κ n` (∃ a noise-arity-`n`
  table realizing κ in that direction) is decidable; `orientSound_conjecture` is
  the NAMED OPEN conjecture (soundness of minimal-noise-arity orientation) — the
  decidable cousin of Janzing–Schölkopf, stated, not proved, not `sorry`d.
* **F3 — orientation from regimes (executed):** with one logged intervention the
  asymmetry appears: `regimePair` is fwd-consistent and NOT bwd-consistent
  (`decide`). Support + logged surgery orients what support alone cannot.
* **F4 — reflexive soundness (logged case, executed):** `LoggedData` tags each
  support with its surgery; the logged witness is soundly generated (`decide`),
  while POOLING the same data (erasing tags) corrupts the defect — the executed
  unlogged-corruption contrast.
-/

namespace Causality.Constructive

/-! ## MechSyntax: the minimal program language (K1 substrate) -/

/-- A minimal unary program language over `Fin 2`: the intension substrate.
Programs are DATA; `eval` is the denotation, `size` the capacity proxy. -/
inductive UProg : Type
  | id : UProg
  | neg : UProg
  | const : Fin 2 → UProg
  | comp : UProg → UProg → UProg
deriving DecidableEq

namespace UProg

/-- Denotation. -/
def eval : UProg → Fin 2 → Fin 2
  | .id, x => x
  | .neg, x => 1 - x
  | .const b, _ => b
  | .comp p q, x => p.eval (q.eval x)

/-- Size: the capacity proxy on syntax. -/
def size : UProg → ℕ
  | .id => 1
  | .neg => 1
  | .const _ => 1
  | .comp p q => 1 + p.size + q.size

end UProg

/-! ## Two-node mechanism skeletons from tables/programs -/

/-- The forward graph: `Pa 0 = ∅`, `Pa 1 = {0}` (closed data, no free variables). -/
def fwdPa : Fin 2 → Finset (Fin 2) := fun i => match i with | 0 => ∅ | 1 => {0}

/-- The backward graph: `Pa 0 = {1}`, `Pa 1 = ∅`. -/
def bwdPa : Fin 2 → Finset (Fin 2) := fun i => match i with | 0 => {1} | 1 => ∅

/-- Rank descent for the forward graph — decidable because closed. -/
theorem fwdPa_lt : ∀ i : Fin 2, ∀ j ∈ fwdPa i, j.val < i.val := by decide

/-- Rank descent for the backward graph. -/
theorem bwdPa_lt : ∀ i : Fin 2, ∀ j ∈ bwdPa i, 1 - j.val < 1 - i.val := by decide

/-- Forward two-node skeleton `X₀ → X₁`: node 0 reads its noise, node 1 computes
`t x₀ u₁` from its parent and its noise. -/
def fwdMech (t : Fin 2 → Fin 2 → Fin 2) : Mech where
  V := Fin 2
  Sp := fun _ => Fin 2
  Pa := fwdPa
  U := fun _ => Fin 2
  f := fun i => match i with
    | 0 => fun inp => inp.2
    | 1 => fun inp => t (inp.1 ⟨0, by decide⟩) inp.2

/-- Backward two-node skeleton `X₁ → X₀`: node 1 reads its noise, node 0 computes
`g x₁ u₀`. -/
def bwdMech (g : Fin 2 → Fin 2 → Fin 2) : Mech where
  V := Fin 2
  Sp := fun _ => Fin 2
  Pa := bwdPa
  U := fun _ => Fin 2
  f := fun i => match i with
    | 0 => fun inp => g (inp.1 ⟨1, by decide⟩) inp.2
    | 1 => fun inp => inp.2

/-- Rank witness for the forward skeleton (descent lemma is closed data). -/
def fwdRank (t : Fin 2 → Fin 2 → Fin 2) : Mech.Rank (fwdMech t) :=
  ⟨fun i => i.val, fwdPa_lt⟩

/-- Rank witness for the backward skeleton. -/
def bwdRank (g : Fin 2 → Fin 2 → Fin 2) : Mech.Rank (bwdMech g) :=
  ⟨fun i => 1 - i.val, bwdPa_lt⟩

/-- The executed support of a forward skeleton: the image of the constructed
solution over all noise configurations. ℚ-free (⟨decide⟩-grade). -/
def suppFwd (t : Fin 2 → Fin 2 → Fin 2) : Finset (Fin 2 × Fin 2) :=
  Finset.univ.image (fun (u : Fin 2 → Fin 2) =>
    ((fwdRank t).solve u (0 : Fin 2), (fwdRank t).solve u (1 : Fin 2)))

/-- The executed support of a backward skeleton. -/
def suppBwd (g : Fin 2 → Fin 2 → Fin 2) : Finset (Fin 2 × Fin 2) :=
  Finset.univ.image (fun (u : Fin 2 → Fin 2) =>
    ((bwdRank g).solve u (0 : Fin 2), (bwdRank g).solve u (1 : Fin 2)))

/-- The executed support of a surgered forward skeleton under `do(X₀ = v)`,
through the transported rank witness. -/
def suppFwdDo (t : Fin 2 → Fin 2 → Fin 2) (v : Fin 2) : Finset (Fin 2 × Fin 2) :=
  Finset.univ.image (fun (u : Fin 2 → Fin 2) =>
    (((fwdRank t).doIntervene ({0} : Finset (Fin 2)) (fun _ _ => v)).solve u (0 : Fin 2),
     ((fwdRank t).doIntervene ({0} : Finset (Fin 2)) (fun _ _ => v)).solve u (1 : Fin 2)))

/-- The executed support of a surgered forward skeleton under `do(X₁ = w)` — the
CHILD intervention, whose support can leave the observational support. -/
def suppFwdDoChild (t : Fin 2 → Fin 2 → Fin 2) (w : Fin 2) : Finset (Fin 2 × Fin 2) :=
  Finset.univ.image (fun (u : Fin 2 → Fin 2) =>
    (((fwdRank t).doIntervene ({1} : Finset (Fin 2)) (fun _ _ => w)).solve u (0 : Fin 2),
     ((fwdRank t).doIntervene ({1} : Finset (Fin 2)) (fun _ _ => w)).solve u (1 : Fin 2)))

/-! ## Intensional non-collapse (executed pair) -/

/-- The identity program. -/
def progId : UProg := .id

/-- Double negation: denotationally the identity, syntactically distinct. -/
def progNegNeg : UProg := .comp .neg .neg

/-- Denotational equality of the pair — the L1-visible layers agree. -/
theorem progPair_denot_eq : ∀ x, progId.eval x = progNegNeg.eval x := by decide

/-- Syntactic distinctness. -/
theorem progPair_syntax_ne : progId ≠ progNegNeg := by decide

/-- Size separation: the intension layer distinguishes what denotation cannot. -/
theorem progPair_size_ne : progId.size ≠ progNegNeg.size := by decide

/-- The induced skeletons have EQUAL executed supports (`decide` through two
interpreter runs): denotationally-equal programs are L1-indistinguishable. With
`progPair_syntax_ne`/`progPair_size_ne` this is the executed intensional
non-collapse pair: the mechanism stratum is strictly finer than every
support-visible layer. -/
theorem intensional_noncollapse_executed :
    suppFwd (fun x _ => progId.eval x)
      = suppFwd (fun x _ => progNegNeg.eval x) := by decide

/-! ## F1 — the orientation Pl-kill (executed pair) -/

/-- The forward witness mechanism: `f(0,u) = 0`, `f(1,u) = u`. -/
def fwdWitness : Fin 2 → Fin 2 → Fin 2 := fun x u => match x with
  | 0 => 0
  | 1 => u

/-- The backward witness mechanism: `g(0,u) = u`, `g(1,u) = 1`. -/
def bwdWitness : Fin 2 → Fin 2 → Fin 2 := fun y u => match y with
  | 0 => u
  | 1 => 1

/-- **F1, executed: the support is directionless.** Opposite-orientation skeletons,
identical executed supports (`κ = {(0,0),(1,0),(1,1)}`, defect 1 — genuinely
coupled, not the trivial case). No support functional can orient an edge. -/
theorem orientation_blind_executed :
    suppFwd fwdWitness = suppBwd bwdWitness := by decide

/-- The shared support is genuinely non-rectangular (its rectangular hull is
strictly larger): the kill is not vacuous. -/
theorem orientation_blind_nonrect :
    ((suppFwd fwdWitness).image Prod.fst ×ˢ
      (suppFwd fwdWitness).image Prod.snd).card
      = (suppFwd fwdWitness).card + 1 := by decide

/-! ## F2 — the orientation functional (decidable defs + the named conjecture) -/

/-- `κ` is realizable in the forward direction with noise arity `n`: some table
`t : Fin 2 → Fin n → Fin 2` has exactly the fibers of `κ`. Decidable. -/
def realizableFwd (κ : Finset (Fin 2 × Fin 2)) (n : ℕ) : Prop :=
  ∃ t : Fin 2 → Fin n → Fin 2, ∀ a b, (a, b) ∈ κ ↔ ∃ u, t a u = b

/-- Backward-direction realizability. Decidable. -/
def realizableBwd (κ : Finset (Fin 2 × Fin 2)) (n : ℕ) : Prop :=
  ∃ g : Fin 2 → Fin n → Fin 2, ∀ a b, (a, b) ∈ κ ↔ ∃ u, g b u = a

instance (κ : Finset (Fin 2 × Fin 2)) (n : ℕ) : Decidable (realizableFwd κ n) := by
  unfold realizableFwd; infer_instance

instance (κ : Finset (Fin 2 × Fin 2)) (n : ℕ) : Decidable (realizableBwd κ n) := by
  unfold realizableBwd; infer_instance

/-- The F1 kill, restated through the functional: the witness support is
bi-realizable already at noise arity 2 — both directions, same κ. -/
theorem kill_biRealizable :
    realizableFwd (suppFwd fwdWitness) 2
      ∧ realizableBwd (suppFwd fwdWitness) 2 := by decide

/-- **F2 soundness — NAMED OPEN CONJECTURE (not proved, not `sorry`d).** For
mechanism classes with a genuine size gradient (beyond tables), the direction of
strictly smaller minimal realization size tracks the generating direction. The
decidable, combinatorial cousin of the Janzing–Schölkopf algorithmic-independence
postulate (route-through sibling; their Kolmogorov frame is never our home). The
binary TABLE class provably cannot witness it (`kill_biRealizable` — tables are
size-symmetric); a program class with structure (e.g. `UProg`-circuits over wider
sorts) is the designated substrate. Discharge or refute there. -/
def orientSound_conjecture : Prop :=
  ∀ κ : Finset (Fin 2 × Fin 2), ∀ n m : ℕ,
    realizableFwd κ n → ¬ realizableBwd κ n → realizableBwd κ m → n < m

/-! ## F3 — orientation from one logged regime (executed) -/

/-- Fwd-consistency of an (observational, do(X₀ = v)) support pair: ONE table
serves both — it realizes the observational support and its `v`-fiber is exactly
the interventional support. -/
def fwdConsistent (κobs κdo : Finset (Fin 2 × Fin 2)) (v : Fin 2) : Prop :=
  ∃ t : Fin 2 → Fin 2 → Fin 2,
    (∀ a b, (a, b) ∈ κobs ↔ ∃ u, t a u = b) ∧
    κdo = Finset.univ.image (fun u => (v, t v u))

/-- Bwd-consistency of the same pair: some `g` realizes the observational support
backward, and — since `do(X₀ = v)` severs `g` — the interventional support must be
`{v} × (X₁'s observational marginal)`. -/
def bwdConsistent (κobs κdo : Finset (Fin 2 × Fin 2)) (v : Fin 2) : Prop :=
  (∃ g : Fin 2 → Fin 2 → Fin 2, ∀ a b, (a, b) ∈ κobs ↔ ∃ u, g b u = a) ∧
    κdo = {v} ×ˢ κobs.image Prod.snd

instance (κobs κdo : Finset (Fin 2 × Fin 2)) (v : Fin 2) :
    Decidable (fwdConsistent κobs κdo v) := by
  unfold fwdConsistent; infer_instance

instance (κobs κdo : Finset (Fin 2 × Fin 2)) (v : Fin 2) :
    Decidable (bwdConsistent κobs κdo v) := by
  unfold bwdConsistent; infer_instance

/-- The F3 generating mechanism: `f(0,u) = u`, `f(1,u) = 1` — chosen so the
intervened fiber is strict. -/
def f3Mech : Fin 2 → Fin 2 → Fin 2 := fun x u => match x with
  | 0 => u
  | 1 => 1

/-- The logged interventional support: `do(X₀ = 1)` on the F3 mechanism, executed
through the transported rank witness. -/
def f3DoSupp : Finset (Fin 2 × Fin 2) := suppFwdDo f3Mech 1

/-- **F3, executed: one logged regime orients the edge.** The (observational,
do(X₀ = 1)) executed pair is forward-consistent and NOT backward-consistent —
support plus one logged surgery derives the direction that support alone
(`orientation_blind_executed`) provably cannot. -/
theorem regime_orients_executed :
    fwdConsistent (suppFwd f3Mech) f3DoSupp 1
      ∧ ¬ bwdConsistent (suppFwd f3Mech) f3DoSupp 1 := by decide

/-! ## F4 — reflexive soundness, logged case (executed) -/

/-- Logged self-generated data over the two-node skeleton: each record tags the
executed support with the surgery that produced it (`none` = observational). -/
structure LoggedData where
  /-- The records: (surgery tag `some (node, value)` or observational `none`,
  executed support). -/
  records : List (Option (Fin 2 × Fin 2) × Finset (Fin 2 × Fin 2))

/-- A logged record is soundly generated by mechanism `t` when every tagged
support IS the executed support of the correspondingly-surgered skeleton. -/
def SoundlyGenerated (t : Fin 2 → Fin 2 → Fin 2) (D : LoggedData) : Prop :=
  ∀ r ∈ D.records,
    r.2 = match r.1 with
      | none => suppFwd t
      | some (n, v) => if n = 0 then suppFwdDo t v else suppFwdDoChild t v

instance (t : Fin 2 → Fin 2 → Fin 2) (D : LoggedData) :
    Decidable (SoundlyGenerated t D) := by
  unfold SoundlyGenerated; infer_instance

/-- The F4 witness run: the agent's own policy acted (`do(X₀ = 1)`) and logged it. -/
def f4Run : LoggedData :=
  ⟨[(none, suppFwd f3Mech), (some (0, 1), f3DoSupp),
    (some (1, 0), suppFwdDoChild f3Mech 0)]⟩

/-- The inline support defect (hull minus support), as in the witness module. -/
def defectOf (κ : Finset (Fin 2 × Fin 2)) : ℕ :=
  (κ.image Prod.fst ×ˢ κ.image Prod.snd).card - κ.card

/-- **F4 logged case, executed:** the tagged run is soundly generated — every
per-tag support is the true surgered support, so per-tag certificates read the
true objects. -/
theorem f4_logged_sound : SoundlyGenerated f3Mech f4Run := by decide

/-- **F4 unlogged corruption, executed:** POOLING the same two supports (erasing
the tags) yields defect `0` — the pooled data looks rectangular ("independent")
— while the true observational defect is `1`. Unlogged self-action erases the
very coupling the certificate exists to detect: the executed form of the
reflexive-soundness principle's negative clause. -/
theorem f4_unlogged_corrupts :
    defectOf (suppFwd f3Mech ∪ suppFwdDoChild f3Mech 0) = 0
      ∧ defectOf (suppFwd f3Mech) = 1 := by decide

/-- The corruption is child-side specifically: pooling PARENT-side interventional
data cannot leave the observational support (the kernel refuted the parent-side
corruption claim — recorded as content, not smoothed): the parent-side pool keeps
the true defect. -/
theorem f4_parent_pool_harmless :
    defectOf (suppFwd f3Mech ∪ f3DoSupp) = defectOf (suppFwd f3Mech) := by decide

end Causality.Constructive
