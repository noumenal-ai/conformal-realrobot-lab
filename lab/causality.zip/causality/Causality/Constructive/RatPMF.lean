/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Mathlib.Algebra.Order.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.Field.Rat

/-!
# RatPMF — executable probability on finite types

The executable probability layer: finitely-supported `ℚ`-valued mass functions with
decidable everything. Mathlib's `PMF`/`Measure` are `ℝ≥0∞`-valued and noncomputable;
every `#eval`-able probabilistic witness needs this layer instead.

## EXTRACTION CONTRACT (fold-out design)

This module is scheduled to be folded out into the general executable-witnesses
infrastructure and re-introduced as an API. Constraints honored here so that the
fold-out is a constant-cost move:

* NO imports from `causality/` (or any design-lab library) — Mathlib only;
* minimal API surface: `RatPMF`, `w`, `support`, `map`, `uniform` — nothing else;
* the bridge `RatPMF → PMF → Measure` is deliberately DEFERRED to the general
  infrastructure (it is the only part that touches `ℝ≥0∞`).
-/

/-- An executable probability mass function on a finite type: rational weights,
nonnegative, summing to one. All fields decidable/computable. -/
structure RatPMF (α : Type*) [Fintype α] [DecidableEq α] where
  /-- The mass function. -/
  w : α → ℚ
  /-- Nonnegativity. -/
  nonneg : ∀ a, 0 ≤ w a
  /-- Total mass one. -/
  sum_one : ∑ a, w a = 1

namespace RatPMF

variable {α β : Type*} [Fintype α] [DecidableEq α] [Fintype β] [DecidableEq β]

/-- The support: the (computable) finite set of points of positive mass. -/
def support (p : RatPMF α) : Finset α := Finset.univ.filter (fun a => p.w a ≠ 0)

/-- **Pushforward** along any function: the mass of `b` is the total mass of its
fiber. Fully computable — the executable shadow of `Measure.map`. -/
def map (f : α → β) (p : RatPMF α) : RatPMF β where
  w b := ∑ a ∈ Finset.univ.filter (fun a => f a = b), p.w a
  nonneg b := Finset.sum_nonneg fun a _ => p.nonneg a
  sum_one := by
    rw [Finset.sum_fiberwise_of_maps_to (fun a _ => Finset.mem_univ (f a))]
    exact p.sum_one

/-- The uniform distribution on a nonempty finite set. -/
def uniform (s : Finset α) (hs : s.Nonempty) : RatPMF α where
  w a := if a ∈ s then ((s.card : ℚ))⁻¹ else 0
  nonneg a := by
    split
    · exact inv_nonneg.mpr (Nat.cast_nonneg _)
    · exact le_rfl
  sum_one := by
    rw [Finset.sum_ite_mem, Finset.univ_inter, Finset.sum_const, nsmul_eq_mul]
    exact mul_inv_cancel₀ (by exact_mod_cast Finset.card_ne_zero.mpr hs)

end RatPMF
