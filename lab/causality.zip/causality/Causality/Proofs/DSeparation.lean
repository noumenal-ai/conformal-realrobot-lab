/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Conjectures.DSeparation

/-!
# Proofs — d-Separation

Leaf-node discharges for the conjectures stated in
`Causality.Conjectures.DSeparation`. Each `theorem … := by sorry` is
the open discharge for one DAG node; the sorry is replaced as the
proof lands. Conjecture statements (`def`s in the conjecture file) are
not edited from here.
-/

namespace Causality.Pearl

theorem T1_2_4_proved : T1_2_4 := by sorry
theorem T1_2_5_proved : T1_2_5 := by sorry
theorem T1_2_6_proved : T1_2_6 := by sorry
theorem T1_2_7_proved : T1_2_7 := by sorry
theorem T1_2_8_proved : T1_2_8 := by sorry
theorem T1_4_1_proved : T1_4_1 := by sorry
theorem D1_2_3_holds : D1_2_3 := by sorry

end Causality.Pearl
