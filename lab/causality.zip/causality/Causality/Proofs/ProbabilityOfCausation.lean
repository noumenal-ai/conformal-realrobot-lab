/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/
import Causality.Conjectures.ProbabilityOfCausation

/-!
# Proofs — Probability of Causation (Chapter 9)

Discharges for the §9.2 cluster, post fidelity review (2026-07-29).

Proved axiom-clean: `T9_2_10` (validity via the cell inequalities; sharpness in
Pearl's any-value sense via one explicit Fréchet construction), `T9_2_11`
(exogenous reduction of the conditional PN/PS to the marginal ratios),
`C9_2_12` (every point of the PN interval (9.14) attained, via the sharpness
construction at `pns = p · a`), `C9_2_12_pns_witness` (comonotone vs
countermonotone pair at marginals `(1/2, 1/2)`), `T9_2_14` (monotonicity kills
the harmed cell; PNS/PN/PS identification (9.21)–(9.23)), `L9_2_6`
(decomposition (9.5) on the joint layer, assumption-free), `T9_2_15`
(eqs. (9.28)–(9.30) on the joint layer, no exogeneity). Open: `T9_4_2`
(needs SCM-level local-invertibility machinery; deliberate sorry).
-/

namespace Causality.Pearl

/-! ### Definitional projection helpers for `toResponse` -/

private theorem toResponse_pns (j : XResponseDist) :
    j.toResponse.pns = j.rMarg false true := rfl

private theorem toResponse_pY1 (j : XResponseDist) :
    j.toResponse.pY1 = j.rMarg false true + j.rMarg true true := rfl

private theorem toResponse_pY0 (j : XResponseDist) :
    j.toResponse.pY0 = j.rMarg true false + j.rMarg true true := rfl

/-! ### Discharges -/

theorem L9_2_6_proved : L9_2_6 := by
  intro j h1 h2
  simp only [XResponseDist.pns, XResponseDist.pn, XResponseDist.ps]
  rw [← mul_div_assoc, ← mul_div_assoc,
    mul_div_cancel_left₀ _ h1.ne', mul_div_cancel_left₀ _ h2.ne']
  ring

theorem T9_2_10_proved : T9_2_10 := by
  constructor
  · -- Validity: the Fréchet interval contains PNS.
    intro d
    have h00 := d.nonneg false false
    have h01 := d.nonneg false true
    have h10 := d.nonneg true false
    have h11 := d.nonneg true true
    have hs := d.sum_one
    constructor
    · apply max_le
      · exact h01
      · simp only [ResponseDist.pY1, ResponseDist.pY0, ResponseDist.pns]
        linarith
    · apply le_min
      · simp only [ResponseDist.pY1, ResponseDist.pns]
        linarith
      · simp only [ResponseDist.pY0, ResponseDist.pns]
        linarith
  · -- Sharpness: EVERY value permitted by the bounds is attained.
    intro a b p _ha0 _ha1 _hb0 _hb1 hpl hpu
    have hp0 : (0 : ℝ) ≤ p := le_trans (le_max_left 0 (a - b)) hpl
    have hab : a - b ≤ p := le_trans (le_max_right 0 (a - b)) hpl
    have hpa : p ≤ a := le_trans hpu (min_le_left a (1 - b))
    have hpb : p ≤ 1 - b := le_trans hpu (min_le_right a (1 - b))
    refine ⟨ResponseDist.mk4 (1 - b - p) p (b - a + p) (a - p)
        (by linarith) hp0 (by linarith) (by linarith) (by ring), ?_, ?_, ?_⟩
    · show p + (a - p) = a; ring
    · show b - a + p + (a - p) = b; ring
    · rfl

theorem T9_2_11_proved : T9_2_11 := by
  intro j hexo
  refine ⟨fun hpos => ?_, fun hpos => ?_⟩
  · -- PN = PNS / P(y|x) under exogeneity.
    have hfac : j.pxy = j.pxMarg true * (j.rMarg false true + j.rMarg true true) := by
      show j.q true false true + j.q true true true =
        j.pxMarg true * (j.rMarg false true + j.rMarg true true)
      rw [hexo true false true, hexo true true true]
      ring
    have hx : j.pxMarg true ≠ 0 := by
      intro h0
      rw [hfac, h0, zero_mul] at hpos
      exact lt_irrefl 0 hpos
    show j.q true false true / j.pxy = j.toResponse.pns / j.toResponse.pY1
    rw [toResponse_pns, toResponse_pY1, hexo true false true, hfac,
      mul_div_mul_left _ _ hx]
  · -- PS = PNS / P(y'|x') under exogeneity.
    have hfac' : j.pxy' = j.pxMarg false * (j.rMarg false false + j.rMarg false true) := by
      show j.q false false false + j.q false false true =
        j.pxMarg false * (j.rMarg false false + j.rMarg false true)
      rw [hexo false false false, hexo false false true]
      ring
    have hx' : j.pxMarg false ≠ 0 := by
      intro h0
      rw [hfac', h0, zero_mul] at hpos
      exact lt_irrefl 0 hpos
    have hden : (1 : ℝ) - (j.rMarg true false + j.rMarg true true) =
        j.rMarg false false + j.rMarg false true := by
      simp only [XResponseDist.rMarg]
      linarith [j.sum_one]
    show j.q false false true / j.pxy' = j.toResponse.pns / (1 - j.toResponse.pY0)
    rw [toResponse_pns, toResponse_pY0, hden, hexo false false true, hfac',
      mul_div_mul_left _ _ hx']

theorem T9_2_14_proved : T9_2_14 := by
  intro d hd
  have hmono : d.r true false = 0 := hd
  have hpns : d.pns = d.pY1 - d.pY0 := by
    simp only [ResponseDist.pns, ResponseDist.pY1, ResponseDist.pY0]
    linarith
  refine ⟨hpns, fun _ => ?_, fun _ => ?_⟩
  · show d.pns / d.pY1 = (d.pY1 - d.pY0) / d.pY1
    rw [hpns]
  · show d.pns / (1 - d.pY0) = (d.pY1 - d.pY0) / (1 - d.pY0)
    rw [hpns]

theorem T9_2_15_proved : T9_2_15 := by
  intro j hm
  have hm' : j.q false true false + j.q true true false = 0 := hm
  have hf : j.q false true false = 0 := by
    have h1 := j.nonneg false true false
    have h2 := j.nonneg true true false
    linarith
  have ht : j.q true true false = 0 := by
    have h1 := j.nonneg false true false
    have h2 := j.nonneg true true false
    linarith
  refine ⟨?_, fun _ => ?_, fun _ => ?_⟩
  · -- (9.28): PNS = P(y_x) - P(y_{x'}).
    show j.pns = j.toResponse.pY1 - j.toResponse.pY0
    simp only [XResponseDist.pns, toResponse_pY1, toResponse_pY0, XResponseDist.rMarg]
    linarith
  · -- (9.29): PN = (P(y) - P(y_{x'})) / P(x, y).
    have hnum : j.py - j.toResponse.pY0 = j.q true false true := by
      simp only [XResponseDist.py, toResponse_pY0, XResponseDist.rMarg]
      linarith
    show j.q true false true / j.pxy = (j.py - j.toResponse.pY0) / j.pxy
    rw [hnum]
  · -- (9.30): PS = (P(y_x) - P(y)) / P(x', y').
    have hnum : j.toResponse.pY1 - j.py = j.q false false true := by
      simp only [XResponseDist.py, toResponse_pY1, XResponseDist.rMarg]
      linarith
    show j.q false false true / j.pxy' = (j.toResponse.pY1 - j.py) / j.pxy'
    rw [hnum]

theorem T9_4_2_proved : T9_4_2 := by sorry

theorem C9_2_12_proved : C9_2_12 := by
  intro a b p ha0 ha1 hb0 hb1 hpl hpu
  have hL : max 0 (a - b) ≤ p * a := (div_le_iff₀ ha0).mp hpl
  have hU : p * a ≤ min a (1 - b) := (le_div_iff₀ ha0).mp hpu
  obtain ⟨d, hd1, hd0, hdp⟩ :=
    T9_2_10_proved.2 a b (p * a) (le_of_lt ha0) ha1 hb0 hb1 hL hU
  refine ⟨d, hd1, hd0, ?_⟩
  show d.pns / d.pY1 = p
  rw [hdp, hd1, mul_div_cancel_right₀ _ (ne_of_gt ha0)]

theorem C9_2_12_pns_witness_proved : C9_2_12_pns_witness := by
  refine ⟨ResponseDist.mk4 (1/2) 0 0 (1/2)
      (by norm_num) le_rfl le_rfl (by norm_num) (by norm_num),
    ResponseDist.mk4 0 (1/2) (1/2) 0
      le_rfl (by norm_num) (by norm_num) le_rfl (by norm_num), ?_, ?_, ?_⟩
  · show (0 : ℝ) + 1/2 = 1/2 + 0; norm_num
  · show (0 : ℝ) + 1/2 = 1/2 + 0; norm_num
  · show (0 : ℝ) ≠ 1/2; norm_num

-- Axiom audit for the discharged theorems (standard axioms only, no sorryAx).
#print axioms L9_2_6_proved
#print axioms T9_2_10_proved
#print axioms T9_2_11_proved
#print axioms T9_2_14_proved
#print axioms T9_2_15_proved
#print axioms C9_2_12_proved
#print axioms C9_2_12_pns_witness_proved

end Causality.Pearl
