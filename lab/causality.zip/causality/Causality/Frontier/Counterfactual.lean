import Causality.Architecture

/-! # Frontier — open construction (NOT in the green default lib)

`counterfactual` below carries an open `sorry` (the Radon-Nikodym abduction step).
Per the conjecture-root method it lives in the non-default `CausalityFrontier` lib so the
default `Causality` lib stays sorry-free under the warnings-are-errors posture. -/

namespace Causality

/-! ## §14 Counterfactual (Pearl's three-step procedure) -/

namespace SCM

variable (M : SCM)

/-- **Counterfactual evaluation** (Pearl §1.4.4, `T7_1_7` in DAG): the
three-step abduction–action–prediction procedure.

Given:
* an observed evidence event `E ⊆ ∀ i, Sp i`
* a hypothetical intervention `do(X = x')`

The counterfactual distribution "what would `Y` have been if `X = x'`,
given that we observed `E`" is computed by:

1. **Abduction**: condition `uDist` on the noise being consistent with
   the observed evidence under the original SCM.
2. **Action**: replace the SCM with its `do(X = x')`-mutated version.
3. **Prediction**: push the abduction-updated noise through the mutated
   structural equations.

### Notes

* Step 1 requires `P(E) > 0`; the absolute-continuity case is handled
  via Radon-Nikodym.
* Step 3 requires the mutated SCM to be recursive.
* The full identifiability question (when can this be computed from
  data alone?) is the subject of `T9_4_2` and
  `EXT_COUNTERFACTUAL_IDENTIFICATION` (Correa-Lee-Bareinboim).
-/
noncomputable def counterfactual
    (X : Finset M.V) (x' : ∀ i ∈ X, M.Sp i)
    (evidence : Set (∀ i : M.V, M.Sp i))
    (hEvidence : MeasurableSet evidence)
    (hRec : (M.doIntervene X x').IsRecursive) :
    Measure (∀ i : M.V, M.Sp i) := by
  -- Step 1 (Abduction): condition uDist on noise consistent with evidence.
  -- The conditioning event is the preimage of `evidence` under the
  -- original SCM's solution map.
  -- Step 2 (Action): doIntervene already supplied as parameter.
  -- Step 3 (Prediction): push abduction-conditioned noise through the
  -- new structural equations.
  sorry

end SCM

end Causality
