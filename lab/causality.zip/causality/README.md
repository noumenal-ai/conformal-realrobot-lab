# causality

Lean 4 formalization of Pearl's causal calculus and the post-2009 literature
that extends it. This is the seventh sub-library of `design-lab/`, alongside
`learning-theory/`, `measurements/`, `transformers/`, `statistics/`, `rl/`,
and `neural-networks/`.

## Status

**v0 — ground-truth ingested, sandbox SCM primitive present, full formalization pending.**

Two artifacts live here so far:

- [`pearl_inheritance_dag_current_literature_audited.json`](./pearl_inheritance_dag_current_literature_audited.json):
  a 140-node, 151-edge, schema-validated audit of Pearl 2009 against May-2026
  literature. This is the formalization target.
- [`Causality/Basic.lean`](./Causality/Basic.lean):
  a sandbox `SCM (U A S)` primitive in the `Causality` namespace, with sketches
  of `doIntervene`, `interventionalDist`, `counterfactualDist`, `causalKernel`,
  `Identifiable`, `BackdoorIdentified`. **This is the simpler 3-type shape, not
  the Pearl-indexed-family shape we will commit to**. Two `sorry`s remain
  (`causalKernel.measurable'` and `counterfactualDist_self`), both standard
  Mathlib applications.

The next refactor will replace `SCM (U A S)` with the indexed-family
`StructuralCausalModel` derived via `task-urs-typing-derivation` from the
DAG's 140 nodes, taking only one custom primitive (per the constraint
established in conversation).

## What the ground-truth DAG specifies

- 27-node main inheritance chain from `T1_2_4` (Probabilistic Implications of
  d-Separation) through `L11_5_1` (graphical identification of direct effects
  in the second-edition elaboration).
- 41 Theorems, 12 Corollaries, 5 Lemmas, 1 Conjecture, 3 conceptual anchors,
  68 Definitions, 10 modern extension nodes (post-2009 literature).
- 26 anchor-chain edges, 50 support-branch edges, 23 definition-prerequisite
  edges, 52 current-literature-extension edges.
- Per-node witness grade, current-literature audit, and explicit
  redaction/extension policy.

## Scope commitments

This sub-library formalizes:

| Layer | Source | Commitment |
|---|---|---|
| **One custom primitive** | Pearl §1.4.1 functional causal model | `structure StructuralCausalModel` |
| **61 Definitions** | Pearl Chs 1–9, 11 (Ch 10 redacted) | direct `def` / `structure` |
| **59 Pearl results** | Pearl Chs 1–9, 11 | full proofs against the book's argument |
| **10 modern extensions** | Post-2009 literature (Shpitser-Pearl, Huang-Valtorta, Perkovic et al., Bareinboim-Pearl, etc.) | full proofs, each with a reduction-to-book bridge theorem |
| **Counterfactual Layer A** | Galles–Pearl 1995 axioms (book's set) | composition, effectiveness, reversibility / recursiveness |
| **Counterfactual Layer A equivalence** | Halpern 2000 / 2008 axioms | derived; equivalence proved as a separate non-trivial theorem |
| **Actual-causation Layer B** | Halpern–Pearl 2005 AC1/AC2/AC3 | additive, lives in `Modern/ActualCausationPostHP.lean` |
| **Linear SEM** | Pearl Ch 5 + Kumor–Chen–Bareinboim 2019 | polynomial-covariance / instrumental-cutset level |

The Ch 10 actual-causation material (sustenance, causal beams, the Pearl-2009
actual-cause definition, the Halpern–Pearl 2005 definition) is **redacted
from strict theorem-level formalization** per the DAG's audit and is preserved
as commented-only documentation in `Ch10_ActualCause/Redacted.lean` once
that file lands.

## Reading the ground truth from Lean

`pearl_inheritance_dag_current_literature_audited.json` is the ingestion
substrate, not a Lean file. Code-side, every formalized node will carry a
back-pointer to its DAG id (`T1_2_4`, `L9_2_6`, `EXT_ID_DO_CALCULUS_COMPLETE`,
…) in its docstring, so the JSON and the Lean formalization stay locked.

## Next steps (not yet done)

1. `Primitive/SCM.lean` — the one custom primitive, derived via
   `task-urs-typing-derivation`.
2. `Ch01_GraphProbSemantics/` — first chapter, anchors `T1_2_4` and `T1_4_1`.
3. Topologically downward through the DAG.

See the top-level `design-lab/README.md` for the overall library map.
