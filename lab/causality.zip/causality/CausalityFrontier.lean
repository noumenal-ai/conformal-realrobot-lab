/-! # CausalityFrontier — the open proof layer (stubbed `:= by sorry`) + counterfactual.
Non-default, exempt from the green posture; governed by the conjecture-root method. -/

import Causality.Proofs.DSeparation
import Causality.Proofs.CausalFoundations
import Causality.Proofs.Identification
import Causality.Proofs.DirectEffects
import Causality.Proofs.LinearSEM
import Causality.Proofs.Confounding
import Causality.Proofs.CounterfactualSemantics
import Causality.Proofs.ProbabilityOfCausation
import Causality.Proofs.GraphicalDirectEffects
import Causality.Proofs.AxiomEquivalence
import Causality.Proofs.Modern.MixedGraphs
import Causality.Proofs.Modern.IDCompleteness
import Causality.Proofs.Modern.CompleteAdjustment
import Causality.Proofs.Modern.Transportability
import Causality.Proofs.Modern.FaithfulnessGeometry
import Causality.Proofs.Modern.PathSpecificEffects
import Causality.Proofs.Modern.CounterfactualID
import Causality.Proofs.Modern.PartialIdentification
import Causality.Proofs.Modern.InstrumentalCutsets
import Causality.Proofs.Modern.ActualCausationPostHP
import Causality.Proofs.Modern.HierarchicalAbstraction
import Causality.Frontier.Counterfactual
