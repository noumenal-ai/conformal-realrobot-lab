/-
Copyright (c) 2026 Noumenal AI / Design Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Design Lab
-/

-- Root: the one custom primitive + 7 frontload records + DiscoveryProblem bundle
import Causality.Architecture

-- Conjecture catalog — stable Prop definitions, one cluster per DAG module
import Causality.Conjectures.DSeparation
import Causality.Conjectures.CausalFoundations
import Causality.Conjectures.Identification
import Causality.Conjectures.DirectEffects
import Causality.Conjectures.LinearSEM
import Causality.Conjectures.Confounding
import Causality.Conjectures.CounterfactualSemantics
import Causality.Conjectures.ProbabilityOfCausation
import Causality.Conjectures.GraphicalDirectEffects
import Causality.Conjectures.AxiomEquivalence
import Causality.Conjectures.Modern.MixedGraphs
import Causality.Conjectures.Modern.IDCompleteness
import Causality.Conjectures.Modern.CompleteAdjustment
import Causality.Conjectures.Modern.Transportability
import Causality.Conjectures.Modern.FaithfulnessGeometry
import Causality.Conjectures.Modern.PathSpecificEffects
import Causality.Conjectures.Modern.CounterfactualID
import Causality.Conjectures.Modern.PartialIdentification
import Causality.Conjectures.Modern.InstrumentalCutsets
import Causality.Conjectures.Modern.ActualCausationPostHP
import Causality.Conjectures.Modern.HierarchicalAbstraction
import Causality.Conjectures.Redacted.ActualCauseCh10

-- Leaf-node proofs — theorems claiming each conjecture; sorries decrease over time

/-!
# Causality — root barrel

Pure-import barrel for the `causality/` sub-library.

## Architecture

The library is organized as a two-tier research artifact:

1. **Root** — `Causality.Architecture`. The one custom primitive
   `SCM` plus the seven frontload records (`ObservedSchema`,
   `DiscoveryAssumptions`, `CausalEquivClass`, `CausalData`,
   `FiniteSampleGuarantee`, `CausalFrame`, `Query`) plus the
   `DiscoveryProblem` bundle plus `Identifiable`. No DAG-node-level
   conjectures here.

2. **Conjecture catalog** — `Causality.Conjectures.*`. Each cluster
   file corresponds to a DAG module (per the audited DAG's `module`
   field). Stable Prop definitions are stated here; once stated they
   are not edited except for substrate refinement before any proof
   attempts. New DAG nodes / hypotheses / KUs are added by appending a
   new `def` to the appropriate cluster file.

3. **Leaf proofs** — `Causality.Proofs.*`. Mirrors the Conjectures/
   structure. Each file declares `theorem <id>_proved : <id> := by
   sorry` for the conjectures it discharges, and over time the sorries
   are replaced with proofs. Proof attempts evolve independently of
   the catalog.

## DAG ground truth

`causality/pearl_inheritance_dag_current_literature_audited.json` —
141 nodes, 155 edges. The cluster file layout is in 1-to-1
correspondence with the DAG's `module` taxonomy (theorems) plus
distribution-by-chapter (definitions).

## Substrate

Mathlib only. Causality is a leaf in the design-lab dependency graph
— no imports from `measurements/`, `learning-theory/`, `statistics/`,
`rl/`, `transformers/`, or `neural-networks/`. (Locked 2026-05-30.)
-/
