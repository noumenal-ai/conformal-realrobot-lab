# MOVE_MANIFEST — publication cleanup (measurements tree)

Date: 2026-07-12. Reversible relocation only; no deletions; no `.lean` touched.

## Moves (source → dest, relative to ZPM/Measurements/HC/)

| Source | Dest |
|---|---|
| QJT_LEDGER.md | discovery/ledgers/QJT_LEDGER.md |
| QJT_URS.md | discovery/QJT_URS.md |
| QUANTUM_TOWER_URS.md | discovery/QUANTUM_TOWER_URS.md |
| HANDOFF_DISCOVERY_URS.md | discovery/HANDOFF_DISCOVERY_URS.md |
| HANDOFF_NOOLOGY_URS.md | discovery/HANDOFF_NOOLOGY_URS.md |
| FLAGSHIP_COHOMOLOGY_URS.md | discovery/FLAGSHIP_COHOMOLOGY_URS.md |
| FOL/NOOLOGY_URS.md | discovery/FOL_NOOLOGY_URS.md (renamed: FOL_ prefix, avoids collision with any future HC-level NOOLOGY) |

Total moved: 7.

## stale_references (referencing file left UNEDITED — docstring comment only)

- `ZPM/Measurements/HC/QJTTwoClique.lean:16` — docstring reads "extraction record: QJT_LEDGER.md".
  The ledger now lives at `discovery/ledgers/QJT_LEDGER.md`. This is a prose comment in a `/-! -/`
  block, not a Lean `import` or path dependency, so the build is unaffected. Update the docstring
  text to `discovery/ledgers/QJT_LEDGER.md` during the docstring-strip pass if desired.

## ambiguous_left_in_place (publication/structural — NOT moved)

- `ZPM/Measurements/HC/Theory.md` — the arc's theory writeup (publication doc), kept in place.
- `ZPM/Measurements/HC/FOUNDATIONS.md` — the HC doctrine writeup (publication doc), kept in place.
- All `.lean` files — frozen, never moved.
- Pre-existing `discovery/`, `discovery/ledgers/`, `discovery/mining/` contents — already correctly placed.

## world-models tree

Scanned identically; already publication-clean — every `*_URS*.md` / `*_LEDGER*.md` / `HANDOFF*` /
`*NOOLOG*` already lives under `world-models/discovery/` (or the correctly-placed
`reports/eg_instrument_v12/internal/`). No moves required.
