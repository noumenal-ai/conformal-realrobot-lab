/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Probability.FintypePMF.DualW1
import Mathlib.Order.FixedPoints

/-!
# The Ferns transport operator: fixpoints, the band, uniqueness, perturbation

`fernsOp g P γ` sends a ground structure `d` to `g ⊔ γ • (transport discrepancy of the
kernel rows under d)` — the operator whose fixpoints are behavioural (bisimulation-type)
metrics. Everything here is order-side: existence is Knaster–Tarski (`OrderHom.lfp`), the
greatest fixpoint is developed D-BANDED (`fernsGfpBanded` — the unbanded greatest fixpoint is
degenerate: at unbounded ground the discrepancy is `⊤`-prone), and uniqueness/stability are
proved by a discrete Grönwall absorption atom in `ℝ≥0∞`, with no completeness or contraction
machinery.

Two facts carry the analysis and both live on the reflexive-triangle cone
(`IsTransportGround`): the **McShane envelope perturbation** `dualW1_add_const_le`
(additive ground perturbation with constant exactly 1; the triangle hypothesis is
load-bearing — off the cone the constant degrades, e.g. along zero-distance chains — and the
lemma claims nothing there) and the **absorption atom** `ennreal_absorb`
(`e ≤ γe + ε ⇒ e ≤ ε/(1-γ)` for bounded `e`), whose `ε = 0` case is uniqueness
(`ferns_fixedPoint_unique`) and whose `ε > 0` case is the kernel-estimation stability bound
(`ferns_fixedPoint_perturb`), with `ε` measured in the transport discrepancy itself.

NOT claimed here: the kernel-equals-bisimilarity theorem (next development), any identity
between `OrderHom.lfp` and the cone-internal iterate supremum (open), K-R duality (unused —
the McShane route removed its last consumer).
-/

noncomputable section

namespace ProbabilityTheory.FintypePMF

open scoped ENNReal Classical

variable {α : Type*} [Fintype α]

/-- The reflexive-triangle cone (symmetry deliberately not required — unused). -/
def IsTransportGround (d : α → α → ℝ≥0∞) : Prop :=
  (∀ a, d a a = 0) ∧ (∀ a b c, d a c ≤ d a b + d b c)

/-- Expectations shift additively under constant shifts. -/
theorem expE_add_const (p : FintypePMF α) (f : α → ℝ≥0∞) (c : ℝ≥0∞) :
    expE p (fun x => f x + c) = expE p f + c := by
  unfold expE
  simp only [mul_add]
  rw [Finset.sum_add_distrib]
  congr 1
  exact expE_const p c

/-- **McShane envelope perturbation**: on the reflexive-triangle cone, an additive constant
perturbation of the ground moves the discrepancy by at most that constant. The envelope
`f₂ x = ⨅ b, (f b + d x b)` of a `(d+δ)`-Lipschitz observable is `d`-Lipschitz (triangle),
below `f` (reflexivity), and `δ`-close to it — no primal form, no duality theorem. -/
theorem dualW1_add_const_le [Nonempty α] {d : α → α → ℝ≥0∞} (hd : IsTransportGround d)
    (δ : ℝ≥0∞) (p q : FintypePMF α) :
    dualW1 (fun a b => d a b + δ) p q ≤ dualW1 d p q + δ := by
  unfold dualW1
  refine iSup₂_le fun f hf => ?_
  set f₂ : α → ℝ≥0∞ := fun x => ⨅ b, (f b + d x b) with hf₂def
  have hf₂_lip : Lip1 d f₂ := by
    intro x y
    rw [show f₂ y + d x y = ⨅ b, (f b + d y b + d x y) from by rw [ENNReal.iInf_add]]
    refine le_iInf fun b => (iInf_le _ b).trans ?_
    calc f b + d x b ≤ f b + (d x y + d y b) := by gcongr; exact hd.2 x y b
      _ = f b + d y b + d x y := by ring
  have hf₂_le : ∀ x, f₂ x ≤ f x := fun x => (iInf_le _ x).trans (by rw [hd.1, add_zero])
  have hle_f₂ : ∀ x, f x ≤ f₂ x + δ := by
    intro x
    rw [show f₂ x + δ = ⨅ b, (f b + d x b + δ) from by rw [ENNReal.iInf_add]]
    refine le_iInf fun b => ?_
    calc f x ≤ f b + (d x b + δ) := hf x b
      _ = f b + d x b + δ := by ring
  have gapb : ∀ u v : FintypePMF α,
      expE u f - expE v f ≤ (expE u f₂ - expE v f₂) + δ := by
    intro u v
    have h1 : expE u f ≤ expE u f₂ + δ :=
      (expE_mono u hle_f₂).trans_eq (expE_add_const u f₂ δ)
    have h2 : expE v f₂ ≤ expE v f := expE_mono v hf₂_le
    calc expE u f - expE v f ≤ (expE u f₂ + δ) - expE v f₂ := tsub_le_tsub h1 h2
      _ = (δ + expE u f₂) - expE v f₂ := by rw [add_comm]
      _ ≤ δ + (expE u f₂ - expE v f₂) := add_tsub_le_assoc
      _ = (expE u f₂ - expE v f₂) + δ := add_comm _ _
  have hterm := le_iSup₂ (f := fun g _ =>
    (expE p g - expE q g) ⊔ (expE q g - expE p g)) f₂ hf₂_lip
  refine sup_le ?_ ?_
  · exact (gapb p q).trans (by gcongr; exact le_sup_left.trans hterm)
  · exact (gapb q p).trans (by gcongr; exact le_sup_right.trans hterm)

/-- **The absorption atom** (discrete Grönwall in `ℝ≥0∞`): a bounded quantity absorbing
itself at rate `γ < 1` with slack `ε` is at most `ε / (1 - γ)`. Uniqueness is the `ε = 0`
case; stability is the general case. -/
theorem ennreal_absorb {e γ ε D : ℝ≥0∞} (h : e ≤ γ * e + ε) (heD : e ≤ D) (hD : D ≠ ⊤)
    (hγ : γ < 1) : e ≤ ε / (1 - γ) := by
  have he_top : e ≠ ⊤ := (heD.trans_lt hD.lt_top).ne
  have h' : e ≤ ε + e * γ := by
    rw [mul_comm γ e] at h
    exact h.trans_eq (add_comm _ _)
  have hsub : e * (1 - γ) ≤ ε := by
    rw [ENNReal.mul_sub (fun _ _ => he_top), mul_one]
    exact tsub_le_iff_right.mpr h'
  have h1γ0 : (1 : ℝ≥0∞) - γ ≠ 0 := (tsub_pos_of_lt hγ).ne'
  have h1γtop : (1 : ℝ≥0∞) - γ ≠ ⊤ := ne_top_of_le_ne_top ENNReal.one_ne_top tsub_le_self
  exact (ENNReal.le_div_iff_mul_le (Or.inl h1γ0) (Or.inl h1γtop)).mpr hsub

/-! ## The operator -/

/-- The Ferns transport operator over gap `g`, kernel `P`, discount `γ`. -/
def fernsOp (g : α → α → ℝ≥0∞) (P : α → FintypePMF α) (γ : ℝ≥0∞) :
    (α → α → ℝ≥0∞) →o (α → α → ℝ≥0∞) where
  toFun d := fun a b => g a b ⊔ γ * dualW1 d (P a) (P b)
  monotone' := fun d d' h => by
    intro a b
    have hm := dualW1_mono (fun x y => h x y) (P a) (P b)
    dsimp only
    gcongr

variable (g : α → α → ℝ≥0∞) (P : α → FintypePMF α) (γ : ℝ≥0∞)

/-- **The least fixed point** (`d*_least`): Knaster–Tarski, no side conditions. -/
def fernsLfp : α → α → ℝ≥0∞ := OrderHom.lfp (fernsOp g P γ)

theorem fernsLfp_fixed : fernsOp g P γ (fernsLfp g P γ) = fernsLfp g P γ :=
  OrderHom.map_lfp _

/-- The forced metric dominates the gap. -/
theorem le_fernsLfp_of_gap (a b : α) : g a b ≤ fernsLfp g P γ a b := by
  conv_rhs => rw [← fernsLfp_fixed g P γ]
  exact le_sup_left

/-- `const D` is prefixed when the gap and the discounted diameter fit under `D`. -/
theorem fernsOp_const_le [Nonempty α] {D : ℝ≥0∞} (hg : ∀ a b, g a b ≤ D)
    (hγD : γ * D ≤ D) : fernsOp g P γ (fun _ _ => D) ≤ fun _ _ => D := by
  intro a b
  refine sup_le (hg a b) ?_
  calc γ * dualW1 (fun _ _ => D) (P a) (P b) ≤ γ * D := by
        gcongr
        exact dualW1_le_of_le_const (fun _ _ => le_rfl) _ _
    _ ≤ D := hγD

theorem fernsLfp_le_const [Nonempty α] {D : ℝ≥0∞} (hg : ∀ a b, g a b ≤ D)
    (hγD : γ * D ≤ D) : ∀ a b, fernsLfp g P γ a b ≤ D :=
  OrderHom.lfp_le _ (fernsOp_const_le g P γ hg hγD)

/-- **The greatest `D`-banded fixed point** (`d*_greatest at D`): the unbanded greatest
fixpoint is degenerate (`⊤`-prone), so the band parameter is content, not blemish. -/
def fernsGfpBanded (D : ℝ≥0∞) : α → α → ℝ≥0∞ :=
  sSup {d | d ≤ fernsOp g P γ d ∧ ∀ a b, d a b ≤ D}

theorem fernsGfpBanded_le_const {D : ℝ≥0∞} (a b : α) : fernsGfpBanded g P γ D a b ≤ D := by
  have h : fernsGfpBanded g P γ D ≤ fun _ _ => D :=
    sSup_le fun _ hd => fun a b => hd.2 a b
  exact h a b

theorem fernsGfpBanded_postfixed (D : ℝ≥0∞) :
    fernsGfpBanded g P γ D ≤ fernsOp g P γ (fernsGfpBanded g P γ D) :=
  sSup_le fun _ hd => hd.1.trans ((fernsOp g P γ).monotone (le_sSup hd))

/-- The banded greatest fixpoint is a genuine fixed point (two-step Tarski). -/
theorem fernsGfpBanded_fixed [Nonempty α] {D : ℝ≥0∞} (hg : ∀ a b, g a b ≤ D)
    (hγD : γ * D ≤ D) :
    fernsOp g P γ (fernsGfpBanded g P γ D) = fernsGfpBanded g P γ D := by
  have hpost := fernsGfpBanded_postfixed g P γ D
  refine le_antisymm (le_sSup ⟨(fernsOp g P γ).monotone hpost, ?_⟩) hpost
  intro a b
  have hb : fernsGfpBanded g P γ D ≤ fun _ _ => D :=
    fun a b => fernsGfpBanded_le_const g P γ a b
  exact ((fernsOp g P γ).monotone hb).trans (fernsOp_const_le g P γ hg hγD) a b

/-- **The band is ordered**: `d*_least ≤ d*_greatest at D`. At `γ < 1` the collapse theorem
below closes the band; at `γ = 1` it may stand open — a boundary object, tracked. -/
theorem fernsLfp_le_gfpBanded [Nonempty α] {D : ℝ≥0∞} (hg : ∀ a b, g a b ≤ D)
    (hγD : γ * D ≤ D) : fernsLfp g P γ ≤ fernsGfpBanded g P γ D :=
  OrderHom.lfp_le _ (le_of_eq (fernsGfpBanded_fixed g P γ hg hγD))

/-- The operator preserves the reflexive-triangle cone when the gap lies in it. -/
theorem fernsOp_preserves_ground (hg : IsTransportGround g) {d : α → α → ℝ≥0∞} :
    IsTransportGround (fernsOp g P γ d) := by
  constructor
  · intro a
    show g a a ⊔ γ * dualW1 d (P a) (P a) = 0
    rw [hg.1 a, dualW1_self, mul_zero, sup_idem]
  · intro a b c
    show g a c ⊔ γ * dualW1 d (P a) (P c)
      ≤ (g a b ⊔ γ * dualW1 d (P a) (P b)) + (g b c ⊔ γ * dualW1 d (P b) (P c))
    refine sup_le ?_ ?_
    · exact (hg.2 a b c).trans (add_le_add le_sup_left le_sup_left)
    · calc γ * dualW1 d (P a) (P c)
          ≤ γ * (dualW1 d (P a) (P b) + dualW1 d (P b) (P c)) := by
            gcongr
            exact dualW1_triangle d (P a) (P b) (P c)
        _ = γ * dualW1 d (P a) (P b) + γ * dualW1 d (P b) (P c) := mul_add _ _ _
        _ ≤ _ := add_le_add le_sup_right le_sup_right

/-! ## Uniqueness and perturbation (the absorption engine) -/

/-- One-sided master chain: a fixed point of `fernsOp g P γ` exceeds a fixed point of
`fernsOp g P' γ` by at most `γ·e + 2γε`, where `e` is their sup-discrepancy and `ε` bounds
the kernel rows' discrepancy under the second metric. `P' = P, ε = 0` gives uniqueness;
`P' = P̂` gives stability. -/
private theorem ferns_master_chain [Nonempty α] {P' : α → FintypePMF α}
    {d d' : α → α → ℝ≥0∞} (hfix : fernsOp g P γ d = d) (hfix' : fernsOp g P' γ d' = d')
    (hd' : IsTransportGround d') {ε : ℝ≥0∞}
    (hε : ∀ s, dualW1 d' (P s) (P' s) ≤ ε) (a b : α) :
    d a b ≤ d' a b + (γ * (⨆ x, ⨆ y, (d x y - d' x y)) + 2 * γ * ε) := by
  set e := ⨆ x, ⨆ y, (d x y - d' x y) with he
  have hde : ∀ x y, d x y ≤ d' x y + e := by
    intro x y
    calc d x y ≤ (d x y - d' x y) + d' x y := le_tsub_add
      _ ≤ e + d' x y := by
          gcongr
          exact le_iSup₂ (f := fun x y => d x y - d' x y) x y
      _ = d' x y + e := add_comm _ _
  have hW : dualW1 d (P a) (P b) ≤ dualW1 d' (P a) (P b) + e :=
    (dualW1_mono hde (P a) (P b)).trans (dualW1_add_const_le hd' e (P a) (P b))
  have hker : dualW1 d' (P a) (P b) ≤ dualW1 d' (P' a) (P' b) + 2 * ε := by
    calc dualW1 d' (P a) (P b)
        ≤ dualW1 d' (P a) (P' a) + dualW1 d' (P' a) (P b) :=
          dualW1_triangle d' (P a) (P' a) (P b)
      _ ≤ dualW1 d' (P a) (P' a) + (dualW1 d' (P' a) (P' b) + dualW1 d' (P' b) (P b)) := by
          gcongr
          exact dualW1_triangle d' (P' a) (P' b) (P b)
      _ = dualW1 d' (P' a) (P' b) + (dualW1 d' (P a) (P' a) + dualW1 d' (P' b) (P b)) := by
          ring
      _ ≤ dualW1 d' (P' a) (P' b) + (ε + ε) := by
          gcongr
          · exact hε a
          · rw [dualW1_comm]; exact hε b
      _ = dualW1 d' (P' a) (P' b) + 2 * ε := by ring
  have hWtotal : dualW1 d (P a) (P b) ≤ dualW1 d' (P' a) (P' b) + 2 * ε + e :=
    hW.trans (by gcongr)
  have hv : g a b ⊔ γ * dualW1 d' (P' a) (P' b) = d' a b := congrFun (congrFun hfix' a) b
  calc d a b = g a b ⊔ γ * dualW1 d (P a) (P b) := (congrFun (congrFun hfix a) b).symm
    _ ≤ g a b ⊔ γ * (dualW1 d' (P' a) (P' b) + 2 * ε + e) := by gcongr
    _ = g a b ⊔ (γ * dualW1 d' (P' a) (P' b) + (γ * e + 2 * γ * ε)) := by
        rw [show γ * (dualW1 d' (P' a) (P' b) + 2 * ε + e)
            = γ * dualW1 d' (P' a) (P' b) + (γ * e + 2 * γ * ε) from by ring]
    _ ≤ (g a b ⊔ γ * dualW1 d' (P' a) (P' b)) + (γ * e + 2 * γ * ε) := by
        refine sup_le ?_ ?_
        · exact le_sup_left.trans le_self_add
        · exact add_le_add le_sup_right le_rfl
    _ = d' a b + (γ * e + 2 * γ * ε) := by rw [hv]

/-- **Uniqueness at `γ < 1`** among bounded fixed points on the cone — the band collapses.
Order-side throughout: the absorption atom at `ε = 0`; no contraction machinery. -/
theorem ferns_fixedPoint_unique [Nonempty α] {d₁ d₂ : α → α → ℝ≥0∞} {D : ℝ≥0∞}
    (h₁ : fernsOp g P γ d₁ = d₁) (h₂ : fernsOp g P γ d₂ = d₂)
    (hg₁ : IsTransportGround d₁) (hg₂ : IsTransportGround d₂)
    (hD₁ : ∀ a b, d₁ a b ≤ D) (hD₂ : ∀ a b, d₂ a b ≤ D)
    (hD : D ≠ ⊤) (hγ : γ < 1) : d₁ = d₂ := by
  have key : ∀ u v : α → α → ℝ≥0∞, fernsOp g P γ u = u → fernsOp g P γ v = v →
      IsTransportGround v → (∀ a b, u a b ≤ D) → u ≤ v := by
    intro u v hu hv hgv hDu
    have hchain := ferns_master_chain g P γ hu hv hgv
      (ε := 0) (fun s => by rw [dualW1_self])
    set e := ⨆ x, ⨆ y, (u x y - v x y) with he
    have heD : e ≤ D := iSup₂_le fun x y => tsub_le_self.trans (hDu x y)
    have habs : e ≤ γ * e + 0 := by
      refine iSup₂_le fun x y => ?_
      have hc := hchain x y
      rw [mul_zero, add_zero] at hc
      rw [add_zero]
      exact tsub_le_iff_right.mpr (hc.trans_eq (add_comm _ _))
    have hzero : e ≤ 0 := by
      have := ennreal_absorb habs heD hD hγ
      rwa [ENNReal.zero_div] at this
    intro x y
    have hxy : u x y - v x y = 0 :=
      le_antisymm ((le_iSup₂ (f := fun x y => u x y - v x y) x y).trans hzero) zero_le
    exact tsub_eq_zero_iff_le.mp hxy
  exact le_antisymm (key d₁ d₂ h₁ h₂ hg₂ hD₁) (key d₂ d₁ h₂ h₁ hg₁ hD₂)

/-- **The perturbation lemma** (kernel-estimation stability, order-side). The bound's shape —
`2γ/(1-γ)` with the row error measured in the transport discrepancy under the ESTIMATED
metric — is anticipated in the bisimulation-metric literature (Ferns–Panangaden–Precup,
SICOMP 2011, §7 sampling-error bounds; the phenomenon of estimated kernels learning different
fixed points is cited there and in Comanici et al. 2012). This file's contribution is the
mechanized proof and its order-side route (absorption + envelope; no completeness apparatus):
if `d` is fixed for the true kernel `P` and `d̂` for the estimate `P̂` (a transport ground,
both bounded), and every row-discrepancy `dualW1 d̂ (P s) (P̂ s) ≤ ε`, then the forced
metrics differ one-sidedly (`d ∸ dest`; symmetrize by swapping roles) by at most
`2γε/(1-γ)`. The audit-facing dividend: estimation error in the
kernel moves the forced geometry by a controlled amount, with `ε` measured in the transport
discrepancy itself. No Banach, no completeness, no duality — the absorption atom plus the
McShane envelope. -/
theorem ferns_fixedPoint_perturb [Nonempty α] {Pest : α → FintypePMF α}
    {d dest : α → α → ℝ≥0∞} {D ε : ℝ≥0∞}
    (hfix : fernsOp g P γ d = d) (hfix' : fernsOp g Pest γ dest = dest)
    (hgest : IsTransportGround dest) (hD : ∀ a b, d a b ≤ D) (hDtop : D ≠ ⊤) (hγ : γ < 1)
    (hε : ∀ s, dualW1 dest (P s) (Pest s) ≤ ε) :
    ∀ a b, d a b - dest a b ≤ 2 * γ * ε / (1 - γ) := by
  have hchain := ferns_master_chain g P γ hfix hfix' hgest hε
  set e := ⨆ x, ⨆ y, (d x y - dest x y) with he
  have heD : e ≤ D := iSup₂_le fun x y => tsub_le_self.trans (hD x y)
  have habs : e ≤ γ * e + 2 * γ * ε := by
    refine iSup₂_le fun x y => ?_
    exact tsub_le_iff_right.mpr ((hchain x y).trans_eq (add_comm _ _))
  have := ennreal_absorb habs heD hDtop hγ
  exact fun a b => (le_iSup₂ (f := fun x y => d x y - dest x y) a b).trans this

/-! ## The Kleene identity: iterates, cone continuity, the repaid carrier debt, the schedule

Ferns et al. work in `met` (pseudometrics under the uniform norm), so their fixed point is a
pseudometric by carrier choice, and their Thm 2.6(3) gives the iteration rate by Banach. Our
lfp lives on the full function lattice — cheaper hypotheses, but it created a debt: nothing
so far says the forced metric satisfies the triangle inequality. This section repays it
order-side: the Kleene supremum of the iterates equals the lfp (via ω-continuity of the
transport discrepancy on cone chains, proved by McShane envelopes and the finite min-sup
exchange), the iterates stay in the cone, hence **the forced metric is a transport ground**
— which in turn discharges the cone hypotheses of `ferns_fixedPoint_unique` and
`ferns_fixedPoint_perturb` at the canonical object. The rate (shape as in Ferns Thm 2.6(3))
gives the certified sweep schedule. -/

/-- The Kleene iterates from `⊥`. -/
noncomputable def fernsIter (n : ℕ) : α → α → ℝ≥0∞ := (fernsOp g P γ)^[n] ⊥

theorem fernsIter_succ (n : ℕ) :
    fernsIter g P γ (n + 1) = fernsOp g P γ (fernsIter g P γ n) := by
  simp [fernsIter, Function.iterate_succ_apply']

theorem fernsIter_monotone : Monotone (fernsIter g P γ) := by
  refine monotone_nat_of_le_succ fun n => ?_
  induction n with
  | zero => exact bot_le
  | succ n ih =>
      rw [fernsIter_succ, fernsIter_succ]
      exact (fernsOp g P γ).monotone ih

/-- The Kleene supremum. -/
noncomputable def fernsKleene : α → α → ℝ≥0∞ := ⨆ n, fernsIter g P γ n

theorem fernsIter_le_lfp (n : ℕ) : fernsIter g P γ n ≤ fernsLfp g P γ := by
  induction n with
  | zero => exact bot_le
  | succ n ih =>
      rw [fernsIter_succ]
      calc fernsOp g P γ (fernsIter g P γ n) ≤ fernsOp g P γ (fernsLfp g P γ) :=
            (fernsOp g P γ).monotone ih
        _ = fernsLfp g P γ := fernsLfp_fixed g P γ

theorem fernsKleene_le_lfp : fernsKleene g P γ ≤ fernsLfp g P γ :=
  iSup_le (fernsIter_le_lfp g P γ)

omit [Fintype α] in
theorem bot_ground : IsTransportGround (⊥ : α → α → ℝ≥0∞) :=
  ⟨fun _ => by simp, fun _ _ _ => by simp⟩

theorem fernsIter_ground (hg : IsTransportGround g) :
    ∀ n, IsTransportGround (fernsIter g P γ n) := by
  intro n
  induction n with
  | zero => exact bot_ground
  | succ n _ =>
      rw [fernsIter_succ]
      exact fernsOp_preserves_ground g P γ hg

omit [Fintype α] in
theorem ground_iSup {d : ℕ → α → α → ℝ≥0∞} (h : ∀ n, IsTransportGround (d n)) :
    IsTransportGround (⨆ n, d n) := by
  constructor
  · intro a
    have hz : ∀ n, d n a a = 0 := fun n => (h n).1 a
    simp [iSup_apply, hz]
  · intro a b c
    simp only [iSup_apply]
    refine iSup_le fun n => ?_
    exact ((h n).2 a b c).trans
      (add_le_add (le_iSup (fun m => d m a b) n) (le_iSup (fun m => d m b c) n))

/-- **ω-continuity of the transport discrepancy on cone chains** (the Kleene engine): the
discrepancy of a monotone supremum of transport grounds is bounded by the supremum of the
discrepancies. McShane envelopes plus the finite min-sup exchange; no case analysis. -/
theorem dualW1_iSup_chain [Nonempty α] {d : ℕ → α → α → ℝ≥0∞} (hmono : Monotone d)
    (hg : ∀ n, IsTransportGround (d n)) (p q : FintypePMF α) :
    dualW1 (⨆ n, d n) p q ≤ ⨆ n, dualW1 (d n) p q := by
  have hDg : IsTransportGround (⨆ n, d n) := ground_iSup hg
  unfold dualW1
  refine iSup₂_le fun f hf => ?_
  have hf' : Lip1 (⨆ n, d n) f := hf
  set fe : ℕ → α → ℝ≥0∞ := fun n x => ⨅ b, (f b + d n x b) with hfe
  have hfe_lip : ∀ n, Lip1 (d n) (fe n) := by
    intro n x y
    rw [show fe n y + d n x y = ⨅ b, (f b + d n y b + d n x y) from by rw [ENNReal.iInf_add]]
    refine le_iInf fun b => (iInf_le _ b).trans ?_
    calc f b + d n x b ≤ f b + (d n x y + d n y b) := by gcongr; exact (hg n).2 x y b
      _ = f b + d n y b + d n x y := by ring
  have hfe_mono : ∀ x, Monotone fun n => fe n x := by
    intro x n m hnm
    exact iInf_mono fun b => by gcongr; exact hmono hnm x b
  have hfe_eq : ∀ x, (⨆ n, fe n x) = f x := by
    intro x
    have h1 : (⨆ n, fe n x) = ⨅ b, ⨆ n, (f b + d n x b) :=
      iSup_iInf_of_monotone fun b n m hnm => by gcongr; exact hmono hnm x b
    have h2 : ∀ b, (⨆ n, (f b + d n x b)) = f b + (⨆ n, d n) x b := by
      intro b
      rw [← ENNReal.add_iSup]
      congr 1
      simp [iSup_apply]
    rw [h1]
    simp_rw [h2]
    refine le_antisymm ((iInf_le _ x).trans ?_) (le_iInf fun b => hf' x b)
    rw [hDg.1 x, add_zero]
  have hExp : ∀ u : FintypePMF α, expE u f = ⨆ n, expE u (fe n) := by
    intro u
    unfold expE
    calc ∑ s, ENNReal.ofReal (u.prob s) * f s
        = ∑ s, ⨆ n, ENNReal.ofReal (u.prob s) * fe n s := by
          refine Finset.sum_congr rfl fun s _ => ?_
          rw [← ENNReal.mul_iSup, hfe_eq]
      _ = ⨆ n, ∑ s, ENNReal.ofReal (u.prob s) * fe n s :=
          ENNReal.finsetSum_iSup_of_monotone fun s n m hnm => by
            gcongr
            exact hfe_mono s hnm
  have hside : ∀ u v : FintypePMF α,
      expE u f - expE v f ≤ ⨆ n, dualW1 (d n) u v := by
    intro u v
    refine tsub_le_iff_right.mpr ?_
    rw [hExp u]
    refine iSup_le fun n => ?_
    have hterm := le_iSup₂ (f := fun h _ =>
      (expE u h - expE v h) ⊔ (expE v h - expE u h)) (fe n) (hfe_lip n)
    have hle : expE u (fe n) - expE v (fe n) ≤ dualW1 (d n) u v :=
      le_sup_left.trans hterm
    have hfeleq : ∀ x, fe n x ≤ f x := fun x =>
      (le_iSup (fun m => fe m x) n).trans (hfe_eq x).le
    calc expE u (fe n) ≤ dualW1 (d n) u v + expE v (fe n) := tsub_le_iff_right.mp hle
      _ ≤ dualW1 (d n) u v + expE v f := by gcongr; exact expE_mono v hfeleq
      _ ≤ (⨆ m, dualW1 (d m) u v) + expE v f := by
          gcongr
          exact le_iSup (fun m => dualW1 (d m) u v) n
  refine sup_le (hside p q) ((hside q p).trans (iSup_mono fun n => ?_))
  exact (dualW1_comm (d n) q p).le

theorem fernsKleene_prefixed [Nonempty α] (hg : IsTransportGround g) :
    fernsOp g P γ (fernsKleene g P γ) ≤ fernsKleene g P γ := by
  intro a b
  show g a b ⊔ γ * dualW1 (fernsKleene g P γ) (P a) (P b) ≤ fernsKleene g P γ a b
  have hcont := dualW1_iSup_chain (fernsIter_monotone g P γ)
    (fernsIter_ground g P γ hg) (P a) (P b)
  calc g a b ⊔ γ * dualW1 (fernsKleene g P γ) (P a) (P b)
      ≤ g a b ⊔ γ * ⨆ n, dualW1 (fernsIter g P γ n) (P a) (P b) := by
        gcongr
        exact hcont
    _ ≤ ⨆ n, fernsIter g P γ (n + 1) a b := by
        refine sup_le ?_ ?_
        · refine le_iSup_of_le 0 ?_
          rw [fernsIter_succ]
          exact le_sup_left
        · rw [ENNReal.mul_iSup]
          refine iSup_le fun n => le_iSup_of_le n ?_
          rw [fernsIter_succ]
          exact le_sup_right
    _ ≤ fernsKleene g P γ a b := by
        refine iSup_le fun n => ?_
        exact le_iSup (fun m => fernsIter g P γ m) (n + 1) a b

/-- **The Kleene identity**: the iterate supremum IS the forced metric. -/
theorem fernsKleene_eq_lfp [Nonempty α] (hg : IsTransportGround g) :
    fernsKleene g P γ = fernsLfp g P γ :=
  le_antisymm (fernsKleene_le_lfp g P γ)
    (OrderHom.lfp_le _ (fernsKleene_prefixed g P γ hg))

/-- **The carrier debt repaid**: the forced metric is itself a transport ground (Ferns get
this by carrier choice; on the full lattice it is a theorem, via the Kleene identity). It
discharges the cone hypotheses of uniqueness and perturbation at the canonical object. -/
theorem fernsLfp_mem_ground [Nonempty α] (hg : IsTransportGround g) :
    IsTransportGround (fernsLfp g P γ) := by
  rw [← fernsKleene_eq_lfp g P γ hg]
  exact ground_iSup (fernsIter_ground g P γ hg)

/-- **The certified schedule** (shape as Ferns et al. SICOMP 2011, Thm 2.6(3); here
order-side and in-kernel): after `n` sweeps the iterate is within `γ^n · D` of the forced
metric, pointwise. -/
theorem fernsIter_rate [Nonempty α] (hg : IsTransportGround g) {D : ℝ≥0∞}
    (hgD : ∀ a b, g a b ≤ D) (hγD : γ * D ≤ D) :
    ∀ n a b, fernsLfp g P γ a b - fernsIter g P γ n a b ≤ γ ^ n * D := by
  intro n
  induction n with
  | zero =>
      intro a b
      rw [pow_zero, one_mul]
      exact tsub_le_self.trans (fernsLfp_le_const g P γ hgD hγD a b)
  | succ n ih =>
      intro a b
      have hle : ∀ x y, fernsLfp g P γ x y ≤ fernsIter g P γ n x y + γ ^ n * D := fun x y =>
        (tsub_le_iff_right.mp (ih x y)).trans_eq (add_comm _ _)
      have hW : dualW1 (fernsLfp g P γ) (P a) (P b)
          ≤ dualW1 (fernsIter g P γ n) (P a) (P b) + γ ^ n * D :=
        (dualW1_mono hle (P a) (P b)).trans
          (dualW1_add_const_le (fernsIter_ground g P γ hg n) _ (P a) (P b))
      have hstep : fernsLfp g P γ a b
          ≤ fernsIter g P γ (n + 1) a b + γ ^ (n + 1) * D := by
        conv_lhs => rw [← fernsLfp_fixed g P γ]
        rw [fernsIter_succ]
        show g a b ⊔ γ * dualW1 (fernsLfp g P γ) (P a) (P b)
          ≤ (g a b ⊔ γ * dualW1 (fernsIter g P γ n) (P a) (P b)) + γ ^ (n + 1) * D
        calc g a b ⊔ γ * dualW1 (fernsLfp g P γ) (P a) (P b)
            ≤ g a b ⊔ γ * (dualW1 (fernsIter g P γ n) (P a) (P b) + γ ^ n * D) := by
              gcongr
          _ = g a b ⊔ (γ * dualW1 (fernsIter g P γ n) (P a) (P b) + γ ^ (n + 1) * D) := by
              rw [mul_add, show γ * (γ ^ n * D) = γ ^ (n + 1) * D from by
                rw [pow_succ]; ring]
          _ ≤ (g a b ⊔ γ * dualW1 (fernsIter g P γ n) (P a) (P b)) + γ ^ (n + 1) * D := by
              refine sup_le (le_sup_left.trans le_self_add) (add_le_add le_sup_right le_rfl)
      exact tsub_le_iff_right.mpr (hstep.trans_eq (add_comm _ _))

end ProbabilityTheory.FintypePMF
