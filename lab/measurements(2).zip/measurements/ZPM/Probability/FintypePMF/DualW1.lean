/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Probability.FintypePMF.Def
import Mathlib.Data.ENNReal.Real
import Mathlib.Data.ENNReal.BigOperators

/-!
# Dual-form transport discrepancy (finite Kantorovich layer)

`dualW1 d p q` is the dual-form transport discrepancy between two finite laws over a ground
structure `d : α → α → ℝ≥0∞`: the supremum over the `d`-Lipschitz test class of the
(symmetrized, truncated) expectation gap. Mathlib has no Kantorovich/Wasserstein at this pin;
the dual form is primary because monotonicity in `d` and boundedness — the two properties a
fixpoint operator consumes — are free from it.

This is a measurement-theoretic primitive (instrument layer): it lives here beside
`tvDistance`, its 0/1-ground shadow. Consumers instantiate the ground structure per substrate
(e.g. `setoidDist` below prices a setoid's partition; the world-model corpus binds the layer to
its congruence clause).

**Contract.** The name follows the bisimulation-metric literature. This file proves
`dualW1_self`, `dualW1_comm`, `dualW1_mono`, `dualW1_triangle`, `dualW1_le_of_le_const`, and
the expectation calculus — `dualW1 d` is a genuine extended pseudometric on finite laws. The
primal (coupling) form is a recorded counter-definition, swapped in only if a downstream
lower-bound direction needs an explicit transport witness.
-/

noncomputable section

namespace ProbabilityTheory.FintypePMF

open scoped ENNReal Classical

variable {α : Type*} [Fintype α]

/-- The `d`-Lipschitz test class, one-sided ENNReal form (pair-symmetric by swapping `a b`). -/
def Lip1 (d : α → α → ℝ≥0∞) (f : α → ℝ≥0∞) : Prop :=
  ∀ a b, f a ≤ f b + d a b

/-- Expectation of an `ℝ≥0∞`-valued observable under a finite law. The `ofReal` boundary
between the ℝ-valued mass and the transport cone is crossed exactly once, here;
`prob_nonneg` makes it lossless. -/
def expE (p : FintypePMF α) (f : α → ℝ≥0∞) : ℝ≥0∞ :=
  ∑ s, ENNReal.ofReal (p.prob s) * f s

/-- **Dual-form transport discrepancy** over ground structure `d`. Symmetric by construction
(no reflection lemma); truncated subtraction. See the file contract for exactly which metric
properties are (and are not) proven. -/
def dualW1 (d : α → α → ℝ≥0∞) (p q : FintypePMF α) : ℝ≥0∞ :=
  ⨆ f ∈ {g : α → ℝ≥0∞ | Lip1 d g}, (expE p f - expE q f) ⊔ (expE q f - expE p f)

/-- The 0/1 ground structure of a setoid: related pairs at distance 0, unrelated at 1.
Bounded, and TV-compatible (its `dualW1` is the discrete-fiber shadow beside `tvDistance`);
the 0/⊤ variant is a recorded counter. -/
def setoidDist (r : Setoid α) : α → α → ℝ≥0∞ :=
  fun a b => if r a b then 0 else 1

/-! ## Expectation calculus (the priced `ofReal` boundary) -/

theorem expE_mono (p : FintypePMF α) {f g : α → ℝ≥0∞} (h : ∀ s, f s ≤ g s) :
    expE p f ≤ expE p g :=
  Finset.sum_le_sum fun s _ => by have hs := h s; gcongr

theorem expE_const (p : FintypePMF α) (c : ℝ≥0∞) : expE p (fun _ => c) = c := by
  unfold expE
  rw [← Finset.sum_mul, ← ENNReal.ofReal_sum_of_nonneg (fun s _ => p.prob_nonneg s),
    p.prob_sum_one, ENNReal.ofReal_one, one_mul]

/-- Indicators decode to `ofReal` of the set's mass. -/
theorem expE_indicator (p : FintypePMF α) (C : Finset α) :
    expE p (fun s => if s ∈ C then 1 else 0) = ENNReal.ofReal (∑ s ∈ C, p.prob s) := by
  unfold expE
  rw [ENNReal.ofReal_sum_of_nonneg (fun s _ => p.prob_nonneg s)]
  simp only [mul_ite, mul_one, mul_zero]
  rw [Finset.sum_ite_mem, Finset.univ_inter]

/-! ## The contract package (what a fixpoint operator consumes) -/

theorem dualW1_self (d : α → α → ℝ≥0∞) (p : FintypePMF α) : dualW1 d p p = 0 := by
  refine le_antisymm ?_ zero_le
  unfold dualW1
  exact iSup₂_le fun f _ => by simp

theorem dualW1_comm (d : α → α → ℝ≥0∞) (p q : FintypePMF α) :
    dualW1 d p q = dualW1 d q p := by
  unfold dualW1
  exact iSup_congr fun f => iSup_congr fun _ => sup_comm _ _

/-- **Monotonicity in the ground structure** (free from the dual form: a smaller `d` admits
fewer tests). -/
theorem dualW1_mono {d d' : α → α → ℝ≥0∞} (h : ∀ a b, d a b ≤ d' a b)
    (p q : FintypePMF α) : dualW1 d p q ≤ dualW1 d' p q := by
  unfold dualW1
  refine iSup₂_le fun f hf => ?_
  exact le_iSup₂ (f := fun f _ => (expE p f - expE q f) ⊔ (expE q f - expE p f)) f
    (fun a b => le_trans (hf a b) (by gcongr; exact h a b))

/-- **Triangle inequality**: a pointwise supremum of pseudometrics is a pseudometric. -/
theorem dualW1_triangle (d : α → α → ℝ≥0∞) (p q r : FintypePMF α) :
    dualW1 d p r ≤ dualW1 d p q + dualW1 d q r := by
  unfold dualW1
  refine iSup₂_le fun f hf => ?_
  have h1 : (expE p f - expE q f) ⊔ (expE q f - expE p f)
      ≤ ⨆ g ∈ {g : α → ℝ≥0∞ | Lip1 d g}, (expE p g - expE q g) ⊔ (expE q g - expE p g) :=
    le_iSup₂ (f := fun g _ => (expE p g - expE q g) ⊔ (expE q g - expE p g)) f hf
  have h2 : (expE q f - expE r f) ⊔ (expE r f - expE q f)
      ≤ ⨆ g ∈ {g : α → ℝ≥0∞ | Lip1 d g}, (expE q g - expE r g) ⊔ (expE r g - expE q g) :=
    le_iSup₂ (f := fun g _ => (expE q g - expE r g) ⊔ (expE r g - expE q g)) f hf
  refine le_trans (sup_le ?_ ?_) (add_le_add h1 h2)
  · exact le_trans tsub_le_tsub_add_tsub (add_le_add le_sup_left le_sup_left)
  · exact le_trans tsub_le_tsub_add_tsub
      (le_trans (add_le_add le_sup_right le_sup_right) (add_comm _ _).le)

/-- **Boundedness**: a `C`-bounded ground structure gives a `C`-bounded discrepancy. -/
theorem dualW1_le_of_le_const [Nonempty α] {d : α → α → ℝ≥0∞} {C : ℝ≥0∞}
    (hd : ∀ a b, d a b ≤ C) (p q : FintypePMF α) : dualW1 d p q ≤ C := by
  have side : ∀ p q : FintypePMF α, ∀ f, Lip1 d f → expE p f - expE q f ≤ C := by
    intro p q f hf
    obtain ⟨s₀, -, hs₀⟩ := Finset.exists_min_image Finset.univ f Finset.univ_nonempty
    have hub : expE p f ≤ C + f s₀ := by
      calc expE p f ≤ expE p (fun _ => f s₀ + C) :=
            expE_mono p (fun s => (hf s s₀).trans (by gcongr; exact hd s s₀))
        _ = f s₀ + C := expE_const p _
        _ = C + f s₀ := add_comm _ _
    have hlb : f s₀ ≤ expE q f := by
      calc f s₀ = expE q (fun _ => f s₀) := (expE_const q _).symm
        _ ≤ expE q f := expE_mono q (fun s => hs₀ s (Finset.mem_univ s))
    exact tsub_le_iff_right.mpr (hub.trans (by gcongr))
  unfold dualW1
  exact iSup₂_le fun f hf => sup_le (side p q f hf) (side q p f hf)

omit [Fintype α] in
/-- A `setoidDist`-Lipschitz observable is constant on classes. -/
theorem eq_of_rel_of_lip1 {r : Setoid α} {f : α → ℝ≥0∞} (hf : Lip1 (setoidDist r) f)
    {x y : α} (hxy : r x y) : f x = f y := by
  have h1 := hf x y
  have h2 := hf y x
  simp only [setoidDist, if_pos hxy, if_pos (r.iseqv.symm hxy), add_zero] at h1 h2
  exact le_antisymm h1 h2

end ProbabilityTheory.FintypePMF
