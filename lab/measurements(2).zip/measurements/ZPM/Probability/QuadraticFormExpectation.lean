/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import Mathlib.Probability.Moments.CovarianceBilin
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Data.Matrix.Mul

/-!
# Expectation of a quadratic form as a covariance trace

For a finite second-moment measure `ν` on `EuclideanSpace ℝ ι` with mean `m = ∫ z ∂ν` and a fixed
matrix `A`, the average of the quadratic form `(y - m)ᵀ A (y - m)` is the trace of `A` against the
covariance matrix of `ν`:

`∫ y, (y - m) ⬝ᵥ A *ᵥ (y - m) ∂ν = ∑ i, ∑ j, A i j * covarianceBilin ν eᵢ eⱼ = (A * covMatrix ν).trace`,

where `eᵢ = EuclideanSpace.basisFun ι ℝ i` and `covMatrix ν` is the Gram matrix of the covariance
bilinear form `ProbabilityTheory.covarianceBilin` in the standard basis.

The proof expands the quadratic form coordinatewise (`Matrix.dot_mulVec_eq_sum_sum`), identifies
each coordinate with an inner product against a basis vector (`EuclideanSpace.inner_basisFun_real`),
pushes the integral through the resulting finite double sum (`MeasureTheory.integral_finset_sum`,
with each cross term integrable as a product of two `L²` functions,
`MeasureTheory.MemLp.integrable_mul`), and reads off each term as a covariance
(`ProbabilityTheory.covarianceBilin_apply`). The trace form then follows from the symmetry of the
covariance (`ProbabilityTheory.covarianceBilin_comm`).

This is the expectation-of-a-quadratic-form identity `E[(X - E X)ᵀ A (X - E X)] = tr(A · Cov X)`, a
standard fact of multivariate probability that Mathlib does not yet record. It is the analytic core
of the Gaussian PAC-privacy log-det surrogate (Xiao-Devadas, arXiv:2210.03458): integrating the
per-sample multivariate Gaussian KL closed form over the data distribution turns its mean term into
`tr((Σ + Σ_B)⁻¹ Σ)`.
-/

open MeasureTheory ProbabilityTheory Matrix WithLp

namespace ProbabilityTheory

variable {ι : Type*} [Fintype ι]

/-- The **covariance matrix** of a measure on `EuclideanSpace ℝ ι`: the Gram matrix of the
covariance bilinear form `covarianceBilin` in the standard basis,
`covMatrix ν i j = covarianceBilin ν eᵢ eⱼ`. -/
noncomputable def covMatrix (ν : Measure (EuclideanSpace ℝ ι)) : Matrix ι ι ℝ :=
  Matrix.of fun i j =>
    covarianceBilin ν (EuclideanSpace.basisFun ι ℝ i) (EuclideanSpace.basisFun ι ℝ j)

@[simp] lemma covMatrix_apply (ν : Measure (EuclideanSpace ℝ ι)) (i j : ι) :
    covMatrix ν i j =
      covarianceBilin ν (EuclideanSpace.basisFun ι ℝ i) (EuclideanSpace.basisFun ι ℝ j) :=
  rfl

/-- `covMatrix` is symmetric: the covariance bilinear form is symmetric
(`ProbabilityTheory.covarianceBilin_comm`). -/
lemma covMatrix_transpose (ν : Measure (EuclideanSpace ℝ ι)) : (covMatrix ν)ᵀ = covMatrix ν := by
  ext i j
  simp only [Matrix.transpose_apply, covMatrix_apply, covarianceBilin_comm]

/-- **`covMatrix` is positive semidefinite.** Its quadratic form on a vector `v` is the covariance
bilinear form evaluated on `∑ᵢ vᵢ eᵢ`, which is nonnegative (`isPosSemidef_covarianceBilin`). -/
lemma covMatrix_posSemidef (ν : Measure (EuclideanSpace ℝ ι)) : (covMatrix ν).PosSemidef := by
  refine Matrix.posSemidef_iff_dotProduct_mulVec.mpr ⟨?_, fun v => ?_⟩
  · show (covMatrix ν)ᴴ = covMatrix ν
    ext i j
    simp only [Matrix.conjTranspose_apply, star_trivial, covMatrix_apply, covarianceBilin_comm]
  · -- The quadratic form equals `covarianceBilin ν w w` for `w = ∑ᵢ vᵢ eᵢ`, hence is nonnegative.
    set w : EuclideanSpace ℝ ι := ∑ i, v i • EuclideanSpace.basisFun ι ℝ i with hw
    have hbil : ∀ u : EuclideanSpace ℝ ι, (covarianceBilin ν) w u
        = ∑ i, v i * (covarianceBilin ν) (EuclideanSpace.basisFun ι ℝ i) u := fun u => by
      rw [hw, map_sum, _root_.sum_apply]
      exact Finset.sum_congr rfl fun i _ => by
        rw [map_smul, _root_.smul_apply, smul_eq_mul]
    have hww : (covarianceBilin ν) w w
        = ∑ i, ∑ j, v i * v j *
            covarianceBilin ν (EuclideanSpace.basisFun ι ℝ i) (EuclideanSpace.basisFun ι ℝ j) := by
      rw [hbil]
      refine Finset.sum_congr rfl fun i _ => ?_
      rw [hw, map_sum, Finset.mul_sum]
      exact Finset.sum_congr rfl fun j _ => by rw [map_smul, smul_eq_mul, mul_assoc]
    have hnn := (isPosSemidef_covarianceBilin (μ := ν)).isNonneg.nonneg w
    rw [ContinuousLinearMap.toBilinForm_apply, hww] at hnn
    rw [Matrix.dot_mulVec_eq_sum_sum, Finset.sum_comm]
    refine hnn.trans_eq (Finset.sum_congr rfl fun i _ => Finset.sum_congr rfl fun j _ => ?_)
    rw [Pi.star_apply, star_trivial, covMatrix_apply]; ring

/-- **The centred coordinate cross term is a covariance.** For each pair of basis directions,
the average product of the two centred coordinates is the covariance bilinear form evaluated on the
two basis vectors. This is `covarianceBilin_apply` read from the integral back to the covariance,
after rewriting the integrand's inner products as coordinates. -/
private lemma integral_coord_mul_coord_eq_covarianceBilin
    (ν : Measure (EuclideanSpace ℝ ι)) [IsFiniteMeasure ν] (hν : MemLp id 2 ν) (i j : ι) :
    ∫ y, inner ℝ (EuclideanSpace.basisFun ι ℝ i) (y - ∫ z, z ∂ν)
        * inner ℝ (EuclideanSpace.basisFun ι ℝ j) (y - ∫ z, z ∂ν) ∂ν
      = covarianceBilin ν (EuclideanSpace.basisFun ι ℝ i) (EuclideanSpace.basisFun ι ℝ j) := by
  rw [covarianceBilin_apply hν]
  simp only [id_eq]

/-- **Expectation of a quadratic form as a sum of covariances.** For `ν` with finite second moment
on `EuclideanSpace ℝ ι` and mean `m = ∫ z ∂ν`, the average of the quadratic form
`(y - m) ⬝ᵥ A *ᵥ (y - m)` is `∑ i j, A i j * covarianceBilin ν eᵢ eⱼ`. -/
theorem integral_dotProduct_mulVec_sub_integral_eq_sum_covarianceBilin
    (ν : Measure (EuclideanSpace ℝ ι)) [IsFiniteMeasure ν] (hν : MemLp id 2 ν)
    (A : Matrix ι ι ℝ) :
    ∫ y, (y - ∫ z, z ∂ν) ⬝ᵥ A *ᵥ (y - ∫ z, z ∂ν) ∂ν
      = ∑ i, ∑ j, A i j *
          covarianceBilin ν (EuclideanSpace.basisFun ι ℝ i) (EuclideanSpace.basisFun ι ℝ j) := by
  -- Each centred coordinate functional `y ↦ ⟪eᵢ, y - m⟫` is `L²`, so each cross term is integrable.
  have hmemLp : ∀ i, MemLp (fun y => inner ℝ (EuclideanSpace.basisFun ι ℝ i) (y - ∫ z, z ∂ν)) 2 ν :=
    fun i => MemLp.const_inner _ (hν.sub (memLp_const (∫ z, z ∂ν)))
  have hint : ∀ i j, Integrable (fun y =>
      inner ℝ (EuclideanSpace.basisFun ι ℝ i) (y - ∫ z, z ∂ν)
        * inner ℝ (EuclideanSpace.basisFun ι ℝ j) (y - ∫ z, z ∂ν)) ν :=
    fun i j => (hmemLp i).integrable_mul (hmemLp j)
  -- Expand the quadratic form into the finite double sum of coordinate products.
  have hquad : ∀ y : EuclideanSpace ℝ ι,
      (y - ∫ z, z ∂ν) ⬝ᵥ A *ᵥ (y - ∫ z, z ∂ν)
        = ∑ i, ∑ j, A i j * (inner ℝ (EuclideanSpace.basisFun ι ℝ i) (y - ∫ z, z ∂ν)
            * inner ℝ (EuclideanSpace.basisFun ι ℝ j) (y - ∫ z, z ∂ν)) := by
    intro y
    rw [Matrix.dot_mulVec_eq_sum_sum, Finset.sum_comm]
    refine Finset.sum_congr rfl fun i _ => Finset.sum_congr rfl fun j _ => ?_
    rw [real_inner_comm (y - ∫ z, z ∂ν) (EuclideanSpace.basisFun ι ℝ i),
      real_inner_comm (y - ∫ z, z ∂ν) (EuclideanSpace.basisFun ι ℝ j),
      EuclideanSpace.inner_basisFun_real, EuclideanSpace.inner_basisFun_real]
    simp only [WithLp.ofLp_sub, Pi.sub_apply]
    ring
  -- Push the integral through the double sum and identify each term as a covariance.
  rw [integral_congr_ae (Filter.Eventually.of_forall hquad),
    integral_finsetSum _ fun i _ =>
      integrable_finsetSum _ fun j _ => (hint i j).const_mul (A i j)]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [integral_finsetSum _ fun j _ => (hint i j).const_mul (A i j)]
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [integral_const_mul, integral_coord_mul_coord_eq_covarianceBilin ν hν i j]

/-- **Expectation of a quadratic form as a covariance trace** (`E[(X - E X)ᵀ A (X - E X)] =
tr(A · Cov X)`). For `ν` with finite second moment on `EuclideanSpace ℝ ι` and mean `m = ∫ z ∂ν`,
`∫ y, (y - m) ⬝ᵥ A *ᵥ (y - m) ∂ν = (A * covMatrix ν).trace`. -/
theorem integral_dotProduct_mulVec_sub_integral_eq_trace_covMatrix
    (ν : Measure (EuclideanSpace ℝ ι)) [IsFiniteMeasure ν] (hν : MemLp id 2 ν)
    (A : Matrix ι ι ℝ) :
    ∫ y, (y - ∫ z, z ∂ν) ⬝ᵥ A *ᵥ (y - ∫ z, z ∂ν) ∂ν = (A * covMatrix ν).trace := by
  rw [integral_dotProduct_mulVec_sub_integral_eq_sum_covarianceBilin ν hν A]
  simp only [Matrix.trace, Matrix.diag_apply, Matrix.mul_apply, covMatrix_apply]
  exact Finset.sum_congr rfl fun i _ =>
    Finset.sum_congr rfl fun j _ => by rw [covarianceBilin_comm]

/-- **Integrability of the quadratic form.** For `ν` with finite second moment, the quadratic form
`y ↦ (y − m) ⬝ᵥ A *ᵥ (y − m)` is integrable: expanded coordinatewise it is a finite sum of products
of two `L²` functions. -/
theorem integrable_dotProduct_mulVec_sub_integral
    (ν : Measure (EuclideanSpace ℝ ι)) [IsFiniteMeasure ν] (hν : MemLp id 2 ν)
    (A : Matrix ι ι ℝ) :
    Integrable (fun y : EuclideanSpace ℝ ι => (y - ∫ z, z ∂ν) ⬝ᵥ A *ᵥ (y - ∫ z, z ∂ν)) ν := by
  have hmemLp : ∀ i, MemLp (fun y => inner ℝ (EuclideanSpace.basisFun ι ℝ i) (y - ∫ z, z ∂ν)) 2 ν :=
    fun i => MemLp.const_inner _ (hν.sub (memLp_const (∫ z, z ∂ν)))
  have hint : ∀ i j, Integrable (fun y =>
      inner ℝ (EuclideanSpace.basisFun ι ℝ i) (y - ∫ z, z ∂ν)
        * inner ℝ (EuclideanSpace.basisFun ι ℝ j) (y - ∫ z, z ∂ν)) ν :=
    fun i j => (hmemLp i).integrable_mul (hmemLp j)
  have hquad : ∀ y : EuclideanSpace ℝ ι,
      (y - ∫ z, z ∂ν) ⬝ᵥ A *ᵥ (y - ∫ z, z ∂ν)
        = ∑ i, ∑ j, A i j * (inner ℝ (EuclideanSpace.basisFun ι ℝ i) (y - ∫ z, z ∂ν)
            * inner ℝ (EuclideanSpace.basisFun ι ℝ j) (y - ∫ z, z ∂ν)) := by
    intro y
    rw [Matrix.dot_mulVec_eq_sum_sum, Finset.sum_comm]
    refine Finset.sum_congr rfl fun i _ => Finset.sum_congr rfl fun j _ => ?_
    rw [real_inner_comm (y - ∫ z, z ∂ν) (EuclideanSpace.basisFun ι ℝ i),
      real_inner_comm (y - ∫ z, z ∂ν) (EuclideanSpace.basisFun ι ℝ j),
      EuclideanSpace.inner_basisFun_real, EuclideanSpace.inner_basisFun_real]
    simp only [WithLp.ofLp_sub, Pi.sub_apply]
    ring
  exact (integrable_finsetSum _ fun i _ => integrable_finsetSum _ fun j _ =>
    (hint i j).const_mul (A i j)).congr (Filter.Eventually.of_forall fun y => (hquad y).symm)

end ProbabilityTheory
