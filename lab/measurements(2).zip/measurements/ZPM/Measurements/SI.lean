/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.SI.Scheme
import ZPM.Measurements.SI.Conjectures
import ZPM.Measurements.SI.DefectTwist

/-!
# Structural ignorance

`Scheme` carries the compression grammar over an arbitrary class: realizable
samples, residuals, kernel schemes and their side-information price, window
traces, shattering and VC bounds. `Conjectures` states the open targets.
`DefectTwist` holds the defect and twist formalizations and the compression
results they reach.
-/
