/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.CechCycle
import ZPM.Measurements.HC.AffineEngine

/-!
# The general-cover Čech machinery: the base-measurement instrument at full generality

This is the proof instrument of maximal generality for the base claims, banked: the
general-cover form of the machinery the cycle files ran at one nerve. Over ANY finite-team
cover of ANY site type, the base structure being measured is the geometry of the cover. The
degree-1 Čech data of the parity local system is the INCIDENCE complex (site cochains → team
cochains by team parity, `parityOn`; for graph covers this is the simplicial `δ⁰` of the
nerve), and the base geometry that governs everything is the space of EVEN SUBCOVERS
(subfamilies covering every site an even number of times, `xorSum D = ∅`; the 1-cycles of
the incidence complex, the cycle space of the nerve graph). The Fredholm alternative is the
instrument that reads the verdict off that geometry: a twist admits a global section iff it
annihilates every even subcover (`exists_section_iff_even_orthogonal`). The computation
CONSUMES the banked Gaussian elimination core of the affine engine (`exists_parity_solution`,
AffineEngine.lean); this file is its Čech presentation, not a re-derivation. The
Čech-cohomological reading of contextuality is Abramsky–Brandenburger (NJP 13 (2011) 113036)
and Abramsky–Mansfield–Barbosa (QPL 2011, EPTCS 95; arXiv:1111.3620); Vorob'ev (Theory Probab. Appl. 7, 1962) is the
extendability formulation.

* **The support (base) stratum at full generality** (`parityFamG_joinFam_nonempty_iff`):
  over ANY cover the base geometry decides gluing. The twisted parity family glues iff its
  twist is orthogonal to every even subcover; `parityBox_joinFam_empty_iff` (CechCycle) is
  the 4-cycle instance.
* **The information stratum at full generality** (`corrT`, `evenSubcover_bound`,
  `evenSubcover_bound_attained`): the base geometry dictates what every fibre-side law may
  do. For every even subcover `D` and twist pairing oddly with it, EVERY global law obeys
  `∑_{T ∈ D} corrT ≤ |D| − 2` (the cycle inequalities, Barahona–Mahjoub, Math. Programming
  36 (1986), at hypergraph generality); for realizable twists the deterministic sections
  attain `|D|`. The facet system of the marginal polytope is graded by the base's
  even-subcover pairing, non-vacuously both ways. The bound quantifies over `D` alone, so
  facets are automatically stable under enlarging the cover.
* **The derivation instances**: the 4-cycle (`chshCover_section_iff`, re-deriving the
  banked holonomy criterion from the general theorem), the Specker triangle
  (`specker_odd_no_section`: the `HigherObstruction` acceptance test discharged
  cohomologically), the n-cycle for every `n` (`nCycle_section_iff`: gluing iff the twist
  sums to zero, backward direction constructive by prefix sums).
* **The functor leg** (`section_iff_of_equiv`): the base realizability verdict transports
  along arbitrary site equivalences. Honest scope: equivariance and subcover-stability are
  banked; the categorical Čech functor over non-invertible cover morphisms and degrees ≥ 2
  are the NEXT rung, stated not claimed.
-/

namespace HiddenChannelCapacity

open Finset

variable {ι : Type*} [DecidableEq ι]

/-! ### The core instrument: the degree-1 obstruction by the Fredholm alternative -/

private lemma sum_toFinset_of_nodup {l : List (Finset ι)} (h : l.Nodup)
    (t : Finset ι → ZMod 2) : ∑ T ∈ l.toFinset, t T = (l.map t).sum := by
  induction l with
  | nil => simp
  | cons a l ih =>
      rw [List.toFinset_cons, List.map_cons, List.sum_cons,
        Finset.sum_insert (by
          rw [List.mem_toFinset]
          exact (List.nodup_cons.mp h).1),
        ih (List.nodup_cons.mp h).2]

/-- **The Fredholm alternative for the incidence Čech complex: the base-measurement
instrument.** A twist prescription on a cover admits a global section iff it annihilates
every even subcover (`xorSum D = ∅`: every site covered an even number of times, the
1-cycles of the incidence complex; for graph covers, the nerve's cycle space). Forward:
parities telescope along even subcovers (`parityOn_xorSum`). Backward: the banked Gaussian
elimination (`exists_parity_solution`). Cycle-orthogonality against the base geometry is
the verdict: the general-cover computation of the degree-1 obstruction. -/
theorem exists_section_iff_even_orthogonal (cover : Finset (Finset ι))
    (t : Finset ι → ZMod 2) :
    (∃ x : ι → ZMod 2, ∀ T ∈ cover, parityOn T x = t T) ↔
      (∀ D ⊆ cover, xorSum D = ∅ → ∑ T ∈ D, t T = 0) := by
  constructor
  · rintro ⟨x, hx⟩ D hD hxor
    have hsum : ∑ T ∈ D, t T = ∑ T ∈ D, parityOn T x :=
      Finset.sum_congr rfl fun T hT => (hx T (hD hT)).symm
    rw [hsum, ← parityOn_xorSum, hxor]
    simp [parityOn]
  · intro horth
    obtain ⟨f, hf⟩ := exists_parity_solution
      (cover.toList.map (fun T => (T, t T)))
      (by
        intro sub hsub hxor
        obtain ⟨l', hl', rfl⟩ := List.sublist_map_iff.mp hsub
        have hnodup : l'.Nodup := hl'.nodup cover.nodup_toList
        have hfst : (l'.map (fun T => (T, t T))).map Prod.fst = l' := by
          rw [List.map_map]
          exact List.map_id'' (fun _ => rfl) l'
        rw [hfst, xorSumL_eq_xorSum hnodup] at hxor
        have hsnd : (l'.map (fun T => (T, t T))).map Prod.snd = l'.map t := by
          rw [List.map_map]
          rfl
        have hsub' : l'.toFinset ⊆ cover := fun T hT => by
          rw [List.mem_toFinset] at hT
          exact Finset.mem_toList.mp (hl'.mem hT)
        rw [hsnd, ← sum_toFinset_of_nodup hnodup t]
        exact horth l'.toFinset hsub' hxor)
    exact ⟨f, fun T hT => hf (T, t T) (List.mem_map_of_mem (Finset.mem_toList.mpr hT))⟩

/-! ### The support stratum at full generality -/

/-- The general parity support on a team: configurations of prescribed total parity
(the PRBox `prRel` at arbitrary sites). -/
def prRelG (T : Finset ι) (c : ZMod 2) : Finset (∀ _i : (T : Finset ι), ZMod 2) :=
  Finset.univ.filter (fun g => (∑ i, g i) = c)

/-- The twisted parity family over an arbitrary cover (team-indexed possibilistic
family; `parityBox` of CechCycle is the 4-cycle instance). -/
noncomputable def parityFamG (cover : Finset (Finset ι)) (t : Finset ι → ZMod 2) :
    List (LocalStruct ι (fun _ => ZMod 2)) :=
  cover.toList.map (fun T => ⟨T, prRelG T (t T)⟩)

omit [DecidableEq ι] in
/-- Restricted parity is team parity. -/
lemma restrict_parity_general (T : Finset ι) (x : ι → ZMod 2) :
    (∑ i, (T.restrict x) i) = parityOn T x :=
  Finset.sum_coe_sort T x

/-- **The support (base) stratum IS the degree-1 obstruction, over every cover**: the base
geometry decides gluing. The twisted parity family glues (nonempty join) iff its twist
annihilates every even subcover. -/
theorem parityFamG_joinFam_nonempty_iff [Fintype ι] (cover : Finset (Finset ι))
    (t : Finset ι → ZMod 2) :
    (joinFam (parityFamG cover t)).Nonempty ↔
      (∀ D ⊆ cover, xorSum D = ∅ → ∑ T ∈ D, t T = 0) := by
  rw [← exists_section_iff_even_orthogonal]
  constructor
  · rintro ⟨x, hx⟩
    rw [mem_joinFam] at hx
    refine ⟨x, fun T hT => ?_⟩
    have hmem := hx ⟨T, prRelG T (t T)⟩
      (by
        rw [parityFamG, List.mem_map]
        exact ⟨T, Finset.mem_toList.mpr hT, rfl⟩)
    rw [prRelG, Finset.mem_filter] at hmem
    rw [← restrict_parity_general T x]
    exact hmem.2
  · rintro ⟨x, hx⟩
    refine ⟨x, mem_joinFam.mpr fun L hL => ?_⟩
    rw [parityFamG, List.mem_map] at hL
    obtain ⟨T, hT, rfl⟩ := hL
    rw [prRelG, Finset.mem_filter]
    exact ⟨Finset.mem_univ _,
      (restrict_parity_general T x).trans (hx T (Finset.mem_toList.mp hT))⟩

/-! ### The information stratum at full generality -/

/-- The parity correlation of a team-carrier law against a reference value: mass of
prescribed parity minus mass of the opposite (the general form of the cycle files'
`corrE`). -/
noncomputable def corrT {T : Finset ι} (c : ZMod 2)
    (p : ProbDistribution (∀ _i : (T : Finset ι), ZMod 2)) : ℝ :=
  ∑ g, (p g : ℝ) * (if (∑ i, g i) = c then 1 else -1)

/-- Correlation pull-back over an arbitrary team. -/
lemma corrT_marginal [Fintype ι] (q : ProbDistribution (∀ _i : ι, ZMod 2))
    (T : Finset ι) (c : ZMod 2) :
    corrT c (q.marginal T)
      = ∑ x, (q x : ℝ) * (if parityOn T x = c then 1 else -1) := by
  unfold corrT
  have hsplit : ∀ g, ((q.marginal T) g : ℝ)
      * (if (∑ i, g i) = c then (1:ℝ) else -1)
      = ∑ f ∈ Finset.univ.filter (fun f => T.restrict f = g),
          (q f : ℝ) * (if parityOn T f = c then (1:ℝ) else -1) := by
    intro g
    rw [ProbDistribution.marginal_coe, Finset.sum_mul]
    refine Finset.sum_congr rfl fun f hf => ?_
    have hres : T.restrict f = g := (Finset.mem_filter.mp hf).2
    rw [← hres, restrict_parity_general]
  rw [Finset.sum_congr rfl fun g _ => hsplit g]
  exact Finset.sum_fiberwise Finset.univ (fun f => T.restrict f)
    (fun f => (q f : ℝ) * (if parityOn T f = c then (1:ℝ) else -1))

/-- **The general facet system, graded by the base's even-subcover geometry**: the base
dictates the fibre-side constraint. For every even subcover `D` and twist pairing oddly
with it, every global law satisfies the cycle inequality `∑_{T ∈ D} corrT ≤ |D| − 2`.
Pointwise core: parities telescope to zero along `D`, so any global configuration disagrees
with an odd-paired twist an odd (hence positive) number of times on `D`. -/
theorem evenSubcover_bound [Fintype ι] (D : Finset (Finset ι)) (hxor : xorSum D = ∅)
    (t : Finset ι → ZMod 2) (hodd : ∑ T ∈ D, t T = 1)
    (q : ProbDistribution (∀ _i : ι, ZMod 2)) :
    (∑ T ∈ D, corrT (t T) (q.marginal T)) ≤ (D.card : ℝ) - 2 := by
  rw [Finset.sum_congr rfl fun T _ => corrT_marginal q T (t T), Finset.sum_comm]
  have hpt : ∀ x : ι → ZMod 2,
      (∑ T ∈ D, (q x : ℝ) * (if parityOn T x = t T then 1 else -1))
        ≤ (q x : ℝ) * ((D.card : ℝ) - 2) := by
    intro x
    rw [← Finset.mul_sum]
    refine mul_le_mul_of_nonneg_left ?_ Prob.zero_le_coe
    set dis := (D.filter (fun T => parityOn T x ≠ t T)).card with hdis
    have hterm : ∀ T ∈ D, (if parityOn T x ≠ t T then (1 : ZMod 2) else 0)
        = parityOn T x + t T := by
      intro T _
      by_cases h : parityOn T x = t T
      · rw [if_neg (by simpa using h), h]
        exact ((by decide : ∀ a : ZMod 2, (0 : ZMod 2) = a + a) (t T))
      · rw [if_pos h]
        exact ((by decide : ∀ a b : ZMod 2, ¬a = b → (1 : ZMod 2) = a + b)
          _ _ h)
    have hodd' : ((dis : ℕ) : ZMod 2) = 1 := by
      rw [hdis, ← Finset.sum_boole (fun T => parityOn T x ≠ t T) D,
        Finset.sum_congr rfl hterm, Finset.sum_add_distrib,
        ← parityOn_xorSum, hxor, hodd]
      simp [parityOn]
    have hge : 1 ≤ dis := by
      rcases Nat.eq_zero_or_pos dis with h0 | h1
      · rw [h0] at hodd'
        simp at hodd'
      · exact h1
    have hsum : (∑ T ∈ D, (if parityOn T x = t T then (1:ℝ) else -1))
        = (D.card : ℝ) - 2 * (dis : ℝ) := by
      have hterm : ∀ T ∈ D, (if parityOn T x = t T then (1:ℝ) else -1)
          = 1 - 2 * (if parityOn T x ≠ t T then (1:ℝ) else 0) := by
        intro T _
        by_cases h : parityOn T x = t T
        · rw [if_pos h, if_neg (by simpa using h)]
          ring
        · rw [if_neg h, if_pos h]
          ring
      rw [Finset.sum_congr rfl hterm, Finset.sum_sub_distrib, ← Finset.mul_sum,
        Finset.sum_boole, Finset.sum_const, nsmul_eq_mul, mul_one, hdis]
    rw [hsum]
    have h1 : (1 : ℝ) ≤ (dis : ℝ) := by exact_mod_cast hge
    linarith
  calc ∑ x, ∑ T ∈ D, (q x : ℝ) * (if parityOn T x = t T then 1 else -1)
      ≤ ∑ x, (q x : ℝ) * ((D.card : ℝ) - 2) := Finset.sum_le_sum fun x _ => hpt x
    _ = (D.card : ℝ) - 2 := by
        rw [← Finset.sum_mul, q.normalized, one_mul]

/-- **Sharpness: the grading is non-vacuous.** Whenever the twist is realized by a section
on `D`, the deterministic law attains `|D|`. With `evenSubcover_bound`: the facet binds
exactly the odd-paired twists. -/
theorem evenSubcover_bound_attained [Fintype ι] (D : Finset (Finset ι))
    (t : Finset ι → ZMod 2) (x₀ : ι → ZMod 2) (hx₀ : ∀ T ∈ D, parityOn T x₀ = t T) :
    (∑ T ∈ D, corrT (t T) ((ProbDistribution.constant x₀).marginal T)) = D.card := by
  have hval : ∀ y : ι → ZMod 2, ((ProbDistribution.constant x₀) y : ℝ)
      = if x₀ = y then 1 else 0 := by
    intro y
    by_cases h : x₀ = y
    · rw [if_pos h]
      show (((ProbDistribution.constant x₀) y : Prob) : ℝ) = 1
      rw [congrFun (ProbDistribution.constant_def x₀) y, if_pos h]
      rfl
    · rw [if_neg h]
      show (((ProbDistribution.constant x₀) y : Prob) : ℝ) = 0
      rw [congrFun (ProbDistribution.constant_def x₀) y, if_neg h]
      rfl
  have hcorr : ∀ T ∈ D, corrT (t T) ((ProbDistribution.constant x₀).marginal T) = 1 := by
    intro T hT
    rw [corrT_marginal]
    rw [Finset.sum_congr rfl fun y _ => (by rw [hval y] :
      ((ProbDistribution.constant x₀) y : ℝ)
          * (if parityOn T y = t T then (1:ℝ) else -1)
        = (if x₀ = y then (1:ℝ) else 0)
          * (if parityOn T y = t T then (1:ℝ) else -1))]
    rw [Finset.sum_congr rfl fun y _ => (by split_ifs <;> ring :
      (if x₀ = y then (1:ℝ) else 0)
          * (if parityOn T y = t T then (1:ℝ) else -1)
        = if x₀ = y then (if parityOn T y = t T then (1:ℝ) else -1) else 0),
      Finset.sum_ite_eq Finset.univ x₀
        (fun y => if parityOn T y = t T then (1:ℝ) else -1),
      if_pos (Finset.mem_univ _), if_pos (hx₀ T hT)]
  rw [Finset.sum_congr rfl hcorr, Finset.sum_const, nsmul_eq_mul, mul_one]

end HiddenChannelCapacity

/-! ### The derivation instances and the functor leg -/

namespace HiddenChannelCapacity

open Finset

variable {ι : Type*} [DecidableEq ι]

/-- The Specker triangle: three pairwise-overlapping contexts on three sites. -/
def speckerCover : Finset (Finset (Fin 3)) := {{0, 1}, {1, 2}, {0, 2}}

theorem specker_all_even : xorSum speckerCover = ∅ := by decide

/-- **The Specker acceptance test, discharged cohomologically**: any odd twist on the
triangle is killed by the full even subcover, the `HigherObstruction` acceptance
phenomenon (the Specker triangle's failure to amalgamate) read as an evaluation of the
base's degree-1 obstruction. -/
theorem specker_odd_no_section (t : Finset (Fin 3) → ZMod 2)
    (hodd : (∑ T ∈ speckerCover, t T) = 1) :
    ¬ ∃ x : Fin 3 → ZMod 2, ∀ T ∈ speckerCover, parityOn T x = t T := by
  rw [exists_section_iff_even_orthogonal]
  intro h
  have h0 := h speckerCover (subset_refl _) specker_all_even
  rw [h0] at hodd
  exact absurd hodd (by decide)

/-- **The functor leg: equivariance.** The base realizability verdict transports along any
site equivalence, cover and twist transported by images. -/
theorem section_iff_of_equiv {ι' : Type*} [DecidableEq ι'] (e : ι ≃ ι')
    (cover : Finset (Finset ι)) (t : Finset ι → ZMod 2) :
    (∃ x : ι → ZMod 2, ∀ T ∈ cover, parityOn T x = t T) ↔
      (∃ x' : ι' → ZMod 2, ∀ T' ∈ cover.image (Finset.image e),
        parityOn T' x' = t (T'.image e.symm)) := by
  have himg : ∀ T : Finset ι, (T.image e).image e.symm = T := by
    intro T
    rw [Finset.image_image]
    simp
  constructor
  · rintro ⟨x, hx⟩
    refine ⟨fun i' => x (e.symm i'), fun T' hT' => ?_⟩
    obtain ⟨T, hT, rfl⟩ := Finset.mem_image.mp hT'
    rw [himg]
    rw [show parityOn (T.image e) (fun i' => x (e.symm i'))
        = parityOn T x from by
      unfold parityOn
      rw [Finset.sum_image (fun a _ b _ h => e.injective h)]
      exact Finset.sum_congr rfl fun i _ => by rw [Equiv.symm_apply_apply]]
    exact hx T hT
  · rintro ⟨x', hx'⟩
    refine ⟨fun i => x' (e i), fun T hT => ?_⟩
    have h1 := hx' (T.image e) (Finset.mem_image_of_mem _ hT)
    rw [himg] at h1
    rw [← h1]
    unfold parityOn
    rw [Finset.sum_image (fun a _ b _ h => e.injective h)]

/-- **The n-cycle instance, every arity**: on the cycle cover over `Fin (n + 2)` the
twisted parity family has a section iff the twist sums to zero, the arity-general holonomy
criterion. Backward direction constructive: prefix sums of the twist. -/
theorem nCycle_section_iff (n : ℕ) (t : Fin (n + 2) → ZMod 2) :
    (∃ x : Fin (n + 2) → ZMod 2, ∀ j : Fin (n + 2), parityOn {j, j + 1} x = t j) ↔
      (∑ j, t j) = 0 := by
  have hne : ∀ j : Fin (n + 2), j ≠ j + 1 := by
    intro j h
    have hval := congrArg Fin.val h
    rw [Fin.val_add_one] at hval
    split_ifs at hval with hl
    · subst hl
      simp [Fin.last] at hval
    · omega
  constructor
  · rintro ⟨x, hx⟩
    have hsum : (∑ j, t j) = ∑ j : Fin (n + 2), (x j + x (j + 1)) := by
      refine Finset.sum_congr rfl fun j _ => ?_
      rw [← hx j, parityOn, Finset.sum_pair (hne j)]
    rw [hsum, Finset.sum_add_distrib,
      show (∑ j : Fin (n + 2), x (j + 1)) = ∑ j, x j from
        Equiv.sum_comp (Equiv.addRight (1 : Fin (n + 2))) x]
    exact (by decide : ∀ a : ZMod 2, a + a = 0) _
  · intro hsum
    refine ⟨fun j => ∑ k ∈ Finset.univ.filter (fun k : Fin (n + 2) => k < j), t k,
      fun j => ?_⟩
    rw [parityOn, Finset.sum_pair (hne j)]
    by_cases hlast : j = Fin.last (n + 1)
    · have hj1 : j + 1 = 0 := by
        subst hlast
        exact Fin.last_add_one _
      have hx0 : (∑ k ∈ Finset.univ.filter (fun k : Fin (n + 2) => k < 0), t k)
          = 0 := by
        rw [Finset.filter_false_of_mem (fun k _ => Fin.not_lt_zero k),
          Finset.sum_empty]
      rw [hj1, hx0, add_zero]
      have hsplit := Finset.sum_filter_add_sum_filter_not Finset.univ
        (fun k : Fin (n + 2) => k < j) t
      have hnotlt : Finset.univ.filter (fun k : Fin (n + 2) => ¬k < j) = {j} := by
        ext k
        simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_singleton,
          not_lt]
        constructor
        · intro h
          subst hlast
          exact le_antisymm (Fin.le_last k) h
        · rintro rfl
          exact le_refl _
      rw [hnotlt, Finset.sum_singleton, hsum] at hsplit
      exact (by decide : ∀ a b : ZMod 2, a + b = 0 → a = b) _ _ hsplit
    · have hfil : Finset.univ.filter (fun k : Fin (n + 2) => k < j + 1)
          = insert j (Finset.univ.filter (fun k : Fin (n + 2) => k < j)) := by
        ext k
        simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert]
        rw [Fin.lt_def, Fin.lt_def, Fin.val_add_one, if_neg hlast]
        constructor
        · intro h
          rcases Nat.lt_succ_iff_lt_or_eq.mp h with h | h
          · right
            exact h
          · left
            exact Fin.ext h
        · rintro (rfl | h)
          · exact Nat.lt_succ_self _
          · exact Nat.lt_succ_of_lt h
      rw [hfil, Finset.sum_insert (by
        rw [Finset.mem_filter]
        rintro ⟨-, hlt⟩
        exact absurd hlt (lt_irrefl j))]
      exact (by decide : ∀ a b : ZMod 2, a + (b + a) = b) _ _

/-- The CHSH cover is the 4-cycle's edge cover in team form. -/
lemma chshCover_eq_image :
    chshCover = Finset.univ.image (fun j : Fin 4 => ({j, j + 1} : Finset (Fin 4))) := by
  decide

/-- **The 4-cycle instance**: the banked holonomy criterion, re-derived. Forward: an
evaluation of the general Fredholm alternative at the full even subcover (the 4-cycle's
cycle space is one-dimensional, so this is the only nontrivial pairing). Backward: the
arity-general constructive section (`nCycle_section_iff` at `n = 2`). -/
theorem chshCover_section_iff (t : Finset (Fin 4) → ZMod 2) :
    (∃ x : Fin 4 → ZMod 2, ∀ T ∈ chshCover, parityOn T x = t T) ↔
      (∑ T ∈ chshCover, t T) = 0 := by
  have hbridge : (∑ T ∈ chshCover, t T) = ∑ j : Fin 4, t {j, j + 1} := by
    rw [chshCover_eq_image,
      Finset.sum_image (by decide :
        ∀ j₁ ∈ (Finset.univ : Finset (Fin 4)), ∀ j₂ ∈ Finset.univ,
          ({j₁, j₁ + 1} : Finset (Fin 4)) = {j₂, j₂ + 1} → j₁ = j₂)]
  constructor
  · intro h
    exact ((exists_section_iff_even_orthogonal chshCover t).mp h)
      chshCover (subset_refl _) (by decide : xorSum chshCover = ∅)
  · intro hsum
    obtain ⟨x, hx⟩ := (nCycle_section_iff 2 (fun j => t {j, j + 1})).mpr
      (by rw [← hbridge]; exact hsum)
    refine ⟨x, fun T hT => ?_⟩
    obtain ⟨j, rfl⟩ := (by decide :
      ∀ T ∈ chshCover, ∃ j : Fin 4, T = {j, j + 1}) T hT
    exact hx j

end HiddenChannelCapacity
