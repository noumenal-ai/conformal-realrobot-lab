/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.QJTOpenProblem
import ZPM.Measurements.HC.PRBox

/-!
# The Čech cohomology of the cycle cover: base structure, and the fibre moduli it fixes

HC is a measurement instrument for BASE structure: the cover and its geometry. This file
measures the base of the 4-cycle and reads off, from that base structure alone, what the
fibre-side laws (distributions, weights, quantum states over the contexts) can and cannot
do. It removes the interpretive gloss from the cohomological reading of the 4-cycle
obstruction: the Čech objects are first-class and every graded statement is witnessed
non-vacuously, at cycle-nerve scope (the general-cover simplicial nerve remains the
flagship rung, stated honestly below). The Čech vocabulary is the proof instrument of
maximal generality, never the claim itself; the claim runs base-to-fibre, from the
discovered cohomology of the cover to the facets and moduli of the information ends.

* **The base/fibre functor law** (`completion_gives_section`): over any sites, values,
  and teams, a fibre-side classical completion projects onto a global section of the base
  SUPPORT family. The banked `no_completionC_of_empty_join` is its contrapositive. Read
  base-first, this is the boundary as a functor law: a base obstruction (no section of the
  support family) forbids every fibre-side completion, so what the base forbids no
  information-fibre measurement can supply.
* **B3 closed** (`prBox_fibre_obstruction`): the base obstruction of the PR box governs
  the fibre. Any distribution family supported inside the possibilistic PR box (`prBox`,
  PRBox.lean) admits no classical completion, read directly off the banked base obstruction
  `joinFam prBox = ∅`, with no re-derivation.
* **H¹ of the cycle nerve, concretely** (`coboundary`, `holF2`): the base invariant,
  computed. The nerve of the 4-cycle cover has no 2-cells, so `C¹ = Z¹`; the coboundary
  `δ⁰ x = fun j => x j + x (j+1)` and the holonomy functional `hol t = ∑ j, t j` compute
  the cohomology: `holF2_coboundary` (hol ∘ δ = 0) and `coboundary_range` (im δ = ker hol)
  exhibit `H¹(nerve; F₂) ≅ F₂` with `hol` the isomorphism. This is the geometry of the
  cover; everything below reads off it.
* **The support (base) stratum is H¹** (`parityBox_joinFam_empty_iff`): the base gluing
  verdict is a cohomology class evaluated. The twisted parity family on the cycle has empty
  join precisely when its class is nonzero; `prBox = parityBox tw` (`prBox_eq_parityBox`)
  and `holF2 tw = 1` (`prBox_class_nonzero`), so `prBox_no_global_section` is the evaluation
  of a nonzero cohomology class (the Abramsky–Brandenburger sheaf reading of strong
  contextuality, NJP 13 (2011) 113036, made a computation).
* **The information stratum is graded by the base class** (`cycle_bound_gen`,
  `cycle_bound_fails_of_hol_zero`): the base cohomology class dictates what every fibre-side
  law may do. For EVERY nonzero-class representative `t`, every global law obeys the facet
  `∑ⱼ corrE (t j) ≤ 2` (the cycle inequalities of the cut polytope, Barahona–Mahjoub, Math.
  Programming 36 (1986) 157–173); for zero-class `t` the bound FAILS (a deterministic
  section attains 4). The facet system of the marginal polytope is indexed exactly by the
  nonzero cohomology classes of the base: the constraints on the fibre are read off the
  geometry of the cover.
* **The moduli, exact** (`mixDist`, `cycleFam_completable_iff`): reading the base class
  through real coefficients fixes the fibre-side moduli. The smoothed cycle family at
  parameter `r` is completable iff `1/4 ≤ r ≤ 3/4`: both facets for the forward direction,
  the one-formula disagreement-strata mixture for the backward. The same base class read
  with Boolean coefficients (the support stratum) resolves only the `r = 1` boundary; read
  with real coefficients (the information stratum) it carries exact moduli. The gap between
  the two readings is the kernel of the change of coefficients, and its extent is now
  kernel-verified.
-/

open scoped ComplexOrder

namespace HiddenChannelCapacity

/-! ### The base/fibre functor law and the B3 closure -/

variable {ι : Type*} [DecidableEq ι] {X : ι → Type*}
  [∀ i, Fintype (X i)] [∀ i, DecidableEq (X i)]

/-- **The base/fibre functor law**: a fibre-side classical completion projects to a
global section of the base support family; every team then sees positive mass on the
restriction of some single global configuration. Contrapositive of
`no_completionC_of_empty_join`: together they say the support functor carries fibre
completions down to base sections and base obstructions up to fibre obstructions, so a
base obstruction forbids every completion the fibre could supply. -/
theorem completion_gives_section {J : Type*} [Fintype ι] (team : J → Finset ι)
    (p : ∀ j, ProbDistribution (∀ i : (team j : Finset ι), X i))
    (q : ProbDistribution (∀ i, X i))
    (hq : IsCompletionC team p q) :
    ∃ x : (∀ i, X i), ∀ j, 0 < ((p j) ((team j).restrict x) : ℝ) := by
  have hex : ∃ x, 0 < (q x : ℝ) := by
    by_contra h
    have h' : ∀ x, (q x : ℝ) = 0 := fun x =>
      le_antisymm (not_lt.mp fun hx => h ⟨x, hx⟩) Prob.zero_le_coe
    have hsum := q.normalized
    rw [Finset.sum_congr rfl fun x _ => h' x] at hsum
    simp at hsum
  obtain ⟨x, hx⟩ := hex
  refine ⟨x, fun j => ?_⟩
  rw [← hq j, ProbDistribution.marginal_coe]
  refine lt_of_lt_of_le hx ?_
  refine Finset.single_le_sum (f := fun f => ((q f : ℝ)))
    (fun f _ => Prob.zero_le_coe) ?_
  rw [Finset.mem_filter]
  exact ⟨Finset.mem_univ _, rfl⟩

/-- The possibilistic PR box in team-indexed form. -/
lemma prBox_eq_parityBox :
    prBox = (List.finRange 4).map
      (fun j : Fin 4 => ⟨cyc j, prRel (cyc j) (tw j)⟩) :=
  rfl

/-- **B3 closed — the fibre obstruction over the banked base obstruction**: any
distribution family on the cycle cover supported inside the PR-box relations
(`prRel`, PRBox.lean) admits no classical completion. Route: the banked
`prBox_no_global_section` (`joinFam prBox = ∅`) forces every global configuration
outside some team's relation, so its mass vanishes there; the support lift
`no_completionC_of_empty_join` finishes. -/
theorem prBox_fibre_obstruction
    (p : ∀ j : Fin 4, ProbDistribution (∀ _i : (cyc j : Finset (Fin 4)), ZMod 2))
    (hsupp : ∀ j g, 0 < ((p j) g : ℝ) → g ∈ prRel (cyc j) (tw j)) :
    ¬ ∃ q, IsCompletionC (X := fun _ => ZMod 2) cyc p q := by
  refine no_completionC_of_empty_join (X := fun _ => ZMod 2) cyc p fun x => ?_
  have hnot : ¬ ∀ L ∈ prBox, (L.team).restrict x ∈ L.rel := by
    intro h
    have hmem := mem_joinFam.mpr h
    rw [prBox_no_global_section] at hmem
    exact absurd hmem (Finset.notMem_empty x)
  by_contra hall
  refine hnot fun L hL => ?_
  rw [prBox_eq_parityBox, List.mem_map] at hL
  obtain ⟨j, -, rfl⟩ := hL
  have hpos : 0 < ((p j) ((cyc j).restrict x) : ℝ) := by
    rcases lt_or_eq_of_le (Prob.zero_le_coe (p := (p j) ((cyc j).restrict x))) with h | h
    · exact h
    · exact absurd h.symm (fun hz => hall ⟨j, hz⟩)
  exact hsupp j _ hpos

/-- Quantum face of the B3 closure, through the quantization arrow: the same base
obstruction reaches the quantum fibre, forbidding any quantum completion of
classically-embedded PR-box-supported prescriptions. -/
theorem prBox_fibre_obstruction_quantum
    (p : ∀ j : Fin 4, ProbDistribution (∀ _i : (cyc j : Finset (Fin 4)), ZMod 2))
    (hsupp : ∀ j g, 0 < ((p j) g : ℝ) → g ∈ prRel (cyc j) (tw j)) :
    ¬ ∃ ω, IsCompletionQ (X := fun _ => ZMod 2) cyc
      (fun j => MState.ofClassical (p j)) ω := by
  rw [completionQ_diag_iff]
  exact prBox_fibre_obstruction p hsupp

/-! ### H¹ of the cycle nerve, concretely: the base invariant -/

/-- The Čech coboundary `δ⁰` of the cycle nerve: a 0-cochain (site assignment) maps to
the 1-cochain of its edge parities. The nerve has no 2-cells, so every 1-cochain is a
cocycle and `H¹ = C¹ / im δ⁰`. -/
def coboundary (x : ∀ _i : Fin 4, ZMod 2) : Fin 4 → ZMod 2 :=
  fun j => x j + x (j + 1)

/-- The holonomy functional on 1-cochains: the sum around the cycle. Descends to the
isomorphism `H¹(nerve; F₂) ≅ F₂` (`holF2_coboundary` + `coboundary_range`). -/
def holF2 (t : Fin 4 → ZMod 2) : ZMod 2 := ∑ j, t j

/-- CECH-1: the holonomy kills coboundaries (the telescope around the cycle). -/
theorem holF2_coboundary : ∀ x, holF2 (coboundary x) = 0 := by decide

/-- CECH-2 (exactness, the H¹ computation): the image of the coboundary is exactly the
kernel of the holonomy. With `holF2_coboundary` this exhibits
`H¹(cycle nerve; F₂) ≅ F₂`, the isomorphism induced by `holF2`. -/
theorem coboundary_range : ∀ t, (∃ x, coboundary x = t) ↔ holF2 t = 0 := by decide

/-- Parity of a restricted global configuration is its edge coboundary (bridges the
`prRel` sum convention to `coboundary`). -/
theorem restrict_parity :
    ∀ (j : Fin 4) (x : ∀ _i : Fin 4, ZMod 2),
      (∑ i, ((cyc j).restrict x) i) = coboundary x j := by
  decide

/-- The twisted parity family on the cycle cover (team-indexed possibilistic box;
`prBox = parityBox tw`). -/
def parityBox (t : Fin 4 → ZMod 2) : List (LocalStruct (Fin 4) (fun _ => ZMod 2)) :=
  (List.finRange 4).map (fun j : Fin 4 => ⟨cyc j, prRel (cyc j) (t j)⟩)

/-- **The support (base) stratum IS H¹**: the base gluing verdict is a cohomology class
evaluated. The twisted parity family has empty join (no global section: strong
contextuality in the Abramsky–Brandenburger sense) precisely when its twist class is
nonzero in `H¹(nerve; F₂)`. -/
theorem parityBox_joinFam_empty_iff :
    ∀ t, joinFam (parityBox t) = ∅ ↔ holF2 t = 1 := by
  decide

/-- The PR box class is the nonzero class. -/
theorem prBox_class_nonzero : holF2 tw = 1 := by decide

/-- `prBox_no_global_section`, re-derived as the evaluation of a nonzero cohomology
class: the banked possibilistic obstruction is a cohomological computation. -/
example : joinFam prBox = ∅ := by
  rw [prBox_eq_parityBox]
  exact (parityBox_joinFam_empty_iff tw).mpr prBox_class_nonzero

/-- Non-vacuity of the zero-class side: the untwisted family HAS a global section. -/
theorem parityBox_zero_glues : (joinFam (parityBox 0)).Nonempty := by decide

end HiddenChannelCapacity

/-! ### The information stratum, graded by the base class: the facet system -/

namespace HiddenChannelCapacity

/-- Disagreement count of a global configuration against an arbitrary 1-cochain
(generalizes the banked `disag = disagT tw`). -/
def disagT (t : Fin 4 → ZMod 2) (x : ∀ _i : Fin 4, ZMod 2) : ℕ :=
  (Finset.univ.filter (fun j : Fin 4 => x j + x (j + 1) ≠ t j)).card

/-- The kernel sign-product contradiction, graded by the class: a disagreement is
forced exactly for NONZERO-class cochains. -/
theorem one_le_disagT : ∀ t x, holF2 t = 1 → 1 ≤ disagT t x := by decide

/-- Flipping the reference parity flips the correlation. -/
lemma corrE_flip {j : Fin 4} (t : ZMod 2)
    (p : ProbDistribution (∀ _i : (cyc j : Finset (Fin 4)), ZMod 2)) :
    corrE (t + 1) p = -corrE t p := by
  unfold corrE
  rw [← Finset.sum_neg_distrib]
  refine Finset.sum_congr rfl fun g _ => ?_
  by_cases h : (pairEquiv j g).1 + (pairEquiv j g).2 = t
  · rw [if_neg (by rw [h]; exact (by decide : ∀ u : ZMod 2, u ≠ u + 1) t), if_pos h]
    ring
  · rw [if_pos ((by decide : ∀ u v : ZMod 2, ¬u = v → u = v + 1) _ (t) h), if_neg h]
    ring

/-- **The facet system of the information (fibre) stratum, indexed by the base's nonzero
cohomology classes**: the base class dictates the fibre-side constraint. For every
1-cochain `t` of nonzero class, every global law satisfies the cycle inequality
`∑ⱼ corrE (t j) ≤ 2` (the cut-polytope facets of the 4-cycle, Barahona–Mahjoub, Math.
Programming 36 (1986), specialized). -/
theorem cycle_bound_gen (t : Fin 4 → ZMod 2) (ht : holF2 t = 1)
    (q : ProbDistribution (∀ _i : Fin 4, ZMod 2)) :
    (∑ j : Fin 4, corrE (t j) (q.marginal (cyc j))) ≤ 2 := by
  rw [Finset.sum_congr rfl fun j _ => corrE_marginal q j (t j), Finset.sum_comm]
  have hpt : ∀ x : (∀ _i : Fin 4, ZMod 2),
      (∑ j : Fin 4, (q x : ℝ) * (if x j + x (j + 1) = t j then 1 else -1))
        ≤ (q x : ℝ) * 2 := by
    intro x
    rw [← Finset.mul_sum]
    refine mul_le_mul_of_nonneg_left ?_ Prob.zero_le_coe
    have hsum : (∑ j : Fin 4, (if x j + x (j + 1) = t j then (1:ℝ) else -1))
        = 4 - 2 * (disagT t x : ℝ) := by
      have hterm : ∀ j : Fin 4, (if x j + x (j + 1) = t j then (1:ℝ) else -1)
          = 1 - 2 * (if x j + x (j + 1) ≠ t j then (1:ℝ) else 0) := by
        intro j
        by_cases h : x j + x (j + 1) = t j
        · rw [if_pos h, if_neg (by simpa using h)]
          ring
        · rw [if_neg h, if_pos h]
          ring
      rw [Finset.sum_congr rfl fun j _ => hterm j, Finset.sum_sub_distrib,
        ← Finset.mul_sum]
      have hcard : (∑ j : Fin 4, (if x j + x (j + 1) ≠ t j then (1:ℝ) else 0))
          = (disagT t x : ℝ) := by
        rw [disagT, Finset.card_filter]
        push_cast
        rfl
      rw [hcard]
      simp
    rw [hsum]
    have h1 : (1 : ℝ) ≤ (disagT t x : ℝ) := by
      exact_mod_cast one_le_disagT t x ht
    linarith
  calc ∑ x, ∑ j : Fin 4, (q x : ℝ) * (if x j + x (j + 1) = t j then 1 else -1)
      ≤ ∑ x, (q x : ℝ) * 2 := Finset.sum_le_sum fun x _ => hpt x
    _ = 2 := by rw [← Finset.sum_mul, q.normalized, one_mul]

/-- **The facet system is genuinely class-graded (non-vacuity of the grading)**: for a
ZERO-class cochain the bound fails — the deterministic global section furnished by the
H¹ computation (`coboundary_range`) attains the maximum 4. -/
theorem cycle_bound_fails_of_hol_zero (t : Fin 4 → ZMod 2) (ht : holF2 t = 0) :
    ∃ q : ProbDistribution (∀ _i : Fin 4, ZMod 2),
      (∑ j : Fin 4, corrE (t j) (q.marginal (cyc j))) = 4 := by
  obtain ⟨x₀, hx₀⟩ := (coboundary_range t).mpr ht
  refine ⟨ProbDistribution.constant x₀, ?_⟩
  have hval : ∀ y, ((ProbDistribution.constant x₀) y : ℝ)
      = if x₀ = y then 1 else 0 := by
    intro y
    by_cases h : x₀ = y
    · rw [if_pos h]
      show (((ProbDistribution.constant x₀) y : Prob) : ℝ) = 1
      rw [congrFun (ProbDistribution.constant_def x₀) y, if_pos h]
      rfl
    · rw [if_neg h]
      show (((ProbDistribution.constant x₀) y : Prob) : ℝ) = 0
      rw [congrFun (ProbDistribution.constant_def x₀) y, if_neg h]
      rfl
  have hcorr : ∀ j : Fin 4,
      corrE (t j) ((ProbDistribution.constant x₀).marginal (cyc j)) = 1 := by
    intro j
    rw [corrE_marginal]
    rw [Finset.sum_congr rfl fun y _ => (by rw [hval y] :
      ((ProbDistribution.constant x₀) y : ℝ)
          * (if y j + y (j + 1) = t j then (1:ℝ) else -1)
        = (if x₀ = y then (1:ℝ) else 0)
          * (if y j + y (j + 1) = t j then (1:ℝ) else -1))]
    rw [Finset.sum_congr rfl fun y _ => (by split_ifs <;> ring :
      (if x₀ = y then (1:ℝ) else 0)
          * (if y j + y (j + 1) = t j then (1:ℝ) else -1)
        = if x₀ = y then (if y j + y (j + 1) = t j then (1:ℝ) else -1) else 0),
      Finset.sum_ite_eq Finset.univ x₀
        (fun y => if y j + y (j + 1) = t j then (1:ℝ) else -1),
      if_pos (Finset.mem_univ _),
      if_pos (show x₀ j + x₀ (j + 1) = t j from congrFun hx₀ j)]
  rw [Finset.sum_congr rfl fun j _ => hcorr j, Finset.sum_const, Finset.card_univ]
  norm_num

end HiddenChannelCapacity

/-! ### The moduli of the base class in the information stratum: completable iff `1/4 ≤ r ≤ 3/4` -/

namespace HiddenChannelCapacity

/-- The disagreement-strata mixture: mass `l` spread uniformly on the 8 configurations
disagreeing with the twist on exactly one edge, mass `1 − l` on the 8 disagreeing on
exactly three. Its edge marginals realize the smoothed family at `r = 1/4 + l/2`. -/
noncomputable def mixMass (l : ℝ) (x : ∀ _i : Fin 4, ZMod 2) : ℝ :=
  (l * (if disag x = 1 then 1 else 0) + (1 - l) * (if disag x = 3 then 1 else 0)) / 8

lemma mixMass_nonneg {l : ℝ} (hl0 : 0 ≤ l) (hl1 : l ≤ 1)
    (x : ∀ _i : Fin 4, ZMod 2) : 0 ≤ mixMass l x := by
  unfold mixMass
  split_ifs <;> linarith

/-- The disagreement strata have 8 configurations each. -/
lemma card_disag_one :
    ((Finset.univ.filter (fun x : (∀ _i : Fin 4, ZMod 2) => disag x = 1)).card = 8) := by
  decide

lemma card_disag_three :
    ((Finset.univ.filter (fun x : (∀ _i : Fin 4, ZMod 2) => disag x = 3)).card = 8) := by
  decide

lemma mixMass_sum (l : ℝ) : ∑ x, mixMass l x = 1 := by
  unfold mixMass
  rw [← Finset.sum_div, Finset.sum_add_distrib, ← Finset.mul_sum, ← Finset.mul_sum,
    Finset.sum_boole, Finset.sum_boole, card_disag_one, card_disag_three]
  norm_num
  ring

/-- The mixture as a distribution. -/
noncomputable def mixDist {l : ℝ} (hl0 : 0 ≤ l) (hl1 : l ≤ 1) :
    ProbDistribution (∀ _i : Fin 4, ZMod 2) :=
  ProbDistribution.mk' (mixMass l) (fun x => mixMass_nonneg hl0 hl1 x) (mixMass_sum l)

@[simp] lemma mixDist_coe {l : ℝ} (hl0 : 0 ≤ l) (hl1 : l ≤ 1)
    (x : ∀ _i : Fin 4, ZMod 2) : ((mixDist hl0 hl1) x : ℝ) = mixMass l x := rfl

/-- Fiber counts of the disagreement strata over an edge configuration: 3 completions
of a twist-agreeing pair lie in the 1-stratum, 1 in the 3-stratum; flipped otherwise. -/
lemma fiber_count_one :
    ∀ (j : Fin 4) (g : ∀ _i : (cyc j : Finset (Fin 4)), ZMod 2),
      ((Finset.univ.filter (fun x : (∀ _i : Fin 4, ZMod 2) =>
        (cyc j).restrict x = g)).filter (fun x => disag x = 1)).card
      = if (pairEquiv j g).1 + (pairEquiv j g).2 = tw j then 3 else 1 := by
  decide

lemma fiber_count_three :
    ∀ (j : Fin 4) (g : ∀ _i : (cyc j : Finset (Fin 4)), ZMod 2),
      ((Finset.univ.filter (fun x : (∀ _i : Fin 4, ZMod 2) =>
        (cyc j).restrict x = g)).filter (fun x => disag x = 3)).card
      = if (pairEquiv j g).1 + (pairEquiv j g).2 = tw j then 1 else 3 := by
  decide

/-- Proof-irrelevant transport of the smoothed family along an equality of parameters. -/
lemma edgeDist_congr {r₁ r₂ : ℝ} (h : r₁ = r₂) (h0 : 0 ≤ r₁) (h1 : r₁ ≤ 1)
    (h0' : 0 ≤ r₂) (h1' : r₂ ≤ 1) (j : Fin 4) :
    edgeDist r₁ h0 h1 j = edgeDist r₂ h0' h1' j := by
  subst h
  rfl

/-- **The mixture completes the smoothed family at `r = 1/4 + l/2`.** -/
lemma mixDist_marginal {l : ℝ} (hl0 : 0 ≤ l) (hl1 : l ≤ 1) (j : Fin 4)
    (hr0 : (0:ℝ) ≤ 1/4 + l/2) (hr1 : 1/4 + l/2 ≤ 1) :
    (mixDist hl0 hl1).marginal (cyc j) = edgeDist (1/4 + l/2) hr0 hr1 j := by
  refine ProbDistribution.ext fun g => ?_
  apply Subtype.ext
  show (((mixDist hl0 hl1).marginal (cyc j)) g : ℝ) = ((edgeDist (1/4 + l/2) hr0 hr1 j) g : ℝ)
  rw [ProbDistribution.marginal_coe, edgeDist_coe]
  rw [Finset.sum_congr rfl fun x _ => mixDist_coe hl0 hl1 x]
  unfold mixMass
  rw [← Finset.sum_div, Finset.sum_add_distrib, ← Finset.mul_sum, ← Finset.mul_sum,
    Finset.sum_boole, Finset.sum_boole, fiber_count_one j g, fiber_count_three j g]
  unfold edgeMass
  by_cases h : (pairEquiv j g).1 + (pairEquiv j g).2 = tw j
  · rw [if_pos h, if_pos h, if_pos h]
    push_cast
    ring
  · rw [if_neg h, if_neg h, if_neg h]
    push_cast
    ring

/-- **THE MODULI THEOREM**: the smoothed cycle family is classically completable
precisely for `1/4 ≤ r ≤ 3/4`. Forward: the two facets of the base's nonzero class
(`tw` and its flip). Backward: the disagreement-strata mixture. Read through real
coefficients the base class carries exact moduli; read through Boolean coefficients
(the support stratum) it detects only the `r = 1` endpoint. The gap between the two
readings, the kernel of the change of coefficients, is the interval `(3/4, 1)` on this
family, kernel-verified at both ends. -/
theorem cycleFam_completable_iff {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    (∃ q, IsCompletionC (X := fun _ => ZMod 2) cyc
      (fun j => edgeDist r hr0 hr1 j) q)
      ↔ (1/4 ≤ r ∧ r ≤ 3/4) := by
  constructor
  · rintro ⟨q, hq⟩
    constructor
    · have hb := cycle_bound_gen (fun j => tw j + 1) (by decide) q
      have heq : ∀ j : Fin 4, corrE (tw j + 1) (q.marginal (cyc j)) = -(2*r - 1) := by
        intro j
        rw [hq j, corrE_flip, corrE_edgeDist hr0 hr1 j]
      rw [Finset.sum_congr rfl fun j _ => heq j, Finset.sum_const,
        Finset.card_univ] at hb
      simp only [Fintype.card_fin, nsmul_eq_mul] at hb
      push_cast at hb
      linarith
    · have hb := cycle_bound_gen tw prBox_class_nonzero q
      have heq : ∀ j : Fin 4, corrE (tw j) (q.marginal (cyc j)) = 2*r - 1 := by
        intro j
        rw [hq j]
        exact corrE_edgeDist hr0 hr1 j
      rw [Finset.sum_congr rfl fun j _ => heq j, Finset.sum_const,
        Finset.card_univ] at hb
      simp only [Fintype.card_fin, nsmul_eq_mul] at hb
      push_cast at hb
      linarith
  · rintro ⟨h14, h34⟩
    have hl0 : (0:ℝ) ≤ 2*r - 1/2 := by linarith
    have hl1 : 2*r - 1/2 ≤ 1 := by linarith
    refine ⟨mixDist hl0 hl1, fun j => ?_⟩
    rw [mixDist_marginal hl0 hl1 j (by linarith) (by linarith)]
    exact edgeDist_congr (by ring) _ _ hr0 hr1 j

/-- The quantum face of the moduli theorem, through the quantization arrow. -/
theorem cycleFam_completableQ_iff {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    (∃ ω, IsCompletionQ (X := fun _ => ZMod 2) cyc
      (fun j => MState.ofClassical (edgeDist r hr0 hr1 j)) ω)
      ↔ (1/4 ≤ r ∧ r ≤ 3/4) := by
  rw [completionQ_diag_iff]
  exact cycleFam_completable_iff hr0 hr1

/-- Battery: the banked `r = 7/8` non-completability is the moduli theorem's upper
boundary at work. -/
example : ¬ ∃ q, IsCompletionC (X := fun _ => ZMod 2) cyc
    (fun j => edgeDist (7/8) (by norm_num) (by norm_num) j) q := fun h => by
  have := (cycleFam_completable_iff (by norm_num) (by norm_num)).mp h
  norm_num at this

/-- Battery: the interior is genuinely completable (non-vacuity of the backward
direction at `r = 1/2`). -/
example : ∃ q, IsCompletionC (X := fun _ => ZMod 2) cyc
    (fun j => edgeDist (1/2) (by norm_num) (by norm_num) j) q :=
  (cycleFam_completable_iff (by norm_num) (by norm_num)).mpr (by norm_num)

end HiddenChannelCapacity
