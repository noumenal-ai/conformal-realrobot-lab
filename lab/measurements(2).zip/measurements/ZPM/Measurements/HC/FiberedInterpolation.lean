/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Fibered
import ZPM.Measurements.HC.Abstract

/-!
# Hidden Channel Capacity — the interpolation leg of the fibered model

`ZPM.Measurements.HC.Fibered` proved the Four-Way fiberwise equivalence between
fiber rectangularity (iii), decomposability (ii), fiber-product surjectivity (v),
and fiber conditional independence (iv). This file adds the **interpolation**
leg (i) by instantiating the substrate-neutral interpolation layer
(`ZPM.Measurements.HC.Abstract`) at the finite, shared-coordinate model.

Read base-first: interpolation is the syntactic shadow of the base structure's
decomposability. The shared interface can mediate a cross-entailment exactly when
the discovered `κ` factors, so leg (i) reads the same base structure as legs (ii)
through (v), now through the vocabulary of definability rather than counting.

The instantiation takes worlds to be admissible triples `S × A × B`, formulas to
be predicates on triples, satisfaction to be function application, and the
shared/left/right partition to be "depends only on the `S` coordinate / on the
`(S, A)` coordinates / on the `(S, B)` coordinates":

* `IsSharedP φ` — `φ` depends only on the shared coordinate;
* `IsLeftP φ` — `φ` depends only on the shared and left coordinates;
* `IsRightP φ` — `φ` depends only on the shared and right coordinates;
* `HasInterpolationProperty κ` — every valid left-to-right entailment over the
  admissible worlds has a shared interpolant.

The headline results are

* `interp_iff_decomposable` — interpolation (i) ⇔ decomposability (ii), and
* `fiveWay_full` — the genuine **Five-Way** equivalence
  `[interpolation, decomposable, fiber-rectangular, fiber-CI, fiber-product
  surjective]` as a `List.TFAE`, in monograph order (i, ii, iii, iv, v).
-/

namespace HiddenChannelCapacity

section Interp

variable {S A B : Type*} [DecidableEq S] [DecidableEq A] [DecidableEq B]

/-- Satisfaction in the fibered model: a formula is a predicate on triples, and
satisfaction is function application. -/
def SatP : (S × A × B) → ((S × A × B) → Prop) → Prop := fun w φ => φ w

/-- Two worlds are **shared-equivalent** when they agree on the shared
coordinate. -/
def SharedEqP : (S × A × B) → (S × A × B) → Prop := fun w w' => w.1 = w'.1

/-- A formula is **shared** when it depends only on the shared coordinate. -/
def IsSharedP (φ : (S × A × B) → Prop) : Prop := ∀ w w', w.1 = w'.1 → (φ w ↔ φ w')

/-- A formula is **left** when it depends only on the shared and left
coordinates. -/
def IsLeftP (φ : (S × A × B) → Prop) : Prop :=
  ∀ w w', w.1 = w'.1 → w.2.1 = w'.2.1 → (φ w ↔ φ w')

/-- A formula is **right** when it depends only on the shared and right
coordinates. -/
def IsRightP (φ : (S × A × B) → Prop) : Prop :=
  ∀ w w', w.1 = w'.1 → w.2.2 = w'.2.2 → (φ w ↔ φ w')

/-- `κ` has the **interpolation property**: every valid left-to-right entailment
over the admissible worlds has a shared interpolant. This is the interpolation
leg (i) of the Five-Way. -/
def HasInterpolationProperty (κ : Finset (S × A × B)) : Prop :=
  ∀ φ ψ, IsLeftP φ → IsRightP ψ →
    (∀ w ∈ Abd SatP (↑κ : Set (S × A × B)) (∅ : Set _), SatP w φ → SatP w ψ) →
    HasInterpolant SatP IsSharedP (↑κ : Set (S × A × B)) (∅ : Set _) φ ψ

/-- `κ` is **amalgamable**: the existential-amalgam form of decomposability — the
abstract amalgamation property (`HiddenChannelCapacity.IsDecomposable`)
instantiated at the fibered model. Any two shared-equivalent admissible worlds
have a common amalgam agreeing with each on its private side. Equivalent to
`Decomposable κ` via `decomposable_iff_absDecomposable`; this is amalgamation leg
(ii) in its model-theoretic form. -/
def Amalgamable (κ : Finset (S × A × B)) : Prop :=
  IsDecomposable SatP SharedEqP IsLeftP IsRightP (↑κ : Set (S × A × B)) (∅ : Set _)

omit [DecidableEq S] [DecidableEq A] [DecidableEq B] in
/-- With no background evidence (`E = ∅`) the admissible worlds are exactly the
elements of `κ`. -/
theorem mem_Abd_empty {κ : Finset (S × A × B)} {w : S × A × B} :
    w ∈ Abd SatP (↑κ : Set (S × A × B)) (∅ : Set _) ↔ w ∈ κ := by
  unfold Abd
  constructor
  · rintro ⟨hw, _⟩
    exact hw
  · intro hw
    refine ⟨hw, ?_⟩
    intro φ hφ
    exact absurd hφ (Set.notMem_empty φ)

omit [DecidableEq S] [DecidableEq A] [DecidableEq B] in
/-- Shared invariance holds: shared formulas cannot tell apart shared-equivalent
worlds. Immediate from `IsSharedP`. -/
theorem shared_invariant :
    SharedInvariant (World := S × A × B) SatP SharedEqP IsSharedP := by
  intro χ hχ w₁ w₂ hshared
  exact hχ w₁ w₂ hshared

omit [DecidableEq S] [DecidableEq A] [DecidableEq B] in
/-- Shared definability holds: every left formula is witnessed by the shared
formula "some admissible world with the same shared coordinate satisfies `φ`". -/
theorem shared_definability (κ : Finset (S × A × B)) :
    HasSharedDefinability SatP SharedEqP IsSharedP IsLeftP (↑κ : Set (S × A × B)) (∅ : Set _) := by
  intro φ _hφL
  refine ⟨fun w => ∃ w', w' ∈ κ ∧ φ w' ∧ w'.1 = w.1, ?_, ?_, ?_⟩
  · -- the witness predicate depends only on the shared coordinate.
    intro w w' hw
    constructor
    · rintro ⟨u, hu, hφu, hu1⟩
      exact ⟨u, hu, hφu, by rw [hu1, hw]⟩
    · rintro ⟨u, hu, hφu, hu1⟩
      exact ⟨u, hu, hφu, by rw [hu1, hw]⟩
  · -- every admissible world satisfying `φ` witnesses itself.
    intro w hw hφw
    rw [mem_Abd_empty] at hw
    exact ⟨w, hw, hφw, rfl⟩
  · -- the witness is realized by an admissible world satisfying `φ`.
    intro w hw
    obtain ⟨u, hu, hφu, hu1⟩ := hw
    refine ⟨u, mem_Abd_empty.mpr hu, hφu, ?_⟩
    unfold SharedEqP
    exact hu1

omit [DecidableEq S] [DecidableEq A] [DecidableEq B] in
/-- Fibered decomposability coincides with the abstract decomposability of the
instantiated layer. -/
theorem decomposable_iff_absDecomposable (κ : Finset (S × A × B)) :
    Decomposable κ ↔ IsDecomposable SatP SharedEqP IsLeftP IsRightP (↑κ : Set (S × A × B)) (∅ : Set _) := by
  constructor
  · -- (⟹) `Decomposable` builds the cross element directly.
    intro hDec w₁ w₂ hw₁ hw₂ hshared
    rw [mem_Abd_empty] at hw₁ hw₂
    unfold SharedEqP at hshared
    -- `wstar = (w₁.1, w₁.2.1, w₂.2.2)`, in `κ` by `Decomposable`.
    refine ⟨(w₁.1, w₁.2.1, w₂.2.2), ?_, ?_, ?_⟩
    · rw [mem_Abd_empty]
      have h1 : (w₁.1, w₁.2.1, w₁.2.2) ∈ κ := by
        rwa [show (w₁.1, w₁.2.1, w₁.2.2) = w₁ from rfl]
      have h2 : (w₁.1, w₂.2.1, w₂.2.2) ∈ κ := by
        have : (w₂.1, w₂.2.1, w₂.2.2) = w₂ := rfl
        rw [← hshared] at this
        rwa [this]
      exact hDec w₁.1 w₁.2.1 w₁.2.2 w₂.2.1 w₂.2.2 h1 h2
    · -- agrees with `w₁` on every left formula (same shared and left coords).
      intro φ hφL
      unfold SatP
      exact hφL (w₁.1, w₁.2.1, w₂.2.2) w₁ rfl rfl
    · -- agrees with `w₂` on every right formula (same shared and right coords).
      intro φ hφR
      unfold SatP
      exact hφR (w₁.1, w₁.2.1, w₂.2.2) w₂ hshared rfl
  · -- (⟸) From abstract decomposability, recover the cross element by testing
    -- the indicator left/right formulas.
    intro hAbs s a₁ b₁ a₂ b₂ h1 h2
    -- feed `w₁ = (s,a₁,b₁)`, `w₂ = (s,a₂,b₂)`, sharing the coordinate `s`.
    have hw₁ : (s, a₁, b₁) ∈ Abd SatP (↑κ : Set (S × A × B)) (∅ : Set _) := mem_Abd_empty.mpr h1
    have hw₂ : (s, a₂, b₂) ∈ Abd SatP (↑κ : Set (S × A × B)) (∅ : Set _) := mem_Abd_empty.mpr h2
    have hshared : SharedEqP (s, a₁, b₁) (s, a₂, b₂) := rfl
    obtain ⟨w, hw, hL, hR⟩ := hAbs hw₁ hw₂ hshared
    rw [mem_Abd_empty] at hw
    -- left indicator: `w` agrees with `w₁` on shared+left, so `w.1 = s`, `w.2.1 = a₁`.
    have hLind : IsLeftP (fun u : S × A × B => u.1 = s ∧ u.2.1 = a₁) := by
      intro u u' hu1 hu2
      show (u.1 = s ∧ u.2.1 = a₁) ↔ (u'.1 = s ∧ u'.2.1 = a₁)
      rw [hu1, hu2]
    have hRind : IsRightP (fun u : S × A × B => u.1 = s ∧ u.2.2 = b₂) := by
      intro u u' hu1 hu2
      show (u.1 = s ∧ u.2.2 = b₂) ↔ (u'.1 = s ∧ u'.2.2 = b₂)
      rw [hu1, hu2]
    have hwL : w.1 = s ∧ w.2.1 = a₁ := by
      have := (hL _ hLind)
      unfold SatP at this
      exact this.mpr ⟨rfl, rfl⟩
    have hwR : w.1 = s ∧ w.2.2 = b₂ := by
      have := (hR _ hRind)
      unfold SatP at this
      exact this.mpr ⟨rfl, rfl⟩
    -- hence `w = (s, a₁, b₂)`, which is therefore in `κ`.
    have hwe : w = (s, a₁, b₂) := by
      apply Prod.ext hwL.1
      apply Prod.ext hwL.2 hwR.2
    rwa [hwe] at hw

/-- **Interpolation ⇔ decomposability** (i ⇔ ii). The interpolation property of
the fibered model holds exactly when the support is decomposable. -/
theorem interp_iff_decomposable (κ : Finset (S × A × B)) :
    HasInterpolationProperty κ ↔ Decomposable κ := by
  constructor
  · -- (Interp ⟹ Decomposable) via the contrapositive at a missing cross element.
    intro hIP s a₁ b₁ a₂ b₂ h1 h2
    by_contra hcon
    -- `hcon : (s, a₁, b₂) ∉ κ`.
    let φ : (S × A × B) → Prop := fun w => w.1 = s ∧ w.2.1 = a₁
    let ψ : (S × A × B) → Prop := fun w => ¬(w.1 = s ∧ w.2.2 = b₂)
    have hφL : IsLeftP φ := by
      intro u u' hu1 hu2
      show (u.1 = s ∧ u.2.1 = a₁) ↔ (u'.1 = s ∧ u'.2.1 = a₁)
      rw [hu1, hu2]
    have hψR : IsRightP ψ := by
      intro u u' hu1 hu2
      show (¬(u.1 = s ∧ u.2.2 = b₂)) ↔ (¬(u'.1 = s ∧ u'.2.2 = b₂))
      rw [hu1, hu2]
    have hent : ∀ w ∈ Abd SatP (↑κ : Set (S × A × B)) (∅ : Set _), SatP w φ → SatP w ψ := by
      intro w hw hφw
      rw [mem_Abd_empty] at hw
      -- `hφw : φ w`, i.e. `w.1 = s ∧ w.2.1 = a₁`.
      have hφw' : w.1 = s ∧ w.2.1 = a₁ := hφw
      show ¬(w.1 = s ∧ w.2.2 = b₂)
      intro hψw
      -- `w.1 = s`, `w.2.1 = a₁` (from `φ`) and `w.2.2 = b₂` (from `¬ψ`) ⇒ `w = (s,a₁,b₂)`.
      apply hcon
      have hwe : w = (s, a₁, b₂) := by
        apply Prod.ext hφw'.1
        exact Prod.ext hφw'.2 hψw.2
      rwa [hwe] at hw
    -- worlds witnessing the failure: `w₁ = (s,a₁,b₁)`, `w₂ = (s,a₂,b₂)`.
    have hw₁ : (s, a₁, b₁) ∈ Abd SatP (↑κ : Set (S × A × B)) (∅ : Set _) := mem_Abd_empty.mpr h1
    have hw₂ : (s, a₂, b₂) ∈ Abd SatP (↑κ : Set (S × A × B)) (∅ : Set _) := mem_Abd_empty.mpr h2
    have hφw₁ : SatP (s, a₁, b₁) φ := ⟨rfl, rfl⟩
    have hψnotw₂ : ¬ SatP (s, a₂, b₂) ψ := fun hc => hc ⟨rfl, rfl⟩
    have hshared : SharedEqP (s, a₁, b₁) (s, a₂, b₂) := rfl
    -- the interpolation property would supply an interpolant; the reverse
    -- direction forbids it.
    have hno := reverse_direction SatP SharedEqP IsSharedP (↑κ : Set (S × A × B)) (∅ : Set _)
      shared_invariant hw₁ hw₂ hshared hφw₁ hψnotw₂ hent
    exact hno (hIP φ ψ hφL hψR hent)
  · -- (Decomposable ⟹ Interp) via the abstract forward direction.
    intro hDec φ ψ hφL hψR hent
    have hAbs := (decomposable_iff_absDecomposable κ).mp hDec
    exact forward_direction SatP SharedEqP IsSharedP IsLeftP IsRightP (↑κ : Set (S × A × B)) (∅ : Set _)
      hAbs (shared_definability κ) hφL hψR hent

end Interp

section Full

variable {S A B : Type*} [DecidableEq S]
  [Fintype A] [Fintype B] [DecidableEq A] [DecidableEq B]
  [MeasurableSpace A] [MeasurableSpace B]
  [DiscreteMeasurableSpace A] [DiscreteMeasurableSpace B]

/-- **The genuine Five-Way equivalence of the fibered HC model**, with both forms
of the decomposability leg made explicit. In monograph order: interpolation (i),
decomposability (ii) and its model-theoretic amalgamation form (ii′), fiber
rectangularity (iii), fiber conditional independence (iv), and fiber-product
surjectivity (v) are all mutually equivalent. -/
theorem fiveWay_full (κ : Finset (S × A × B)) :
    List.TFAE
      [ HasInterpolationProperty κ,
        Decomposable κ,
        Amalgamable κ,
        FiberRect κ,
        FiberCI κ,
        FiberProductSurjective κ ] := by
  tfae_have 1 ↔ 2 := interp_iff_decomposable κ
  tfae_have 2 ↔ 3 := decomposable_iff_absDecomposable κ
  tfae_have 2 ↔ 4 := (fiberRect_iff_decomposable κ).symm
  tfae_have 4 ↔ 5 := fiberRect_iff_fiberCI κ
  tfae_have 4 ↔ 6 := fiberRect_iff_fps κ
  tfae_finish

end Full

end HiddenChannelCapacity
