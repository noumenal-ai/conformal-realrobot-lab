/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Marginals
import Mathlib.Data.Fintype.Powerset

/-!
# The first higher obstruction

The hidden-channel defect is irreducibly higher-degree: it is not a function of any proper family
of marginal shadows. Two kernel-verified witnesses over three binary parts:

* **Shadow-blindness** (`parity3_shadow_blind`): the 3-ary parity relation
  `κ⊕ = {f : Fin 3 → Fin 2 | f 0 + f 1 + f 2 = 0}` has every proper sub-team marginal
  rectangular — every strict shadow reports "no hidden channel" — while the global defect is
  `hcCombPi κ⊕ = 4`. The obstruction lives strictly above the pairwise level: genuinely
  three-body hidden correlation.

* **Failure of amalgamation** (`specker_not_glues`): the Specker triangle — pairwise structures
  `f 0 = f 1`, `f 1 = f 2`, `f 0 ≠ f 2` — is 1-consistent (`specker_consistent`: all shared
  coordinate projections agree, each the full `Fin 2`), yet no multipartite relation has these
  three as its pairwise marginals. The base structure that forces this is the cover's cyclic
  shape: it licenses the verdict *no global section*, one the mutually consistent local marginals
  provably cannot deliver — the combinatorial form of a nonzero first Čech obstruction over the
  coordinate cover.

Together these are the acceptance test for the cohomological-roots programme: any candidate
complex attached to an ignorance structure must vanish on every proper shadow of `parity3` yet
detect its global defect, and must obstruct the gluing of the Specker family.
-/

namespace HiddenChannelCapacity

open Finset

/-! ### Shadow-blindness: the parity relation -/

/-- The 3-ary parity relation: admissible configurations of three binary parts with even sum. -/
def parity3 : Finset (∀ _ : Fin 3, Fin 2) :=
  Finset.univ.filter (fun f => f 0 + f 1 + f 2 = 0)

/-- **Shadow-blindness.** Every proper sub-team marginal of the parity relation is rectangular,
while the global defect is `4`: the hidden channel is invisible to all proper shadows. -/
theorem parity3_shadow_blind :
    (∀ S ∈ (Finset.univ.erase Finset.univ : Finset (Finset (Fin 3))),
      IsRectPi (projS parity3 S)) ∧ hcCombPi parity3 = 4 := by
  decide

/-- Every proper sub-team marginal of the parity relation is rectangular. -/
theorem parity3_proper_marginals_rect (S : Finset (Fin 3)) (hS : S ≠ Finset.univ) :
    IsRectPi (projS parity3 S) :=
  parity3_shadow_blind.1 S (Finset.mem_erase.mpr ⟨hS, Finset.mem_univ S⟩)

/-- The parity relation's global defect. -/
theorem hcCombPi_parity3 : hcCombPi parity3 = 4 :=
  parity3_shadow_blind.2

/-- The parity relation is not rectangular: the global hidden channel is real. -/
theorem parity3_not_isRectPi : ¬ IsRectPi parity3 := by
  rw [← hcCombPi_eq_zero_iff_isRectPi, hcCombPi_parity3]
  decide

/-! ### Failure of amalgamation: the Specker triangle -/

/-- The sub-team `{0, 1}`. -/
def S01 : Finset (Fin 3) := {0, 1}

/-- The sub-team `{1, 2}`. -/
def S12 : Finset (Fin 3) := {1, 2}

/-- The sub-team `{0, 2}`. -/
def S02 : Finset (Fin 3) := {0, 2}

/-- Perfect correlation on `{0, 1}`. -/
def diag01 : Finset (∀ _ : S01, Fin 2) :=
  Finset.univ.filter (fun g => g ⟨0, by decide⟩ = g ⟨1, by decide⟩)

/-- Perfect correlation on `{1, 2}`. -/
def diag12 : Finset (∀ _ : S12, Fin 2) :=
  Finset.univ.filter (fun g => g ⟨1, by decide⟩ = g ⟨2, by decide⟩)

/-- Perfect anticorrelation on `{0, 2}`. -/
def anti02 : Finset (∀ _ : S02, Fin 2) :=
  Finset.univ.filter (fun g => g ⟨0, by decide⟩ ≠ g ⟨2, by decide⟩)

/-- **The Specker triangle is 1-consistent**: on every shared coordinate the three pairwise
structures expose the same projection (the full `Fin 2`). Consistency is what makes the failure
to glue an obstruction rather than an accident. -/
theorem specker_consistent :
    projPi diag01 ⟨0, by decide⟩ = projPi anti02 ⟨0, by decide⟩
      ∧ projPi diag01 ⟨1, by decide⟩ = projPi diag12 ⟨1, by decide⟩
      ∧ projPi diag12 ⟨2, by decide⟩ = projPi anti02 ⟨2, by decide⟩ := by
  decide

/-- **The Specker triangle does not glue**: no multipartite relation has the three consistent
pairwise structures as its marginals. Any admissible global configuration would satisfy
`f 0 = f 1`, `f 1 = f 2`, `f 0 ≠ f 2`. The cover's cyclic base geometry is what denies the global
section the mutually consistent local sections appear to permit — the first nonzero Čech-type
obstruction, in kernel-checkable form. -/
theorem specker_not_glues :
    ¬ ∃ κ : Finset (∀ _ : Fin 3, Fin 2),
      projS κ S01 = diag01 ∧ projS κ S12 = diag12 ∧ projS κ S02 = anti02 := by
  rintro ⟨κ, h01, h12, h02⟩
  -- the diagonal marginal is nonempty, so the relation is nonempty
  have hne : κ.Nonempty := by
    have hd : diag01.Nonempty := ⟨S01.restrict (fun _ => (0 : Fin 2)), by decide⟩
    rw [← h01] at hd
    exact Finset.image_nonempty.mp hd
  obtain ⟨f, hf⟩ := hne
  -- transport the marginal memberships of an admissible configuration
  have m01 : S01.restrict f ∈ diag01 := h01 ▸ Finset.mem_image_of_mem _ hf
  have m12 : S12.restrict f ∈ diag12 := h12 ▸ Finset.mem_image_of_mem _ hf
  have m02 : S02.restrict f ∈ anti02 := h02 ▸ Finset.mem_image_of_mem _ hf
  -- the three constraints contradict: f 0 = f 1 = f 2 ≠ f 0
  exact (Finset.mem_filter.mp m02).2
    (((Finset.mem_filter.mp m01).2).trans ((Finset.mem_filter.mp m12).2))

end HiddenChannelCapacity
