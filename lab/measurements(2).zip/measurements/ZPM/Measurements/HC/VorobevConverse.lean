/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.CyclicConverse

/-!
# The Vorob'ev converse: finders and assembly

The chain of CYCLIC_CONVERSE_URS D26. These are the finders that locate, inside the cover's
primal geometry, the base structure the converse turns on (a non-covered clique or a chordless
cycle), each of which licenses the verdict that a pairwise-consistent local family realizes no
global structure. The primal grammar (`Adj`, `shared`, cliques and coverage), the parity bridge
(`mem_xorSum`), and the two FINDERS feeding `clean_system_obstruction`:

* the CLIQUE DATUM (`clean_system_of_uncovered_clique`): a cardinality-minimal non-covered
  clique yields a clean system — all erase-sets are covered (they are smaller cliques),
  parity closes by counting (odd size: all erase-sets; even size: two erase-sets and their
  symmetric difference, an edge), and NON-COVEREDNESS IS CLEANLINESS (a team hosting two
  members contains the whole clique);
* the CYCLE DATUM (`clean_system_of_chordlessCycle`): a chordless cycle of length ≥ 4 yields
  a clean system — CHORDLESSNESS IS CLEANLINESS (a team hosting two cycle pairs co-hosts a
  cyclically non-consecutive pair of vertices).

The one-step GYO collapse (`isEarOf_of_simplicial`): in a conformal cover, a simplicial
vertex of the shared-primal graph produces an EAR outright — every team containing it has
boundary inside the team covering its closed neighborhood. Hence ear-free ∧ conformal covers
have no simplicial shared vertex, and Dirac's lemma (the single named classical obligation,
absent from Mathlib) upgrades this to the chordal/conformal dichotomy.

The assembly (`capstone_of_core`): a clean system on an ear-free core extracted by
`exists_earFree_core_chain` transfers to the FULL cover — the ear-chain lemma routes any
team hosting two members into a single core team, where core-cleanliness applies.
-/

namespace HiddenChannelCapacity

open Finset
open scoped symmDiff

variable {ι : Type*} [DecidableEq ι]

/-! ### The parity bridge -/

/-- Membership in an F2 sum is odd incidence. -/
lemma mem_xorSum {D : Finset (Finset ι)} {i : ι} :
    i ∈ xorSum D ↔ Odd (D.filter (i ∈ ·)).card := by
  induction D using Finset.induction_on with
  | empty => simp [xorSum]
  | @insert w D hw ih =>
    rw [xorSum, Finset.fold_insert hw, id]
    by_cases hiw : i ∈ w
    · rw [Finset.filter_insert, if_pos hiw, Finset.card_insert_of_notMem
        (fun h => hw (Finset.mem_filter.mp h).1), Nat.odd_add_one]
      simp only [Finset.mem_symmDiff, hiw, true_and, not_true, and_false, or_false, id_eq]
      exact not_congr ih
    · rw [Finset.filter_insert, if_neg hiw]
      simp only [Finset.mem_symmDiff, hiw, false_and, false_or, and_true,
        not_false_eq_true, id_eq]
      exact ih

/-- An F2 sum vanishes iff every incidence count is even. -/
lemma xorSum_eq_empty_iff {D : Finset (Finset ι)} :
    xorSum D = ∅ ↔ ∀ i : ι, ¬ Odd (D.filter (i ∈ ·)).card := by
  rw [Finset.eq_empty_iff_forall_notMem]
  exact forall_congr' (fun i => by rw [mem_xorSum])

/-! ### The primal grammar -/

/-- Primal adjacency: distinct co-hosted vertices. -/
def Adj (𝒞 : Finset (Finset ι)) (u v : ι) : Prop :=
  u ≠ v ∧ ∃ T ∈ 𝒞, u ∈ T ∧ v ∈ T

instance (𝒞 : Finset (Finset ι)) (u v : ι) : Decidable (Adj 𝒞 u v) := by
  unfold Adj
  infer_instance

omit [DecidableEq ι] in
lemma Adj.symm' {𝒞 : Finset (Finset ι)} {u v : ι} (h : Adj 𝒞 u v) : Adj 𝒞 v u :=
  ⟨h.1.symm, h.2.imp (fun _ hT => ⟨hT.1, hT.2.2, hT.2.1⟩)⟩

/-- Co-hosted vertices are adjacent or equal. -/
lemma adj_or_eq_of_cohosted {𝒞 : Finset (Finset ι)} {V : Finset ι} (hV : V ∈ 𝒞) {u v : ι}
    (hu : u ∈ V) (hv : v ∈ V) : Adj 𝒞 u v ∨ u = v := by
  by_cases h : u = v
  · exact Or.inr h
  · exact Or.inl ⟨h, V, hV, hu, hv⟩

/-- A clique of the primal graph. -/
def IsClique (𝒞 : Finset (Finset ι)) (K : Finset ι) : Prop :=
  ∀ u ∈ K, ∀ v ∈ K, u ≠ v → Adj 𝒞 u v

/-- A vertex set covered by a single team. -/
def Covered (𝒞 : Finset (Finset ι)) (K : Finset ι) : Prop :=
  ∃ T ∈ 𝒞, K ⊆ T

/-- Conformality: every clique inside the cover is covered. -/
def Conformal (𝒞 : Finset (Finset ι)) : Prop :=
  ∀ K ⊆ coverU 𝒞, IsClique 𝒞 K → Covered 𝒞 K

instance (𝒞 : Finset (Finset ι)) (K : Finset ι) : Decidable (IsClique 𝒞 K) := by
  unfold IsClique; infer_instance
instance (𝒞 : Finset (Finset ι)) (K : Finset ι) : Decidable (Covered 𝒞 K) := by
  unfold Covered; infer_instance
instance (𝒞 : Finset (Finset ι)) : Decidable (Conformal 𝒞) := by
  unfold Conformal; infer_instance

lemma mem_coverU {𝒞 : Finset (Finset ι)} {v : ι} :
    v ∈ coverU 𝒞 ↔ ∃ T ∈ 𝒞, v ∈ T := by
  rw [coverU, Finset.mem_sup]
  rfl

/-- Small cliques are covered: the empty set (nonempty cover), singletons, edges. -/
lemma covered_of_card_le_two {𝒞 : Finset (Finset ι)} (hne : 𝒞.Nonempty) {K : Finset ι}
    (hKsub : K ⊆ coverU 𝒞) (hK : IsClique 𝒞 K) (hcard : K.card ≤ 2) : Covered 𝒞 K := by
  have h0 : K.card = 0 ∨ K.card = 1 ∨ K.card = 2 := by omega
  rcases h0 with h | h | h
  · rw [Finset.card_eq_zero] at h
    subst h
    obtain ⟨T, hT⟩ := hne
    exact ⟨T, hT, Finset.empty_subset T⟩
  · obtain ⟨v, rfl⟩ := Finset.card_eq_one.mp h
    obtain ⟨T, hT, hvT⟩ := mem_coverU.mp (hKsub (Finset.mem_singleton_self v))
    exact ⟨T, hT, Finset.singleton_subset_iff.mpr hvT⟩
  · obtain ⟨u, v, huv, rfl⟩ := Finset.card_eq_two.mp h
    obtain ⟨-, T, hT, huT, hvT⟩ :=
      hK u (Finset.mem_insert_self u {v}) v
        (Finset.mem_insert_of_mem (Finset.mem_singleton_self v)) huv
    exact ⟨T, hT, Finset.insert_subset huT (Finset.singleton_subset_iff.mpr hvT)⟩

/-! ### The clique datum -/

private lemma erase_union_erase {K : Finset ι} {i j : ι} (hij : i ≠ j) :
    K.erase i ∪ K.erase j = K := by
  ext v
  simp only [Finset.mem_union, Finset.mem_erase]
  constructor
  · rintro (⟨-, hv⟩ | ⟨-, hv⟩) <;> exact hv
  · intro hv
    by_cases hvi : v = i
    · exact Or.inr ⟨by rw [hvi]; exact hij, hv⟩
    · exact Or.inl ⟨hvi, hv⟩

/-- **The clique datum**: a cardinality-minimal non-covered clique yields a clean system.
Minimality covers the erase-sets; non-coveredness is cleanliness; parity closes by counting. -/
theorem clean_system_of_uncovered_clique (𝒞 : Finset (Finset ι)) (hne : 𝒞.Nonempty)
    (hnc : ¬ Conformal 𝒞) :
    ∃ 𝒲 : Finset (Finset ι), 𝒲.Nonempty ∧ (∀ w ∈ 𝒲, w ≠ ∅) ∧
      (∀ w ∈ 𝒲, ∃ T ∈ 𝒞, w ⊆ T) ∧
      (∀ V ∈ 𝒞, ∀ w₁ ∈ 𝒲, ∀ w₂ ∈ 𝒲, w₁ ⊆ V → w₂ ⊆ V → w₁ = w₂) ∧
      xorSum 𝒲 = ∅ := by
  classical
  -- a minimal-cardinality non-covered clique
  simp only [Conformal, not_forall] at hnc
  obtain ⟨K₀, hK₀sub, hK₀cl, hK₀nc⟩ := hnc
  set cands : Finset (Finset ι) :=
    ((coverU 𝒞).powerset.filter (fun K => IsClique 𝒞 K ∧ ¬ Covered 𝒞 K)) with hcands
  have hK₀mem : K₀ ∈ cands := by
    rw [hcands, Finset.mem_filter, Finset.mem_powerset]
    exact ⟨hK₀sub, hK₀cl, hK₀nc⟩
  obtain ⟨K, hKmem, hKmin⟩ := Finset.exists_min_image cands Finset.card ⟨K₀, hK₀mem⟩
  rw [hcands, Finset.mem_filter, Finset.mem_powerset] at hKmem
  obtain ⟨hKsub, hKcl, hKnc⟩ := hKmem
  -- minimality: every smaller clique in the cover is covered
  have hmin : ∀ K' ⊆ coverU 𝒞, IsClique 𝒞 K' → K'.card < K.card → Covered 𝒞 K' := by
    intro K' hsub hcl hlt
    by_contra hnc'
    have : K' ∈ cands := by
      rw [hcands, Finset.mem_filter, Finset.mem_powerset]
      exact ⟨hsub, hcl, hnc'⟩
    exact absurd (hKmin K' this) (by omega)
  have hk3 : 3 ≤ K.card := by
    by_contra h
    exact hKnc (covered_of_card_le_two hne hKsub hKcl (by omega))
  -- the erase-sets are covered
  have herase : ∀ s ∈ K, Covered 𝒞 (K.erase s) := by
    intro s hs
    refine hmin (K.erase s) ((Finset.erase_subset s K).trans hKsub)
      (fun u hu v hv huv => hKcl u (Finset.mem_of_mem_erase hu) v (Finset.mem_of_mem_erase hv) huv)
      ?_
    rw [Finset.card_erase_of_mem hs]
    omega
  -- cleanliness engine: a team hosting K is impossible
  have hclean_engine : ∀ V ∈ 𝒞, ¬ K ⊆ V := by
    intro V hV hKV
    exact hKnc ⟨V, hV, hKV⟩
  rcases Nat.even_or_odd K.card with heven | hodd
  · -- even: two erase-sets and their symmetric difference (an edge)
    have hk4 : 4 ≤ K.card := by
      obtain ⟨m, hm⟩ := heven
      omega
    obtain ⟨i, hi, j, hj, hij⟩ := Finset.one_lt_card.mp (by omega : 1 < K.card)
    refine ⟨{K.erase i, K.erase j, ({i, j} : Finset ι)}, ⟨K.erase i, by simp⟩, ?_, ?_, ?_, ?_⟩
    · intro w hw
      simp only [Finset.mem_insert, Finset.mem_singleton] at hw
      rcases hw with rfl | rfl | rfl
      · exact Finset.nonempty_iff_ne_empty.mp
          ⟨j, Finset.mem_erase.mpr ⟨hij.symm, hj⟩⟩
      · exact Finset.nonempty_iff_ne_empty.mp
          ⟨i, Finset.mem_erase.mpr ⟨hij, hi⟩⟩
      · exact Finset.nonempty_iff_ne_empty.mp ⟨i, Finset.mem_insert_self i {j}⟩
    · intro w hw
      simp only [Finset.mem_insert, Finset.mem_singleton] at hw
      rcases hw with rfl | rfl | rfl
      · exact herase i hi
      · exact herase j hj
      · obtain ⟨-, T, hT, hiT, hjT⟩ := hKcl i hi j hj hij
        exact ⟨T, hT, Finset.insert_subset hiT (Finset.singleton_subset_iff.mpr hjT)⟩
    · -- cleanliness: any two distinct members union to ⊇ K
      intro V hV w₁ hw₁ w₂ hw₂ h₁V h₂V
      simp only [Finset.mem_insert, Finset.mem_singleton] at hw₁ hw₂
      by_contra hne'
      apply hclean_engine V hV
      have hcover : K ⊆ w₁ ∪ w₂ := by
        rcases hw₁ with rfl | rfl | rfl <;> rcases hw₂ with rfl | rfl | rfl <;>
          (try exact absurd rfl hne') <;>
          (intro v hv
           simp only [Finset.mem_union, Finset.mem_erase, Finset.mem_insert,
             Finset.mem_singleton]
           by_cases hvi : v = i
           · subst hvi
             by_cases hvj : v = j
             · exact absurd hvj hij
             · tauto
           · by_cases hvj : v = j
             · subst hvj
               tauto
             · tauto)
      exact hcover.trans (Finset.union_subset h₁V h₂V)
    · -- parity via the three-fold symmetric difference
      have hAB : K.erase i ≠ K.erase j := by
        intro h
        have hjA : j ∈ K.erase i := Finset.mem_erase.mpr ⟨hij.symm, hj⟩
        rw [h] at hjA
        exact (Finset.notMem_erase j K) hjA
      have hcardC : ({i, j} : Finset ι).card ≤ 2 :=
        Finset.card_insert_le i {j} |>.trans (by simp)
      have hAC : K.erase i ≠ ({i, j} : Finset ι) := by
        intro h
        have h1 := congrArg Finset.card h
        rw [Finset.card_erase_of_mem hi] at h1
        omega
      have hBC : K.erase j ≠ ({i, j} : Finset ι) := by
        intro h
        have h1 := congrArg Finset.card h
        rw [Finset.card_erase_of_mem hj] at h1
        omega
      have hnd : ([K.erase i, K.erase j, ({i, j} : Finset ι)] : List (Finset ι)).Nodup := by
        simp [hAB, hAC, hBC]
      have hset : ({K.erase i, K.erase j, ({i, j} : Finset ι)} : Finset (Finset ι)) =
          ([K.erase i, K.erase j, ({i, j} : Finset ι)] : List (Finset ι)).toFinset := by
        simp
      rw [hset, ← xorSumL_eq_xorSum hnd, xorSumL_cons, xorSumL_cons, xorSumL_cons,
        xorSumL_nil, symmDiff_empty]
      ext v
      simp only [Finset.mem_symmDiff, Finset.mem_erase, Finset.mem_insert,
        Finset.mem_singleton, Finset.notMem_empty, iff_false]
      by_cases hvi : v = i <;> by_cases hvj : v = j <;>
        simp [hvi, hvj, hij, hij.symm, hi, hj]
  · -- odd: all erase-sets
    refine ⟨K.image (fun s => K.erase s), ?_, ?_, ?_, ?_, ?_⟩
    · obtain ⟨s, hs⟩ := Finset.card_pos.mp (by omega : 0 < K.card)
      exact ⟨K.erase s, Finset.mem_image_of_mem _ hs⟩
    · intro w hw
      obtain ⟨s, hs, rfl⟩ := Finset.mem_image.mp hw
      have : 2 ≤ (K.erase s).card := by
        rw [Finset.card_erase_of_mem hs]
        omega
      exact Finset.nonempty_iff_ne_empty.mp (Finset.card_pos.mp (by omega))
    · intro w hw
      obtain ⟨s, hs, rfl⟩ := Finset.mem_image.mp hw
      exact herase s hs
    · intro V hV w₁ hw₁ w₂ hw₂ h₁V h₂V
      obtain ⟨s₁, hs₁, rfl⟩ := Finset.mem_image.mp hw₁
      obtain ⟨s₂, hs₂, rfl⟩ := Finset.mem_image.mp hw₂
      by_cases hs : s₁ = s₂
      · rw [hs]
      · exfalso
        apply hclean_engine V hV
        have : K ⊆ K.erase s₁ ∪ K.erase s₂ := by
          rw [erase_union_erase hs]
        exact this.trans (Finset.union_subset h₁V h₂V)
    · rw [xorSum_eq_empty_iff]
      intro v
      by_cases hvK : v ∈ K
      · have hfil : (K.image (fun s => K.erase s)).filter (v ∈ ·) =
            (K.filter (fun s => s ≠ v)).image (fun s => K.erase s) := by
          ext w
          simp only [Finset.mem_filter, Finset.mem_image]
          constructor
          · rintro ⟨⟨s, hs, rfl⟩, hvw⟩
            exact ⟨s, ⟨hs, fun h => (Finset.notMem_erase v K) (h ▸ hvw)⟩, rfl⟩
          · rintro ⟨s, ⟨hs, hsv⟩, rfl⟩
            exact ⟨⟨s, hs, rfl⟩, Finset.mem_erase.mpr ⟨fun h => hsv h.symm, hvK⟩⟩
        rw [hfil, Finset.card_image_of_injOn
          (fun a ha b hb hab => by
            by_contra hne'
            have haK : a ∈ K := (Finset.mem_filter.mp ha).1
            have hbK : b ∈ K := (Finset.mem_filter.mp hb).1
            have : b ∈ K.erase a := Finset.mem_erase.mpr ⟨fun h => hne' h.symm, hbK⟩
            rw [hab] at this
            exact (Finset.notMem_erase b K) this)]
        have : (K.filter (fun s => s ≠ v)).card = K.card - 1 := by
          rw [Finset.filter_ne', Finset.card_erase_of_mem hvK]
        rw [this, Nat.odd_iff]
        obtain ⟨m, hm⟩ := hodd
        omega
      · have : (K.image (fun s => K.erase s)).filter (v ∈ ·) = ∅ := by
          ext w
          simp only [Finset.mem_filter, Finset.mem_image, Finset.notMem_empty, iff_false,
            not_and]
          rintro ⟨s, hs, rfl⟩ hvw
          exact hvK (Finset.mem_of_mem_erase hvw)
        rw [this, Finset.card_empty, Nat.odd_iff]
        omega

/-! ### The one-step GYO collapse -/

/-- The shared vertices of a cover. -/
def shared (𝒞 : Finset (Finset ι)) : Finset ι :=
  (coverU 𝒞).filter (fun v => 1 < (𝒞.filter (v ∈ ·)).card)

lemma mem_shared {𝒞 : Finset (Finset ι)} {v : ι} :
    v ∈ shared 𝒞 ↔ ∃ T ∈ 𝒞, ∃ T' ∈ 𝒞, T ≠ T' ∧ v ∈ T ∧ v ∈ T' := by
  rw [shared, Finset.mem_filter, Finset.one_lt_card]
  constructor
  · rintro ⟨-, T, hT, T', hT', hne⟩
    rw [Finset.mem_filter] at hT hT'
    exact ⟨T, hT.1, T', hT'.1, hne, hT.2, hT'.2⟩
  · rintro ⟨T, hT, T', hT', hne, hvT, hvT'⟩
    exact ⟨mem_coverU.mpr ⟨T, hT, hvT⟩,
      T, Finset.mem_filter.mpr ⟨hT, hvT⟩, T', Finset.mem_filter.mpr ⟨hT', hvT'⟩, hne⟩

/-- A team's boundary is its shared part. -/
lemma bndry_eq_inter_shared {𝒞 : Finset (Finset ι)} {T : Finset ι} (hT : T ∈ 𝒞) :
    T ∩ coverU (𝒞.erase T) = T ∩ shared 𝒞 := by
  ext v
  simp only [Finset.mem_inter, and_congr_right_iff]
  intro hvT
  rw [mem_coverU, mem_shared]
  constructor
  · rintro ⟨T', hT', hvT'⟩
    exact ⟨T, hT, T', (Finset.mem_erase.mp hT').2, fun h => (Finset.mem_erase.mp hT').1 h.symm,
      hvT, hvT'⟩
  · rintro ⟨T₁, hT₁, T₂, hT₂, hne, hv₁, hv₂⟩
    by_cases h : T₁ = T
    · exact ⟨T₂, Finset.mem_erase.mpr ⟨fun hh => hne (h.trans hh.symm), hT₂⟩, hv₂⟩
    · exact ⟨T₁, Finset.mem_erase.mpr ⟨h, hT₁⟩, hv₁⟩

/-- **The one-step GYO collapse**: in a conformal cover, a simplicial shared vertex yields an
ear — every team containing it has boundary inside the team covering its closed shared
neighborhood. -/
theorem isEarOf_of_simplicial {𝒞 : Finset (Finset ι)} (hconf : Conformal 𝒞) {v : ι}
    (hv : v ∈ shared 𝒞)
    (hsimp : ∀ x ∈ shared 𝒞, ∀ y ∈ shared 𝒞, Adj 𝒞 v x → Adj 𝒞 v y → x ≠ y → Adj 𝒞 x y) :
    ∃ T ∈ 𝒞, IsEarOf 𝒞 T := by
  classical
  -- the closed shared neighborhood is a clique
  set K : Finset ι := insert v ((shared 𝒞).filter (fun x => Adj 𝒞 v x)) with hK
  have hKsub : K ⊆ coverU 𝒞 := by
    intro x hx
    rw [hK, Finset.mem_insert] at hx
    rcases hx with rfl | hx
    · exact Finset.filter_subset _ _ hv
    · exact Finset.filter_subset _ _ ((Finset.mem_filter.mp hx).1)
  have hKcl : IsClique 𝒞 K := by
    intro x hx y hy hxy
    rw [hK, Finset.mem_insert] at hx hy
    rcases hx with rfl | hx <;> rcases hy with rfl | hy
    · exact absurd rfl hxy
    · exact (Finset.mem_filter.mp hy).2
    · exact ((Finset.mem_filter.mp hx).2).symm'
    · exact hsimp x (Finset.mem_filter.mp hx).1 y (Finset.mem_filter.mp hy).1
        (Finset.mem_filter.mp hx).2 (Finset.mem_filter.mp hy).2 hxy
  obtain ⟨T₀, hT₀, hKT₀⟩ := hconf K hKsub hKcl
  -- v is shared: a second team T ≠ T₀ contains it
  obtain ⟨T₁, hT₁, T₂, hT₂, hT₁₂, hv₁, hv₂⟩ := mem_shared.mp hv
  obtain ⟨T, hT, hvT, hTne⟩ : ∃ T ∈ 𝒞, v ∈ T ∧ T ≠ T₀ := by
    by_cases h : T₁ = T₀
    · exact ⟨T₂, hT₂, hv₂, fun hh => hT₁₂ (h.trans hh.symm)⟩
    · exact ⟨T₁, hT₁, hv₁, h⟩
  -- T's boundary sits inside T₀
  refine ⟨T, hT, Or.inr ⟨T₀, Finset.mem_erase.mpr ⟨fun h => hTne h.symm, hT₀⟩, ?_⟩⟩
  intro x hx
  rw [bndry_eq_inter_shared hT] at hx
  obtain ⟨hxT, hxSh⟩ := Finset.mem_inter.mp hx
  by_cases hxv : x = v
  · exact hKT₀ (by rw [hK, hxv]; exact Finset.mem_insert_self v _)
  · have hadj : Adj 𝒞 v x := ⟨fun h => hxv h.symm, T, hT, hvT, hxT⟩
    exact hKT₀ (by
      rw [hK]
      exact Finset.mem_insert_of_mem (Finset.mem_filter.mpr ⟨hxSh, hadj⟩))

/-! ### The chain extraction and the transfer -/

/-- **Chain extraction**: a non-Graham-reducible cover has an ear-free core such that any
vertex set inside the core's cover hosted anywhere in the cover is hosted inside the core. -/
theorem exists_earFree_core_chain (𝒞 : Finset (Finset ι)) :
    ¬ GrahamReducible 𝒞 → ∃ 𝒞' ⊆ 𝒞, EarFree 𝒞' ∧
      ∀ w : Finset ι, w ⊆ coverU 𝒞' → (∃ V ∈ 𝒞, w ⊆ V) → ∃ W ∈ 𝒞', w ⊆ W := by
  induction 𝒞 using Finset.strongInductionOn with
  | _ 𝒞 ih =>
    intro h
    have hne : 𝒞.Nonempty := by
      rcases 𝒞.eq_empty_or_nonempty with rfl | hne
      · exact absurd (show GrahamReducible (∅ : Finset (Finset ι)) from rfl) h
      · exact hne
    by_cases hear : ∀ T ∈ 𝒞, ¬ IsEarOf 𝒞 T
    · refine ⟨𝒞, Finset.Subset.refl 𝒞, ⟨hne, hear⟩, ?_⟩
      rintro w - ⟨V, hV, hwV⟩
      exact ⟨V, hV, hwV⟩
    · simp only [not_forall, not_not] at hear
      obtain ⟨T, hT, hearT⟩ := hear
      have hrec : ¬ GrahamReducible (𝒞.erase T) := by
        intro hred
        apply h
        have hcard : 𝒞.card = (𝒞.erase T).card + 1 := by
          rw [Finset.card_erase_of_mem hT]
          have : 1 ≤ 𝒞.card := Finset.card_pos.mpr ⟨T, hT⟩
          omega
        rw [GrahamReducible, hcard]
        exact Or.inr ⟨T, hT, hearT, hred⟩
      obtain ⟨𝒞', hsub, hef, hchain⟩ := ih (𝒞.erase T) (Finset.erase_ssubset hT) hrec
      refine ⟨𝒞', hsub.trans (Finset.erase_subset T 𝒞), hef, ?_⟩
      rintro w hwcov ⟨V, hV, hwV⟩
      by_cases hVT : V = T
      · rcases hearT with hempty | ⟨T', hT', hsub'⟩
        · exfalso
          obtain ⟨W, hW⟩ := hef.1
          exact (Finset.notMem_empty W) (hempty ▸ hsub hW)
        · refine hchain w hwcov ⟨T', hT', ?_⟩
          intro x hx
          refine hsub' (Finset.mem_inter.mpr ⟨by rw [← hVT]; exact hwV hx, ?_⟩)
          have hmono : coverU 𝒞' ⊆ coverU (𝒞.erase T) :=
            Finset.le_iff_subset.mp (Finset.sup_mono hsub)
          exact hmono (hwcov hx)
      · exact hchain w hwcov ⟨V, Finset.mem_erase.mpr ⟨hVT, hV⟩, hwV⟩

/-- **The transfer**: a clean system on a chained ear-free core is a clean system on the full
cover — any team hosting two members routes them into a single core team. -/
theorem capstone_of_core [Fintype ι] (𝒞 𝒞' : Finset (Finset ι)) (hsub : 𝒞' ⊆ 𝒞)
    (hchain : ∀ w : Finset ι, w ⊆ coverU 𝒞' → (∃ V ∈ 𝒞, w ⊆ V) → ∃ W ∈ 𝒞', w ⊆ W)
    (𝒲 : Finset (Finset ι)) (hne𝒲 : 𝒲.Nonempty) (hmem : ∀ w ∈ 𝒲, w ≠ ∅)
    (hhost : ∀ w ∈ 𝒲, ∃ T ∈ 𝒞', w ⊆ T)
    (hclean : ∀ V ∈ 𝒞', ∀ w₁ ∈ 𝒲, ∀ w₂ ∈ 𝒲, w₁ ⊆ V → w₂ ⊆ V → w₁ = w₂)
    (hΔ : xorSum 𝒲 = ∅) :
    ∃ fam : List (LocalStruct ι (fun _ => ZMod 2)),
      fam.map (·.team) = 𝒞.toList ∧ Consistent fam ∧
      (∀ L ∈ fam, L.rel.Nonempty) ∧ ¬ Glues fam := by
  have hcov : ∀ w ∈ 𝒲, w ⊆ coverU 𝒞' := by
    intro w hw
    obtain ⟨T, hT, hwT⟩ := hhost w hw
    exact hwT.trans (Finset.le_sup (f := id) hT)
  refine clean_system_obstruction 𝒞 𝒲 hne𝒲 hmem ?_ ?_ hΔ
  · intro w hw
    obtain ⟨T, hT, hwT⟩ := hhost w hw
    exact ⟨T, hsub hT, hwT⟩
  · intro V hV w₁ hw₁ w₂ hw₂ h₁V h₂V
    obtain ⟨W, hW, hWsub⟩ := hchain (w₁ ∪ w₂)
      (Finset.union_subset (hcov w₁ hw₁) (hcov w₂ hw₂))
      ⟨V, hV, Finset.union_subset h₁V h₂V⟩
    exact hclean W hW w₁ hw₁ w₂ hw₂
      ((Finset.subset_union_left).trans hWsub) ((Finset.subset_union_right).trans hWsub)

/-! ### The chordless-cycle datum -/

/-- A chordless cycle: duplicate-free, length ≥ 4, consecutive pairs hosted, and the only
adjacencies among its vertices are the cyclically consecutive ones. -/
def IsChordlessCycle (𝒞 : Finset (Finset ι)) (l : List ι) : Prop :=
  l.Nodup ∧ 4 ≤ l.length ∧
  (∀ w ∈ cyclePairs l, ∃ T ∈ 𝒞, w ⊆ T) ∧
  ∀ (i j : ℕ) (hi : i < l.length) (hj : j < l.length),
    Adj 𝒞 (l[i]'hi) (l[j]'hj) →
      (i + 1) % l.length = j ∨ (j + 1) % l.length = i ∨ i = j

/-- **Chordlessness is cleanliness**: no team hosts two distinct pairs of a chordless cycle. -/
theorem clean_of_chordlessCycle {𝒞 : Finset (Finset ι)} {l : List ι}
    (h : IsChordlessCycle 𝒞 l) :
    ∀ V ∈ 𝒞, ∀ w₁ ∈ cyclePairs l, ∀ w₂ ∈ cyclePairs l, w₁ ⊆ V → w₂ ⊆ V → w₁ = w₂ := by
  obtain ⟨hnd, h4, hhost, hch⟩ := h
  have h0 : 0 < l.length := by omega
  intro V hV w₁ hw₁ w₂ hw₂ h₁V h₂V
  obtain ⟨a, ha, rfl⟩ := List.mem_iff_getElem.mp hw₁
  obtain ⟨b, hb, rfl⟩ := List.mem_iff_getElem.mp hw₂
  simp only [length_cyclePairs] at ha hb
  by_cases hab : a = b
  · subst hab
    rfl
  · exfalso
    rw [getElem_cyclePairs l h0 a (by simpa using ha)] at h₁V
    rw [getElem_cyclePairs l h0 b (by simpa using hb)] at h₂V
    have ha1 : (a + 1) % l.length < l.length := Nat.mod_lt _ h0
    have hb1 : (b + 1) % l.length < l.length := Nat.mod_lt _ h0
    have hva : l[a] ∈ V := h₁V (Finset.mem_insert_self _ _)
    have hva1 : l[(a + 1) % l.length]'ha1 ∈ V :=
      h₁V (Finset.mem_insert_of_mem (Finset.mem_singleton_self _))
    have hvb : l[b] ∈ V := h₂V (Finset.mem_insert_self _ _)
    have hvb1 : l[(b + 1) % l.length]'hb1 ∈ V :=
      h₂V (Finset.mem_insert_of_mem (Finset.mem_singleton_self _))
    have inj : ∀ {x y : ℕ} {hx : x < l.length} {hy : y < l.length},
        l[x]'hx = l[y]'hy → x = y :=
      fun hxy => (List.Nodup.getElem_inj_iff hnd).mp hxy
    have m_a := mod_succ_cases l.length a ha
    have m_b := mod_succ_cases l.length b hb
    have m_a1 := mod_succ_cases l.length ((a + 1) % l.length) ha1
    have m_b1 := mod_succ_cases l.length ((b + 1) % l.length) hb1
    rcases adj_or_eq_of_cohosted hV hva hvb with hAdj | hEq
    · rcases hch a b ha hb hAdj with h1 | h2 | h3
      · -- (a+1) % n = b: refute via the cross pair (a, (b+1) % n)
        rcases adj_or_eq_of_cohosted hV hva hvb1 with hAdj' | hEq'
        · rcases hch a ((b + 1) % l.length) ha hb1 hAdj' with g | g | g <;>
            rcases m_a with ⟨e1, e1'⟩ | ⟨e1, e1'⟩ <;>
            rcases m_b with ⟨e2, e2'⟩ | ⟨e2, e2'⟩ <;>
            rcases m_b1 with ⟨e3, e3'⟩ | ⟨e3, e3'⟩ <;>
            omega
        · have := inj hEq'
          rcases m_a with ⟨e1, e1'⟩ | ⟨e1, e1'⟩ <;>
            rcases m_b with ⟨e2, e2'⟩ | ⟨e2, e2'⟩ <;>
            omega
      · -- (b+1) % n = a: refute via the cross pair (b, (a+1) % n)
        rcases adj_or_eq_of_cohosted hV hvb hva1 with hAdj' | hEq'
        · rcases hch b ((a + 1) % l.length) hb ha1 hAdj' with g | g | g <;>
            rcases m_b with ⟨e1, e1'⟩ | ⟨e1, e1'⟩ <;>
            rcases m_a with ⟨e2, e2'⟩ | ⟨e2, e2'⟩ <;>
            rcases m_a1 with ⟨e3, e3'⟩ | ⟨e3, e3'⟩ <;>
            omega
        · have := inj hEq'
          rcases m_a with ⟨e1, e1'⟩ | ⟨e1, e1'⟩ <;>
            rcases m_b with ⟨e2, e2'⟩ | ⟨e2, e2'⟩ <;>
            omega
      · exact hab h3
    · exact hab (inj hEq)

/-- The chordless-cycle rung of the converse. -/
theorem obstruction_of_chordlessCycle [Fintype ι] (𝒞 : Finset (Finset ι)) (l : List ι)
    (h : IsChordlessCycle 𝒞 l) :
    ∃ fam : List (LocalStruct ι (fun _ => ZMod 2)),
      fam.map (·.team) = 𝒞.toList ∧ Consistent fam ∧
      (∀ L ∈ fam, L.rel.Nonempty) ∧ ¬ Glues fam :=
  cycle_obstruction 𝒞 l h.1 (by have := h.2.1; omega) h.2.2.1 (clean_of_chordlessCycle h)

/-! ### The assembly, awaiting the dichotomy -/

/-- The clean system of a chordless cycle, in finder form. -/
theorem clean_system_of_chordlessCycle {𝒞 : Finset (Finset ι)} {l : List ι}
    (h : IsChordlessCycle 𝒞 l) :
    ∃ 𝒲 : Finset (Finset ι), 𝒲.Nonempty ∧ (∀ w ∈ 𝒲, w ≠ ∅) ∧
      (∀ w ∈ 𝒲, ∃ T ∈ 𝒞, w ⊆ T) ∧
      (∀ V ∈ 𝒞, ∀ w₁ ∈ 𝒲, ∀ w₂ ∈ 𝒲, w₁ ⊆ V → w₂ ⊆ V → w₁ = w₂) ∧
      xorSum 𝒲 = ∅ := by
  have hnd := h.1
  have h4 := h.2.1
  have hhost := h.2.2.1
  have hlen0 : cyclePairs l ≠ [] := by
    intro hnil
    have hl := length_cyclePairs l
    rw [hnil] at hl
    simp at hl
    omega
  refine ⟨(cyclePairs l).toFinset,
    ⟨(cyclePairs l).head hlen0, List.mem_toFinset.mpr (List.head_mem hlen0)⟩, ?_, ?_, ?_, ?_⟩
  · intro w hw
    exact cyclePairs_ne_empty (l := l) (by omega) (List.mem_toFinset.mp hw)
  · intro w hw
    exact hhost w (List.mem_toFinset.mp hw)
  · intro V hV w₁ hw₁ w₂ hw₂
    exact clean_of_chordlessCycle h V hV w₁ (List.mem_toFinset.mp hw₁)
      w₂ (List.mem_toFinset.mp hw₂)
  · rw [← xorSumL_eq_xorSum (nodup_cyclePairs l hnd (by omega))]
    exact xorSumL_cyclePairs l hnd (by omega)

/-- **The capstone, modulo the dichotomy**: once every ear-free core is non-conformal or has
a chordless cycle (the Dirac edge, URS D26 L6), every non-Graham-reducible cover hosts the base
structure that licenses the verdict: a pairwise-consistent family of nonempty local relations
that no global structure realizes. -/
theorem capstone_of_dichotomy [Fintype ι] (𝒞 : Finset (Finset ι))
    (hng : ¬ GrahamReducible 𝒞)
    (hdi : ∀ 𝒞' : Finset (Finset ι), 𝒞' ⊆ 𝒞 → EarFree 𝒞' →
      ¬ Conformal 𝒞' ∨ ∃ l : List ι, IsChordlessCycle 𝒞' l) :
    ∃ fam : List (LocalStruct ι (fun _ => ZMod 2)),
      fam.map (·.team) = 𝒞.toList ∧ Consistent fam ∧
      (∀ L ∈ fam, L.rel.Nonempty) ∧ ¬ Glues fam := by
  obtain ⟨𝒞', hsub, hef, hchain⟩ := exists_earFree_core_chain 𝒞 hng
  rcases hdi 𝒞' hsub hef with hnc | ⟨l, hl⟩
  · obtain ⟨𝒲, h1, h2, h3, h4, h5⟩ := clean_system_of_uncovered_clique 𝒞' hef.1 hnc
    exact capstone_of_core 𝒞 𝒞' hsub hchain 𝒲 h1 h2 h3 h4 h5
  · obtain ⟨𝒲, h1, h2, h3, h4, h5⟩ := clean_system_of_chordlessCycle hl
    exact capstone_of_core 𝒞 𝒞' hsub hchain 𝒲 h1 h2 h3 h4 h5

end HiddenChannelCapacity
