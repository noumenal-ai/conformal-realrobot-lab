# Structured-Ignorance Factorization — a meta-mathematical analysis

*Status discipline.* This is foundational design (`act(imagine)`), with Dhruv as the
expert verifier. Three labels are used throughout: **[KV]** kernel-verified / established
mathematics; **[DEF]** a definitional commitment we are choosing (not forced, but
identity-fixing); **[CONJ]** a substrate-mapping conjecture to verify against the
literature before banking. The constructivist constraint is standing: route through
subjective frameworks (Halpern plausibility), never anchor in them.

---

## 1. What the field is

**The object.** An *ignorance structure* is the set of co-admissible configurations over
a structured domain — formally a relation `κ ⊆ ∏ᵢ Xᵢ` with a distinguished partition into
a shared interface `S` and private parts. It is the support / possibility datum: *which
joint configurations are jointly admissible*, before any weighting. **[DEF]**

**The theory.** Structured-Ignorance Factorization (SIF) studies the **factorization
obstruction** — whether `κ` decomposes as the product of its projections `∏ᵢ πᵢ(κ)` — and
**grades it constructively** by `hcComb(κ) = |∏ᵢ πᵢ(κ)| − |κ|`, with `hcComb = 0 ⟺` factored.
The central result is the five-way equivalence binding the combinatorial, logical
(interpolation/amalgamation), information-theoretic (CI), and geometric (fiber-product /
global-section) faces of that obstruction. **[KV]** for the finite/propositional and the
Set/FOL legs already formalized.

**What kind of theory.** A **constructive, support-first theory of relational
decomposition** — *not* a measure theory. Standard probability/information theory takes
the distribution as primary and the support as the derived set `{p > 0}`. SIF **inverts
the primacy**: the support (an order/logic object) is primary; the distribution is a
secondary weighting. This inversion is the whole identity of the field. **[DEF]**

---

## 2. The unifying epistemic lens

One sentence: **ignorance is an admissibility structure, factorization is its
decomposition, and the measure is a forgetful weighting on top.**

- **Ignorance-as-admissibility (Axiom 1).** Ignorance is structured and generative, not a
  measure-theoretic lack. Its primary datum is *co-possibility* — a relation / an order /
  a consistent theory — which is a logical, not a measure-theoretic, object. **[DEF]**
- **Support primary, measure secondary.** There is a forgetful functor
  `F : IgnoranceStructures → ProbabilityStructures` that drops order-primacy and adds a
  weighting. Information theory lives in the *target*; SIF lives in the *source*. The
  proven **support↔distribution separation is exactly the statement that `F` is not
  faithful** (rectangular support does not determine the measure; the canonical measure is
  the section that would invert it). **[KV]** (separation witness) / **[CONJ]** (the
  functor framing).
- **The obstruction = irreducible relationality.** `hcComb` measures the coupling that
  *cannot be reconstructed from the parts through the shared interface* — the UK content
  relative to the interface vocabulary.

---

## 3. Strong definition: an ignorance structure

> **[DEF] Definition.** Fix a finite index set and base sorts `(Xᵢ)`. An **ignorance
> structure** is a relation `κ ⊆ ∏ᵢ Xᵢ` equipped with the **projection (cylindrification)
> operators** `πⱼ` (existential marginalization over coordinate `j`), the **rectangular
> hull** `⊗κ = ∏ᵢ πᵢ(κ)` (the maximal ignorance consistent with the marginals), and the
> **factorization grading** `h(κ) = |⊗κ| − |κ|` valued in a **constructive ordered monoid**
> (`ℕ`, or a free commutative monoid for the multi-interface case). `κ` is **factorable**
> when `h(κ) = 0`, i.e. `κ = ⊗κ`.

The **signature** of the field is therefore `⟨ Boolean/relational base ; projections πⱼ ;
hull ⊗ ; constructive grading h ⟩`. The constructivity of `h` (cardinality, decidable,
domain-free) is the non-negotiable commitment that separates SIF from the
distribution-graded (Studený) and subjective (plausibility) cousins. **[DEF]**

---

## 4. Why logic orders are first-class

Because the **carrier is an order, not a measure.** The co-admissibility relation is an
order-theoretic / relational object; factorization is *order decomposition*; and the
logical face (Craig interpolation, model-theoretic amalgamation) is the **syntactic shadow
of that decomposition** — interpolation says the shared vocabulary suffices to mediate the
parts, amalgamation says local order-pieces agreeing on the interface glue to a global
one. These are not corollaries that happen to hold; they are the object *seen
syntactically*. **[DEF]**

The measure is the **forgetful image** under `F` (§2). So the logic legs are first-class
*because the object is a logical/order object and the measure is the derived view* — the
opposite of the standard setup where order is the derived `{p>0}` and the measure is
primary. This is the precise content of "logic orders are first-class in our system": SIF
**refuses the forgetting** that information theory performs by construction.

---

## 5. Where it slots in the math universe

The strongest candidate home, and why:

- **[CONJ — strongest] Abstract algebraic logic: cylindric & polyadic algebras**
  (Henkin–Monk–Tarski). A relation closed under projections is a **cylindric set algebra**;
  rectangular `κ` are its "rectangular / low-dimensional" elements; and **amalgamation of
  the algebra variety ⟺ interpolation of the logic** is the classical Maksimova/Madarász
  correspondence we already cited. This is exactly where the logic legs natively live. SIF
  is then a **constructively-graded fragment of cylindric-type algebra** — cylindric set
  algebras *plus a cardinality grading of non-rectangularity*, which the classical theory
  (equational/Boolean) does not carry. **Verify the precise fit against the cylindric
  algebra literature before banking.**
- **[KV] Sheaf / topos & monoid-consistency.** The local-to-global / global-section view
  (Abramsky; Atserias–Kolaitis monoid-consistency, where support/bags/probability are one
  monoid knob). This is the categorical home of the amalgamation/marginal-problem face.
- **[KV] Model theory.** Amalgamation, types, the compact Polish type-space carrier (the
  FOL lift, already built).
- **[KV] Combinatorics / complexity.** Rectangle defect ↔ nonnegative rank ↔ extension
  complexity (Yannakakis); the marginal-problem complexity ladder (NP-hard → QMA).
- **[KV] Information theory.** The support-shadow of MI (Gács–Körner / the secondary
  weighting).

**The unifying placement:** SIF is the **constructive, support-first theory of
local-to-global obstructions for graded relational structures** — the corner where
abstract algebraic logic, order theory, and sheaf theory meet, carrying a constructive
cardinality grading that is native to none of them. That grading is the field's own
contribution; everything else it routes through.

---

## 6. How to interpret it

`hcComb` is the **degree of irreducible relationality**: the part of the whole that the
parts plus the shared interface cannot reconstruct. The four faces are one obstruction —
*the failure to reconstruct the whole from the parts through a shared interface* — wearing
four vocabularies: a missing-cell count (combinatorics), a definability gap (logic), a
positive mutual information (information), a missing global section (geometry/physics).

---

## 7. Does it need an axiom/rule addition to be an independent formal system?

**As a theory: no.** `hcComb` + the five-way are kernel-verified and definable in ZFC /
finite combinatorics. Well-definedness is not in question. **[KV]**

**As an independent formal *system*: the move is a signature, not a new mathematical
axiom.** What no ambient system carries is the **constructive factorization grading `h` as
a first-class invariant on relational structures, definitionally co-equal with the
logic-order characterization.** The recommendation is to **promote
`⟨ πⱼ , ⊗ , h ⟩` to a primitive algebraic signature and define the variety of *graded
ignorance structures*** — a constructive-graded cousin of cylindric algebras — with these
laws:

1. **Projection laws** (cylindric: `πⱼ` idempotent/closure, projections on distinct
   coordinates commute). **[KV import]**
2. **Hull law.** `⊗κ = ∏ᵢ πᵢ(κ)` is the least rectangular element above `κ`. **[KV]**
3. **Grading law.** `h : structures → constructive ordered monoid`, monotone, with
   `h(κ) = 0 ⟺ κ = ⊗κ`. **[DEF — the new primitive]**
4. **Coherence law (the five-way as an axiom of the variety, not an instance theorem).**
   factorability ⟺ interpolation ⟺ amalgamation ⟺ CI ⟺ fiber-product — promoted from
   "a theorem proved per model" to **the defining coherence of the object**, so that an
   ignorance structure *is* a thing on which these four views coincide, and the field's
   open frontier is precisely where a refinement (weighting, infinite carrier) makes them
   **diverge** (the separation). **[DEF]**

The single **new primitive** is law 3 + law 4 read together: *a constructive grading of
relational non-factorability, with the logic-order view co-equal by definition.* That is
what makes the system independent (it is not interpretable into cylindric algebra,
Studený's distribution cone, or information theory without adding exactly this), and it is
what differentiates it sharply: **SIF is the unique framework that (a) takes the
support/order primary, (b) grades the obstruction constructively, and (c) makes the
logic-order characterization co-equal with the combinatorial and information ones.**

---

## 8. The open foundational decisions (for the expert in the loop)

1. **Grading codomain.** `ℕ` (bipartite) vs a free commutative monoid / an ordered
   semiring (multi-interface, higher arity). The choice fixes whether the variety is
   one-sorted or graded-by-a-monoid (and connects to Atserias–Kolaitis).
2. **Is the five-way a definition or a theorem?** Promoting it to a coherence *law*
   (law 4) makes the system independent but commits to studying divergence as the content;
   leaving it a theorem keeps SIF a fragment of cylindric algebra + info theory.
3. **Cylindric fit.** Verify the algebraic-logic placement (§5) before banking — it is the
   load-bearing [CONJ], and if it holds it gives SIF an immediate representation theory,
   variety structure, and a 70-year toolkit (Henkin–Monk–Tarski) to differentiate within.

---

## 9. Verification of the cylindric placement — CONFIRMED [was CONJ, now established by primary sources, 2026-06-30]

A strict-relevance probe (anti-vacuity discipline: generic "relations + projections"
matches rejected as non-findings) grounded all four questions in fetched primary sources
(Monk, *Leon Henkin and Cylindric Algebras*; Sayed Ahmed, arXiv:1309.0681; Mann
arXiv:0711.4376; Kohlas arXiv:1804.02840).

- **Q1 — the object IS a cylindric set algebra; "rectangular" is a NAMED notion. CONFIRMED
  (direct, not analogy).** Cylindrification = coordinate projection (Monk:
  `CᵢX = {a : ∃b∈X, aⱼ=bⱼ for all j≠i}`); a rectangular element is defined
  `a rectangular iff c(Γ)a · c(Δ)a = c(Γ∩Δ)a` — the algebraic encoding of "a is the product
  of its projections." The dimension theory (`Δx`, 0-dimensional elements) is present. The
  substrate is a literal structural fit.
- **Q2 — DECISIVE: no constructive cardinality grading of non-rectangularity exists in
  cylindric / polyadic / relation algebra. ABSENT.** Rectangularity is a *Boolean
  predicate*; the dimension set is *index-valued*, not numeric; "rectangular" does not even
  appear in the 977 KB Sayed Ahmed survey. **`hcComb(κ) = |∏ᵢπᵢ(κ)| − |κ|` is a genuine new
  primitive laid on the cylindric substrate — not a rediscovery.**
- **Q3 — interpolation ⟺ (super)amalgamation attaches precisely. CONFIRMED.** It is a named
  theorem in the cylindric/polyadic setting (Sayed Ahmed; Madarász; Sági; Németi), the
  canonical Maksimova form "logic has Craig interpolation iff the variety has the
  super-amalgamation property." The logic legs sit on real algebra.
- **Q4 — the CI/MI leg and the fiber-product/global-section leg are ABSENT from algebraic
  logic.** ("IF-cylindric independence" = Hintikka quantifier-independence, rejected
  vacuous; Kohlas CI = valuation/information-algebra substrate, not cylindric.) **The
  five-way's information + geometric bridges are SIF's own, not pre-existing.**

**Net:** SIF is, established, **a constructively-graded fragment of cylindric set algebra**.
Substrate + logic legs are INHERITED (a 70-year Henkin–Monk–Tarski toolkit comes with
them); the **constructive grading and the cross-domain bridges (CI, fiber-product) are the
new primitives.**

## 10. The independent formal system, now pinned: **graded cylindric set algebras**

§7 asked whether to add an axiom; §9 fixes exactly what and where. The projection/hull
signature is NOT to be reinvented — it is already the cylindric set algebra signature
(Boolean ops + cylindrifications `cᵢ` + diagonals `dᵢⱼ`). The independent system is that
signature **enriched with exactly one new primitive**: a grading

> `h : A → (constructive ordered monoid)`,  monotone,  with the **coherence law**
> `h(a) = 0 ⟺ a is rectangular ⟺ interpolation ⟺ amalgamation ⟺ CI ⟺ fiber-product`.

So the field's well-defined, independent formal system is **the variety of graded cylindric
set algebras** — Henkin–Monk–Tarski cylindric set algebras carrying a constructive
non-rectangularity grading whose zero-locus is the five-way. One new primitive (the
grading), one new law (the coherence), on a 70-year substrate. That is the minimal,
honest, and maximally-differentiated axiomatic identity for the field.

---

## 11. The interpretation — a geometric foundation for uncertainty [THESIS]

The correct reading of the whole field, stated at full strength:

> **Uncertainty is defined here geometrically, not measure-theoretically.** The object of
> study is the *possibility-structure* — which configurations are co-admissible, a Stone
> space / relational object — and uncertainty is the **cohomological obstruction** to
> reconstructing the whole from its parts over a shared interface. `hcComb` is the
> **magnitude of that obstruction**: an integer invariant of a geometric object (an
> Euler-characteristic / Betti-number reading), whose roots are **cohomological**, not
> arithmetic. The count is the numerical shadow of the geometry, not a primitive.

This is the **Kolmogorov-dual** foundation. Kolmogorov grounds uncertainty in *measure*
(σ-additivity over ℝ — analytic/arithmetic roots, the distribution primary). This field
grounds uncertainty in the *geometry of the possibility-structure* (cohomology over a Stone
base — geometric roots, the support primary). They are **base ⊥ fibre** of the fibration
`F : measures ↦ supports` (§6/§9): Kolmogorov works in the fibre, this field works in the
base; the canonical measure is a *section*.

**Why it intersects everywhere — as a corollary, not a coincidence.** Local-to-global
obstruction is a *substrate-independent* geometric phenomenon (it is defined over any site /
topos). Cohomology is its universal home. Therefore a cohomological theory of ignorance
**instantiates in every substrate where parts and wholes are distinguishable** — logic
(amalgamation), statistics (the marginal problem), physics (contextuality), complexity
(CSP/consistency), databases (join consistency), model theory (types). The field "intersects
everywhere" *because* it is geometric: the universality is the signature of a genuine
universal, exactly as cohomology itself appears everywhere. **[KV that the legs instantiate;
the unifying corollary is CONJ pending the theorem below.]**

**Why "the structure of ignorance" is literally the object.** If uncertainty is the geometry
of co-possibility and its obstruction, the field studies that structure *directly* — not via
a measure-theoretic proxy. URT Axiom 1 (ignorance is structured and generative, not a lack)
is here given a **geometry**.

**The theorem that "proving that" requires — the cohomological-roots theorem (= the Rosetta
stone, reframed).** Construct a cohomology theory `H•` on ignorance structures such that:
(i) the factorization obstruction is a class in `H•` (`H•` trivial ⟺ rectangular ⟺ the
five-way), and (ii) `hcComb` is its **degree-0 invariant / Euler characteristic**. Proving
this would establish that the measure has geometric roots, would *derive* the universality
as a corollary, and would identify amalgamation-homology with contextuality-cohomology
(the flagship). **[CONJ — this is the field's deepest and hardest claim; everything else is
the scaffolding that makes it well-posed.]**

Status discipline: the carrier-as-Stone-space and the obstruction-as-cohomology (contextuality
side: Abramsky–Mansfield–Barbosa; CSP side: Ó Conghaile) are **[KV]**; `hcComb` as the Euler
characteristic of a *single unifying* `H•` is **[CONJ]**; "geometric foundation for
uncertainty" is the **thesis/stance** this conjecture, if proved, establishes.

### 11.1 The fibre-side sibling — Cuzzolin's geometry of uncertainty [KV program; complementarity interpretive]

Cuzzolin's **"geometry of uncertainty"** (Springer 2021; *Geometry of relative plausibility and
relative belief of singletons*, Ann. Math. Artif. Intell. 2010) represents belief functions as
points in `ℝ^(2^|Θ|−2)` and studies probability transformations as lines, projections, planes
and angles, deriving an uncertainty measure `R[b]` from **orthogonality** in that space. It is a
real, developed geometric foundation for uncertainty — but it geometrizes the **measure side**:
the simplex of belief functions = the **fibre** of `F : measures ↦ supports`, with a **metric /
convex / Euclidean** geometry.

SIF geometrizes the **base** (supports) with a **topological / cohomological (non-metric)**
geometry. **Same Boolean/subset lattice, same Möbius transform; opposite objects** (measures-on-
the-lattice vs structure-of-the-lattice), **opposite geometries** (metric vs cohomological). So
Cuzzolin is the **fibre-side sibling**, and the strongest *external* evidence that the
base-geometry SIF occupies is a real, unoccupied complement — there is literally a developed
geometry of the fibre in the literature, and the base is empty.

**Discipline (route through, never home — same rule as Halpern).** Dempster–Shafer belief
functions are a *credal/subjective* framework (plausibility functions are part of it), and
Cuzzolin's is a *metric* geometry of the *fibre*. So: **cite him as the fibre-side sibling,
borrow the geometry→measure method (sharpened by contrast: his measure is an angle, SIF's is an
Euler characteristic), use belief functions — mass on subsets — as the concrete meeting point of
the two geometries — but never anchor home there.** SIF's home stays the constructive,
cohomological base. See [[feedback_route_through_plausibility_not_home]].
