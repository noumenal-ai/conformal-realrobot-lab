# QJT_LEDGER — Lauritzen–Zwiernik derivation ledger (extraction record)

Extracted 2026-07-07 by an Opus reader agent from the authoritative arXiv PDF
(2605.19453v2, 30 Jun 2026, 33 pages, complete). The paper postdates the assistant
knowledge cutoff: every statement below came from fetched text, cross-checked against the
ar5iv render (which, note, hallucinated a nonexistent "Theorem 2.3" in one pass; the
PDF's real numbering is used throughout). This file is the single formalization source
for the QJT arc; companion: QJT_URS.md.

**Global positivity convention (load-bearing for Lean):** the paper works almost entirely
in the strictly positive cone. S₁⁺(H) = PosDef density operators (p.4). Every main
theorem assumes strictly positive marginals. PSD-but-singular states appear only in the
Pauli feasibility boundary (Lemma 4.4, ε²+δ² = 1: every completion singular).

---

## PART 1: DEFINITIONS (exact)

- **Def 2.1 (p.4).** For M, N in the PosDef cone: `M ⊙ N := exp(log M + log N)`
  (log-linear; commutative, associative). `M ⋆ N := N^{1/2} M N^{1/2}` (sandwich; neither
  commutative nor associative). `M ⊙ N = M ⋆ N ⟺ [M, N] = 0`, and then both = MN.
- **Partial trace (p.4).** Tr_A : L(H_{A∪B}) → L(H_B) unique linear map with
  Tr((I_A ⊗ M)ρ) = Tr(M Tr_A(ρ)) (eq. 2); Tr_A(X ⊗ Y) = Tr(X)Y (eq. 3).
- **Entropy/divergence (p.5).** S(ρ) = −Tr(ρ log ρ). EXTENDED von Neumann divergence for
  non-trace-one PosDef (eq. 4): `D(X‖Y) := Tr(X log X) − Tr(X log Y) − Tr(X) + Tr(Y)`.
  Klein: D ≥ 0, = 0 ⟺ X = Y. On density operators the trace terms cancel (Umegaki).
- **Def 2.4 (p.6): quantum CI = CMI-zero.** I(A:B|C)_ρ := S(ρ_{AC}) + S(ρ_{BC}) − S(ρ_C)
  − S(ρ) ≥ 0 (SSA). A ⊥⊥_Q B | C [ρ] ⟺ I(A:B|C)_ρ = 0. Log form for strictly positive ω
  (p.9): ⟺ log ω = log ω_{AC} + log ω_{BC} − log ω_C (embedded). Petz form: Prop A.11.
- **Def 3.7 (p.12): GLOBAL Markov property** w.r.t. G: graphical separation implies
  quantum CI, for all disjoint triples. (Leifer–Poulin used local; equivalence hinges on
  the intersection property, Prop 2.5.)
- **Chordal/junction tree (§2.4, p.6).** Cliques C, junction tree with running
  intersection, separators S = adjacent-clique intersections with multiplicity ν(S)
  (junction-tree independent). Running example (Fig. 1): 7 vertices, cliques
  {1,2,3},{2,4,5},{2,5,6},{2,6,7}; separators {2},{2,5},{2,6}.
- **T(R), two-clique (eq. 5, p.7).** Consistent pair ρ_{AC}, ρ_{BC} (common ρ_C):
  `T(R) := exp(log ρ_{AC} + log ρ_{BC} − log ρ_C) = ρ_{AC} ⊙ ρ_{BC} ⊙ ρ_C^{−1}`,
  every operator embedded into L(H_{ABC}) by tensoring with the identity BEFORE logs.
- **T(R), chordal (eq. 11, p.13).** `T(R) := exp(Σ_C log ρ_C − Σ_S ν(S) log ρ_S)`,
  embeddings as above.
- **M(R) (p.7).** The feasible set: strictly positive global states with the prescribed
  marginals. Quantum Markov completion = element of M(R) that is quantum Markov on G.
- **Sandwich reconstructions (p.10).** ρ_{A|B} := ρ_B^{−1/2} ρ_{AB} ρ_B^{−1/2} (direct
  conditional; Tr_A ρ_{A|B} = I_B). K := ρ_{AC}^{1/2} ρ_C^{−1/2} ρ_{BC}^{1/2} (eq. 1).
  One-sided reconstructions: ρ_{B|C} ⋆ ρ_{AC} = KK*, ρ_{A|C} ⋆ ρ_{BC} = K*K. Equal ⟺ K
  normal. **Def 3.5:** Markov compatible over C (⊛) when K normal.
- **gI (eq. 10, p.13).** `gI(G)_ρ := Σ_C S(ρ_C) − Σ_S ν(S) S(ρ_S) − S(ρ)` ≥ 0 (Prop
  3.9), = 0 ⟺ ρ quantum Markov on G. Complete G: always 0. Empty G: quantum total
  correlation. Two-clique: = I(A:B|S)_ρ.

## PART 2: THEOREM INVENTORY

| # | Content | Positivity |
|---|---|---|
| Lem 2.2 | iterated marginalization composes | trace-one |
| Lem 2.3 (Pull-out) | Tr_A((I_A⊗M)ρ) = M·Tr_A(ρ), and right version. "Most useful identity in the paper" | none |
| Prop 2.5 (Intersection) | strictly positive: A⊥⊥_Q B\|(C∪D) and A⊥⊥_Q D\|(B∪C) ⟹ A⊥⊥_Q (B∪D)\|C. Graphoid; makes pairwise/local/global Markov equivalent. App A.6 | **PosDef** |
| **Thm 3.1** | two-clique: Tr(T(R)) ≤ 1; TFAE (i) = 1, (ii) T(R) ∈ M(R), (iii) ∃ Markov completion. Then T(R) unique | **PosDef** |
| Lem 3.2 | `D(ω‖T(R)) + 1 − Tr(T(R)) = I(A:B|C)_ω + Δ_R(ω)`, Δ_R(ω) := D(ω_{AC}‖ρ_{AC}) + D(ω_{BC}‖ρ_{BC}) − D(ω_C‖ρ_C) ≥ 0 (DPI) | S₁⁺ |
| Lem 3.3 | ρ_{B\|C} ⋆ σ_{AC} is a state with the right A∪C-marginal and conditional | S₁⁺ |
| Prop 3.4 | Thm 3.1 conditions ⟺ **K normal**; then T(R) = KK* = K*K = both sandwiches (cites Zhang 2013 Thm 2.1) | **PosDef** |
| Lem 3.8 | chordal decomposition (A,B,S): Markov on G ⟺ Markov on both induced pieces + A⊥⊥_Q B\|S. Semigraphoid axioms only | S₁⁺ |
| Prop 3.9 | chordal SSA: S(ρ) ≤ Σ_C S(ρ_C) − Σ_S ν(S)S(ρ_S); equality ⟺ Markov. Induction on cliques; base = SSA | S₁⁺ |
| **Thm 3.10** | chordal: Tr(T(R)) ≤ 1; TFAE as in 3.1; T(R) unique Markov completion AND unique max-entropy element; S(T(R)) = Σ_C S(ρ_C) − Σ_S ν(S)S(ρ_S) | **PosDef** |
| Lem 3.11 | `D(ω‖T(R)) + 1 − Tr(T(R)) = Σ_C S(ρ_C) − Σ_S ν(S)S(ρ_S) − S(ω)` for ω ∈ M(R) | S₁⁺ |
| Prop 3.12 | gI(G)_ρ = D(ρ‖T(R_ρ)) + 1 − Tr(T(R_ρ)) | S₁⁺ |
| Lem 3.13 | three-point identity D(ρ‖τ) = D(ρ‖σ) + D(σ‖τ) + ⟨ρ−σ, log σ − log τ⟩ | S₁⁺ |
| Thm 3.14 | max-entropy ⟺ log ρ̂ = λI + Σ_A (M_A ⊗ I); any feasible family; gives S(ρ̂) − S(ω) = D(ω‖ρ̂) | S₁⁺ feasible |
| Rem 3.15 | quantum departure: max-entropy completion can exist WITHOUT being Markov (Ex 4.3) | — |
| Lem 4.1/4.2 | anticommuting Pauli words: T = Σ a_i W_i, T² = r²I; ρ = 2^{−n}(I+T) PosDef ⟺ r < 1; log ρ = log(√(1−r²)/2^n)·I + (arctanh(r)/r)·T | r < 1 |
| Ex 4.3/Lem 4.4 | ρ₁₂ = ¼(I+εX⊗X), ρ₂₃ = ¼(I+δZ⊗Z): feasible ⟺ ε²+δ² ≤ 1 | boundary singular |
| Lem 4.5 | A,B ≻ 0: A^{1/2}B^{1/2} normal ⟺ AB = BA | PosDef |
| Lem 4.6 | Markov completion exists ⟺ εδ = 0 ([ρ₁₂,ρ₂₃] = (εδ/16)[W₁,W₂]) | strict |
| Lem 4.7 | Tr(T(R)) = cosh r/(cosh b · cosh d), b = arctanh ε, d = arctanh δ, r = √(b²+d²); = 1 ⟺ εδ = 0 | strict |
| Rem 4.8 | Markov does NOT imply commuting overlapping marginals (σ₁ ⊗ σ₂₃ caution) | — |
| §4.4 | 7-qubit chordal Pauli: W₁ = X₁X₂X₃, W₂ = Y₂X₄X₅, W₃ = Y₂Y₅X₆, W₄ = Z₂X₆X₇ pairwise anticommuting; Tr(T(R)) = cosh r/Π cosh b_j; = 1 ⟺ at most one a_j ≠ 0 | strict |
| Prop A.7 | DPI for partial trace (self-contained finite-dim proof) | PosDef |
| Prop A.9 | equality-DPI criterion: X_t^{ρ,τ} ∈ im(J_A) for all t | PosDef |
| Prop A.10 | Petz recovery for partial trace: equality ⟺ ρ = τ^{1/2}(τ_A^{−1/2}ρ_A τ_A^{−1/2} ⊗ I_B)τ^{1/2} (eq. 20) | PosDef |
| Prop A.11 | I(A:B|C)_σ = 0 ⟺ σ = σ_{BC}^{1/2}σ_C^{−1/2}σ_{AC}σ_C^{−1/2}σ_{BC}^{1/2} (eq. 26) | PosDef |

## PART 3: PROOF SKELETONS

**Thm 3.1 (two-clique).** Trace bound: (1) Lieb's three-matrix inequality (Ruskai 2002
Thm 5): Tr(T(R)) ≤ Tr ∫₀^∞ ρ_{AC}(tI+ρ_C)^{−1} ρ_{BC}(tI+ρ_C)^{−1} dt. (2) Pull-out
collapses the integrand to Tr(ρ_C²(tI+ρ_C)^{−2}). (3) Spectral: Σ_i ∫ λ_i²/(t+λ_i)² dt =
Σ λ_i = 1. Equivalences: engine = Lem 3.2. (i)⟹(ii),(iii): apply 3.2 at ω = T(R): 0 =
I + Δ_R, both ≥ 0, both vanish; Δ_R = 0 + DPI forces marginal equalities via Klein.
(iii)⟹(i),(ii): apply 3.2 at the Markov ω: 0 = D(ω‖T(R)) + 1 − Tr(T(R)), both ≥ 0 ⟹
Tr = 1 and ω = T(R) (uniqueness). Tools: pull-out, Lem 3.2, DPI-INEQUALITY only, Klein.

**Prop 3.4.** Forward: Markov completion + Prop A.10/A.11 (Petz) gives both sandwich
identities ⟹ K normal. Converse: K normal ⟹ ω := KK* = K*K ∈ M(R) (pull-out) and the
Petz shape ⟹ CMI = 0 (A.11) ⟹ Markov, unique by 3.1. NEEDS equality-DPI/Petz.

**Thm 3.10 (chordal).** c := Tr(T(R)), σ := T(R)/c. log c = −[Σ_C D(σ_C‖ρ_C) −
Σ_S ν(S)D(σ_S‖ρ_S)] + [S(σ) − Σ_C S(σ_C) + Σ_S ν(S)S(σ_S)] (eq. 13). Second bracket ≤ 0
by Prop 3.9; first bracket ≥ 0 by induction on junction-tree LEAVES: leaf clique C₀ with
separator S₀ contributes D(σ_{C₀}‖ρ_{C₀}) − D(σ_{S₀}‖ρ_{S₀}) ≥ 0 by DPI, remainder by IH.
Equivalences mirror 3.1 with Lem 3.11 as the engine and Prop 3.9's equality case for the
Markov property; max-entropy leg via Thm 3.14 (log T(R) manifestly log-linear). The
junction-tree-leaf induction is the structural core; base case of 3.9 = SSA.

**App A (the Petz module, self-contained, finite-dim).** Weighted operator space
⟨X,Y⟩_ρ := Tr(X*Yρ); relative modular operator Δ_{τ,ρ}(X) := τXρ^{−1}. Chain: A.1
(Δ positive self-adjoint), A.2 (D(ρ‖τ) = −⟨I, log Δ · I⟩_ρ), A.3 (completion-of-square
variational identity), A.4 (integral variational formula for D with maximizer
X_t = (tI+Δ)^{−1}I), A.5 (J_A(X) = X⊗I_B is a weighted-space isometry with
J_A*Δ_{τ,ρ}J_A = Δ_{τ_A,ρ_A}), A.6 (f_t(J_A X) = f_t^{marg}(X)), A.7 (DPI: restricted
max ≤ full max), A.9 (equality ⟺ maximizer in im(J_A) for all t), A.10 (resolvent-to-
Petz conversion via polynomial functional calculus; converse via the Petz CPTP map +
DPI), A.11 (specialize τ = σ_A ⊗ σ_{BC}; eq. 25: D(σ‖τ) − D(σ_{AC}‖τ_{AC}) = I(A:B|C)).
Prop 2.5 (intersection) proof: two equality-in-monotonicity statements force the
maximizer constant in both B and D coordinates, conclude via A.9 again.

## PART 4: API MAP (grades against the 2026-07-07 floor)

- ⊙, ⋆, K, normality predicate: EASY (HermitianMat.log/exp/sqrt/rpow present).
- T(R) two-clique: MEDIUM (embeddings via relabel/piProd = our ptraceS plumbing).
  T(R) chordal: HARD only in the junction-tree indexing (OUR combinatorics covers it).
- Pull-out (Lem 2.3): EASY new lemma over traceLeft/traceRight.
- qcmi: PRESENT (definitional match); SSA: PRESENT.
- Extended divergence D(X‖Y) with trace correction: MEDIUM new definition + Klein.
- **Lieb three-matrix inequality (Ruskai Thm 5): HARD, self-contained; Lieb–Ando
  backbone present; resolvent integrals via cfc; pseudo-inverse via cfc + supportProj.**
- Spectral integral ∫λ²/(t+λ)²dt = λ: EASY via cfc.
- **DPI-inequality: PRESENT (sandwichedRenyiEntropy_DPI at α = 1). The whole inequality
  spine of Thm 3.1/3.10 runs on tools we HAVE.**
- **Equality-DPI/Petz (A.9/A.10/A.11, Prop 3.4, Prop 2.5): ABSENT; the paper's App A is
  a self-contained finite-dim construction we formalize ourselves. Needs left/right
  multiplication superoperators + joint functional calculus. THE make-or-break module.**
- Semigraphoid Q1–Q4 from qcmi + SSA: MEDIUM. Prop 3.9 induction: HARD (junction-tree
  leaves; our RIP/ear machinery is the substrate). Thm 3.14: MEDIUM–HARD.
- Pauli examples: MEDIUM, self-contained; needs arctanh/cosh + cfc on 2-eigenvalue
  states. Excellent CI test vectors.

**Feasibility verdict:** inequality spine (trace bounds + identities + existence
equivalences (i)⟺(ii) and the (iii)⟹ direction) reachable with current floor + Ruskai
assembly. Characterization spine (K-normality, intersection, uniqueness-via-Petz) gated
on formalizing App A.

## PART 5: PAULI TEST VECTORS (exact)

Ex 4.3: H = (ℂ²)^⊗3; W₁ = X⊗X⊗I on {1,2}, W₂ = I⊗Z⊗Z on {2,3}, anticommuting.
ρ₁₂ = ¼(I+εXX), ρ₂₃ = ¼(I+δZZ), |ε|,|δ| < 1, consistent (ρ₂ = I/2). Feasible ⟺
ε²+δ² ≤ 1 (witness σ = ⅛(I+εW₁+δW₂); infeasibility via ‖T‖ = √(ε²+δ²)). Markov
completion ⟺ εδ = 0. Tr(T(R)) = cosh r/(cosh b cosh d) with b = arctanh ε, d = arctanh δ.
Max-entropy completion exists on the whole strict region but is Markov only on εδ = 0:
the separations local-consistency ⊋ feasibility ⊋ Markov-feasibility all realized.
§4.4 (7 qubits, Fig-1 chordal graph): four pairwise-anticommuting words (X₁X₂X₃, Y₂X₄X₅,
Y₂Y₅X₆, Z₂X₆X₇), clique marginals ⅛(I+a_jW_j), separators maximally mixed;
Tr(T(R)) = cosh r/Π cosh b_j; = 1 ⟺ at most one a_j ≠ 0. Rem 4.8: σ₁⊗σ₂₃ is Markov with
possibly non-commuting overlapping marginals (caution against commutation-based defs).

## PART 6: NON-CHORDAL (the open problem, verbatim-grounded)

The trace criterion is proved ONLY for two-clique and chordal clique families. Off
chordal graphs T(R) is NOT EVEN DEFINED (no junction tree, no canonical separator
multiplicities). Thm 3.14's dual/log-linear characterization holds for any FEASIBLE
family but does not decide feasibility, gives no trace test, and its maximizer need not
be Markov (Rem 3.15). The paper (p.16): "even in the classical situation there is no
simple condition for M(R) to be non-empty unless A is the set of cliques of a chordal
graph." General consistency is QMA-complete (Liu 2006); Fraser 2022 gives countable
necessary inequalities; Kim 2021 entropy criteria. THE OPEN TARGET: a verifiable
criterion (trace-type or cohomological) for quantum Markov / feasible completion on
non-chordal covers, where the logarithmic candidate has no canonical form.

## PART 7: NOT-EXTRACTED

Fig. 1's drawn geometry beyond what the clique/separator lists force (the lists
themselves are authoritative); bibliographic identifiers not independently verified.
No technical gaps: all definitions, theorems, both main proof skeletons, all of App A,
and all Pauli computations extracted from the PDF directly.

Local copy of the fetched PDF (for re-reference without re-fetch):
`/Users/polaris/.claude/projects/-Users-polaris-Documents-Epistemology-and-Zetesis-Projects-formal-learning-theory-kernel--claude-worktrees-competent-albattani-a63655/d84b56da-d0d9-49ff-b836-47b62be8bfc8/tool-results/webfetch-1783379198561-l5lv3e.pdf`
