# The Geometry of Ignorance
## Field note — what this field is, and why it is fundamental

**Status.** Draft v0.3, internal, 2026-07-07. Updated at the close of the flagship-evidence
and quantum arc: the CHSH/PR-box leg lands in the kernel (contextuality of the CHSH
scenario ⟺ its cover's cyclicity, both directions), and a pre-registered, adversarially
verified candidate battery produces the first structural evidence on the flagship's
counting identity: the affine direction-presheaf Čech complex ([NUM], §8), the
entropy-valued junction-tree identity ([NUM], §8), and a no-go for cardinality-χ-additive
carriers, with the Dowker route and the naive counting telescope refuted.
v0.2 (2026-07-03) closed the discrete local-to-global arc: the amalgamation stack, the
Graham/GYO decidability bridge, the affine obstruction engine, and the **discrete Vorob'ev
converse**: the local-to-global gluing characterization on covers, whose hard direction
manufactures an explicit non-gluing witness from the cover's cyclic structure. That landed
the flagship's H¹-side (§8) on the discrete, multi-context nerve, entirely in the kernel.
v0.1 (2026-07-02) closed the foundation-fixing arc: the two-pass novelty certification, the
cylindric-algebra placement probe, the information-cohomology collision probe, the
complexity-bridge probes, the Moonshine rejection, and the adoption of the geometric frame.
Companion documents: `FOUNDATIONS.md` (the meta-mathematical analysis), the consolidated
build ledgers and per-subsystem discovery URSs under `discovery/` (indexed by the full
`discovery/SHAPE_OF_IGNORANCE_DISCOVERY_URS.md`, gitignored), the Lean corpus under
`ZPM/Measurements/HC/` (the proofs).

**Claim discipline, used throughout.**
**[KV]** kernel-verified: Lean 4, zero `sorry`, axioms at most
`propext, Classical.choice, Quot.sound` (several results use none at all).
**[NUM]** numerically verified: exact-arithmetic computation over pre-registered witness
zoos and randomized batteries (hundreds of instances), independently re-implemented by an
adversarial verifier before acceptance; not yet kernel-checked. A [NUM] law with a proof
sketch is a formalization target, not a theorem.
**[PROBE]** established by adversarial literature audit against fetched primary sources,
under a strict anti-vacuity rule (generic resemblance = non-finding).
**[CONJ]** conjecture, named as such.
**[STANCE]** interpretive position — what the conjectures, if proved, would establish.

---

## 0. The one-paragraph answer

This field studies the *shape of the possible* before anything is weighed. Its object is
the possibility-structure — the bare relation `κ ⊆ ∏ᵢ Xᵢ` of jointly admissible
configurations over a shared interface — and its measure is the constructive integer

> `hcComb(κ) = |∏ᵢ πᵢ(κ)| − |κ|`,

the number of configurations the interface permits but the joint forbids. The central
theorem **[KV]** is that the vanishing of this one number is simultaneously a
combinatorial statement (κ is a rectangle), a logical statement (Craig interpolation
holds across the interface), a model-theoretic statement (amalgamation), an
information-theoretic statement (mutual information vanishes at the canonical measure),
and a geometric statement (the fiber product surjects; a global section exists). The
field's identity: it is the **support-side geometry of uncertainty** — the base of the
fibration `F : measures ↦ supports` whose fibre is Kolmogorov's probability theory. Its
formal home is **graded cylindric set algebra** [PROBE]. Its governing thesis
**[STANCE]**: the measure has geometric roots — it is the Euler-characteristic shadow of
a local-to-global obstruction — and not arithmetic ones. Probability theory weighs the
possible; this field measures its shape.

---

## 1. The objection this note exists to answer

Seen from any one discipline, the field looks like a collage. Combinatorial rectangles
belong to communication complexity. Craig interpolation belongs to proof theory (1957).
Amalgamation belongs to Robinson and Fraïssé. Mutual information belongs to Shannon.
Fiber products and global sections belong to category and sheaf theory. Stone spaces
belong to topology; contextuality to quantum foundations; conditional independence to
statistics. A reader encountering the field's vocabulary meets eight disciplines in as
many pages and reasonably suspects a pastiche: distinct ideas cut and pasted under a new
name.

The objection dissolves in three steps, and the third is the important one.

**First: the pieces are not analogous — they are provably identical.** A pastiche is held
together by resemblance; this field is held together by a theorem. The five
characterizations above are not "related notions" but *equivalent conditions on the same
object*, and the equivalence is machine-checked end to end (`fiveWay_full`,
`fiveWay_fol`) **[KV]**. Each face was indeed discovered separately, decades ago, in its
home discipline. What no discipline owned — because each owned only its face — is the
solid. The two-pass novelty audit confirmed this at the strongest available standard: the
bridge from the logic pair (interpolation/amalgamation) to the information side (MI/CI)
appears in **no examined work in any field** [PROBE]. Maksimova's
interpolation⟺amalgamation correspondence is fifty years old and stays inside algebraic
logic; Shannon's MI=0 criterion stays inside statistics. The identity of the five faces
is new mathematics, and it is the field's first possession.

**Second: the unity survived deformation.** A pastiche frays when you stretch it, because
its seams are rhetorical. We stretched this object twice. Lifting from finite supports to
first-order type spaces (compact Polish Stone carriers), the five faces moved *together*
— and where they genuinely came apart, the divergence was itself a theorem, not a tear:
the support↔distribution separation (`Pcorr`: rectangular support with `MI > 0`)
**[KV]**, the Beth-conditionality of the forward interpolation direction in genuine FOL
**[KV]**, the single-context/multi-context split against sheaf contextuality [PROBE].
An artifact of stitching does not produce kernel-checked theorems about exactly where its
own seams lie.

**Third — the inversion: universality masquerades as eclecticism.** The reason the field
touches logic, statistics, physics, complexity, databases, and learning is not that it
borrowed from each. It is that the local-to-global failure of relational structure is a
*substrate-independent* phenomenon, and each discipline contains one of its shadows.
Anything genuinely universal reads, at first contact, as trespass on everyone's land —
this was said of cohomology, and of category theory, before their unifications were
absorbed. The correct inference from "it appears everywhere" is not "it is a collage of
everywhere" but "it is upstream of everywhere it appears." The falsification record backs
this reading: we adversarially tried to dissolve the field into its neighbours five
separate times — the ancestor audit, the cylindric probe, the information-cohomology
probe, the complexity probes, the Moonshine test — with explicit license to return
"kill." One target died (Moonshine, correctly). The field did not dissolve; it
crystallized, each probe returning a sharper boundary. Pastiches do not survive that
protocol. Structures do.

---

## 2. The object and its measure

An **ignorance structure** is a relation `κ ⊆ ∏ᵢ Xᵢ` over a finite index of sorts, with a
distinguished partition into a shared interface `S` and private parts — the record of
*which* joint configurations are admissible, prior to and independent of any weighting.
Its **projections** `πᵢ(κ)` are what the interface exposes of each part; the
**rectangular hull** `⊗κ = ∏ᵢ πᵢ(κ)` is the maximal ignorance consistent with those
exposures; and

> `hcComb(κ) = |⊗κ| − |κ|`

grades the gap: the configurations the marginals license that the joint excludes — the
coupling that exists in the structure but is invisible through the shared vocabulary. We
call the phenomenon the **hidden channel**, and `hcComb` its combinatorial capacity.

Three adjectives fix the measure's character, and each negates a neighbouring tradition:

- **Constructive.** A finite cardinality: decidable, computable, kernel-verifiable. Not
  an ordinal preference scale (against subjective plausibility), not a real-valued
  functional requiring analysis (against entropy).
- **Domain-free.** No choice of valuation domain, no chosen ordering, no ℝ. The measure
  is determined by the relation alone.
- **Distribution-free.** Invariant across *every* probability measure supported on `κ`.
  It grades what the support forces, which no reweighting can undo.

The last property is the field's centre of gravity, and §4 gives it its geometry.

---

## 3. What is actually proven

The field is unusual for its age in that its core is not a manifesto but a verified
corpus. As of this note:

**The propositional stack [KV].** Six layers under `ZPM/Measurements/HC/`, zero `sorry`:
the abstract interpolation–amalgamation biconditional and the **oscillation theorem** —
notably proved from **no axioms at all** (not even choice); the combinatorial layer
(`hcComb_eq_zero_iff_isRect`, cross-recombination); the mutual-information leg through
genuine measure theory (uniform measure via `PMF.uniformOfFinset`, absolute continuity
and finite KL discharged, `fiveWay_uniform`); the fibered shared-interface model; the
full **six-entry equivalence** `fiveWay_full` (interpolation, decomposability,
amalgamation-as-such, fiber-rectangularity, fiber-CI, fiber-product surjectivity); and
the Spekkens instance, including an explicit oscillation trajectory. The oscillation
theorem is the dynamical heart: a trajectory of ignorance structures that ever exhibits a
cross-domain discovery cannot have been factorable at every step — the obstruction must
spike. Discovery has a conservation law, and `hcComb` is what it conserves against.

**The first-order lift [KV].** The type-space carrier: `CompleteType T α` topologized by
its clopen formula base and proved compact (Alexander subbase + the compactness theorem),
totally separated, Polish, Borel — the Stone-dual carrier on which the infinite theory
lives. Over it: the Set-based five-way (`fiveWay_fol`); **genuine type-reduct
amalgamation** at `St(S ⊕ A ⊕ B)` with real `L[[·]]`-sentence vocabularies, where the
reverse direction (non-amalgamable ⟹ no shared interpolant: the first-order hidden
channel) is unconditional and the forward direction is **Beth-conditional** — the
precise, honest locus where first-order logic exacts its price; the
measurability-obstruction leg (marginalization = analytic projection ⟹ null-measurable,
riding the Polish carrier); `support_prod` — the support of a product measure is the
product of supports — a general lemma absent from Mathlib; the one-way bridge
`mi_zero_imp_rectangular_support`; and the **separation witness** `Pcorr` (mass 3/8
diagonal, 1/8 off): rectangular support, non-product measure. Support-level and
distribution-level factorization are therefore *separated in general and unified exactly
at the canonical measure* — the measure-theoretic form of the CHSH boundary.

**Landed contact with hard problems [KV, partial].** The reverse direction of the
Ben-David–Hrubeš–Moran–Shpilka–Yehudayoff compression theorem (learnability
undecidability, Nature MI 2019) is closed in Kuratowski form — a compression scheme
forces the aleph bound; the forward direction is a documented axiom-of-choice seam. The
CHSH support/distribution boundary and the Spekkens oscillation witness are formalized.
These are not promissory notes; they are the field already touching undecidability of
learning and the quantum-classical boundary with checked proofs.

**The discrete local-to-global stack [KV].** The five-way's geometric leg (*the fiber
product surjects; a global section exists*) is a two-team statement. Its multi-team
generalization is the **gluing question on a cover**: given a hypergraph `𝒞` (a family of
teams over a shared index) and a pairwise-consistent family of local relations, one per
team, does a global configuration restricting to all of them exist? The classical answer
(Vorob'ev 1962; Beeri–Fagin–Maier–Yannakakis 1983) is that gluing is forced *exactly* when
the cover is **acyclic**. This stack now closes that iff in the kernel, in both directions,
with the hard direction made constructive:

- `glues_of_acyclic` — the positive half: a pairwise-consistent, duplicate-free family over
  an acyclic cover always glues (the order-free amalgamation theorem, run over a
  running-intersection order extracted from acyclicity).
- `acyclic_iff_grahamReducible` — acyclicity **is decidable**: it coincides with
  Graham/GYO ear-reduction, so the hypothesis of the positive half is machine-checkable
  (`decide`, never `native_decide`).
- The **affine obstruction engine** (`affine_obstruction`, `clean_system_obstruction`) — an
  `F₂`-linear constraint system with per-team constants and a hosted *odd* dependency yields
  a consistent family of nonempty local relations that provably does **not** glue: the
  explicit non-splitting cocycle.
- `exists_consistent_not_glues_of_not_acyclic` — the **converse**, unconditional: *every*
  non-acyclic cover hosts such a family. The proof reduces, via a chordal/conformal
  dichotomy (Atserias–Kolaitis) and a one-step GYO collapse, to a graph lemma — **Dirac's
  lemma** (`dirac_strong`: a chordless-cycle-free vertex set is a clique or holds two
  nonadjacent simplicial vertices), formalized here from first principles over a bespoke
  path grammar because Mathlib carries no chordality theory.
- `acyclic_iff_forall_consistent_glues` — the headline: **a cover is acyclic exactly when
  pairwise consistency forces gluing.** The Specker triangle (three 2-element teams closing
  a 3-cycle) is the minimal witness of the negative side, produced *unconditionally* by the
  engine — the smallest arity-3 amalgamation failure, kernel-checked.

All of the above are `[propext, Classical.choice, Quot.sound]`, zero `sorry`. This is the
**local-to-global obstruction of the field made constructive on the nerve** — the discrete
form of the flagship's H¹-side (§8), and the first place the multi-context object the
flagship needs is not conjectured but proved.

---

## 4. The correct lens: one fork, two geometries

In 1933 Kolmogorov founded uncertainty on measure: a σ-additive weighting, real-valued,
with the distribution as the primary object. Under that foundation the support is a
derived artifact — `{p > 0}` — and everything structural about co-possibility is read off
a weighting chosen first. This was a fork, though it was not visible as one: *weight
first, shape derived* — or *shape first, weight derived*. Probability theory took the
first tine and built the modern edifice on it. The second tine was never built. This
field is the second tine.

The precise statement is a fibration. Let `F : measures ↦ supports` send each probability
measure to its support. The **fibre** over a support `κ` is the space of all weightings
of that shape — and it is on the fibres that the entire measure-theoretic tradition
lives: Kolmogorov's axioms, Shannon's functionals, and, notably, the existing *geometry*
of uncertainty (Cuzzolin's simplicial geometry of belief functions — lines, projections,
angles in the space of measures: a *metric* geometry of the fibre). The **base** — the
space of shapes itself — had no geometry of its own. This field equips it with one, and
the geometry is of a different kind: topological and cohomological (Stone base, presheaf
obstruction), not metric. The base does not know distances; it knows whether local data
glues.

Three independent audits confirmed the base/fibre split as a fact about the literature
rather than a framing choice [PROBE]: Cuzzolin's program geometrizes the fibre
metrically; the separation witness proves `F` is not faithful (the fibre over a
rectangular support contains non-product measures — shape does not determine weight);
and information cohomology (§6) turns out to be, precisely, cohomology *of the fibre*.
The **canonical measure** — uniform on finite supports, conjecturally the
generically-stable Keisler measure under NIP on infinite ones **[CONJ]** — is a *section*
of `F`, and it is exactly along that section, and only there, that the two tines touch:
`hcComb(κ) = 0 ⟺ MI = 0` at the canonical measure **[KV]**.

Everything distinctive about the field follows from taking the untaken tine. Logic is
first-class because the base object is an order/relational object, and interpolation and
amalgamation are its decomposition *seen syntactically* — where the fibre tradition must
reconstruct structure from a weighting, the base tradition reads it directly. The measure
is an integer because base invariants count; they do not integrate. And
distribution-freeness is not a robustness afterthought but the definition of living on
the base.

---

## 5. The formal identity: graded cylindric set algebras

"Where does it sit in the mathematical universe" has a verified answer, and it is sharper
than an analogy. A relation closed under coordinate projections *is* a cylindric set
algebra in the sense of Henkin–Monk–Tarski: cylindrification is exactly existential
projection, and "rectangular element" is a named notion of that literature — Monk: *"a is
rectangular iff c(Γ)a · c(Δ)a = c(Γ∩Δ)a"* — the equational form of "a product of its
projections" [PROBE]. On that substrate the interpolation⟺superamalgamation
correspondence is a classical theorem of the variety (Maksimova; Madarász; Sayed Ahmed;
Németi) [PROBE]. Two things, and exactly two, are absent from seventy years of that
literature, checked adversarially: any **cardinality grading of non-rectangularity**
(rectangularity there is a Boolean predicate; the dimension set is index-valued; no
`|hull| − |κ|` exists), and any bridge to **conditional independence or the
fiber-product/global-section view** [PROBE].

The independent formal system is therefore pinned with unusual economy:

> **The variety of graded cylindric set algebras** — the Henkin–Monk–Tarski signature
> (Booleans, cylindrifications, diagonals), enriched with **one new primitive**, a
> monotone grading `h` into a constructive ordered monoid, and **one new law**, the
> coherence `h(a) = 0 ⟺ a rectangular ⟺ interpolation ⟺ amalgamation ⟺ CI ⟺
> fiber-product`.

One primitive, one law, on a seventy-year substrate that arrives with its own
representation theory. The inheritance is disciplined: the substrate and the logic pair
are *inherited* (and said so — interpolation⟺amalgamation is classical, not claimed);
the grading and the cross-domain coherence are *contributed*. The remaining genuinely
open design decision is the grading codomain — `ℕ` for the bipartite case, a commutative
monoid or semiring for multi-interface and higher arity, where the Atserias–Kolaitis
monoid-consistency parameter (below) suggests the codomain and the support↔distribution
knob may be the same dial **[CONJ]**.

---

## 6. Position in the populated world

The field's neighbourhood is dense, and the honest map of it is an asset, not a threat.
The two-pass ancestor audit (ten works, primary sources, strict "no summing of siblings"
rule) returned **no direct ancestor** [PROBE]. The instructive part is *how* each
near-neighbour falls short, because the pattern is the field's own silhouette:

- **Abramsky–Brandenburger sheaf contextuality** — the deepest sibling, and the field's
  own lineage for the cohomological reading. Shares the support-level
  obstruction-to-global-section. Its gradings are binary (strong contextuality),
  LP-fractional (contextual fraction — a distance between *distributions*), or
  cohomological classes; none is a cardinality defect, and the logic legs are absent.
- **Mayer's structural independence** (2024) — support-level and distribution-free, the
  right instincts; but *binary* (history-set disjointness), ungraded, with no
  information bridge and no logic legs.
- **Studený's imsets** — the most developed combinatorial-algebraic CI theory; its
  grading lives in the dual supermodular cone *over a distribution*. Combinatorial, but
  fibre-graded.
- **Cuzzolin's geometry of uncertainty** — a genuine geometry, of the *fibre*, and
  metric. The complement, not a competitor.
- **Information cohomology (Baudot–Bennequin; Vigneaux)** — the nearest cohomological
  program, and the decisive check. Its cocycles are entropy and Shannon MI *as functions
  of a law or a histogram*: cohomology of the fibre, again. The single most telling
  finding of the whole audit sequence sits here: Vigneaux's nondegenerate-product
  definition invokes the exact inclusion `ι : E_XY ↪ E_X × E_Y` — the very
  support-versus-hull comparison this field grades — **as a nondegeneracy hypothesis**,
  a condition assumed to hold so that the entropy cocycle is determined, and never
  grades the defect itself [PROBE]. The field's object is present in the neighbouring
  literature *as the thing assumed away*. There is no cleaner form of an empty niche
  than a hypothesis nobody thought to measure.

One deflation must be stated as plainly as the findings: **"uncertainty is
cohomological" is not the field's novelty.** That frame is a populated ambient
(information cohomology, contextuality cohomology, TDA, Gromov, Leinster). The novelty
is the *specific object* — support-level, distribution-free, constructively
cardinality-graded, with the logic faces co-equal by law — which is unoccupied in every
audited direction. The field claims the empty cell, not the room.

---

## 7. Why it is fundamental

Five arguments, in decreasing order of how much they would survive the flagship
conjecture failing.

**(1) The foundational fork.** The field is not a technique inside probability theory; it
is the other tine of probability theory's founding choice. Weight-first was taken in
1933 and built out for ninety years, including its own geometry (of the fibre).
Shape-first was available the entire time and was never built: every tradition that
approached it either binarized the shape (Mayer, Dawid, database consistency),
re-weighted it (Studený, contextual fraction, information cohomology), or cohomologized
it without counting (Abramsky). Building the untaken half of a foundational fork is a
foundation-level act regardless of how the deeper conjectures resolve.

**(2) Universality as corollary, not coincidence.** Local-to-global obstruction is
definable over any site; cohomology is its universal home. If uncertainty *is* such an
obstruction (the field's thesis), then its appearance in logic, statistics, physics,
complexity, causality, and learning is a derived fact rather than an eclectic
observation. The field's breadth is then evidence of its depth — precisely inverted from
the pastiche reading. The five-way equivalence is the finite, checkable germ of that
universality: five substrates, one vanishing condition, proved.

**(3) The empty cell, verified.** Fundamentality claims are cheap; this one was purchased
adversarially. Two-pass ancestor audit, four targeted follow-up probes, every one
licensed to kill, one kill accepted (Moonshine), the killer detail (Vigneaux's
hypothesis) found *inside* the nearest competitor's own definitions. The specific
object is new at the strictest standard we could operationalize.

**(4) The constructive bar.** Every prior calculus of non-probabilistic uncertainty paid
for generality with subjectivity — chosen scales, chosen orderings, elicited masses —
and was rejected by the constructivist tradition on exactly those grounds. This field's
measure is a decidable count with a kernel-checked theory: the first uncertainty
calculus a proof assistant can hold end to end. That is why the working discipline is
"route *through* plausibility, Dempster–Shafer, Cuzzolin — never home": the home is the
one place in the uncertainty landscape where the constructivist bar is met natively.

**(5) Landed contact.** Already proved against hard external targets: the undecidability
frontier of learning (EMX/Kuratowski, reverse direction closed), the quantum boundary
(CHSH separation, Spekkens oscillation), the complexity interface (the marginal problem
as the unifying open node with its NP-hard → QMA-complete ladder; the corridor from
Gács–Körner common information through nonnegative rank to extension complexity giving
`hcComb`'s rectangle a known complexity meaning). A foundation that touches
undecidability, quantum non-locality, and complexity lower bounds in its first year of
formalization is not a rearrangement of parts.

**And the honest hinge.** The full strength of "fundamental" — the geometric-roots
thesis itself — rides on one unproved theorem (§8). If that theorem fails, the field
does not evaporate: the five-way, the separation, the certificate machinery, the formal
system, and the landed contacts all stand. But the claim would demote from "the
geometric foundation of uncertainty" to "a unifying organizing principle with a
verified core." The distinction is stated here so that no reader of this note can
conflate the proven floor with the conjectured ceiling.

---

## 8. The flagship: the cohomological-roots theorem

**[CONJ]** Construct a cochain complex canonically attached to an ignorance structure
`κ` such that (i) the factorization obstruction is a class in its cohomology `H•`, with
`H• trivial ⟺ κ rectangular ⟺ the five-way`; and (ii) `hcComb(κ)` is its degree-zero
invariant — an Euler characteristic. Proving it would simultaneously: ground the measure
geometrically (the count becomes the shadow of the geometry), *derive* the universality
of §7(2), and identify the model-theoretic obstruction (amalgamation homology,
Goodrick–Kim–Kolesnikov lineage) with the physical one (contextuality cohomology) — the
Rosetta stone.

Two traps, named so they cannot be walked into silently. **The degree-zero trap:** there
is a trivial reading — `hcComb = dim coker(ℤ^κ ↪ ℤ^{⊗κ})` — which is a twenty-line Lean
exercise and proves nothing: the Euler characteristic of a discrete set is its size, and
a two-term inclusion complex has no higher cohomology to cast a shadow. Formalizing it
and calling the flagship done would be the exact dressing-up this programme's honesty
axioms exist to catch. It is admissible only as explicitly-labeled scaffolding. **The
context trap:** `hcComb` is a *single-context* invariant (one joint measurement), while
sheaf contextuality is essentially *multi-context* (CHSH needs four overlapping
contexts). The flagship's cohomology is therefore not literally Abramsky's `Ȟ¹`; the
candidate construction is a Čech complex of the row/column cover of the hull, whose
`H¹`-type failures are exactly the fiber-product-surjectivity failures. Constructing
that complex and verifying `χ = hcComb`, `H¹ = 0 ⟺ rectangular` on the existing finite
witnesses (Spekkens, `Pcorr`) is *paper mathematics first*, Lean second — the honest
sequencing for gated imagination.

**What v0.2 lands, and what it does not.** The context trap is now half-crossed. The
discrete gluing stack (§3) builds exactly the multi-context object the flagship needs (a
cover with arbitrarily many overlapping teams, its nerve, and the sheaf of local sections)
and proves, **in the kernel**, the qualitative core of the intended H¹ statement:
*a global section exists for every consistent local family* ⟺ *the nerve is acyclic*
(`acyclic_iff_forall_consistent_glues`), with the obstruction, when acyclicity fails, an
explicit non-splitting `F₂` cocycle rather than a mere existence claim. In cohomological
terms this is the set-valued/non-abelian `H¹ = 0 ⟺ acyclic nerve` face, made constructive
and multi-context — precisely the "row/column cover" Čech picture, generalized off the
bipartite hull to any cover. Two things remain **[CONJ]**, and the honest scope of the
flagship is now exactly their difference:

- **The counting identity `χ = hcComb`.** The gluing stack characterizes *when* the
  obstruction vanishes; it does not yet equate the graded defect `hcComb(κ)` with an Euler
  characteristic of the complex. Tying the acyclicity of the nerve back to the cardinality
  grading `|⊗κ| − |κ|` — turning the qualitative `H¹ = 0` into the quantitative degree-zero
  shadow — is the remaining arithmetic-to-geometry bridge, and it is what would move the
  governing thesis from **[STANCE]** to **[KV]**.
- **The abelian complex.** The kernel result is non-abelian (set-valued gluing); the
  degree-zero-trap warning still applies to any abelian two-term reading. The genuine
  cochain complex whose higher cohomology *casts the shadow* is still to be constructed
  paper-first.

So the flagship demotes cleanly into a proven leg and a named gap: the local-to-global
*obstruction* is now KV on the discrete nerve; its identification as *an Euler
characteristic of a cohomology* is the one conjecture that carries the geometric-roots
claim. No wording in this note attaches "cohomology" to the proven part.

**The counting identity: first structural evidence (2026-07-07, [NUM] throughout this
paragraph).** A pre-registered candidate battery (each law probed and then adversarially
re-implemented; ledger in `FLAGSHIP_COHOMOLOGY_URS.md`) moved the gap decisively:

- **The abelian complex exists on the affine subclass.** For pairwise-consistent
  F₂-affine local systems on any cover, the Čech complex of the **direction presheaf** on
  the nerve (coefficients: the projected linear parts of the local solution spaces, which
  pairwise consistency makes well-defined; differentials: coordinate projections) has all
  four target properties, verified on ~800 instances by two independent implementations:
  gluing holds iff the mismatch class vanishes in H¹; forest nerves have H¹ = 0; the PR
  box is the nonzero class in a 1-dimensional H¹ while the even twist on the same cover
  is a coboundary; and on acyclic covers the exact zero-correction identity
  log₂|join| = Σ_teams dim V_T − Σ_tree-edges dim V_sep holds for every join tree, with
  log₂|join| = dim H⁰ universally whenever the glue exists. All three trap tests pass.
  Proof sketches exist for all four laws; this is the named formalization target.
- **The counting identity is entropy-valued, not cardinality-valued.** The naive
  cardinality telescope |join| = ∏ teams / ∏ separators is FALSE, in both directions,
  already on the two-team path cover (exhaustively checked). The identity that is exact
  (machine precision, join-tree invariant, every acyclic instance tested) is the
  junction-tree factorization of the uniform distribution on the join:
  **log₂|join| = Σ_nodes H(U_T) − Σ_edges H(U_S)**. The cardinality version is its
  max-entropy degradation, and the degradation is exactly what breaks exactness. The
  affine case above is the specialization H = dim. This answers the §5 codomain question
  in direction: the grading codomain of the cohomological reading is entropy, restricting
  to dimension on the affine locus, and the support-versus-distribution separation (the
  Pcorr lesson of §3) reappears at the counting level.
- **A no-go pins the trap from outside.** hcComb(κ ⊔ κ') = hc + hc' + |A||B'| + |A'||B|
  (exact, and immediate algebraically), so no χ-additive functor computes hcComb: any
  candidate must couple the parts through the hull's cross-blocks. The minimal complex
  realizing this (the evaluation complex ℚ^{πL} ⊗ ℚ^{πR} → ℚ^κ, with χ = hcComb and
  acyclicity iff rectangularity) has its cohomology concentrated in degree zero equal to
  the defect space: it is the formal boundary of the degree-zero trap, named as
  scaffolding. Separately, the Dowker complex is dead as a carrier: hcComb is not even a
  face-set invariant of the Dowker pair (explicit collision witnesses).

The honest state after the battery: the flagship's abelian complex is specified and
[NUM]-verified on the affine subclass with formalization-ready proof sketches; the general
counting identity is an entropy identity whose cardinality shadow (`hcComb` at two teams)
is exact precisely where max-entropy degradation is lossless. What remains [CONJ] is the
general-κ complex whose entropic Euler characteristic realizes the junction-tree identity
cochain-level, where the no-go now says any such complex must be hull-coupled and cannot be
cardinality-χ-additive.

The multipartite direction is not decoration here: bipartite structures always
2-amalgamate, and it is at arity ≥ 3 that amalgamation genuinely fails — exactly where
the higher obstruction should first be non-zero. The Specker triangle is that failure at
its minimum, and it is now a kernel witness (§3). The flagship and the multipartite
generalization are one project seen at two depths.

---

## 9. The epistemic lens

The field did not begin as mathematics; it began as an ignorance question — *when is a
causal learner finished?* — and the mathematics is what that question precipitated under
formalization. The lens that found it (URT: ignorance as a structured, generative field,
never the complement of knowledge) reads the objects as follows. The relation `κ` is
structured ignorance itself: the co-possibility datum. The hull is the maximal ignorance
the interface admits; `hcComb` counts the regularity present in the joint but
unarticulable through the shared vocabulary — in the lens's terms, the unarticulated
(UK) content trapped behind an interface, the exact pressure that forces grammar
expansion. The five-way says: no hidden channel ⟺ nothing unaskable across the
interface. The oscillation theorem is the lens's signature made theorem: genuine
cross-domain discovery *requires* the obstruction to have been positive — ignorance is
generative, and `hcComb` is the gauge of its generative pressure. The
support↔distribution separation is the boundary between admissibility structure and
resolved weight (the Pl→Coh boundary; the CHSH lesson generalized).

Discipline: the lens predicted where to dig and is recorded as the field's origin. The
mathematics stands without it; the lens is not an axiom of the system, and the system is
not evidence "for" the lens in any circular sense. Each illuminates the other; neither
leans.

---

## 10. The program

**Just landed (v0.2).** The discrete local-to-global stack (§3): the Vorob'ev gluing
iff on covers, both directions, converse constructive, discharged to Dirac's lemma; the
affine obstruction engine; the Graham/GYO decidability bridge. This was the "multipartite
theory / where the homology turns on" line of the v0.1 mid-term, brought forward and
closed on the qualitative (set-valued `H¹`) side. What it exposes as the true next step is
sharper than before: not *whether* the multi-context obstruction exists (proved), but its
**quantitative** identification with `hcComb`.

**Immediate (days).** The **structural-CI certificate**: contraposing the proven bridge,
a non-rectangular fiber certifies `A ⊥̸ B | S` for *every* distribution supported there
— a distribution-free, faithfulness-immune conditional-dependence certificate, graded by
`hcComb`, one short lift above already-landed lemmas. The fastest genuine application:
the primitive causal-discovery step that no reweighting can fool, kernel-checked. In
parallel: formalize the graded-cylindric signature and coherence law, fixing the formal
system in Lean.

**Mid.** Formalize the affine flagship: the direction-presheaf Čech complex over
AffineEngine, in the order fixed by the URS (complex + d∘d = 0; glue ⟺ coboundary; forest
vanishing; the PR-box class; the dimension identity), the substrate mapped by the Mathlib
floor scan (finrank + rank-nullity as the spec layer; simplicial homology and
Euler–Poincaré are absent from Mathlib at this pin and must be built). Then the general-κ
entropic complex ([CONJ]: realize the junction-tree entropy identity cochain-level,
respecting the no-go). The canonical section (Keisler/NIP) closing the
support↔distribution circle; the codomain question now has a direction (entropy,
restricting to dimension on the affine locus) with the Atserias–Kolaitis monoid knob as
its remaining calibration; the corridor (common information → nonnegative rank →
extension complexity) giving `hcComb` a complexity-theoretic exchange rate.

**Far.** The second-order phase transition: in full SOL, compactness, completeness, and
Craig/Beth all fail — the carrier collapses and the oscillation theorem becomes
*Beth-dependent*, making oscillation a discriminator on the Lindström hierarchy; the
honest question is which controlled fragment buys articulation without losing the
discovery-closure. The descriptive-complexity white space (the interpolation leg that
cohomological k-consistency lacks). The marginal-problem ladder as the complexity home
("the cost of the hidden channel": NP-hard classically, QMA-complete quantumly). And
one parked bet: Moonshine — direct fit tested and rejected; retained as a far-future,
first-principles question (whether its obstruction and ours are instances of one
categorical obstruction theory), gated on the flagship existing first.

**Standing non-claims.** No leverage on P vs NP (the feasible-interpolation route is a
name collision, crypto-barriered; our own `PvNPInFrame` formalizes the collapse of the
naive reframing — the field proves its *own* limits, which is worth more than the claim
would have been). Quantum reach is to quantum advantage, not to classical separations.
Subjective uncertainty calculi are corridors, never foundations.

---

## 11. Naming

A collision must be flagged: "geometric measure theory" is Federer's field
(rectifiability, currents, Hausdorff measure) and cannot be the name.

**Direction confirmed by the founder (2026-07-02): the field's identity is the
shape-of-ignorance family** — "the shape of ignorance" / "the geometry of ignorance" —
this was the dream field the programme was always aimed at, and the name is now settled
in direction; only the exact lexical form remains open. "Structural mutual information"
and "structured-ignorance factorization" are retired as headlines — accurate about legs,
unfaithful to the frame — though both survive as names of faces; "hidden channel" remains
the obstruction's name. The name says what the Kolmogorov contrast says: probability
weighs; this measures shape.

**The tagline is a working tagline by design.** Current form (v0.1): *probability theory
is the calculus of how much we do not know; this is the calculus of the shape of what we
do not know.* Sharpening rule: tagline revisions are **earned by ledger transitions**
(a CONJ moving to KV licenses a sharper claim — e.g. when the flagship lands,
"conjecturally a cohomology" becomes "a cohomology"), never by wordsmithing alone. The
tagline matures at exactly the rate the field does.

---

## 12. Ledger

| Claim | Status | Witness |
|---|---|---|
| Five/six-way equivalence, propositional | **KV** | `fiveWay_full`, 0 sorry, std axioms |
| Interpolation–amalgamation core + oscillation | **KV** (axiom-free) | `Abstract.lean` |
| MI leg via genuine measure theory | **KV** | `fiveWay_uniform` |
| FOL carrier: compact Polish Borel type space | **KV** | `FOL/{Topology,Compact,Polish}` |
| Genuine type amalgamation; reverse unconditional, forward Beth-conditional | **KV** | `FOL/Amalgamation.lean` |
| Support↔distribution separation; unification at canonical measure | **KV** | `Pcorr`; `fiveWay_uniform` |
| `support_prod` (new to Mathlib) | **KV** | `FOL/LegIVBridge.lean` |
| EMX compression ⟹ aleph bound (reverse) | **KV** | `EMX.lean` (forward = AC seam, open) |
| Discrete Vorob'ev converse: acyclic cover ⟺ pairwise-consistency forces gluing | **KV** | `acyclic_iff_forall_consistent_glues`, `Dirac.lean`, 0 sorry, std axioms |
| Constructive non-gluing witness on any cyclic cover (affine `F₂` engine) | **KV** | `exists_consistent_not_glues_of_not_acyclic`, `clean_system_obstruction` |
| Acyclicity decidable = Graham/GYO reducibility; order-free amalgamation | **KV** | `acyclic_iff_grahamReducible`, `glues_of_acyclic` |
| Dirac's lemma (chordless-cycle-free ⟹ clique or two nonadjacent simplicials) | **KV** | `dirac_strong`, first-principles path grammar |
| Minimal arity-3 gluing failure (Specker triangle), produced unconditionally | **KV** | `specker_hosts_nonglue` via the capstone |
| Discrete `H¹`-side of the flagship (set-valued gluing ⟺ acyclic nerve) | **KV** (qualitative); `χ = hcComb` still **CONJ** | §3, §8 |
| CHSH scenario forces contextuality from its cover's shape alone | **KV** | `chshCover_not_acyclic`, `chsh_hosts_nonglue` |
| Possibilistic PR box: consistent, locally nonempty, no global section, no glue | **KV** | `prBox_no_global_section`, `prBox_not_glues` |
| No contextuality without the cycle (acyclic Bell path glues everything) | **KV** | `bellPath_no_contextuality` |
| Affine flagship complex (direction-presheaf Čech: H¹ = gluing obstruction, PR box = the class, exact dim identity on acyclic covers) | **NUM** (two independent implementations, ~800 instances; proof sketches ready) | §8; `FLAGSHIP_COHOMOLOGY_URS.md` |
| Entropy junction-tree identity log₂\|join\| = ΣH(nodes) − ΣH(edges) | **NUM** (exact, join-tree invariant) | §8 |
| Cardinality join-tree telescope ∏teams/∏separators | **REFUTED** (both directions, exhaustive on the 2-team path) | §8 |
| Dowker complex as flagship carrier; any Euler formula from the Dowker pair | **REFUTED** (collision witnesses: not a face-set invariant) | §8 |
| hcComb non-additivity no-go: hc(κ⊔κ') = hc + hc' + \|A\|\|B'\| + \|A'\|\|B\| | **NUM** (also immediate algebraically) | §8 |
| No direct ancestor; unique logic↔information bridge | **PROBE** | two-pass audit, 10 works |
| Cylindric substrate literal; grading absent there; CI/fiber legs absent there | **PROBE** | Monk; Sayed Ahmed corpus |
| Information cohomology is fibre-level; the defect appears there only as an ungraded hypothesis | **PROBE** | Vigneaux 1709.07807, 2003.02021 |
| Contextuality reaches quantum advantage, not P vs NP; feasible-interpolation route barriered | **PROBE** | Krajíček–Pudlák; BPR; Schmid et al. |
| Moonshine direct fit | **REJECTED** (parked, first-principles, gated) | four-channel probe |
| Cohomological-roots theorem (`hcComb` = Euler characteristic of a real `H•`) | **CONJ** (the flagship); `H¹`-side now KV on the discrete nerve, `χ = hcComb` identity open | §8 |
| Canonical section on infinite carriers (Keisler/NIP) | **CONJ** | open |
| "Uncertainty is geometric" | **STANCE** | established iff flagship lands |

---

*The field in one sentence: probability theory is the calculus of how much we do not
know; this is the calculus of the shape of what we do not know. The shape, unlike the
weight, has a logic, an algebra, and a local-to-global obstruction now proven on the
discrete nerve, its reading as the Euler characteristic of a cohomology the one conjecture
that remains, all under one verified roof.*
