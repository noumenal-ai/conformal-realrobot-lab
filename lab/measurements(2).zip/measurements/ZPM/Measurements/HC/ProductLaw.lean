/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Multipartite
import Mathlib.Logic.Equiv.Prod
import Mathlib.Tactic.Zify
import Mathlib.Tactic.Ring

/-!
# Juxtaposition and the derivation law

The disjoint-interface product of ignorance structures, and how the base grading behaves under
it: for `κ₁` over `ι₁` and `κ₂` over `ι₂`, `sumRel κ₁ κ₂` is the relation over `ι₁ ⊕ ι₂` whose
configurations restrict to a `κ₁`- and a `κ₂`-configuration. Under this operation:

* the size is multiplicative (`card_sumRel`),
* the hull is multiplicative on nonempty structures (`hullPi_sumRel`),
* and the defect obeys the **Leibniz rule** (`hcCombPi_sumRel`):
  `hcCombPi (κ₁ ⊗ κ₂) = hcCombPi κ₁ · |hull κ₂| + |κ₁| · hcCombPi κ₂`.

The defect is a derivation, not a homomorphism: the kernel-swept refutations of the
multiplicative and additive candidate laws are recorded in `PRODUCT_LAW_URS.md`. The homomorphic
invariant under juxtaposition is the pair (hull size, size) in `(ℕ × ℕ, ×)`; the defect is its
difference-derivation, and the additive form of the grading is `log(|hull|/|κ|)` — exactly the
counting bound of the approximate five-way's upper leg. Nonemptiness in the hull and Leibniz
laws is sharp at the empty-index corner (the hull of the empty structure over no parts is the
unit configuration, not empty), the third independent appearance of that boundary.
-/

namespace HiddenChannelCapacity

open Finset

universe u

variable {ι₁ ι₂ : Type*} {X₁ : ι₁ → Type u} {X₂ : ι₂ → Type u}

/-- Deciding equality on a summed family, componentwise. -/
instance instDecidableEqSumElim [∀ i, DecidableEq (X₁ i)] [∀ i, DecidableEq (X₂ i)] :
    ∀ i : ι₁ ⊕ ι₂, DecidableEq (Sum.elim X₁ X₂ i) := fun i =>
  Sum.rec (fun a => inferInstanceAs (DecidableEq (X₁ a)))
    (fun b => inferInstanceAs (DecidableEq (X₂ b))) i

/-- Finiteness of a summed family, componentwise. -/
instance instFintypeSumElim [∀ i, Fintype (X₁ i)] [∀ i, Fintype (X₂ i)] :
    ∀ i : ι₁ ⊕ ι₂, Fintype (Sum.elim X₁ X₂ i) := fun i =>
  Sum.rec (fun a => inferInstanceAs (Fintype (X₁ a)))
    (fun b => inferInstanceAs (Fintype (X₂ b))) i

variable [Fintype ι₁] [Fintype ι₂] [DecidableEq ι₁] [DecidableEq ι₂]
  [∀ i, DecidableEq (X₁ i)] [∀ i, DecidableEq (X₂ i)]

/-- **Juxtaposition** (the disjoint-interface product): the relation over `ι₁ ⊕ ι₂` whose
configurations restrict to a `κ₁`- and a `κ₂`-configuration. -/
def sumRel (κ₁ : Finset (∀ i, X₁ i)) (κ₂ : Finset (∀ i, X₂ i)) :
    Finset (∀ i : ι₁ ⊕ ι₂, Sum.elim X₁ X₂ i) :=
  (κ₁ ×ˢ κ₂).image (Equiv.prodPiEquivSumPi X₁ X₂)

omit [DecidableEq ι₁] [DecidableEq ι₂] in
/-- Membership in a juxtaposition is componentwise membership. -/
lemma mem_sumRel {κ₁ : Finset (∀ i, X₁ i)} {κ₂ : Finset (∀ i, X₂ i)}
    {f : ∀ i : ι₁ ⊕ ι₂, Sum.elim X₁ X₂ i} :
    f ∈ sumRel κ₁ κ₂
      ↔ (fun i => f (Sum.inl i)) ∈ κ₁ ∧ (fun i => f (Sum.inr i)) ∈ κ₂ := by
  rw [sumRel, Finset.mem_image]
  constructor
  · rintro ⟨p, hp, rfl⟩
    exact Finset.mem_product.mp hp
  · rintro ⟨h1, h2⟩
    refine ⟨(fun i => f (Sum.inl i), fun i => f (Sum.inr i)),
      Finset.mem_product.mpr ⟨h1, h2⟩, ?_⟩
    funext i
    rcases i with i | i <;> rfl

omit [DecidableEq ι₁] [DecidableEq ι₂] in
/-- **Multiplicativity of size** under juxtaposition. -/
theorem card_sumRel (κ₁ : Finset (∀ i, X₁ i)) (κ₂ : Finset (∀ i, X₂ i)) :
    (sumRel κ₁ κ₂).card = κ₁.card * κ₂.card := by
  rw [sumRel, Finset.card_image_of_injective _ (Equiv.injective _), Finset.card_product]

omit [DecidableEq ι₁] [DecidableEq ι₂] in
/-- The left projections of a juxtaposition are the left factor's projections (nonempty
partner). -/
lemma projPi_sumRel_inl {κ₁ : Finset (∀ i, X₁ i)} {κ₂ : Finset (∀ i, X₂ i)}
    (hκ₂ : κ₂.Nonempty) (i : ι₁) :
    projPi (sumRel κ₁ κ₂) (Sum.inl i) = projPi κ₁ i := by
  ext a
  rw [projPi, projPi]
  constructor
  · intro ha
    obtain ⟨f, hf, rfl⟩ := Finset.mem_image.mp ha
    exact Finset.mem_image.mpr ⟨_, (mem_sumRel.mp hf).1, rfl⟩
  · intro ha
    obtain ⟨g, hg, rfl⟩ := Finset.mem_image.mp ha
    obtain ⟨g₂, hg₂⟩ := hκ₂
    exact Finset.mem_image.mpr
      ⟨Equiv.prodPiEquivSumPi X₁ X₂ (g, g₂), mem_sumRel.mpr ⟨hg, hg₂⟩, rfl⟩

omit [DecidableEq ι₁] [DecidableEq ι₂] in
/-- The right projections of a juxtaposition are the right factor's projections (nonempty
partner). -/
lemma projPi_sumRel_inr {κ₁ : Finset (∀ i, X₁ i)} {κ₂ : Finset (∀ i, X₂ i)}
    (hκ₁ : κ₁.Nonempty) (i : ι₂) :
    projPi (sumRel κ₁ κ₂) (Sum.inr i) = projPi κ₂ i := by
  ext a
  rw [projPi, projPi]
  constructor
  · intro ha
    obtain ⟨f, hf, rfl⟩ := Finset.mem_image.mp ha
    exact Finset.mem_image.mpr ⟨_, (mem_sumRel.mp hf).2, rfl⟩
  · intro ha
    obtain ⟨g, hg, rfl⟩ := Finset.mem_image.mp ha
    obtain ⟨g₁, hg₁⟩ := hκ₁
    exact Finset.mem_image.mpr
      ⟨Equiv.prodPiEquivSumPi X₁ X₂ (g₁, g), mem_sumRel.mpr ⟨hg₁, hg⟩, rfl⟩

/-- **Multiplicativity of the hull** under juxtaposition, on nonempty structures. Sharp at the
empty-index corner: the hull of the empty structure over no parts is the unit configuration. -/
theorem hullPi_sumRel {κ₁ : Finset (∀ i, X₁ i)} {κ₂ : Finset (∀ i, X₂ i)}
    (hκ₁ : κ₁.Nonempty) (hκ₂ : κ₂.Nonempty) :
    hullPi (sumRel κ₁ κ₂) = sumRel (hullPi κ₁) (hullPi κ₂) := by
  ext f
  simp only [hullPi, Fintype.mem_piFinset, mem_sumRel]
  constructor
  · intro h
    refine ⟨Fintype.mem_piFinset.mpr fun i => ?_, Fintype.mem_piFinset.mpr fun i => ?_⟩
    · have := h (Sum.inl i)
      rwa [projPi_sumRel_inl hκ₂] at this
    · have := h (Sum.inr i)
      rwa [projPi_sumRel_inr hκ₁] at this
  · rintro ⟨h1, h2⟩ i
    rcases i with i | i
    · rw [projPi_sumRel_inl hκ₂]
      exact Fintype.mem_piFinset.mp h1 i
    · rw [projPi_sumRel_inr hκ₁]
      exact Fintype.mem_piFinset.mp h2 i

/-- **The Leibniz rule for the defect**: under juxtaposition the hidden-channel defect is a
derivation over the multiplicative pair (hull size, size),

`hcCombPi (κ₁ ⊗ κ₂) = hcCombPi κ₁ · |hull κ₂| + |κ₁| · hcCombPi κ₂`.

The defect is not a homomorphism (the multiplicative and additive candidate laws are refuted by
kernel sweep); the homomorphic invariant is the bi-grading, and the defect is its
difference-derivation. -/
theorem hcCombPi_sumRel {κ₁ : Finset (∀ i, X₁ i)} {κ₂ : Finset (∀ i, X₂ i)}
    (hκ₁ : κ₁.Nonempty) (hκ₂ : κ₂.Nonempty) :
    hcCombPi (sumRel κ₁ κ₂)
      = hcCombPi κ₁ * (hullPi κ₂).card + κ₁.card * hcCombPi κ₂ := by
  have h1 : κ₁.card ≤ (hullPi κ₁).card := Finset.card_le_card (subset_hullPi κ₁)
  have h2 : κ₂.card ≤ (hullPi κ₂).card := Finset.card_le_card (subset_hullPi κ₂)
  rw [hcCombPi, hullPi_sumRel hκ₁ hκ₂, card_sumRel, card_sumRel, hcCombPi, hcCombPi]
  zify [h1, h2, Nat.mul_le_mul h1 h2]
  ring

end HiddenChannelCapacity
