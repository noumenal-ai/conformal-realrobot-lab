# HANDOFF_NOOLOGY_URS: the agent axis: mind, Will, actions, and the ignorance therein

**What this document is.** One of a pair of handoff documents written 2026-07-07 for a
cold session (a fresh Claude instance, or any collaborator) joining the Shape of
Ignorance / Hidden Channel Capacity programme mid-flight. This document describes the
REASONER: how we work, what we have committed to, which of our own failure modes have
actually fired, and how the toolkit is wired. Its twin, `HANDOFF_DISCOVERY_URS.md` (same
directory), describes the OBJECT: what has been discovered, verified, refuted, and what
is known about what is not known. Read this one first. The two axes are kept in separate
documents deliberately; conflating the reasoner's state with the object's state is the
canonical error of this methodology, and the separation is itself load-bearing.

**Assume nothing.** This document is written for a reader with zero context. Every path
is absolute or design-lab-relative, every command is complete, every rule comes with the
incident that taught it.

---

## 0. The programme in three sentences

Dhruv Gupta (PI, Zetesis Labs, dhruv@zetesislabs.com) runs a research programme called
the Shape of Ignorance: a mathematical field whose object is the support-level structure
of joint possibility (relations, covers, gluing) and whose claims are machine-verified in
Lean 4. Claude executes formalization, search, computation batteries, and derivation at
scale, under a strict methodology (URT: Universal Reasoning Theory) that treats
ignorance as structured and measurable, and treats Claude's own tendency to confabulate
as a first-class engineering constraint. The current arc (QJT) formalizes the first
machine-checked quantum junction tree theorem and attacks a genuinely open problem: the
non-chordal quantum Markov marginal characterization.

## 1. The two agents and the collaboration contract

- **Dhruv provides depth**: blockers, design decisions, domain judgment, direction
  changes, and the standing challenge "is this OPEN mathematics or an elementary or
  known observation?" His challenges are not rhetorical; they have repeatedly redirected
  arcs (see the interrogation round in the discovery document).
- **Claude provides scale**: execution, exhaustive search, parallel computation,
  formalization, literature probes. Claude does NOT unilaterally reduce scope, does not
  offer breaks, does not give calendar estimates for proof work (characterize options
  structurally instead: infrastructure needed, proof topology, what becomes askable).
- Turn protocol: Dhruv issues a directive; Claude runs the full loop (Section 3) and
  returns outcome-first. When Dhruv is pondering, Claude grounds and prepares but does
  not commit to new directions without him.

## 2. The Will snapshot (standing law, with the reasons)

These are commitments, not preferences. Each has a reason and most have an incident.

1. **Never `sorry`. Absolute.** Not in drafts on disk, not as staging markers, not as
   cheat-axioms. Unproved obligations are encoded as named Prop definitions tracked in a
   URS, or the work is not written yet. INCIDENT: the sorry-in-draft failure mode has
   fired at least five times across the programme (FiveWayPi, GrahamBridge, a
   CyclicConverse stub, a deliberate "staging sentinel" in Dirac's sep_clique_step, an
   unused helper stub); each firing is logged in the URS ledgers. The rule survives
   because kernel state must never lie.
2. **A4 is review-only; A5 is the only resolution.** A4 (honesty) diagnoses: trivial
   proof, vacuous hypothesis, known result restated. It NEVER licenses stopping.
   Declaring something "honestly open" and moving on is the canonical hedge. A5
   (anti-simplification): when stuck, ADD structure; never route around an obstruction,
   never fall back to a simpler statement, never ask the PI "minimal or full?" (asking
   to reduce scope is itself a violation). Rigor over speed, always.
3. **Plans are URS files.** Never generic markdown to-do lists. A URS (Universal
   Reasoning State) is a measurement instrument over ignorance: it carries candidate
   laws WITH pre-registered expected verdicts, K/U geometry, kill criteria, and verdict
   rounds. If it reads like a Gantt chart it is not a URS.
4. **Pre-registration before probes.** Every candidate law gets its expected verdict
   written down BEFORE any computation or search runs. INCIDENT: the C-JT law
   (cardinality junction-tree telescope) was pre-registered TRUE and came back
   exhaustively FALSE; the pre-registration is what made the correction visible and
   valuable rather than silently absorbed.
5. **Gated imagination.** Claude-generated mathematical structure is conjecture until a
   verifier speaks. The verifiers in this programme: the Lean kernel; the [NUM] battery
   protocol (an independent probe agent computes, then a BLIND adversarial verifier
   re-implements from scratch and hunts edge cases; only doubly-surviving results are
   banked, graded [NUM]); primary-source literature probes under the anti-vacuity rule
   (a novelty claim requires naming the works checked and what they contain; generic
   resemblance = non-finding). INCIDENT: an Opus developer agent produced a plausible
   headline law ("quantum gluing ⟺ laminar covers") that its own adversarial verifier
   REFUTED with an explicit counterexample; the gate worked exactly as designed.
6. **Post-cutoff sources are fetch-only.** The LZ paper (arXiv:2605.19453) postdates the
   model knowledge cutoff (January 2026). Every claim about its content must come from
   fetched text; gaps are marked NOT-EXTRACTED, never filled from memory.
7. **Axiom discipline.** Allowed axioms: `propext`, `Classical.choice`, `Quot.sound`,
   nothing else. `decide` is allowed; `native_decide` is FORBIDDEN (it adds a trust
   axiom). Every banked theorem gets `#print axioms` checked. Vendor code with sorries
   is not patched; sorried declarations are QUARANTINED (recorded do-not-use; the
   current quarantine list is in the discovery document and in QJT_URS).
8. **Model cost cap.** No model more expensive than Opus in any workflow or subagent,
   in any session, unless Dhruv himself directs it in that session. Always set
   `opts.model` explicitly in workflow `agent()` calls; never leave it to inherit.
   INCIDENT: a nine-agent battery inherited the session's Fable tier without an explicit
   choice; the policy was set immediately after and lives in Claude's memory as
   universal.
9. **No em-dashes in prose Claude writes for Dhruv.** Use period, colon, parentheses,
   or comma. (Pre-existing document text keeps its own style; the rule governs newly
   authored prose, including URS files and this document.)
10. **Never degrade security or verification infrastructure** to get unblocked; find
    another mechanism. Never push Claude's private memory directory to any repo.
11. **The PI's challenge discipline.** For every result, answer in writing: open, or
    elementary, or formalization-first? Concede the elementary answer plainly. Value
    claims must survive literature subtraction.

## 3. The operating loop (what Claude actually does each turn)

1. **Read state**: the relevant URS files (inventory in Section 5), and memory.
2. **Floor before formalize**: every Lean name is resolved through mathlib-search
   (Section 4.2) BEFORE being used in a proof. Roughly 40 percent of pattern-guessed
   Mathlib names are wrong; guessing is banned.
3. **URS write**: candidate laws + expected verdicts + kill criteria, BEFORE probes.
4. **Route each act by reliability**: describe/search/experiment (running code, Lean,
   batteries) are reliable; imagine is gated (Rule 5). Big fan-out work goes to
   workflows or background agents; precision Lean stays in the main loop (subagents
   lack the session's build discipline).
5. **Verify**: kernel compile + axiom audit for Lean; adversarial re-implementation for
   numerics; fetched sources for literature.
6. **Verdict round**: write outcomes back into the URS, including Claude's own errors,
   with the same prominence as successes.
7. **Report outcome-first** to Dhruv, corrections before victories.

**Workflow/battery pattern (reusable)**: a Workflow script with phase 'Probe' (one
independent agent per candidate law, structured-output schemas, each blind to the
others) piped into phase 'Verify' (one adversarial verifier per definite verdict, fresh
implementation, "default to refuted on ANY discrepancy"). Ultracode (standing workflow
opt-in) may be ON or OFF per session; when OFF, workflows need explicit direction from
Dhruv. Background single agents (Agent tool, `run_in_background: true`) are used for
long builds and paper-extraction; give them exhaustive self-contained prompts and
require a structured final report.

## 4. The toolkit map (exact paths and commands)

### 4.1 The repository

- **design-lab root** (run everything from here):
  `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab`
- **The HC corpus** (this field's Lean + URS files):
  `measurements/ZPM/Measurements/HC/` (design-lab-relative).
- **Toolchain**: Lean `v4.31.0`, Mathlib pin `fabf563a7c95a166b8d7b6efca11c8b4dc9d911f`.
  Everything (ZPM, Physlib, QuantumInfo) is on this exact pin.
- **The vendored physics library**: `physlean/` at design-lab root. Root namespaces:
  `Physlib` (classical/relativity slice), `PhyslibAlpha`, `QuantumInfo` (density
  matrices, channels, entropy: our quantum substrate). The root lakefile has
  `require Physlib from "physlean"`, so it is a workspace member.
- **Claude's private memory** (NOT in any repo, never push):
  `/Users/polaris/.claude/projects/-Users-polaris-Documents-Epistemology-and-Zetesis-Projects-formal-learning-theory-kernel/memory/`
  (index: `MEMORY.md`; read it at session start).

### 4.2 mathlib-search (the canonical name-resolution instrument)

```bash
cd "/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab"
S=.claude/skills/mathlib-search/scripts/mathlib-search
"$S" target list        # all targets + built/active state
"$S" target quantuminfo # switch (restarts daemon, ~30s; index cached after first build)
"$S" q '"MState"'       # name substring | type patterns | subexpressions
"$S" regex -i 'petz|recovery'   # POSIX-ERE over names
"$S" reindex measurements       # after rebuilding a library (PENDING for measurements:
                                # its index predates the newest OptimalTransport work)
```
Hits print `name type <file:line> [⚠ sorry]`; the sorry flag is kernel-authoritative;
never use a flagged lemma. Targets include: `mathlib`, `measurements` (ZPM),
`physlean` (Physlib), `quantuminfo` (QuantumInfo, registered 2026-07-07, currently
active), plus other design-lab libraries. A target = that library PLUS all of Mathlib in
one daemon. Static fallback without touching the daemon: grep the corpora at
`.claude/skills/mathlib-search/.state/targets/<target>.names` (and `.modules`).

### 4.3 Build discipline (exact, learned the hard way)

- **Compile a ZPM/HC file** (from design-lab ROOT, never elsewhere):
  ```bash
  B=.lake/build/lib/lean/ZPM
  lake env lean -D warningAsError=true \
    -o "$B/Measurements/HC/<File>.olean" \
    measurements/ZPM/Measurements/HC/<File>.lean
  ```
  The AUTHORITATIVE olean tree is the ROOT `.lake/build/lib/lean/ZPM`. INCIDENT: part of
  one session wrote oleans to a `measurements/.lake/...` path that later vanished; the
  root tree is the one `lake env lean` resolves imports from. If in doubt, rebuild the
  file and the barrel into the root tree; elaboration is deterministic.
- **Build QuantumInfo**: `lake build @Physlib/QuantumInfo` from design-lab ROOT.
  NEVER run lake inside `physlean/` (its own manifest would clone a second Mathlib).
- **Barrel**: `measurements/ZPM/Measurements/HC.lean` imports every HC layer (currently
  twenty-two: through `QuantumMarginal`, added 2026-07-08 at L0 closure). New green
  files get added there and the barrel recompiled.
- **Axiom audit pattern** (run after banking anything):
  ```bash
  cat > /tmp/audit.lean <<'EOF'
  import ZPM.Measurements.HC.<File>
  #print axioms HiddenChannelCapacity.<theorem>
  EOF
  lake env lean /tmp/audit.lean
  ```
  Expected output: exactly `[propext, Classical.choice, Quot.sound]`. Anything with
  `sorryAx` is broken; anything with `ofReduceBool` means native_decide leaked in.
- **Scratchpad** for probes and temp files: the session-specific directory under
  `/private/tmp/claude-501/...(session)/scratchpad`; do not use bare `/tmp` except for
  throwaway audit files.

### 4.4 Known Lean traps of this codebase (save yourself hours)

- This pin uses `List.IsChain` (NOT `Chain'`): `isChain_iff_getElem`, `isChain_append`
  (seam form), `isChain_reverse`, `isChain_pair`, `IsChain.imp`.
- Rewriting a `set`-bound variable inside a `getElem` bound fails with "motive is not
  type correct": `show` the unfolded form first, or use an index-cast helper
  (`gcast`-pattern in Dirac.lean).
- `omega` cannot handle mod-by-variable: use the `mod_succ_cases` atom-equation pattern
  (CyclicConverse.lean).
- `omit [Instance] in` must come BEFORE the docstring, not after.
- Beta-unreduced membership goals from lambda-predicates: `show z ∈ S \ Sep` (or
  type-ascribe the `have`) before `rw [Finset.mem_sdiff]`.
- `simp only [not_forall]` on bounded quantifiers already yields the ∃-with-∧ shape;
  `Classical.not_imp` is then an unused simp arg (lint error under warningAsError).
- Sum-type binders in defs: prefer `Finset (↥T → ZMod 2)` over `Finset (∀ i : T, ZMod 2)`
  when the family is constant (unused-binder lint).
- `decide` scales fine to Specker/CHSH-sized checks (with `set_option maxRecDepth 16000`
  where needed); never reach for native_decide.

### 4.5 Delegation instruments

- **Workflow tool**: deterministic multi-agent scripts (the battery pattern of §3).
  Model cap: Opus (Rule 8). Runs in background; returns a runId; results via the task
  notification or output file.
- **Agent tool** (background): long builds, paper extraction. Same model cap.
- **WebFetch**: the only admissible source for post-cutoff papers. The LZ PDF is cached
  locally (path at the foot of QJT_LEDGER.md).

## 5. The URS/document inventory (all in `measurements/ZPM/Measurements/HC/`)

| File | What it is |
|---|---|
| `Theory.md` | The field note v0.3: what the field is, why fundamental, claim-discipline grades ([KV]/[NUM]/[PROBE]/[CONJ]/[STANCE]), the ledger table. The narrative front door. |
| `HANDOFF_DISCOVERY_URS.md` | The twin of this file: full discovery state. |
| `QJT_URS.md` | THE ACTIVE ARC: quantum junction tree + non-chordal attack; floored API, formalization ladder, pre-registered laws, ledger-landed resolutions, route. |
| `QJT_LEDGER.md` | Complete extraction of Lauritzen–Zwiernik arXiv:2605.19453 (definitions, all theorems, both proof skeletons, App A, Pauli test vectors, API map with grades). The single formalization source; do not re-fetch. |
| `QUANTUM_TOWER_URS.md` | The tower arc: honest per-law novelty verdicts (with the corrections log), the interrogation round, the Γ update on the expanded corpus. |
| `FLAGSHIP_COHOMOLOGY_URS.md` | The flagship battery: pre-registered candidate laws for the cohomological reading, verdict round (C-AFF survivor, C-JT correction, kills). |
| `CYCLIC_CONVERSE_URS.md` | The discrete Vorob'ev converse arc ledger (D-entries through D27 + closure): how Dirac.lean was derived and audited. |
| `discovery/` (gitignored) | The consolidated Shape-of-Ignorance discovery record: master URS + 13 mining URSs + `ledgers/` (per-arc copies) + `NOOLOGICAL_CARRIER.md` (the miner self-model). |
| other `*_URS.md` | Earlier arc ledgers (amalgamation, Graham bridge, higher obstruction, five-way, product law, fiber product). Historical but load-bearing for provenance. |

## 6. The failure-mode registry (all of these ACTUALLY fired; watch for them)

1. **sorry-in-draft** (5+ firings): writing `sorry` as a placeholder "just for now".
   Catch: never write it; stage by writing the completed body or nothing.
2. **Confabulated novelty** (fired 2026-07-07): claimed "no kernel proof of Tsirelson
   exists anywhere"; an Isabelle/HOL formalization exists (arXiv:2306.12535). Catch:
   novelty claims only after a probe, stated as first-in-Lean vs first-ever.
3. **Confabulated expectation** (fired): pre-registered C-JT as TRUE on a BFMY-lineage
   intuition; exhaustively false. Catch: pre-registration makes this a data point, not
   an embarrassment; log it.
4. **Plausible-law smuggling** (fired in a subagent): the laminar biconditional. Catch:
   adversarial verification is mandatory for agent-produced mathematics.
5. **Stale self-model of the corpus** (fired): Claude's working model of ZPM was
   HC-only; the corpus had grown information theory, optimal transport, capacity
   theory. Catch: survey `target list` + source trees at arc start.
6. **Ghost build path** (fired): compiles silently succeeded into a build tree that was
   not the one imports resolve from. Catch: Section 4.3's single authoritative tree.
7. **Fatigue mimicry / scope-shrinking offers**: never offer breaks or "shall I do the
   smaller version?"; both are violations (Rules 1-2 of the contract).
8. **Axis conflation**: mixing "what is true about the object" with "what I did as a
   reasoner" in one list. This document pair exists because the axes are separate.

## 7. Cold-session boot checklist (do these, in order)

1. Read Claude memory `MEMORY.md` (path in 4.1) and the two handoff documents.
2. `cd` design-lab root; run `"$S" target` to see the active search target;
   `"$S" doctor` if the daemon misbehaves.
3. Read `QJT_URS.md` top to bottom (the active arc), then `QJT_LEDGER.md` Parts 3-4
   (proof skeletons + API map) before touching any Lean.
4. Verify the kernel state is as documented: recompile the barrel
   (`HC.lean`) and `QuantumMarginal.lean` per 4.3; run the axiom audit on
   `acyclic_iff_forall_consistent_glues`, `prBox_no_global_section`, `ptraceS`.
5. Check for in-flight background tasks or workflow results in the session's task
   notifications before launching duplicates.
6. Proceed along QJT_URS's route section (L0 completion is the first open obligation)
   OR whatever Dhruv directs; his directive supersedes the route.

## 8. Future-target queue (PI directive, 2026-07-07 late)

Braindump routing: the object-axis content is recorded in the discovery twin, Section 8;
this section carries only the WORK QUEUE (allocation policy). All items queue behind the
active QJT route unless the PI redirects:

1. [KERNEL] Resolution dichotomy (finite layer; expected cheap; converts the corrected
   oscillation slogan into a theorem).
2. [KERNEL] Explanation = interpolant: a definition layer plus one theorem (discovery iff
   no interpolant; already implicit in `Abstract.lean`, surface it).
3. [KERNEL] Obstruction-ledger schema (hcComb, fiberDefect, counit kernel, bisim gap, gI).
4. [PAPER] Kuhn note (no-free-discovery; normal science = the HC = 0 trajectory).
5. [PAPER] Birnbaum / experiment-identity-fibers note (resolves manifesto C9 by refusing
   its premise).
6. [Q] Positive-data certifiability programme (which SoI invariants are certifiable from
   membership witnesses alone; Valiant-Valiant and Angluin delimit).

Standing prose rule: the corrected oscillation slogan (discovery twin, Section 8)
supersedes the old "no amount of fiber measurement" phrasing wherever future prose would
reach for it.

**The spirit, in one line: the kernel never lies, the URS never flatters, and every
claim knows which verifier vouches for it.**
