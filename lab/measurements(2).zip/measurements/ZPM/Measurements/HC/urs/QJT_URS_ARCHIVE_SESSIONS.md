# QJT_URS — the quantum junction tree and the non-chordal attack

**Problem (one line).** Formalize the Lauritzen–Zwiernik quantum Markov marginal theorem
(the first machine-checked quantum junction tree), then attack the open problem they
leave: the non-chordal characterization, via the field's cohomological machinery on the
stabilizer (quantum-affine) subclass.

**Started 2026-07-07. Source: Lauritzen–Zwiernik, "The Markov Marginal Problem for
Density Operators," arXiv:2605.19453 (May 2026; postdates knowledge cutoff, all content
from fetches). Substrate: QuantumInfo (built, slice audited clean), our chordality stack
(Dirac.lean), our junction-tree/RIP machinery (GrahamBridge/Amalgamation), the affine
direction-presheaf complex [NUM].**

---

## The theorem being formalized (from the abstract, verbatim-grounded)

T(ℛ): the canonical logarithmic construction, noncommutative analog of the junction-tree
formula (exp of the alternating log-sum over clique/separator marginals). Results:
(i) two overlapping marginals, and clique marginals on a CHORDAL graph: Tr(T(ℛ)) = 1 ⟺ a
quantum Markov completion exists; (ii) when it exists it is UNIQUE, equals T(ℛ), and is
the maximum-entropy completion; (iii) two-clique case: the two one-sided sandwich
reconstructions agree ⟺ the trace condition; (iv) gI(𝒢)_ρ, the global quantum
information of a chordal graph: a relative-entropy discrepancy from ρ to the logarithmic
candidate with a trace correction; (v) the intersection property for strictly positive
quantum CI; (vi) three-qubit Pauli examples separating local consistency / feasibility /
Markov feasibility / max entropy.

**Field alignment notes.** (a) gI(𝒢) is a graded, cover-indexed marginal-defect measure:
OP4's candidate object, delivered by the source paper. (b) The logarithmic form runs on
`HermitianMat.log/exp`, both present. (c) Chordality + clique trees are OUR banked
combinatorics (`dirac_strong`, RIP orders, ear machinery): the classical half of the
theorem is already in this kernel.

---

## Object axis (γ)

### Floored API (kernel-authoritative, target `quantuminfo`, this session)

PRESENT and clean: `HermitianMat.{sqrt, cfc (43 decls), log, exp, rpow, ker, kerProj,
supportProj (+65-name family), commute_sqrt_*}`; `MState.{traceLeft, traceRight, prod,
relabel(+_M,_cast,_comp), assoc, assoc', SWAP, piProd, uniform(+posDef), purify(+spec,X),
spectrum, pure_iff_constant_spectrum}`; `qcmi` + `qcmi_nonneg` (SSA) + dim bounds;
`qRelativeEnt_{additive, eq_neg_Sᵥₙ_add, ker, ne_top, op_le, rank, relabel}`;
`sandwichedRenyiEntropy_DPI` + `_eq_one` (relative-entropy DPI at α = 1); LiebAndoTrace
joint convexity; traceNorm; fidelity. Mathlib side (same daemon): Schur complement
(`Matrix.schur_complement_eq₁₁/₂₂`, PosSemidef fromBlocks criteria).

ABSENT (build ourselves): Petz recovery map and everything quantum-Markov-chain
(CMI = 0 ⟺ recoverable, HJPW): from scratch. PSD pseudo-inverse: build via
`cfc (x ↦ x⁻¹ on support)` + `supportProj`. Team-indexed partial trace `ptraceTeam`:
build via `piProd` carrier + `relabel` + `traceLeft` (plan validated by the tower
workflow's verifier against real signatures). DPI EQUALITY case (Petz sufficiency
theorem): absent; the inequality exists at α = 1.

QUARANTINE (unchanged): `Entropy.Axiomatized.*`, `Capacity.*`,
`qRelativeEnt_joint_convexity`, `fidelity_channel_nondecreasing`,
`ClassicalInfo.Capacity.BlockCode`.

### The formalization ladder (banking the first; each rung gated on the previous)

| Rung | Content | Risk |
|---|---|---|
| L0 | `ptraceTeam : MState (∀ i, X i) → (S : Finset ι) → MState (∀ i : S, X i)` + presheaf law (quantum `projS_image_restrict₂`) + `diag ∘ ptraceTeam = classical-marginal ∘ diag` | LOW (plumbing; relabel bookkeeping is the only trap) |
| L1 | T(ℛ) for a junction tree: `exp(Σ_cliques log ρ_C − Σ_seps log ρ_S)` on the piProd carrier; strict positivity regime first (PosDef marginals; support subtleties deferred and TRACKED, not hidden) | MED (log/exp of embedded operators; embeddings of team-local operators into the global space must commute correctly: the paper's own noncommutativity caveat) |
| L2 | Two-clique theorem: Tr(T(ℛ)) = 1 ⟺ quantum Markov completion exists; + the sandwich-reconstruction equivalence | HIGH (the paper's core; proof route unknown until full-text read; may need Petz-style machinery we must build) |
| L3 | Chordal/clique-tree case by induction along OUR RIP order (ear machinery) | MED once L2 lands (the induction is our home ground) |
| L4 | Uniqueness + max-entropy + gI(𝒢) | HIGH (variational; may need DPI-equality: defer, do not block L2/L3 on it) |

### The open-problem attack (candidate laws, verdicts pre-registered)

| Law | Statement | Expected verdict | Verifier |
|---|---|---|---|
| QJT-STAB | Stabilizer bridge: for stabilizer local states (the quantum-affine class) on ANY cover, quantum Markov completion is characterized by a symplectic-F₂ Čech condition: the direction-presheaf complex lifts with (direction space ↦ stabilizer group, parity datum ↦ phase function); completion ⟺ mismatch class vanishes (+ normalization condition). Specializes LZ on chordal covers; extends off-chordal on the computable subclass | PLAUSIBLE, the field's bet; needs care where stabilizer CI ≠ group condition | [NUM] battery: symplectic F₂ + exact stabilizer formalism (Python), probe + adversarial re-implementation, BEFORE any Lean |
| QJT-CYC | On the 4-cycle, there exist stabilizer families that are pairwise-consistent AND satisfy the local Markov/CMI conditions on all overlaps, with NO completion; the obstruction is a nonzero class of the lifted complex (the quantum PR box, upgraded from possibilistic to state-level) | TRUE expected (LZ's Pauli separations + our parity engine point the same way) | same battery |
| QJT-LOC | The sharp open question, formulated: is non-chordal completion-forcing cut out by LOCAL separator conditions, or is there a cover with all local conditions satisfiable and a strictly GLOBAL (cohomological) obstruction? QJT-CYC would settle it NEGATIVELY for locality on the stabilizer class | the field predicts: cohomological, not local | derivation + battery; kernel later |
| QJT-GRADE | gI(𝒢) vs the field's grading: on classical (diagonal) states over acyclic covers, gI reduces to the classical junction-tree KL discrepancy, and its vanishing locus is our entropy identity's exactness locus; the quantum hcComb candidate at chordal covers IS gI | PLAUSIBLE, checkable numerically | battery; ties OP4 to the source paper |

### KU (askable now)
Full-text proof routes of LZ Theorems (two-clique and chordal): what exactly do they
invoke (Golden–Thompson? Lie–Trotter? operator-log lemmas? Petz sufficiency?); whether
Tr(T) ≤ 1 always in the strictly positive regime; how they handle singular marginals;
the exact definition of "quantum Markov completion" over a graph (which CI conditions,
w.r.t. which separators); whether their intersection-property proof is formalizable
with our qcmi API.

### UK (pressure)
The stabilizer lift smells like it makes the LZ trace condition a PARITY condition (the
trace of the log-candidate on stabilizer data should collapse to an F₂ phase sum: the
quantum trace obstruction and our cyclic parity obstruction may literally be the same
invariant on this class). If that holds, the non-chordal answer on stabilizer covers is
the affine flagship complex wearing quantum dress, and the [KV] classical capstone, the
[NUM] affine H¹, and the quantum Markov problem meet in one object. Unarticulated
remainder: what replaces the direction presheaf off the stabilizer class.

---

## Agent axis (Γ)

**Will snapshot:** rigor over speed; the LZ paper postdates the knowledge cutoff, so
EVERY claim about its content must come from fetched text, never from memory; candidate
laws above are pre-registered and none is banked; [NUM] batteries precede Lean on all
new mathematics; sorry-quarantine discipline on vendor code; workflow model cap: Opus,
per standing policy.

**Route plan:** (1) full-paper read + derivation ledger (background agent, Opus): exact
definitions, all theorem statements, proof skeletons, lemma-level dependency map against
the floored API, flagging every step that needs machinery we lack. (2) L0 in main loop
(pure plumbing, no paper dependency). (3) QJT-STAB/CYC battery design after the ledger
lands. (4) L1/L2 formalization gated on the ledger. This URS is the handover document
for all of it.

---

## LEDGER LANDED — 2026-07-07 (QJT_LEDGER.md, full 33-page extraction; KU resolutions)

**Resolved KU (proof routes now KNOWN).**
- Thm 3.1's engine is Lemma 3.2: `D(ω‖T(R)) + 1 − Tr(T(R)) = I(A:B|C)_ω + Δ_R(ω)`, pure
  algebra over the extended divergence; ALL equivalence directions run on DPI-INEQUALITY
  (which we HAVE at α = 1) + Klein. The trace bound itself needs exactly one deep input:
  Lieb's three-matrix inequality (Ruskai 2002 Thm 5) + pull-out + a cfc spectral integral.
- The characterization spine (K-normality Prop 3.4, intersection Prop 2.5, the
  Petz-shaped uniqueness legs) is gated on ONE module: the paper's own self-contained
  finite-dimensional App A (weighted operator spaces, relative modular operator
  Δ_{τ,ρ}(X) = τXρ⁻¹, variational formula, equality criterion, Petz recovery, A.11).
  No external HJPW needed: formalizing App A IS the Petz build.
- Chordal Thm 3.10 = junction-tree-LEAF induction (our RIP/ear machinery is the
  substrate) + Prop 3.9 (chordal SSA, base case = SSA which we have) + Lem 3.11 + Thm
  3.14 (max-entropy, log-linear dual form).
- Positivity: everything strictly positive (PosDef). Support/singular handling is a
  DELIBERATE non-goal of the source; our formalization matches (PosDef hypotheses),
  singular boundary tracked as future structure, not smuggled.

**Ladder re-grade.**
- L2 splits: **L2a (inequality spine + existence equivalences)** — reachable with the
  current floor + the Ruskai assembly (HARD but self-contained; Lieb–Ando backbone
  present). **LA (the App A Petz module)** — the make-or-break build, prerequisite for
  **L2b (K-normality, intersection, uniqueness)**. L3 (chordal) needs L2a + Prop 3.9
  induction; its max-entropy leg needs Thm 3.14 (MEDIUM–HARD).
- New EASY obligations promoted to immediate: pull-out lemma (Lem 2.3, "most useful
  identity in the paper") over traceLeft/traceRight; extended divergence def + Klein;
  ⊙/⋆/K definitions; L0 presheaf law.

**QJT-STAB refinement (UK → sharper KU).** LZ's regime EXCLUDES exact stabilizer states
(singular); the battery objects are their ε-smoothed Pauli states ¼(I + εW). The
symplectic-F₂ structure enters through the ANTICOMMUTATION GRAPH of the constraint
words, and the trace obstruction has the exact analytic form Tr(T(R)) = cosh r / Π cosh
b_j (b_j = arctanh a_j, r = ‖b‖₂) for pairwise-anticommuting words: a strictly convex
hyperbolic defect, = 1 ⟺ at most one active word. The Čech-lift battery should
therefore carry (anticommutation graph, arctanh parameters) as its coefficient data and
test class-vanishing against the cosh-ratio criterion across mixed commutation patterns,
INCLUDING non-chordal covers where T(R) is undefined and our cocycle formulation is the
candidate replacement. The 3-qubit and 7-qubit Pauli families are the pinned test
vectors (all separations realized: local-consistency ⊋ feasibility ⊋ Markov-feasibility).

**Route (updated).** (1) L0 completion: presheaf law + pull-out + diag bridge. (2) EASY
layer: ⊙/⋆/K, extended divergence + Klein, Lem 3.2 as algebra. (3) The Ruskai assembly
(L2a's one hard stone). (4) Thm 3.1 existence equivalences = L2a banked. (5) In
parallel: QJT-STAB/CYC [NUM] battery with the cosh-criterion as ground truth on chordal
instances. (6) LA (App A) as its own sub-arc. (7) L3 chordal induction. (8) The
non-chordal attack rides the battery verdicts.

---

## PI FOLD-IN, 2026-07-07 (late): grading tower + ledger contacts

- **QJT-GRADE, sharpened.** The grading codomain is now an explicit three-tier tower:
  dim (affine dimension identity, [NUM]) → H (entropy junction-tree identity, [NUM]) →
  S(ρ) (LZ chordal: S(T(R)) = Σ_C S(ρ_C) − Σ_S ν(S)S(ρ_S), Thm 3.10). QJT-GRADE is
  exactly the claim that this tower commutes with the diagonal embedding (on diagonal
  states over acyclic covers, gI = the classical junction-tree KL discrepancy). The L0
  diagonal bridge is the substrate of that commutation; test vectors unchanged.
- **gI joins the obstruction ledger.** The PI's obstruction-ledger schema [CONJ]
  (one schema with morphisms over hcComb, fiberDefect, the idealize -| observe counit
  kernel, the bisimMetric gap; discovery twin Section 8) gains gI as its quantum row
  when L4 lands. A consumer of L4, not a prerequisite; it does not reorder the ladder.
- **Supporting-hyperplane reading (OP2 contact).** Prop 3.9 (chordal SSA) says the
  junction-tree entropy functional supports the cover-relative quantum entropy cone at
  Markov states; gI >= 0 with zero locus = Markov is the supported-face statement. This
  names the OP2 bridge the arc will eventually export.
- Route unchanged: L0 completion remains the first open obligation.

---

## L0 URS, 2026-07-08 (written mid-rung, after a PI method correction)

**Problem (one line).** Bank the three L0 obligations (presheaf law, pull-out, diagonal
bridge) as kernel objects whose ENCODING GRAMMAR the higher rungs (EASY, L2a, L3)
inherit; the mathematics is elementary, so the entire ignorance is in the encoding.

**Correction that forced this entry (Γ, logged with the same prominence as results).**
The reasoner entered a compile-iterate loop (six cycles) treating errors as the
discovery instrument instead of pre-articulating the ignorance and using the kernel as
the VERIFIER of designed hypotheses. The uncaught tell: three error bursts of one KIND
(syntactic-vs-definitional mismatch) are one joint, not three bugs. Caught by the PI,
not by self-audit. Rule reinstated: URS write precedes probe bursts; a repeated error
class triggers a joint articulation, not another patch.

### Object axis (γ): the encoding, measured

**KK (with evidence class).**
- The mathematics of all three obligations: finite sum reindexing along explicit
  bijections, delta-collapse, fiber decomposition. Zero mathematical risk anywhere in
  L0. [elementary]
- The floored API (kernel-authoritative, this session): `MState.relabel` is pullback
  (`M := reindex e.symm`; `relabel_m`/`relabel_relabel` are rfl-lemmas);
  `traceLeft/Right` are `Matrix.of`-wrapped entry sums, rectangular-friendly;
  the vendor's own proof grammar for this layer is: `ext` to entries at ABSTRACT
  carrier types, then `Finset.sum_*`. `ofClassical` is `HermitianMat.diagonal` of a
  `Prob`-valued `FunLike`; `ProbDistribution.mk'` constructs from ℝ-level data. NO
  pull-out, NO distribution marginal, NO relabel-trace commutation exists anywhere:
  all three are ours to build. [floored]
- Traces (T) from this session's probe protocol, now evidence:
  - T1: all four pull-out lemmas verified green (probe5/probe6) via the pointwise-have
    grammar: `have hterm : ∀ x, entry = collapsed` proved OUTSIDE binders, then
    `Finset.sum_congr`. [KV-grade probe, pending file compile]
  - T2: on structure-literal Equivs, `rw [dif_pos h]` fails against beta-unreduced
    composites while `exact dif_pos h` succeeds: proof irrelevance and Subtype eta are
    DEFINITIONAL, so defeq-checking tactics succeed where syntactic rewriting fails.
  - T3 (the load-bearing one): a one-shot `rfl` expanding a two-layer
    relabel/traceRight composite at CONCRETE Pi-subtype carriers times out at 200k
    heartbeats, while the same shape at abstract carriers is cheap. Defeq cost is
    governed by carrier concreteness (instance re-derivation at Pi-subtype types), not
    by proof depth.
  - T4: the Prob → ℝ → 𝕜 coercion arrives by two instance paths (`diagonal_mat`'s
    cast vs the explicit double-coe); rw's reducible-rfl cannot close the residue;
    default-transparency `rfl` expected to (KU-5).

**KU (askable now, each with expected verdict and kill).**
- KU-1 `traceAlong_m` rfl at abstract carriers: expected CHEAP-TRUE; kill = vendor
  traceRight not definitionally mat-level (then: one simp chain).
- KU-2 staged concrete proofs stay under heartbeats once all defeq work is abstract:
  expected TRUE; kill = instance blowup even at instantiation (then: heartbeats bump,
  vendor precedent exists).
- KU-3 `piSplit_merge` branches close by `simp [hiT, hiS]` with the two @[simp]
  apply-lemmas: expected TRUE; kill = coercion-of-mk normalization stall (then:
  per-branch `exact (dif_pos _).trans ...` chains).
- KU-4 `Finset.sum_fiberwise` name/shape at this pin for marginal normalization;
  KU-5 `ofClassical` coercion residue closes by terminal `rfl`;
  KU-6 `Finset.sum_nbij'` argument order at this pin;
  KU-7 the `MState.ext (HermitianMat.ext hm)` incantation;
  KU-8 barrel + axiom audit clean at the end (expect exactly the three axioms).

**UK (articulated this entry: the joints, named).**
- UK-1 → R-MOVE (the reassembly this entry exists for): the ABSTRACTION-BOUNDARY LAW.
  Definitional transparency in this vendor stack is affordable exactly up to the first
  concrete Pi-subtype carrier; the vendor's own lemmas implicitly respect it. Grammar
  rule adopted for the whole arc: every entry/composition lemma is stated over
  ABSTRACT index types and concrete carriers only ever INSTANTIATE it. Concretely:
  define `traceAlong (e : d ≃ a × b) : MState d → MState a := (·.relabel e.symm).traceRight`
  as THE L0 primitive; `ptraceS` and `qRestrict₂` become instances; ONE abstract entry
  lemma (`traceAlong_m`, rfl) and ONE abstract composition theorem
  (`traceAlong_traceAlong`, hypothesis = a pointwise split-coherence equation) carry
  everything; the concrete presheaf law is `traceAlong_traceAlong` applied to
  `piSplit_merge`. All defeq at abstract types (cheap); all concrete content is pure
  Pi-combinatorics (no MState). This is also the shape LZ Lem 2.2 wants at the EASY
  layer, so the grammar is bought once for the arc.
- UK-2 (named anomaly, parked): `Matrix.mul_apply` fires outside `Finset.sum` binders
  but not under them in this environment (T1 workaround: pointwise-have). Cause
  unarticulated (suspect instance unification in binder metacontexts). Becomes
  load-bearing at the EASY layer (mul-heavy goals); the sanctioned workaround grammar
  is recorded; one diagnostic probe owed before L1.
- UK-3 (coercion normal form): every classical-quantum bridge from here to QJT-GRADE
  crosses Prob → ℝ → ℂ. Normal form adopted: statements carry the explicit
  `((· : ℝ) : ℂ)` double-cast; one canonicalizing lemma per direction when the EASY
  layer arrives.
- UK-4 (structure debt, flagged not hidden): QuantumMarginal.lean now hosts three
  namespaces (Matrix pull-out = ForMathlib-grade; ProbDistribution.marginal =
  ClassicalInfo-grade; HC presheaf). Acceptable for L0; split before the barrel grows
  consumers of the Matrix block.

**UU.** Whether any entry-calculus survives above L0: the EASY layer's objects
(log/exp/⊙/⋆ via cfc) are spectral, not entrywise; the operator-level grammar is not
askable from below this rung.

### Agent axis (Γ)

- **A (Will snapshot).** Unchanged (never sorry, upheld including probes: goal-display
  via `done`, zero sorry anywhere; floor-before-formalize, upheld; axiom discipline;
  Opus cap). ADDED by correction: URS-write precedes probe bursts; repeated error
  class = joint, articulate before patching.
- **R-moves.** (1) teamSplit/complMerge/piSplit_merge grammar [in file];
  (2) traceAlong abstraction [imagine-move, kernel-gated, this tick];
  (3) pointwise-have workaround grammar [verified, T1].
- **M-moves.** Floor (done); probe-as-verifier protocol (T1-T4); next: ONE consolidated
  rewrite against this design, ONE compile as verdict, verdict round back here.
- **Γ_core.** Pl_imagine(traceAlong) HIGH: small, fully verifier-gated, mirrors the
  vendor's own assoc-family shape. Pl_imagine(one-shot bridge) MEDIUM (KU-5 coercion).
  Coh_ens↔Will HIGH: the R-move serves L1-L3 directly, not just this rung.
- **η (mid-rung).** Banked-in-probe: 4 pull-out lemmas + T1-T4 + one grammar law
  (UK-1). Cost: six compile cycles and one PI correction; the correction is the most
  valuable artifact of the tick.

### VERDICT ROUND, 2026-07-08: L0 BANKED

**Kernel state.** `QuantumMarginal.lean` green under `warningAsError`; barrel at
TWENTY-TWO layers (QuantumMarginal added, barrel recompiled green); axiom audit on all
eight banked declarations returns exactly `[propext, Classical.choice, Quot.sound]`.
Banked: `MState.traceAlong` + `traceAlong_m` (entry calculus, rfl) +
`traceAlong_traceAlong` (abstract Lem 2.2); `ptraceS`, `qRestrict₂` as instances;
`qRestrict₂_ptraceS` (the presheaf law, = abstract theorem + `piSplit_merge`); the four
`Matrix.trace{Left,Right}_*_kron_*` pull-out lemmas (Lem 2.3, any NonAssocSemiring);
`ProbDistribution.marginal` (fiber-sum pushforward) + `ptraceS_ofClassical` (the
diagonal bridge). L0 is CLOSED; all three obligations plus the promoted-EASY pull-out.

**KU resolutions (all eight).** KU-1 TRUE (rfl cheap at abstract carriers). KU-2 TRUE
with a REFINEMENT: the one post-redesign timeout was not carrier concreteness but a
higher-order unification hole (`Fintype.sum_prod_type _`); pinning the function
argument explicitly resolved it instantly. KU-3 TRUE (`simp [hiT, hiS]` closed every
branch). KU-4 TRUE (`Finset.sum_fiberwise` as guessed). KU-5 TRUE (terminal
default-transparency `rfl` closed the coercion residue). KU-6 TRUE (`sum_nbij'` with
named `i`/`j` arguments). KU-7 resolved better than expected (`MState.ext_m` exists,
entry-level ext in one step). KU-8 clean.

**New trace T5 (extends the abstraction-boundary law, UK-1).** Unification holes in
higher-order argument position cost like concrete-carrier defeq: the grammar rule
extends to "pin every higher-order argument with an explicit lambda; `_` is only for
first-order data."

**η of the corrected method, measured.** Pre-correction: six compile cycles for the
pull-out block alone. Post-URS redesign: the entire remaining file (composition
theorem, presheaf law, bridge, marginal) closed in one write plus three compiles, two
of which were one-line fixes. The URS-first discipline paid measurably within the
same rung.

**Route.** Next rung: the EASY layer (⊙/⋆/K + normality, extended divergence + Klein,
Lem 3.2 as algebra), with the UK-2 diagnostic probe (mul_apply-under-binder anomaly)
owed FIRST since the EASY layer is mul-heavy. The QJT-STAB/CYC [NUM] battery remains
the parallel track. UK-4 (module split of the Matrix/ProbDistribution blocks) fires
before external consumers appear.

---

## EASY-LAYER URS, 2026-07-08 (pre-implementation; UK-2 closed; floor re-graded)

**Problem (one line).** Bank Def 2.1 (⊙, ⋆), K + normality, the extended divergence D
with Klein, and Lem 3.2 as algebra, in the strictly-positive regime, leaving T(R)
two-clique statable; the L0 grammar (abstraction-boundary law, entry calculus,
explicit higher-order arguments) governs every write.

### UK-2 VERDICT (the owed diagnostic, closed)

Differential battery (P1, P2', P3', D1, D2, D3 + exact replay): `Matrix.mul_apply`
under a `Finset.sum` binder fails to fire EXACTLY at the four-way conjunction
{NonAssocSemiring instance path} AND {rectangular product} AND {pair-typed indices}
AND {under binder}; perturbing any single conjunct makes it fire. Over ℂ (a full
field, Semiring path) the corner is unreachable, so it is MOOT for the QJT arc;
recorded for ForMathlib-grade generality only. The pointwise-have grammar stays the
sanctioned workaround where the corner is live (the four L0 pull-outs already use
it). Downgraded from suspected law to pinned corner.

### Object axis (γ)

**KK (floored this tick; the ledger's Part-4 API map is STALE in our favor).**
- `HermitianMat.exp` / `.log` (cfc-based, LogExp.lean) with `CFC.exp_log`/`CFC.log_exp`
  roundtrips; `HermitianMat.rpow`, `.cfc` family.
- **`HermitianMat.log_kron [NonSingular A] [NonSingular B] :
  (A ⊗ₖ B).log = A.log ⊗ₖ 1 + 1 ⊗ₖ B.log`** with `_diagonal`/`_with_proj` variants:
  the embedded-log law T(R) needs, graded "ours to build" in QJT_LEDGER Part 4, is
  ALREADY VENDORED. Re-grade: PRESENT.
- **`HermitianMat.peierls_inequality (A) (g) (hg : ConvexOn ℝ univ g) :
  ∑ i, g ((A.mat i i).re) ≤ (A.cfc g).trace`**: the classical substrate for Klein.
- `HermitianMat.inner` (40-lemma family incl. `inner_eq_trace_mul`, `inner_comm`),
  `HermitianMat.trace` family, `HermitianMat.trace_reindex`, `Matrix.trace_submatrix`,
  `Matrix.traceRight_eq_traceLeft_reindex`.
- `HermitianMat.NonSingular A ↔ IsUnit A.mat` (typeclass, Invertible round-trip,
  `log_mono`, `log_conj_unitary`, `PosDef_kronecker`, `PosDef_reindex`, `cfc_posDef`).
  The paper's strictly-positive cone = PosDef hypotheses; NonSingular carries
  invertibility where that is all the lemma needs.

**KU (pre-registered, each with expected verdict and kill).**
- KU-E1: a non-normalized Klein (D(X‖Y) >= 0, = 0 iff X = Y) at HermitianMat level:
  expected ABSENT (qRelativeEnt is MState/trace-1); build via Peierls + spectral
  pinching or log_mono. RISK: the one genuinely hard stone of this layer.
- KU-E2: T(R) := exp(Σ embedded logs) well-defined WITHOUT commutation: expected
  trivially TRUE (cfc of a Hermitian sum).
- KU-E3 (the keystone, this tick): the trace duality (paper eq 2, team-indexed):
  `Tr(embedAlong e M * ρ.m) = Tr(M * (ρ.traceAlong e).m)`. Route fully floored:
  ρ.m = (ρ.relabel e.symm).m.submatrix e e; `submatrix_mul_equiv` moves the reindex
  off the product; trace is submatrix-equiv invariant; then the L0 pull-out
  `traceRight_kron_one_mul` + `traceRight_trace` finish. Expected ONE PAGE; kill =
  name/shape mismatch on the two Mathlib submatrix lemmas.
- KU-E4: the divergence carrier: D : ℝ via `HermitianMat.inner`
  (D(X‖Y) := ⟨X, X.log⟩ − ⟨X, Y.log⟩ − X.trace + Y.trace): expected the vendor-idiom
  form; kill = inner/trace real-part friction (then: complex trace with a real-part
  wrapper).
- KU-E5: Lem 3.2 needs the CMI log form for PosDef states; bridge Sᵥₙ to
  −⟨ρ, log ρ⟩-form: floor `Sᵥₙ` vs `HermitianMat.log` relation before the 3.2 write.

**UK (articulated).**
- UK-E1 (inquiry owed before pricing L2a): the vendor's LogExp/Peierls/NonSingular
  layer is richer than QJT_LEDGER Part 4 assumed (log_kron present, Peierls present).
  One systematic sweep of LogExp.lean + Peierls.lean + the CFC files is owed to
  RE-GRADE the L2a Ruskai assembly (its "resolvent integrals via cfc" may be
  partially vendored too). Do the sweep before writing Lem 3.2, not after.
- UK-E2 (the dual primitive): `embedAlong e M := (M ⊗ₖ 1).submatrix e e` is
  traceAlong's dual and the grammar the chordal induction (L3) will run on
  (embeddings of clique marginals BEFORE logs). Its algebra (embedAlong-of-log via
  log_kron + conj-invariance; embedAlong of commuting blocks) is next tick's
  definitional layer, designed at abstract carriers per the abstraction-boundary law.

### Agent axis (Γ)

- A: unchanged; URS-precedes-probes now explicitly in force (this entry precedes the
  keystone write).
- M this tick: UK-2 differential battery (7 probes, closed); EASY floor sweep
  (5 queries + 3 source reads); keystone implementation next with the kernel as
  verifier.
- Pl_imagine(keystone route) HIGH (every step floored); Pl_imagine(Klein route)
  MEDIUM (Peierls is substrate, assembly unverified); Coh_ens↔Will HIGH.
- Route: keystone (KU-E3) this tick; then ⊙/⋆/K/D definitional layer + Klein
  (KU-E1); then the UK-E1 LogExp sweep; then Lem 3.2. Battery track unchanged,
  awaiting PI direction on workflow spend.

### KEYSTONE VERDICT (same tick): KU-E3 TRUE, BANKED

`Matrix.embedAlong` (the dual primitive, `(M ⊗ₖ 1).submatrix e e`) and
**`MState.traceAlong_duality`** (`Tr(embedAlong e M * ρ.m) = Tr(M * (traceAlong e ρ).m)`,
LZ eq (2) split-indexed) are green in `QuantumMarginal.lean`; barrel recompiled;
audits: duality carries exactly the three standard axioms, `embedAlong` only
`Quot.sound`. Proof exactly as pre-registered (submatrix_mul_equiv, trace
equiv-invariance, traceRight_trace, the L0 pull-out), one page.

**UK-2 mechanism IDENTIFIED (upgrade from pinned corner to articulated cause).** The
duality proof reproduced the corner outside binders: `rw` with the rectangular-stated
pull-out fails against a square-typed goal product because SQUARE goals elaborate `*`
through `Mul (Matrix n n α)` while the general lemma is stated over the rectangular
`HMul` instance; the two are defeq but not reducibly, so keyed rewriting gives up.
This also explains the binder battery (square passed, rectangular failed, Semiring
repathed). Sanctioned grammar, now with its reason: at instance-path seams use
defeq-checking moves (`exact`, `congrArg`, term-mode application), never syntactic
rewriting. Two firings, one cause, entered as encoding law alongside the
abstraction-boundary law.

Deposited this rung beyond the plan: the duality was scheduled inside the EASY layer;
it is banked early because it is L0-grammar-pure. The EASY layer proper (⊙/⋆/K/D +
Klein) opens next tick with KU-E1 as its first stone and the UK-E1 LogExp sweep before
Lem 3.2.

---

## L2a FRONT-LOAD, 2026-07-08 (the BANK-Thm-3.1 bet; written before any probe or floor)

**PI directive.** Bank the full QJT problem this turn; front-load deeply; typing-derive
the propositions; floor; build; A5 throughout; cite sources per definition; hand to an
ultraconservative reviewer.

**THE BET (pre-registered, measurable).** A new file `QJTTwoClique.lean`, green under
`warningAsError`, added to the barrel, axioms exactly `[propext, Classical.choice,
Quot.sound]`, containing the COMPLETE two-clique quantum junction tree theorem
(Lauritzen–Zwiernik arXiv:2605.19453, Theorem 3.1) in the strictly positive regime:
(B1) the scenario layer at the abstract three-block carrier; (B2) T(R) (LZ eq. 5);
(B3) the trace bound Tr(T(R)) ≤ 1 WITHOUT Lieb's three-matrix inequality (route below);
(B4) Lemma 3.2 in normalized real form; (B5) the equivalences (i) Tr = 1 ⟺ (ii) T(R) is
a completion ⟺ (iii) a Markov completion exists, plus uniqueness. DECLARED OUT OF THE
BET (not scope reduction; ladder placement): Prop 3.4 / K-normality (L2b, gated on App
A), the chordal Thm 3.10 (L3). Bet lost partially if a floor-kill fires (F-table below);
the URS then records the exact wall and the A5 overflow obligation (build the missing
analysis, never weaken the statement).

### Front-load passes (the several-tick deepen/disprove record, Γ-trace)

**Pass 1 (deepen; the re-grade that changes the ladder).** The ledger graded the trace
bound HARD via Lieb/Ruskai (LZ's own §3.1 route). But LZ's CHORDAL proof (eq. 13) does
not use Lieb, and the two-clique case IS a chordal graph with two cliques. Specialized
derivation, checked twice: let c := Tr T(R), σ := T(R)/c (a state; PosDef since exp is
PosDef and c > 0). Then log T(R) = (log c)·1 + log σ, so
Tr(σ log T(R)) = log c − S(σ). Duality (BANKED: `traceAlong_duality`) turns
Tr(σ · embedded logs) into marginal pairings, giving
log c = −Δ_R(σ) − I(A:B|C)_σ where Δ_R(ω) := D(ω_AC‖ρ_AC) + D(ω_BC‖ρ_BC) − D(ω_C‖ρ_C).
Δ_R(σ) ≥ 0 by ONE DPI application (trace out A; σ_C = Tr_A σ_AC by the BANKED presheaf
law; ρ_C = Tr_A ρ_AC by the consistency hypothesis) plus state-level D ≥ 0; and
I(A:B|C)_σ ≥ 0 is SSA (vendored `qcmi_nonneg`). Hence log c ≤ 0. **The one hard stone
of the EASY-layer grading dissolves: no Lieb, no resolvent integrals, no Ruskai
assembly for Thm 3.1.** (L2a's price collapses to bridge lemmas.)

**Pass 2 (disprove attempt; attacks and their outcomes).**
- Attacked the Δ = 0 extraction in (i)⟹(ii): naive reading gives only D_AC = D_C. The
  correct order (recorded as the proof plan): from Δ = 0 and D_AC ≥ D_C (DPI over A):
  D_BC ≤ 0 ⟹ D_BC = 0 ⟹ ω_BC = ρ_BC (zero-iff) ⟹ ω_C = Tr_B ω_BC = Tr_B ρ_BC = ρ_C
  (presheaf + consistency) ⟹ D_C = 0 ⟹ D_AC = 0 ⟹ ω_AC = ρ_AC. One DPI pairing
  suffices; the naive two-pairing symmetric argument is NOT needed.
- Attacked log T(R) = Σ embedded logs: needs `log_exp` on a Hermitian SUM argument
  (no commutation needed: cfc log of exp of self-adjoint). Hypothesis check owed to
  the floor (F5).
- Attacked the carrier friction (vendor `qcmi` block convention unknown): mitigated
  structurally: EVERYTHING stated at the abstract carrier a × b × c with our own three
  marginal maps via `traceAlong` at three named equivs; ONE relabel bridge imports
  `qcmi_nonneg`. The abstraction-boundary law (L0) applied at theorem level.
- Attacked σ-wellformedness: c > 0 needed (else σ undefined): Tr exp(H) > 0 always
  (exp PosDef ⟹ positive trace, [Nonempty carrier]). Recorded as a lemma obligation.

**Pass 3 (definition-engineering audit; the eliminations).**
- The EXTENDED divergence (LZ eq. 4) is ELIMINATED from the critical path: every D in
  the proof is state-vs-state except D(ω‖T(R)), and that one appears only through
  D(ω‖T(R)) = D_state(ω‖σ) − log c − 1 + c. So Lem 3.2 is restated in NORMALIZED form:
  **D_state(ω‖σ) − log c = I(A:B|C)_ω + Δ_R(ω)** for every state ω. (Equivalent to LZ
  Lem 3.2 by log T = log c + log σ; the docstring cites Lem 3.2 and states the
  normalization explicitly. A4 audit: this is a presentation variant, not a new claim.)
  At ω = σ: the bound. At Markov ω ∈ M(R): D(ω‖σ) = log c ≤ 0 and ≥ 0 ⟹ c = 1 ∧ ω = σ:
  existence direction AND uniqueness in one stroke.
- Klein needs reduce to: state-level D ≥ 0 and D = 0 ⟺ equality. Scalar corrections
  (−log c − 1 + c ≥ 0) via `Real.log_le_sub_one_of_pos` (Mathlib, to floor). No
  PSD-vs-PSD Klein anywhere.

### R (typing derivation, per task-urs-typing-derivation)

| Concept | Profile | Centerpiece decision | Measurement notes |
|---|---|---|---|
| Scenario carrier | T-Abbrev + variables | `{a b c : Type*}` + three named equivs `eqAC : a×b×c ≃ (a×c)×b`, `eqBC : ... ≃ (b×c)×a`, `eqC : ... ≃ c×(a×b)` as `def`s (stable names for traceAlong/embedAlong arguments) | Pl crisp; Coh composes by design with the L0 primitives; Inv: any association handled by these three names only |
| Marginals | T-Abbrev | `margAC ω := ω.traceAlong eqAC` etc.; second-level marginal via `Equiv.prodComm` | inherits L0 grammar |
| Consistency | T-Prop | `Consistent2 ρAC ρBC : Prop := ρAC.traceAlong (Equiv.prodComm _ _) = ρBC.traceAlong (Equiv.prodComm _ _)` | the LZ consistency hypothesis verbatim (cite p.7) |
| PosDef regime | hypothesis args | `(hAC : ρAC.m.PosDef)` style; NO subtype/structure wrapper | a wrapper breaks Coh with every vendor lemma (Coh_break ≈ 1); vendor idiom is side conditions |
| embed (Hermitian) | T-Bridge | `HermitianMat.embedAlong` wrapping the banked Matrix-level def OR vendor `⊗ₖ`+reindex on HermitianMat (floor F5 decides) | Coh_coercion high at the Matrix↔HermitianMat seam: budget ONE bridge point, restate duality there once |
| T(R) | T-Parametric | `Tlog ... : HermitianMat (a×b×c) ℂ := exp(embedded logs sum)`; NOT an MState (trace < 1 is the theorem's subject; LZ eq. 5 cited) | the load-bearing type decision; normalized `σ` built as MState only under c > 0 |
| Divergence | T-Parametric + T-Bridge | algebra in ℝ: either vendor `qRelativeEnt.toReal` end-to-end or own `qDivR ρ σ := ⟨ρ.M, ρ.M.log⟩ − ⟨ρ.M, σ.M.log⟩` with a toReal bridge for nonneg/zero-iff (floor F4 decides) | ENNReal is Coh-hostile to the subtraction-laden Lem 3.2 algebra: ℝ is forced for the identity layer; inequalities imported across ONE seam |
| I(A:B\|C) | T-Abbrev + T-Bridge | own S-sum at our carrier; ONE relabel bridge to vendor `qcmi_nonneg` (F6) | keeps the theorem statement vendor-convention-free |
| M(R), Markov | T-Prop | `IsCompletion`, `IsMarkovCompletion` Props (LZ p.7, Def 2.4 cited) | quantifier structure trivial; vacuity audit: nonempty instances exist (product states) |
| Thm 3.1 | T-Prop ×4 | bound; (i)⟹(ii); (iii)⟹(i); uniqueness; assembled iff | separate named theorems per Lean idiom |

**UKs discovered by the typing pass:** UK-T1 the single Matrix↔HermitianMat seam
placement (duality restatement); UK-T2 the single ENNReal↔ℝ seam per imported
inequality; UK-T3 the MState constructor field names for σ; UK-T4 the Sᵥₙ ↔ −⟨ρ, log ρ⟩
bridge (= old KU-E5), now on the critical path of the log c identity.

### K/U (object axis), with the floor table (pre-registered verdicts)

**KK.** The L0 layer (traceAlong + entry calculus + composition + duality + pull-out +
presheaf + diagonal bridge, all banked); SSA vendored; exp/log/cfc vendored; log_kron
vendored (EASY-layer floor); the front-load derivations above (checked twice by hand,
kernel pending).

| Floor | Question | Expected | Kill (A5 overflow if fired) |
|---|---|---|---|
| F1 | vendor state-level D zero-iff (`qRelativeEnt = 0 ⟺ ρ = σ`) exists | PRESENT 0.7 | build via spectral double decomposition (HARD; bet partially lost) |
| F2 | DPI at α = 1 usable for partial trace (channel object exists or direct lemma) | PRESENT 0.6 | build partial-trace CPTPMap (MEDIUM) |
| F3 | Sᵥₙ = −⟨ρ, log ρ⟩ bridge | PRESENT 0.5 | build via cfc spectrum sum (MEDIUM) |
| F4 | qRelativeEnt ↔ real log-form bridge under PosDef | PRESENT 0.4 | own qDivR + matrix Klein from Peierls (HARD; the bet's main risk) |
| F5 | HermitianMat reindex + ⊗ₖ + log_exp hypotheses friendly | PRESENT 0.9 | Matrix-level workarounds (LOW) |
| F6 | qcmi convention bridgeable by relabels | PRESENT 0.85 | restate SSA at our carrier via Sᵥₙ relabel-invariance (LOW-MED) |

**UK.** Whether the vendor's sandwiched-entropy foundations make F4's bridge
definitional or analytic (the sweep decides); whether `Tr exp(H) > 0` needs Nonempty
carrier plumbing. **UU.** The operator grammar above this rung (Petz/App A) stays
unaskable from here.

### AMRT (agent axis)

- **A.** Will unchanged (never sorry incl. drafts; A5 add-structure-only; floors before
  names; cite LZ per definition in every docstring; Opus cap on subagents; reviewer
  handoff mandated this turn). The bet above is the tick's identity commitment.
- **M.** Background sweep workflow (4 Sonnet extractors over Relative/DPI/VonNeumann+
  SSA/LogExp+CFC+Peierls+LiebConcavity) launched BEFORE this entry; pinpoint daemon
  floors after; kernel as sole verifier of the build; ultraconservative Sonnet reviewer
  (async) after banking; `mathlib-search reindex measurements` at tick end (loogle
  updated with this tick's progress; quantuminfo target unchanged since its build).
- **R.** The typing table above + the two L0 encoding laws (abstraction-boundary;
  defeq-at-instance-seams) inherited wholesale.
- **T.** Passes 1-3 above; sweep + floor results and compile traces appended at the
  verdict round.

**Γ_core.** Pl_imagine(eq-13 specialization) MEDIUM-HIGH pre-kernel (derived twice,
adversarially attacked once, no verifier yet: it is the bet's biggest exposure and its
biggest payoff); Pl_imagine(normalized 3.2) HIGH (pure algebra); Coh_ens↔Will HIGH (the
bet IS the directive). Honesty note: the eq-13 route is MY specialization of LZ's
chordal proof to their two-clique case; if the kernel refutes a step, the fallback is
LZ's own Lieb route (which means the bet's B3 fails this turn and the Ruskai assembly
returns to the ladder).

### L2a VERDICT ROUND, 2026-07-08: THE BET IS WON

**Kernel state.** `QJTTwoClique.lean`, 935 lines, green under `warningAsError`; barrel at
TWENTY-THREE layers; zero sorry; every headline declaration audits to exactly
`[propext, Classical.choice, Quot.sound]`: `HermitianMat.inner_cfc_cfc`,
`inner_log_faithful`, `lem_3_2`, `trC_le_one`, `sigT_markov_of_trC_eq_one`,
`markov_completion_eq_sigT`, `lz_theorem_3_1`.

**Bet items.** B1 scenario layer ✓ (native a × c × b carrier; qcmi applies verbatim;
design shift from the abstract-equiv plan logged: vendor-composite marginals make qcmi
DEFINITIONAL). B2 T(R) ✓ (LZ eq. 5, embeddings as HermitianMat kron/reindex). B3 the
trace bound WITHOUT Lieb ✓ (the front-load's eq-13 specialization CONFIRMED BY THE
KERNEL: `trC_le_one` uses only Lemma 3.2 at ω = σ(R), SSA, and one DPI application).
B4 Lemma 3.2 in normalized real form ✓ (pure algebra over the three dualities). B5 the
full equivalences + uniqueness ✓ (`lz_theorem_3_1`).

**Floor-table outcomes.** F1 FIRED as pre-registered (faithfulness ABSENT vendor-wide):
the A5 overflow was built THIS TURN: `inner_log_faithful` via the new shared-eigenbasis
double sum `inner_cfc_cfc` (generalizing the vendored `inner_eq_doubly_stochastic_sum`
to `(cfc f, cfc g)` pairs with ONE kernel), doubly-stochastic row/column sums, and the
strict scalar Klein layer (`kleinTerm`). F2 PRESENT better than expected
(`CPTPMap.traceLeft` + `sandwichedRenyiEntropy_DPI_eq_one`; ONE ENNReal→ℝ seam via
`qRelativeEnt_rank` + `toReal_bridge`). F3 PRESENT (`Sᵥₙ_eq_neg_trace_log`). F4 PRESENT
definitionally (the vendor's α = 1 branch IS the inner-log form). F5/F6 PRESENT.
NEW build beyond plan: `posDef_traceLeft` (strictly positive marginals).

**Γ (honesty log).** (1) The sorry-in-draft failure mode fired a SIXTH time mid-turn
(a heredoc draft with a `sorry` placeholder landed on disk for one command's duration;
caught by the same command's echo, removed before any compile; a second draft with
sorry was refused BEFORE write). The rule held in substance and failed in letter once;
logged with the incidents. (2) The eq-13 re-derivation (front-load Pass 1) survived the
kernel unchanged: the derivation-first discipline priced the whole rung correctly and
the "hard stone" (Ruskai/Lieb assembly) was never needed. (3) The encoding laws (defeq
at instance seams: fired twice more, both resolved by `congrArg`/`show` moves as the
grammar dictates; the `ℝ≥0`-scope and Σ-identifier traps are new entries for the trap
registry).

**Route.** L2b (K-normality, Prop 3.4) remains gated on App A (the Petz module = the LA
rung). L3 (chordal) opens on our junction-tree combinatorics with `lz_theorem_3_1` as
its base case. The QJT-STAB/CYC battery track is unchanged. Reviewer handoff: an
ultraconservative Sonnet verifier runs async on this file (claims, citations, proofs).

**REVIEWER VERDICT (ultraconservative Sonnet, async, 2026-07-08): CLEAN, all seven
items PASS.** Highlights beyond the brief: (1) axiom probe rebuilt from scratch over
ALL 47 declarations (not the self-reported seven), all exactly the three standard
axioms; (2) statement fidelity checked against the CACHED PDF directly, including the
confirmation that LZ's own Thm 3.1 proof does invoke Lieb/Ruskai while the eq. 13
chordal route is genuinely Lieb-free, so `trC_le_one` is correctly described as a
two-clique specialization of the alternate route; (3) NON-VACUITY KERNEL-PROVED: the
reviewer compiled `lz_theorem_3_1 hAC0 hCB0 hcons0` at uniform ⊗ uniform states on
`Fin 2` factors, exit 0, axioms clean: the theorem has a fully discharged concrete
instance; (4) qcmi convention hand-expanded from vendor source and confirmed =
LZ I(A:B|C); (5) no URS overclaim found. L2a is BANKED AND INDEPENDENTLY VERIFIED.

---

## OPEN-PROBLEM FRONT-LOAD, 2026-07-08 (the QJT-LOC bank; unified prop set; written before floors)

**PI directive.** Bank the OPEN problem now (LA, L2b, L3, QJT-STAB/CYC) from ONE unified
prop set typed in a single KU pass; discharge both critiques (the missing rung-connecting
functor; the crisp novelty line) via A5 only; the support-vs-information gap is the
central understanding; outcome = the world's first machine-checked solution to the open
QJT problem.

**THE OPEN PROBLEM, sharpest form (from the interrogation round + LZ p. 16).** LZ prove
the trace criterion for two-clique and chordal covers and leave general covers open,
noting no simple non-emptiness condition exists off chordal graphs. The locality form:
is quantum(-Markov) completability on non-chordal covers decided by SEPARATOR-LOCAL
conditions (conditions on proper subfamilies), or is there a strictly GLOBAL obstruction?

**THE BET (pre-registered).** A new file `QJTOpenProblem.lean`, green, barrel-added,
axioms exactly the three, containing:

CORE (the named outcome; all six needed for the bet to be WON):
- **B1 (the functor, critique 1 discharged).** The diagonal pair
  (`MState.ofClassical` [vendored] with a new retraction `MState.diagDist` extracting the
  diagonal distribution) with BOTH naturality squares over the ptraceS presheaf:
  `ptraceS_ofClassical` [banked, L0] and the new
  `diagDist_ptraceS : (ptraceS ω S).diagDist = ω.diagDist.marginal S`. This is the formal
  arrow: the SAME marginal presheaf carries the possibilistic, distributional, and
  quantum rungs, and the squares commute.
- **B2 (transport).** For families of classically-embedded (diagonal) prescriptions on
  any cover: a quantum completion exists iff a classical distributional completion
  exists. Forward: `diagDist` of the completion. Backward: `ofClassical`. This makes
  "the identification phenomenon is quantization-invariant" a THEOREM, not a parallel.
- **B3 (G1, support-obstruction lifts).** If the possibilistic support family has empty
  join (`joinFam = ∅`), then NO distributional completion and NO quantum completion
  exists for ANY family supported there. Applied at the PR box [banked
  `prBox_no_global_section`]: the base-level obstruction kills every fibre. (The
  fibration F : measures → supports of Theory.md §4, made kernel.)
- **B4 (G2, the information-level witness).** The smoothed cycle family at r = 7/8 on
  the 4-cycle over `∀ i : Fin 4, Fin 2`: per-edge distributions with mass r/2 on each
  parity-agreeing pair and (1−r)/2 on each parity-disagreeing pair, with ONE edge
  twisted. Kernel facts: (a) FULL supports (the possibilistic join is everything:
  support-level obstruction VANISHES); (b) pairwise consistent (uniform site marginals);
  (c) every proper subcover admits a strictly positive completion (3-path junction-tree
  construction, explicit rational masses); (d) NO quantum completion exists (correlation
  functional: the four edge-correlations are ±(2r−1); any global distribution satisfies
  the pointwise cycle bound |c₁+c₂+c₃−c₄| ≤ 2 [16-point check]; 4(2r−1) = 3 > 2 kills;
  quantum killed via B2/B3-machinery: the diagonal of any quantum completion is a
  classical completion).
- **B5 (QJT-LOC, assembled).** Therefore completability on the non-chordal 4-cycle is
  NOT a function of the proper-subfamily data: two families agreeing on every proper
  subcover-condition class (all locally completable, all fully supported) differ in
  global completability. No separator-local criterion decides the LZ completion problem
  off chordal covers; the obstruction is strictly global, and it is INVISIBLE at the
  support stratum. With B3 this is the two-sided independence: support-obstructions lift
  to information; information-obstructions exist where support is blind.
- **B6 (the gap named).** The one-parameter family r ∈ (1/2, 1]: at r = 1 it degenerates
  to the possibilistic PR box [KV]; at r = 7/8 the obstruction is strictly
  informational. The parity class DESCENDS from support to information through the
  correlation functional: the same class, two strata.

TYPED-SET (same turn, single typing pass; proofs ranked AFTER the core; the residual, if
any, recorded at the verdict round): **LA** (`LZPetzRecovery`, LZ Prop A.10/A.11 as a
named Prop), **L2b** (`LZKNormalCriterion`, Prop 3.4), **L3**
(`LZChordalTraceCriterion`, Thm 3.10 over our junction-tree combinatorics),
**QJT-STAB** (the stabilizer Čech characterization shape). Typing them WITH the core in
one table is the directive's point: the entire goal structure visible and type-checked
at once.

**Honesty rows (critique 2, pre-registered).** The witness mathematics (cycle marginal
polytope, cut inequality) is classical and elementary to specialists; LZ Thm 3.1 was
LZ's theorem, mechanized here first. The NEW objects of this arc: the machine-checked
resolution of the locality question; the formal quantization-invariance arrow (B1/B2);
the two-sided support/information independence (B3+B4), the transform-side face of which
is `WMSpec.Transform.TransformOrthogonality` (which imports THIS layer: the derivation
direction is ours). Novelty of the assembled statement: UNKNOWN pending probe; claimed
as formalization + assembly + arrow, never as new deep quantum mathematics.

**Front-load passes (Γ-trace).** Pass 1 (deepen): the witness derivation (threshold
r > 3/4 from the cut facet; the 16-point sign-product contradiction for the pointwise
bound; the r = 1 degeneration to the banked PR box). Pass 2 (disprove): (i) quantum
evasion attack: killed by the diagonal retraction (any ω with the prescribed diagonal
marginals has diagDist a classical completion); (ii) "are the local conditions really
all local conditions": formalized as proper-subcover completability, the strongest
local class; sub-subcovers inherit by marginal coherence [banked presheaf law];
(iii) consistency check of the smoothed family: single-site marginals uniform on every
edge including the twisted one ✓. Pass 3 (audit): the (c)-construction is the cost
center (rational-mass 3-path junction trees); the grammar exists in the ecosystem
(`WMSpec.Transform` works raw-ℝ with explicit sum lemmas: adopt that idiom: ℝ-valued
mass functions, `ProbDistribution.mk'` only at interfaces).

**Floor table (expected verdicts).** F1 ProbDistribution API friendly 0.9; F2 diag
extraction (PSD diagonal real-nonneg, trace-1 sum) 0.85; F3 rational-mass Prob
construction via mk' + norm_num 0.8; F4 the 16-point bound decide-able 0.9; F5
supp-marginal positivity lemma from `marginal_coe` 0.9; F6 the 3-path marginal checks
(field_simp + consistency telescope) 0.7: the risk center. Kills: per-item A5 overflow
(build the missing lemma), never statement-weakening.

**A (Will).** Unchanged + this directive; the sorry-registry stands at six firings: zero
tolerance this arc. **M.** Floors via daemon (targets measurements + quantuminfo);
typing table below; kernel as verifier; ultraconservative Sonnet reviewer async at the
end; `reindex measurements` at close. **R.** The typing table (next entry). **T.** The
three passes above; compile traces at the verdict round.

### R: the unified typing table (task-urs-typing-derivation, one pass, whole goal visible)

| # | Concept | Profile | Centerpiece type decision | Measurement notes |
|---|---|---|---|---|
| 1 | `MState.diagDist` (the retraction) | T-Bridge | `MState d → ProbDistribution d`, mass `(ω.m x x).re`; nonneg from PSD diagonal, sum-1 from trace | Coh: completes the (ofClassical, diagDist) adjoint-like pair over ONE presheaf; the arrow's missing leg |
| 2 | `diagDist_ptraceS` | T-Prop (naturality) | `(ptraceS ω S).diagDist = ω.diagDist.marginal S` | entry calculus mirrors the banked `ptraceS_ofClassical`; the two squares together = the functor |
| 3 | Prescription families | T-Parametric | `p : J → ProbDistribution (∀ i : (team j : Finset ι), X i)` with `IsCompletionC/Q` Props quantified over `∀ j` | GENERAL (any ι, any cover); the witness instantiates at `ι = Fin 4`, `X = fun _ => ZMod 2` |
| 4 | Transport (B2) | T-Prop | `(∃ ω, IsCompletionQ (ofClassical ∘ p) ω) ↔ (∃ q, IsCompletionC p q)` | quantization-invariance as one iff; Inv: holds at every arity/cover |
| 5 | Support lift (B3) | T-Prop | empty possibilistic join of supports ⟹ no classical AND no quantum completion, ∀ fibres | the fibration statement; consumes `marginal_coe` positivity |
| 6 | Value type | T-Abbrev | `ZMod 2` sites (not `Fin 2`): parities are `∑ i, g i` sums, matching the banked `prRel` grammar | kills all coordinate surgery |
| 7 | `edgeDist` (smoothed family) | T-Parametric | mass `if (∑ i, g i) = tw e then r/2 else (1−r)/2`, `tw 3 = 1` else `0`; SYMBOLIC in `r` | strict positivity for r ∈ (0,1); r = 1 degenerates to the PR box supports |
| 8 | `pathCoords` reparameterization | T-Bridge (the proof engine) | the Equiv `(∀ i : Fin 4, ZMod 2) ≃ base-site × edge-parities`; all marginal/normalization sums FACTOR through it (`Equiv.sum_comp` + `Fintype.sum_prod_type`) | replaces 16-point numeric grinding by symbolic factorization; the `WMSpec.Transform.sum_pi_prod` idiom |
| 9 | Correlation functional | T-Abbrev | `corrE p := mass(parity 0) − mass(parity 1) : ℝ` per edge; pull-back lemma `corrE (marginal) = expectation of sign` | linearity + the pointwise bound live here |
| 10 | Pointwise cycle bound | T-Prop + decide | ℤ-valued sign-sum `≤ 2` over the 16 points, by `decide`; cast to ℝ | the sign-product contradiction, kernel-checked |
| 11 | 3-path completions (B4c) | T-Parametric construction | junction-tree mass `4·m₁·m₂·m₃` in the `pathCoords` chart | the cost center; symbolic in r |
| 12 | B4/B5 assembly | T-Prop ×3 | full-support lemma; proper-subcover completability; no-global-completion; the locality corollary | quantifier care: "local class" = proper-subcover conditions |
| 13 | LA (`LZPetzRecovery`) | T-Prop (typed, proof ranked after core) | faithful A.11 statement via existing vocabulary (qcmi, sqrt, rpow) | vocabulary EXISTS: typed this turn |
| 14 | L2b (`LZKNormalCriterion`) | T-Prop (typed) | Prop 3.4 via K := sqrt/rpow products + IsHermitian-normality | vocabulary exists |
| 15 | L3 (`LZChordalCriterion`) | T-Prop (typed) | statement over List-of-teams with the CLASSICAL RIP predicate (Amalgamation) + quantum families | reuses banked combinatorics; proof = own rung |
| 16 | QJT-STAB | T-Break (recorded) | faithful typing REQUIRES the symplectic/stabilizer vocabulary absent from the entire corpus; typing it without that layer would be vacuous (A4) | the vocabulary build is the obligation, logged, not dodged |

**UKs discovered by the pass:** UK-O1 the `pathCoords` chart is the single engine for
normalization, marginals, consistency, correlations AND the infeasibility sum: build it
first, everything else consumes it. UK-O2 the `sum_fiber_restrict` helper in
QJTTwoClique is `private`: replicate (do not de-private vendor-style file surgery
mid-arc). UK-O3 ProbDistribution equality: needs a `DFunLike.ext`-style extensionality:
floor. UK-O4 the sign-functional needs an ℤ↔ℝ cast seam: one lemma.

### OPEN-PROBLEM VERDICT ROUND, 2026-07-08

**Kernel state.** `QJTOpenProblem.lean`, 522 lines, green under `warningAsError`;
barrel at TWENTY-FOUR layers; zero sorry; all nine headline declarations audit to
exactly the three standard axioms.

**Bet outcomes.**
- **B1 WON (critique 1 discharged).** The quantization arrow is FORMAL: `MState.diagDist`
  (the retraction) + `diagDist_ofClassical` + both naturality squares
  (`ptraceS_ofClassical` [L0], `diagDist_ptraceS` [new]) over the ONE marginal presheaf.
- **B2 WON.** `completionQ_diag_iff`: quantum completability of classically-embedded
  families = classical completability, ANY cover, ANY arity. Quantization-invariance is
  a theorem, not a parallel.
- **B3 WON (general form).** `no_completionC_of_empty_join`: empty possibilistic join
  kills every classical (hence quantum) fibre. RESIDUAL: the PR-box-specific corollary
  instantiation (`prBox_fibre_obstruction`, pure plumbing to `joinFam`).
- **B4 WON on (a),(b),(d); (c) RESIDUAL.** Full support (`edgeDist_full_support`: the
  support obstruction VANISHES), pairwise consistency (`edgeDist_site_uniform`: all site
  marginals uniform), and NO completion, classical (`cycleFam_not_completableC`, via
  `cycle_bound` + the kernel sign-product contradiction `one_le_disag` [decide] +
  `corrE_edgeDist`: 4(2·7/8 − 1) = 3 > 2) or quantum (`cycleFam_not_completableQ`, via
  B2). (c) proper-subcover completability: construction fully designed (chart₃ with
  general twist + rotation transport; front-load Pass 3) but NOT kernel-verified this
  turn: the residual obligation.
- **B5 PARTIAL.** Kernel-proved: LZ-completability off chordal covers is NOT implied by
  full support + pairwise consistency (the trivially-checkable local sanity class), and
  the obstruction is strictly informational (invisible at the support stratum). The
  full "no proper-subcover criterion" form awaits (c). NOT claimed beyond what is
  proved.
- **B6 WON.** The r-family: r = 1 degenerates to the banked PR box supports; r = 7/8 is
  the strictly-informational witness. The parity class descends from support to
  information through the correlation functional: kernel-realized.
- **TYPED-SET RESIDUAL:** LA/L2b faithful Prop statements + L3 (typing table row 13-15)
  not written this turn (context exhausted on the core); QJT-STAB recorded as T-Break
  (row 16). All ranked next.

**The support-vs-information gap, as banked.** Two kernel theorems now bracket it:
support-obstructions kill every fibre (B3), and there exist fibre-obstructions over
obstruction-free supports (B4): the two strata carry INDEPENDENT obstruction theories.
The transform-side face (`WMSpec.Transform.TransformOrthogonality`) derives from this
layer; the derivation direction is ours.

**Honesty (critique 2, standing).** The witness mathematics is classical (cycle marginal
polytope); the new objects: the machine-checked strictly-global-obstruction theorem for
the LZ completion problem, the quantization arrow, the two-sided independence. Novelty
of the assembly: pending probe; never claimed as new deep quantum mathematics.

---

## B4(c)/B5-CLOSURE FRONT-LOAD, 2026-07-08 (residual bank; written before floors)

**THE BET.** Extend `QJTOpenProblem.lean` (green, barrel, three axioms) with:
- **C1** the base-point chart `cycChart s : V ≃ ZMod 2 × (ZMod 2)³` (site value at
  `s := j₀ + 1` + the three path-edge parities; inverse by char-2 cumulative sums);
- **C2** the junction-tree completion `pathMass j₀` := `(1/2)·∏` over the three edges
  `≠ j₀` of `M_j(par_j x)` with `M_j u := if u = tw j then r else 1 − r` (the classical
  junction-tree formula for the path, LZ Rem 3.15 classical case; masses scaled so the
  edge marginal reproduces `edgeMass`), a `ProbDistribution` (sum-1 via C1);
- **C3** the three marginal checks: for every path edge `e ≠ j₀`,
  `(pathDist j₀).marginal (cyc e) = edgeDist r e`, each case closing by TWO shift-sums
  (`∑_v M(u + v) = 1`, the `Equiv.addLeft` bijection trick) after the fiber transport
  through `sum_fiber_restrict'` and the complement chart (`compl (cyc e) = {e+2, e+3}`,
  by `decide`);
- **C4** B5 CLOSED: `qjt_not_local`, the packaged theorem: the r = 7/8 family has full
  support ∧ uniform-site consistency ∧ EVERY proper subcover (∀ E ≠ univ, via a missing
  `j₀ ∉ E`) admits a strictly positive classical AND quantum completion ∧ no global
  classical completion ∧ no global quantum completion. Plus the general-subset
  corollary from the four maximal cases.

**Pre-registered honesty rows.** The subcover completions constructed are the classical
junction trees embedded diagonally: quantum completions via `ofClassical` +
`ptraceS_ofClassical` (one line per family). Their MARKOV property (classical CMI = 0,
quantum qcmi = 0) holds by construction mathematically but is NOT kernel-verified this
tick: recorded as the new residual `R-Markov` (needs the Sᵥₙ(ofClassical)/Shannon
bridge). B5 is therefore closed for COMPLETABILITY (the statement the infeasibility side
kills, and the stronger reading: since Markov ⟹ completable, the global side also kills
Markov-completability; only the subcover MARKOV-witnesses remain unverified).

**Floor table.** F1 `Equiv.addLeft` on ZMod 2 + `Equiv.sum_comp` for shift-sums:
PRESENT 0.95. F2 Fin-4 case facts (`j₀ ≠ e → j₀ ∈ {e+1,e+2,e+3}`, complement
memberships, `s − s = 0`, `add_sub_cancel_left`): decide/Mathlib 0.95. F3 char-2
cancellation (`CharTwo.add_self_eq_zero` at ZMod 2): PRESENT 0.9. F4
`Finset.eq_univ_iff_forall` for the subset corollary: PRESENT 0.9. Kill = A5 overflow
per item.

**Γ (passes).** Pass 1: full derivation (chart, M-scaling, three-case fiber sums; the
12-case fear collapsed to 3 by keeping the product explicit over `[s, s+1, s+2]`).
Pass 2 (disprove): both equiv-inverse directions checked by hand (char-2 telescopes);
the value-match `(1/2)·M = edgeMass` verified; the e = s+1 case's non-obvious fiber
parameterization (v free, a determined) checked via Fubini order. Pass 3 (audit): the
Markov-scope line above; the statement quantifies subcovers via missing-edge, with the
general-subset corollary making "proper subcover" literal. **R (typing).** C1 T-Bridge
(proof engine); C2 T-Parametric (symbolic in r); C3 T-Prop ×3-case; C4 T-Prop package.
UK-C1: the piSubtypeProd-assembled value-extraction lemmas (four `dif`-evaluations) are
the only new bookkeeping genus; the L0 grammar covers them.

### C5 UPGRADE (same tick): R-Markov is NOT a residual. A4 flagged the hedge; A5 banks it.

**Bet upgraded.** The pre-registered honesty row ("Markov property recorded as residual
R-Markov") was the canonical A4-as-escape-device. Withdrawn. New bet items, banked THIS
tick alongside C1-C4:
- **C5-cl** the constructed path completions are CLASSICAL MARKOV completions w.r.t.
  the path junction tree, in factorization form (Lauritzen, Graphical Models 1996,
  Prop 3.1 / Dawid 1979 CI): both separator identities
  `q(x) * marg_sep = marg_left * marg_right` pointwise, symbolic in r. Ingredients:
  four new marginal-value lemmas (two 1-site: uniform 1/2; two 3-site:
  `(1/2)*M*M`-form), all by the shift-sum engine.
- **C5-q** the diagonal quantum completions are QUANTUM MARKOV completions in the LZ
  sense (arXiv:2605.19453, global Markov property Def via qcmi): both quantum CMIs of
  the relabeled `ofClassical (pathDist)` vanish. Route: entropy bridge
  `Sᵥₙ (ofClassical p) = -Σ p log p` (vendor-gap fill if absent, same class as
  `inner_log_faithful`), diagonal-trace marginal bridges, the Shannon identity
  `H(ABC) + H(sep) = H(left) + H(right)` from C5-cl positivity + log-splitting.
**A (constraints):** three axioms only; no sorry ever; warningAsError; vendor read-only;
cite LZ/Lauritzen/Dawid in docstrings. **M:** the shift-sum elimination engine
(evaluation charts at arities 1/2/3 on complement subtypes + arity-4 on V, if-chain
inverses, NO parity chart needed: derived this pass, replaces the cumulative-sum C1
design). **R:** `Mfun r t`, `pathMass`, `IsMarkovOnPath` (T-Prop), charts (T-Bridge),
entropy bridge (T-Bridge, vendor-gap class). **T:** QJTTwoClique + QuantumMarginal +
QJTOpenProblem greens; the C3 edge-marginal cases double as CI-side inputs.
**K/U.** KK: all C1-C4 mathematics (derived+attacked, 3 passes); C5-cl arithmetic
(derived this pass: CI1 = (1/4)M₁M₂M₃ both sides; CI2 same). KU: vendor state of
{Sᵥₙ def, spectrum_ofClassical, Hₛ API, qcmi def+constituents, cfc/diagonal,
relabel-of-diagonal} = THE floor batch below. UK: whether qcmi's marginal-extraction
shape (traceLeft/traceRight on nested products) composes with our Pi-relabeling without
an assoc-seam (the L0 instance-path-seam law says: expect exact/congrArg moves, not rw).
**Kill protocol: NONE.** Bank-or-build: any missing vendor piece is built in-kernel this
tick (A5: the answer to absence is structure).

### C1-C5 VERDICT ROUND, 2026-07-08 (the same-turn bank; zero residuals)

**Kernel state.** QJTOpenProblem.lean now 1834 lines, green under warningAsError;
barrel green; zero sorry; zero native_decide; ALL headline declarations audit to
exactly [propext, Classical.choice, Quot.sound], including the vendored
`Sᵥₙ_ofClassical` dependency (independently audited clean before use).

**Bet outcomes. ALL WON, banked this tick:**
- **C1 WON (redesigned mid-tick, recorded):** the cumulative-sum chart was replaced by
  evaluation charts (`quadChart`, `complChart1/2/3`) with if-chain inverses; no
  characteristic-2 telescoping anywhere. The front-load's Γ recorded the redesign
  before the write.
- **C2 WON:** `pathMass`/`pathDist` (junction-tree completion, symbolic in r), sum-1 by
  four shift-sum eliminations (`sum_Mfun_right/left`, the one engine).
- **C3 WON:** `pathDist_marginal` (all three path edges, three chart cases).
- **C4 WON:** `subcover_completableC/Q` (any proper subcover via a missing edge),
  `qjt_not_local` packaged: full support ∧ every-proper-subcover strictly-positive
  Markov completable ∧ no global classical ∧ no global quantum completion.
- **C5-cl WON:** `IsMarkovOnPath` (factorization CI at both separators; Lauritzen 1996
  Prop 3.1 / Dawid 1979) + `pathDist_isMarkov`, via four new separator-marginal value
  lemmas (`pathDist_marg_T3_late/early`, `pathDist_marg_T1_mid/late`).
- **C5-q WON:** the REUSABLE bridge layer: `PDfst/PDsnd`, `relabel_ofClassical`,
  `traceLeft_ofClassical`, `traceRight_ofClassical` (vendor gaps filled, general), and
  the general theorem `qcmi_ofClassical_of_factorization`: strictly positive classical
  CI on A×B×C embeds via ofClassical to vanishing qcmi (LZ Def 2.7 global Markov),
  proof through Sᵥₙ_ofClassical + the Shannon identity H(ABC)+H(B) = H(AB)+H(BC) by
  log-splitting. Applied at both separators: `pathCompletion_qcmi_sep1/sep2`,
  `pathCompletion_quantum_markov`, and the full clause
  `subcover_markov_completable`: every proper subcover admits a completion that is
  strictly positive, classically Markov, AND quantum Markov, while the cycle admits
  none. The locality failure survives every strengthening of the local data.

**A4/A5 ledger.** The R-Markov residual hedge was withdrawn and discharged as C5 (the
A5-response to the A4-flag). One mid-write design substitution (C1) was an engine
choice, not a statement simplification: all banked statements are those bet or
stronger. No sorry fired this tick.

### THE COHOMOLOGICAL INSIGHT (what the completed bank makes exact)

1. **Degree pinned.** Local triviality on every proper subcomplex + no global section
   is the DEFINITION of a nonvanishing first obstruction: before C4, the cycle failure
   could conceivably have hidden a local defect; now the class provably lives on the
   fundamental 1-cycle of the nerve. This is the distribution-stratum sibling of
   ParityFamily's support-stratum degree-irreducibility for hcComb.
2. **hcComb = the Boolean-coefficient shadow.** One F2-holonomy germ (`one_le_disag`:
   twists sum to 1 around the cycle) drives one Čech-1 class realized in a TOWER of
   coefficient systems over the same nerve: F2/possibilistic (PR box, hcComb's
   stratum), real/measure (the smoothed family, pairing value 4(2r−1) − 2 against the
   fundamental cycle), quantum (via the quantization arrow). The support-information
   gap IS the kernel of the change-of-coefficients map real → Boolean: the r-family
   (3/4 < r < 1) is a kernel-verified one-parameter family in that kernel. Support
   classes are discrete; information classes have MODULI (die exactly at the cut
   facet r = 3/4).
3. **Quantization-stability.** The class survives coefficient enrichment all the way
   to quantum states, and Markov-strengthening of local data cannot see it: the tower
   support → distribution → quantum is one Čech complex under change of coefficients,
   with the arrow (B1/B2) making functoriality literal.
4. **Chordality boundary explained.** Acyclic covers = collapsible nerve = H¹-trivial:
   `acyclic_iff_forall_consistent_glues` is exactly local-to-global at trivial H¹, and
   the LZ trace criterion is a 0-dimensional functional, decisive only there.
5. **Honesty row.** The Čech language above is interpretive gloss on kernel-verified
   section-statements; the formal Čech complex with the class as a first-class object
   is the flagship's next rung, now with its acceptance tests banked at TWO strata.

### POST-REVIEW CORRECTION, 2026-07-12 (step-6 reviewer verdict: ISSUES FOUND → fixed)

The ultraconservative reviewer independently reproduced ALL mathematics (from-scratch
Python at r = 7/8 AND r = 0.3, all four j₀: masses, marginals, both separator
factorizations, the Shannon identity, the infeasibility bound), verified formal
faithfulness (E genuinely universal over proper subsets; hfac against the real
marginals; positivity genuinely discharged; both qcmi groupings match the tree),
confirmed all three citations real and well-placed, and audited all 82 declarations
plus vendored dependencies to the three standard axioms. It found four issues, now
fixed:
1. **CRITICAL (caught what my checks missed):** `edgeMass` was missing its `{j : Fin 4}`
   binder. The file was green under `lake env lean` (my compile path all along) because
   that path DOES NOT apply the package's `autoImplicit := false` leanOption; under
   `lake build` (authoritative) the file FAILED with cascading sorry-recovery. The
   previous verdict rounds' "green" claims were made under the permissive path: an
   honest-instrument failure, logged. Fix: the binder added; `lake build` now exit 0
   for file AND barrel; axiom profile re-verified. **Standing rule from this event:
   every bank must be verified with `lake build` (or `lake env lean` with explicit
   `-D autoImplicit=false`), never `lake env lean` alone.**
2. Dangling docstring references (`prBox_fibre_obstruction` — a recorded B3 residual,
   never delivered; `cycleFam`/`cycleFam_not_completable` — wrong names): module
   docstring corrected to name only delivered objects (`edgeDist`,
   `cycleFam_not_completableC/Q`).
3. Barrel layer miscount (twenty-two → twenty-four).
4. Rhetoric softened per critique-2 discipline: the barrel and module docstring now
   state the locality resolution as what is literally proved — a witness family whose
   local passes (full support, consistency, strictly positive classical-Markov and
   quantum-Markov subcover completions) do not imply global completability — refuting
   every sufficient criterion at or below that strength, NOT a formalized quantifier
   over all criteria.
Residuals unchanged and ranked: prBox_fibre_obstruction (B3 plumbing), LA/L2b/L3
typed-Prop proofs, QJT-STAB vocabulary.

---

## CECH-CYCLE FRONT-LOAD, 2026-07-12 (B3 closure + de-glossing the cohomology; written before floors)

**THE BET.** New file `CechCycle.lean` (imports QJTOpenProblem + PRBox), banking:
- **D1 (maximally general prop, typed first):** `completion_gives_section`: over ANY
  sites/values/teams, a classical completion of a family maps to a global section of
  its SUPPORT family (∃ x, ∀ j, restrict x ∈ supp(p j)). The support functor carries
  completions to sections; the banked `no_completionC_of_empty_join` is its
  contrapositive. This is the fundamental boundary stated as a functor law.
- **D2 (B3 closed):** `prBox_fibre_obstruction`: any distribution family on the CHSH
  cover supported inside the PR-box relations has no classical completion (hence no
  quantum, via transport). Bridged to the BANKED possibilistic object
  (`prBox`/`joinFam`, PRBox.lean + Amalgamation.lean vocabulary), not re-derived.
- **D3 (the nerve's H¹, concrete):** `coboundary` (δ⁰ : sites → edge-cochains, the
  cycle nerve has no 2-cells so C¹ = Z¹), `holF2` (the holonomy functional Σ_j t j),
  CECH-1 `holF2_coboundary = 0` (telescope), CECH-2 exactness
  `(∃ x, coboundary x = t) ↔ holF2 t = 0` (im δ = ker hol: this IS the computation
  H¹(cycle nerve; F2) ≅ F2 presented concretely).
- **D4 (support stratum = H¹):** `parity_glues_iff_hol`: the possibilistic parity
  family with twist t glues iff holF2 t = 0. `prBox_no_global_section` becomes the
  evaluation of a nonzero cohomology class (holF2 tw = 1, by decide).
- **D5 (information stratum is H¹-graded):** the facet system: `one_le_disagT`
  (∀ t with hol t = 1, every global config disagrees somewhere: 256-point decide),
  `cycle_bound_gen` (for EVERY nonzero-class representative t, every global law obeys
  Σ_j corrE(t j) ≤ 2), and NON-VACUITY BOTH WAYS: `cycle_bound_fails_of_hol_zero`
  (for hol t = 0 a point-mass completion attains Σ = 4: the bound is genuinely
  class-graded, not universal).
- **D6 (the moduli, exact):** `mixDist` (the one-formula mixture over the
  disagreement-1 and disagreement-3 strata, mass (λ·[disag = 1] + (1−λ)·[disag = 3])/8)
  with marginal law giving edge parameter r = 1/4 + λ/2, and the headline
  `cycleFam_completable_iff`: the smoothed family is completable IFF 1/4 ≤ r ≤ 3/4.
  Forward: BOTH facets (t = tw and its flip t+1̄, both hol-1). Backward: mixDist.
  The information-stratum class has exact moduli; the support stratum sees only the
  r = 1 boundary point. THE GAP IS THE KERNEL OF CHANGE-OF-COEFFICIENTS, now with
  its exact extent kernel-verified.
- **D7 honesty row:** what remains interpretive after this bank: the general-cover
  nerve as a simplicial object and Čech functoriality beyond the 4-cycle (the
  flagship rung). The CYCLE-nerve cohomology itself will be fully concrete: δ, hol,
  exactness, both strata graded by the class, moduli exact. Scope stated in file
  docstring.
- **D8 battery:** decide-instances inhabiting every hypothesis class: holF2 tw = 1;
  t = 0 glues with witness; attainment at hol-0; counts of disagreement strata.
**A:** three axioms; no sorry; warningAsError; AUTHORITATIVE CHECK = lake build (new
standing rule after the binder event); cite Barahona–Mahjoub (cycle inequalities /
cut polytope facets, Math. Prog. 1986), Abramsky–Brandenburger (sheaf-theoretic
contextuality, NJP 2011) for the support-stratum reading, LZ for the completion
problem. **M:** decide on closed F2-statements (≤ 256 points); the shift-sum engine
where sums are symbolic; fiber-count decide-facts for mixDist marginals. **R:**
holF2/coboundary T-Abbrev; CECH-2/3 T-Prop decide-backed (counterdefinition:
cumulative-sum constructive inverse if decide chokes — it will not at 16 points);
cycle_bound_gen T-Parametric over t; mixDist T-Construction; completable_iff T-Prop
(headline). **T:** QJTOpenProblem greens (corrE, cycle_bound-pattern, edgeDist,
IsCompletionC/Q, transport), PRBox/Amalgamation possibilistic stack.
**K/U.** KK: all derivations above (3 passes; the facet-flip r < 1/4 arithmetic and
the 8+8 disagreement-strata counts hand-checked; reviewer's independent Python already
confirmed the strata counts {1:×8, 3:×8}). KU → FLOOR: (i) exact signatures of
prBox/prRel/joinFam/LocalStruct/chshCover and any mem_joinFam lemma; (ii)
ProbDistribution.constant and its coe; (iii) name-clash sweep for
holF2/coboundary/disagT. UK: whether the PRBox carrier encoding matches cyc-teams
literally or needs a translation layer (bridge cost unknown until read). UU: none
identified at this scope. **Kill protocol: NONE (bank-or-build).**
**Noology (Γ):** this tick's inquiry move: re-deriving the facet system as H¹-INDEXED
(t ranges over nonzero-class representatives) rather than tw-specific was the
UK→KU transition produced by trying to DISPROVE "the bound is cohomological" (if it
were, it must fail at hol = 0 — it does, and that failure is D5's second half). The
moduli interval closed both ends is the anti-A4 discipline applied to my own gloss.

### CECH-CYCLE VERDICT ROUND, 2026-07-12 (all bets won; lake build authoritative)

**Kernel state.** CechCycle.lean, 435 lines; `lake build` exit 0 for file AND
25-layer barrel (the authoritative check, per the standing rule); zero sorry; zero
native_decide; all fourteen headline declarations audit to exactly the three
standard axioms.

**Bet outcomes.**
- **D1 WON:** `completion_gives_section`, fully general (any sites/values/teams).
- **D2 WON (B3 residual CLOSED):** `prBox_fibre_obstruction(_quantum)`, routed
  through the BANKED `prBox_no_global_section` via `mem_joinFam` and the rfl-bridge
  `prBox_eq_parityBox` — the fibre obstruction is literally the lift of the banked
  base obstruction, no re-derivation.
- **D3 WON:** `coboundary`/`holF2`/`holF2_coboundary`/`coboundary_range`:
  H¹(cycle nerve; F₂) ≅ F₂ computed in-kernel (im δ = ker hol, both inclusions).
- **D4 WON:** `parityBox_joinFam_empty_iff` (∀ t: empty join ↔ hol t = 1),
  `prBox_class_nonzero`, the re-derivation example, and `parityBox_zero_glues`
  (zero-class side inhabited). Strong contextuality of the PR box IS the evaluation
  of the nonzero class: no longer gloss.
- **D5 WON:** `one_le_disagT` (class-graded sign contradiction, 256-point decide),
  `cycle_bound_gen` (facets indexed by nonzero-class cochains), and the non-vacuity
  of the grading itself: `cycle_bound_fails_of_hol_zero` (zero-class references
  attain 4 via the deterministic section that CECH-2 furnishes). The facet system of
  the cycle marginal polytope = the nonzero H¹ classes: kernel fact.
- **D6 WON (headline):** `mixDist` + `mixDist_marginal` (fiber-count decides:
  3/1-splitting of the disagreement strata over edge configurations) +
  `cycleFam_completable_iff`: completable iff 1/4 ≤ r ≤ 3/4; quantum face
  `cycleFam_completableQ_iff` through the arrow. Battery: the banked 7/8
  non-completability re-derived from the boundary; r = 1/2 completability witnessed.
- **D7 honesty row (standing):** first-class at CYCLE-NERVE scope. The general-cover
  simplicial nerve, its Čech functor over arbitrary covers, and higher degrees remain
  the flagship rung; the file docstring says so. The cohomological reading of hcComb
  beyond the cycle stays labeled interpretation until that rung is built.
- **D8 WON:** every hypothesis class inhabited (both hol-values, both bound regimes,
  both moduli boundary sides).

**The measured boundary, final form.** Over one nerve: Boolean coefficients (support
stratum) see {r = 1}; real coefficients (information stratum) see the class with
moduli, vanishing exactly on [1/4, 3/4]; quantum coefficients see the same moduli
(the arrow). The support/information gap on this family = (3/4, 1) exactly, plus the
mirror (0, 1/4): the kernel of change-of-coefficients, kernel-verified at both ends,
with the r = 1 endpoint being where the class becomes support-visible (the PR box).

---

## CECH-NERVE FRONT-LOAD, 2026-07-12 (the flagship rung: general covers; written before floors)

**THE BET.** New file `CechNerve.lean` (HC layer 26), banking the general-cover Čech
machinery whose 4-cycle shadow is CechCycle.lean, in the architecture of a mature
meta-theory (parent objects first, special cases as derivation theorems, hypotheses
earned by kernel witnesses):
- **N1 (the parent complex, maximally general):** over ANY finite site type ι, ANY
  cover (Finset (Finset ι)), ANY field K: the incidence matrix, the team-sum map
  `δ := M.mulVecLin : (ι → K) →ₗ (↥cover → K)` (the Čech coboundary of the incidence
  complex; for graph covers, literally the simplicial δ⁰ of the nerve), and the even-
  subcover space `cycleSpace := ker (Mᵀ.mulVecLin)` (for graph covers, the cycle space
  of the nerve graph).
- **N2 (the core: H¹ by the Fredholm alternative):** `range δ = {t | ∀ c ∈ cycleSpace,
  c ⬝ᵥ t = 0}` over any field: realizable twists are exactly the cycle-orthogonal ones.
  Route: adjointness (⊆, via Matrix.dotProduct_mulVec) + dimension count (rank-nullity,
  rank Mᵀ = rank M, perfect dotProduct pairing to the dual, finrank of the annihilator)
  + Submodule.eq_of_le_of_finrank_eq. Counterdefinition (swap on floor-failure):
  range_dualMap_eq_dualAnnihilator_ker route; second fallback: bespoke elimination à la
  AffineEngine (floor decides; consume, never duplicate).
- **N3 (support stratum, general covers):** `parity_glues_iff_orthogonal`: the twisted
  parity family over ANY cover has a global section iff its twist annihilates the even-
  subcover space — CECH-3 at full generality; plus the joinFam-form bridge through
  the general parity support `prRelG` (the PRBox `prRel` is its Fin-4 instance).
- **N4 (information stratum, general covers):** general `corrT`/pullback (public
  general fiber-sum replica), the graded facet system `evenSubcover_bound`: for every
  even subcover c and twist with ODD pairing, every global law obeys
  `∑_{T ∈ supp c} corrT ≤ card (supp c) − 2` (Barahona–Mahjoub cycle inequalities at
  hypergraph generality; pointwise core: ⟨c, δx⟩ = 0 forces an odd, hence positive,
  disagreement count). Sharpness: for twists in range δ the deterministic section
  attains card (supp c) (`bound_fails`-general).
- **N5 (derivation theorems = the instances):** (a) the 4-cycle: cycleSpace = {0, 1̄}
  (decide), and CechCycle's `coboundary_range` re-derived from N2 — the banked H¹
  computation becomes an instance of the flagship object; (b) the Specker triangle:
  all-ones is an even subcover, the odd twist pairs to 1, no gluing — the
  HigherObstruction acceptance test discharged cohomologically; (c) the n-cycle for
  all n ≥ 3 (T-Parametric): cycleSpace = {0, all-ones} by hand (constancy propagation),
  gluing iff Σ t = 0 — the arity-n schema.
- **N6 (the functor leg, honest scope):** equivariance under site-equivalences
  (verdict transport by conjugation) and subcover-stability of the facet system
  (extension-by-zero of even subcovers). The full categorical Čech functor over
  non-invertible cover morphisms and higher degrees: stated as the NEXT rung in the
  docstring, not claimed.
**A:** three axioms; no sorry; lake build authoritative; cite Vorob'ev 1962,
Abramsky–Brandenburger NJP 2011 (+ Abramsky–Mansfield–Barbosa QPL 2011 (EPTCS 95), the Čech
cohomology of contextuality — the interpretation our incidence presentation
computes), Barahona–Mahjoub 1986, and Mathlib provenance for every duality lemma.
**M:** Matrix/LinearMap algebra for N2; Finset sums for bridges; ZMod-2 parity
counting for N4; decide only at finite instances. **R:** M/δ/cycleSpace T-Abbrev;
N2/N3/N4 T-Prop (N2 the core); prRelG T-Parametric; instances T-Bridge/T-NUM;
equivariance T-Bridge. **T:** CechCycle (the shadow to recover), PRBox/Amalgamation
(joinFam vocabulary), AffineEngine (possible core overlap — floor before writing),
QJTOpenProblem (corrE-pattern, constant-distribution sharpness pattern).
**K/U.** KK: all derivations (3 passes: the Fredholm presentation; the odd-count
pointwise core generalizes verbatim; n-cycle kernel computation). KU → FLOOR:
(i) exact Mathlib names {Matrix.rank_transpose, Matrix.rank via mulVecLin,
Subspace.finrank_add_finrank_dualAnnihilator_eq or variant, Basis.toDualEquiv,
LinearMap.finrank_range_add_finrank_ker, Submodule.eq_of_le_of_finrank_eq,
Matrix.dotProduct_mulVec, Finset.sum_coe_sort}; (ii) AffineEngine's Gaussian core
form (consume-vs-present decision); (iii) ZMod 2 field instance. UK: whether the
annihilator-dimension lemma exists in the Subspace or the BilinForm library at this
pin (two names to try). UU: none at this scope. **Kill: NONE (bank-or-build; the
counterdefinition chain for N2 is three-deep).**
**Noology (Γ):** the inquiry move of this tick: recognizing that the "simplicial
nerve" our honesty rows deferred is, for THIS coefficient system, the incidence
complex — the Čech functor's degree-1 data is a linear map, and H¹-computation is
the Fredholm alternative. The attached WMSpec corpus supplied the architectural
grammar (parent → derivation → boundary witness), not the mathematics.

### CECH-NERVE VERDICT ROUND, 2026-07-12 (lake build authoritative)

**Kernel state.** CechNerve.lean, 427 lines; `lake build` exit 0 for file and 26-layer
barrel; zero sorry; zero native_decide; all nine headline declarations audit to exactly
the three standard axioms.

**Bet outcomes.**
- **N1/N2 WON, amended per the pre-registered floor decision:** the floor found the
  affine engine's `exists_parity_solution` + `parityOn_xorSum` + `xorSumL_eq_xorSum`
  ARE the duality core in symmetric-difference form; per the front-load's
  "consume, never duplicate", N2 is banked as the Čech PRESENTATION of the banked
  Gaussian elimination (`exists_section_iff_even_orthogonal`, over ZMod 2, arbitrary
  site types and covers). The field-general Matrix/finrank presentation is recorded as
  a named next rung (docstring + here), not silently dropped.
- **N3 WON:** `parityFamG_joinFam_nonempty_iff` — the support stratum is the degree-1
  obstruction over EVERY cover; `prRelG`/`parityFamG` generalize the PRBox vocabulary;
  `restrict_parity_general` bridges to the LocalStruct grammar.
- **N4 WON:** `corrT`/`corrT_marginal` (general-team pullback), `evenSubcover_bound`
  (cycle inequalities for every even subcover with odd pairing; pointwise core: the
  telescoped parity forces an odd disagreement count), `evenSubcover_bound_attained`
  (sharp at realizable twists). Facets quantify over D alone: cover-enlargement
  stability is automatic.
- **N5 WON, one route amendment:** (a) 4-cycle `chshCover_section_iff` re-derives the
  banked holonomy criterion: forward via N2 at the full even subcover, backward via
  the constructive n-cycle section. The bet's cycle-space CLASSIFICATION decide
  (`∀ D ∈ powerset, xorSum D = ∅ → D = ∅ ∨ D = full`) hit a genuine kernel-evaluation
  wall (elaborator whnf timeout at 200k heartbeats; `decide +kernel` still grinding
  at 7+ minutes: killed) — an A5 route-substitution, not a statement change: both
  directions of the instance are kernel-checked; the classification statement itself
  is subsumed and NOT separately banked. (b) Specker `specker_odd_no_section`: the
  HigherObstruction acceptance test discharged as a cohomology evaluation.
  (c) `nCycle_section_iff` for every `Fin (n+2)`: constructive prefix-sum sections;
  the holonomy criterion at every arity.
- **N6 WON (scoped):** `section_iff_of_equiv` (site-equivalence transport);
  subcover-stability automatic by the D-only facet formulation. Next rungs named:
  non-invertible cover morphisms, degrees ≥ 2, field-general coefficients.
**A4/A5 ledger.** One sorry-in-draft caught in the heredoc BEFORE write (list-sum
bridge gap); the draft was refused and the bridge built as
`sum_toFinset_of_nodup` (8th firing class, logged). The two amendments above are
route/presentation decisions pre-registered in the front-load, with statements
delivered at or above bet strength.
**The discovered structure (the directive's target).** The meta-theory now has the
shape the attached identification corpus exemplifies: parent object (incidence
complex over arbitrary covers) → computation by a banked engine (Gaussian core) →
derivation instances (4-cycle, Specker, n-cycle) each earning its hypothesis —
with BOTH strata of the support/information boundary graded by ONE object (the
even-subcover pairing): possibilistic gluing = pairing-orthogonality;
distributional facets = odd-pairing inequalities, sharp exactly at realizable
twists. The boundary being measured is now a single kernel-object evaluated in two
coefficient systems, over every finite cover.

---

## CECH-K FRONT-LOAD, 2026-07-12 (field-general coefficients; written before floors)

**THE BET.** New file `CechK.lean` (HC layer 27):
- **K1 (maximally general prop, typed first):** the Fredholm alternative for an
  ARBITRARY matrix over an ARBITRARY field — nothing incidence-specific:
  `range M.mulVecLin = orthogonal of ker Mᵀ.mulVecLin` under the dot-product bilinear
  form; usable mem-form: `y ∈ range M ↔ ∀ z, Mᵀz = 0 → z ⬝ᵥ y = 0`. Route (primary):
  adjointness (⊆) + dimension count: nondegeneracy of the dot form, reflexive-form
  orthogonal-finrank lemma, rank-nullity, `Matrix.rank_transpose`,
  `Submodule.eq_of_le_of_finrank_le`. Counterdefinition chain (floor decides):
  (b) dualAnnihilator route via `Basis.toDualEquiv` +
  `Subspace.finrank_add_finrank_dualAnnihilator_eq`; (c) bespoke basis-extension.
- **K2 (the incidence instance):** `incidenceM cover : Matrix ↥cover ι K` (0/1), entry
  calculus (`mulVec` = team sums, `transpose-mulVec` = site-incidence sums), and the
  field-general support-stratum criterion `incidence_section_iff_K`: prescribed team
  sums over K are realizable iff orthogonal to every K-cocycle of the transpose.
- **K3 (the ZMod-2 cross-validation):** the cochain/subset dictionary (indicator ↔
  support through `mem_xorSum`), and the derivation theorem: the K1-instance at
  `K := ZMod 2` RECOVERS the banked engine-form `exists_section_iff_even_orthogonal`
  — the rank argument and the Gaussian elimination arrive at one criterion from
  independent proofs: a genuine two-engine cross-validation, stated as a theorem.
**A:** three axioms; no sorry; lake build authoritative; cite: Fredholm alternative
(finite-dimensional folklore; Strang's four-subspaces presentation), Mathlib
provenance per lemma in docstrings; incidence/nerve reading per CechNerve. **M:**
Matrix/LinearMap/BilinForm algebra; Finset entry calculus; ZMod-2 counting for K3.
**R:** dotB T-Abbrev (mk₂); K1 T-Prop Submodule-eq + mem-corollary; incidenceM
T-Abbrev; K2/K3 T-Bridge/T-Prop. **T:** CechNerve (the target of the
cross-validation), AffineEngine (the other engine), VorobevConverse (mem_xorSum).
**K/U.** KK: the dimension-count derivation (3 passes; orthogonal-orientation checked
against A's definition; nondegeneracy via single-vectors; adjointness via
dotProduct_mulVec). KU → FLOOR: exact names/forms of {BilinForm.orthogonal +
finrank_add_finrank_orthogonal (+ hypothesis: IsRefl? Nondegenerate?),
Subspace.finrank_add_finrank_dualAnnihilator_eq (plan B), Matrix.rank_transpose,
Matrix.rank def-bridge, LinearMap.finrank_range_add_finrank_ker,
Submodule.eq_of_le_of_finrank_le, dotProduct_single-family, Finset.sum_ite_mem,
mem_xorSum exact form}. UK: whether the orthogonal-finrank lemma's hypothesis
packaging (radical-form vs nondegenerate-form) matches; the ZMod-2
indicator-dictionary friction. UU: none at scope. **Kill: NONE (three-deep chain).**
**Noology (Γ):** the inquiry move: recognizing the field-general rung's parent is a
pure matrix theorem with NO Čech vocabulary — maximal generality means the flagship
consumes it as an instance, and the ZMod-2 corner becomes a two-engine consistency
theorem rather than a re-proof. Reviewer note: the CechNerve review was lost at
process exit; this tick's reviewer covers BOTH files.

### CECH-K VERDICT ROUND, 2026-07-12 (lake build authoritative)

**Kernel state.** CechK.lean; `lake build` exit 0 for file and 27-layer barrel; zero
sorry; zero native_decide; all seven headline declarations audit to exactly the three
standard axioms.

**Bet outcomes. ALL WON.**
- **K1 WON:** the Fredholm alternative for arbitrary matrices over arbitrary fields
  (`range_mulVecLin_eq_orthogonal_ker_transpose` + membership + solvability forms),
  by the primary route exactly as floored: `dotB` (mk₂), `dotB_nondegenerate` (both
  separating components via basis vectors — the floor revealed Nondegenerate is the
  CONJUNCTION SeparatingLeft ∧ SeparatingRight; both proved),
  `LinearMap.BilinForm.finrank_orthogonal`, rank-nullity, `Matrix.rank_transpose`,
  `Submodule.eq_of_le_of_finrank_le`. No counterdefinition needed.
- **K2 WON:** `incidenceM` + entry calculus + `incidence_section_iff_K`: the
  field-general support-stratum criterion over every cover.
- **K3 WON, route as pre-registered in typing:** `even_orthogonal_iff_cocycle_
  orthogonal` — the two-engine cross-validation, proved by CHAINING the Gaussian
  engine and the rank engine through the section space; the explicit
  indicator-dictionary is absorbed into the equivalence (noted in the docstring as
  the alternative direct proof). The consistency of two independent computations of
  the degree-1 obstruction is now a theorem.
**Reviewer note:** the CechNerve review was lost at process exit before completing;
this tick's reviewer brief covers BOTH CechNerve.lean and CechK.lean.
**The tower now:** possibilistic (Boolean) stratum ← ZMod-2 linear stratum
(two engines, cross-validated) ← field-general linear stratum (Fredholm) — one
incidence complex, three coefficient levels, with the real-coefficient facet system
(CechNerve N4) and the exact moduli (CechCycle) sitting over the same nerve. Next
rungs: cover morphisms, degrees ≥ 2, presheaf coefficients.

### POST-REVIEW CORRECTION, 2026-07-12 (dual-file reviewer: CLEAN + one citation fix)

The dual-file reviewer (CechNerve + CechK, the former's first review having been lost
at process exit) independently reproduced: three cold `lake build`s; every declaration
in both files axiom-probed (including privates) to the standard three; the mathematics
from scratch (400 random covers with three-way criterion agreement; 300 random
matrices over GF(2)/GF(3)/GF(5)/ℚ for the Fredholm alternative; 301 facet-bound and
301 attainment checks; n-cycles 5-8 with the prefix-sum witness reconstructed;
Specker exhaustively); textual engine-consumption and engine-chaining; orientation
and nondegeneracy conventions against Mathlib source; non-vacuity witnesses incl. a
concrete nonsquare K1 instance; all docstrings and both verdict rounds against disk.
ONE actionable finding, fixed: Abramsky-Mansfield-Barbosa venue corrected from
"CSL 2011" to QPL 2011 (EPTCS 95; arXiv:1111.3620) in CechNerve.lean and this file.
Barrel rebuilt green after the fix.
