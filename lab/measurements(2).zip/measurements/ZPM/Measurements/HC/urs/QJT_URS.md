
---

## KEYSTONE FRONT-LOAD, 2026-07-12 (the thesis-level statements; assembly of banked parts)

**The critique discharged:** the machinery lives in the proofs but not the statements;
qjt_not_local reads as a QM counterexample. The eidometry corpus puts the thesis IN
the theorem statements. **THE BET** (`Keystone.lean`, layer 28; every component
banked+reviewed, so this is statement-engineering, the R-move the critique demands):
- **X1** `completability_not_support_functional`: two families on the SAME cover with
  IDENTICAL supports (r = 1/2 and r = 7/8, both full) and OPPOSITE completability —
  the verdict is not a functional of the support family. The completion-arc analogue
  of eidometry's `parity_boundary`/`support_moves_width`.
- **X2** `completability_class_functional`: the verdict IS a functional of the class
  pairing — completable iff |Σⱼ corrE(tw j)| ≤ 2, the evaluation of the family against
  the H¹ generator. Ignorance about global structure is support-blind yet
  cohomology-structured.
- **X3** `three_strata_one_class`: one conjunction: possibilistic verdict = class
  vanishing (∀ twists); distributional verdict = class moduli (∀ r); quantum verdict
  = same moduli (∀ r). One class, three coefficient systems, one theorem.
**A:** three axioms; lake build; no new mathematics claimed — the docstrings carry the
programme thesis (support/structure; ignorance about structure; structure of
ignorance) in the eidometry module-doc style. **K/U:** all KK (assembly); UK: none;
floors: none needed (all names banked this session). Kill: none.

### KEYSTONE VERDICT ROUND, 2026-07-12

X1/X2/X3 ALL WON, first compile; barrel at 28 green (lake build); zero sorry; all four
declarations audit to the three standard axioms. The critique is discharged at the
statement level: the completion arc now carries its thesis in theorem statements
(support-blindness, cohomology-structure, one-class-three-strata), mirroring the
identification arc's keystone discipline. Research fan (3 sonnet agents) launched on
the three prior-art strata; verdicts pending. The paper's framing follows the keystone:
the LZ resolution is the quantum-stratum shadow of the support/structure separation,
not a standalone QM result.

### NOVELTY LEDGER, incremental (fan findings, verified leg), 2026-07-12

Verified by the classical-stratum sweep's adversarial leg (identifiers checked):
1. **Vorob'ev 1962 already contains the cycle obstruction AT THE SUPPORT STRATUM.**
   Via Atserias-Kolaitis arXiv:2009.09488 (pp. 34-35): Vorob'ev's Theorem 2.2 (1962,
   p. 152) identifies the forbidden families {G_n} and {Z_n}, with Z_n literally the
   chordless n-cycle (n ≥ 4; teams {A_i, A_{i+1}}). His witnesses are DEGENERATE:
   0/1 indicator relations (equality constraints with one inequality), i.e. exactly
   the possibilistic stratum our capstone formalizes. CONSEQUENCE for the claim
   boundary: the classical cycle counterexample as such is Vorob'ev's own; what is
   NOT in Vorob'ev: strictly positive (support-blind) witnesses, the
   Markov-strengthened subcover clause, the exact moduli interval, the quantum
   stratum, and machine-checking. Our keystone framing (support-blindness) is
   therefore not only philosophically right but historically exact: prior art lives
   at the support stratum; the fibre stratum is ours to stake.
2. **The PR-box = Z_4 identification is Atserias-Kolaitis 2020, not Vorob'ev.**
   arXiv:2009.09488 p. 3 states the PR-box support is the 4-cycle case of THEIR
   semiring construction. The paper must cite: Vorob'ev 1962 Thm 2.2 (cycle
   obstruction), A-K 2020 (PR-box link + semiring generalization), alongside the
   Abramsky-Brandenburger strong-contextuality reading. ACTION ITEM: read
   2009.09488 closely before drafting; their semiring generalization is the nearest
   classical neighbor and its exact scope (degenerate vs strictly positive
   witnesses; any thresholds) must be pinned. Preliminary reading of the quoted
   construction says their witnesses are also degenerate-support style.
3. **Barrett disambiguation:** noisy-box threshold cite is Barrett-Linden-Massar-
   Pironio-Popescu-Roberts, PRA 71, 022101 (2005), DOI 10.1103/PhysRevA.71.022101
   (NOT the 2002 memory-loophole paper, PRA 66, 042111).
4. **Mathlib formalization territory:** Mathlib.Algebra.Star.CHSH contains only the
   algebraic CHSH identity, the commutative ≤ 2 bound, and Tsirelson ≤ 2√2 in
   star-monoid form. No PR box, no marginal problem, no Vorob'ev, no nonsignaling
   or marginal polytope. The formalization component of our claim is unclaimed
   territory (subject to the wider sweep still running).
Pending: classical-stratum final synthesis; LZ-adjacency (resumed); cohomology
stratum; Keystone reviewer.

### NOVELTY LEDGER, incremental 2 (cohomology-stratum verdict), 2026-07-12

Per-component, source-verified by the sweep (full texts read for the AB-school core):
- **Facet-indexing by cohomology classes: NOT FOUND anywhere** (AB 2011; AMB QPL 2011;
  ABKLM CSL 2015; Carù 2017/2018; Okay-Raussendorf line; Okay-Kharoof-Ipek 2023;
  Aasnæss 2020/2022). All prior cohomology in the school is a gluing DETECTOR on the
  possibilistic collapse, sufficient-not-necessary by the authors' own statement
  (Hardy model counterexample). Our `cycle_bound_gen`/`evenSubcover_bound` facet
  grading is the cleanest novelty candidate.
- **Three-strata-one-class + transport: NOT FOUND.** The literature keeps
  possibilistic cohomology, LP-based contextual fraction, and quantum realizability
  as separate tools. Caveat recorded: the bare existence of a quantum stratum is
  AB-standard; the staked novelty is the unifying transport and the single class.
- **The interval [1/4, 3/4]: textbook number, both flags RESOLVED against our kernel.**
  (i) Parameterization: our r is per-context constraint-satisfaction probability
  (mass r/2 on each of the two twist-agreeing configs), i.e. exactly the
  game-success parameterization p, whose classical bound is 3/4 with mirror 1/4.
  (ii) Direction: our `cycleFam_completable_iff` is completable INSIDE [1/4, 3/4],
  matching the convexity-forced geometry (noncontextual inside, contextual tails);
  independently confirmed earlier by the reviewer's LP over the full r-grid. The
  claim is the cohomological-moduli FRAMING and the kernel proof, never the number.
  Contextual-fraction relative: our interval = the zero set of CF(p) = max(0, 4p−3,
  1−4p) (ABM PRL 119, 050504 (2017) Thm 1 + Brunner et al. RMP 86, 419 (2014)).
- **Two-engine Fredholm packaging over general covers: NOT FOUND** (nearest: Carù's
  snake-lemma invariant; no cross-check engine anywhere). General covers per se ARE
  prior (Carù; Okay-Kharoof-Ipek): cover-generality alone must not be claimed.
- **Machine-checking: NOT FOUND** for sheaf contextuality, Čech obstructions, or the
  contextual fraction, across five ecosystems. Adjacent: KS in HOL Light (Harrison
  2005), CHSH + Tsirelson in Isabelle AFP (Echenim et al.), SAT-certified KS bounds.
  A DeepMind formal-conjectures issue lists Bell inequalities as an OPEN target.
- **NEW TIER-1 ADJACENCY: Ikeda, arXiv:2511.04326 (Nov 2025, rev. Jan 2026),
  "Quantum Entanglement as a Cohomological Obstruction": a Čech presheaf of DENSITY
  OPERATORS with partial-trace restrictions and gluing obstructions.** The sweep
  assumed our quantum stratum is empirical-model realizability; it is NOT: our
  IsCompletionQ is density-operator marginal gluing (ptraceS prescriptions), i.e.
  exactly Ikeda's problem class. Ikeda is direct, dated prior art for the
  cohomological FRAMING of the quantum stratum and must be read closely and
  distinguished (he has no LZ problem, no Markov completions, no locality
  impossibility, no thresholds, no classical transport, no machine-checking, on the
  sweep's reading; verify by close read before drafting). ACTION ITEM: close-read
  2511.04326 alongside Atserias-Kolaitis 2009.09488 before the manuscript.
- Name corrections for the bibliography: Giovanni Carù; Sivert Aasnæss.

### KEYSTONE REVIEW VERDICT, 2026-07-12: CLEAN (all five items)

Reviewer independently: cold-built file+barrel under strict settings; axiom-probed all
four declarations; reproduced the witness pair by LP (feasible at r = 1/2, infeasible
at 7/8, both full-support); verified the class-functional criterion on a 100k-grid and
corrE = 2r−1 on 2000 random r; brute-forced all 16 possibilistic verdicts; confirmed
the eidometry cross-references are REAL (TransformKeystone:12, parity_boundary at
TransformOrthogonality:105) and that every docstring attributes the mathematics to the
layers below. One stylistic note (the "same class" phrasing across the ∀t-leg and the
tw-fixed legs): docstring clarified to name the H¹ ≅ F₂ identification explicitly;
barrel rebuilt green. Fan status: cohomology verdict banked; classical synthesis and
LZ-adjacency still running.

### NOVELTY LEDGER, incremental 3 (LZ-adjacency verdict), 2026-07-12

- **v2 (2026-06-30) does NOT touch the open problem** (rhetorical rewording only;
  quote banked: "even in the classical situation there is no simple condition for
  M(R) to be non-empty unless A is the set of cliques of a chordal graph"). v2 adds
  the intersection property Prop 2.5 (settles a Leifer-Poulin 2008 question) and a
  CHORDAL 7-qubit example. All theorems remain two-clique/chordal.
- **ZERO citing works** (Semantic Scholar, INSPIRE, ADS, arXiv full-text; Scholar
  ambiguous-at-zero flagged).
- **Adjacency clean**: Leifer-Poulin 0708.1337, Brown-Poulin 1206.0755 (Gibbs
  factorization axis, not completion), Poulin-Hastings 1012.2050, Liu
  quant-ph/0604166 (QMA-completeness: the complementary HARDNESS statement; cite
  alongside our LOCALITY impossibility as different axes), Kato-Brandao 1609.06636.
- **Fine 1982 (PRL 48, 291; JMP 23, 1306) anchors the classical 4-cycle**: CHSH
  necessary AND sufficient for a global joint. Our classical interval must be
  presented as machine-checked Fine-corollary. Araujo et al. PRA 88, 022118 (2013)
  for n-cycle polytopes. Zhao-Yu arXiv:2604.03884 (Lean CHSH rigidity): disjoint.
- **VERDICT: the claimed result appears nowhere in full or substantial part.** Ours
  to stake: the quantum witness (subcover quantum-Markov completions + global
  impossibility), the joint statement in LZ's density-operator setting, the
  machine-checking, and the base-measurement framing per the realignment.
- Ambiguity flags: Scholar zero unconfirmed; possible unpublished GitHub Lean
  contextuality code; Chen 2605.02877 full text unscanned.
