# QUANTUM_TOWER_URS — the three-level gluing tower and the open-problem frontier

**Problem (one line).** Bank the classical–quantum–no-signaling gluing tower over covers,
and, under the PI's explicit challenge ("open QM problems we solve with HC, not
reinterpret known ones"), separate what is formalization-first from what is genuinely
OPEN, then develop the open directions into attackable statements.

**Started 2026-07-07. Depends on: discrete Vorob'ev stack [KV], PRBox.lean [KV], affine
direction-presheaf complex [NUM], entropy junction-tree identity [NUM], QuantumInfo build
(in progress, Sonnet background agent; sorry-quarantine policy: sorried vendor decls are
recorded do-not-use; axiom taint fine).**

---

## Object axis (γ)

### The tower (the banking layer — honest status tags on every law)

| Law | Statement | Expected verdict | Honest novelty status |
|---|---|---|---|
| T1 (classical wall) | obstruction ⟺ cover cyclicity; PR box strongly contextual; acyclic Bell path glues everything | **KV, DONE** | Vorob'ev 1962 content; FORMALIZATION FIRST, not open |
| T2a (diag transfer) | every classical non-gluing witness lifts: diagonal embedding gives pairwise-compatible quantum marginals with no global state, on every cyclic cover | TRUE, elementary | folklore in QMP literature; formalization first ONLY |
| T2b (monogamy witness) | on the acyclic 2-chain, quantum consistency does NOT force gluing (maximally entangled pair, purity ⟹ product) | TRUE, elementary | textbook monogamy; formalization first ONLY |
| T3 (no-signaling wall) | PR box marks the outer wall [KV]; Tsirelson 2√2 the middle wall | Tsirelson: TRUE, known 1980 | CORRECTED 2026-07-07: a proof-assistant formalization EXISTS (Echenim–Mhalla, Isabelle/HOL, arXiv:2306.12535, J. Autom. Reasoning). A Lean port would be first-in-Lean only. NOT open |
| **VERDICT ON THE PI'S CHALLENGE** | T1/T2a/T2b/T3 are ELEMENTARY or KNOWN. Their value is substrate + kernel firsts + the tower FRAME. None is an open QM problem. | — | conceded up front |

### The open frontier (the actual targets — what the tower is substrate FOR)

**OP1 — The quantum Vorob'ev problem (the field's own question, asked quantumly).**
Classical [KV]: pairwise consistency forces gluing ⟺ the cover is acyclic. Quantum: for
WHICH covers does pairwise consistency of density-matrix marginals force a global state?
T2b shows acyclicity is not sufficient. Candidate law **QV**: the quantum Vorob'ev class
is exactly the covers with no genuine overlap (every pairwise intersection empty, or
teams nested), i.e., DEGENERATE. Sub-questions: (i) is QV known/published anywhere?
(novelty probe required — the contextuality literature cites Vorob'ev for the classical
class; the quantum-marginal literature studies complexity, not the cover
characterization); (ii) proof route: generalize the monogamy witness to ANY two teams
with nonempty symmetric-difference overlap; (iii) the REFINED quantum question, since the
raw class is likely degenerate: characterize covers where quantum consistency + exact
quantum Markov conditions (vanishing CMI, Hayden–Jozsa–Petz–Winter/Petz recovery) force
gluing — the quantum junction-tree theorem. On trees this is HJPW-known; the CHARACTERIZATION
over general covers appears open.

**OP2 — The entropic marginal cone contact.** Our [NUM] identity (log₂|join| = ΣH(nodes)
− ΣH(edges) on junction trees) is the classical polymatroid/Shannon-cone base case. The
quantum entropy cone (which von Neumann entropy vectors are achievable; existence of
non-von-Neumann inequalities for n ≥ 4 parties) is FAMOUSLY OPEN. Attackable contact: the
COVER-RELATIVE entropy cone — entropies indexed by a cover's teams rather than the full
powerset, with the junction-tree identity as the exactness locus. Candidate law **EC**:
on acyclic covers the classical cover-relative entropy cone is exactly cut out by
submodularity + the junction-tree equality (kernel-checkable in the finite-support
setting we own); the quantum analog on the 2-chain is cut out by SSA + ?? — where the ??
is the open content. QuantumInfo has SSA proved: the substrate for asking this in the
kernel exists.

**OP3 — Completeness of the cohomological contextuality obstruction.** AMB-lineage
cohomology gives SUFFICIENT conditions for contextuality with known false positives in
general. Our affine complex [NUM] law (a) — glue ⟺ mismatch class vanishes — is a
COMPLETENESS theorem on the affine subclass. Novelty probe required: is affine-class
completeness already in Abramsky–Barbosa–Kishida–Lal–Mansfield (2015) or successors
(AvN arguments, linear-system games)? If yes: our contribution is the kernel proof +
the direction-presheaf formulation. If no or only partially: the completeness
CHARACTERIZATION (for which coefficient presheaves / system classes is Čech H¹ complete?)
is an open question we are positioned to attack, because we own both the complete affine
case and the classical set-valued case where completeness provably fails (which witness?
— derive one: a non-glueable non-affine family with vanishing affine-shadow class).

**OP4 — The quantum tier of hcComb (the graded question).** The tower is qualitative
(glue/no-glue). The field's measure is graded. Quantum candidate grading at the 2-team
base: minimal extension defect (how far marginal-compatibility fails, e.g. in trace
distance or relative entropy to the compatible set) vs our hcComb. Is there a quantum
hcComb with a five-way-style equivalence? Genuinely open, high risk, high alignment;
needs OP1/OP2 structure first.

### KK (relevant, banked)
Classical stack [KV]; PR box + Bell path [KV]; affine complex + entropy identity [NUM];
QuantumInfo API surface (MState, traceLeft/Right bipartite only, prod, pinching CPTP,
purity/spectrum, SSA, DPI, relative entropy, POVM, separability); pins identical
(v4.31.0, fabf563a); NO team-indexed partial trace exists (our bridge to build); NO
Bell/CHSH/Tsirelson/marginal-compatibility content exists in QuantumInfo.

### KU (askable now)
QV novelty + truth; EC cover-relative formulation; OP3 completeness literature status;
ptraceS presheaf laws (quantum projS_image_restrict₂ analog — expected TRUE, routine);
diag∘ptrace = classical-marginal∘diag (expected TRUE, 10-line); whether QuantumInfo's
slice is sorry-clean (builder audit pending — quarantine list gates all of this).

### UK (pressure, articulated)
The tower frame suggests the hidden channel has TIERED capacity: possibilistic ⊂ quantum
⊂ no-signaling, with the field's grading question living BETWEEN walls (OP4). The
junction-tree entropy identity smells like the shadow of a single tiered statement
(classical H, quantum S, with CMI = 0 as the quantum flatness condition). Unarticulated:
the right morphism between the affine H¹ and the quantum obstruction.

---

## Agent axis (Γ) — handed to the interrogation workflow

**Will snapshot:** rigor over speed; A4 review-only, A5 the only resolution; no candidate
banked without a verifier; novelty claims require primary-source probes under the
anti-vacuity rule (generic resemblance = non-finding); the PI's challenge is the standing
adversarial frame: "is this OPEN, or elementary?" must be answered per law, in writing,
with the elementary answer CONCEDED not spun.

**Verifiers available:** Lean kernel (classical tier now; quantum tier post-build);
exact-arithmetic computation batteries (the [NUM] protocol, probe + independent
adversarial re-implementation); primary-source literature probes; the quarantine list
from the builder audit.

**What the workflow must produce:** per-law interrogation verdicts (open vs elementary vs
formalization-first, with citations where known); the three open directions (OP1, OP2,
OP3) each developed into: precise statement candidates, what HC machinery contributes
BEYOND the known literature, the first genuinely new lemma reachable, proof-plan sketch,
and kill criteria. Structured to be consolidated back into this URS.

---

## OP1 DEVELOPMENT (2026-07-07, derivation agent) — the quantum Vorob'ev problem

**Correction to candidate QV.** The naive candidate ("empty or nested") is WRONG-BY-OMISSION.
The correct degeneracy predicate is LAMINAR: any two teams are nested OR disjoint. The witness
triggers EXACTLY when a pair T,T' CROSSES, i.e. all three of T∖T', T∩T', T'∖T are nonempty.
Laminar ⟺ no crossing pair. (The naive "nested or empty" IS laminarity pairwise, so it is not
so much wrong as under-named; the operative concept is the laminar/crossing dichotomy, and the
sharp trigger is the three-part nonemptiness, not merely "genuine overlap".)

**Candidate law QV (corrected).** The quantum Vorob'ev class = LAMINAR covers. Two directions:
- (⊆, the WITNESS, mostly derived): any crossing pair yields a pairwise-consistent quantum
  family (MES across the a0–b0 boundary vs MES across b0–c0, maximally mixed elsewhere; both
  overlap-marginals = uniform_B, so consistent) with no global state (a0b0 pure ⟹ global product
  across that cut ⟹ b0c0 marginal separable, contradicting entangled MES(b0c0)). Elementary
  content (monogamy); the COVER-LEVEL characterization is the new packaging.
- (⊇, positive, elementary): laminar ⟹ gluing by tensoring over disjoint root teams, each root
  dominating its nested descendants as marginals (forced by pairwise consistency of nested pairs).

**Resolves the T2b tension.** The 2-chain {a,b},{b,c} is ACYCLIC but CROSSES (not laminar), so it
sits in the non-gluing region: laminar ⊊ acyclic. "Acyclicity insufficient" = acyclic permits
crossings. The quantum wall moves inward from cyclic (classical) to crossing (quantum).

**E5 (does a covering super-team restore gluing?) — RESOLVED NO.** A team T'' ⊇ T∪T' that is
pairwise-consistent with the witness would, restricted to T∪T', BE a global state for {T,T'},
contradicting non-gluing. So no consistent T'' exists; adding it breaks pairwise consistency
rather than restoring gluing. Adding teams never restores gluing for a crossing pair.

**OP1-refined (the plausibly-OPEN target): quantum junction-tree under QCMI=0.** Add the
hypothesis that every separator carries vanishing QCMI (quantum Markov / Petz-recoverable). On
CHAINS this is HJPW (sequential Petz recovery) — KNOWN. The BREAK: at a branch separator S
shared by ≥3 teams, the per-branch Petz recovery maps do not commute, so there is no canonical
recovery order and no well-defined "product of conditionals". The branch-separator joint-
recoverability condition is the NEW content; NOVELTY PROBE required before any unpublished claim.

**First new lemma (reachable, against real QuantumInfo API).**
`quantum_vorobev_laminar`: pairwise consistency of density-matrix marginals forces a global
state ⟺ the cover is laminar. Load-bearing sub-lemma to BUILD (conjecture-with-proof-plan, NOT
banked): `MState.eq_prod_of_traceRight_pure : ρ.traceRight = pure ψ → ρ = (pure ψ) ⊗ᴹ ρ.traceLeft`,
provable via `purify`/`purify_spec` + `eq_of_sum_eq_pure` + `pure_separable_iff_traceLeft_pure`
(all present, MState.lean lines 676/979/1000/1019). Team-indexed partial traces over
`(v:↥T)→dV` must be built by composing bipartite `traceLeft`/`traceRight` through `relabel`
(Equiv reindex, line 1051) and `piProd` (line 1313); `Ket.MES` + `traceRight_pure_MES`
(Entanglement.lean 241) is the monogamy engine.

**Kill criteria for OP1.** (a) If the novelty probe finds the laminar characterization already
stated (contextuality or quantum-marginal literature), QV downgrades to formalization-first. (b)
If `eq_prod_of_traceRight_pure` fails to close in-kernel (some purify API gap), the witness ⊆
direction is blocked and must be rerouted. (c) If a branch-separator quantum junction-tree
theorem is found in the literature, OP1-refined downgrades from open to formalization-first.

---

## Γ UPDATE — 2026-07-07, R-grammar expansion survey (PI-directed)

**Trigger.** PI: "we recently greatly expanded design lab machinery including wasserstein,
multivariate gaussian etc; use /mathlib-search and update your noological URS." Survey run
via static name-corpora + source trees (daemon left undisturbed while the builder held it),
then spot checks. This section records what my act(formalize) grammar now contains that it
did not when the tower laws were drafted.

**New machinery relevant to THIS arc (all kernel-loaded at the pin):**

- **ZPM/InformationTheory** — the analytic information layer: `KullbackLeibler`
  (Real/Fintype/FiniteSupport forms, Binary with derivatives, **CondChainRule**,
  **Tensorization**, MapEquiv) and **KullbackLeibler/Gaussian**: the multivariate Gaussian
  KL **closed form** `klDivReal_multivariateGaussian` (on Mathlib's own
  `ProbabilityTheory.multivariateGaussian` over `EuclideanSpace ℝ ι` with covariance
  matrices), plus AffineImage, Whitening, Diagonal, AbsolutelyContinuous, OneDim.
  Also `Pinsker` (binary + general), `MutualInformation` (real MI, nonneg,
  `eq_zero_iff_product` at measure level), CrossEntropy, TotalCorrelation.
- **ZPM/MeasureTheory/OptimalTransport** — `dualW1` (Kantorovich-side dual W₁ over ℝ≥0∞
  costs on general measures: Lip1, triangle, comm, map_le, setoidDist) with a parallel
  **FintypePMF** version under ZPM/Probability. Fresh (edited today); measurements search
  index predates it — maintenance note: run `mathlib-search reindex measurements` before
  the next measurements-target session.
- **ZPM/Probability** — Concentration (Chebyshev majority, bounded RVs), Exchangeability
  (split measures, double sample), Decision, FintypePMF.
- **ZPM/MeasureTheory** — ChoquetCapacity (capacitability: `AnalyticSet.compactCap_eq`,
  `cap_eq_iSup_isCompact`), AnalyticMeasurability, ProbabilityMeasure.
- **world-models/WMSpec** — `Metric/Wasserstein` + `BisimMetric`:
  `dynCong_iff_dualW1_setoidDist_eq_zero` (bisimulation ⟺ dual-W₁ vanishing; the field's
  vanishing-iff-structural pattern on a dynamic substrate).
- **crypto** — SurrogateFromKernel/SurrogateBound/Whitening (the PAC-Privacy MI-surrogate
  project; Gaussian mechanisms).
- **QuantumInfo (builder report, banked to KK).** Built green from design-lab root
  (`lake build @Physlib/QuantumInfo`, 8636 jobs) against the IDENTICAL root mathlib; target
  `quantuminfo` registered and active (183 MState hits, sorry-taint markers working).
  **Planned import slice audited CLEAN** (standard three axioms, no sorryAx): MState +
  traceLeft/traceRight/prod/pure_iff_constant_spectrum, Pinching, VonNeumann + SSA
  (`Sᵥₙ_strong_subadditivity`), DPI, Entanglement (EoF). **QUARANTINE (do not use):**
  all of `Entropy.Axiomatized.*`; `qRelativeEnt_joint_convexity`; all of `Capacity.*`;
  `ClassicalInfo.Capacity.BlockCode`; `fidelity_channel_nondecreasing`. Build discipline:
  always from design-lab ROOT, never from inside physlean/ (its own manifest would clone a
  second mathlib).

**What the expansion changes about the arc (Γ-consequences):**

1. **OP4 becomes STATABLE now, classically.** The graded marginal problem needs a metric
   on the compatible set; `dualW1` (FintypePMF + measure forms) and the Pinsker chain
   (KL ⟶ TV ⟶ W₁ comparisons) are exactly the missing grammar. The candidate graded law
   (defect of a family = distance from the glueable set, compared against hcComb and the
   entropy identity) can be written as a pre-registered battery without waiting on OP1.
2. **OP2's substrate is richer than assumed.** CondChainRule + Tensorization + measure-level
   MI are the classical junction-tree entropy identity's natural formalization toolkit; the
   [NUM] identity has a direct kernel path that did not exist in my model of the corpus.
3. **UK→KU: the GAUSSIAN TIER (new articulation, conjecture-status, the survey's main
   yield).** With multivariate Gaussians + KL closed forms in the grammar, the tower gains
   a candidate FOURTH wall between classical relations and quantum states: the **Gaussian
   marginal problem** is covariance/PSD completion, and its classical answer is the
   Grone–Johnson–Sá–Wolkowicz theorem (1984, KNOWN, conceded): every consistent partial
   PSD specification completes ⟺ the specification graph is CHORDAL. Honest tags: GJSW is
   not open; a kernel proof would be a formalization first with real content (the
   completion construction). The field-native candidates on top of it:
   - **TN (tower nesting, ours):** the four walls in one kernel frame: relational gluing =
     hypergraph acyclicity ⊂ Gaussian gluing = chordality of the specification graph ⊂
     quantum gluing = (likely degenerate, OP1) ⊂ no-signaling = everything; with our OWN
     chordal/conformal dichotomy as the bridge between walls one and two (acyclic ⟺
     chordal + conformal: the walls nest THROUGH the dichotomy already in the kernel).
   - **We already own the graph half:** Dirac.lean built minimal separators, simplicial
     vertices, and chordality from scratch; GJSW's proof runs on perfect elimination
     orderings, i.e. iterated `dirac_strong`. The distance from our banked stack to GJSW
     is the linear-algebra half only (Schur complements, one-entry completion).
   - **Graded Gaussian defect (candidate-open):** minimal KL (or W₂, closed-form for
     Gaussians) distance from a consistent partial covariance to the completable set, as
     the Gaussian hcComb; whether this carries a five-way-style equivalence appears
     unexplored. Needs a novelty probe before any claim.
4. **Standing corpus-model correction (feedback to self):** my working model of ZPM was
   HC-only and materially stale; the corpus now spans information theory, OT, capacity
   theory, and concentration. Rule reaffirmed: survey `target list` + source trees at arc
   start, not just the subsystem under edit.

---

## VERDICT ROUND — 2026-07-07 (workflow `quantum-tower-interrogation`: 4 developers, 2 adversarial verifiers, ~455k tokens, all Opus)

### Corrections to my own record (A4 firings, logged)

1. **T3 novelty claim was FALSE.** I wrote "no kernel proof exists anywhere we know" for
   Tsirelson. Echenim–Mhalla formalized CHSH + Tsirelson's bound in Isabelle/HOL
   (arXiv:2306.12535, J. Automated Reasoning). A Lean formalization is first-in-Lean, a
   re-implementation in a different prover. Table row corrected above.
2. **W2's headline law REFUTED by its verifier.** "Quantum gluing ⟺ laminar cover" is
   FALSE as a biconditional: counterexample {ab, bc, abc} — non-laminar (ab, bc cross) yet
   EVERY pairwise-consistent family glues, because the super-team abc pins both marginals
   and is itself the global state. Root cause: a crossing-pair monogamy witness does not
   extend to covers containing a dominating super-team. What survives verified: the
   crossing-PAIR witness (SDP-infeasible + monogamy, two independent checks), laminar ⟹
   glue, and the named Lean obligation `MState.eq_prod_of_traceRight_pure` (true,
   unwritten, the crux sub-lemma).
3. **W3's mechanism claim corrected.** The junction-tree entropy identity's true reason is
   Hammersley–Clifford (the join-indicator is a Gibbs distribution with clique-indicator
   potentials, hence tree-Markov), not the developer's "team-uniform marginals" story.
   Identity itself re-verified on chains AND branching trees (26,927 instances).

### Per-law final verdicts (literature-subtracted)

| Item | Verdict | Key citations |
|---|---|---|
| T1 | formalization-first; math is Vorob'ev 1962 + Abramsky–Brandenburger NJP 2011 | AB arXiv:1102.0264 lineage |
| T2a | elementary/folklore; explicit in PRA 101:032341 (2020); Navascués–Baccari–Acín Quantum 2021 | thin bridge lemma only |
| T2b | textbook monogamy (CKW 2000) | assembly, not discovery |
| T3 | known 1980; Isabelle/HOL formalization exists | Lean port = first-in-Lean only |
| OP1 raw (QV) | laminar biconditional FALSE (see counterexample); corrected candidate below is CONJ | — |
| OP1 refined | **the surviving open residue**: chordal case CLOSED May 2026 by Lauritzen–Zwiernik arXiv:2605.19453 (noncommutative junction-tree T(R); Tr(T(R)) = 1 ⟺ quantum Markov completion; unique; max-entropy). General NON-CHORDAL covers open: is completion-forcing cut out by local separator-CMI conditions, or does non-chordality introduce a strictly cohomological obstruction? Nobody has a machine-checked quantum junction tree: the chordal formalization is a genuine first with content | LZ 2605.19453; HJPW 2004; Leifer–Poulin 2008 |
| OP2 | open but populated: hypergraph quantum entropy cones are a named subfield (Bao–Cheng–Hernández-Cuenca–Su, SciPost 9:067 2020); Zhang–Yeung gap is the real wall; LOW HC leverage conceded. Kernel value = finite checkable instances only | — |
| OP3 | AvN/Z₂ completeness KNOWN (ABKLM CSL 2015, arXiv:1502.03097; stabilizer AvN-triples 1705.08459). Hardy model = the canonical FALSE NEGATIVE of Čech H¹ (our kill-criterion witness for set-valued incompleteness, for free). Open flag-plant: (i) whether our affine direction-presheaf class is STRICTLY larger than the AvN fragment (scope comparison due in the affine formalization arc), (ii) the coefficient-presheaf completeness characterization (the open problem Carù 1807.04203 and Aasnaess 2212.09382 leave standing) | — |
| OP4 | open, no literature collision found, downstream of OP1/OP2; unattackable today | — |

### Corrected OP1 candidate (CONJ, not banked)

The counterexample forces the corrected shape: **QV′: quantum gluing for all pairwise-
consistent families ⟺ the maximal teams of the cover are pairwise disjoint.** Forward
direction is W2's verified claim 3 (roots tensor, nested teams pinned). Converse is the
genuinely subtle part: two crossing MAXIMAL teams admit the MES witness on the pair, but
the witness must EXTEND to a consistent family over all remaining teams; other teams
intersecting the entangled legs constrain the extension. The extension problem (for which
covers does the monogamy witness propagate?) is now a sharply posed open combinatorial-
quantum question, and it is OUR kind of question: it is the quantum analog of the
engine's hosted-datum extension, and the blocking pattern (dominating super-teams) is
nerve-structural. Status: CONJ, needs its own battery + proof attempt.

### The consolidated frontier after subtraction

1. **Non-chordal quantum Markov completion (OP1 residue).** The one direction that is
   simultaneously open, freshly bounded by a 2026 result, and squarely on our machinery:
   LZ close chordal covers; non-chordality is exactly where our cyclic obstructions and
   H¹ classes live. The tower-nesting picture STRENGTHENS: chordality is the completion
   wall in BOTH the Gaussian tier (GJSW 1984) and the quantum-Markov tier (LZ 2026), and
   our Dirac chordality stack is the shared kernel substrate for both. The question "does
   non-chordality force a cohomological (non-local) obstruction to quantum Markov
   completion" is the field's flagship question wearing quantum dress.
2. **The QV′ extension problem** (above): new, sharp, ours to develop or kill.
3. **OP3's two flag-plants**, resolved as part of the affine formalization arc.
4. **Kernel firsts with content, if wanted as substrate**: machine-checked quantum
   junction tree (LZ chordal case); first-in-Lean Tsirelson (correctly labeled).

**η of the workflow:** high on the interrogation axis (two false claims of mine caught,
one developer law killed by counterexample, one mechanism corrected, the frontier
narrowed to genuinely open ground with fresh citations); zero new banked theorems, as
expected for an interrogation round.
