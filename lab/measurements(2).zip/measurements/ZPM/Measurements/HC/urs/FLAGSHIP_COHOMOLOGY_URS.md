# FLAGSHIP_COHOMOLOGY_URS — the cohomological-roots arc (and the quantum leg)

**Problem (one line).** Construct the cochain complex canonically attached to an ignorance
structure such that H• trivial ⟺ rectangular/glueable (the five-way / the v0.2 nerve
theorem) AND hcComb is its Euler-characteristic shadow; land the quantum contact (PR box /
CHSH possibilistic contextuality) as theorem instances of the v0.2 machinery.

**Session start: 2026-07-07. Prior state: Theory.md v0.2 §8 (the flagship, re-scoped:
H¹-side KV on the discrete nerve; χ = hcComb identity open). This arc is the field note's
"paper mathematics first, Lean second" step, run under gated imagination with kernel and
explicit-computation verifiers.**

---

## Object axis (γ) — discovery state about the flagship

**KK (stabilized).**
- The qualitative H¹ statement is a THEOREM: `acyclic_iff_forall_consistent_glues` —
  set-valued gluing on a cover succeeds for all consistent families iff the nerve is
  acyclic; failure is witnessed constructively by the affine F₂ engine (v0.2, KV).
- The engine's obstruction datum (closed coherent system, odd hosted dependency) is
  cocycle-shaped: per-team constants over F₂ whose cyclic sum is 1 — a non-splitting
  1-cochain on the nerve. Not yet NAMED as cohomology in the kernel.
- hcComb = |⊗κ| − |κ| at arity 2; `hcComb_eq_zero_iff_isRect`; the five/six-way (KV).
- The two traps (Theory.md §8): degree-zero trap (two-term inclusion complex, χ trivially
  the size difference, no higher cohomology); context trap (hcComb is single-context;
  sheaf-contextuality H¹ is multi-context).

**KU (askable, unresolved) — the candidate laws of this arc, verdicts pre-registered.**

| Law | Statement | Expected verdict | Verifier |
|---|---|---|---|
| C-DOW | H̃•(Dowker_X(κ); ℚ) = 0 ⟺ κ rectangular | **FALSE** (⟸ fails: W1 = 3-of-4 has contractible Dowker but hc = 1; ⟹ holds: rect ⟹ full simplex) | explicit computation on zoo |
| C-DOWχ | some χ of the Dowker pair recovers hcComb | **FALSE** (Dowker forgets cell multiplicity) | computation on zoo |
| C-REL | relative complex C•(⊗κ, κ) "proves" the flagship | **TRAP INSTANCE** (fails T1 below; recorded, not probed) | — |
| C-JT | join-tree counting: on an acyclic cover with a consistent family, \|glue\| = ∏_teams \|rel_T\| / ∏_separators \|marg_S\| (running-intersection telescope) | **TRUE** (BFMY lineage; the multiplicative Euler-type formula, the quantitative germ on trees) | numeric sweep on random acyclic families |
| C-AFF | affine subclass: for F₂-affine local systems on a cover there is a genuine chain complex (solution presheaf Čech complex) with H⁰ = global solutions, H¹ = 0 ⟺ every coherent family glues, and explicit alternating dim formula on acyclic covers; the engine's odd class has dim H¹ ≥ 1 on cycles | **TRUE** (linear algebra; the engine's Gaussian core is the boundary-map theory) | numeric F₂ linear algebra sweep + engine cross-check |
| C-RANK1 | matrix route: κ as 0/1 matrix on the hull; rect-with-full-projections ⟺ all-ones ⟺ rank 1; a Koszul-type complex of the rank-1 comparison has χ = hcComb without indexing cochains by ⊗κ∖κ | **UNKNOWN — exploratory** (suspect the honest version lands in the nonneg-rank corridor, not cohomology) | symbolic/numeric exploration |
| C-LOG | the grading codomain for the cohomological reading is log-scale on the affine subclass: dim-defect = log₂-of-cardinality-defect ratio; the §5 monoid knob and the χ-codomain are the same dial | **PLAUSIBLE, arity-2 check first** | dim bookkeeping in C-AFF sweep |
| Q-CHSH | the CHSH cover (4-cycle on Fin 4) is not acyclic; `cycle_obstruction` on it yields a consistent nonempty non-gluing family = the possibilistic PR box; strong contextuality as ¬Glues | **TRUE** (direct instance of v0.2) | Lean kernel, `decide` + instantiation |

**Kill criteria (operationalized traps — a candidate surviving its verifier must ALSO pass
these, else it is scaffolding, not the flagship):**
- **T1 (degree-zero trap test).** The differential is nonzero on the witness zoo, and no
  cochain group is definitionally indexed by ⊗κ∖κ (or any set whose definition mentions
  the defect). χ must emerge from ranks of genuine maps.
- **T2 (context trap test).** The complex is defined uniformly on covers (arbitrary team
  count), specializes at the 2-team cover to an hcComb-statement, and at cyclic covers its
  H¹ detects the engine's odd class. Single-context-only constructions fail T2.
- **T3 (functoriality).** Monotone under κ ⊆ κ' with controlled behavior, or at least
  invariant under sort-relabeling; ad-hoc per-witness constructions fail.

**UK (sensed, articulated this session — the R-move under test).** The v0.2 lesson
inverted the flagship's geography: the cohomology does not live on single-context κ (T2:
there is no room); it lives on the COVER, and hcComb is the arity-2/2-team shadow of a
nerve-level invariant. Leading articulation: the flagship complex is the Čech complex of
the cover with coefficients in the (linearized) local-section presheaf; the affine
subclass is where it is exactly linear algebra (C-AFF), the general case is its set-valued
/ non-abelian degeneration (already KV qualitatively), and the counting identity is the
join-tree telescope (C-JT) made homological. If C-JT and C-AFF both verify, the flagship
splits into: (i) affine flagship [formalizable next], (ii) general counting identity
[open], with the trap-free complex named.

**UU.** Whether the general (non-affine) counting identity has ANY exact cochain-level
form, or only inequalities (submodularity-type). Not askable until C-AFF/C-JT verdicts.

---

## Agent axis (Γ) — noological state

**A (Will snapshot).** Rigor-first, A5-first, never-sorry; imagine is GATED: every
candidate law above is conjecture until its verifier speaks; no candidate is banked from
plausibility. The two traps are Pl-kill criteria written BEFORE probing. Paper-first
sequencing honored: this arc's Lean writes are (a) the quantum leg (KV-reliable instance
work) and (b) only-if-verified skeletons.

**R-moves this session.** (1) The geography inversion (UK above) articulated as a testable
reframe rather than banked. (2) The witness zoo fixed as the shared verification substrate
across candidates. (3) Kill criteria T1-T3 as the operational form of §8's prose traps.

**M-moves.** Verification = parallel independent computation agents (workflow), one per
candidate, blind to each other; adversarial re-check on survivors; Lean kernel for Q-CHSH.
Learning-route floors (mathlib-search) before any Lean write.

**Γ_core.** Pl_imagine is LOW on the general complex (history: every naive candidate is
trap-shaped) — hence the battery; Pl_imagine is HIGH on Q-CHSH (pure instantiation of KV
machinery); Coh_ens↔Will: the arc directly serves the field's governing thesis and the
honest hinge named in Theory.md §7.

**Witness zoo (shared substrate, fixed before probes).**
Bipartite: R1 = 2×2 full (hc 0); W1 = 3-of-4 (hc 1); W2 = 2×2 matching (hc 2);
W3 = 3×3 diagonal (hc 6); W4 = Pcorr support = 2×2 full (hc 0, control);
W5 = L-shape 3-of-9 (hc 3... verify: hull 2×2? no: L-shape {(0,0),(0,1),(1,0)} ⊆ 3×3 has
projections {0,1}×{0,1}, hull 4, hc 1 — RECOMPUTE in probe, do not trust this row);
W6 = random 4×4 samples. Multi-context: PR box on the 4-cycle; Specker triangle family;
path cover (acyclic control); random join-trees (C-JT).

**γ this session (to be filled at verdict round):**
- [pre-registered] C-DOW hand-derivation already found the W1 kill (Dowker of 3-of-4 is a
  full simplex, contractible, hc = 1): expect the computation agent to CONFIRM.

**η:** to be assessed at verdict round.

---

## VERDICT ROUND — 2026-07-07 (battery `flagship-candidate-battery`, 9 agents, ~572k tokens)

Protocol: each candidate probed by an independent computation agent (fresh code, exact
arithmetic, seeded), every definite verdict re-attacked by an adversarial verifier with a
fully independent implementation and fresh edge-case zoos. No verdict below rests on a
single implementation.

| Law | Pre-registered | Verdict | Adversarial check |
|---|---|---|---|
| C-DOW | FALSE | **CONFIRMED_FALSE** | not refuted |
| C-DOWχ | FALSE | **CONFIRMED_FALSE** (structural) | not refuted |
| C-JT | TRUE | **CONFIRMED_FALSE — my expectation was WRONG** | not refuted |
| C-AFF | TRUE | **CONFIRMED_TRUE** (all four laws, ~800 instances) | not refuted |
| C-RANK1 | exploratory | **CONFIRMED_TRUE** (no-go + minimal witness) | not refuted |
| C-LOG | plausible | **CONFIRMED** via C-AFF/C-JT jointly | (derived) |
| Q-CHSH | TRUE | **KV** — kernel, clean axioms | Lean kernel |

**γ (what is now known that was not).**

1. **The affine flagship complex exists and is fully specified.** On pairwise-consistent
   F₂-affine local systems over any cover: the Čech complex of the **direction presheaf**
   on the nerve — F(σ) = π_{c(σ)}(V_T) (well-defined exactly on the consistent locus;
   V_e = π_e(V_T) + π_e(V_T') extends off it), coordinate-projection restrictions, char-2
   Čech differential. Verified laws: (a) glue ⟺ the mismatch class [δ] vanishes in H¹
   (δ_{TT'} = π_e(s_T + s_T'), a cocycle, class independent of reference sections);
   (b) forest nerves have H¹ = 0 (consistency ⟹ gluing); (c) the PR box is the nonzero
   class in a 1-dimensional H¹, and the even-parity twist on the SAME cover is a
   coboundary — the invariant separates the classes; (d) on α-acyclic covers, EXACT with
   zero correction and join-tree independence: log₂|join| = Σ_T dim V_T − Σ_e dim V_sep;
   universally log₂|join| = dim H⁰ whenever the glue exists, cyclic covers included.
   Trap checks T1/T2/T3 all PASS. Probe supplied proof sketches for all four laws
   ((a) unwinding, (b) leaf-to-root surjectivity of d⁰, (d) fiber counting along the
   tree): this is FORMALIZABLE on top of AffineEngine + the mathlib-floor findings.

2. **The general counting identity is entropy-valued, not cardinality-valued.** The
   pre-registered C-JT (|join| = ∏ nodes / ∏ separators) is FALSE in both directions on
   the simplest acyclic cover (exhaustive: 64/255 failures on the 2-team path; both kill
   witnesses closed under join). The TRUE identity, exact to machine precision on all 320
   + 297 instances and join-tree invariant: with U = uniform on the join,
   **log₂|join| = Σ_{tree nodes} H(U_T) − Σ_{tree edges} H(U_{S_e})** — the uniform
   distribution on the join factorizes over the junction tree. C-JT is its max-entropy
   degradation (H ↦ log₂|support|), and the degradation is what breaks exactness. The
   affine case (1) is the special case H = dim (uniform on an affine subspace). The §5
   monoid-knob question is thereby answered in direction: the χ-codomain is entropy,
   restricting to dimension on the affine locus; the support-vs-distribution separation
   (the Pcorr lesson) reappears at the counting level.

3. **No-go, with the forcing identity (provable by expansion).**
   hcComb(κ ⊔ κ') = hc + hc' + |A||B'| + |A'||B| and
   hcComb(κ × κ') = hc·hc' + hc·|κ'| + hc'·|κ| — exact on 2601 ordered pairs and
   algebraically immediate. Hence NO χ-additive functor computes hcComb: any candidate
   must couple the parts through the hull's cross-blocks. The minimal witness realizing
   this is the evaluation complex K(κ): ℚ^{πL} ⊗ ℚ^{πR} → ℚ^κ (χ = hcComb, acyclic ⟺
   rectangular, contravariantly functorial) — but its cohomology concentrates in degree 0
   and equals the defect space: the FORMAL boundary of the degree-zero trap, correctly
   labeled scaffolding, not the flagship.

4. **Dowker is dead as the flagship carrier.** Not only does the iff fail (19/36
   vanishing-but-nonrectangular; W1 as predicted): hcComb is not even a FACE-SET invariant
   of the Dowker pair (R1/W1 collision: identical complexes, hc 0 vs 1; 43 collision pairs
   zoo-wide), killing every Euler-characteristic reading at once. Surviving one-way
   fragment (trivial theorem): nonempty rectangular ⟹ Dowker is a full simplex.

**Q-CHSH (kernel, this turn).** `PRBox.lean`, barrel at twenty-one layers, axioms
propext/Classical.choice/Quot.sound: `chshCover_not_acyclic`; `chsh_hosts_nonglue` (the
scenario's SHAPE forces the possibility of contextuality); the explicit possibilistic PR
box with `prBox_consistent`, `prBox_no_global_section` (joinFam = ∅: Abramsky–Brandenburger
strong contextuality), `prBox_not_glues`; and the acyclic control
`bellPath_no_contextuality` — drop one context and every consistent family glues.
Possibilistic contextuality of the CHSH scenario ⟺ its cover's cyclicity, both directions
kernel-checked. The PR box is now the pinned nonzero H¹ instance the affine complex must
(and does, numerically) detect.

**Corrected belief, logged for the discipline.** C-JT was pre-registered TRUE on my
BFMY-lineage intuition; the battery killed it with exhaustive counterexamples and the
verifier independently reproduced both kill witnesses. The join-tree structure governs
CONSISTENCY and the entropy factorization, not raw cardinality products. This is exactly
what pre-registration is for.

**Next formalization target (gated, now justified):** the affine Čech complex over
AffineEngine — substrate per MATHLIB-FLOOR: Finset-indexed F₂ linear maps with
`Module.finrank` as the spec layer (`LinearMap.finrank_range_add_finrank_ker` for
rank-nullity; `Module.card_eq_pow_finrank` to pin dims through cardinalities; simplicial
homology and Euler–Poincaré are ABSENT from Mathlib at this pin and must be built).
Deliverables in order: the complex + d∘d = 0; law (a) glue ⟺ coboundary; law (b) forest
vanishing; the PR-box class computation (decide-friendly); law (d) the dim identity.

**η: very high.** One kernel-closed quantum leg, one construction that survived double
implementation with all trap checks, one corrected law replaced by a sharper true one, one
no-go with an exact forcing identity, three clean kills. The flagship is no longer a
one-line conjecture: it is a specified complex with verified finite evidence and a named
degradation explaining WHY the naive cardinality reading was never going to work.
