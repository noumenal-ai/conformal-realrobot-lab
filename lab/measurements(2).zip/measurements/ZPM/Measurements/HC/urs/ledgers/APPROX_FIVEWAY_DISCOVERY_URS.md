# Discovery URS (γ) — the approximate five-way (#14): typing derivation + proof DAG

Object-axis instrument. Companion: APPROX_FIVEWAY_NOOLOGICAL_URS.md (Γ). PI decisions held
constant: monoid-valued knob (A-K direction), multipartite theorem Prop / bipartite witness,
lower leg = acceptance criterion.

═══════════════════════════════════════════════════════════
## TYPING DERIVATION (six concepts, measured)
═══════════════════════════════════════════════════════════

**C1 — multipartite substrate** `{ι : Type*} [Fintype ι] {X : ι → Type*}` with per-part
`[Fintype (X i)] [DecidableEq (X i)] [MeasurableSpace (X i)] [DiscreteMeasurableSpace (X i)]`.
`κ : Finset (∀ i, X i)`; `proj i κ := κ.image (fun f => f i)`; `hull κ := Fintype.piFinset
(fun i => proj i κ)`; `hcCombPi κ := (hull κ).card − κ.card`; `IsRectPi κ := κ = hull κ`.
- M(C1) = (g_Pl 0.2, Coh_break 0, Inv 0.8, Comp 0.95) → **T-Parametric** (plain defs over
  section variables, the HC module's own idiom; no bundling).
- COUNTERDEF C1′ (the genuine alternative): the interface-typed fibered presentation
  (S-indexed families, Fibered.lean style). SWAP CONDITION: when the flagship's multipartite
  amalgamation leg is built (arity ≥ 3 higher obstruction), the interface presentation becomes
  primary; #14's information face (full-independence comparison, TC vs ∏ marginals) is natively
  the plain Π-presentation. Documented forward edge, not this build.

**C2 — `totalCorrelationReal`** `(P : Measure (∀ i, X i)) : ℝ := klDivReal P (Measure.pi fun i
=> P.map (fun f => f i))`. The Π-analog of `mutualInformationReal` (= klDivReal against the
product of own marginals).
- M(C2) = (g_Pl 0.1, Coh_coercion 0.2 [one bridge to MI], Inv 0.9, Comp 0.95) → **T-Abbrev**
  one-liner, BUT placement is the load-bearing call: it is an information-theory def, not an
  HC def → lives in **ZPM/InformationTheory** (sibling of MutualInformation), upstreamable;
  the HC module consumes it.
- COUNTERDEF C2′: entropy-sum form (Σᵢ H(margᵢ) − H(P)). SWAP CONDITION: never as the
  definition (klDiv form is total and matches the toolkit); the entropy form appears as a
  THEOREM (the finite-support identity) if the upper leg needs it.

**C3 — canonical measure on κ** `uniformMeasurePi κ hκ := (PMF.uniformOfFinset κ hκ).toMeasure`.
T-Abbrev, verbatim generalization (PMF.uniformOfFinset is type-agnostic). Workhorse lemmas
mirror the bipartite file: singleton mass `1/|κ|`, marginal singleton mass `countᵢ(a)/|κ|` where
`count i a := (κ.filter (fun f => f i = a)).card` (Π-analog of rowCount/colCount).

**C4 — the theorem pair (T-Prop; hypothesis structure is the content).**
- UPPER (fibre-crawling, shallow direction): `TC(unif κ) ≤ Real.log ((hull κ).card / κ.card)`
  `= Real.log (1 + hcCombPi κ / κ.card)`. Route: finite-entropy identity
  `TC = Σᵢ H(margᵢ) − log |κ|` + `H(margᵢ) ≤ log |proj i κ|`. DEPENDENCY KU-ent: Mathlib
  finite Shannon entropy (`measureEntropy`?) — if absent, counterdef: private inline entropy
  or a direct log-sum proof. (Ess-sup and pointwise-ratio routes checked on paper: they give
  the weaker `(n−1)log|κ|`, not the hull bound; entropy route is the right one.)
- LOWER (the content; acceptance criterion): for `P` a probability measure with
  `P(↑κ) = 1` and marginal mass floors `c : ι → ℝ≥0` (`∀ i, ∀ a ∈ proj i κ, P.map(evalᵢ) {a} ≥ cᵢ`):
  `TC(P) ≥ pinskerConst · (hcCombPi κ · ∏ᵢ cᵢ)²`.
  Route (M-Pipeline): Pinsker `TC = klDiv(P, ∏marg) ≥ const · TV²` ∘ `TV ≥ |P(F) − Q(F)|` at the
  forbidden set `F = ↑(hull κ \ κ)` ∘ `P(F) = 0` ∘ `Q(F) = Σ_{x∈F} ∏ᵢ margᵢ(xᵢ) ≥ hcCombPi · ∏ᵢ cᵢ`
  (each `xᵢ ∈ proj i κ` so each factor ≥ cᵢ).
  **The knob is here**: `c` lives in the pointwise-ordered commutative monoid `ι → ℝ≥0`, and the
  bound consumes its monoid fold `∏ᵢ cᵢ`. CANONICAL INSTANCE: `P = unif κ`, `cᵢ = 1/|κ|`, giving
  the section theorem `hcCombPi κ > 0 → TC(unif κ) ≥ pinskerConst · (hcCombPi κ / |κ|^n)² > 0`.
- A4 pre-check: neither leg is trivial (upper needs the entropy chain; lower needs Pinsker + the
  forbidden-mass computation); hypotheses all load-bearing (drop the floor → the separation
  witness Pcorr-style mass-shifting kills the bound; drop P(κ)=1 → F can carry P-mass).

**C5 — the K-weighted layer (T-Break, documented; the honest A-K installment).**
- PRIMARY (exercised): the floor family `c : ι → ℝ≥0` with its monoid fold, as in C4-LOWER.
  This IS a monoid-valued parameter and the statement exhibits the dial: the same `c` grades the
  weighting (mass floors) and scales the count (`hcCombPi · ∏c`). Two exercised instances:
  canonical (`c = 1/|κ|`, recovering the section theorem) and general-P (the off-section
  corollary).
- COUNTERDEF C5′ (the full A-K signature): K-relations `w : (∀ i, X i) → K` over an ordered
  commutative semiring K with a realization hom to ℝ≥0; grading codomain = K. SWAP CONDITION:
  the §10 graded-cylindric-signature build (separate installment); adopting it NOW would add
  fields no proved instance exercises (Γ-gate). The "one dial" identification remains **[CONJ]**
  (PI's); C4-LOWER is its first statability witness, not its proof.
  -- BREAK POINT: the signature design is underdetermined by this theorem; the ad-hoc choice
  (floor family) is recorded as the minimal exercised form. A-K citation: [to-verify].

**C6 — bipartite witness (T-Bridge).** Over `ι = Fin 2`, `X = ![α, β]`-style: transport along
the `(∀ i : Fin 2, X i) ≃ᵐ X 0 × X 1` equivalence: `hcCombPi = hcComb` (image), `TC = MI`
(map), `uniformMeasurePi ↔ uniformMeasure`, and the section theorem instantiates against
`fiveWay_uniform`'s objects. What the bridge must NOT lose: the `proj`/`projL,projR`
identification (image under eval = projL/projR after transport).

**η checks.** Profiles: T-Parametric, T-Abbrev, T-Abbrev, T-Prop, T-Break, T-Bridge — no
homogeneity; 1 break point (budgeted, documented); 2 Mathlib bridges (piFinTwo, piFinset).

═══════════════════════════════════════════════════════════
## IGNORANCE LEDGER (to floor via mathlib-search)
═══════════════════════════════════════════════════════════

**KK.** Bipartite HC module (hcComb, uniformMeasure, marginal lemmas, fiveWay_uniform,
uniform_klDiv_ne_top proof patterns); klDivReal toolkit (Real, MapEquiv, Tensorization, NormLlr,
M3d idioms); `mutualInformationReal` def; PMF.uniformOfFinset (bipartite file uses it);
ZPM barrel imports Pinsker + TotalVariation.

**KU (name-level, floor ALL before formalize).**
- KU-1 ZPM Pinsker: real path + exact statement (klDiv vs TV, constant convention). My grep of
  InformationTheory/Pinsker/Basic.lean returned EMPTY — path unknown, do not assume.
- KU-2 ZPM TotalVariation: def + the `|P A − Q A| ≤ TV P Q` characterization + discrete sum form.
- KU-3 finite Shannon entropy in Mathlib (`measureEntropy`/`Hm`?): exists? uniform value?
  subadditivity/max bounds? Else trigger C2′ counterdef (inline private entropy or log-sum).
- KU-4 `Fintype.piFinset`: name, `mem_piFinset`, `card_piFinset` (= ∏ cards).
- KU-5 DecidableEq instance for `∀ i, X i` over `[Fintype ι]` + per-part DecidableEq.
- KU-6 PMF.uniformOfFinset API: `toMeasure_apply`/singleton mass, support lemma.
- KU-7 the Fin-2 measurable equivalence (`MeasurableEquiv.piFinTwo`?) + `Measure.pi` over Fin 2
  ↔ `Measure.prod` + map-eval-of-pi lemmas.
- KU-8 klDivReal on discrete/finite support: the sum formula or the PMF-level API the bipartite
  file used for `uniform_eq_product_iff_isRect` (reuse its exact route).
- KU-9 `Measure.map (eval i)` of `Measure.pi` and of `PMF.toMeasure` (marginal machinery).
- KU-10 measurability of ↑κ, ↑(hull κ \ κ) under DiscreteMeasurableSpace on the Π-type
  (instance: `DiscreteMeasurableSpace (∀ i, X i)`? or via Countable/Fintype).

**UK (carried, articulated, not banked).**
- UK-A: whether the NFL/shattering lower bounds factor through C4-LOWER (the base-forces-fibre
  mechanism) — CONJ edge for the field note's landed-contact list, gated on #14 landing.
- UK-B: the sharp constant/regime of the lower leg (Pinsker is not tight for large defects;
  a log-regime lower bound may exist) — post-landing sharpening edge.
- UK-C: multipartite TC vs pairwise-MI decompositions (which inequality family the fibered
  presentation needs) — flagship-adjacent, parked.

**UU.** What the knob is when the weighting monoid is not realizable in ℝ≥0 (genuinely
non-probabilistic gradings) — Path-B/graded-signature territory, flagged only.

═══════════════════════════════════════════════════════════
## FLOORING OUTCOME (all KU → KK or named counterdef; KU-only status reached)
═══════════════════════════════════════════════════════════

- **KU-1 CLOSED, route collapsed.** ZPM Pinsker lives at `InformationTheory/Pinsker/`
  (Basic = barrel over Binary/Bridge/General). `General.lean` has
  `two_sq_sub_le_klDivReal (P Q) [IsProbabilityMeasure ×2] (hac) (h_int) (A) (hA) :
  2·(P.real A − Q.real A)² ≤ klDivReal P Q` — the LOWER LEG IS THIS LEMMA at
  `A = ↑(hull κ \ κ)`: P.real A = 0 (P(κ)=1), Q.real A = Σ_{x∈F} ∏ᵢ margᵢ(xᵢ) ≥ hcCombPi·∏ᵢcᵢ.
  No TV detour, no general Pinsker needed (both exist anyway: `pinsker_proof`, `tvDistReal`).
  Also available: `klBin_le_klDivReal` (two-set coarsening) and `binary_pinsker` if the sharper
  klBin form is wanted later (UK-B edge).
- **KU-2 CLOSED.** `tvDistReal` = sSup over measurable sets of |P.real − Q.real|; not needed for
  the collapsed route.
- **KU-3 CLOSED by counterdef-collapse.** `measureEntropy` ABSENT from the pinned Mathlib
  (target=mathlib confirmed; earlier zeros were a wrong-corpus artifact, daemon had drifted to
  target=rl — reset). But NO entropy def is needed: the upper leg's max-entropy step
  `H(margᵢ) ≤ log |proj i κ|` IS `klDivReal_nonneg` (Gibbs) applied to (margᵢ ‖ uniform on projᵢ),
  already in ZPM (Real.lean). Upper leg = finite-sum decomposition of `TC(unif κ)`
  (`= Σᵢ H(margᵢ) − log|κ|` unfolded as explicit Finset sums, margᵢ(a) = countᵢ(a)/|κ|)
  + per-part `klDivReal_nonneg`. Runs entirely on the existing toolkit.
- **KU-4/5/6/7 CLOSED.** `Fintype.piFinset` family (mem/card lemmas present);
  `PMF.uniformOfFinset` API (`toMeasure_uniformOfFinset_apply`, `support_uniformOfFinset`,
  `uniformOfFinset_apply`); `MeasurableEquiv.piFinTwo` (+ `piFinTwoEquiv`) for the C6 bridge.
- **KU-8/9 CLOSED by pattern-reuse.** The bipartite file's `marginalFst_singleton` /
  `uniform_eq_product_iff_isRect` machinery is the exact template for the Π-marginal
  (`countᵢ(a)/|κ|`) and discrete-klDivReal computations.
- **KU-10 RESOLVABLE at write time.** Discrete measurability on the finite Π-type: κ and F are
  finite unions of singletons; `MeasurableSingletonClass` on Pi or per-set finiteness suffices.
- Side-conditions of the Pinsker lemma at the discrete substrate: `hac` (support inclusion on a
  finite discrete space; margᵢ positive on projᵢ ⟹ ∏marg positive on hull ⊇ κ) and `h_int`
  (integrability on a finite space) — standard, discharge at write time
  (`Integrable.of_finite`-family, floor exact name then).

**Resulting theorem shapes (final, for the talk).**
- Section (canonical): `hcCombPi κ > 0 → totalCorrelationReal (uniformMeasurePi κ hκ)
  ≥ 2 * (hcCombPi κ / (hull κ).card … )²` — via cᵢ = 1/|κ| (exact spelling of the fold at
  write time), strictly positive.
- Off-section (knob): `P(↑κ) = 1` + floors `c` ⟹ `TC(P) ≥ 2·(hcCombPi κ · ∏ᵢ cᵢ)²`.
- Upper: `TC(unif κ) ≤ Real.log ((hull κ).card / κ.card)`.
- Witness: Fin-2 transport to `hcComb`/`mutualInformationReal`/`fiveWay_uniform` objects.

**Build layout.** `ZPM/InformationTheory/TotalCorrelation/Def.lean` (C2 + Fin-2/MI bridge);
`ZPM/Measurements/HC/Multipartite.lean` (C1 substrate + counting + marginal lemmas);
`ZPM/Measurements/HC/ApproximateFiveWay.lean` (C4 both legs + C5 knob corollary + C6 witness).

═══════════════════════════════════════════════════════════
## OUTCOME (γ — Gate 9): #14 DISCHARGED, both legs
═══════════════════════════════════════════════════════════

**GREEN + installed, 0 sorry, warningAsError.** Four new files + barrel:
- `InformationTheory/TotalCorrelation/Def.lean`: `totalCorrelationReal` +
  `totalCorrelationReal_fin_two` (TC over Fin 2 = MI of the paired law, via
  `measurePreserving_piFinTwo` + `klDivReal_map_measurableEquiv`).
- `InformationTheory/KullbackLeibler/FiniteSupport.lean` (reusable atom):
  `klDivReal_fintype` (KL on finite discrete = weighted log-ratio sum, via explicit
  `withDensity` singleton-mass density) + `absolutelyContinuous_of_forall_singleton`.
- `Measurements/HC/Multipartite.lean`: `projPi`/`hullPi`/`hcCombPi`/`IsRectPi`/`countPi` +
  `hcCombPi_eq_zero_iff_isRectPi` (zero-set anchor) + `card_hullPi_sdiff`.
- `Measurements/HC/ApproximateFiveWay.lean`:
  * LOWER (the content): `le_totalCorrelationReal_of_marginal_le` —
    `2(hcCombPi κ · ∏ᵢcᵢ)² ≤ TC(P)` for any P with `P(κ)=1` + marginal floors `c`;
    knob = the floor family, fold `∏c`, one visible dial.
  * Canonical section: `lower_totalCorrelationReal_uniform` (`cᵢ = 1/|κ|`) +
    `totalCorrelationReal_uniform_pos` (defect ≠ 0 → TC > 0, quantitative info leg).
  * UPPER (fibre-crawling): `totalCorrelationReal_uniform_le` — `TC(unif κ) ≤
    log(|hullPi κ|/|κ|)`, via klDivReal_fintype + per-part Gibbs
    (`neg_log_card_le_sum_mul_log` = klDivReal_nonneg against uniform-on-projection,
    NO entropy def needed) + the `Finset.sum_comp` fiber regrouping.
  * WITNESS: `mutualInformationReal_uniform_image_lower` — over Fin 2 the lower leg lands
    verbatim on the bipartite module's `hcComb`/`uniformMeasure`/`mutualInformationReal`
    (transport: `hcCombPi_fin_two`, `map_uniformMeasurePi_piFinTwo`).
- HC.lean barrel: eight layers (+ Multipartite, + ApproximateFiveWay); ZPM.lean barrel now
  imports ZPM.Measurements.HC (the module was previously unreachable from the root — its
  oleans were never built in design-lab; the whole chain now compiles + installs green).

**A4 catches during build (content, kept).**
- `absolutelyContinuous_pi_marginal`: the support hypothesis (and κ itself) were DECORATIVE —
  a probability measure on a finite discrete product is AC w.r.t. its own marginal product
  unconditionally. Removed both; the lemma is stronger and reusable (upstreamable).
- The M3b-era note "Finset.sum_neg_distrib nonexistent" is STALE: it exists in the current pin
  and compiled. Ledger corrected.

**Γ lessons (logged for the instance).** Tactic-block if-branches over PMF-produced `if`s carry
foreign Decidable instances: state case-split lemmas as `hu_mem`/`hu_notmem` pairs (if_pos/if_neg
against the goal's own instance) rather than as an `if`-statement have. `Finset.sum_comp` under
rw suffers HO-unification: instantiate it as a `have hcomp := Finset.sum_comp (s := κ) f g` term
and rewrite with the constructed equation. `omit` must precede the docstring, not follow it.

**Field-note ledger updates earned (for the PI to port to zetesis-puremath):**
- The approximate five-way moves from open to **[KV]** (both legs + witness).
- The one-dial conjecture gains its first statability witness (the knob appears in a proved
  theorem); remains [CONJ] as an identification.
- UK-A (NFL/shattering lower bounds factor through the lower leg) remains a named [CONJ] edge
  for the landed-contact list. UK-B (sharper klBin-form lower leg) and the multipartite
  total-correlation faces at arity ≥ 3 (flagship-adjacent) are the named sharpening edges.
