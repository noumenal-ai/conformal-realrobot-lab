# Graham-Bridge URS — decidable acyclicity (Γ ⟷ γ)

The decidability face of the amalgamation architecture: `Acyclic` as ∃-RIP-order (certificate),
Graham reduction as the decision procedure, the bridge `Acyclic ↔ Graham`, and the payoff
`Decidable (Acyclic 𝒞)` — replacing the six-orderings hack with the order-free kernel-fact.

═══════════════════════════════════════════════════════════
## Γ — derivations
═══════════════════════════════════════════════════════════

**D1 (the confluence trap, found in-model and dodged).** The DETERMINISTIC greedy ("eliminate
any ear, repeat") is complete only given confluence: *if 𝒞 is acyclic and T is any ear, then
𝒞 \ T is acyclic*. Proof attempt: move T to the front of an RIP order and repair the tail. The
repair fails at a precise point: a member L whose RIP-witness WAS T needs a new witness
containing `L ∩ cover(later \ T) ⊆ T ∩ cover(others) ⊆ T̂`, but T̂ (the ear's home) may sit
EARLIER than L in the order — no later witness available. The gap is real (the textbook proofs
route through join-tree characterizations, not naive deletion). DERIVED DODGE: the bridge does
not need determinism. Formulate Graham as the NONDETERMINISTIC ear-elimination —
`GrahamN (n+1) 𝒞 := 𝒞 = ∅ ∨ ∃ T ∈ 𝒞, ear T ∧ GrahamN n (𝒞.erase T)` — and both directions of
the bridge become card-fuel inductions with NO confluence: an RIP order's head IS an ear whose
removal leaves an RIP tail (→), and an elimination run IS an RIP order read forward (←).
Confluence (= deterministic-greedy completeness, linear-time decision) is a genuine SEPARATE
theorem, named as a strengthening edge, not smuggled.

**D2 (fuel over well-founded recursion).** Each elimination drops `𝒞.card` by exactly one, so
`card` itself is the fuel: `GrahamN : ℕ → Finset (Finset ι) → Prop` structural in the fuel.
This kills the WF-recursion-under-∃ risk AND makes the Decidable instance a structural mirror
of `decidableRIP` (bounded ∃ over 𝒞 via `decidableDexistsFinset`, subset checks decidable).
`GrahamReducible 𝒞 := GrahamN 𝒞.card 𝒞`.

**D3 (the two-level grammar + the family lift).** `RIPCover : List (Finset ι) → Prop` (teams
only) mirrors `RIP` with `RIP fam ↔ RIPCover (fam.map (·.team))` (the condition only reads
teams). `Acyclic 𝒞 := ∃ order, order.Nodup ∧ order.toFinset = 𝒞 ∧ RIPCover order`. The
family-level headline `glues_of_acyclic` needs the PERM LIFT: from a team-order σ with
`σ.toFinset = (fam.map team).toFinset` (both Nodup) get `σ.Perm (fam.map team)`, then lift the
permutation along `map team` to reorder fam itself; `Consistent`/`Glues` are perm-invariant
(membership-only defs), `RIP` is not (order is the content). Floor the two list lemmas
(Nodup + toFinset-eq → Perm; Perm lifts along map); if the map-lift is absent upstream, prove
by induction on the Perm derivation.

**D4 (Pl_imagine audit).** Risky steps: the toFinset/erase bookkeeping under Nodup
(cons/insert/erase round-trips — floor exact names); cover transport `listCover order =
coverU order.toFinset` (induction, sup-vs-fold alignment: use one primitive, `Finset.sup id`,
with `listCover` defined to fold and a bridging lemma — or define listCover := (·.toFinset.sup id)
directly?? NO: RIPCover's recursion wants the fold form on tails; keep fold + bridge lemma).

**D5 (planned checks, expected verdicts).** #eval: GrahamN on the triangle cover = FALSE, on
the path = TRUE, on ∅ and singletons = TRUE. Post-build kernel facts: `¬ Acyclic {S01,S12,S02}`
and `Acyclic {S01,S12}` BY DECIDE through the new instance — the order-free upgrade of
`speckerFam_no_rip` promised last tick, landing in its natural home.

═══════════════════════════════════════════════════════════
## γ — deliverables
═══════════════════════════════════════════════════════════

`HC/GrahamBridge.lean`: listCover, RIPCover (+ decidable), RIP_iff_ripCover, coverU, ear body,
GrahamN (+ structural decidable), GrahamReducible, **acyclic_iff_grahamReducible** (the bridge,
two fuel inductions), **instance Decidable (Acyclic 𝒞)** (the payoff), perm-lift lemmas,
**glues_of_acyclic** (the order-free amalgamation headline), and the kernel facts
`speckerCover_not_acyclic` / `pathCover_acyclic`. Strengthening edges named: deterministic-greedy
confluence; vertex-ear GYO equivalence.

## Verdicts + Γ-yield

**All deliverables GREEN, 0 sorry, barrel at sixteen layers. Axioms: propext,
Classical.choice, Quot.sound only (decide throughout, no native_decide).**

**D5 verdicts — all as predicted.** Probe: GrahamN triangle FALSE, path/∅/singleton TRUE.
Kernel facts landed through the new instance: `speckerCover_not_acyclic` and
`pathCover_acyclic`, both by `decide` — the six-orderings hack (`speckerFam_no_rip`) is
retired as the load-bearing form; the order-free statement now lives in its natural home.

**D1 held under load.** The nondeterministic `GrahamN` carried the FULL bridge; confluence
was never needed. Both directions compiled as the predicted card-fuel inductions with no
structural change (head-is-ear via the toFinset/erase round-trip; reassembly via
`insert_erase` + `notMem_erase`). Deterministic-greedy confluence remains a named
strengthening edge (linear-time decision), untouched and unsmuggled.

**D2 held verbatim.** Card-as-fuel made `decidableGrahamN` structural on the fuel with the
`haveI`-recursive pattern; no WF recursion anywhere.

**D3 held with one refinement.** The perm lift (`exists_perm_map_eq`) was NOT upstream and
was built by induction on the TARGET list σ (mem extraction → `append_of_mem` split →
`perm_middle` → `cons_inv` → IH → reassemble), cleaner than the fallback plan's induction
on the Perm derivation. `Consistent`/`Glues` perm-invariance are the predicted
`Perm.mem_iff` one-liners. **`glues_of_acyclic` composes exactly as drawn:**
`perm_of_nodup_nodup_toFinset_eq` → lift → `rip_iff_ripCover` → `consistent_of_perm` →
`glues_of_rip` → `glues_of_perm`.

**D4 risks — the errors hit were exactly the audited class.** (i) `∅` invalid in
identifiers (`h∅` → `hempty`): SECOND instance of the ledger entry (first: `hS∩`); now a
confirmed lexical rule — no unicode set symbols in hypothesis names. (ii) `∃ l', l'.Perm l`
needs the binder type ascribed (`∃ l' : List α`) or field notation cannot resolve. (iii)
omit audit must check STATEMENT-level instance references: `Consistent` mentions
`team ∩ team`, so `DecidableEq ι` is referenced and cannot be omitted; the failed omit
cascaded downstream as a spurious "declaration uses sorry" at `glues_of_acyclic` (the known
cascade signature — fix the omit, the cascade clears). (iv) an unused-simp-arg lint where
rfl-substitution absorbed `htf`.

**Process breach, logged honestly.** The first Write of the file carried two literal
`sorry` placeholders in a stubbed perm lift — the SECOND firing of the FiveWayPi failure
mode (never-sorry applies to drafts on disk). Caught at session resume before any compile;
the tail was rewritten complete. The standing rule is reaffirmed and strengthened: hold the
Write until every proof in the file is complete; a hard lemma is written FIRST, not
stubbed last.

**Γ-yield.**
1. **The decidability face is closed.** `Acyclic` (∃ duplicate-free RIP enumeration) is
   DECIDABLE via the bridge — an ∃-over-lists proposition turned kernel-checkable by a
   fueled elimination procedure. With `decidableConsistent`, the amalgamation theorem now
   has FULLY CHECKABLE hypotheses: `glues_of_acyclic` is a certified decision procedure
   for gluing over acyclic covers, closing the PI's rigor request (order-independence
   answered by theorem, not by choice of face).
2. **Reusable infrastructure:** `exists_perm_map_eq` (generic perm lift along any map —
   any future list-of-bundles vs list-of-projections bridge consumes this) and the
   card-as-fuel pattern for decidable elimination procedures on `Finset`.
3. Named next edges: general cyclic converse (every cycle hosts a parity-style non-gluing
   family); deterministic-greedy confluence; C-JLeib≤; the measure-level lift of
   `glues_of_rip`/`glues_of_acyclic` (consistent measure families — where PhysLean's
   quantum marginal instances land, now unblocked on loogle).
