# Fiber-Product URS — the join over a genuine interface (Γ ⟷ γ)

The Leibniz-failure locus tick. Candidates recorded with Γ-provenance and expected verdicts
BEFORE kernel contact; verdicts and the rotation's return leg filled after.

═══════════════════════════════════════════════════════════
## Γ — the derivations (in-model, before any experiment)
═══════════════════════════════════════════════════════════

**D1 (type route: join over one ambient index, not sum-type reindexing).** The fiber product of
structures on OVERLAPPING index sets types painfully as a three-block sum (reindexing hell). The
grammar already owns the clean formulation: one ambient `ι`, two sub-teams `T₁ T₂ : Finset ι`,
factors living on the MARGINAL types, and the join
`join T₁ T₂ κ₁ κ₂ := univ.filter (fun f => T₁.restrict f ∈ κ₁ ∧ T₂.restrict f ∈ κ₂)` —
the natural join / largest structure with marginals inside the factors. At `S = T₁ ∩ T₂ = ∅`
and `T₁ ∪ T₂ = univ` it degenerates to the ⊗ of ProductLaw (a coherence check, deferred).

**D2 (the defect decomposition — the headline, derived in-model).** For the join of κ's OWN
marginals (the 2-reconstruction), under a cover `T₁ ∪ T₂ = univ`:
- `κ ⊆ join` (every configuration passes its own marginal tests — unconditional, no cover);
- the hulls AGREE: for `i ∈ T₁`, `projPi (join) i ⊆ projPi (projS κ T₁) ⟨i⟩ = projPi κ i`
  (the last step is `projPi_projS`), and `⊇` from `κ ⊆ join`; the cover makes every `i` land
  in some `Tⱼ`. Hence with `κ ⊆ join ⊆ hull`:
  **`hcCombPi κ = hcCombPi (join own) + (|join own| − |κ|)`** — the defect splits into the
  join-level defect plus the RECONSTRUCTION GAP. The gap is the quantitative 2-locality failure:
  `gap = 0 ⟺ κ decomposes along (T₁, T₂)`.
- Sanity instance predicted: parity3 with T₁ = {0,1}, T₂ = {1,2}: marginals full ⟹ join = full
  cube ⟹ d(join) = 0, gap = 4 = the whole defect. Shadow-blindness, quantified by the split.

**D3 (two-cover amalgamation — the positive half of the Specker asymmetry).** Two structures
with AGREEING interface marginals always glue: given the cover and
`hcons : κ₁.image (restrict₂ inter_subset_left) = κ₂.image (restrict₂ inter_subset_right)`,
the join realizes both factors as its exact marginals (`projS (join) Tⱼ = κⱼ`). Construction:
for `g ∈ κ₁` pick `h ∈ κ₂` with the same interface restriction (exists by hcons), glue by
`fun i => if hi : i ∈ T₁ then g ⟨i, hi⟩ else h ⟨i, _⟩` (the else-branch's membership from the
cover). No nonemptiness needed: consistency transfers emptiness. This completes the pair with
`specker_not_glues`: two consistent structures ALWAYS amalgamate; three can fail.

**D4 (Pl_imagine audit).** The ⊗-Leibniz law verbatim at a genuine interface is the gated
analogy of this tick (provenance: pattern-continuation from ProductLaw). The in-model prediction
is KILL: the interface correlates the factors, so the (hull,size) bi-grading is no longer
multiplicative. Its kill is the tick's purpose: "Leibniz fails at genuine interfaces" as a
kernel-fact, marking where the flagship's H¹ must carry the correction.

═══════════════════════════════════════════════════════════
## γ — candidates (recorded before kernel contact)
═══════════════════════════════════════════════════════════

Ambient for sweeps: ι = Fin 3, T₁ = {0,1}, T₂ = {1,2} (interface {1}), X = ZMod 2.

| id | statement | provenance | expected |
|----|-----------|------------|----------|
| SJ1 | `κ ⊆ join T₁ T₂ (projS κ T₁) (projS κ T₂)` (no cover needed) | D2 | HOLD uncond. |
| SJ2 | hull(join own) = hull(κ), under cover | D2 hull argument | HOLD ∀ κ at this ι (∅ benign: both ∅); sweep incl. ∅ |
| SJ3 | `hcCombPi κ = hcCombPi (join own) + (|join own| − |κ|)`, under cover | D2 arithmetic | HOLD (nonempty κ at least) |
| SJ3p | parity3 instance: d(join own) = 0 ∧ gap = 4 | D2 sanity | HOLD |
| SJ4 | amalgamation: cover + hcons → `projS (join) T₁ = κ₁ ∧ projS (join) T₂ = κ₂` | D3 construction | HOLD |
| SJ5 | ⊗-Leibniz verbatim at the {1}-interface: `d(join κ₁ κ₂) = d₁·|hull κ₂| + k₁·d₂` | D4 gated analogy | KILL |
| SJ6 | the ≤ direction of SJ5 (boundary probe) | D4 | sweep-only datum |

═══════════════════════════════════════════════════════════
## Verdicts + Γ-yield (filled after)
═══════════════════════════════════════════════════════════

| id | verdict | disposition |
|----|---------|-------------|
| SJ1 | HOLD uncond. | PROVED `subset_join_projS` |
| SJ2 | HOLD (swept incl. ∅) | PROVED `projPi_join_projS` (under cover) |
| SJ3 | HOLD | PROVED `hcCombPi_eq_join_add_gap` — THE DECOMPOSITION |
| SJ3p | HOLD (whole parity defect = gap) | sweep-fact; the decomposition quantifies shadow-blindness |
| SJ4 | sweep blocked (instance synthesis under double binder); D3's construction validated instead by GENERAL PROOF | PROVED `projS_join_left` + `projS_join_right` (direct mirrored gluing; join_comm as API) |
| SJ5 | KILLED | kernel-fact `hcCombPi_join_ne_leibniz` (diag/diag over interface {1}: 6 ≠ 12) |
| SJ6 | HOLD at swept ambient | **CONJECTURE C-JLeib≤**: `hcCombPi (join κ₁ κ₂) ≤ d₁·|hull κ₂| + k₁·d₂` at genuine interfaces — one-ambient evidence, unproved; the "interface only tightens" direction |

**Γ-yield (the rotation's return leg).**
1. The Leibniz EQUALITY is exactly the zero-interface phenomenon: proved at S = ∅ (ProductLaw),
   kernel-refuted at S = {1} (FiberProduct). The failure locus of the derivation law IS the
   interface — the flagship's H¹ must carry precisely the correction term
   `d₁·H₂ + k₁·d₂ − d(join)`, which SJ6 conjectures is nonnegative.
2. The DECOMPOSITION is the first rung of the cohomological ladder built: defect = (2-local
   defect) + (2-locality failure). Iterating along a junction tree is the Vorob'ev induction;
   the gap term is what a Čech H¹ over the cover must compute.
3. Prediction-audit: all four HOLD-expectations held, both KILL-expectations killed, and SJ4's
   instrument failure (not the law) was routed around by proving the general theorem — the
   correct disposition when the probe, not the claim, is the blocker.

**Vorob'ev readiness (assessed):** the amalgamation engine (two-cover case) is proved — it is
the induction STEP. Missing grammar for the Vorob'ev tick: (a) general cover-families
(`fam : ∀ T ∈ cover, Finset (∀ i : T, X i)`) with pairwise consistency and Glues — small,
generalizes P2's inline Specker vocabulary; (b) the ACYCLICITY formalization — the genuine
R-expansion and typing decision: running-intersection-property LIST of teams (induction-friendly,
primary candidate) vs Graham-reduction predicate (decidable, sweep-friendly) — the RIP-list is
the recommended primary with Graham as a later decidability bridge. Positive half = RIP-induction
over `projS_join_left/right`; converse = cycle → generalized Specker family (parity machinery).
PhysLean instances enter after.
