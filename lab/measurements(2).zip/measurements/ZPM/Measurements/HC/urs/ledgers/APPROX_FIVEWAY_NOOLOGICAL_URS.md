# Noological URS (Γ) — me-as-reasoner building the approximate five-way (#14)

Inquiry-axis instrument for MY building of the quantitative HC theorem. The object's proof
obligations live in the companion discovery URS (APPROX_FIVEWAY_DISCOVERY_URS.md); the two are
coupled, never merged (2.4). Frame document: FIELD_NOTE.md (zetesis-puremath canonical copy).

**PROBLEM (one line).** Prove the value-level bridge across the Kolmogorov fork: explicit
two-sided bounds between the base count `hcComb` and the fibre functional (total correlation of
the canonical measure), multipartite, with a monoid-valued off-section knob.

═══════════════════════════════════════════════════════════
## AGENT AXIS (Γ)
═══════════════════════════════════════════════════════════

**A (Will snapshot).** Build #14 per the PI's two fixed decisions: (1) knob = monoid-valued
parameter, Atserias-Kolaitis direction, stated so grading-codomain and weighting-structure are
visibly ONE parameter; (2) multipartite `κ ⊆ ∏ᵢ Xᵢ` is the theorem Prop, bipartite is an instance
witness against the existing `fiveWay_uniform` objects. Acceptance criterion (PI-fixed): the LOWER
leg is the content; the tick is not complete on the upper leg alone. No `sorry`; unproved
obligations are named Prop-defs; every Mathlib name floored by mathlib-search before
`act(formalize)`; kernel is the verifier for all imagined structure.

**Γ-CORRECTION 3 (standing bias, logged).** The field note corrected my framing twice in one
conversation: I proposed "make HC real-valued" (wrong: the integer character is definitional,
base invariants count, they do not integrate) and posed "which HCreal" as an open fork (wrong:
the canonical section settles it). Diagnosis: my substrate's training mass is overwhelmingly
FIBRE mathematics (probability, analysis, entropy functionals), so my defaults pull every
base-object toward a fibre reading. Standing rule for all HC work: before proposing structure,
ask "is this a base statement or a fibre statement, and which side does my proposal silently
move the object to?" The upper/lower asymmetry is the litmus: upper legs crawl to fibres
(my comfort zone, low η); lower legs are base-forcing (the field's content, where predictions
live). Route my effort to the lower legs deliberately, against the pull.

**R-moves (this task).**
- UU→UK→KU already executed by the PI's frame + decisions: "quantitative five-way" is now
  articulated as "quantitative faithfulness of the canonical section," multipartite, one-dial.
- NEW R structure I must generate (imagine-moves, kernel-gated): (i) `totalCorrelationReal` (the
  Π-analog of `mutualInformationReal`); (ii) the multipartite ignorance-structure substrate
  (projections, hull, `hcComb` over `∏ᵢ Xᵢ`); (iii) the K-weighted layer (A-K direction).
  Gate discipline for (iii): the kernel verifies typeability and instances but CANNOT adjudicate
  signature design (many signatures compile). Honest protocol: the MINIMAL signature exercised by
  the two proved instances (Boolean/canonical → recovers the uniform theorem; ℝ≥0/mass-floor →
  the off-section corollary). Any field or law not exercised by a proved instance is decoration
  (A4) or explicitly CONJ. The "one dial" identification (grading codomain = weighting structure)
  is the PI's conjecture: my job is to make the statement SHAPE exhibit it (one parameter,
  two specializations), never to claim it proved.

**M-moves (do· classes).** M-Construction for the substrate defs (multipartite hull, uniform
measure on a Finset of a Π-type); M-Bridge for the bipartite witness (new defs ↔ the existing
`hcComb`/`projL`/`projR`/`uniformMeasure` objects, via `MeasurableEquiv.piFinTwo`-family);
M-Pipeline for the lower leg (Pinsker ∘ TV-versus-forbidden-cell-mass ∘ product-marginal
computation); M-BoundedAverage for the upper leg (entropy/counting). Will-relative boundary:
manipulable = def spellings, proof routes, file layout; held-constant = the two PI decisions,
the lower-leg acceptance criterion, green build.

**Γ_core.**
- Coh_{ens↔Will}: "shape forces information at the canonical measure, quantitatively" is the
  field note's own thesis made theorem-shaped; coherent. The build also serves the §10 program
  (first installment of the graded signature) and the crypto pipeline (leakage floors): one build,
  three Will-threads, no conflict.
- Pl_imagine: LOW and gated on four spots: (a) the exact lower-leg constant/shape (Pinsker route
  is candidate, not banked; the kernel decides); (b) the K-signature design (minimal-instance
  protocol above); (c) the Atserias-Kolaitis citation (direction named by the PI; exact reference
  UNVERIFIED, mark [to-verify], never fabricate); (d) the "NFL factors through the lower leg"
  observation is UK to carry, not bank (named in the discovery URS as a CONJ edge for the field
  note's landed-contact list, gated on proof).

**Known unfloored KUs at write time (learning-route, resolve by search before formalize).**
- ZPM Pinsker: the barrel imports `ZPM.InformationTheory.Pinsker.Basic` but my grep returned
  empty; the file path or the statement name is UNKNOWN. Do not assume its exact form.
- Whether Mathlib/ZPM has finite-support entropy (`measureEntropy`?) or whether the upper leg
  should avoid entropy entirely and run on klDiv counting directly.
- `Measure.pi` marginal-map lemmas on discrete Π-types; `PMF.uniformOfFinset.toMeasure.map (eval i)`
  computations; `MeasurableEquiv` between `∀ i : Fin 2, X i` and `X 0 × X 1` and its measure-pi
  bridge (`Measure.pi` over `Fin 2` ↔ `Measure.prod`).

═══════════════════════════════════════════════════════════
## COUPLING (Γ ↔ γ)
═══════════════════════════════════════════════════════════

My imagine-moves (TC def, multipartite substrate, K-layer) GENERATE the askability; the discovery
URS (typing-derivation, next) stabilizes them into typed defs + a proof DAG; mathlib-search closes
the name-KUs; the kernel closes the proof-KUs. The lower-leg acceptance criterion couples A (Will)
to γ-completion: γ is not banked until the lower leg is green, whatever else compiles.

**η forecast.** High if the lower leg lands general (multipartite, knob-parameterized): it is the
field's first non-vacuous quantitative prediction and the first theorem-witness of the one-dial
conjecture's statability. The upper leg alone: low η (counting; fibre-crawling), explicitly not
the deliverable.
