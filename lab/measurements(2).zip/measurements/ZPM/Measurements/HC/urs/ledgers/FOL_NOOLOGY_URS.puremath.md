# FOL HC-lift — NOOLOGY URS (Γ-axis: the reasoner's grammar moves)

This is the **Γ / noological** ledger for lifting Hidden Channel Capacity from the
finite propositional setting to first-order logic. It tracks *how I transform what
is askable* — the carrier R-move and the operators that move it. The **discovery
(γ) outcomes** live in the memory `project_hc_in_zpm.md` (the Discovery URS).
Two axes, never merged (noological-urs §2.4).

## A — Will snapshot (held fixed)
Re-derive HC over FOL by **lifting the carrier**, not re-deriving the legs: the
axiom-free `Abstract` layer stays untouched; the propositional cube `{T,F}^σ`
generalizes to the compact Stone space of the formula algebra. Close R1–R3
(the type-space-topology → Polish build) **sorry-free and axiom-clean**, kernel-
verified. No new abstraction, no simplification; a real gap is a Pl-kill to
surface, not smooth.

## R — the grammar move (the lift)
Carrier `{T,F}^σ` (finite valuation cube = finite Stone space) → `St(B)` =
`FirstOrder.Language.Theory.CompleteType T α` (compact Stone space of the
Lindenbaum algebra). The propositional model is the **finite-Stone special case**.
Under Stone duality, `SharedEq`, `IsLeft/IsRight/IsShared`, the fibration, and the
measure substrate all fall out of the *same* dualization — one R-move, the
abstract layer invariant under it.

## M — the operators (by route, noological-urs §2.5)
- `act(search)` [learning, reliable] — m1 scout: Mathlib has `CompleteType` + the
  clopen base `typesWith` but **no topology** (build, not citation); Craig/Beth
  absent (⇒ interpolation leg stays conditional-on-Beth); `PolishSpace`/`Profinite`/
  metrization present. **DONE.**
- `act(formalize)` [reliable, kernel-gated] — instantiate against the real Mathlib
  `CompleteType` API. R1 done; R2/R3 pending.
- `act(communicate)` — import ZPM `ChoquetCapacity`/`AnalyticMeasurability` + FLT
  borel→analytic bridge for the measure-leg integrand (attaches once R3 lands
  `PolishSpace`+`BorelSpace`).

## Γ_core
- **Pl_imagine(path is correct math) = HIGH** — Stone duality is classical; the
  R1 proof was the documented intent of `typesWith` (`typesWith_not` hands it over).
- **Pl_imagine(buildable in Mathlib now) = HIGH for R1 (verified), MEDIUM for R2**
  — compactness of `CompleteType` (closed subset of the Cantor cube of sentences)
  is the genuinely harder node; ingredients present, assembly absent.
- **Coh_ens↔Will = HIGH** — the lift makes the existing propositional HC a *special
  case*, maximally Will-coherent.

## The build plan (R1–R3) and status
- **R1 — Stone topology + clopen base. CLOSED 2026-06-23.**
  `ZPM/Measurements/HC/FOL/TypeSpaceTopology.lean`:
  `instTopologicalSpace := generateFrom (range typesWith)`; `isClopen_typesWith`.
  Sorry-free, axiom-clean (`[propext, Classical.choice, Quot.sound]`; `isOpen` even
  `[Quot.sound]`). Kernel-verified; audited CLOSED in both the ZPM and design-lab
  `measurements` indexes.
- **R2 — compact + T2 + totally-disconnected. CLOSED 2026-06-23.**
  - **Separation half (T2 + totally-disconnected): CLOSED.**
    `TypeSpaceSeparation.lean`: `instTotallySeparatedSpace` (distinct types split by
    the disjoint clopen partition `typesWith φ ⊔ typesWith ∼φ`, covering by
    `mem_or_not_mem`, disjoint by `typesWith_not`) ⇒ `t2Space`,
    `totallyDisconnectedSpace`. Sorry-free, axiom-clean.
  - **Compactness: CLOSED.** `TypeSpaceCompact.lean`: `instCompactSpace`, sorry-free,
    axiom-clean. **Route discovered/refined this tick (act(search)): Alexander's
    subbasis theorem `isCompact_generateFrom`** — this SUPERSEDED the planned cube
    embedding + range-closedness (a genuine simplification-FREE improvement: no
    embedding needed). FIP argument: a basic cover `univ ⊆ ⋃ typesWith φᵢ` ⇒ the
    negation theory `onTheory T ∪ {∼φᵢ}` has empty type-set (`setOf_subset_eq_empty_iff`)
    ⇒ unsatisfiable ⇒ (compactness thm `isSatisfiable_iff_isFinitelySatisfiable`) a
    finite unsatisfiable subtheory ⇒ a finite subcover. Friction resolved:
    `∼`-injectivity (`snot_injective`), `IsFinitelySatisfiable` unfold, the
    finite-sentence→finite-subcover extraction.
- **R3 — Polish + Borel. CLOSED 2026-06-23.** `ZPM/Measurements/HC/FOL/Polish.lean`,
  under `[Countable (L[[α]].Sentence)]` (countable language). Chain, all sorry-free
  axiom-clean: `instSecondCountableTopology` (finite-intersection basis of the
  countable clopen base `range typesWith` is countable, via
  `isTopologicalBasis_of_subbasis` + `countable_setOf_finite_subset`) ⇒
  `instMetrizableSpace` (compact+T2 ⇒ T3, + second-countable ⇒ Urysohn
  `metrizableSpace_of_t3_secondCountable`) ⇒ `instCompletelyMetrizable` (chosen
  metric `metrizableSpaceMetric` is complete by compactness) ⇒ `instPolishSpace`
  (separable + completely-metrizable) ⇒ `instMeasurableSpace := borel _` +
  `instBorelSpace`. Friction resolved: `IsCompletelyMetrizableSpace` from compact
  metrizable needs `metrizableSpaceMetric` + `open TopologicalSpace`.

## ★ BUILD PLAN R1–R3 COMPLETE (2026-06-23)
The first-order type space `CompleteType T α` is now a **compact Polish Borel Stone
space** (clopen-based, compact, T2, totally-disconnected, metrizable, Polish, Borel),
all sorry-free and axiom-clean (the three standard kernel axioms). This is exactly
the carrier ZPM's Choquet/analytic tower and the FLT borel→analytic bridge consume.
The Stone-dual carrier lift is DONE: the propositional finite cube generalized to the
compact type space, abstract layer untouched.

**Next phase (new direction, NOT part of R1–R3):** the FOL HC measure leg —
instantiate the abstract structural legs over `CompleteType` (SharedEq via reduct
maps; interpolation conditional on Beth) and define HC over a Keisler measure
(integrand measurability via the FLT bridge; canonical measure under NIP = the open
frontier).

## FOL FIVE-WAY (R1–R5) — lifting the ignorance factorization (in progress)
The `/loop` R1–R5 lifts the five legs of the Five-Way to first-order ignorance:
`κ ⊆ S × A × B` is the structured ignorance over a shared interface `S` and private
parts `A`, `B` (for FOL, type spaces of sublanguages — the R1–R3 carrier). The legs
are the equivalent conditions under which **the ignorance factors over `S`**.

**R-move (the lift):** Finset → **Set**. The propositional Five-Way (`Fibered`,
`FiberedInterpolation`) was Finset-based (finite supports); the FOL legs are Set-based,
so they hold over the *infinite* type-space coordinates. The geometry legs are
carrier-agnostic (any coordinate types); the FOL-ness enters via the carrier (R1–R3)
for the measure leg.

- **R2/R3/R5 — geometry legs CLOSED 2026-06-23.** `FOL/FiveWayStructural.lean`:
  Set-based `Decomposable` (ii), `FiberRect` (iii), `FiberProductSurjective` (v) over
  `{S A B : Type*}`; `fiveWayStructural_tfae` proves them mutually equivalent.
  Sorry-free, axiom-clean (`decomposable_iff_fps` needs **no axioms**). The ignorance
  factoring over the shared interface, three equivalent ways, for any coordinate types.
- **R1 — interpolation. CLOSED 2026-06-23.** `FOL/FiveWayInterpolation.lean`:
  Set lift of `FiberedInterpolation` — `SatP/SharedEqP/IsLeftP/IsRightP/IsSharedP`,
  `HasInterpolationProperty`, `interp_iff_decomposable` (via `forward_/reverse_direction`),
  `shared_definability` discharged (Beth-level witness; Craig-conditional by design).
  Sorry-free, axiom-clean. **The proofs carried over from the Finset template verbatim**
  (they were first-order logic over membership; the `DecidableEq` instances were never
  used). `fiveWay_fol` ties **R1/R2/R3/R5 into one TFAE** — interpolation (i),
  decomposability (ii), amalgamation (ii′), fiber-rectangular (iii), fiber-product
  surjective (v) — over the infinite-coordinate ignorance. Audited CLOSED.
- **R4 — conditional independence / measurability obstruction. CLOSED 2026-06-23.**
  *Reframed (Dhruv): the measurability obstruction is the load-bearing leg, and the
  Borel setup (R1–R3) already cleared its ground.* `FOL/FiveWayCI.lean`: the
  factorization obstruction lives in the analytic-vs-Borel gap (marginalizing a
  definable family = an existential projection = an analytic/Suslin set, not Borel);
  the carrier makes it measurable. `analytic_nullMeasurable` (analytic ⊆ type space ⇒
  `NullMeasurableSet`, instantiating ZPM `AnalyticSet.nullMeasurableSet` at the
  Polish/Borel carrier), `marginal_nullMeasurable` (projection of Borel = analytic ⇒
  null-measurable — the integrand made well-defined), `mi_eq_zero_iff_product` (the
  information-theoretic leg: `mutualInformationReal P = 0 ↔ P` factors, via ZPM
  `mutualInformationReal_eq_zero_iff_product`). Sorry-free, axiom-clean, audited.
  The obstruction leg connects **directly** to the info-theoretic leg: null-measurable
  marginals are exactly what make MI well-defined.

## ★ FOL FIVE-WAY LIFT COMPLETE (2026-06-23) — all five legs closed
- Support-level legs (i interp, ii decomp, ii′ amalgam, iii fiberRect, v fps):
  `fiveWay_fol` (one TFAE, `FiveWayInterpolation.lean`).
- Info-theoretic / measurability-obstruction leg (iv): `FiveWayCI.lean`.
All sorry-free, axiom-clean (`[propext, Classical.choice, Quot.sound]`), vendor-synced,
audited. The propositional Five-Way is now a special case of a first-order statement
over the compact Polish Borel type space.

## Γ_core (this loop)
Pl_imagine(geometry legs) = HIGH (Set-generalization of proven Finset legs; verified).
Pl_imagine(interpolation port) = HIGH (abstract layer axiom-free; the Finset proofs
carried verbatim — DecidableEq was never load-bearing). Pl_imagine(measurability leg) =
HIGH — the Borel carrier (R1–R3) instantiates ZPM's analytic/MI machinery directly; no
new measure needed for the leg itself. Coh_ens↔Will = HIGH (the lift makes the
propositional Five-Way a special case; ignorance-structure framing held throughout).

## ★ DEEP FINDING (2026-06-23, Dhruv probe: "clean lift, or a 7th leg?")
The five "clean" legs lift cleanly **because they are carrier-agnostic** —
`FiveWayStructural` is stated over a bare `κ : Set (S×A×B)` with `{S A B : Type*}` and
never touches the type-space structure; it would hold for finite sets, reals, anything.
So that lift is **shallow** (not deeply first-order). The genuinely first-order content
lives exactly where the lift is NOT clean:
- **Leg iv** changed *interpretation* (support→distribution), not strength: classical
  `FiberCI` rode the canonical *uniform* measure (support-pinned on finite κ); on the
  infinite type space there is no uniform measure, so it detaches into a distribution-
  level statement (`mi_eq_zero_iff_product`) + (classically-trivial, now substantive)
  measurability scaffolding. The measurability obstruction is NOT a 7th leg — it is
  always-true infrastructure — UNLESS a canonical measure is fixed, at which point
  "obstruction-set is null" *does* become a genuine new leg with no finite analog.
- **Amalgamation** in the carrier-agnostic model collapses to `FiberProductSurjective`
  (trivial set-recombination). Genuine FOL amalgamation lives in the *single* type space
  `St(S⊕A⊕B)` with reducts and **can fail** — that failure is the first-order hidden
  channel.

## Genuine FOL amalgamation — CLOSED 2026-06-23 (`FOL/Amalgamation.lean`)
Second instantiation of the axiom-free `Abstract` layer, at the genuine carrier:
`World = CompleteType T (S⊕A⊕B)`, `Sat` = type membership, `IsShared/Left/Right φ` = "φ
is pulled in from `L[[S]] / L[[S⊕A]] / L[[S⊕B]]` along the parameter inclusions
(`lhomWithConstantsMap` + `onSentence`)", `SharedEqT` = agree-on-shared-sentences. Then
`IsDecomposable` *is* `TypeAmalgamable` — genuine type-reduct amalgamation. Landed
sorry-free, axiom-clean (`[Quot.sound]` only): `sharedInvariantT`, `typeReverse_direction`
(the FOL hidden channel — non-amalgamable ⇒ no shared interpolant), `typeAmalgamable_imp_interp`
(forward Maksimova, **Beth-conditional**). The Beth condition IS the genuine discovery:
in the carrier-agnostic case `shared_definability` was a finitary `∃` and provable; over
real types the shared witness must be an actual `L[[S]]`-sentence = Beth definability
(Craig/Beth absent from Mathlib). So the lift is honestly non-clean here, and amalgamation
*strengthens* into a real model-theoretic property.

## Leg-iv FOL end — COMPLETE 2026-06-23 (bridge + separation + unification)
The support↔distribution relationship is now pinned exactly, as three theorems:
- **One-way bridge** (`FOL/LegIVBridge.lean`): `support_prod` — `(μ.prod ν).support =
  μ.support ×ˢ ν.support` (general lemma **absent from Mathlib**, via open-rectangle nbhd
  basis + `prod_prod`) ⇒ `mi_zero_imp_rectangular_support` (MI=0 ⇒ rectangular support,
  any prob measure w/ std regularity). The *easy* direction.
- **Separation witness** (`FOL/SupportDistributionSeparation.lean`): the converse
  **genuinely fails**. `support_distribution_separation` — a concrete `Pcorr` on
  `Bool×Bool` (mass 3/8 diagonal, 1/8 off) with **rectangular support**
  (`Pcorr_support_rectangular`, every point positive ⇒ full grid) that is **not a product**
  (`Pcorr_ne_product`, `Pcorr{(tt,tt)}=3/8 ≠ 1/2·1/2=1/4`). So rectangular support does
  NOT force the distribution to factor; equivalently (via `mi_eq_zero_iff_product`)
  rectangular support with MI≠0. Sorry-free, axiom-clean.
- **Unification witness** (already in `MutualInformation.lean`):
  `mutualInformationReal_uniform_eq_zero_iff_isRect` — at the **canonical/uniform** measure,
  support ⇔ distribution. They coincide exactly there.

So support-level and distribution-level HC are **separated in general, unified only at the
canonical measure** — the precise measure-theoretic form of the **CHSH Pl-kill** (HC is
support-level). The only remaining converse, for the *general* infinite case, is the
canonical support→measure map (generically-stable Keisler measure under NIP) — a genuine
construction, not a defect; the FOL-end characterization itself is now complete.

## η
HIGH throughout — every leg instantiated existing, verified machinery at the new carrier
(the R1–R3 build was the hard part; the legs were assembly). R1/R4 each closed in one
build; R2/R3/R5 in one. FOL Five-Way: 5 legs over ~2 ticks.
