# Cyclic-Converse URS — the capstone: cyclic covers host consistent non-gluing families (Γ ⟷ γ)

The extraction-shaped tick. The audit identified the force (terminality of the natural join +
decidable mortality) and its limit (everything so far was verification-shaped). This URS records
the in-model derivation of the witness engine, including TWO refutations found and absorbed
BEFORE kernel contact, and the surviving extraction condition ♠ with its sweep plan.

═══════════════════════════════════════════════════════════
## Γ — derivations (in-model, before Lean)
═══════════════════════════════════════════════════════════

**D1 (force-grounding).** Non-gluing proofs ride join terminality: if any glue exists, the
natural join is one (the hsub argument of every banked proof, to be crystallized as
`glues_iff_joinFam`). For an affine family the join is the solution set of the union system:
unsolvable system ⟹ empty join ⟹ (nonempty rels) no glue, three lines. The engine's whole
weight therefore sits on: (a) consistency of the constructed family, (b) unsolvability.

**D2 (the affine engine and its support discipline).** Relations = solution sets of F2-linear
constraints (vector, constant) with support inside the team. Marginal behavior of a
single-constraint relation: FULL on an interface iff the support escapes it (absorb at a free
support coordinate — the ParityFamily extension engine, generalized to sub-supports); EXACT
(same affine set) iff the support fits and the partner carries the identical constraint.
Consistency modes: private support (⊄ every other team) needs nothing; shared support demands
exact replication on every team containing it. Unsolvability: a dependency among the DISTINCT
constraints with odd constant sum. Constants via the flip trick: set all constants from a
reference point f₀, then flip ONE constraint whose support is private (breaks no replication
pair); any dependency using the flipped slot once becomes odd.

**D3 (KILL 1 — team-parity DBC refuted in-model).** The skeleton "∃ D with team-parity boundary
w(D) = ∑_{T∈D} 1_T either 0 or landing in a host team" (swept clean at n = 4, 168 antichains,
probe12) is FALSE in general: the 6-vertex ear-free family A = {b,c,p}, B = {a,c,q},
C = {a,b,r} (triangle overlaps, one private vertex each) has independent team vectors and no
landing sum. Kill lesson: 1_T are the wrong canonical vectors; privates poison every sum.

**D4 (the boundary-privacy click — the capstone's structural coincidence).** With
∂T := T ∩ cover(rest): EAR-FREENESS IS EXACTLY "∂T ⊄ T' for every other T'", which is EXACTLY
the private-support condition making boundary-supported constraints consistency-free. The
hypothesis of the theorem is the consistency discipline of the witness class. D3's killer is
witnessed by the boundary parities 1_{∂A}, 1_{∂B}, 1_{∂C} (they sum to 0; each pairwise-shared
vertex sits in exactly two boundaries).

**D5 (KILL 2 — the two-move disjunction refuted in-model).** ♣ := (boundary parities dependent)
∨ (interface landing w(D) ⊆ T'' ∉ D) is ALSO false: add a triple-shared vertex s to D3's killer
(A = {b,c,s,p}, B = {a,c,s,q}, C = {a,b,s,r}, 7 vertices): boundary vectors become independent
(their sum is 1_s ≠ 0) and no sum lands in a single team. BUT the engine still wins: boundary
parities on all three PLUS the correction constraint 1_s (= the boundary sum), whose support
fits inside every team, replicated on all three. Hand-verified: consistent (two-constraint
marginals agree; the span's interface part is {0, 1_s} on every interface) and unsolvable
(dependency ∂A + ∂B + ∂C + 1_s = 0, flip the private ∂A slot).

**D6 (the survivor — condition ♠).** All known witnesses (Specker triangle, tetrahedron, D3's
killer, D5's killer) are instances of ONE datum:
  ♠(𝒞) := ∃ D ⊆ 𝒞 nonempty with supp(∑_{T∈D} 1_{∂T}) ⊆ some team of 𝒞.
Construction from ♠: boundary parities on D + the correction u_D := ∑_{T∈D} 1_{∂T} replicated on
its hosts (u_D = 0: pure boundary case, no correction). Dependency: ∑_D ∂-parities + u_D (used
once) = 0. Odd constants by flipping one ∂-slot (private by ear-freeness). ♠ SUBSUMES: even
covers (u = 0 via ∂ = T when every vertex is shared), the interface move (w(D) ∩ shared ⊆ T''),
and the boundary move (u = 0). The DESCENT lemma (antichain: a bad host T ∈ D moves out of D,
w stays nonzero, |D| = 2 is automatically clean since SΔT ⊆ S forces nesting) upgrades weak
landings to strong ones where needed.

**D7 (the heart, named).** C-♠: every nonempty EAR-FREE family satisfies ♠. This is the single
remaining combinatorial obligation; everything else is derived. Status: open; swept below.
Fallback ladder if a sweep kills C-♠: (i) sub-boundary vectors (constraints on subsets of ∂T,
still private when they contain a witness-per-other-team of ear-freeness); (ii) the full
span-closed constraint game (Čech-H¹ form: kernel of ⊕_T F2^T → F2^V modulo pairwise-exact
elements, relative to a closed subspace family) — each rung stays inside the affine engine,
alphabet ZMod 2 throughout; (iii) alphabet growth (the classical BFMY fallback) only if the
whole linear game dies.

**D8 (assembly plan for the build).**
`HC/CyclicConverse.lean`: earFree + `exists_earFree_core` (greedy elimination, card induction,
from ¬GrahamReducible); core lemmas (antichain; no nesting into eliminated teams — descent along
the elimination order); `glues_iff_joinFam` (the force, crystallized); `affRel` (sub-support
parity relation) + the two marginal lemmas (full when support escapes; exact when it fits);
the ♠-construction theorems (consistency + unsolvability + non-gluing); C-♠; the capstone
`exists_consistent_not_glues_of_not_acyclic` (alphabet ZMod 2); headline iff
`acyclic_iff_forall_consistent_glues` (⟸ capstone, ⟹ glues_of_acyclic). Pl_imagine risk
register: (a) two-constraint teams (a D-member hosting u too): the span {0, ∂T, u, ∂T+u} has
FOUR elements; the marginal argument must handle the interface part of the span, not just the
listed constraints — mitigations: prove the marginal lemma for ≤2-constraint systems by explicit
casework, or choose D minimizing overlap; (b) the ∂-computation grammar (bndry via coverU/erase,
reuse GrahamBridge vocabulary); (c) F2 sums as odd-incidence filters (no fold-instance needs).

═══════════════════════════════════════════════════════════
## γ — candidates (recorded BEFORE the probe run)
═══════════════════════════════════════════════════════════

Probe 13. bndry C T := T ∩ coverU (C.erase T); uD C D := odd-incidence set of {∂T : T ∈ D};
SpadeMove C := ∃ D ⊆ C nonempty, ∃ T'' ∈ C, uD C D ⊆ T''.

| id | statement | provenance | expected |
|----|-----------|------------|----------|
| K6 | D3's killer is ear-free ∧ fails team-parity DBC | D3 hand-derivation | HOLD (verifying the kill mechanically) |
| K7 | D5's killer is ear-free ∧ fails BMove ∧ fails IMove ∧ satisfies ♠ | D5 hand-derivation | HOLD |
| S-tetra | tetrahedron satisfies ♠ | D6 (D = {abc,abd}, u = {c,d} ⊆ acd) | HOLD |
| S4 | every nonempty ear-free antichain at n = 4 satisfies ♠ | C-♠ | HOLD (0 violations) |
| S5 | every nonempty ear-free antichain at n = 5 satisfies ♠ (full DFS enumeration) | C-♠ | HOLD (0 violations) |
| S6 | every nonempty ear-free antichain at n = 6 with ≤ 4 teams satisfies ♠ | C-♠ | HOLD (0 violations); this stratum contains K6-type patterns |

A violation anywhere = KILL of C-♠ at that instance → the D7 fallback ladder engages, with the
violating instance as the new engineered-ignorance seed. Oscillation is expected AT C-♠'s proof,
not necessarily at these sweeps (n ≤ 6 may be too small to kill ♠; a clean sweep is evidence,
not proof — the proof obligation remains open either way).

═══════════════════════════════════════════════════════════
## Γ — second derivation block (post-sweep audit)
═══════════════════════════════════════════════════════════

**D9 (A4 ALARM — ♠ as swept is VACUOUS).** D = {T}, T'' = T gives u = ∂T ⊆ T on EVERY cover:
SpadeMove is a tautology and the 0-violation sweeps (S4/S5/S6) measured nothing. Valid residue:
the kill verifications K6/K7 (those predicates are non-vacuous), the ear-free censuses
(41 at n=4; 4572 of 7580 at n=5 — the count matches Dedekind M(5), validating the enumerator;
5590/30100/201075 at n=6 for m=3/4/5), and the bitmask-vs-Finset cross-validation at n=4.
The singleton datum is degenerate for the ENGINE: the correction constraint cancels the
boundary constraint at the same slot, leaving the trivial dependency. The predicate must
encode engine-realizability, not landing alone.

**D10 (constants are per-vector — the flip needs no privacy).** Consistency forces equal
constants only for THE SAME vector replicated across teams; so the constant assignment is any
function c : W → F2. Unsolvability = c odd on one global dependency; local solvability +
interface coherence = c even on all team-local relations. The privacy machinery of D6 was
solving a non-problem.

**D11 (the ear-chain lemma — outside teams collapse to the core).** If a used vector x
(supported in the core's cover) fits inside an eliminated team V, then at V's elimination stage
x ⊆ V ∩ cover(stage ∖ V) ⊆ V's ear-witness; induction along the run lands x inside a CORE
member. So replication demands and interference conditions chain down: all conditions are
core-level. (Concrete instance forcing this: adjoin V = ∂A ∪ {fresh} to the K7 core — V is an
ear, gets eliminated, yet contains a used boundary; replication with per-vector constants
handles it, and the chain lemma says that is the general case.)

**D12 (the closure-rank criterion — the engine in one condition).** Close W under intra-team
subset sums (each landing sum is enforced and replicated; finite, core-anchored by D11). Local
relations (F2 vectors over W-indices): for each team V and each S ⊆ W_V with ∑S = 0: 1_S; with
∑S = w ∈ W: 1_S + 1_w. Witnessing c exists iff r := 1_{W₀} (the global dependency: D-boundaries
+ u, each used once — distinctness of W₀ required) is OUTSIDE span(local relations). This one
rank test encodes: local solvability, derived-constant coherence, interface span-agreement
(closure makes span(W_V) ∩ F2^I = span(W ∩ F2^I) on both sides of every interface), and
oddness. The two named Lean obligations downstream: the AFFINE MARGINAL LEMMA (projS of an
F2-affine solution set = solution set of the interface-visible span — elementary extension
argument, reusable program-wide) and the heart C-ENGINE below.

**C-ENGINE (the heart, final form).** Every nonempty ear-free cover admits D ⊆ 𝒞 with
W₀ := {∂T : T ∈ D} ∪ {u := ∑∂T if ≠ 0} distinct, u hosted if nonzero (|D| ≥ 2 if u = 0), and
r ∉ span(local relations) after closure. Fallback ladder if killed: sub-boundary vectors
enlarge the candidate W₀; then the full span-closed game (Čech-H¹ form); alphabet growth last.

## γ — candidates, round 2 (recorded BEFORE probe 13d)

| id | statement | provenance | expected |
|----|-----------|------------|----------|
| E-tetra | tetra passes EngineWitness (D = {abc,abd}, u = {c,d}) | D12 + hand-check | HOLD |
| E-K6 | K6 killer passes (D = all, u = 0) | D12 + hand-check | HOLD |
| E-K7 | K7 killer passes (D = all, u = {s}, NI verified by hand) | D12 + hand-check | HOLD |
| E4 | all 41 ear-free antichains at n=4 pass EngineWitness | C-ENGINE | HOLD (genuine risk now — predicate is non-vacuous) |
| E5 | all 4572 at n=5 pass | C-ENGINE | HOLD |
| E6 | all n=6 cores, m = 3,4 (and 5 if the interpreter allows) pass | C-ENGINE | HOLD; a kill here fires the sub-boundary rung |

## Verdicts (probes 13a–13f)

Round 1 (♠): S4/S5/S6 returned 0 violations — VOIDED by D9 (predicate vacuous). Valid residue:
K6 kill verified (ear-free ∧ ¬DBCweak); K7 kill verified (ear-free ∧ ¬BMove ∧ ¬IMove); ear-free
censuses 41 (n=4) / 4572 of 7580 = M(5)−1 ✓ (n=5) / 5590+30100+201075 (n=6, m=3..5); bitmask
engine ≡ Finset definitions at n=4 (41 = 26+8+6+1, exact stratum match).

Round 2 (EngineWitness, non-vacuous closure-rank): E-tetra HOLD ✓, E-K6 HOLD ✓, E-K7 HOLD ✓
(each for the derived reason). E4 HOLD: all 41 at n=4, 0 violations. E5 HOLD: all 4572 at n=5
(m ≤ 10 complete; tail 115+20+2 = 137 matches the census exactly), 0 violations. E6 HOLD:
n=6 m=3 (5590, 0), m=4 (30100, 0), m=5 (201075, 0). Total: 241,378 ear-free cores, 0 violations.

═══════════════════════════════════════════════════════════
## Γ — CONSOLIDATION (noological, restrict mode; post-sweep)
═══════════════════════════════════════════════════════════

PROBLEM: ground the cyclic-converse capstone; formalize the witness engine as the field's toolset.

— object axis (γ), component by component —
KK (kernel-banked): the fifteen-layer HC substrate; glues_of_rip; glues_of_acyclic;
  decidableAcyclic; the probe engines (bitmask ≡ Finset cross-validated at n=4).
KK-in-model, kernel-pending (derived + hand-verified, formalize this tick):
  1. join terminality (glues_iff_joinFam) — already implicit in three banked proofs;
  2. Δ-additivity of parity functionals (char-2 arithmetic);
  3. solvable_of_coherent — ELEMENTARY route derived: Gaussian step at (x, w₀), image system
     H' avoids x, c' well-defined BY coherence at collisions, dependency-lift with parity
     bookkeeping, induction on |H|; no duality API needed;
  4. the affine marginal lemma — REDUCES to 3 on the pinned system (pinned coherence verified
     in-model: ∑_D pinned-constants = ∑_D c + parity_{ΔD∩S} g = 0 via closedness + visibility);
  5. consistency of closed coherent families — both interface marginals equal the same
     visible system (corollary of 4);
  6. ¬Glues from a hosted odd dependency — the four-line terminality argument;
  7. ear-free core extraction; the ear-chain collapse (fuel inductions on the GrahamN grammar).
KU (open, next block): C-ENGINE — every ear-free core admits a passing datum. Inv evidence:
  241,378 instances, 0 violations (n≤5 exhaustive, n=6 through m=5). NOT knowledge. The attack
  surface the rank form exposes: which team-local relations can touch a chosen flip vector
  (ear-freeness constrains exactly this); descent lemma available for interface data.
UK: whether the engine's coefficient-general form (arbitrary finite field / abelian group)
  changes the heart's difficulty; whether C-ENGINE needs |D| minimality. Named, not pursued.

— agent axis (Γ) —
A (Will snapshot): rigor-first, A5-first, never-sorry; the capstone is not banked until
  C-ENGINE compiles; sweeps are evidence, never proof.
R-moves this block: team-parities → boundary-parities → correction vectors → per-vector
  constants → closure-rank. Each expansion FORCED by a verified kill, none speculative.
Γ_core status: Pl_imagine was verifier-raised throughout (candidate → decide → verdict);
  that is why three kills landed honestly instead of banking fakes. For the C-ENGINE proof
  it remains GATED: the only admissible verifiers are the kernel and instance-decides; any
  proof sketch stays conjecture (KU) until compiled. For THIS tick (act(formalize) of
  in-model-derived structure) the kernel is the verifier; the elementary solvability route
  deliberately avoids ungated dependence on unfloored duality APIs.
η: three kills + one vacuity-catch + one surviving engine + 241K checks, all pre-kernel;
  the block's entire cost was probe-time. High.

**Formalization directive (A5-first structure, derived from the consolidation).**
The engine file must be the GENERAL toolset, independent of ears/Graham/cores:
`HC/AffineEngine.lean` = parity grammar (parityOn, wsum, Δ-additivity, xorSum by fold with
local Std instances) → solvable_of_coherent (elementary Gaussian induction) → affLocal
(uniform replication rule internalized: every team enforces every fitting constraint) →
marginal lemma (closed systems) → affFam_consistent + affLocal_nonempty + not_glues_affFam →
the package export `affine_obstruction`. Ear-freeness enters only in the later
CyclicConverse.lean (extraction + chain + C-ENGINE + assembly). Alphabet ZMod 2; the
coefficient-general engine is a named rung, not this file.

**Γ-yield (this block).**
1. The oscillation the PI predicted fired THREE times before kernel contact: C-DBC killed by a
   6-vertex instance; the two-move disjunction killed by a 7-vertex instance; then my own ♠
   sweep caught as vacuous (A4 on the probe, not the claim). Each kill was absorbed by adding
   structure: team parities → boundary parities → correction vectors → per-vector constants +
   ear-chain + closure-rank. The survivor is an ENGINE, not a formula.
2. The capstone's plot armor, named: (i) join terminality (all non-gluing proofs are
   one-object checks); (ii) ear-freeness ⟺ boundary privacy (the theorem's hypothesis IS the
   witness class's consistency discipline); (iii) the ear-chain collapse (the ∀-quantified
   cover reduces to its core); (iv) the closure-rank criterion (consistency + solvability +
   oddness = one linear-algebra condition).
3. Open heart: C-ENGINE (every ear-free core admits a passing datum) — ~276K kernel-checked
   instances, no proof yet. Two named Lean obligations: the affine marginal lemma (projS of an
   F2-affine solution set) and C-ENGINE. Everything else in D8's assembly plan is
   derivation-complete.

## Verdicts, round 3 — the engine is BANKED (HC/AffineEngine.lean, seventeenth barrel layer)

**GREEN: 587 lines, 0 sorry, axioms propext/Classical.choice/Quot.sound.** Contents exactly
per the formalization directive: parity grammar (`parityOn`, `wsum`, transports including
`wsum_restrict₂`, Δ-additivity via char-2 `linear_combination`); `xorSum`/`xorSumL` algebra
(fold with local Std instances); **`exists_parity_solution`** — the elementary list-Gaussian
solvability core, compiled BY the derived plan (eliminate a vertex, transform the tail,
lift dependencies along `List.sublist_map_iff`; the list formulation dissolved every
image-collision obligation, as predicted); `affLocal` (uniform replication internalized) with
canonical `mem_affLocal_rel` (instance-anchored — the Fintype-context Decidable clash appeared
exactly as the Γ-ledger predicts and the canonical-iff pattern killed it);
**`imarg_affLocal`** — the exact marginal computation via the SINGLETON-PIN trick (the pinned
system is coherent by closedness; one solvability lemma serves nonemptiness AND marginals;
the separate "affine marginal lemma" obligation DISSOLVED into the pin); `consistent_affFam`
(both interface marginals ARE the visible system); `affLocal_nonempty`; `not_glues_affFam`
(the four-line terminality argument); the package **`affine_obstruction`**; decidable
`ClosedAt`/`CoherentAt` (sweep-facing). One surprise honesty gain: `sysCoherent_pinned` never
uses S ⊆ V — the pin argument is stronger than derived.

**Kernel smoke test:** the engine proved `¬ Glues (affFam [A,B,C] 𝒲 δ_{∂A})` for the K6
C-DBC-killer instance end-to-end, all hypotheses by `decide`. The witness class that emerged
from the three kills is now a compiled, instance-validated machine.

**Remaining for the capstone (task #34):** CyclicConverse.lean = ear-free core extraction +
ear-chain lemma + C-ENGINE (the single open heart: produce D, u, and the closure-rank datum
from ear-freeness; the engine consumes it as `ClosedAt`/`CoherentAt`/odd-dependency inputs) +
assembly + the headline iff.

═══════════════════════════════════════════════════════════
## Γ — third derivation block (the heart, by construction)
═══════════════════════════════════════════════════════════

**D13 (the boundary shadow is faithful and clean).** For an ear-free 𝒞 with boundaries
∂T = T ∩ Sh (Sh = shared vertices): ear-freeness ⟺ ∂T ⊆ T' never ⟺ ∂T ⊆ ∂T' never, so the
boundary family ℬ is an ANTICHAIN of DISTINCT NONEMPTY sets, and every vertex of ⋃ℬ = Sh lies
in ≥ 2 members (v shared ⟹ v ∈ ∂T for every T ∋ v). Conversely any such abstract ℬ is realized
by the ear-free cover 𝒞 := ℬ itself (min-degree 2 makes ∂β = β). The heart is therefore a
statement about antichains with min-degree 2; the 241K sweep already covers all instances with
|Sh| ≤ 6.

**D14 (the strong-datum collapse — the engine inputs become trivial).** Call (D, V) a STRONG
datum if u := ∑_{T∈D} 1_{∂T} satisfies u = 0 (even case, |D| ≥ 2) or 0 ≠ u ⊆ ∂V with V ∉ D and
u ⊄ ∂T for every T ∈ D. For a strong datum, with 𝒲 := {∂T : T ∈ D} ∪ {u if ≠ 0} and c := δ_u
(even case: δ_{∂T₀} for any T₀ ∈ D): EVERY TEAM HOSTS AT MOST ONE CONSTRAINT (∂T fits only T by
ear-freeness; u fits no D-team by strength; a u-host fits no ∂T by ear-freeness). Hence ClosedAt
and CoherentAt hold TRIVIALLY (no intra-team sums exist), distinctness holds, the dependency
𝒲 itself is hosted with xorSum ∅ and c-sum 1. C-ENGINE ⟸ strong-datum existence, with the
engine's hypotheses discharged by three one-line lemmas. (K7's weak datum needed the NI/closure
machinery; its DESCENT (D = {B,C}, u = {b,c}, host A) is strong — the descent lemma upgrades
every weak landing on an antichain, terminating at |D| = 2 where strength is automatic.)

**D15 (the kernel reformulation — LAND is a rank statement).** With ℬ independent (else even
datum exists): a landing datum (D, V ∉ D, 0 ≠ ∑_D β ⊆ β_V) exists iff the PUNCTURE at V
(the family {β_T ∖ β_V : T ≠ V}) is F2-dependent — kernel argument: codewords inside β_V form
K_V ∋ β_V; puncture-dependent ⟺ dim K_V ≥ 2 ⟺ some codeword z ∉ {0, β_V} lies in β_V, and
z or z + β_V has a V-free representation. So THE HEART IS:
  **(HeartB) every distinct-nonempty antichain with min-degree ≥ 2 is F2-dependent, or some
  puncture is F2-dependent.**
Trivial sub-case (O-LAND): the full punctured sum is ∑_{T≠V} (β_T ∖ β_V) = O ∖ β_V where
O := {v : deg v odd}; so O = ∅ gives the even datum and O ⊆ β_V gives puncture-V-dependence.
The genuinely open region: O ≠ ∅ and O ⊄ every member (the tetrahedron lives here; its witness
is a pair-difference: β_S Δ β_T ⊆ β_V, which is also the complete m = 3 proof since min-degree
forces every difference into the third member).

**D16 (sweep plan: extract the witness structure, then prove).** Probe 14 sweeps HeartB in
exact form on all strata AND classifies each core by which witness fires: even (dep), O-LAND,
pair-difference, or only-bigger-D. Candidates recorded before the run:

| id | statement | expected |
|----|-----------|----------|
| H4/H5/H6 | HeartB holds on every ear-free core (n=4, n=5, n=6 m≤5) | HOLD (equivalent to strong-data existence; engineDatum held, but strong ⊊ engine-data — genuine risk) |
| W-COVER | dep ∨ O-LAND ∨ pair-difference covers every core | UNKNOWN — the measurement that guides the proof |

If W-COVER holds, the proof target factorizes: ¬dep ∧ ¬O-LAND ⟹ pair-difference, for
antichains with min-degree 2. If it fails, the failing instances are the imagination fuel.

**Verdicts (probe 14).** H4/H5/H6 HOLD (0 violations everywhere); W-COVER HOLD at n ≤ 6
(every core covered by dep ∨ O-LAND ∨ pair; tetra = pair-only, K6 = dep+pair, K7 = O-LAND+pair).

**D17 (KILL 3 — HeartB and the boundary-parity engine are FALSE; found by construction).**
The n ≤ 6 regularity is an artifact. Constructed killer X4 (m = 4, |Sh| = 8): four odd-classes
o₁..o₄ (each βᵢ misses exactly oᵢ) plus a 4-cycle of degree-2 vertices e₁₂, e₂₃, e₃₄, e₄₁:
βᵢ = (O ∖ oᵢ) ∪ {adjacent e's}. Kernel-checked: ear-free, ¬dep, ¬O-LAND, ¬pair, ¬HeartB (all
punctures independent), and ¬engineWitness — the FULL closure-rank engine over boundary-parity
systems has no datum. The strong-collapse route (D14) is sound but its input class was too
narrow. Sub-boundary search on X4: no 3-vector system; a 4-VECTOR SYSTEM EXISTS — the CYCLE
PARITIES wᵢ = {eᵢ₋₁, eᵢ} ⊆ βᵢ, ∑ wᵢ = 0, each hosted at exactly one team: the Specker triangle
generalized to the 4-cycle. The engine (already 𝒲-general) consumes it unchanged.

**D18 (the witness ladder, and completeness at m ≤ 4).**
L1 (even: ℬ dependent) ∨ L2 (landing: some puncture dependent; strong datum via descent) ∨
L3 (B-cycle: k ≥ 3 distinct teams + distinct vertices vᵢ ∈ βᵢ ∩ βᵢ₊₁; witness wᵢ = {vᵢ₋₁, vᵢ}).
Both L1/L2 (D14) and L3 (minimal cycle) yield ≤ 1 hosted constraint per team, so ClosedAt,
CoherentAt, and the odd hosted dependency are discharged by one-line lemmas — no closure, no
rank machinery in Lean. CANONICALIZATION: for the ladder predicates only the presence and
parity of each vertex membership-TYPE matters, so m = 4 has exactly 3^11 canonical forms over
ALL vertex counts: EXHAUSTIVE sweep (probe 16): 127,488 ear-free canonical cores, 0 ladder
failures (with L3 under-approximated — a fortiori safe). m = 5: 29,753 random canonical
samples (probe 17), 0 failures.

**D19 (C-LADDER proof skeleton; one named case open).**
(i) PROVED in-model: if the team-intersection graph H is a forest, a leaf team T has
∂T ⊆ β_S (its unique neighbor): an EAR. So ear-freeness forces H-cycles.
(ii) Minimal H-cycle of length k ≥ 4: chord-freeness (any repeated or cross-cycle shared
vertex yields a shorter cycle) makes consecutive intersection sets pairwise disjoint, so
distinct representatives exist: a B-cycle: L3 fires.
(iii) k = 3 (triangles): representatives exist unless Hall fails: two of the three pairwise
intersections are the SAME SINGLETON {v} (a triple point with collapsed sides). THE ONE OPEN
CASE: an ear-free core all of whose minimal H-cycles are Hall-failing triangles must satisfy
L1 ∨ L2 ∨ (a B-cycle elsewhere). K7 is the near-miss instance (triple point s, but the sides
have second elements, SDR = (c, a, b): its own witness IS a B-cycle).
(iv) Minimality gives ≤ 1-per-team for the L3 system: a team hosting two cycle-vectors gives
a shortcut, contradicting minimal k.

**C-ENGINE, re-chartered (the honest statement after Kill 3):** every nonempty ear-free
family admits a hosted zero-sum distinct system with ≤ 1 constraint per team (equivalently:
L1 ∨ L2 ∨ L3 — the C-LADDER). Everything else in the capstone chain (extraction, ear-chain,
descent, D14-collapse, L3-collapse, engine consumption, assembly) is derivation-complete.
The triangle-Hall case of C-LADDER is the single remaining combinatorial obligation.

═══════════════════════════════════════════════════════════
## Γ — fourth derivation block (the triangle-Hall attack)
═══════════════════════════════════════════════════════════

**D20 (THEOREM, proved in-model: B-cycle existence).** In the bipartite incidence graph B
(teams vs shared vertices): ear-freeness forces min-degree 2 on both sides (a 1-element
boundary is an ear via its vertex's second team). If B had no cycle of length ≥ 6, every
2-connected block is K_{2,n} (ear-decomposition: on K_{2,m}, only length-2 ears between the
hub pair avoid creating 6-cycles; middle-pair ears only at m = 2 where roles swap). Leaf
blocks of the block-tree then contradict ear-freeness: team-hubs S, T with S internal give
β_S = M ⊆ β_T (an EAR); vertex-hubs give two internal teams with equal boundaries (antichain
violation); single-block components likewise. Hence EVERY ear-free core has a B-cycle of
length ≥ 6. This subsumes the old H-forest observation and needs no Hall analysis.

**D21 (proved in-model: long cycles are clean; the engine's death condition).** For the cycle
system wᵢ = {vᵢ₋₁, vᵢ}: the datum dies exactly when some team hosts TWO of the wᵢ (ClosedAt
then demands the sum, cascading; at k = 3 two vectors span the triple). For a SHORTEST cycle
of length ≥ 6: a two-vector host at k ≥ 5 yields a strictly shorter ≥ 6 cycle (arc + host
shortcut); at k = 4 the split host yields a direct 6-cycle (so shortest 8 ⟹ clean); at k = 3
a host means a team ⊇ the whole triple. Hence: shortest length ≥ 8 ⟹ clean datum; the ONLY
obstruction is length-6 with every 6-cycle's triple hosted ("BLOCKED").

**D22 (census of BLOCKED, probes 18).** Blocked cores exist (n=6: 3860 at m=4, 2691 at m=5)
and EVERY one satisfies dep ∨ land (0 final-ladder violations across all strata). Refined:
blocked ∧ ¬dep is nonempty (965 / 1968) and ALWAYS rescued by landing. Structure of
specimens: dep-rescued blocked cores are GRAPH-LIKE (2-element boundaries; blocked ⟺
triangle-free; min-degree-2 graphs contain cycles whose edge sets are F2-even: L1 fires —
this sub-case is PROVED in-model); land-rescued blocked ∧ ¬dep specimens are tetrahedron-like
(pair-difference landings). Also proved in-model (the strong pair-fact): ¬L2 implies NO
pair-difference β_S Δ β_T lands in ANY team.

**D23 (the residual, stated exactly).** OPEN: blocked ∧ independent ⟹ landing. Attack
notes: rep-swaps at a hosted triple either produce an unhosted triple (clean datum) or force
Tᵢ ∩ Tⱼ ⊆ β_W and disjoint outside-parts Aᵢ; the recursion lacks a termination measure so
far. All 241K+127K+30K swept instances comply. This is a genuinely paper-grade combinatorial
lemma (the hard kernel of the classical BFMY converse, sharpened to the affine witness
class); it gets its own tick, not a rushed proof.

**Build directive (this tick): C-ENGINE's machine.** CyclicConverse.lean part 1:
`EarFree` + `exists_earFree_core` (extraction, fuel induction on GrahamN — proof-complete);
`cyclePairs`/`CycleDatum` (verts + hosted + clean, teams eliminated from the datum) with the
cycle-parity algebra (pairs = pointwise Δ of singleton lists; xorSumL is a Δ-homomorphism on
zipWith and permutation-invariant, so the cycle sum telescopes to ∅); `cycle_obstruction` —
the L3 rung consuming `affine_obstruction` with ClosedAt/CoherentAt discharged by cleanliness
(≤ 1 hosted vector per team). L1/L2 constructors + the HeartLadder assembly land with the
D23 tick so C-ENGINE closes as one coherent piece.

## Verdicts, round 4 — the machine is BANKED (HC/CyclicConverse.lean, eighteenth layer)

**GREEN: 285 lines, 0 sorry, axioms propext/Classical.choice/Quot.sound.** Contents:
`EarFree` (+ decidable), **`exists_earFree_core`** (strong induction on the cover; the
Graham-fuel step Or.inr-composes exactly as derived), the cycle-pair algebra
(`pair_eq_symmDiff`, `xorSumL_zipWith_symmDiff`, `xorSumL_perm`, `getElem_cyclePairs`,
`xorSumL_cyclePairs` — the telescoping proof compiled on the derived route: pointwise Δ of
the list against its rotation, homomorphism, permutation invariance, X ∆ X = ∅ —
`nodup_cyclePairs` with mod-arithmetic discharged through `mod_succ_cases` atom-equations),
and **`cycle_obstruction`**: a clean hosted cycle in ANY cover yields a pairwise-consistent
family of nonempty relations over the whole cover that does not glue.

**Kernel smoke tests:** the SPECKER TRIANGLE's non-gluing rederived from the general rung
(`cycle_obstruction _ [0,1,2]`, all hypotheses by decide) — the field note's founding witness
is now an instance of one theorem; and X4 (the HeartB-killer) witnessed through its
degree-2 e-cycle `[4,5,6,7]`. Γ-note: one more sorry-in-draft firing (an unused helper stub),
caught and deleted before compile — third occurrence of the failure mode.

**Remaining for C-ENGINE (the D23 tick):** the blocked-case lemma (blocked ∧ independent ⟹
landing), the L1/L2 datum constructors (D14 collapse, one-liner family), the B-cycle existence
formalization (D20: the K_{2,n}-block argument needs a bipartite-graph mini-grammar or an
elementary reformulation), and the HeartLadder assembly; then the Vorob'ev capstone
(extraction + ear-chain + assembly + the headline iff).

═══════════════════════════════════════════════════════════
## Γ — fifth derivation block (D23 under the question protocol)
═══════════════════════════════════════════════════════════

**D24 (THE QUESTION, posed before evidence — the one I would have asked the PI).**
Q: is the ZMod-2-affine witness class COMPLETE for the capstone? Sharpened: (Q-KILL) does an
ear-free core exist — expected just past the swept horizon, n ≥ 7 — that is blocked at EVERY
cycle length, boundary-independent, and landing-free, killing the whole sub-boundary engine
(kill #4)? (Q-CLASSICAL) what witness class does the classical BFMY converse construction
use — and if its domains grow beyond {0,1}, is that evidence the affine class cannot be
complete, so D23-as-stated is FALSE and the ladder needs an ALPHABET rung, not a proof?
Note the correction Q-KILL forces on D23's own statement: "blocked" must quantify over ALL
cycle lengths (the D22 sweeps checked 6-cycles only; a clean 8-cycle in a shortest-6 core is
possible and would rescue it — unswept until now).

**Γ-routing (the imagination instrument, from my own kill-ledger).** Every kill was found by
neutralizing each rung of the then-current ladder one structural feature at a time under the
ear-free constraint: K6 (privates poison team parities), K7 (triple point forces boundary
independence while blocking landings), X4 (odd-classes + a degree-2 cycle kill all boundary-
level rungs; the sub-boundary cycle rescued it). The D23-killer recipe is therefore FORCED,
not arbitrary: start from X4's skeleton and DIRTY its rescue — every cycle must acquire a
host containing two consecutive pairs — while keeping boundaries and all punctures
independent. Hand-validation of the tension: adding the all-e team {e₁₂,e₂₃,e₃₄,e₄₁} to X4
dirties the e-cycle but immediately CREATES a landing (β₂+β₄+β₅ = {o₂-class pair} ⊆ β₁ —
computed by hand, to be probe-verified). Density (dirtying) fights rank (independence): the
question is whether the fight has a winner at larger n. Both outcomes are results.

**Expected verdicts, recorded before the run.**
| id | statement | expected |
|----|-----------|----------|
| Q-K6C | X4 + all-e-team creates the hand-computed landing | HOLD (verifies the tension) |
| Q-HUNT | randomized + structured hunt at n = 7..9 finds a core with ¬dep ∧ ¬land ∧ no clean cycle (length ≤ 6) | GENUINELY UNKNOWN — base rate from my ledger says kills live one step past the horizon; the density-rank tension says rescues proliferate with size |
| Q-DEATH | any Q-HUNT survivor also fails the general small-system closure-rank search (≤ 5 vectors) | UNKNOWN; a survivor here is kill #4 |
| Q-CLASSICAL | the BFMY converse witness uses domains beyond {0,1} or non-affine relations | UNKNOWN — if affine-expressible, evidence FOR D23; if not, evidence the ladder needs an alphabet rung |

**Verdicts (probes 19 + import).** Q-K6C HOLD ✓ (X4+all-e is ear-free with the hand-computed
landing — the density-rank tension is mechanical fact). Q-HUNT: ZERO killers in 792 exhaustive
X4-extensions and ~145,000 random cores (n = 7..9, m = 4..6). Q-DEATH: vacuous (no survivors).
Q-CLASSICAL: RESOLVED by import (Atserias-Kolaitis, arXiv:2312.02023, generalizing BFMY 1983):
the classical cyclic witnesses are TSEITIN GADGETS — congruence constraints ≡ 0 mod d on all
teams, ≡ 1 on one, contradiction by summing: OUR ENGINE at modulus d. Their reduction: every
non-acyclic hypergraph safe-deletes to an induced-reduced C_k (non-chordality, k ≥ 4) or
H_k = all (k−1)-subsets of k vertices (non-conformality, k ≥ 3; H₃ = C₃), and counterexamples
LIFT back through vertex-pinning (= our dite-splice) and covered-edge marginals (= our
replication). Their mod-d domains serve arbitrary-monoid uniformity, not Boolean necessity.

**D25 (THE ANSWER — D23 dissolves; the final architecture).**
At Boolean semantics the ZMod-2 affine class is COMPLETE, and the heart is not
blocked-vs-landing but CHORDAL-vs-CONFORMAL:
1. Ear-free core ⟹ its primal graph is non-chordal, or it is non-conformal (the classical
   "conformal ∧ chordal ⟹ acyclic" direction — via Dirac simplicial vertices, the ONE
   remaining classical lemma to formalize: chordal ⟹ simplicial vertex; conformality makes
   its closed neighborhood a team-subset; that team is an ear).
2. Non-chordal ⟹ a SHORTEST chordless primal cycle (length ≥ 4) ⟹ CHORDLESSNESS IS
   CLEANLINESS (a team hosting two cycle pairs spans three cycle vertices = a chord) ⟹ the
   banked `cycle_obstruction` consumes it.
3. Non-conformal ⟹ a MINIMAL non-covered clique W, |W| ≥ 3 ⟹ NON-COVEREDNESS IS THE
   ONE-PER-TEAM CONDITION (a team hosting two supports W∖{i}, W∖{j} contains W). |W| = 3:
   the unhosted triangle = clean cycle. |W| ≥ 4: the H_k data — k odd: even datum
   (∑ of the (k−1)-subset parities = 0 since degrees k−1 are even); k even: landing datum
   ({i,j} = (W∖i) Δ (W∖j) hosted by any T_l ⊇ W∖{l}). Kernel-cross-validated: tetra = H₄
   (its landing datum was verified turns ago); X4's e-cycle was chordless.
4. Consumption UNIFIES: even, landing, H_k, cycle are all one theorem — a hosted clean
   system with vanishing F2 sum and nonempty distinct members (`clean_system_obstruction`);
   the rungs differ only as FINDERS. Cleanliness against non-core teams transfers by the
   ear-chain lemma (D11), exactly as predicted there.
5. D23-as-stated is neither proved nor refuted: BYPASSED — the blocked/landing decomposition
   was the wrong frame; the census (dep ∨ land partitioning blocked cores) is retroactively
   explained as the H_k parity split by k, and the Q-HUNT emptiness as the two-terminal-
   structure fact.

Γ-note (the protocol itself): the answer came from the adversarial question, the learning
route (import), and cross-validation against my own kernel-checked instances — not from
unverified generation. The imagination instrument (kill-recipe routing) produced the QUESTION;
the verifiers produced the ANSWER. Remaining Lean obligations, now sharply classical:
primal-graph grammar; shortest-chordless-cycle extraction; Dirac's simplicial-vertex lemma;
minimal non-covered clique extraction; the H_k datum constructors; the assembly.

═══════════════════════════════════════════════════════════
## Γ — sixth derivation block (the Vorob'ev one-shot; derived BEFORE Lean)
═══════════════════════════════════════════════════════════

**D26 (the full chain, each link derived in-model with adversarial audit).**

(L1) mem_xorSum : i ∈ xorSum D ↔ Odd |{w ∈ D : i ∈ w}| — the parity bridge making every
datum-sum a per-vertex count (Finset.induction, fold_insert + mem_symmDiff).

(L2) Grammar: Adj 𝒞 u v := u ≠ v ∧ ∃ T ∈ 𝒞, u ∈ T ∧ v ∈ T; shared 𝒞 := vertices in ≥ 2
teams; ∂T = T ∩ shared; EarFree ⟹ ∂T ≠ ∅ and ∂T ⊄ T' — hence ∂T is a CLIQUE covered only
by T itself.

(L3) THE CLIQUE DATUM (¬conformal case), minimality only: K a non-covered clique of minimal
card (≥ 3 since edges/singletons/∅ are covered). Erase-sets K∖{s} are smaller cliques ⟹
covered. k odd: 𝒲 := image of erase (injective on K); per-vertex incidence k−1 even ⟹
xorSum = ∅ by L1. k even: 𝒲 := {K∖{i}, K∖{j}, {i,j}} with (K∖i) ∆ (K∖j) = {i,j} (an edge ⟹
covered). CLEANLINESS = NON-COVEREDNESS: any team hosting two members contains K. Distinct,
nonempty ✓ (k−1 ≥ 2). Kernel cross-check: the k = 4 instance on the tetrahedron is the H₄
datum already verified by decide; k = 3 odd is the Specker shape.

(L4) THE ONE-STEP GYO COLLAPSE (conformal case): if v is simplicial in the shared-primal
graph and every clique is covered, then K := N_Sh(v) ∪ {v} ⊆ T₀ for some team, and EVERY
team T ∋ v has ∂T ⊆ T₀ (boundary vertices are shared and T-co-hosted with v, hence
Sh-neighbors of v). v shared ⟹ ∃ T ∋ v, T ≠ T₀ ⟹ T is an EAR. No surgery, no induction,
no RIP-lifting: ear-freeness makes the classical GYO induction a single step.

(L5) chordless ⟹ clean: cycle vertices are automatically shared (three consecutive in one
team = a chord for k ≥ 4); a team hosting two cycle pairs exhibits a non-consecutive
co-hosted pair (adjacent pairs: the outer pair at distance 2; separated pairs: an endpoint
pair at distance ∈ [2, k−2]) = a chord. So HasChordlessCycle feeds cycle_obstruction directly.

(L6) THE DICHOTOMY: EarFree ⟹ ¬Conformal ∨ HasChordlessCycle — contradiction-form: EarFree ∧
Conformal ∧ chordal ⟹ Dirac gives a simplicial vertex of G[Sh] (nonempty by L2) ⟹ ear (L4).
THE SINGLE CRUX: Dirac's lemma (finite graph with no chordless ≥ 4 cycle has a simplicial
vertex). Floor Mathlib; else the two-nonadjacent-simplicial strong induction via minimal
separators (the one genuinely heavy classical piece).

(L7) CHAIN EXTRACTION (strengthened D11): exists_earFree_core upgraded to return
∀ w ⊆ coverU 𝒞', (∃ V ∈ 𝒞, w ⊆ V) → ∃ W ∈ 𝒞', w ⊆ W — the same strong induction; the
eliminated ear's witness absorbs w and recursion descends. TRANSFER: full-cover cleanliness
of a core datum: w₁, w₂ ⊆ V ∈ 𝒞 ⟹ w₁ ∪ w₂ ⊆ coverU 𝒞' (members are core-hosted) ⟹ chained
into a single core team ⟹ core-cleanliness applies. Hosting transfers by core ⊆ 𝒞.

(L8) ASSEMBLY: ¬Acyclic ⟹ ¬GrahamReducible (banked bridge) ⟹ core (L7) ⟹ datum (L3/L6+L5)
⟹ transfer (L7) ⟹ clean_system_obstruction (banked) ⟹ the capstone; headline iff with
glues_of_acyclic (banked) via toFinset_toList/nodup_toList.

**Adversarial audit performed on each link** (recorded: minimality soundness in L3; the
Δ-identity; Sh-membership of simplicial neighbors in L4; conformality's quantification over
K ⊆ coverU; k = 4 wrap-around cases in L5; chain-transfer's union move in L7). Failure mode
to guard in Lean: mod-index plumbing in L5 (use the mod_succ_cases atom-equation artillery);
image-collapse parity in L3 (erase is injective on K). If Dirac resists in-session: bank
L1-L5+L7-L8 green, name Dirac as THE single remaining lemma with exact statement — the next
turn imagines with R = everything-but-Dirac.

## Verdicts, round 5 — the one-shot outcome (HC/VorobevConverse.lean, NINETEENTH layer)

**GREEN: 588 lines, 0 sorry, axioms propext/Classical.choice/Quot.sound. Six compile rounds.**
Banked, exactly per the D26 derivation: `mem_xorSum`/`xorSum_eq_empty_iff` (L1); the primal
grammar with decidable `Adj`/`IsClique`/`Covered`/`Conformal` (L2);
**`clean_system_of_uncovered_clique`** (L3 — both parities; the even case via the three-fold
symmetric difference, the odd case via injective-image counting);
**`isEarOf_of_simplicial`** (L4 — the one-step GYO collapse compiled verbatim: no surgery, no
induction); **`clean_of_chordlessCycle`** (L5 — the cross-pair trichotomy chased by
mod-atom-splits + omega, 32-leaf casework in two blocks) and `obstruction_of_chordlessCycle`;
**`exists_earFree_core_chain`** (L7 — extraction with the ear-chain clause) and
**`capstone_of_core`** (the cleanliness transfer through unions);
**`capstone_of_dichotomy`** (L8 — the FULL ASSEMBLY: extraction → dichotomy-case → finder →
transfer → clean_system_obstruction).

**Kernel smoke:** the Specker cover through the assembled capstone end-to-end — its ear-free
core is non-conformal, `hd : ∀ 𝒞' ∈ powerset, EarFree → ¬Conformal` by decide, and
`capstone_of_dichotomy` produces the consistent non-gluing family.

**The one-shot verdict, honest:** NOT complete — one lemma stands. Everything else of the
Vorob'ev converse is kernel-green, and the capstone is now literally a composition awaiting
one input:
  **(DIRAC) a finite nonempty graph with no chordless cycle of length ≥ 4 has a simplicial
  vertex** — instantiated at (shared 𝒞', Adj 𝒞'), feeding isEarOf_of_simplicial to give the
  dichotomy `EarFree 𝒞' → ¬Conformal 𝒞' ∨ ∃ l, IsChordlessCycle 𝒞' l`, which
  capstone_of_dichotomy consumes. Mathlib has NO chordality theory (floored: zero names).
  Proof plan for next turn (classical, two-nonadjacent-simplicial strong induction): minimal
  a-b separator S; S is a clique (two shortest cross-component paths + chordality); induct on
  G[component ∪ S]; a simplicial vertex on each side. Lean needs a small path/reachability
  grammar over Finset-graphs — THE remaining R-expansion.

**Γ-yield (the imagine-sensitive turn).** The load-bearing imagined-then-verified move was
the ONE-STEP GYO COLLAPSE: noticing that ear-freeness makes the entire classical
chordal+conformal ⟹ acyclic induction collapse to "simplicial shared vertex ⟹ ear" — this
deleted surgery, RIP-lifting, and vertex-deletion from the plan, and it compiled exactly as
derived. Second yield: stating the clique finder via cardinality-minimality alone (no H_k
taxonomy). The URS-first protocol held: every Lean block was derived and adversarially
audited in D26 before writing; six compile rounds, no structural rework.

═══════════════════════════════════════════════════════════
## Γ — seventh derivation block (DIRAC, derived before Lean)
═══════════════════════════════════════════════════════════

**D27 (the Dirac leg: statement, proof shape, adversarial audit).** Alternatives audited and
rejected: MCS-correctness (needs the same path-lemma), single-vertex-removal induction (the
classic pitfall: does not induct), direct everywhere-non-simplicial ⟹ chordless-cycle (IS
Dirac's contrapositive), clique-tree route (circular). The separator proof is the floor.

STATEMENT (chosen for zero-friction consumption): over the FIXED primal graph of 𝒞, with the
GLOBAL hypothesis hchord : ¬ ∃ l, IsChordlessCycle 𝒞 l, prove ∀ S nonempty:
∃ v ∈ S simplicial-in-S. The hosting clause of IsChordlessCycle is free when cycles are built
from adjacencies (Adj carries its host), and the global hypothesis is stable under the
S-shrinking induction — no induced-subgraph transport at all.

PROOF SHAPE (strong induction on S.card, strengthened disjunct "S complete ∨ two nonadjacent
simplicial vertices"): a, b ∈ S nonadjacent; Sep := a card-minimal (a,b)-separator inside
S ∖ {a,b} (the full S ∖ {a,b} separates since a path within {a,b} forces adj a b);
A/B := reach-sets of a/b in S ∖ Sep. Facts: A ∩ B = ∅ (reach-transitivity), no A-B adjacency
(neighbor-closure), every x ∈ Sep has neighbors in A and in B (else Sep.erase x separates:
first-occurrence prefix argument). CLAIM (Sep is a clique): x ≠ y ∈ Sep, ¬adj x y: take
MINIMAL-length x→y paths with interior in A and in B (nonempty families via Sep-neighbors +
A-internal connectivity; interiors nonempty since ¬adj ∧ x ≠ y forces length ≥ 3); the
assembled cycle x·intA·y·rev(intB) is nodup, length ≥ 4, consecutively adjacent, hosted —
so by hchord its chordless CLAUSE fails: the resulting chord is killed case-by-case:
within-side chords splice to shorter minimal paths (take(i+1)++drop(j) is a Sublist: nodup,
chain via chain'_append, strictly shorter), cross-side chords violate A-B disjointness, and
the x—y chord is ¬adj. INDUCTION: IH on A ∪ Sep (smaller: b outside); complete-case: any
A-vertex is simplicial there; else of two nonadjacent simplicials at most one is in the
clique Sep, so one lies in A; its S-neighbors lie in A ∪ Sep (Sep or neighbor-closure), so it
is simplicial in S. Symmetrically in B; the two are nonadjacent (A-B). Top level: complete ⟹
any vertex; else the pair (a,b) exists.

ADVERSARIAL AUDIT (R1-R8, recorded): interior-nonemptiness from ¬adj + x≠y; x,y ∉ A ∪ B;
assembled-cycle nodup across the four segments; wrap-pair adjacency (q₁ ~ x by symmetry);
position-alignment of P-consecutiveness with c-consecutiveness under reversal; termination
(A ∪ Sep ⊊ S via b); Sep-clique needed BEFORE extracting the A-side simplicial from the
two-nonadjacent disjunct; both A- AND B-neighbor minimality arguments needed. Lean grammar:
ONE path predicate parameterized by a vertex-Prop; endpoints via head?/getLast?; chords via
getElem + chain'_iff_getElem; minimal length via Nat.sInf; walk→path extraction by
strong induction on length splicing at a duplicate.

---

**D27 CLOSURE (γ — Gate 9, the Dirac leg is GREEN).**
`HC/Dirac.lean` GREEN + installed, barrel at TWENTY layers, 1115 lines, 24 declarations,
0 sorry, axioms `[propext, Classical.choice, Quot.sound]` only (decide-free proof; no
`native_decide`). The full converse now closes UNCONDITIONALLY:

* `dirac_strong` — chordless-cycle-free `S` is complete or has two nonadjacent simplicial
  vertices. Strong induction on `S` via `Finset.strongInduction`.
* `earFree_dichotomy` — the D26 hypothesis of `capstone_of_dichotomy` is now a THEOREM:
  ear-free ⟹ non-conformal ∨ chordless cycle. `shared_nonempty_of_earFree` +
  `isEarOf_of_simplicial` (the one-step GYO collapse from VorobevConverse).
* `exists_consistent_not_glues_of_not_acyclic` — the CAPSTONE, no dichotomy hypothesis.
* `acyclic_iff_forall_consistent_glues` — the headline: acyclic ⟺ pairwise consistency
  forces gluing. Forward via `glues_of_acyclic`; converse via the capstone.

SMOKE (unconditional): `specker_hosts_nonglue` / `specker_not_forall_glues` — the capstone
fires on the REAL `{S01,S12,S02}` triangle purely from `speckerCover_not_acyclic`, with no
gadget built by hand. Axiom-clean.

DERIVATION-vs-FORMALIZATION verdicts (which D27 predictions held, which the kernel corrected):

- **Chain' → IsChain (grammar correction).** D27 named `chain'_append` / `chain'_iff_getElem`;
  this Mathlib pin (fabf563a) renamed the API to `List.IsChain`. Floored via regex before
  writing: `isChain_iff_getElem`, `isChain_append` (seam `∀ x ∈ l₁.getLast?, ∀ y ∈ l₂.head?`),
  `isChain_reverse`, `isChain_pair`, `IsChain.imp`. The predicted proof SHAPE was exactly
  right; only the names moved. UK→KU: "Chain' is not this pin's spelling" is now KK.
- **The `set`-variable motive trap (new KU, resolved).** `rw` on a `getElem` whose bound
  proof mentions a `set`-bound list (`intB`, `c`) fails with "motive is not type correct".
  Resolution: `show`-recast the goal to the unfolded list first, then `rw`. Recorded as a
  reusable pattern (`gcast`/`gcast_list` index-cast helper + `show` before every
  set-variable `getElem` rewrite). This is the single most-repeated fix in the leg.
- **Assembled-cycle segment count = 2, not 4 (simplification that HELD).** D27 feared a
  four-segment nodup argument (x·intA·y·rev(intB)). The kernel-clean form was
  `c := pA ++ intB` (the FULL A-connector, not x·interior·y, concatenated with the reversed
  B-interior): endpoints of pA already carry x,y, so `List.nodup_append` needs only
  pA-nodup, intB-nodup (reverse∘dropLast∘drop sublists of pB), and A/B-disjointness. The
  disjointness needed `hABdisj : ∀ v, QA v → QB v → False` added to `sep_clique_step`'s
  signature — supplied at the call site by `A ∩ B = ∅` (reach-transitivity). R7 audit item
  (four-segment nodup) DISSOLVED under the better assembly.
- **Wrap-pair adjacency confirmed (R4).** The cycle's closing edge `pB[1] ~ x` needed the
  `.symm'` orientation; `hadjc` discharges all consecutive edges including the `% length`
  wrap via `mod_succ_cases`. Held exactly as predicted.
- **Both-side minimality both needed (R8 confirmed).** `no_chord_of_minimal` is invoked on
  BOTH pA (within-A chords) and pB (within-B chords, via the position-translated pB-pair);
  cross-side chords die by `hABnadj`; the x–y chord by `hnadj`. Four zones, exactly the
  audit's forecast. The distance-≥2 arithmetic for each within-side chord is `mod_succ_cases`
  + `omega` on the consecutiveness-exclusion hypotheses.
- **erase_separates (the minimality lemma) — first-occurrence prefix, confirmed.** The
  "every separator vertex has neighbors on both sides" fact is `erase_separates`: if `x` had
  no A-reachable neighbor then `Sep.erase x` still separates (the first `x`-occurrence on a
  violating path has an A-reachable predecessor adjacent to `x`), contradicting card-
  minimality via `Nat.sInf_le`. `{k : ℕ | p[k]? = some x}` needed the explicit `ℕ`
  annotation + `show p[k]? = some x` casts for `Nat.sInf_mem`/`Nat.sInf_le`.

η (validated novelty per effort): HIGH. The programme's single remaining lemma is closed;
the discrete Vorob'ev converse — the discrete skeleton of the HC gluing question — is now a
theorem with a checkable axiom profile. Γ (inquiry): the bespoke path grammar (walks /
reachability / minimal paths / connectors over `List.IsChain`, built because Mathlib has zero
chordality theory) is a reusable R-expansion, not a one-off — it is the substrate any future
induced-subgraph / separator argument in this corpus will import.
