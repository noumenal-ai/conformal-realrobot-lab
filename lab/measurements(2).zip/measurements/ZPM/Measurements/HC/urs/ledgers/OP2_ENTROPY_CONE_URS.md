# OP2-entropy-cone — cover-relative entropy cone contact (working ledger)

Started 2026-07-07. Direction = OP2-entropy-cone. Depends on: [NUM] junction-tree
entropy identity (Theory.md §8), QuantumInfo Entropy/{VonNeumann,SSA,Relative}.lean
(same v4.31.0 pin). No literature search performed; conjectures marked; classical
claims machine-verified in this session (scratchpad op2_check.py / op2_l3.py /
op2_cone.py, three independent probes, 253 + ~1400 + 20000 instances).

## The classical base — banked as [NUM+derivation]

**Setup.** Acyclic cover C of [n] with junction tree J (nodes = teams T, edges =
tree edges carrying separators S = T ∩ T'). Consistent family of marginal supports
κ_T ⊆ ∏_{i∈T} X_i, pairwise agreeing on overlaps. JOIN = natural join / fiber
product = { global x : x|_T ∈ κ_T for all T }.

**L1 (max-entropy extension).** Among all distributions P on X_[n] supported in the
join, the uniform U maximizes Shannon H, and H(U) = log₂|join|. (Elementary: max
entropy on a finite set is uniform. CONCEDED elementary.) The content is L2/L3.

**L2 (junction-tree identity, = [NUM]).** log₂|join| = Σ_nodes H(U_T) − Σ_edges H(U_S)
for U uniform-on-join. Re-verified independently (max err 1.8e-15 / 253 acyclic
instances). Not new as a fact (this IS the [NUM] result); banked as the base point.

**L3 (THE SHARP LEMMA — supporting hyperplane / exactness locus).**
For ANY distribution P supported in the join,
    H(P)  ≤  Σ_nodes H(P_T) − Σ_edges H(P_S)   [junction-tree UPPER bound]
with equality iff P factors through the tree (is Markov w.r.t. J, i.e. every tree
edge has conditional mutual information I(A;C|B_S)=0). Uniform-on-join achieves
equality because it IS the tree-Markov factorization of its own team-uniform
marginals. Therefore:
    log₂|join| = max_{supp P ⊆ join} H(P) = jt-functional at the uniform-marginal point,
and the [NUM] identity is the CONTACT of the junction-tree hyperplane with the
cover-relative entropy region; the cardinality telescope |join| = ∏|κ_T|/∏|κ_S| is
its degradation OFF this face (refuted 80/253 instances, matching Theory.md §8).
Verified: min slack (jt-ub − H(P)) = −4.4e-16 (never negative); 258/298 non-uniform
P on join support strictly interior (I>0).

**L3-2chain (the base cover, exact form).** On teams AB, BC over separator B:
    H(AB) + H(BC) − H(B) − H(ABC) = I(A;C|B) ≥ 0  (Shannon submodularity),
equality iff A–B–C Markov. Verified: min I over 500 random joints = 0.0;
|I| for Markov factorizations ≤ 2.7e-15; uniform-on-join has |I| ≤ 8.9e-16 (so the
identity is exact precisely because uniform-on-join is Markov on the 2-chain).

**Cone statement (candidate law EC, classical half — CONJECTURE, structure verified
on 2-chain).** On an acyclic cover the cover-relative entropy cone (closure of
achievable (H_T)_{T∈C-closure}) is cut out by (i) the Shannon-cone inequalities
restricted to the closure (monotonicity + submodularity along tree edges) and (ii)
NO extra equality; the junction-tree equality Σ_nodes H_T − Σ_edges H_S = H_[n] is a
SUPPORTING hyperplane, not a facet-forcing equality, whose contact face is exactly
the tree-Markov locus. Verified on 2-chain: SSA facet min slack −2.7e-15, region has
interior (max slack 0.627), CMI=0 face populated. STATUS: the "cut out by
submodularity restricted to the tree" claim for n≥4 acyclic covers is CONJECTURE
(reduces to whether restricting the Shannon cone to a junction-tree-indexed
sub-lattice introduces no non-Shannon facets; plausibly true classically since the
classical entropy cone is Shannon on ≤3 vars and the tree localizes constraints to
≤3-var windows, but UNPROVED for the global cone).

## The quantum lift — banked API + the open content named

**Kernel API confirmed (QuantumInfo, v4.31.0 pin):**
- `qMutualInfo ρ = S(ρᴬ) + S(ρᴮ) − S(ρᴬᴮ)` (VonNeumann.lean:84).
- `qConditionalEnt ρ = S(ρᴬᴮ) − S(ρᴮ)` (VonNeumann.lean:80).
- `qcmi ρ = qConditionalEnt ρ.assoc'.traceRight − qConditionalEnt ρ`
  = I(A;C|B) = S(AB) + S(BC) − S(B) − S(ABC) (VonNeumann.lean:95).
- `Sᵥₙ_strong_subadditivity`: S(ABC) + S(B) ≤ S(AB) + S(BC) (SSA.lean:1184). PROVED.
- `qcmi_nonneg`: 0 ≤ qcmi ρ (SSA.lean:1266). PROVED (this IS SSA-as-CMI).
- `qMutualInfo_as_qRelativeEnt`: I(A:B) = D(ρ ‖ ρᴬ⊗ρᴮ) (Relative.lean:2196). PROVED.
- ABSENT anywhere in QuantumInfo: any equality-condition/saturation theorem for SSA,
  any Markov-chain-state def, any Petz map / recovery map, any Fawzi–Renner remainder.
  (grepped: markov/petz/recover/fawzi/renner/saturat → zero hits in Entropy/.)

**Q-SSA (smallest kernel-provable quantum statement — TRUE, IMMEDIATE from `qcmi_nonneg`):**
    S(AB) + S(BC) − S(B) − S(ABC) ≥ 0   for every ρ_ABC.
This is the quantum cover-relative constraint on the 2-chain: the exact operator
lift of the classical 2-chain submodularity. CONCEDED: this is SSA restated over the
cover; formalization-first, NOT open. Its VALUE = it is the quantum-tier facet of the
cover-relative cone, kernel-provable TODAY by one `exact qcmi_nonneg _`.

**Q-EQ (the open content — the equality locus / Petz face):**
    equality S(AB)+S(BC) = S(B)+S(ABC) holds  ⟺  ρ_ABC is a quantum Markov chain
    A–B–C  ⟺  ρ_ABC is Petz-recoverable from ρ_BC by the B→BC Petz map
    (Hayden–Jozsa–Petz–Winter structure theorem: ρ = ⊕_k p_k ρ_{A b_k^L} ⊗ ρ_{b_k^R C}).
STATUS in kernel: the ⟹ direction (equality ⟹ recoverable) and the structure theorem
are ABSENT. This is the classical junction-tree EQUALITY's quantum failure made
precise: classically CMI=0 ⟺ Markov factorization P(AB)P(BC)/P(B) is a DISTRIBUTION;
quantumly S(AB)+S(BC)−S(B) is NOT in general the entropy of any state (the "Markov
factorization" ρ_AB ρ_B^{-1} ρ_BC need not be a valid density operator), so the join
= max-entropy = junction-tree picture BREAKS exactly at non-Markov states, and the
gap is I(A;C|B) = qcmi > 0. THE OPEN LEMMA: characterize the equality face; on the
2-chain it is HJPW-known mathematically but UNFORMALIZED; over general acyclic covers
the "quantum junction-tree theorem" (which covers force gluing under vanishing-CMI
conditions) is the OP1(iii) frontier and appears open as a cover-characterization.

## What HC/SoI machinery contributes BEYOND the literature (honest)

Beyond "SSA restated": the COVER-RELATIVE framing supplies the missing INDEX. Standard
quantum-entropy-cone work indexes by the full powerset 2^[n] and asks for ALL von
Neumann inequalities (famously open n≥4). Our contribution is not a new inequality; it
is a REDUCTION of the index set to a junction-tree lattice, under which (classically,
proven here) the cone is Shannon-cut and the exactness locus is the Markov face, and
(quantumly) the ONLY constraint that survives on the acyclic base is SSA + the Petz
equality face. This makes attackable the SUB-question "on which covers does the
cover-relative quantum cone equal its classical shadow's SSA-relaxation", which is a
finite, tree-localized question, rather than the global cone. The [NUM] identity is
recast as: uniform-on-join sits on the classical Markov face; the quantum obstruction
to the same identity is exactly qcmi, and qcmi=0's characterization (Petz) is the one
missing kernel lemma that would close the 2-chain quantum junction-tree theorem.

## Kill criteria
- If the cover-relative quantum cone on the 2-chain is cut out by SSA ALONE (no Petz
  face needed for any downstream gluing statement), OP2's quantum half collapses to
  "SSA restated" with no open residue → demote to formalization-first.
- If HJPW/Petz-recovery turns out already formalized in some QuantumInfo dependency
  we missed (recheck on build), the "open lemma" is a porting task, not new math.
- If restricting the Shannon cone to junction-tree indices provably introduces
  non-Shannon facets for some n≥4 acyclic cover, the classical EC conjecture is FALSE
  as stated and must be re-scoped to n≤3 windows.

## Precise conjecture list (nothing here banked as proven beyond the [NUM]/API facts)
1. EC-classical (cover-relative cone = tree-restricted Shannon cone on acyclic covers,
   n≥4): CONJECTURE. Verified structurally on 2-chain only.
2. Q-EQ (SSA-equality ⟺ Petz-recoverable, 2-chain): mathematically HJPW-known,
   UNVERIFIED in kernel, UNPROVEN here.
3. Quantum junction-tree theorem over general acyclic covers (OP1(iii) contact):
   OPEN as a cover-characterization; not attempted.
