# Product-Law URS — the AK-monoid codomain decision (Γ ⟷ γ, the rotation explicit)

The instrument for the grading-codomain decision. Unlike prior ticks, the candidate laws are
RECORDED HERE WITH THEIR Γ-PROVENANCE BEFORE any kernel contact, each carrying its expected
verdict; the sweep verdicts then rotate back into a Γ-yield (what the kill-pattern teaches about
the signature). Two axes, coupled at named points, never merged.

═══════════════════════════════════════════════════════════
## Γ — the imagination, engineered
═══════════════════════════════════════════════════════════

**A (Will snapshot).** Decide what the grading codomain must be by PROVING the law family the
juxtaposition operation forces, on the kernel. The field note (§5) says "a monotone grading into
a constructive ordered monoid" with the codomain open — this tick is the experiment that closes
part of that KU.

**The operation algebra (R-move: what is composable).** Three operations present themselves on
the substrate grammar:
- ⊗ (juxtaposition, disjoint interface): `ι₁ ⊕ ι₂`, `X := Sum.elim X₁ X₂`, the relation of pairs.
  Types compose via the pi-over-sum equivalence (floor it). THIS TICK'S OBJECT.
- ∪ (same-index union): hull can JUMP (cross-recombination — the oscillation theorem's own
  mechanism), so no valuation-like law is expected; a refutation here is a boundary worth one
  sweep, not a build.
- ×_S (fiber product over a shared interface): the AK-consistency operation proper; degenerates
  to ⊗ at S = ∅. Where the Leibniz law should FAIL is where H¹ lives — flagship-adjacent,
  scheduled AFTER Vorob'ev (and with PhysLean now on loogle, the quantum instances of ×_S become
  reachable then). NOT this tick.

**Pl_imagine self-audit (the honest part).** My token-level prior pattern-matches "defect" to
"norm/valuation" and wants d(⊗) = d·d' or d + d'. That analogy is EXACTLY the kind of plausible
structure 2.3 gates: recorded below as L-mult/L-add with verdict EXPECT-KILL, because the
in-model arithmetic (next) contradicts them — the sweep will arbitrate between my arithmetic and
my analogy.

**The in-model derivation (imagine, gated).** Write Hᵢ = |hullᵢ|, kᵢ = |κᵢ|, dᵢ = Hᵢ − kᵢ.
IF hull and card are multiplicative under ⊗ (L-hull, L-card below), then
`d(κ⊗κ') = H₁H₂ − k₁k₂ = (H₁−k₁)H₂ + k₁(H₂−k₂) = d₁H₂ + k₁d₂` — **the Leibniz rule of a
derivation**, not a homomorphism law. Two consequences derived before any experiment:
1. The homomorphic invariant under ⊗ is the PAIR `(H, k)` in `(ℕ × ℕ, ×)`; the defect is the
   difference-derivation of that bi-grading. The AK "codomain knob" answer this predicts: the
   ordered-monoid codomain of the signature is the bi-graded `ℕ × ℕ` (equivalently the
   fill-fraction `k/H` multiplicatively), and `hcComb` alone is its shadow — monotone (proved,
   `hcCombPi_projS_le`) but not homomorphic.
2. The ADDITIVE form: `log(H/k)` is additive under ⊗ — and `log(H/k)` is exactly the counting
   bound of the approximate five-way's upper leg (`totalCorrelationReal_uniform_le`). So the
   additive grading the monoid wants is the same quantity the information face already bounds:
   a three-face coincidence (combinatorial bi-grading, additive log-form, TC upper bound)
   predicted in-model. If the sweep sustains L-hull/L-card, this coincidence is a theorem chain.

**The (∅, ∅)-corner standing hypothesis.** Twice now (hull-commutation, monotonicity) the sole
failure class was the empty structure/empty index. Prediction: L-hull fails at empty FACTORS
(a projection of a product with an empty partner collapses) and is repaired by `Nonempty` on
both; the empty-INDEX corners are benign (a factor over no parts is the unit `{emptyFn}` of ⊗ —
the operation has a unit, another monoid datum). Sweep includes all corners.

═══════════════════════════════════════════════════════════
## γ — the candidate family (recorded BEFORE kernel contact)
═══════════════════════════════════════════════════════════

Object: `sumRel κ₁ κ₂ : Finset (∀ i : ι₁ ⊕ ι₂, Sum.elim X₁ X₂ i)`, the image of `κ₁ ×ˢ κ₂`
under the pi-over-sum equivalence (type floor: the dependent `Equiv` name).

| id | statement | Γ-provenance | expected |
|----|-----------|--------------|----------|
| L-card | `(sumRel κ₁ κ₂).card = κ₁.card * κ₂.card` | image of a product under an injection | HOLD (uncond.) |
| L-hull | `hullPi (sumRel κ₁ κ₂) = sumRel (hullPi κ₁) (hullPi κ₂)` | projections of a product are factor projections, IF partner nonempty | HOLD with both `Nonempty`; KILL at an empty factor |
| L-Leibniz | `hcCombPi (sumRel κ₁ κ₂) = hcCombPi κ₁ * (hullPi κ₂).card + κ₁.card * hcCombPi κ₂` | the in-model arithmetic above | HOLD with both `Nonempty` |
| L-mult | `hcCombPi (sumRel κ₁ κ₂) = hcCombPi κ₁ * hcCombPi κ₂` | norm-analogy (Pl_imagine, gated) | KILL |
| L-add | `hcCombPi (sumRel κ₁ κ₂) = hcCombPi κ₁ + hcCombPi κ₂` | valuation-analogy (Pl_imagine, gated) | KILL |
| L-unit | `sumRel` with the empty-index unit `{emptyFn}` is identity (up to the equiv) | monoid structure of ⊗ | HOLD (statement deferred: reindexing equiv needed; recorded, not this build) |
| B-union | `hcCombPi (κ₁ ∪ κ₂) ≤ hcCombPi κ₁ + hcCombPi κ₂` (same index, both nonempty) | subadditivity guess (Pl_imagine, gated); hull-jump argues AGAINST | sweep-only; verdict = boundary datum either way |

**Coupling points.** L-mult/L-add are kept IN the record although the in-model arithmetic
already contradicts them: if the sweep kills them (expected), the kill certifies the arithmetic
AND the Γ-yield "the grading is a derivation, not a homomorphism" becomes evidence-backed, not
narrative. If the sweep SUSTAINS one of them, my in-model arithmetic is wrong somewhere upstream
(L-card or L-hull) — either way the rotation produces content.

═══════════════════════════════════════════════════════════
## Verdicts + Γ-yield (filled after the sweep/build)
═══════════════════════════════════════════════════════════

| id | verdict (sweep) | disposition |
|----|-----------------|-------------|
| L-card | HOLD, unconditional (incl. empties, incl. empty index) | PROVED `card_sumRel` |
| L-hull | HOLD universally at nonempty INDICES (empty factors benign — better than predicted); KILLED at empty index with nonempty κ₁, empty κ₂ (hull of ∅ over no parts = unit); guarded form re-swept clean | PROVED `hullPi_sumRel` with both `Nonempty` |
| L-Leibniz | same profile as L-hull | PROVED `hcCombPi_sumRel` (zify+ring on the ℕ-sub) |
| L-mult | KILLED at n = (2,2) | recorded: the defect is NOT multiplicative |
| L-add | KILLED at n = (2,2) | recorded: the defect is NOT additive |
| L-unit | deferred (reindexing equiv) | named edge |
| B-union | KILLED (both-nonempty subadditivity fails) | boundary datum: the hull-jump under union is real; the grading is not a valuation. The jump is the oscillation theorem's mechanism, now with a quantitative witness class |

**Γ-yield (the rotation's return leg — the codomain decision).**
1. The kill-pattern certifies the in-model arithmetic over the norm/valuation analogies: the
   defect is a **derivation**, not a homomorphism. The homomorphic invariant of ⊗ is the
   bi-grading `(|hull|, |κ|)` in `(ℕ × ℕ, ×)`; `hcCombPi` is its difference-derivation
   (Leibniz), monotone along restriction (`hcCombPi_projS_le`), NOT monotone under union.
2. **Signature revision recommended to the field note (§5):** "a monotone grading into a
   constructive ordered monoid" should read: *the grading is the bi-graded pair
   `(hull, size) : ℕ × ℕ` (multiplicative under juxtaposition, componentwise monotone along
   restriction); the hidden-channel defect is its difference-derivation; the additive scalar
   form is `log(hull/size)`, which the information face independently bounds
   (`totalCorrelationReal_uniform_le`).* The AK "monoid knob" answer at the disjoint interface:
   `(ℕ × ℕ, ×)`, with the scalar shadows (ℕ-difference, ℝ-log-ratio) derived, not primitive.
3. The Γ-corner ledger: the empty-index/empty-structure boundary appeared a THIRD independent
   time (hull-commutation, monotonicity, now the product laws), always via "the empty product
   over no parts is the unit." This is now a named structural constant of the theory
   (the ⊗-unit), not a nuisance: L-unit's deferred statement will make it the monoid identity.
4. Prediction-audit: my corner-prediction for L-hull was wrong in the BENIGN direction (empty
   factors are fine; only the empty index bites). Recorded to recalibrate: the corner lives in
   the INDEX grammar, not the structure lattice.

**Build:** `HC/ProductLaw.lean` GREEN + installed, 0 sorry — `sumRel`, `mem_sumRel`,
`card_sumRel`, `projPi_sumRel_inl/inr`, `hullPi_sumRel`, `hcCombPi_sumRel` (the Leibniz rule),
with the componentwise `Sum.elim` instances. Barrel at thirteen layers.

**Next edges:** the fiber product ×_S over a genuine interface (where Leibniz should FAIL and
H¹ lives — the Vorob'ev-adjacent tick; PhysLean now on loogle for the quantum instances after
that); L-unit as the ⊗-monoid identity; the total-correlation additivity under ⊗ at the measure
level (the informational face of the Leibniz law).
