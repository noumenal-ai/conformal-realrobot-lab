# Higher-Obstruction Discovery URS (γ) — skeleton via typing-derivation

Two files. Every concept typed from the measurement, not the template.

## File 1 — `HC/Marginals.lean` (infrastructure)

**projS (T-Bridge, g_Pl crisp after D1).**
`def projS (κ : Finset (∀ i, X i)) (S : Finset ι) : Finset (∀ i : S, X i) := κ.image S.restrict`
Instances: `DecidableEq (∀ i : S, X i)` from per-part DecidableEq + `FinsetCoe.fintype`. KU-inst.

**The presheaf law (T-Prop) — statement DERIVED from type pressure:** the naive
`projS (projS κ T) …` double-subtypes (marginal of a marginal reindexes over ↥T). The clean law
is the restriction-map form, which is also what a future Čech complex consumes:
`theorem projS_image_restrict₂ (hST : S ⊆ T) : (projS κ T).image (Finset.restrict₂ hST) = projS κ S`
Proof: `image_image` + the composition law `restrict₂ hST ∘ T.restrict = S.restrict` (KU-comp: floor).
Corollary tower functoriality: `restrict₂ ∘ restrict₂ = restrict₂` at the projS level (optional).

**Coordinate compatibility (T-Prop):** `projPi (projS κ S) ⟨i, hiS⟩ = projPi κ i` — the singleton
marginal of a marginal is the original projection (lands homogeneously in `Finset (X i)` because
`X ↑⟨i,hiS⟩ ≡ X i`). Needed by P2's consistency vocabulary and by hull commutation.

**Hull commutation (T-Prop, D3-gated):** `hullPi (projS κ S) = projS (hullPi κ) S` — run the
decide experiment FIRST (parity3, an asymmetric κ, and κ = ∅; the ∅ case may make it
unconditional). Only then act(formalize). If refuted at ∅: add `κ.Nonempty`.

## File 2 — `HC/HigherObstruction.lean` (the theorem pair)

**parity3 (T-Construction):**
`def parity3 : Finset (∀ _ : Fin 3, Fin 2) := Finset.univ.filter (fun f => f 0 + f 1 + f 2 = 0)`
(constant family; derived Decidable instances only — no Classical in the decide goal).

**P1 shadow-blindness (M-Construction, decide):**
`theorem parity3_shadow_blind : (∀ S : Finset (Fin 3), S ≠ Finset.univ → IsRectPi (projS parity3 S)) ∧ hcCombPi parity3 = 4`
Decidability stack: IsRectPi = Finset eq (decidable), ∀ over Finset (Fin 3) (fintype). decide-risk:
subtype-pi kernel reduction over ≤ 8-point spaces; fallback = explicit 6-case split, rfl per case.

**P2 non-gluing family (typed via the projS grammar, NOT a new structure — η check).**
Family: `fam : ∀ S : Finset ι, S.card = 2 → Finset (∀ i : S, X i)`.
1-consistency (homogeneous via projPi-at-subtype-element — no double subtype):
`Consistent fam := ∀ S hS T hT i (hiS : i ∈ S) (hiT : i ∈ T), projPi (fam S hS) ⟨i, hiS⟩ = projPi (fam T hT) ⟨i, hiT⟩`
Glue: `Glues fam := ∃ κ, ∀ S hS, projS κ S = fam S hS`.
Witness (Specker triangle over `fun _ : Fin 3 => Fin 2`): κ₀₁ = diag, κ₁₂ = diag, κ₀₂ = antidiag.
`theorem specker_not_glues : Consistent speckerFam ∧ ¬ Glues speckerFam`
decide-risk HIGH on the ¬∃ (256 candidate finsets × marginal checks): try decide; fallback manual
(the a=b, b=c, a≠c parity contradiction, ~10 lines).
A4 note (from D2): the "always glues at arity 2" companion is a reindexing tautology — dropped;
P1 carries the degree statement, P2 carries only the genuine non-gluing existence.

## Ignorance ledger
KK: Multipartite substrate; image_image; piFinset API; parity extension argument (D2).
KU: KU-comp (restrict₂ composition law names), KU-inst (subtype-pi instance stack),
KU-hull (D3 experiment then proof), KU-decide (reduction behavior — resolved empirically).
UK: none remaining articulable at this scope; the general-n parity family and the Vorob'ev
acyclicity horizon are named follow-up edges, not this build.

═══════════════════════════════════════════════════════════
## OUTCOME (γ — Gate 9): both files GREEN + installed, 0 sorry, barrel at ten layers
═══════════════════════════════════════════════════════════

**`HC/Marginals.lean`** — `projS` (Mathlib `restrict` grammar per D1), `decidableIsRectPi`
(the instance whose absence blocked every quantified decide — probe-diagnosed),
`projS_image_restrict₂` (the presheaf law, one line on `restrict₂_comp_restrict` exactly as
D1 predicted), `projPi_projS` (coordinate compatibility, `rfl`-tight), `piFinset_image_restrict`
(section-extension: restriction image of a product of nonempty factors is the product of
restricted factors — the genuinely new combinatorial lemma), `hullPi_projS` (hull-marginal
commutation, `κ.Nonempty` SHARP).

**`HC/HigherObstruction.lean`** — `parity3_shadow_blind` (every proper marginal rectangular ∧
defect = 4, by decide, kernel-fast), corollaries `parity3_proper_marginals_rect` /
`hcCombPi_parity3` / `parity3_not_isRectPi`; `specker_consistent` (1-consistency by decide) +
`specker_not_glues` (manual 12-line parity contradiction — the kernel's decide over 256
candidate relations hit maxRecDepth, so the informative proof replaced the enumerative one).

**Experiment ledger (the D3 story, a full oscillation of the method).** The imagined hull
commutation law survived three #eval refutation sweeps (parity3, asymmetric kA, ∅ at fixed S) —
then the GENERAL PROOF ATTEMPT exposed the case my sweep never exercised (`κ = ∅, S = ∅`: empty
product over no parts is a singleton), the counterexample was kernel-verified (`hc_probe4`,
exit 0), and the law landed with its sharp `Nonempty` hypothesis. Gated imagination worked
exactly as designed: probe, attempt, refute, sharpen, prove. Second empirical yield: the missing
`Fintype (Finset (Fin 3))` instance (import `Mathlib.Data.Fintype.Powerset`) was the sole root
cause of every quantified-decide synthesis failure.

**What this banks for the flagship.** The acceptance tests are now kernel-facts: any candidate
complex must (i) vanish on all proper shadows of `parity3` yet detect its defect 4, and
(ii) obstruct the Specker gluing. The presheaf grammar (`projS`, `restrict₂` compatibility,
hull endomorphism) is the substrate the complex will be defined on. Named follow-up edges:
the general-n parity family (`hcCombPi = 2^(n-1)`, extension argument), the Vorob'ev acyclicity
horizon for the amalgamation leg, and the law-hunting decide-sweeps for the AK-monoid grading.

═══════════════════════════════════════════════════════════
## OUTCOME 2 (γ — Gate 9): parity schema + the monotone-grading law. Barrel at eleven layers.
═══════════════════════════════════════════════════════════

**`HC/ParityFamily.lean` (GREEN, 0 sorry).** `parityRel n` over `ZMod 2`; `parityRel_three`
(the `n = 3` member IS `parity3`, by decide — schema meets witness); `exists_extension` (the
one-free-coordinate parity-absorption engine); `projS_parityRel` (proper marginals are FULL, the
statement upgraded from rectangular during typing); `isRectPi_univ`; `card_parityRel = 2^(n-1)`
for `n ≥ 1` (restriction away from one index is injective on parity onto the full cube — the
count rides the fullness theorem, no separate bijection); `hullPi_parityRel = univ` and
`hcCombPi_parityRel = 2^(n-1)` for `n ≥ 2` (sharp: `n = 1` has defect 0, the engineered L2
refutation); `parityRel_shadow_blind` — the ∀-n theorem schema.

**`HC/Marginals.lean` gains `hcCombPi_projS_le`** — THE MONOTONE-GRADING LAW: on nonempty
relations, a sub-team's defect never exceeds the team's. This is the "monotone grading into an
ordered monoid" law of the graded-cylindric signature (field note §5), now kernel-fact. Proof by
fiber counting over the restriction map through `hullPi_projS`.

**The forced oscillation (the PI's instruction, executed).** The law was derived in-model with a
fiber-counting sketch; the UNIVERSAL decide-sweep (every structure, every sub-team, n = 2 and 3)
REFUTED it — the sketch was wrong at the same `(∅, ∅)` corner that broke hull-commutation. The
corner was confirmed as the sole failure class (`hcCombPi (projS ∅ ∅) = 1 > 0`), the law
resharpened with `κ.Nonempty`, re-swept clean universally, then proved. Same boundary, witnessed
twice, now carried by two theorems' hypotheses: the empty product over no parts is a structural
boundary of the marginal theory, not an accident. Second engineered refutation: L2 stated
over-sharp (n = 1 included) fell exactly at n = 1, carving `hn : 2 ≤ n`.

**Γ lessons banked:** `push_neg` deprecated → `push Not`; `Finset.not_mem_erase` →
`notMem_erase`; double `← sum_coe_sort` rewrites re-match their own output (use direct
`sum_congr` with subtype-membership application instead); the minimal-import closure lacks
`positivity`/`sum_le_sum` (order-BigOperators import or `Nat.two_pow_pos`).

**Remaining edges:** exact five-way closure at arity n (TC-zero ⟺ IsRectPi — one direction
already a corollary of the quantitative legs); Vorob'ev acyclicity horizon; AK-monoid product
law sweeps; the flagship complex (paper-first, its falsifier suite now three kernel-facts strong:
parity3, Specker, parityRel-schema).

═══════════════════════════════════════════════════════════
## OUTCOME 3 (γ — Gate 9): the exact five-way at arity n. Barrel at twelve layers.
═══════════════════════════════════════════════════════════

**`HC/FiveWayPi.lean` (GREEN, 0 sorry).** `fiveWay_uniformPi` — a genuine FIVE-leg TFAE:
[IsRectPi, hcCombPi = 0, TC(uniformPi) = 0, cross-closure, the counting identity
∏ᵢ countPi κ i (f i) = ite (f ∈ κ) |κ|^(n-1) 0]. Supporting: `prod_prod_erase` (the
double-product identity, pair-counting via `prod_comm'`), `countPi_piFinset` (= Mathlib's
`Fintype.card_filter_piFinset_eq` — D2 was upstream VERBATIM, the learning route at its best),
`prod_countPi_of_isRectPi` (the ℕ backbone), `uniformMeasurePi_eq_pi_of_isRectPi` (the
measure-factorization face, `ext_of_singleton` + the backbone + `ENNReal.mul_inv_cancel`, with
the `card ι = 0` branch handled via the IsEmpty singleton argument),
`totalCorrelationReal_uniformPi_eq_zero_iff` (the exact information leg, forward from the
quantitative lower leg's positivity, backward through the factorization + `klDivReal_eq_zero_iff`
at `klDiv_self`).

**Engineered-sweep yield (the fifth leg).** The over-sharp converse probe — does the counting
identity CHARACTERIZE rectangularity? — SURVIVED the universal sweep at n = 2, 3, so the
identity was promoted from proof-internal backbone to a leg of the TFAE (5 → 4: a
permitted-but-forbidden configuration has all counts positive, contradicting the vanishing
branch). The exact five-way now has a purely arithmetic face alongside the combinatorial,
information-theoretic, and closure faces.

**Γ note (A4 self-catch, recorded).** During drafting I wrote two `sorry` placeholders into the
calc skeleton of the factorization proof — caught on the next action and rewritten in full
before any compile. The standing never-sorry constraint applies to DRAFTS on disk, not only to
banked files: write complete proofs or hold the Write.

**Remaining edges:** AK-monoid product-law sweeps (hcCombPi of products/disjoint unions — the
codomain decision instrument); Vorob'ev acyclicity horizon (which interface hypergraphs force
gluing — the amalgamation leg's home); the flagship complex (paper-first; falsifier suite:
parity3, Specker, parityRel schema, and now the factorization identity as the H⁰-normalization
any candidate complex must reproduce).
