# Noological URS (Γ) — me building the first-higher-obstruction pair

Self-model for the kernel-ready shadow of the cohomological flagship. Derivations are made IN the
model (Γ working, not Γ recording). Object-axis (γ) skeleton follows separately via
typing-derivation; coupled, never merged (2.4).

**PROBLEM.** Marginal/restriction infrastructure + the theorem pair showing the defect is
irreducibly higher-degree (invisible to proper shadows), as the combinatorial core and acceptance
test of the flagship.

═══════════════════════════════════════════════════════════
## A (Will snapshot) + substrate facts (KK about me/the corpus)
═══════════════════════════════════════════════════════════

No sorry; axiom-clean (propext/choice/Quot.sound only — this GATES tooling below); every Mathlib
name mathlib-search-floored before act(formalize); decide/#eval = reliable act(experiment) on
closed finite props; Pl_imagine LOW unverified, but INSTANT-verifiable claims (closed decidable
props on concrete finite structures) form a trust region where imagination is cheap to launder
into knowledge through the kernel: generate candidate laws, kernel filters. Substrate green:
Multipartite.lean (projPi/hullPi/hcCombPi/IsRectPi/countPi), ApproximateFiveWay, TotalCorrelation.

═══════════════════════════════════════════════════════════
## DERIVATIONS (the noology used, per the PI's instruction)
═══════════════════════════════════════════════════════════

**D1 (R-grammar: the type of `projS`) — resolved by presheaf pressure + learning route.**
A marginal over `S ⊆ ι` lives on a different type (`∀ i : S, X i`), so the marginal family is a
presheaf over the subset lattice, and any future Čech complex is built from its restriction maps.
Inventing my own restriction grammar = gated imagine with a slow verifier (heterogeneous-equality
hell surfaces only downstream). Learning route wins: **Mathlib already fixed this grammar** — I
saw `measurePreserving_restrict₂_multivariateGaussian {I J : Finset ι}` in the Gaussian marginal
API during the M3d build, so `Finset.restrict : (∀ i, X i) → (∀ i : S, X i)` and the nested
`Finset.restrict₂ : S ⊆ T → (∀ i : T, X i) → (∀ i : S, X i)` exist WITH their composition laws.
Decision: `projS κ S := κ.image S.restrict`, restriction maps = image of `restrict₂`. FLOOR the
exact names/laws; do not guess.

**D2 (A4 catch made in-model: the "arity-2 collapse" is a tautology at the defect level).**
At `n = 2` the only pair is `univ`, and `proj_univ κ ≅ κ`: "pairwise determines global" is
vacuous. Worse, singleton marginals are ALWAYS trivially rectangular (the hull of a 1-index
structure is itself), so "proper shadows blind" is universal at n = 2. The true content splits
into two different theorems:
- **P1 (shadow-blindness, the degree statement).** There is a κ whose EVERY proper-subset
  marginal is rectangular while `hcCombPi κ > 0`. Witness: 3-parity
  `κ⊕ = {f : Fin 3 → Fin 2 | f 0 + f 1 + f 2 = 0}`: every proper marginal is a full cube
  (any partial assignment extends — one free coordinate absorbs parity), `|κ⊕| = 4`,
  `|hull| = 8`, defect `= 4`. Sharp form quantifies over ALL proper S (not just pairs).
  The n-ary parity family generalizes this to every n (defect `2^{n-1}`), named as the follow-up
  strengthening edge; the n = 3 instance is the flagship's acceptance test and lands by decide.
- **P2 (the amalgamation asymmetry, the gluing statement).** Genuinely different vocabulary: a
  1-consistent FAMILY of pairwise structures with no global structure realizing it. Witness: the
  Specker triangle (κ₁₂ = diag, κ₂₃ = diag, κ₁₃ = antidiag on Fin 2). At a 2-element index every
  such family glues trivially; at 3 it can fail. This IS the combinatorial H¹-class-existence
  statement — "the cohomology core directly" in finite form. Requires the family/consistency/glue
  grammar (a genuine R-expansion): built as PART 3, after P1 banks.

**D3 (a law derived and GATED, to be kernel-tested before proof): hull commutes with marginals.**
For nonempty κ: `hullPi (projS κ S) = projS (hullPi κ) S`. Reasoning: coordinate projections
compose (`proj_i ∘ proj_S = proj_i` for `i ∈ S`), and restriction of a full product is the full
product of the restricted factors PROVIDED the dropped factors are nonempty (κ nonempty ⟹ all
projPi nonempty). This is the "hull is a presheaf endomorphism" statement — the object the
complex will be built on. Per 2.3 this is imagined structure: before act(formalize), run the
CHEAP experiment (decide on parity3 and on an asymmetric random κ) to try to refute it. Only then
prove. (Nonemptiness is load-bearing: for κ = ∅ with S ≠ univ... hull ∅ = piFinset of ∅-projections
= ∅ ✓ both sides ∅ — the law may hold unconditionally; the experiment will say.)

**D4 (tooling gate from the axiom-cleanliness Will): decide yes, native_decide NEVER.**
`native_decide` introduces the `ofReduceBool` trust axiom — violates the corpus's axiom
discipline (FIELD_NOTE: "axioms at most propext, Classical.choice, Quot.sound"). All witnesses
must land by `decide`/`rfl`/explicit enumeration. Risk register: kernel reduction of
`Finset`-of-functions ops (piFinset of 8 lambdas, filter with derived Decidable instances) —
mitigations: constant family `X := fun _ => Fin 2` over `Fin 3`, define κ⊕ by `filter` over
`univ` with the derived instances (no Classical leakage into the decide goal), `rfl` fallback for
card equations, and if instance mismatch bites, `Finset.decidableMem`-aligned statement forms
(the Decidable-instance lesson from the ApproximateFiveWay build, Γ-ledger).

**D5 (Pl_imagine trust map for this build).** Trusted: closed decidable claims on parity3 /
Specker (kernel settles in ms — imagination is safe because laundering is instant). Gated:
general-n law families (AK-monoid codomain laws, restriction monotonicity), any "the complex
is..." claim (paper-first per the field note; the kernel holds only its falsifiers).

═══════════════════════════════════════════════════════════
## UK→KU forced by this build (Γ output)
═══════════════════════════════════════════════════════════

- KU-func: the presheaf laws — `restrict₂` composition; `projS (projS κ T) hST = projS κ S`
  (marginal-of-marginal). The enabling equations for any complex. → floor restrict₂ lemmas, prove.
- KU-hull: D3's law, experiment-then-prove.
- KU-inst: Fintype/DecidableEq instance stack on `∀ i : (S : Finset ι), X i` (subtype pi). → floor.
- KU-blind: P1's exact decidable statement form (∀ proper S, IsRectPi (projS κ⊕ S)) ∧ defect = 4.
- KU-glue (part 3): the family/consistency/glue grammar for P2 — typing pass of its own.

**Coupling.** D1/D4 (Γ: grammar choice, tooling gate) fix the γ skeleton's types; D2 (Γ: A4
catch) fixes the γ theorem statements; D3 (Γ: gated imagine) becomes a γ obligation only after
its experiment. η: P1 + infrastructure is the flagship's acceptance test made kernel-fact —
high validated-novelty-per-effort; P2 is the first nonzero-H¹ witness in finite form.

═══════════════════════════════════════════════════════════
## TICK 3 (Γ) — exact five-way at arity n
═══════════════════════════════════════════════════════════

**D1 (route).** `IsRectPi → TC = 0` via the measure identity `uniformPi κ = Measure.pi
(marginals)` + `klDivReal_eq_zero_iff.mpr`; converse directions free (contrapositive of
`totalCorrelationReal_uniform_pos`). Also the measure-converse (`= pi → rect`) mirrors bipartite
`uniform_eq_product_iff_isRect`: positive pi-mass at any hull point forces membership.

**D2 (load-bearing atom).** Fiber count of a product:
`countPi (piFinset F) i a = if a ∈ F i then ∏_{j ∈ erase i} |F j| else 0`. Floor Mathlib
`filter_piFinset` family first (learning route).

**D3 (in-model reduction + engineered sweeps).** The mass identity clears denominators to the ℕ
backbone: rect κ → `∏ᵢ countPi κ i (f i) = if f ∈ κ then |κ|^(n-1) else 0`, which reduces by D2
to the PURE double-product identity `∏ᵢ ∏_{j ∈ erase i} c j = (∏ c)^(n-1)` — pair-counting: each
j occurs n−1 times (`prod_comm'` + `prod_pow`); possibly UNCONDITIONAL (check n = 0, 1, zeros).
Sweeps: (i) D2 universally incl. EMPTY factors; (ii) the double-product identity at n = 0..4
incl. zeros; (iii) the backbone on all rect κ; (iv) over-sharp converse: does the backbone
identity CHARACTERIZE rect? (expect refutation or bonus leg — either is content).

**D4 (ENNReal joint).** `c^(n-1) * (c⁻¹)^n = c⁻¹` via `mul_pow` + `ENNReal.mul_inv_cancel`
(card ≠ 0 from nonempty, ≠ ⊤ natCast); no subtraction in exponents on the ℝ≥0∞ side.
