# Amalgamation-Leg URS — Vorob'ev positive direction (Γ ⟷ γ)

Rigor-first tick. The grammar extension and the positive amalgamation theorem, with the
architecture decision (Graham vs RIP) resolved by derivation, the induction invariant derived
in-model BEFORE Lean, and the risky step named under the Pl_imagine audit.

═══════════════════════════════════════════════════════════
## Γ — derivations
═══════════════════════════════════════════════════════════

**D1 (grammar: local structures as a bundled type — T-Structure).** A family over a cover needs
"team + structure on the team's marginal type" as ONE object (membership-dependent functions
over lists are HEq-hostile). `structure LocalStruct where team : Finset ι; rel : Finset (∀ i : team, X i)`;
a family is `List (LocalStruct ι X)`. Interface marginal `imarg L S hS := L.rel.image (restrict₂ hS)`
reuses the presheaf grammar. Pairwise consistency and `Glues` state homogeneously (both interface
marginals live on `T₁ ∩ T₂`). The canonical glue candidate is the NATURAL JOIN of the family,
`joinFam fam := univ.filter (fun f => ∀ L ∈ fam, L.team.restrict f ∈ L.rel)` — no subtype-pi
accumulation in the induction (the FiberProduct lesson, D1 there, applied again).

**D2 (architecture: Graham vs RIP — the delegated decision, resolved).** The PI leans Graham for
maximal rigor. Assessment: the two are DIFFERENT FACES, and rigor wants both in the right roles:
- The induction IS the RIP structure — a Graham-first proof would first extract an elimination
  order, i.e. rebuild RIP. So RIP-list is the CERTIFICATE form and the induction's engine.
- Graham reduction is the DECIDABLE, order-free face — the right definition of "acyclic cover"
  for sweeps and for the converse's hypothesis. Order-independence is where the rigor concern
  lives, and it is answered by a bridge theorem, not by choosing one face.
Decision: this tick builds `RIP : List (Finset ι) → Prop` (certificate) + the positive theorem;
`Acyclic 𝒞 := ∃ order, order.toFinset = 𝒞 ∧ RIP order` is the order-free wrapper; the **Graham
bridge** (`graham 𝒞 = true ↔ Acyclic 𝒞`, the decision procedure) is the NEXT tick — a
self-contained combinatorial theorem, honoring the Graham preference as the decidability face
of the same architecture.

**D3 (the induction invariant, derived in-model — the whole proof before any Lean).**
`RIP (L :: rest)`: L.team meets `cover rest` inside a single member `T' ∈ rest`. Invariant:
`joinFam` of an RIP + pairwise-consistent family realizes EVERY member's marginal. Step, with
S := L.team ∩ cover rest ⊆ T':
- The S-marginals of `L.rel` and of `joinFam rest` AGREE: `joinFam rest`'s T'-marginal is
  `rel'` (IH), its S-sub-marginal is `rel'`'s S-marginal (**the presheaf law
  `projS_image_restrict₂` — built two ticks ago, load-bearing exactly here**), which equals
  `L.rel`'s S-marginal by pairwise consistency restricted along `restrict₂_comp_restrict₂`.
- SPLICE MOVE (the one engine for both legs): given f ∈ joinFam rest and g ∈ L.rel agreeing on
  S, the function `f' := g on L.team, f elsewhere` satisfies all constraints: L's by
  construction; each T_k ∈ rest because f' = f OFF L.team and ON `T_k ∩ L.team ⊆ S` where g = f.
- Leg (a) realizes L: g ∈ L.rel → trace lifts through the S-marginal agreement to some f → splice.
- Leg (b) preserves rest: h ∈ rel_k → IH gives f with T_k-restrict = h → f's S-trace lifts to
  g ∈ L.rel (agreement, other direction) → splice; T_k-restrict unchanged (T_k ∩ L.team ⊆ S).
- Base: singleton/empty family: realize by arbitrary extension — needs `[∀ i, Nonempty (X i)]`,
  which REPLACES any cover-condition (uncovered coordinates fill arbitrarily). A5 note: this is
  MORE general than the classical covering formulation, not less.

**D4 (Pl_imagine audit — the risky steps named).**
- `T_k ∩ L.team ⊆ S`: needs `T_k ⊆ cover rest` — definitional from membership in rest ✓ but the
  fold-union membership lemma must be built (`subset_cover_of_mem`).
- The splice's dite-membership juggling is the FiberProduct pattern verbatim (two proofs banked);
  proof-irrelevance carries the subtype recasts.
- The trace-lifting through TWO image-layers (marginal of marginal) is where instance/motive
  drift bit before: keep every `restrict₂` fully pinned; term-mode witnesses (Γ-ledger lesson).

**D5 (kernel checks planned, expected verdicts).** RIP decidability is derivable (finite list
checks) → sweep: the Specker triangle cover has NO RIP order (all 6 permutations fail — the
converse INSTANCE, closing the leg at both ends for the minimal case: positive theorem + triangle
kernel-fact); the path cover ({0,1},{1,2}) is RIP ✓; parity3's full-marginal family over the
triangle is consistent AND glues (the full cube) — cyclicity does not force failure, it permits
it (guards against over-reading the converse).

═══════════════════════════════════════════════════════════
## γ — deliverables
═══════════════════════════════════════════════════════════

`HC/Amalgamation.lean`: LocalStruct, imarg, Consistent, Glues, joinFam, cover, RIP,
`subset_cover_of_mem`, `projS_joinFam_singleton` (base), the splice lemma,
**`joinFam_realizes`** (RIP + Consistent → every marginal realized), **`glues_of_rip`**
(the amalgamation leg), and the triangle kernel-facts. Graham bridge + general cyclic converse:
named next edges.

## Verdicts + Γ-yield

**All deliverables GREEN, 0 sorry, barrel at fifteen layers.**
`LocalStruct`/`imarg`/`imarg_image`/`Consistent` (+ decidable instance)/`Glues`/`joinFam`/
`famCover`/`RIP` (+ recursive decidable instance)/`exists_restrict_eq`;
**`projS_joinFam`** — the positive Vorob'ev theorem, by the D3 induction exactly as derived
(presheaf transport → consistency matching at the interface → splice; both legs through the one
splice engine); **`glues_of_rip`**; Specker closure: `speckerFam_consistent` (decide),
`speckerFam_no_rip` (all six orderings fail RIP, decide), `speckerFam_not_glues` (bridged from
the concrete non-realization).

**The D3 derivation held verbatim** — the in-model proof compiled with no structural changes,
only linter/name repairs. The presheaf law (`projS_image_restrict₂`), built three ticks ago
under the "any future complex consumes this" rationale, was load-bearing at exactly the
predicted joint (hkey). The one honest deviation: `speckerFam_no_rip` quantifies over the six
explicit orderings, not `List.Perm` (kernel reduction of `permutations` sticks at its aux; the
order-free `Perm`/`Acyclic`-quantified form is scheduled with the Graham tick, its natural home).

**Γ-yield.**
1. The amalgamation leg is CLOSED at both ends: RIP + consistent ⟹ glues (theorem schema, any
   arity, any parts), and the triangle is kernel-witnessed as consistent + unorderable + unglued.
   The oscillation theorem's discrete engine is now a proved implication, not a narrative.
2. Architecture confirmed under load: the RIP-certificate carried the induction; nothing in the
   proof wanted Graham. Graham enters as the DECISION face: `Acyclic 𝒞 := ∃ order, RIP order`
   + `graham_iff_acyclic` — the named next tick, completing the PI's rigor request as the
   decidability bridge.
3. Named edges: Graham bridge; the general cyclic converse (cycle → parity-style non-gluing
   family, generalizing the triangle); C-JLeib≤ (the interface-tightening inequality); the
   measure-level lift of `glues_of_rip` (consistent MEASURE families over RIP covers — where
   PhysLean's quantum marginal instances land).
