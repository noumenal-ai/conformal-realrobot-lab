# HANDOFF_DISCOVERY_URS: the object axis: what is known, and what is known about what is not

**What this document is.** The discovery half of the 2026-07-07 handoff pair (its twin,
`HANDOFF_NOOLOGY_URS.md`, describes the reasoner, the rules, and the toolkit; read it
first). This document is the exhaustive state of the MATHEMATICS: every banked result
with its evidence grade and witness, every refutation, every open question with its
sharpest known formulation, and the ignorance geometry of the whole programme. Written
for a fully naive reader.

**Claim discipline (used on every line).**
- **[KV]** kernel-verified: Lean 4, zero sorry, axioms at most
  `propext, Classical.choice, Quot.sound`. The strongest grade.
- **[decide]** a finite decidable check inside a [KV] proof.
- **[NUM]** numerically verified under the battery protocol: exact-arithmetic
  computation over pre-registered zoos, independently re-implemented by a blind
  adversarial verifier before acceptance. A [NUM] law with a proof sketch is a
  formalization target, not a theorem.
- **[PROBE]** established by literature audit against fetched primary sources under the
  anti-vacuity rule.
- **[CONJ]** conjecture, named as such. **[STANCE]** interpretive position.
- **[REFUTED]** killed, with the witness recorded.

---

## 0. The field, for a naive reader

Probability theory weighs possibilities; this field measures their SHAPE before any
weighting. Its primitive object is a relation κ ⊆ ∏ᵢ Xᵢ (which joint configurations are
admissible at all), and more generally a COVER: a family of overlapping "teams" of
variables, each carrying a local relation (or local probability distribution, or local
quantum state), with the central question: when do consistent local descriptions GLUE
into a global one? The field's founding measure is hcComb(κ) = |hull| − |κ| (the number
of configurations the marginals permit but the joint forbids), and its founding theorem
[KV] is a five-way equivalence: this one number vanishes iff κ is a combinatorial
rectangle iff Craig interpolation holds across the interface iff amalgamation holds iff
mutual information vanishes at the canonical measure iff the fiber product surjects.
Everything below builds outward from that: to covers (local-to-global gluing), to
quantum states (the quantum marginal problem), and toward the field's flagship
conjecture (the obstruction is cohomological and the measure is its Euler-characteristic
shadow). The front-door narrative is `Theory.md` (same directory, v0.3).

## 1. The kernel corpus (what is [KV], file by file)

All paths relative to `measurements/ZPM/Measurements/HC/`. The barrel `../HC.lean`
imports twenty-one layers; every theorem below is axiom-audited clean.

**The classical discrete stack (the field's own theorems):**
- `Abstract.lean`: the interpolation–amalgamation biconditional and the oscillation
  theorem (proved from NO axioms at all): a trajectory exhibiting cross-domain discovery
  cannot have been factorable at every step.
- `Combinatorial.lean`, `FiveWayPi.lean`, `Marginals.lean`, `Multipartite.lean`,
  `ApproximateFiveWay.lean`, `ProductLaw.lean`, `FiberProduct.lean`: hcComb, hulls,
  marginal presheaf (`projS`, `projS_image_restrict₂`), the five/six-way equivalence at
  arity 2 and arity n, total correlation, product laws.
- `Amalgamation.lean`: `LocalStruct` (team + local relation), `Consistent` (pairwise
  marginal agreement), `Glues` (a global relation with exactly the prescribed
  projections), `joinFam` (the natural join), the positive Vorob'ev direction over
  running-intersection orders.
- `GrahamBridge.lean`: `Acyclic` (order-free hypergraph acyclicity), the decidability
  bridge `acyclic_iff_grahamReducible` (GYO ear reduction), `glues_of_acyclic` (the
  order-free amalgamation theorem), `speckerCover_not_acyclic` [decide].
- `AffineEngine.lean`: the F₂ affine obstruction engine: local parity systems with
  per-team constants, coherence, and `affine_obstruction`: a closed coherent system
  with a hosted ODD dependency yields a consistent family of nonempty local relations
  that does not glue. The constructive heart of every negative result.
- `CyclicConverse.lean`: ear-free cores, the cycle-pair F₂ algebra,
  `clean_system_obstruction`, `cycle_obstruction`: a cleanly hosted cycle yields a
  consistent non-gluing family.
- `VorobevConverse.lean`: the primal graph grammar (Adj, cliques, `Conformal`), the
  minimal-non-covered-clique datum, the one-step GYO collapse
  (`isEarOf_of_simplicial`), the chordless-cycle datum ("chordlessness is
  cleanliness"), chained core extraction, and `capstone_of_dichotomy`.
- `Dirac.lean` (1115 lines, built from scratch because Mathlib has NO chordality
  theory): a bespoke path grammar over `List.IsChain` (walks, reachability, minimal
  paths, connectors), `sep_clique_step` (minimal separators are cliques, via an
  assembled two-sided cycle whose chord is killed case-by-case), `erase_separates`,
  **`dirac_strong`** (a chordless-cycle-free vertex set is a clique or holds two
  nonadjacent simplicial vertices), `earFree_dichotomy`, and the headline pair:
  **`exists_consistent_not_glues_of_not_acyclic`** (every non-acyclic cover hosts a
  consistent nonempty non-gluing family: the discrete Vorob'ev CONVERSE, constructive)
  and **`acyclic_iff_forall_consistent_glues`** (a cover is acyclic exactly when
  pairwise consistency forces gluing). Smoke: `specker_hosts_nonglue` fires the
  capstone on the concrete Specker triangle unconditionally.
- `HigherObstruction.lean` etc.: the Specker objects (`S01,S12,S02`), arity-n substrate.

**The quantum leg:**
- `PRBox.lean`: the CHSH scenario as the 4-cycle cover; `chshCover_not_acyclic`
  [decide]; `chsh_hosts_nonglue` (the scenario's SHAPE alone forces the possibility of
  contextuality, via the capstone); the explicit possibilistic PR box (`prRel`,
  parity supports with odd constant sum): `prBox_consistent`, `prBox_rels_nonempty`,
  **`prBox_no_global_section`** (`joinFam prBox = ∅`: strong contextuality in the
  Abramsky–Brandenburger possibilistic sense), `prBox_not_glues`; and the control
  **`bellPath_no_contextuality`**: drop one context (acyclic Bell path) and every
  consistent family glues. Possibilistic contextuality of CHSH ⟺ its cover's
  cyclicity, both directions [KV].
- `QuantumMarginal.lean` (L0 CLOSED 2026-07-08, in the barrel, all audits clean):
  `MState.traceAlong` (the abstract partial-trace primitive, with entry calculus and
  the abstract composition theorem = LZ Lem 2.2 shape); `ptraceS` (the quantum
  `projS`) and `qRestrict₂` (the quantum `Finset.restrict₂`) as instances; the
  presheaf law `qRestrict₂_ptraceS`; the four matrix-level pull-out lemmas (Lem 2.3);
  `ProbDistribution.marginal` and the diagonal bridge `ptraceS_ofClassical`. The
  encoding grammar (abstraction-boundary law) is recorded in QJT_URS's L0 entry.

**The vendored quantum substrate** (`physlean/QuantumInfo`, same Mathlib pin, built via
`lake build @Physlib/QuantumInfo` from root): density matrices (`MState`), bipartite
partial traces, products, relabeling/`piProd`, purification, spectrum/purity, CPTP
channels and pinching, von Neumann entropy with **SSA proved** (`qcmi_nonneg`), DPI at
α = 1 (`sandwichedRenyiEntropy_DPI`), relative entropy (`qRelativeEnt` + lemmas),
HermitianMat toolkit (sqrt, cfc, log, exp, rpow, support/kernel projections, Lieb–Ando
convexity). **QUARANTINE (sorry-tainted vendor code, do not use):**
`Entropy.Axiomatized.*` (whole subtree), `Capacity.*` (whole subtree),
`qRelativeEnt_joint_convexity`, `fidelity_channel_nondecreasing`,
`ClassicalInfo.Capacity.BlockCode`.

## 2. The [NUM] layer (twice-implemented numerics; formalization targets)

From the flagship battery (`FLAGSHIP_COHOMOLOGY_URS.md`, probe + blind adversarial
re-implementation, ~800 instances, zero surviving discrepancies):

- **The affine direction-presheaf Čech complex** (the flagship's abelian complex on the
  affine subclass). For pairwise-consistent F₂-affine local systems on ANY cover: nerve
  of the cover; coefficients F(σ) = the projected direction (linear) spaces, well
  defined exactly on the consistent locus; restrictions = coordinate projections;
  char-2 Čech differential, d∘d = 0. Verified laws: (a) glue ⟺ the mismatch class [δ]
  vanishes in H¹ (class independent of reference sections); (b) forest nerves have
  H¹ = 0; (c) the PR box is the nonzero class in a 1-dimensional H¹ and the even twist
  on the same cover is a coboundary; (d) on α-acyclic covers, EXACT zero-correction
  identity log₂|join| = Σ_T dim V_T − Σ_edges dim V_sep for every join tree, and
  log₂|join| = dim H⁰ whenever the glue exists (cyclic covers included). Proof sketches
  exist for all four.
- **The entropy junction-tree identity**: for U uniform on the join of a consistent
  family over an acyclic cover, log₂|join| = Σ_nodes H(U_T) − Σ_edges H(U_sep), exact
  to machine precision, join-tree invariant. TRUE MECHANISM (verifier-corrected): the
  join-indicator is a Gibbs distribution with clique-indicator potentials, hence
  tree-Markov (Hammersley–Clifford); uniform max-entropy then gives the identity.
- **The no-go**: hcComb(κ⊔κ') = hc + hc' + |A||B'| + |A'||B| exactly (and the product
  law): no χ-additive functor computes hcComb; any candidate complex must couple parts
  through the hull's cross-blocks.

[REFUTED] in the same battery: the Dowker complex as flagship carrier (hcComb is not
even a face-set invariant of the Dowker pair: explicit collision witnesses R1 vs W1);
the cardinality junction-tree telescope |join| = ∏teams/∏separators (false in BOTH
directions, exhaustively, already on the two-team path; it is the max-entropy
degradation of the true entropy identity).

## 3. Literature-subtracted verdicts (the interrogation round, [PROBE] grade)

Full detail with citations in `QUANTUM_TOWER_URS.md`. The compressed truth table:

| Claim | Verdict |
|---|---|
| Discrete Vorob'ev over covers, PR box strong contextuality, Bell-path control | mathematics KNOWN (Vorob'ev 1962; Abramsky–Brandenburger 2011); our kernel proofs are formalization firsts and load-bearing substrate |
| Diagonal transfer (classical non-gluing lifts to quantum marginal infeasibility) | folklore (explicit in PRA 101:032341 2020; Navascués–Baccari–Acín 2021) |
| Monogamy witness on the 2-chain | textbook (CKW 2000) |
| Tsirelson bound | known 1980; ALREADY FORMALIZED in Isabelle/HOL (Echenim–Mhalla, arXiv:2306.12535); a Lean version is first-in-Lean only |
| "Quantum gluing ⟺ laminar covers" (a subagent's candidate law) | [REFUTED] by counterexample: cover {ab, bc, abc} is non-laminar yet always glues (the super-team pins everything); crossing-pair witnesses do not extend past dominating super-teams |
| AvN/Z₂-affine completeness of the Čech contextuality obstruction | KNOWN (Abramsky–Barbosa–Kishida–Lal–Mansfield, CSL 2015, arXiv:1502.03097; stabilizer AvN triples arXiv:1705.08459). The Hardy model is the canonical FALSE NEGATIVE of Čech H¹ (our free witness that set-valued completeness fails) |
| Hypergraph quantum entropy cones | a populated subfield (Bao et al., SciPost 9:067 2020); LOW leverage for us, conceded |
| Quantum junction tree on chordal covers | CLOSED May 2026 by Lauritzen–Zwiernik arXiv:2605.19453 (see Section 4); nobody has a machine-checked version |

## 4. The active arc: QJT (quantum junction tree + the open problem)

**The source theorem (Lauritzen–Zwiernik, "The Markov Marginal Problem for Density
Operators", arXiv:2605.19453v2; complete extraction in `QJT_LEDGER.md`, which is the
single formalization source).** In the strictly positive (PosDef) regime: define
T(R) = exp(Σ_cliques log ρ_C − Σ_seps ν(S) log ρ_S) (every marginal embedded by
tensoring with identities BEFORE logs). Then Tr(T(R)) ≤ 1 always, and for two
overlapping marginals (Thm 3.1) and clique marginals on a CHORDAL graph (Thm 3.10):
Tr(T(R)) = 1 ⟺ a quantum Markov completion exists ⟺ T(R) itself is one; it is then
unique and the maximum-entropy completion. Two-clique case: equivalently the two
one-sided sandwich reconstructions agree ⟺ K = ρ_{AC}^{1/2}ρ_C^{−1/2}ρ_{BC}^{1/2} is
normal. Their gI(𝒢)_ρ = Σ_C S(ρ_C) − Σ_S ν(S)S(ρ_S) − S(ρ) ≥ 0 vanishes exactly on
Markov states and equals the divergence from ρ to the log-candidate (with trace
correction): a graded, cover-indexed defect measure (the field's OP4 object, delivered).

**Proof-structure facts that set the formalization strategy (ledger Parts 3-4):**
- The INEQUALITY spine (trace bounds, the engine identities Lem 3.2/3.11, all existence
  equivalences) uses only: pull-out (Lem 2.3), Klein, the extended (non-normalized)
  divergence, DPI-INEQUALITY (which QuantumInfo HAS at α = 1), and ONE deep stone:
  Lieb's three-matrix inequality (Ruskai 2002 Thm 5; Lieb–Ando backbone present,
  assembly is ours).
- The CHARACTERIZATION spine (K-normality, the intersection property, Petz-shaped
  uniqueness) is gated on ONE self-contained module: the paper's own finite-dimensional
  Appendix A (weighted operator spaces, relative modular operator Δ_{τ,ρ}(X) = τXρ⁻¹,
  variational formula, equality-DPI criterion, Petz recovery, CMI = 0 ⟺ Petz identity).
  No external HJPW needed; formalizing App A IS the Petz build.
- The chordal induction is junction-tree-LEAF induction over exactly our banked RIP/ear
  combinatorics; the base case of the chordal entropy inequality (Prop 3.9) is SSA,
  which QuantumInfo has.
- Everything strictly positive; exact stabilizer states are singular limits (battery
  objects are the paper's own ε-smoothed Pauli states).

**Pauli test vectors (exact, ledger Part 5).** 3-qubit: ρ₁₂ = ¼(I+εX⊗X),
ρ₂₃ = ¼(I+δZ⊗Z): feasible ⟺ ε²+δ² ≤ 1; Markov-completable ⟺ εδ = 0;
Tr(T(R)) = cosh r/(cosh b · cosh d), b = arctanh ε, d = arctanh δ, r = √(b²+d²).
7-qubit chordal (cliques {123},{245},{256},{267}; four pairwise-anticommuting words):
Tr(T(R)) = cosh r/∏cosh bⱼ, = 1 ⟺ at most one parameter nonzero. These realize ALL the
separations (local consistency ⊋ feasibility ⊋ Markov feasibility) and are the CI
ground truth for everything below.

**The formalization ladder (QJT_URS, re-graded after the ledger):**
L0 `ptraceS` (core GREEN; presheaf law + pull-out lemma + diagonal bridge OPEN) →
EASY layer (⊙ := exp∘(log+log), ⋆ sandwich, K, extended divergence + Klein, Lem 3.2 as
algebra) → L2a (the Ruskai stone, then Thm 3.1's existence equivalences: BANKABLE with
the current floor) → LA (App A, the make-or-break Petz module) → L2b (K-normality,
intersection, uniqueness) → L3 (chordal, our combinatorics) → L4 (max-entropy, gI).

**The OPEN PROBLEM (the actual prize).** Off chordal covers, T(R) IS NOT EVEN DEFINED
(no junction tree, no canonical separator multiplicities); the paper says plainly that
even classically there is no simple non-emptiness condition off chordal graphs, and
general quantum consistency is QMA-complete (Liu 2006). The open question, sharpest
form: **is quantum-Markov completion-forcing on non-chordal covers cut out by LOCAL
separator conditions, or does non-chordality introduce a strictly GLOBAL (cohomological)
obstruction with no local characterization?** The field's bet (pre-registered, [CONJ]):
cohomological. The attack runs on the stabilizer (quantum-affine) subclass, where our
affine Čech machinery lifts with the ANTICOMMUTATION GRAPH of the constraint words as
the symplectic structure and the cosh-ratio trace formula as chordal ground truth:
- QJT-STAB [CONJ]: completion for smoothed-stabilizer families on ANY cover ⟺ a
  symplectic-F₂ Čech class vanishes (+ normalization).
- QJT-CYC [CONJ, expected TRUE]: on the 4-cycle, families satisfying every LOCAL
  condition with no completion, obstruction = a nonzero class (the state-level quantum
  PR box).
- QJT-GRADE [CONJ]: on diagonal states over acyclic covers, gI reduces to the classical
  junction-tree KL discrepancy; gI is the quantum hcComb at chordal covers.
All three go through the [NUM] battery (probe + blind adversarial verifier) BEFORE any
Lean.

## 5. The wider frontier (beyond the active arc, ranked)

1. **QV′ extension problem** [CONJ]: corrected quantum-Vorob'ev candidate: "quantum
   gluing for all consistent families ⟺ maximal teams pairwise disjoint"; its hard
   direction is the sharp new question of when the monogamy witness propagates past
   other teams (the blocking pattern is nerve-structural). Born from the refutation in
   Section 3.
2. **The affine flagship formalization** (FLAGSHIP_COHOMOLOGY_URS): the [NUM] complex
   into Lean (order fixed: complex + d∘d = 0; glue ⟺ coboundary; forest vanishing; the
   PR-box class; the dimension identity). Includes the OP3 flag-plants: is our affine
   class strictly larger than ABKLM's AvN fragment, and the coefficient-presheaf
   completeness characterization (open per Carù/Aasnæss). Substrate decision made:
   bespoke Finset-indexed F₂ linear algebra with `Module.finrank` as spec layer
   (Mathlib at this pin has NO simplicial homology and NO Euler–Poincaré).
3. **The general-κ entropic complex** [CONJ]: realize the entropy junction-tree
   identity cochain-level, respecting the no-go (must be hull-coupled, cannot be
   cardinality-χ-additive).
4. **The Gaussian tier** (tower nesting) [CONJ]: chordality is the completion wall for
   BOTH Gaussian PSD completion (Grone–Johnson–Sá–Wolkowicz 1984, known) and quantum
   Markov completion (LZ 2026): the four-wall tower (relational gluing = acyclicity ⊂
   Gaussian = chordality ⊂ quantum ⊂ no-signaling) with our own chordal/conformal
   dichotomy as the kernel bridge between the first two walls. ZPM now carries
   multivariate Gaussian KL closed forms (`klDivReal_multivariateGaussian`) and dual-W₁
   (`dualW1`), so both the Gaussian wall and the graded (W₁/KL-defect) versions are
   statable.
5. **Kernel firsts available as substrate** (correctly labeled): machine-checked
   quantum junction tree (= this arc's banking track); first-in-Lean Tsirelson (a port
   of the Isabelle proof, not a first-ever).

## 6. Ignorance geometry (the global K/U map)

- **KK** (stabilized): everything in Sections 1-4 above at its stated grade; the exact
  toolchain pins; the quarantine list; the LZ proof skeletons.
- **KU** (askable, unresolved): the QJT candidate laws (verdicts pre-registered); the
  Ruskai-assembly difficulty; whether App A's weighted-space calculus needs new
  Mathlib-side superoperator infrastructure or falls to HermitianMat's CFC; the OP3
  scope comparison (our affine class vs AvN); the QV′ extension characterization; the
  L0 presheaf-law bookkeeping.
- **UK** (felt, articulated this session, unverified): on stabilizer data the LZ trace
  obstruction and the field's cyclic parity obstruction may be literally the same
  invariant (the cosh-ratio collapsing to an F₂ phase condition in the singular limit);
  if so, the [KV] classical capstone, the [NUM] affine H¹, and the quantum Markov
  problem meet in one object, and the non-chordal answer on this class is the affine
  flagship in quantum dress. What replaces the direction presheaf OFF the stabilizer
  class is unarticulated.
- **UU** (not yet askable): the correct general-cover replacement for T(R) off the
  stabilizer class; whether the entropic and cohomological readings of the obstruction
  unify at a single tiered statement (classical H, quantum S, flatness = CMI 0).

## 7. Verification recipes (trust nothing, re-check everything)

- Any [KV] claim: compile the file and `#print axioms <name>` (exact commands in the
  noology twin, Section 4.3); expect exactly `[propext, Classical.choice, Quot.sound]`.
- Any [NUM] claim: the battery scripts live in the session scratchpads referenced in
  the URS verdict rounds; re-run or re-implement; the protocol REQUIRES a fresh
  implementation for any re-verification, never re-running the probe's own code alone.
- Any [PROBE] claim: the citations are in QUANTUM_TOWER_URS and QJT_LEDGER; re-fetch
  the named sources; the anti-vacuity rule applies to any extension.
- The LZ paper: use `QJT_LEDGER.md` (complete extraction) and the cached PDF path at
  its foot; do not trust model memory for ANY of its content.

## 8. Addendum: PI fold-in, 2026-07-07 (late session)

Braindump from the PI, routed here as object-axis state. Grades as marked; nothing below
is banked without its verifier. The work-queue routing lives in the noology twin,
Section 8. The refuted slogan below appears in NO file of this folder (grepped); the
correction is recorded so future prose never reintroduces it.

**Correction (to KK phrasing, not to any theorem).** The old oscillation slogan ("no
amount of fiber measurement breaks the base obstruction") is refuted by the kernel's own
`kId_restrictL_singleton_resolves`. Correct form: fiber reweighting preserves the defect
identically (the grading is distribution-free by definition); the obstruction is provably
invisible to shared vocabulary (`reverse_direction`); it survives all non-trivializing
conditioning (`kId_restrictR_pair_unresolved`); it dies only by collapse (trivialize a
coordinate) or by expansion (discover configurations filling toward the hull).

**New candidate structures ([CONJ] unless noted):**
- **Resolution dichotomy** [CONJ, kernel-cheap]: every move from hcComb > 0 to
  hcComb = 0 factors as side-collapse or hull-completion; only the second is discovery.
  Expected an afternoon at the finite layer; converts the corrected slogan into a
  theorem.
- **Explanation-as-interpolant** [DEF/CONJ]: an interpolant is an interface-level
  explanation; a discovery is a truth temporarily inexplicable in the shared language;
  the oscillation theorem says the inexplicable phase is unavoidable. Proof-complexity
  echo [IMPORT]: Krajicek's feasible interpolation reads as "systems with
  guaranteed-small interpolants are too weak to represent discovery." First foothold for
  the manifesto's UU item on what the third column does to explanation.
- **Type-theoretic dynamics** [STANCE/CONJ]: fiber moves and support-shrinking
  conditioning are in-context derivation; configuration discovery is context extension,
  the one move no derivation performs; Craig failure is discovery's proof-theoretic
  signature.
- **Design validity, impossibility form**: `reverse_direction` already implies some
  claims are provably untestable by any interface-respecting experiment (sibling of the
  evidence-types theorem, with interpolation making "interface-respecting" precise).
- **Design validity is decidable**: "experiment E bears on claim P" = P is non-constant
  across configurations E separates = a hull/defect condition in integer arithmetic;
  R-NV (contrast-pair non-vacuity) is an SoI invariant.
- **Experiment identity fibers** [CONJ + PAPER]: base-identity (same SoI morphism) and
  fiber-identity (same evidential content, the likelihood principle) are different
  relations and provably diverge (Pcorr-style witnesses); the sixty-year Birnbaum debate
  was conducted entirely in the fiber, the base relation never on the table. Resolves
  the manifesto's C9 by refusing its premise.
- **No-free-discovery reading** [STANCE + PAPER]: `no_discovery_under_decomposability` =
  a system maintaining factorization at every step never makes a cross-domain discovery.
  Kuhn cycle, kernel-checked at toy scale: normal science = the HC = 0 trajectory
  (provably discovery-free); anomaly = the forced spike; revolution resolves by the
  dichotomy (collapse or expansion).
- **The obstruction ledger** [CONJ]: one schema with morphisms unifying the programme's
  defect instruments: hcComb (rectangularity), fiberDefect (spec-to-fiber
  non-factoring, >= 3/20), the counit kernel of idealize -| observe, the
  bisimMetric-vs-quotient gap, and (once QJT L4 lands) gI. Conjecture: the rigidity
  dichotomy is the closure-graded refinement of F's non-faithfulness, and
  rigid/non-rigid corresponds to a five-way face (interpolant-richness).

**Imports (delimiting or load-bearing):**
- **Rigidity Dichotomy** [IMPORT from world-models, load-bearing]: the characterization
  axis for when F is NOT lossy. Closure-rich readout classes (lattices/algebras) force
  base-determines-fiber (separation gives total approximability; universal approximation
  re-read as fibration rigidity, one ReLU layer per lattice op); closure-poor classes
  (Lipschitz/transport) have kernel-checked non-factorization (fiber gaps <= 1/4 vs
  >= 2/5 on the same forced base). The corpus itself states the Pcorr/CHSH analogy.
- **Base-empirics boundary** [Q]: kappa is never observed; positive samples yield exact
  dyadic membership witnesses (exists-certificates) but the defect is not one-sidedly
  certifiable from positive data. Delimiting imports: Valiant-Valiant support-size lower
  bounds; Angluin's tell-tale condition. Ownable open question: characterize the SoI
  invariants certifiable from membership witnesses alone.
- **Ancestry** [IMPORT]: statistics-of-the-base: Pearl's identification/estimation split
  (identifiability decided at structure level, before data), Manski partial
  identification (bounds from admissible sets). Expansion-move ancestry: Karni-Viero
  reverse Bayesianism, AGM expansion, Heifetz-Meier-Schipper unawareness (the update
  Bayes cannot perform, now carrying a graded invariant).
- **The grading tower, made explicit**: the chi-codomain runs dim → H → S(ρ) (affine
  dimension identity [NUM]; entropy junction-tree identity [NUM]; LZ chordal entropy
  identity S(T(R)) = Σ_C S(ρ_C) − Σ_S ν(S)S(ρ_S)): the fibration's separation
  reappearing at counting level, now three-tiered. QJT-GRADE (QJT_URS) is the assertion
  that this tower commutes with the diagonal embedding.
- **OP2 contact**: OP2's L3 supporting-hyperplane lemma = the junction-tree functional
  supports the entropy cone at Markov points; quantum form: Prop 3.9 / gI >= 0 with
  equality exactly at Markov states.

**The state, in one line: the classical local-to-global theory of the field is closed
in the kernel; the quantum chordal theory has a complete formalization plan with one
hard stone and one make-or-break module; and the open problem is engaged at exactly the
point where the field's own machinery (cycles, parity, Čech classes) is the natural
weapon.**
