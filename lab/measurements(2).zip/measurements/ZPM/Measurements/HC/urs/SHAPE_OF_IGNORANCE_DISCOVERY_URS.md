# Shape of Ignorance — Discovery (γ) URS

The single durable object-knowledge map of the Hidden Channel Capacity (HC) / "Shape of
Ignorance" programme. This is a **discovery URS**: the field's content (theorems, definitions,
citations, literature position, open problems, cross-tree state), not a reasoner's self-model.
It is written to survive total session loss and let any future reader (human or agent)
reconstruct the whole effort.

Synthesized by the final Opus consolidator from a fan of 13 Sonnet miners, each of which read a
fixed, kernel-verified slice of the corpus and wrote a mining URS
(`discovery/mining/URS_01.md` … `URS_13.md`). Provenance for every claim below is traceable to
one of those 13 files; where miners disagreed, or a slice was incomplete, this is stated.

## How to read the tags (never upgraded)

Every result carries the kind-of-truth tag its miner assigned, preserved verbatim:

- **[KV]** — a theorem the Lean kernel proves (statement transcribed).
- **[decide]** — a finite decidable check (`by decide`, kernel evaluation).
- **[CONJ]** — a conjecture named as such in the corpus.
- **[PROBE]** — a literature-audit verdict (novelty / no-ancestor / boundary), asserted in prose.
- **[STANCE]** — an interpretive or positioning claim in a docstring or ledger.
- **[def]** — a definition (not itself a truth-claim).
- **[infra]** — build/engineering scaffolding, import-aggregators, private helper lemmas.

Honesty discipline, applied throughout: a `= 0 ⟺` equivalence bundle is a **framing** result;
a quantitative inequality is a **hard** result; a `decide` fact is a **finite check**. These are
never conflated. Kernel-proven and prose-asserted are kept distinct. No miner ran the Lean kernel;
all [KV] tags are transcribed from source that the corpus self-reports as `sorry`-free and
axiom-clean (`[propext, Classical.choice, Quot.sound]`, sometimes narrower). Independent
`#print axioms` verification is a named residual (see §7 Γ).

**PI reconciliation (2026-07-03).** That residual is discharged at the source: the maintainer
confirms the corpus is fully verified from all angles, so the [KV] tags stand as kernel-true,
not merely self-reported. Independently within the consolidation session, the v0.2 discrete
stack (`dirac_strong`, `earFree_dichotomy`, `exists_consistent_not_glues_of_not_acyclic`,
`acyclic_iff_forall_consistent_glues`, the twenty-layer barrel, and the Specker smoke test)
was recompiled and `#print axioms`-audited to `[propext, Classical.choice, Quot.sound]`, zero
`sorry`, `decide` only (never `native_decide`). The §7 Γ item is retained as a note on the
mining method (miners read, they did not build), not as doubt about the results.

The three philosophical layers of the carrier are held throughout: **Layer 1** (ignorance is
structured and generative; the discovery axis γ and the noological axis Γ are never merged),
**Layer 2** (the miners were inductive models that simulate abduction, so self-generated
structure is low-trust), **Layer 3** (the HC programme is evidence catalogued, never an axiom
invoked). This document is the γ-axis map. The Γ-axis routing list for the next session is §7.

---

# 1. The object and its measure

## 1.1 The ignorance structure

The primitive object is an **ignorance structure**: a relation `κ ⊆ ∏ᵢ Xᵢ` over a finite index
of sorts, with a distinguished partition into a **shared interface** `S` and **private parts**
(commonly two, `A` and `B`). It is the record of *which* joint configurations are admissible,
prior to and independent of any weighting (Theory.md §2; FOUNDATIONS.md §1, §3 — miner 13).

Three characterizing adjectives, from the field note (Theory.md §2):
- **constructive** — finite cardinality, decidable, kernel-verifiable (against subjective
  plausibility, and against entropy);
- **domain-free** — no valuation domain, no ordering, no ℝ;
- **distribution-free** — invariant across every probability measure supported on `κ`.

The philosophical reading (Theory.md §9, [STANCE]): `κ` is *structured ignorance itself*; the
field "did not begin as mathematics; it began as an ignorance question — when is a causal learner
finished? — and the mathematics is what that question precipitated under formalization." The
mathematics is stated to stand without the lens: "the lens is not an axiom of the system."

## 1.2 The measure κ → hcComb / hcCombPi (stated precisely)

**Bipartite support level** (`Combinatorial.lean`, miner 01):
- `projL κ := κ.image Prod.fst`, `projR κ := κ.image Prod.snd` — the left/right marginal supports.
- `IsRect κ : Prop := κ = projL κ ×ˢ projR κ` — **rectangularity**: `κ` equals the product of its
  marginal supports.
- **`hcComb κ : ℕ := (projL κ ×ˢ projR κ).card - κ.card`** — the **combinatorial hidden channel
  capacity**: the number of admissible configurations missing from the full product of the
  marginals. Zero iff `κ` factors.

**Multipartite (arity-n) level** (`Multipartite.lean`, miner 04):
- `projPi κ i := κ.image (fun f => f i)` — coordinate projection (what the interface exposes of
  part `i`).
- `hullPi κ := Fintype.piFinset (fun i => projPi κ i)` — the **rectangular hull**, the product of
  the coordinate projections; "the maximal ignorance consistent with the marginal exposures."
- **`hcCombPi κ : ℕ := (hullPi κ).card - κ.card`** — the multipartite combinatorial hidden-channel
  defect, the arity-n generalization of `hcComb`.
- `IsRectPi κ : Prop := κ = hullPi κ`.
- `card_hullPi` [KV]: `(hullPi κ).card = ∏ i, (projPi κ i).card`.
- `card_hullPi_sdiff` [KV]: `(hullPi κ \ κ).card = hcCombPi κ` — the **forbidden region** has
  exactly `hcCombPi κ` elements. This set drives the quantitative lower leg (§2.3).

`hcComb` is the `Fin 2` special case of `hcCombPi`, tied by `hcCombPi_fin_two` [KV]
(`ApproximateFiveWay.lean`, miner 05): over `Fin 2`, `hcCombPi κ = hcComb (κ.image piFinTwo)`.

The **anchor biconditionals** (framing results, [KV]):
- `hcComb_eq_zero_iff_isRect` [KV] (miner 01): `hcComb κ = 0 ↔ IsRect κ`.
- `hcCombPi_eq_zero_iff_isRectPi` [KV] (miner 04): `hcCombPi κ = 0 ↔ IsRectPi κ`.

Honesty note (carrier discipline, flagged by miners 01 and 13): the vanishing of `hcComb` is
proved to be equivalent to rectangularity (a hard `[KV]` fact). The further, *cohomological*
reading of `hcComb` as an Euler characteristic `χ` of a canonical complex is still **[CONJ]** (the
flagship, §5). "hcComb is proved to vanish iff rectangular" and "hcComb's cohomological meaning is
proved" are not the same claim; only the first holds.

## 1.3 The abstract substrate (substrate-neutral core)

Above the combinatorial layer sits `Abstract.lean` (miner 01), polymorphic over `World` and
`Formula`, importing nothing beyond `Mathlib.Data.Set.Basic`. Definitions: `Abd` (admissible
worlds compatible with evidence `E`), `SharedInvariant`, `IsDecomposable` (the amalgamation /
factorization property whose failure HC measures), `HasInterpolant`, `HasSharedDefinability`,
`HasCrossDiscovery`. Its four theorems (all [KV], cited to a "monograph"):
- `reverse_direction` (Thm 4.6): shared invariance + shared-equivalent admissible worlds
  disagreeing across a valid cross-entailment ⇒ no shared interpolant.
- `forward_direction` (Thm 4.7): decomposability + shared definability ⇒ interpolant reconstructed.
- `no_discovery_under_decomposability` (Thm 7.5).
- `oscillation_theorem` (Thm 7.7). See §2.6.

Theory.md §3 asserts [PROBE/STANCE] these four are proved "from no axioms at all (not even
choice)" — a strong, `#print axioms`-checkable claim flagged for independent confirmation
(miner 01, §7 Γ).

**Bridge caveat** (miner 01, honest): within the mined slice, the connection between the abstract
`IsDecomposable`/`HasInterpolant` layer and the concrete `IsRect`/`hcComb` layer is *asserted in
prose*, not linked by an explicit Lean reduction theorem inside `Abstract.lean`/`Combinatorial.lean`.
The instantiation is performed downstream (`FiberedInterpolation.lean`, `FiveWayInterpolation.lean`,
`FOL/Amalgamation.lean`), where the abstract triple is concretely specialized.

---

# 2. Theorem inventory by subsystem, with dependency spine

The dependency spine, top to bottom:

```
Abstract.lean  (substrate-neutral: reverse/forward_direction, oscillation_theorem)
   │
Combinatorial.lean  (hcComb, IsRect, hcComb_eq_zero_iff_isRect)          ── bipartite support
   │                                                                          │
MutualInformation.lean  (fiveWay_uniform: the 4-item bipartite TFAE)  ◄──────┤
   │                                                                          │
Fibered/FiberedInterpolation.lean  (fiveWay_full: the SIX-way)  ◄────────────┘
   │
Multipartite.lean / Marginals.lean  (hcCombPi, hullPi, projS, presheaf law)
   │
FiveWayPi.lean  (fiveWay_uniformPi: exact five-way at arity n)
   │
ApproximateFiveWay.lean  (THE QUANTITATIVE two-sided bound: 2(hcCombPi/|κ|ⁿ)² ≤ TC ≤ log(|hull|/|κ|))
   │
HigherObstruction / ParityFamily  (shadow-blindness, Specker non-gluing, 2^(n-1) defect)
   │
Amalgamation / GrahamBridge  (positive Vorobev: RIP/acyclic ⇒ glues; decidable acyclicity)
   │
AffineEngine / CyclicConverse / VorobevConverse / Dirac  (the converse: not-acyclic ⇒ not-glues)
   │
FOL/*  (the first-order lift: compact Polish Borel type space, Beth-conditional amalgamation)
```

Information-theory backbone (`ZPM/InformationTheory/`, general-purpose, HC-consumed) sits to the
side and feeds the measure legs: KL / Pinsker / total correlation / mutual information (§2.9).

## 2.1 Bipartite support layer and the anchor biconditional (miner 01)

`Combinatorial.lean` — all hand-written Finset proofs, no `decide`:
- `subset_prod` [KV]: `κ ⊆ projL κ ×ˢ projR κ`.
- **`hcComb_eq_zero_iff_isRect`** [KV] — the headline biconditional (framing): `hcComb κ = 0 ↔
  IsRect κ`.
- `isRect_iff_cross_closed` [KV]: `IsRect κ ↔ ∀ a ∈ projL κ, ∀ b ∈ projR κ, (a,b) ∈ κ` — "no
  hidden coupling": individually-admissible values recombine.
- `isRect_of_projL_card_le_one`, `isRect_of_projR_card_le_one` [KV] — a one-element marginal forces
  a rectangle.
- `isRect_restrictL_singleton`, `isRect_restrictR_singleton` [KV] (Thm 8.5): **singleton private
  evidence resolves** — restricting one component to a single value always yields a rectangle.
- `hcComb_restrictL_singleton` [KV]: corollary, `hcComb (restrictL κ {a}) = 0`. (No symmetric
  right-corollary is stated — a deliberate economy, flagged by miner 01.)

## 2.2 Spekkens toy-model instance (miner 01)

`Spekkens.lean`, over `Fin 4 × Fin 4`, attributed to "Spekkens 2007" (§3). All numeric facts by
`by decide`:
- `kId_hcComb = 12`, `kX_hcComb = 12`, `kZ_hcComb = 12`, `kY_hcComb = 12` [decide] — the four
  maximally-entangled correlations.
- `kSep_hcComb = 0`, `kFull_hcComb = 0` [decide] — separable and full-ignorance states factor.
- `kPartial_hcComb = 10` [decide] — an intermediate partially-entangled state.
- `kId_restrictR_pair_unresolved = 2`, `kId_restrictL_pair_unresolved = 2` [decide] — **shared /
  private *pair* evidence cannot resolve** (`hcComb = 2 > 0`).
- `oscillationTrajectory_profile = [0, 12, 2, 0]` [decide] — the capacity profile along
  `κ_full → κ_id → κ_id|(A∈{0,1}) → κ_id|(A=0)`.
- `spekkens_oscillation_witness` [KV], `spekkens_not_perpetually_rectangular` [KV] — the `0 → >0 →
  0` shape is non-vacuously realized.

Honesty note (miner 01): the Spekkens facts are proved *directly* from the combinatorial layer,
not by *instantiating* the abstract `oscillation_theorem` as a Lean lemma. The docstring's
"witness to the oscillation theorem" is a correctly-scoped narrative match of the numeric shape
`0 → >0 → 0`, not a machine-checked instantiation. The layer self-labels [STANCE]: "an
illustrative instance of the support layer, not core pure mathematics."

## 2.3 The information-theoretic leg and the bipartite five/six-way (miners 02, 03)

**Bipartite MI leg** (`MutualInformation.lean`, miner 03):
- `uniformMeasure κ hκ := (PMF.uniformOfFinset κ hκ).toMeasure` [def].
- `uniform_eq_product_iff_isRect` [KV] — the bridge lemma: uniform joint = product of its marginals
  `↔ IsRect κ`.
- **`mutualInformationReal_uniform_eq_zero_iff_isRect`** [KV] — the information-theoretic leg: the
  uniform distribution on `κ` has zero mutual information between its coordinates `↔ IsRect κ`.
- **`fiveWay_uniform`** [KV] — the bipartite TFAE. NAMING NOTE (miners 03, 02, 04 concur): the
  `List.TFAE` literally contains **four** items — `[IsRect κ, hcComb κ = 0, MI = 0, cross-closed]`
  — and its own docstring says "four legs," though the theorem is *named* "Five-Way." The fifth
  leg (interpolation) is added by the fibered file. This is a naming convention, not a claim-vs-proof
  mismatch.

**The genuine (fibered) five-way** (`Fibered.lean` + `FiberedInterpolation.lean`, miner 02): the
shared-coordinate model `κ ⊆ S × A × B`, with each `s : S` indexing a fiber `fiber κ s ⊆ A × B`.
- `fiveWay_fibered` [KV] — the **Four-Way** (explicitly named so): `FiberRect`, `Decomposable`,
  `FiberProductSurjective`, `FiberCI` are TFAE. Interpolation still missing at this point.
- `interp_iff_decomposable` [KV]: interpolation ⇔ decomposability (i ⇔ ii), by instantiating the
  abstract `reverse_direction`/`forward_direction` at the fibered model.
- **`fiveWay_full`** [KV] — the **genuine Five-Way**, a SIX-element `List.TFAE`:
  `[HasInterpolationProperty, Decomposable, Amalgamable, FiberRect, FiberCI,
  FiberProductSurjective]`. NAMING NOTE (miner 02): the sixth element is decomposability in its
  model-theoretic amalgamation form (`Amalgamable`), a *duplicate-with-different-form* of leg (ii),
  not a genuine sixth leg. The corpus's own name is "the genuine Five-Way."

This is the six-way equivalence the task foregrounds: **interpolation (i) ⇔ decomposability (ii)
⇔ amalgamation (ii′) ⇔ fiber-rectangularity (iii) ⇔ fiber-CI (iv) ⇔ fiber-product surjectivity
(v)** — the vanishing of one number is simultaneously a logical, model-theoretic,
information-theoretic, combinatorial, and geometric statement (Theory.md §0).

## 2.4 The exact five-way at arity n (miner 04)

`FiveWayPi.lean`:
- **`fiveWay_uniformPi`** [KV] — the exact five-way at arity n, a five-element `List.TFAE`:
  1. `IsRectPi κ` (rectangularity),
  2. `hcCombPi κ = 0` (vanishing combinatorial defect),
  3. `totalCorrelationReal (uniformMeasurePi κ hκ) = 0` (vanishing total correlation),
  4. cross-closure (`∀ f, (∀ i, f i ∈ projPi κ i) → f ∈ κ`),
  5. the counting identity (`∀ f, ∏ i, countPi κ i (f i) = if f ∈ κ then κ.card^(n-1) else 0`).

  The `5 → 4` direction is a genuinely nontrivial converse (positivity of every factor), which is
  *why* leg 5 was promoted from proof-internal backbone to a TFAE leg (miner 04, discovery-URS
  OUTCOME 3). Supporting: `totalCorrelationReal_uniformPi_eq_zero_iff` [KV],
  `uniformMeasurePi_eq_pi_of_isRectPi` [KV], `prod_countPi_of_isRectPi` [KV].

## 2.5 THE QUANTITATIVE approximate five-way — the information bound (miner 05) — HEADLINE

`ApproximateFiveWay.lean`. Named by its miner "the field's first non-vacuous quantitative
prediction." The two-sided sandwich (two separate theorems on the same LHS quantity):

**Lower leg** (shape forces information):
- `le_totalCorrelationReal_of_marginal_le` [KV] — the general form, with a monoid-valued floor
  family `c : ι → ℝ≥0` as the "knob": for any probability measure `P` supported on `κ` whose
  coordinate marginals are floored by `c` on exposed values,
  `2 * (hcCombPi κ · ∏ᵢ cᵢ)² ≤ totalCorrelationReal P`.
- **`lower_totalCorrelationReal_uniform`** [KV] — the canonical section instance:
  `2 * (hcCombPi κ / |κ|^(Fintype.card ι))² ≤ totalCorrelationReal (uniformMeasurePi κ hκ)`.
  i.e. **`2 (hcCombPi / |κ|ⁿ)² ≤ TC`.**
- `totalCorrelationReal_uniform_pos` [KV]: `hcCombPi κ ≠ 0 → 0 < totalCorrelationReal
  (uniformMeasurePi κ hκ)` — the quantitative form of the five-way's information leg.

**Upper (counting) leg** (fibre-crawling, no structural content):
- **`totalCorrelationReal_uniform_le`** [KV]: `totalCorrelationReal (uniformMeasurePi κ hκ) ≤
  Real.log (|hullPi κ| / |κ|)` — the counting bound.

So the full sandwich the task names, **`2 (hcCombPi/|κ|ⁿ)² ≤ TC ≤ log(|hullPi κ|/|κ|)`**, is the
combination of `lower_totalCorrelationReal_uniform` and `totalCorrelationReal_uniform_le`. Honesty
note (miner 05, Γ-6): no single Lean theorem states the two-sided inequality as one statement; the
sandwich is the true, direct combination of two individually-proved bounds sharing the same LHS.

Bipartite witness: `mutualInformationReal_uniform_image_lower` [KV] — the multipartite lower leg
specialized to `Fin 2` and re-expressed in the bipartite module's vocabulary (`hcComb`,
`mutualInformationReal`).

Proof route: Pinsker's set-bound lemma `two_sq_sub_le_klDivReal` (from
`ZPM.InformationTheory.Pinsker.General`, §2.9) applied at the forbidden set `F = hullPi κ \ κ`,
whose product-of-marginals mass is `≥ hcCombPi κ · ∏ᵢ cᵢ`, combined with
`absolutelyContinuous_pi_marginal` (an unconditional AC lemma the build found stronger than first
stated). The constant `2` is literal (design-stage placeholder `pinskerConst` resolved to 2).

**The "one dial" conjecture** [CONJ] (miner 05): the identification of the grading codomain with
the weighting structure — that the floor family's monoid and the grading monoid are one parameter
— is the PI's named conjecture. `le_totalCorrelationReal_of_marginal_le` is its "first statability
witness, not its proof." Remains [CONJ].

## 2.6 The oscillation theorem (miners 01, 13)

`oscillation_theorem` [KV] (`Abstract.lean`, Thm 7.7): for a step-indexed family, if shared
definability holds at every step and cross-domain discovery holds at *some* step, then
decomposability does **not** hold at every step. Via the combinatorial layer: `∃ t, HC(κₜ) > 0`.
The field-note gloss (Theory.md §3, [STANCE]): "a trajectory of ignorance structures that ever
exhibits a cross-domain discovery cannot have been factorable at every step — the obstruction must
spike. Discovery has a conservation law, and `hcComb` is what it conserves against."

Its FOL-carrier instance, `typeOscillation` [KV], exists **only in the puremath tree** (miner 13;
see §6) — a direct instantiation of `oscillation_theorem` at the type carrier, its one substantive
feature being the explicit `HasSharedDefinability` (Beth) hypothesis, "exactly where the first-order
content enters." Also witnessed concretely by the Spekkens `[0,12,2,0]` trajectory (§2.2).

## 2.7 Multipartite substrate, marginals presheaf, higher obstruction, parity (miner 04)

**Marginals as a presheaf** (`Marginals.lean`):
- `projS κ S := κ.image S.restrict` [def] — the marginal over a sub-team `S`.
- `projS_image_restrict₂` [KV] — **the presheaf law**: the restriction map carries the T-marginal
  onto the S-marginal; the compatibility any Čech-type complex over the marginal family consumes.
- `piFinset_image_restrict` [KV] — "the genuinely new combinatorial lemma": the restriction image
  of a product of nonempty factors is the product of restricted factors.
- `hullPi_projS` [KV] — the hull commutes with marginalization; sharp (fails for `κ = ∅, S = ∅`,
  kernel-witnessed).
- **`hcCombPi_projS_le`** [KV] — the defect is monotone along marginalization: `hcCombPi (projS κ
  S) ≤ hcCombPi κ`; "the monotone-grading law of the graded signature." Also sharp at `(∅, ∅)`.

**Higher obstruction** (`HigherObstruction.lean`): "the hidden-channel defect is irreducibly
higher-degree: not a function of any proper family of marginal shadows."
- `parity3 := {f : Fin 3 → Fin 2 | f 0 + f 1 + f 2 = 0}` [def].
- `parity3_shadow_blind` [decide]: every proper sub-team marginal of `parity3` is rectangular, and
  the global defect is `hcCombPi parity3 = 4`. "The hidden channel is invisible to all proper
  shadows."
- `specker_consistent` [decide] and `specker_not_glues` [KV] — the **Specker triangle**: three
  pairwise-consistent local structures (`diag01`, `diag12`, `anti02` over teams `S01`, `S12`,
  `S02`) that expose the same interface projections but have **no global gluing**. "Consistent local
  sections, no global section — the first nonzero Čech-type obstruction, in kernel-checkable form."
  `specker_not_glues` is a hand-written 12-line parity contradiction (a `decide` over 256 candidate
  relations hit `maxRecDepth`).

**The parity family schema** (`ParityFamily.lean`): `parityRel n := {f : Fin n → ZMod 2 | ∑ f i =
0}`.
- `projS_parityRel` [KV]: every proper sub-team marginal is `= Finset.univ` (the full cube —
  strictly stronger than mere rectangularity).
- `card_parityRel` [KV]: `2^(n-1)` configurations for `n ≥ 1`.
- **`hcCombPi_parityRel`** [KV]: `hcCombPi (parityRel n) = 2^(n-1)` for `n ≥ 2` — half the hull.
  Sharp: the defect is 0 at n = 1.
- `parityRel_shadow_blind` [KV]: at every arity `n ≥ 2` all strict shadows are rectangular yet
  `0 < hcCombPi` — the hidden channel is irreducibly n-body at every arity. (Uses positivity, not
  the exact value, though the exact value is available — a minor strength asymmetry versus the n=3
  witness, flagged by miner 04.)
- `parityRel_three` [decide]: `parityRel 3 = parity3` — schema meets witness (a `decide`-checked
  equality of finsets over the isomorphic-but-not-syntactically-identical `Fin 2` vs `ZMod 2`).

## 2.8 The product law and the fiber-product join (miners 02, 03)

**Product law / juxtaposition** (`ProductLaw.lean`, miner 03): `sumRel κ₁ κ₂` over `ι₁ ⊕ ι₂`.
- `card_sumRel` [KV]: size is multiplicative (unconditional).
- `hullPi_sumRel` [KV]: hull is multiplicative on nonempty structures (sharp at the empty-index
  corner: the hull of the empty structure over no parts is the unit configuration — the "third
  independent appearance of that boundary").
- **`hcCombPi_sumRel`** [KV] — **the Leibniz rule for the defect**: `hcCombPi (κ₁ ⊗ κ₂) = hcCombPi
  κ₁ · |hullPi κ₂| + |κ₁| · hcCombPi κ₂`. The defect is a **derivation**, not a homomorphism. The
  homomorphic invariant is the bi-grading `(|hull|, |κ|) : ℕ × ℕ` under `×`; `hcComb` is its
  difference-derivation. The additive scalar form `log(|hull|/|κ|)` is exactly the counting-bound
  upper leg of §2.5 (a predicted three-face coincidence, discussed in `PRODUCT_LAW_URS.md`).
- Kernel-swept KILLs (miner 03): the multiplicative law `L-mult` and additive law `L-add` are both
  refuted at `n = (2,2)`; subadditivity under union `B-union` fails (the hull-jump under union is
  the oscillation theorem's mechanism, now with a quantitative witness class).

**The fiber-product join over a genuine interface** (`FiberProduct.lean`, miner 02): `join T₁ T₂
κ₁ κ₂` — the natural join, the largest relation whose `T₁`/`T₂`-marginals lie in the factors.
- `subset_join_projS` [KV]: `κ ⊆ join (its own marginals)`, unconditionally.
- **`hcCombPi_eq_join_add_gap`** [KV] — **THE DECOMPOSITION**: under a cover `T₁ ∪ T₂ = univ`,
  `hcCombPi κ = hcCombPi (join own) + (|join own| − |κ|)`. The defect splits into the two-local
  reconstruction defect plus the RECONSTRUCTION GAP (the quantitative failure of two-locality). On
  `parity3` the entire defect is gap (marginals full) — shadow-blindness quantified.
- `projS_join_left`, `projS_join_right` [KV] — two-cover amalgamation: two structures whose
  interface marginals agree always glue.
- `hcCombPi_join_ne_leibniz` [decide] — **Leibniz dies at a genuine interface**: the ⊗-Leibniz law
  applied to the diagonal structures over interface `{1}` is false (`6 ≠ 12`), kernel-checked.
- **[CONJ] C-JLeib≤** (`FIBER_PRODUCT_URS.md`, SJ6): `hcCombPi (join κ₁ κ₂) ≤ d₁·|hull κ₂| + k₁·d₂`
  at genuine interfaces — the "interface only tightens" direction. One-ambient evidence, **unproved**.

## 2.9 Information-theory backbone (miner 11) — general-purpose, HC-consumed

`ZPM/InformationTheory/` (25 files in miner 11's slice). Assessed as **general-purpose
infrastructure the HC programme consumes, not HC-specific mathematics** (no file imports from
`Measurements/HC/`; the only HC hooks are forward-pointer docstrings). The Pinsker derivation
chain the approximate five-way rides on:

```
two_sq_le_neg_log_one_sub, two_sq_le_neg_log    (boundary bounds)
        ▼
binary_pinsker : 2(p−q)² ≤ klBin p q            (sharp constant 2)
        ▼
klBin_le_klDivReal : klBin(P(A),Q(A)) ≤ klDivReal P Q   (DPI for indicators, via Jensen)
        ▼
two_sq_sub_le_klDivReal : 2(P(A)−Q(A))² ≤ klDivReal P Q ◄── consumed by ApproximateFiveWay lower leg
        ▼
pinsker_proof : tvDistReal P Q ≤ sqrt(klDivReal P Q / 2)
```

Other backbone results [KV]: `klDivReal` (the ℝ-valued KL layer) and its Mathlib bridge
`klDivReal_eq_toReal_klDiv`; `klDivReal_fintype` (finite-sum form); `klDivReal_nonneg`;
`klDivReal_eq_zero_iff` (`= 0 ↔ P = Q`, finite-KL essential); `klDivReal_compProd` (integral
conditional chain rule, filling a gap Mathlib's additive chain rule cannot); `klDivReal_map_
measurableEquiv` (invariance under measurable equivalence); `klDiv_pi`/`klDiv_pi'` (KL
tensorization over finite products); `totalCorrelationReal := klDivReal P (∏ᵢ P.map(eval i))`
(Watanabe's total correlation) with `totalCorrelationReal_fin_two` = MI; `mutualInformationReal`
and `mutualInformationReal_eq_zero_iff_product` [KV].

## 2.10 The discrete Vorob'ev converse — acyclic ⟺ gluing (miners 06, 07, 08) — HEADLINE

The v0.2 headline arc: the discrete local-to-global obstruction made constructive on the nerve.

**Positive direction — amalgamation** (`Amalgamation.lean`, `GrahamBridge.lean`, miner 06):
- `LocalStruct`, `Consistent` (pairwise interface-marginal agreement), `Glues` (a global structure
  realizes every member), `joinFam` (the natural join), `RIP` (running intersection property) [def].
- `projS_joinFam` [KV] — **the amalgamation theorem** (positive Vorob'ev, certificate form): the
  natural join of a running-intersection, pairwise-consistent family realizes every member exactly.
- **`glues_of_rip`** [KV]: RIP + consistent ⇒ glues.
- `acyclic_iff_grahamReducible` [KV] — **the Graham bridge**: acyclicity ⇔ Graham/GYO ear-reduction.
- `decidableAcyclic` [decide] — **the payoff**: acyclicity is decidable (`decide`, never
  `native_decide`).
- **`glues_of_acyclic`** [KV] — the order-free headline: a pairwise-consistent family with
  duplicate-free teams over an acyclic cover glues, with fully checkable hypotheses.
- `speckerFam_not_glues` [KV], `speckerCover_not_acyclic` [decide], `pathCover_acyclic` [decide] —
  the triangle is unorderable + unglued; the path is acyclic.

**The affine obstruction engine** (`AffineEngine.lean`, `CyclicConverse.lean`, miner 07): the
witness machinery for CONSISTENT NON-GLUING families over `ZMod 2`.
- `exists_parity_solution` [KV] — the solvability core: elementary Gaussian elimination over
  list-presented F₂ parity systems.
- `imarg_affLocal` [KV] — the exact marginal computation (the interface sees exactly the visible
  constraints).
- `consistent_affFam` [KV], `not_glues_affFam` [KV] — **the obstruction theorem**: a hosted odd
  dependency kills every glue (summing the satisfactions forces `0 = 1` in `ZMod 2`).
- **`affine_obstruction`** [KV] — packaged: a closed coherent system with a hosted odd dependency
  yields a consistent family of nonempty local relations that does not glue — **the explicit
  non-splitting F₂ cocycle.**
- `clean_system_obstruction` [KV], `cycle_obstruction` [KV] — the unified consumption theorem, and
  the chordless-cycle rung. NAMED-BUT-UNBUILT (miner 07): `clean_system_obstruction`'s docstring
  names four "witness rungs" — chordless cycles, even boundary data, landings, `H_k` clique
  parities — of which only chordless cycles is instantiated here.

**The Vorob'ev converse and Dirac** (`VorobevConverse.lean`, `Dirac.lean`, miner 08):
- `clean_system_of_uncovered_clique` [KV] — the clique datum: a non-conformal cover yields a clean
  system.
- `isEarOf_of_simplicial` [KV] — the one-step GYO collapse.
- `capstone_of_dichotomy` [KV] — the capstone modulo the dichotomy (takes the chordal/conformal
  dichotomy as a hypothesis `hdi`, discharged by Dirac).
- **`dirac_strong`** [KV] — **Dirac's lemma, strong form**: in a chordless-cycle-free adjacency
  structure, every finite vertex set is complete or contains two distinct non-adjacent simplicial
  vertices. Formalized from first principles over a bespoke path grammar (minimal-separator
  argument, `maxHeartbeats 1600000`) because **Mathlib has no chordality theory** ([PROBE]:
  "floored: zero names").
- `earFree_dichotomy` [KV] — an ear-free cover is non-conformal or contains a chordless cycle.
- `exists_consistent_not_glues_of_not_acyclic` [KV] — **the capstone, unconditional**: every
  non-acyclic cover hosts a consistent non-gluing family.
- **`acyclic_iff_forall_consistent_glues`** [KV] — **THE DISCRETE VOROB'EV THEOREM (the headline)**:
  a cover is acyclic ⇔ pairwise consistency forces gluing. Axioms `[propext, Classical.choice,
  Quot.sound]`, 0 sorry, decide-free (no `native_decide`).

Honesty note (miner 08): the Vorob'ev-converse ledger (`CYCLIC_CONVERSE_URS.md`, 706 lines)
records **four rounds of conjecture-then-refutation** (team-parity DBC, the two-move disjunction,
HeartB / boundary-parity engine — all KILLED and found false by construction; a vacuity A4 alarm)
before the surviving affine-engine construction. The named conjecture C-ENGINE / D23 (the
blocked-vs-landing decomposition) was **not proved — it was BYPASSED** ("the wrong frame");
the eventual chordal-vs-conformal route supersedes it. The Lean files show only the clean
end-state. A `sorry`-on-disk incident (twice, caught before compile) is logged in
`GRAHAM_BRIDGE_URS.md`.

## 2.11 The FOL lift — compact Polish type space, Beth-conditional amalgamation, Pcorr (miners 09, 10) — HEADLINE

**The type-space carrier (R1–R3)** (`FOL/TypeSpaceTopology/Compact/Separation.lean`, `Polish.lean`,
miner 09): inside Mathlib's `FirstOrder.Language.Theory.CompleteType T α`, a chain of seven
kernel-verified instances turning the first-order complete-type space into a **compact Polish Borel
Stone space**:
- `instTopologicalSpace` [def] — the Stone topology, `generateFrom (range typesWith)`.
- `isClopen_typesWith` [KV] — the basic sets are clopen.
- **`instCompactSpace`** [KV] — compactness, via **Alexander's subbasis theorem**
  `isCompact_generateFrom` (the FOL compactness theorem in topological form; a basic cover's
  negation theory is unsatisfiable, so has a finite unsatisfiable subtheory = a finite subcover).
- `instTotallySeparatedSpace` [KV] ⇒ `t2Space`, `totallyDisconnectedSpace` [KV].
- (for countable languages) `instSecondCountableTopology` → `instMetrizableSpace` (Urysohn) →
  `instCompletelyMetrizable` → **`instPolishSpace`** [KV] → `instMeasurableSpace := borel _` +
  `instBorelSpace` [KV].

This carrier is the load-bearing FOL-specific ingredient consumed by the measurability-obstruction
leg and (per docstring) by ZPM's Choquet/analytic tower and the FLT borel→analytic bridge.

**The FOL five-way** (`FiveWayStructural.lean`, `FiveWayInterpolation.lean`, `FiveWayCI.lean`,
miner 10):
- `fiveWayStructural_tfae` [KV] — the geometry legs (`Decomposable`, `FiberRect`,
  `FiberProductSurjective`) over arbitrary `{S A B : Type*}`, Set-based (so they apply to the
  infinite carrier).
- `shared_definability` [KV] — proved *unconditionally* here (a finitary `∃` witness).
- **`fiveWay_fol`** [KV] — the first-order Five-Way (minus the open CI leg): interpolation (i),
  decomposability (ii), amalgamation (ii′), fiber-rectangularity (iii), fiber-product surjectivity
  (v), TFAE.
- `analytic_nullMeasurable`, `marginal_nullMeasurable` [KV] — leg iv's measurability obstruction:
  marginalizing a definable family is an existential projection = an analytic (Suslin) set, not
  Borel in general; the carrier makes it null-measurable. `mi_eq_zero_iff_product` [KV].

**Genuine first-order amalgamation** (`FOL/Amalgamation.lean`, miner 10): over the single type
space `St(S ⊕ A ⊕ B)` with real `L[[·]]`-sentence vocabularies.
- `TypeAmalgamable κ := IsDecomposable SatT SharedEqT IsLeftT IsRightT κ ∅` [def] — genuine
  type-reduct amalgamation, a *genuinely different* instantiation than the carrier-agnostic case.
- `sharedInvariantT` [KV].
- **`typeReverse_direction`** [KV] — **the first-order hidden channel** (reverse direction,
  unconditional): non-amalgamable ⇒ no shared interpolant; the shared vocabulary is blind to the
  coupling between private blocks.
- **`typeAmalgamable_imp_interp`** [KV] — the first-order Maksimova correspondence (forward
  direction), **Beth-conditional**: takes `HasSharedDefinability` (= Beth definability) as a
  hypothesis. THE GENUINE DISCOVERY (miner 09/10, [STANCE], corroborated by code): in the
  carrier-agnostic case shared-definability was a finitary `∃` and provable; over real types the
  shared witness must be an actual `L[[S]]`-sentence = Beth definability. Craig/Beth are **not in
  Mathlib** ([PROBE]), so this stays a hypothesis. The lift is honestly non-clean here, and
  amalgamation *strengthens* into a real model-theoretic property.

**Support/distribution separation — Pcorr** (`LegIVBridge.lean`,
`SupportDistributionSeparation.lean`, miner 10):
- `support_prod` [KV] — the support of a product measure is the product of supports (a general
  lemma **absent from Mathlib**, [PROBE]).
- `mi_zero_imp_rectangular_support` [KV] — the one-way (easy) bridge: MI = 0 ⇒ rectangular support,
  for any probability measure.
- **`support_distribution_separation`** [KV] — **the converse genuinely fails**: the explicit
  witness `Pcorr` on `Bool × Bool` (mass 3/8 on each diagonal, 1/8 off-diagonal) has **rectangular
  support** (`Pcorr_support_rectangular`) yet is **not a product** (`Pcorr_ne_product`:
  `Pcorr{(tt,tt)} = 3/8 ≠ 1/2·1/2 = 1/4`). So support-level factorization does NOT entail
  distribution-level factorization — "the measure-theoretic form of the **CHSH Pl-kill**."
  Support-level and distribution-level HC are separated in general and unified exactly at the
  canonical/uniform measure (`mutualInformationReal_uniform_eq_zero_iff_isRect`, the unification
  witness).

**The DEEP FINDING** (miner 09/10, Dhruv probe "clean lift, or a 7th leg?"): the five "clean" legs
lift cleanly *because they are carrier-agnostic* (they would hold for finite sets, reals, anything)
— so that lift is **shallow**. The genuinely first-order content lives in exactly the two places
the lift is NOT clean: (a) leg iv changing interpretation (support→distribution, since there is no
uniform measure on the infinite type space) — NOT a 7th leg unless a canonical measure is fixed;
(b) amalgamation, which collapses to trivial set-recombination in the carrier-agnostic model but
becomes genuine and *fallible* at the single type space — **that failure is the first-order hidden
channel.**

## 2.12 Landed contact with hard external problems (Theory.md §3, miner 13)

- `EMX/Kuratowski reverse direction` [KV, partial] — the reverse direction of the
  Ben-David–Hrubeš–Moran–Shpilka–Yehudayoff compression theorem (learnability undecidability,
  Nature MI 2019) is closed in Kuratowski form (a compression scheme forces the aleph bound); the
  forward direction is a documented axiom-of-choice seam.
- `PvNPInFrame` [KV] — the field formalizes the *collapse* of the naive P-vs-NP reframing; a
  standing non-claim: no leverage on P vs NP (the feasible-interpolation route is a name collision,
  crypto-barriered).

## 2.13 The offshoot: Gaussian KL for PAC-privacy (miner 12) — NOT core HC

`ZPM/InformationTheory/KullbackLeibler/Gaussian/` (6 files). **Verdict (miner 12, high confidence,
triangulated by import graph + git status): an OFFSHOOT module (PAC-privacy / crypto-learning-
theory support), not part of the core HC discovery tree.** No file under `Measurements/HC/` imports
it; its stated consumer `mutualInformationReal_le_condKL` does not yet exist in the tree; its
citations point to Xiao-Devadas PAC-Privacy (arXiv:2210.03458), not HC. Content [KV]: the full
multivariate Gaussian–Gaussian KL closed form `klDivReal_multivariateGaussian` (matches Cover &
Thomas), via a whitening/diagonalize-and-tensorize chain. Catalogued here as offshoot
infrastructure for completeness, not as HC discovery content.

---

# 3. Organized bibliography

Every citation from every miner, deduped, grouped by the claim it supports. IDs are transcribed
verbatim; where none is present the corpus's own "no id given" is preserved. **No id is fabricated.**
Miners who touched each work are noted. The overwhelming majority of the `.lean` files carry **zero
external citations**; the bibliography lives almost entirely in the two field notes (`Theory.md`,
`FOUNDATIONS.md`) mined by miner 13, plus the two Atserias–Kolaitis references and the Gaussian
sub-library's textbook cites.

## 3.1 Resolvable identifiers (arXiv / venue present)

- **Atserias–Kolaitis, arXiv:2312.02023** (generalizing BFMY 1983). Supports: the chordal/conformal
  dichotomy in the Vorob'ev-converse proof route; the classical cyclic witnesses shown to be Tseitin
  gadgets = the affine engine at modulus d; the "monoid-consistency parameter" suggested as the
  grading codomain / support↔distribution "one dial." (miners 08, 13; direction-only in miner 05's
  slice.) The *arXiv id* appears only in `CYCLIC_CONVERSE_URS.md` (miner 08); elsewhere it is cited
  by surname pair.
- **Xiao-Devadas, arXiv:2210.03458** — PAC-Privacy log-det surrogate. Supports the OFFSHOOT Gaussian
  KL module's stated purpose (miner 12; via `QuadraticFormExpectation.lean`). Not core HC.
- **Sayed Ahmed, arXiv:1309.0681** — cylindric/polyadic interpolation⟺(super)amalgamation survey;
  also the "977 KB survey" in which "rectangular" does not appear (the absent-grading finding).
  (miner 13.)
- **Mann, arXiv:0711.4376** — cylindric-placement primary source. (miner 13.)
- **Kohlas, arXiv:1804.02840** — Q4 rejection: Kohlas CI = valuation/information-algebra substrate,
  not cylindric. (miner 13.)
- **Vigneaux, arXiv:1709.07807 and arXiv:2003.02021** — information cohomology; the
  nondegenerate-product definition invokes the exact inclusion `E_XY ↪ E_X × E_Y` (the
  support-vs-hull comparison this field grades) as a *nondegeneracy hypothesis assumed to hold*,
  and never grades the defect itself. The decisive information-cohomology boundary/Pl-kill. (miner
  13; ids in the Theory.md §12 ledger table.)
- **Cuzzolin, "geometry of relative plausibility and relative belief of singletons," Ann. Math.
  Artif. Intell. 2010** (plus a Springer 2021 monograph, book title not quoted). The fibre-side
  sibling: geometrizes the *measure* side (the simplex of belief functions = the fibre of `F`).
  "Route through, never home." (miner 13.)
- **H. Q. Minh, "Regularized Divergences Between Covariance Operators and Gaussian Measures on
  Hilbert Spaces," J. Theoret. Probab. 34 (2021), arXiv:1904.05352** — the infinite-dimensional
  generalization, explicitly scoped OUT of the Gaussian module's finite-dimensional content. (miner
  12; offshoot.)
- **T. M. Cover and J. A. Thomas, Elements of Information Theory, 2nd ed., Wiley, 2006** (no
  arXiv/DOI, standard book cite) — the scalar and multivariate Gaussian KL closed form. (miner 12;
  offshoot.)

## 3.2 Named works, no id given (year sometimes present)

Supporting **the cylindric-algebra substrate placement**:
- **Monk, "Leon Henkin and Cylindric Algebras"** (title only). Cylindrification = coordinate
  projection; the equational rectangularity form `c(Γ)a · c(Δ)a = c(Γ∩Δ)a`. (miner 13.)
- **Maksimova** (no id) — "logic has Craig interpolation iff the variety has super-amalgamation";
  the interpolation⟺amalgamation correspondence, "fifty years old, stays inside algebraic logic."
  (miner 13; also named in `FOL/Amalgamation.lean`, miners 09, 10 — bare attribution, no id.)
- **Madarász, Sági, Németi** (no ids) — co-cited with Maksimova / Sayed Ahmed for the
  interpolation⟺superamalgamation correspondence. (Sági appears only in FOUNDATIONS.md; Maksimova
  only in Theory.md's version of this cluster — a minor citation-list asymmetry, miner 13.)

Supporting **the classical local-to-global / gluing result**:
- **Vorob'ev 1962** (no title/id). (miners 06, 08, 13 — the "Vorob'ev" namesake; expansion presumed
  N.N. Vorob'ev but never given in-corpus.)
- **Beeri–Fagin–Maier–Yannakakis 1983 / "BFMY 1983"** (no title/id; the acronym is never expanded
  in-corpus). Acyclic database schemes; gluing forced exactly when the cover is acyclic. (miners 06
  "GYO", 08, 13.)

Supporting **the contextuality / cohomology lineage**:
- **Abramsky–Brandenburger** (no id) — sheaf contextuality, "the deepest sibling and the field's own
  lineage for the cohomological reading"; shares the support-level obstruction-to-global-section but
  its gradings are binary / LP-fractional / cohomological classes, none a cardinality defect, and
  the logic legs are absent. (miner 13.)
- **Abramsky–Mansfield–Barbosa** (no id) — the obstruction-as-cohomology, contextuality side,
  tagged [KV] in-file as established literature. (miner 13.)
- **Ó Conghaile** (no id) — the CSP side of obstruction-as-cohomology. (miner 13.)
- **Baudot–Bennequin; Vigneaux** — information cohomology (Vigneaux ids in §3.1). Cocycles are
  entropy/Shannon MI: cohomology of the *fibre*, again. (miner 13.)

Supporting **the base/fibre split and near-neighbours**:
- **Kolmogorov, 1933** (no title/id) — founded uncertainty on measure (σ-additive, ℝ-valued,
  distribution primary); the fibre-side foundation SIF is dual to. (miner 13.)
- **Mayer's structural independence, 2024** (no further id) — support-level, distribution-free (right
  instincts), but binary, ungraded, no information bridge, no logic legs. (miner 13.)
- **Studený's imsets** (no id) — most developed combinatorial-algebraic CI theory; grading lives in
  the dual supermodular cone over a *distribution* — combinatorial but fibre-graded. (miner 13.)
- **Gács–Körner** (no id) — common information → nonnegative rank → extension complexity corridor.
  (miner 13.)
- **Yannakakis** (no id) — rectangle defect ↔ nonnegative rank ↔ extension complexity. (miner 13.)
- **Goodrick–Kim–Kolesnikov** (no id, "lineage" only) — amalgamation homology, the model-theoretic
  obstruction lineage. (miner 13.)
- **Krajíček–Pudlák; BPR; Schmid et al.** (no ids, group) — contextuality reaches quantum advantage,
  not P vs NP; feasible-interpolation route barriered. (miner 13.)
- **Federer** (no id) — disambiguation only: "geometric measure theory" is Federer's field
  (rectifiability, currents, Hausdorff measure) and cannot be the name. (miner 13.)

Supporting **named classical theorems used but never cited with an id** (bare namedrops, all "no id
given"): **Spekkens 2007** (the toy model, miner 01 — searched the whole tree, no fuller citation
exists); **Alexander's subbasis theorem**, **Urysohn's metrization theorem**, **Craig
interpolation**, **Beth definability** (miner 09, via Mathlib lemma names); **Watanabe** (total
correlation, miner 11 — name only, no year/title/id); **CHSH** (Clauser-Horne-Shimony-Holt, the
support/distribution boundary, miners 09, 10 — presumed, never cited); **Keisler measure / NIP /
generically-stable** (the canonical-measure open frontier, miners 09, 10 — the single most
load-bearing named-but-uncashed external machinery, invoked in three files, never once with a
citation).

## 3.3 Internal (non-external) references, flagged so they are not mistaken for citations

- **"The monograph"** — theorem numbers 4.6, 4.7, 7.5, 7.7 cited in `Abstract.lean`; no title,
  author, or year given anywhere (miners 01, 10). Presumed the field's own manuscript.
- **"Field note §5"** — cited by `PRODUCT_LAW_URS.md` and `Marginals.lean` for the "monotone grading
  into a constructive ordered monoid" vocabulary; never filename-resolved by miners 03, 04. Now
  identifiable (from miner 13) as `Theory.md` §5 / `FOUNDATIONS.md`.
- **`CHARTER.md`** — the "Duplicate rule exception" governance clause cited by the KL layer (miner
  11); confirmed to exist at `design-lab/measurements/CHARTER.md`, content unread.
- **`project_hc_in_zpm.md` / `project_crypto_learning_theory_pac_privacy.md`** — memory-file
  discovery ledgers referenced by `NOOLOGY_URS.md` and the Gaussian module (miners 09, 12), outside
  the project tree.

---

# 4. Literature-audit / novelty position

## 4.1 Scope of the mine

The corpus's own audit apparatus is concentrated in the two field notes (`Theory.md`,
`FOUNDATIONS.md`). The stated search:
- **Two-pass ancestor audit** [PROBE] (Theory.md §6): **ten works, primary sources, strict "no
  summing of siblings" / anti-vacuity rule** ("generic resemblance = non-finding"). Returned **no
  direct ancestor**.
- **Cylindric-placement verification** [PROBE] (FOUNDATIONS.md §9, dated 2026-06-30, "was CONJ, now
  established by primary sources"): four Q/A verdicts against Monk / Mann / Kohlas / the 977 KB Sayed
  Ahmed survey (see §4.2).
- **Five adversarial dissolution attempts** with explicit license to return "kill" (Theory.md §1):
  the ancestor audit, the cylindric probe, the information-cohomology probe, the complexity probes,
  the Moonshine test. **One target died** (Moonshine, correctly).

Fields spanned: abstract algebraic logic (cylindric/polyadic algebras), sheaf/topos contextuality,
model theory (amalgamation, type spaces), combinatorics/complexity (extension complexity,
marginal-problem ladder), information theory and information cohomology, database theory (acyclicity),
Bell-inequality physics (CHSH), belief-function geometry.

## 4.2 What was cleared (no-ancestor findings) [PROBE]

- **Q2 — DECISIVE, ABSENT** (FOUNDATIONS.md §9): no constructive cardinality grading of
  non-rectangularity exists in cylindric / polyadic / relation algebra. Rectangularity is a Boolean
  predicate there; the dimension set is index-valued, not numeric; "rectangular" does not appear in
  the 977 KB Sayed Ahmed survey. `hcComb = |∏πᵢ| − |κ|` is a **genuine new primitive** on the
  cylindric substrate, not a rediscovery.
- **Q4 — ABSENT** (FOUNDATIONS.md §9): the CI/MI leg and the fiber-product/global-section leg are
  absent from algebraic logic. The five-way's information + geometric bridges are SIF's own.
- **The bridge finding — the single strongest novelty claim** [PROBE] (Theory.md §1): "the bridge
  from the logic pair (interpolation/amalgamation) to the information side (MI/CI) **appears in no
  examined work in any field**."
- **Base/fibre split confirmed as a literature fact, not a framing choice** [PROBE] (Theory.md §4),
  via three independent audits.

What was **INHERITED** (not novel), honestly (FOUNDATIONS.md §9 net verdict): SIF is a
constructively-graded fragment of cylindric set algebra. The substrate + the logic legs
(interpolation/amalgamation) come with the 70-year Henkin–Monk–Tarski toolkit (Q1, Q3 CONFIRMED).
The new primitives are the constructive grading and the cross-domain bridges.

## 4.3 Boundaries and Pl-kills found [PROBE]

- **The CHSH support/distribution boundary** — the `Pcorr` witness (§2.11): support-level and
  distribution-level factorization are separated in general, unified only at the canonical measure.
  HC is a **support-level** invariant. This is a genuine limit, not a defect.
- **The Vigneaux ungraded-hypothesis boundary** — information cohomology invokes the exact
  support-vs-hull inclusion as a *nondegeneracy hypothesis assumed to hold*, and never grades the
  defect. The decisive information-cohomology check: it is cohomology of the fibre, not the base.
- **Moonshine — REJECTED** (Theory.md §10, §12): a four-channel probe killed the direct fit. The one
  target that died in the falsification protocol.
- **Mathlib-library floors** [PROBE] (not academic-literature audits, but genuine coverage checks):
  no chordality theory (`dirac_strong` built from scratch); no Craig/Beth (interpolation leg stays
  Beth-conditional); no `support_prod`; no multivariate-Gaussian density/AC. None state a search
  methodology or Mathlib version — flagged as under-documented audit trails.
- **P vs NP standing non-claim** — `PvNPInFrame` formalizes the collapse of the naive reframing:
  the field proves its own limit.

---

# 5. Open problems and the flagship

## 5.1 The flagship — the cohomological-roots / Euler-characteristic conjecture [CONJ]

The field's deepest and hardest claim (Theory.md §8; FOUNDATIONS.md §11, transcribed near-verbatim
by miner 13):

> Construct a cochain complex canonically attached to an ignorance structure `κ` such that
> **(i)** the factorization obstruction is a class in its cohomology `H•`, with `H• trivial ⟺ κ
> rectangular ⟺ the five-way`; and **(ii)** `hcComb(κ)` is its **degree-zero invariant — an Euler
> characteristic**.

Named traps (honest, in-file): the **degree-zero trap** (the trivial two-term inclusion-complex
reading proves nothing, admissible only as explicitly-labeled scaffolding) and the **context trap**
(`hcComb` is single-context; sheaf contextuality is multi-context; the flagship's complex is "not
literally Abramsky's Ȟ¹" but a Čech complex of the row/column cover of the hull).

**What is proven toward it** [KV]: the discrete gluing stack (§2.10) builds exactly the multi-context
object the flagship needs and proves, in the kernel, the **qualitative core of the intended H¹
statement**: a global section exists for every consistent local family ⟺ the nerve is acyclic
(`acyclic_iff_forall_consistent_glues`), with the obstruction, when acyclicity fails, an **explicit
non-splitting F₂ cocycle** (`affine_obstruction`) rather than a mere existence claim.

**What remains [CONJ]**:
1. **The counting identity `χ = hcComb`** — tying nerve acyclicity to the cardinality grading
   `|⊗κ| − |κ|`. (This is the precise sense in which `hcComb`'s cohomological meaning is *not* yet
   proved, §1.2. Miner 01 independently saw the Theory.md ledger line: "Discrete H¹-side... KV
   (qualitative); χ = hcComb still CONJ.")
2. **The abelian complex** — the genuine cochain complex whose higher cohomology "casts the shadow"
   is still to be constructed paper-first.

## 5.2 The canonical-measure open frontier [CONJ]

The canonical support→measure map: **uniform for finite `κ`**; conjecturally the
**generically-stable Keisler measure under NIP** for infinite `κ` (Theory.md §4; miners 09, 10,
who flag it as the single leading open construction, named identically in four files, never built).
This is the converse `SupportDistributionSeparation` shows genuinely fails at the support level and
that only a canonical measure would supply. It is also what makes leg iv a genuine 7th leg
("obstruction-set is null") rather than always-true infrastructure.

## 5.3 The graded cylindric set algebra — the pinned formal system [STANCE/CONJ]

The recommended formal home (FOUNDATIONS.md §10; Theory.md §5): "the variety of **graded cylindric
set algebras**" — the Henkin–Monk–Tarski signature (Booleans, cylindrifications, diagonals) enriched
with exactly **one new primitive**, a monotone grading `h : A → (constructive ordered monoid)`, and
**one new law**, the coherence `h(a) = 0 ⟺ a rectangular ⟺ interpolation ⟺ amalgamation ⟺ CI ⟺
fiber-product`. Open [CONJ]: the **grading codomain** — ℕ for the bipartite case, a commutative
monoid/semiring for multi-interface and higher arity, where the Atserias–Kolaitis monoid-consistency
parameter suggests the codomain and the support↔distribution knob "may be the same dial" (the "one
dial" conjecture, §2.5).

## 5.4 Smaller named open edges

- **C-JLeib≤** [CONJ] (§2.8): the interface-tightening inequality `hcCombPi(join κ₁ κ₂) ≤ d₁·|hull
  κ₂| + k₁·d₂`. One-ambient evidence, unproved.
- **Named-but-unbuilt witness rungs** (miner 07): even boundary data, landings, `H_k` clique
  parities (only chordless cycles is built).
- **Deterministic-greedy Graham confluence** (miner 06): a strictly stronger, more standard result
  named as an edge, explicitly NOT proved (the nondeterministic `GrahamN` carried the full bridge).
- **Sharper lower-leg constant / log-regime** (miner 05, UK-B): Pinsker is not tight for large
  defects.
- **NFL/shattering lower bounds factoring through the lower leg** (miner 05, UK-A) — a CONJ edge for
  the landed-contact list.
- **`mutualInformationReal_le_condKL`** — the PAC-privacy variational bound named as the consumer of
  the conditional-chain-rule and Gaussian machinery, but **does not exist anywhere in the ZPM tree**
  (miners 11, 12). Either unbuilt, renamed, or outside ZPM. (Offshoot-adjacent.)

---

# 6. Cross-tree state: design-lab ↔ zetesis-puremath sync-delta

Synthesized from miner 13's exhaustive `diff`/`comm` audit (verified at file/byte level, not
inferred from prose). All divergences are **strictly directional** — every file pair is one tree's
superset of the other; **no conflicts** (no case of both trees independently diverging on the same
entity).

## 6.1 Byte-identical in both trees (the synced core)

- `Theory.md` (the flagship field note) — byte-identical. The two tree owners keep the field note
  in lockstep despite module-level lag elsewhere.
- Seven top-level `HC/` files: `Abstract.lean`, `Combinatorial.lean`, `Fibered.lean`,
  `FiberedInterpolation.lean`, `MutualInformation.lean`, `Spekkens.lean`, `Theory.md`.
- Nine `FOL/` files: `FiveWayCI.lean`, `FiveWayInterpolation.lean`, `FiveWayStructural.lean`,
  `LegIVBridge.lean`, `Polish.lean`, `SupportDistributionSeparation.lean`, `TypeSpaceCompact.lean`,
  `TypeSpaceSeparation.lean`, `TypeSpaceTopology.lean`.

## 6.2 What design-lab must gain (to reach puremath parity on the two audited FOL files)

1. **`typeOscillation`** [KV] — the 22-line theorem appended to puremath's `FOL/Amalgamation.lean`
   (design-lab's version is 139 lines, byte-identical through line 138; puremath's is 161 lines).
   A genuine proof-content gap, but **very likely a trivial port** ([CONJ]-grade, miner 13): every
   dependency it needs (`oscillation_theorem`, `SatT`, `SharedEqT`, `IsSharedT/LeftT/RightT`,
   `HasSharedDefinability`, `HasCrossDiscovery`, `TypeAmalgamable`) already exists byte-identical in
   design-lab. Not compile-verified by any miner.
2. **The "Leg-iv" narration update** in `FOL/NOOLOGY_URS.md` (design-lab's 10-line stub → puremath's
   23-line + 5-line synthesis). **Pure documentation lag, zero new Lean content**: the underlying
   Lean files the fuller ledger describes (`SupportDistributionSeparation.lean`,
   `MutualInformation.lean`) are already present byte-identical in design-lab. Only design-lab's
   ledger prose is stale.

## 6.3 What puremath must gain (design-lab is strictly ahead on the discrete stack and info-theory)

1. **14 root-level `HC/` Lean files** — the entire discrete local-to-global "v0.2" stack:
   `AffineEngine.lean`, `Amalgamation.lean` (root-level, distinct from `FOL/Amalgamation.lean`),
   `ApproximateFiveWay.lean`, `CyclicConverse.lean`, `Dirac.lean`, `FiberProduct.lean`,
   `FiveWayPi.lean`, `GrahamBridge.lean`, `HigherObstruction.lean`, `Marginals.lean`,
   `Multipartite.lean`, `ParityFamily.lean`, `ProductLaw.lean`, `VorobevConverse.lean`.
2. **9 root-level `*_URS.md` ledgers**: `AMALGAMATION_URS.md`, `APPROX_FIVEWAY_DISCOVERY_URS.md`,
   `APPROX_FIVEWAY_NOOLOGICAL_URS.md`, `CYCLIC_CONVERSE_URS.md` (706 lines — the capstone ledger),
   `FIBER_PRODUCT_URS.md`, `GRAHAM_BRIDGE_URS.md`, `HIGHER_OBSTRUCTION_DISCOVERY_URS.md`,
   `HIGHER_OBSTRUCTION_NOOLOGICAL_URS.md`, `PRODUCT_LAW_URS.md`.
3. **12 `ZPM/InformationTheory/` files** (a *sibling* of `HC/`, not nested inside it — miner 13
   corrects the slice-note path): the 6 Gaussian KL files (OFFSHOOT), plus `CondChainRule.lean`,
   `FiniteSupport.lean`, `MapEquiv.lean`, `NormLlr.lean`, `Tensorization.lean`,
   `TotalCorrelation/Def.lean`. (Of these, only `FiniteSupport.lean` is HC-consumed.)

Puremath has, design-lab lacks: **`FOUNDATIONS.md`** (the puremath-only meta-mathematical analysis,
fully mined by miner 13).

## 6.4 Structural reading of the divergence [STANCE — miner 13's inference, not verified]

The shape is consistent with puremath being where the *original FOL lift* happened (later
selectively back-ported to design-lab, explaining why only the last result `typeOscillation` and
its ledger entry didn't make the port), while design-lab is where the *newer discrete gluing-stack
arc* (the "v0.2" material, dated 2026-07-02/03 vs the FOL work's 2026-06-23) originated and has not
yet been forward-ported. Not grounded in commit history — a plausible reading of file-level evidence
only, cheaply confirmable by a git-log pass.

## 6.5 PORT EXECUTED (2026-07-03) — the sync-delta is now resolved [KV, both trees built]

The corpus was ported and both trees build. Key finding at execution: the two trees are on
**different toolchains** (design-lab Lean v4.31.0 / Mathlib `fabf563a`; puremath Lean v4.30.0-rc2 /
Mathlib `2c53994e`), and disk (99% full) ruled out bumping puremath's pin. So the port was
design-lab → puremath against puremath's *older* Mathlib, and the drift turned out to be tiny.

- **Core corpus ported and GREEN in both trees, byte-identical source.** The 14 v0.2 HC files + the
  6 HC-relevant `InformationTheory` files + the full 20-layer `HC.lean` barrel were copied into
  puremath. `lake build ZPM` in puremath = **3094 jobs, 0 errors** (the barrel is reachable from
  `ZPM.lean` root). Dirac's 1115 lines of `List.IsChain` proof compiled against the older Mathlib
  unchanged (both revs are post-`IsChain`-refactor).
- **Total drift: four one-line edits, all cross-compatible**, applied to *both* trees so the source
  stays byte-identical: `FiniteSupport.lean` and `ApproximateFiveWay.lean:97` `le_zero_iff.mp` →
  `nonpos_iff_eq_zero.mp`; `ApproximateFiveWay.lean:189` `zero_le` → `(by positivity)`;
  `ApproximateFiveWay.lean:105` `zero_lt_iff.mpr` → `pos_iff_ne_zero.mpr`. Cause: the ENNReal
  `0`-comparison lemmas resolve to the wrong (multiplicative) `Zero` instance in the older Mathlib;
  `nonpos_iff_eq_zero`/`pos_iff_ne_zero`/`positivity` are unambiguous in both.
- **`typeOscillation` reverse-ported** design-lab ← puremath (§6.2 item 1): `FOL/Amalgamation.lean`
  is now byte-identical in both trees (161 lines) and compiles green in design-lab (fabf563a). The
  "very likely trivial port" [CONJ] is now [KV].
- **`FOUNDATIONS.md`** copied into design-lab (both trees now carry it, tracked).

**Irreducible residue (cannot be synced without bumping puremath's Mathlib pin):**
- **4 pin-adapted infra files keep one version per tree**: `Binary/Derivatives.lean`,
  `Binary/TwoSqLeNegLog.lean` (`.congr_deriv`/`.fun_pow` vs `convert`/`.pow`),
  `MeasureTheory/.../NullMeasurable.lean` (`sdiff` vs `diff` rename),
  `Probability/Concentration/ChebyshevMajority.lean` (`integral_finsetSum` vs `integral_finset_sum`).
  Each tree already had its own working version; forcing identity would break one tree.
- **The Gaussian KL offshoot (6 files + `Probability/QuadraticFormExpectation.lean`) stays
  design-lab-only.** It genuinely depends on Mathlib features *added after* puremath's pin:
  `Matrix.dot_mulVec_eq_sum_sum` (absent from `2c53994e`) and a `toEuclideanCLM` star-algebra-equiv
  `StarHomClass` instance. This is the non-core PAC-privacy module (§2.13); it is gated on a puremath
  toolchain bump (needs disk freed). A Pl-kill recorded as content, not a failure.

Net: the entire Shape-of-Ignorance corpus is byte-identical and green in both trees; only the four
pin-adapted infra files and the non-core Gaussian offshoot remain divergent, both for the single
root cause of the Mathlib-pin gap.

---

# 7. Consolidated agent-axis ignorance (Γ) — routing list for the next session

Everything the fan could not resolve, deduped, as the routing list. These are miner-axis gaps
(what the miners could not resolve), kept strictly separate from the object content above.

## 7.1 Unresolved citations (route to `verify-citations`)

- **Spekkens 2007** — no arXiv/DOI anywhere in the tree; the corpus attributes a construction to
  prior work it cannot resolve (miner 01).
- **Atserias–Kolaitis** — arXiv:2312.02023 appears in one ledger (miner 08); elsewhere surname-only.
  Direction-only, unverified in miner 05's slice ("[to-verify]").
- **BFMY** — never expanded to author names in-corpus (miner 08); "Beeri–Fagin–Maier–Yannakakis
  1983" appears only in Theory.md (miner 13). No id.
- **Watanabe** (total correlation) — name only, no year/title/id (miner 11).
- **Maksimova, Madarász, Sági, Németi** — bare names, no ids; the interpolation⟺amalgamation
  correspondence. Minor Sági/Maksimova asymmetry between Theory.md and FOUNDATIONS.md (miner 13).
- **CHSH, Keisler measure, NIP, generically-stable, Craig, Beth, Alexander, Urysohn** — named
  classical machinery, never cited with an id; Keisler/NIP is the most load-bearing uncashed
  reference (miners 09, 10, 13).
- **Vorob'ev 1962, Kolmogorov 1933, Ben-David et al. / Nature MI 2019, Yannakakis, Gács–Körner,
  Goodrick–Kim–Kolesnikov, Studený, Mayer 2024, Cuzzolin book title, Krajíček–Pudlák/BPR/Schmid** —
  year and/or venue only, no arXiv/DOI (miner 13).

## 7.2 Unresolved internal references

- **"The monograph"** — Thm 4.6/4.7/7.5/7.7; no title/author/year (miners 01, 10). Does it exist as
  a discrete artifact?
- **`mutualInformationReal_le_condKL`** — named as consumer in two files, exists nowhere in ZPM
  (miners 11, 12). Unbuilt, renamed, or outside ZPM?
- **`mutualInformationReal_uniform_eq_zero_iff_isRect`** — named as the "unification witness" in
  `SupportDistributionSeparation.lean` but not in miner 10's six files; located by miner 13 in
  `MutualInformation.lean`. (Cross-slice resolved by synthesis.)
- **`hc_probe4`, "Pcorr-style mass-shifting," "field note §5," "barrel at N layers," "M3a/M3b/M3d,"
  "ticks," "vendor-synced," "FiveWayPi failure mode"** — internal process/experiment labels several
  miners could not resolve (miners 04, 05, 03, 06, 09). ("Field note §5" resolved by synthesis to
  Theory.md §5.)

## 7.3 Unverified strong claims (route to independent kernel check)

- **Axiom-freedom of the abstract layer** — Theory.md claims `oscillation_theorem` et al. proved
  "from no axioms at all (not even choice)"; a `#print axioms` away from confirmation, never run by
  any miner (miner 01).
- **Axiom-cleanliness / `sorry`-freedom** — all [KV] tags rest on the corpus's self-reports
  (`[propext, Classical.choice, Quot.sound]`, "0 sorry", "no native_decide") plus miners' textual
  absence-of-`sorry` checks. No miner ran `lake build` or `#print axioms`. (All miners.)
- **`typeOscillation` port feasibility** — "very likely a sync gap not a proof gap" is miner 13's
  Pl_imagine judgment, not compile-verified.
- **"absent from Mathlib" claims** — chordality, Craig/Beth, `support_prod`, Gaussian density: none
  state a Mathlib version or search method (miners 08, 09, 10, 12).
- **`decide` numeric facts** (Spekkens `hcComb` values, `hcCombPi_join_ne_leibniz` 6≠12, parity
  defects) — not independently recomputed by any miner (miners 01, 02, 04).

## 7.4 Slices not fully mined (coverage gaps for follow-up)

- **9 design-lab-only `*_URS.md` ledgers** were mined only at the theorem level via their `.lean`
  files (miners 02, 04, 05, 06, 07, 08 covered the paired `.lean` + specific URS in their slices);
  miner 13 confirmed all 9 exist but read only opening lines. `CYCLIC_CONVERSE_URS.md` (706 lines)
  is the largest; its full Γ⟷γ record of the four-round conjecture-refutation history is captured in
  summary (§2.10) but not exhaustively.
- **`CHARTER.md`, `project_hc_in_zpm.md`, `project_crypto_learning_theory_pac_privacy.md`** — memory/
  governance files referenced but not read (miners 11, 09, 12).
- **The abstract-to-combinatorial reduction** — no miner located a Lean term instantiating
  `Abstract.lean`'s `World/Formula/Sat` with `Finset (α × β)` and proving `IsDecomposable` = `IsRect`
  under it, within `Abstract.lean`/`Combinatorial.lean` (miner 01). The instantiation is done in the
  fibered/FOL layers (miners 02, 10), but the direct bipartite reduction remains prose-asserted at
  the base.

## 7.5 Named-but-unbuilt / superseded (honesty ledger)

- **C-ENGINE / D23** — BYPASSED, not proved ("the wrong frame"); superseded by the chordal/conformal
  route (miner 08).
- **Four killed conjectures** in the Vorob'ev-converse history: team-parity DBC, the two-move
  disjunction, HeartB, boundary-parity engine — all refuted, invisible in the clean Lean end-state
  (miner 08).
- **Witness rungs** (even boundary data, landings, `H_k` clique parities), **deterministic-greedy
  confluence**, **C-JLeib≤**, **the abelian complex**, **the counting identity χ = hcComb**, **the
  canonical Keisler measure** — all named, none built (miners 07, 06, 02, 13, 05, 09, 10).

---

## Provenance map (miner → subsystem)

| Miner | Slice | Primary § here |
|-------|-------|----------------|
| 01 | Abstract core, Combinatorial, Spekkens | §1.2, §1.3, §2.1, §2.2 |
| 02 | Fibered five-way, fiber-product join | §2.3, §2.8 |
| 03 | Mutual information, product law | §2.3, §2.8, §2.9 |
| 04 | Multipartite, higher obstruction, parity, FiveWayPi | §2.4, §2.6, §2.7 |
| 05 | Quantitative approximate five-way (the bound) | §2.5 |
| 06 | Amalgamation, Graham/GYO bridge | §2.10 (positive) |
| 07 | Affine engine, cyclic converse | §2.10 (engine) |
| 08 | Vorob'ev converse, Dirac | §2.10 (converse) |
| 09 | FOL type-space topology, compact, Polish | §2.11 (carrier) |
| 10 | FOL five-way, amalgamation, support/distribution separation | §2.11 (legs, Pcorr) |
| 11 | Information-theory backbone (KL, Pinsker, TC, MI) | §2.9 |
| 12 | Gaussian KL (PAC-privacy offshoot) | §2.13 |
| 13 | Field notes, cross-tree divergence audit | §3, §4, §5, §6 |

*End of the Shape of Ignorance Discovery (γ) URS.*
