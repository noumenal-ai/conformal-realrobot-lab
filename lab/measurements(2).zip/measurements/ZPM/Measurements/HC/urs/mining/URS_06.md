# URS_06 — Amalgamation and Graham/GYO bridge

Miner: Sonnet miner 06. Slice: Amalgamation and Graham/GYO bridge (positive Vorob'ev direction,
certificate form, and its order-free/decidable acyclicity face).

## Files mined

1. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/Amalgamation.lean` (260 lines) — read end to end.
2. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/AMALGAMATION_URS.md` (106 lines) — read end to end.
3. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/GrahamBridge.lean` (257 lines) — read end to end.
4. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/GRAHAM_BRIDGE_URS.md` (121 lines) — read end to end.

All four files were read completely with no truncation. `Amalgamation.lean` imports
`ZPM.Measurements.HC.Marginals` and `ZPM.Measurements.HC.HigherObstruction`; these are outside
my assigned slice and were NOT read (see Agent-axis ignorance below) — I only report what the
imports are used for as visible from call sites inside my two files (e.g. `projS`,
`projS_image_restrict₂` from Marginals; the Specker triangle objects `S01,S12,S02,diag01,diag12,
anti02,specker_not_glues` from HigherObstruction, used but not defined in my slice).

## Theorems and definitions

Organized by file, in file order. Each entry tagged per the carrier's kind-of-truth scheme.

### Amalgamation.lean

- **`LocalStruct (ι) (X)`** — [def] Structure bundling a `team : Finset ι` with
  `rel : Finset (∀ i : team, X i)`, the admissible local configurations. Docstring: "A **local
  structure**: a team of parts together with an ignorance structure on the team's marginal
  type."
- **`LocalStruct.imarg`** — [def] `L.rel.image (Finset.restrict₂ hS)` — the interface marginal
  of a local structure over a sub-team `S ⊆ L.team`.
- **`LocalStruct.imarg_image`** — [KV] Lemma: sub-marginalizing an interface marginal composes:
  `(L.imarg hT).image (Finset.restrict₂ hS) = L.imarg (hS.trans hT)`. Proved by
  `Finset.image_image` + `Finset.restrict₂_comp_restrict₂`.
- **`Consistent (fam)`** — [def] Pairwise consistency: `∀ L₁ ∈ fam, ∀ L₂ ∈ fam,
  L₁.imarg(∩) = L₂.imarg(∩)` — any two members expose the same interface marginal on their team
  intersection.
- **`Glues (fam)`** — [def] `∃ κ : Finset (∀ i, X i), ∀ L ∈ fam, projS κ L.team = L.rel` — some
  global structure realizes every member exactly.
- **`joinFam (fam)`** — [def] `univ.filter (fun f => ∀ L ∈ fam, L.team.restrict f ∈ L.rel)` —
  the natural join: all global configurations passing every local test.
- **`mem_joinFam`** — [KV] Membership characterization lemma for `joinFam` (simp-derived).
- **`famCover`** — [def] Recursive union of a family's teams: `[] ↦ ∅`; `L :: rest ↦ L.team ∪
  famCover rest`.
- **`team_subset_famCover`** — [KV] `L ∈ fam → L.team ⊆ famCover fam`, by induction on `fam`.
- **`RIP`** — [def] **Running intersection property.** Recursive: `[] ↦ True`; `L :: rest ↦
  (rest = [] ∨ ∃ L' ∈ rest, L.team ∩ famCover rest ⊆ L'.team) ∧ RIP rest`. Docstring: "each
  member meets the union of the later members inside a single later member (the head is the
  last-eliminated team)."
- **`decidableRIP`** — [decide] Structural `Decidable` instance for `RIP`, recursive on the
  list.
- **`exists_restrict_eq`** — [KV] `[∀ i, Nonempty (X i)] → ∀ T g, ∃ f, T.restrict f = g` — any
  local configuration extends to a global one, given nonempty parts (via `Classical.arbitrary`
  on the complement). Marked as "on nonempty parts" in docstring.
- **`projS_joinFam`** — **[KV] THE AMALGAMATION THEOREM.** "The **amalgamation theorem**
  (positive Vorob'ev, certificate form): the natural join of a running-intersection,
  pairwise-consistent family realizes every member exactly." Statement: `[Fintype ι] [∀ i,
  Fintype (X i)] [∀ i, Nonempty (X i)] → (fam) → RIP fam → Consistent fam → ∀ L ∈ fam, projS
  (joinFam fam) L.team = L.rel`. Proved by induction on `fam` (nil case vacuous; cons case
  splits on `hhead : rest = [] ∨ ∃ L' ∈ rest, ...`, base case realizes by arbitrary extension
  via `exists_restrict_eq`, inductive case builds the interface `S := L₀.team ∩ famCover rest`,
  proves `hSagree` (interface marginals of `L₀` and `L'` agree, via `imarg_image` +
  consistency), proves `hkey : projS (joinFam rest) S = L₀.imarg hSL₀` (using
  `projS_image_restrict₂` from Marginals — outside my slice), then the SPLICE construction
  `hsplice` (function `f'` = `g` on `L₀.team`, `f` elsewhere) discharges both "leg (a): realize
  the head" and "leg (b): preserve the tail").
- **`glues_of_rip`** — **[KV] THE AMALGAMATION LEG.** "a running-intersection, pairwise-consistent
  family glues." `RIP fam → Consistent fam → Glues fam`, immediate corollary of
  `projS_joinFam` with witness `joinFam fam`.
- **`speckerFam`** — [def] The Specker triangle instantiated as a `List (LocalStruct (Fin 3)
  (fun _ => Fin 2))`: `[⟨S01, diag01⟩, ⟨S12, diag12⟩, ⟨S02, anti02⟩]`. `S01, S12, S02, diag01,
  diag12, anti02` are imported from `HigherObstruction` (outside my slice; not re-defined here).
- **`decidableConsistent`** — [decide] `Decidable (Consistent fam)` instance via `infer_instance`
  after unfolding.
- **`speckerFam_consistent`** — [decide] `Consistent speckerFam`, proved `by decide`.
- **`speckerOrders`** — [def] The six explicit permutations (orderings) of the three-element
  Specker family, written out as a literal list of six lists.
- **`speckerFam_no_rip`** — [decide] "The Specker family admits no running-intersection order:
  every one of its six orderings fails `RIP`." `∀ fam ∈ speckerOrders, ¬ RIP fam`, `by decide`.
  Docstring explicitly notes: "(The order-free `Perm`-quantified form arrives with the
  Graham-reduction tick.)" — i.e. this file itself flags this theorem as the enumerated
  predecessor to what GrahamBridge.lean generalizes.
- **`speckerFam_not_glues`** — [KV] "The Specker family does not glue (from the concrete
  non-realization)." `¬ Glues speckerFam`, proved by `rintro`-ing a witness `κ` and applying
  `specker_not_glues` (imported from HigherObstruction, outside my slice) to the three
  restricted facts.

### AMALGAMATION_URS.md (the Γ-ledger / process record for Amalgamation.lean)

This file is process/derivation prose, not Lean. Its content is tagged per-entry below since it
mixes STANCE (architecture rationale), decide-adjacent planning, and post-hoc verdict reporting.

- **D1** — [STANCE/def] Grammar decision: local structures as a bundled type ("T-Structure").
  Rationale given: "a family over a cover needs 'team + structure on the team's marginal type'
  as ONE object (membership-dependent functions over lists are HEq-hostile)." States the
  `LocalStruct` structure literally, the `imarg` definition, and that `joinFam` avoids
  "subtype-pi accumulation in the induction (the FiberProduct lesson, D1 there, applied
  again)" — an explicit cross-reference to a prior tick's URS (FiberProduct), outside my
  slice.
- **D2** — [STANCE] Architecture decision: "Graham vs RIP — the delegated decision, resolved."
  States: "The PI leans Graham for maximal rigor." Assessment concludes RIP-list is the
  certificate form / induction engine, Graham reduction is the decidable order-free face, and
  a bridge theorem (not file-internal to Amalgamation.lean; this is the forward pointer to
  GrahamBridge.lean) resolves the order-independence concern. Explicitly frames the planned
  next artifact: `Acyclic 𝒞 := ∃ order, order.toFinset = 𝒞 ∧ RIP order` and "the **Graham
  bridge** (`graham 𝒞 = true ↔ Acyclic 𝒞`, the decision procedure) is the NEXT tick."
- **D3** — [STANCE/def] "the induction invariant, derived in-model — the whole proof before any
  Lean." Full prose derivation of the `projS_joinFam` proof strategy (S-marginal agreement via
  `projS_image_restrict₂`, the SPLICE MOVE, legs (a)/(b), the base case needing
  `[∀ i, Nonempty (X i)]`). Contains an explicit A5 self-note: "this is MORE general than the
  classical covering formulation, not less" (uncovered coordinates fill arbitrarily replacing
  any covering condition).
- **D4** — [STANCE] "Pl_imagine audit — the risky steps named." Flags: the `T_k ∩ L.team ⊆ S`
  step needing a lemma to be built (`subset_cover_of_mem` — note: this named lemma does NOT
  appear as a top-level declaration in the final `Amalgamation.lean` I read; see Cross-tree
  notes); the splice's dite-membership juggling identified as "the FiberProduct pattern
  verbatim (two proofs banked)"; the trace-lifting through two image layers flagged as a
  known instance/motive drift risk.
- **D5** — [STANCE/decide, planned] "kernel checks planned, expected verdicts." Predicts: RIP
  decidability derivable; Specker triangle cover has NO RIP order (all 6 permutations fail);
  path cover `({0,1},{1,2})` is RIP; "parity3's full-marginal family over the triangle is
  consistent AND glues (the full cube) — cyclicity does not force failure, it permits it
  (guards against over-reading the converse)." Note: `parity3` is not a declaration inside my
  two Amalgamation files — this is a forward/cross-reference to material outside my slice.
- **γ — deliverables list** — [STANCE] Enumerates the planned file contents; notably lists
  `subset_cover_of_mem` and `projS_joinFam_singleton` (base) as planned deliverables — neither
  appears as a named top-level declaration in the final `Amalgamation.lean` (the base case is
  inlined directly inside `projS_joinFam`'s proof rather than factored to a separate lemma).
  Also names the eventual theorem `joinFam_realizes` — the shipped file names this
  `projS_joinFam` instead. Flagged as a naming divergence, not a content gap (see Cross-tree
  notes).
- **Verdicts + Γ-yield** — [decide/STANCE] "All deliverables GREEN, 0 sorry, barrel at fifteen
  layers." Confirms the full declaration list as it landed (matching what I read in the .lean
  file). States: "The D3 derivation held verbatim — the in-model proof compiled with no
  structural changes, only linter/name repairs." Records "The one honest deviation:
  `speckerFam_no_rip` quantifies over the six explicit orderings, not `List.Perm` (kernel
  reduction of `permutations` sticks at its aux; the order-free `Perm`/`Acyclic`-quantified
  form is scheduled with the Graham tick, its natural home)" — this is a **self-reported
  Pl-kill**: the shipped theorem is weaker than the originally intended form, honestly logged.
  Γ-yield item 1: "The amalgamation leg is CLOSED at both ends: RIP + consistent ⟹ glues
  (theorem schema, any arity, any parts), and the triangle is kernel-witnessed as consistent +
  unorderable + unglued. The oscillation theorem's discrete engine is now a proved
  implication, not a narrative." Γ-yield item 2: "Architecture confirmed under load: the
  RIP-certificate carried the induction; nothing in the proof wanted Graham." Γ-yield item 3
  names forward edges: "Graham bridge; the general cyclic converse (cycle → parity-style
  non-gluing family, generalizing the triangle); C-JLeib≤ (the interface-tightening
  inequality); the measure-level lift of `glues_of_rip` (consistent MEASURE families over RIP
  covers — where PhysLean's quantum marginal instances land)." [PROBE-adjacent forward
  pointer to PhysLean, not a literature-audit verdict — no citation given, just a named future
  integration point.]

### GrahamBridge.lean

- **`listCover`** — [def] Recursive union of a `List (Finset ι)`: `[] ↦ ∅`; `T :: rest ↦ T ∪
  listCover rest`.
- **`RIPCover`** — [def] "Team-level running intersection property: each team meets the union
  of the later teams inside a single later team." Same recursive shape as `RIP` but over bare
  `List (Finset ι)` (no attached `rel`).
- **`decidableRIPCover`** — [decide] Structural `Decidable` instance, recursive on the list.
- **`coverU`** — [def] `𝒞.sup id` — the union of a finite set of teams (Finset-of-Finsets sup).
- **`listCover_eq_coverU`** — [KV] `listCover l = coverU l.toFinset`, by induction (bridges the
  fold form used by `RIPCover`'s recursion to the `sup` form used at the `Finset` level).
- **`IsEarOf`** — [def] "The ear condition: the team meets the union of the others inside a
  single other team (or there are no others)." `𝒞.erase T = ∅ ∨ ∃ T' ∈ 𝒞.erase T, T ∩ coverU
  (𝒞.erase T) ⊆ T'`.
- **`decidableIsEarOf`** — [decide] `Decidable (IsEarOf 𝒞 T)` via `infer_instance` after
  unfolding.
- **`GrahamN`** — [def] "Nondeterministic ear elimination, fueled." `0, 𝒞 ↦ 𝒞 = ∅`; `n+1, 𝒞 ↦ 𝒞
  = ∅ ∨ ∃ T ∈ 𝒞, IsEarOf 𝒞 T ∧ GrahamN n (𝒞.erase T)`.
- **`decidableGrahamN`** — [decide] Structural `Decidable` instance, recursive on the fuel `n`.
- **`GrahamReducible`** — [def] "**Graham reducibility**: ear elimination empties the cover;
  the cover's size is fuel enough since every elimination removes exactly one team." `𝒞 ↦
  GrahamN 𝒞.card 𝒞`.
- **`(instance) Decidable (GrahamReducible 𝒞)`** — [decide] Via `unfold` + `infer_instance`.
- **`Acyclic`** — [def] "**Order-free acyclicity**: some duplicate-free enumeration of the
  cover is a running-intersection order." `∃ order : List (Finset ι), order.Nodup ∧
  order.toFinset = 𝒞 ∧ RIPCover order`.
- **`grahamN_of_ripCover`** — [KV] "An RIP order eliminates from the front: its head is an ear
  and the tail remains RIP." `∀ order, order.Nodup → RIPCover order → GrahamN order.length
  order.toFinset`. Proved by structural recursion on `order`, nil case by `simp`, cons case
  splits on the RIP head condition and rebuilds via `erase_insert`/`Finset` bookkeeping.
- **`exists_ripCover_of_grahamN`** — [KV] "An elimination run is a running-intersection order
  read forward." `∀ n 𝒞, GrahamN n 𝒞 → ∃ order, order.Nodup ∧ order.toFinset = 𝒞 ∧ RIPCover
  order`. Proved by induction on the fuel `n`.
- **`acyclic_iff_grahamReducible`** — **[KV] THE GRAHAM BRIDGE.** "**The Graham bridge**:
  acyclicity is exactly Graham reducibility." `Acyclic 𝒞 ↔ GrahamReducible 𝒞`. Proved directly
  from the two lemmas above (forward direction uses `List.toFinset_card_of_nodup` to align the
  order length with `𝒞.card`).
- **`decidableAcyclic`** — **[decide] THE PAYOFF.** "**Acyclicity is decidable** — the payoff
  of the bridge." `Decidable (Acyclic 𝒞)` via `decidable_of_iff` through the bridge iff.
- **`famCover_eq_listCover`** — [KV] `famCover fam = listCover (fam.map (·.team))`, by
  induction, connecting the family-level cover (from Amalgamation.lean) to the cover-level
  primitive defined in this file.
- **`rip_iff_ripCover`** — [KV] "The family-level running intersection property reads only the
  teams." `RIP fam ↔ RIPCover (fam.map (·.team))`, by induction, using `famCover_eq_listCover`.
- **`exists_perm_map_eq`** — [KV] Generic list lemma: "A permutation of a mapped list lifts
  along the map." `∀ {σ l}, σ.Perm (l.map g) → ∃ l', l'.Perm l ∧ l'.map g = σ`. Proved by
  induction on `σ`, using `List.append_of_mem`, `List.perm_middle`, `Perm.cons_inv`.
- **`consistent_of_perm`** — [KV] "Pairwise consistency is permutation-invariant." `fam'.Perm
  fam → Consistent fam → Consistent fam'`, one-liner via `Perm.mem_iff`.
- **`glues_of_perm`** — [KV] "Gluing is permutation-invariant." `fam'.Perm fam → Glues fam' →
  Glues fam`, one-liner.
- **`glues_of_acyclic`** — **[KV] THE ORDER-FREE AMALGAMATION HEADLINE.** "a
  pairwise-consistent family with duplicate-free teams over an acyclic cover glues. Acyclicity
  is decidable, so the hypothesis is checkable." Statement: `[Fintype ι] [∀ i, Fintype (X i)]
  [∀ i, Nonempty (X i)] → (fam) → Consistent fam → (fam.map (·.team)).Nodup → Acyclic
  (fam.map (·.team)).toFinset → Glues fam`. Proved by: extracting the RIP order-witness `σ`
  from `Acyclic`, obtaining `σ.Perm (fam.map (·.team))` via
  `List.perm_of_nodup_nodup_toFinset_eq`, lifting to `fam'` via `exists_perm_map_eq`, then
  composing `rip_iff_ripCover`, `consistent_of_perm`, `glues_of_rip`, `glues_of_perm`.
- **`speckerCover_not_acyclic`** — [decide] "The Specker cover is not acyclic: the order-free
  triangle fact, by `decide` through the bridge's decidability instance." `¬ Acyclic
  ({S01, S12, S02} : Finset (Finset (Fin 3)))`, `by decide`. This is the order-free
  strengthening of `speckerFam_no_rip` from Amalgamation.lean.
- **`pathCover_acyclic`** — [decide] "The path cover is acyclic." `Acyclic ({S01, S12} :
  Finset (Finset (Fin 3)))`, `by decide`.

### GRAHAM_BRIDGE_URS.md (the Γ-ledger for GrahamBridge.lean)

- **D1** — [STANCE] "the confluence trap, found in-model and dodged." Detailed prose: the
  DETERMINISTIC greedy ("eliminate any ear, repeat") requires a confluence lemma ("if 𝒞 is
  acyclic and T is any ear, then 𝒞 \ T is acyclic"). A proof attempt is described and its
  failure located precisely: "a member L whose RIP-witness WAS T needs a new witness
  containing `L ∩ cover(later \ T) ⊆ T ∩ cover(others) ⊆ T̂`, but T̂ (the ear's home) may sit
  EARLIER than L in the order — no later witness available." Explicit claim: "The gap is real
  (the textbook proofs route through join-tree characterizations, not naive deletion)." —
  **[PROBE-adjacent STANCE]**: this is an interpretive claim about "textbook proofs" with no
  named source, author, or citation attached; I flag it as unverifiable prose, not a
  literature-audit verdict with a scope (see Literature-audit verdicts section — there is
  none to record here beyond this unattributed remark). DERIVED DODGE recorded: formulate
  Graham as nondeterministic ear-elimination so both bridge directions become confluence-free
  card-fuel inductions. Confluence is explicitly named "a genuine SEPARATE theorem, named as a
  strengthening edge, not smuggled."
- **D2** — [STANCE] "fuel over well-founded recursion." Rationale: each elimination drops
  `𝒞.card` by exactly one, so card is fuel; kills "the WF-recursion-under-∃ risk" and makes
  the Decidable instance structural, mirroring `decidableRIP`.
- **D3** — [STANCE/def] "the two-level grammar + the family lift." Describes `RIPCover` mirrors
  `RIP`, the family-level headline needs the "PERM LIFT" (Nodup + toFinset-eq → Perm; Perm
  lifts along map), and states the plan: "Floor the two list lemmas... if the map-lift is
  absent upstream, prove by induction on the Perm derivation."
- **D4** — [STANCE] "Pl_imagine audit." Flags risky steps: toFinset/erase bookkeeping under
  Nodup; cover transport `listCover order = coverU order.toFinset` — explicit design question
  raised and resolved in-text: "define listCover := (·.toFinset.sup id) directly?? NO:
  RIPCover's recursion wants the fold form on tails; keep fold + bridge lemma."
- **D5** — [STANCE/decide, planned] "planned checks, expected verdicts." Predicts `#eval`
  results (GrahamN triangle = FALSE, path = TRUE, ∅/singletons = TRUE) and the post-build
  kernel facts `¬ Acyclic {S01,S12,S02}` and `Acyclic {S01,S12}` "BY DECIDE through the new
  instance — the order-free upgrade of `speckerFam_no_rip` promised last tick."
- **γ — deliverables list** — [STANCE] Enumerates: listCover, RIPCover (+decidable),
  RIP_iff_ripCover [note: file lists this as `RIP_iff_ripCover`; the shipped lemma name in the
  .lean file is `rip_iff_ripCover` — lowercase-first naming divergence, cosmetic], coverU, ear
  body, GrahamN (+structural decidable), GrahamReducible, `acyclic_iff_grahamReducible`,
  `instance Decidable (Acyclic 𝒞)`, perm-lift lemmas, `glues_of_acyclic`,
  `speckerCover_not_acyclic` / `pathCover_acyclic`. Named strengthening edges: "deterministic-
  greedy confluence; vertex-ear GYO equivalence" — the latter (**vertex-ear GYO equivalence**)
  is a NEW named edge not previously mentioned in AMALGAMATION_URS.md's edge list; flagged
  under Cross-tree notes below since "GYO" appears in my slice's task title but this is the
  only place in the four files where "GYO" is spelled out (elsewhere the file uses "Graham" /
  "Graham reduction" — GYO = Graham-Yu-Özsoyoğlu is the standard name for this algorithm in the
  database-theory literature, but no citation to that literature is given anywhere in my
  slice; I record this as an unlinked terminology fact, not a verified literature claim).
- **Verdicts + Γ-yield** — [decide/STANCE] "All deliverables GREEN, 0 sorry, barrel at sixteen
  layers. Axioms: propext, Classical.choice, Quot.sound only (decide throughout, no
  native_decide)." — **[decide]** an explicit axiom-hygiene report: only the three standard
  Lean/Mathlib foundational axioms are used, no `native_decide` (which would use untrusted
  compiled evaluation) and no other custom axioms. "D5 verdicts — all as predicted." "D1 held
  under load. The nondeterministic `GrahamN` carried the FULL bridge; confluence was never
  needed." "D2 held verbatim." "D3 held with one refinement" — `exists_perm_map_eq` "was NOT
  upstream and was built by induction on the TARGET list σ... cleaner than the fallback plan's
  induction on the Perm derivation." "D4 risks — the errors hit were exactly the audited
  class," with four itemized sub-findings: (i) a lexical rule about unicode in identifiers
  ("`∅` invalid in identifiers (`h∅` → `hempty`): SECOND instance of the ledger entry (first:
  `hS∩`); now a confirmed lexical rule"); (ii) `∃ l', l'.Perm l` needing explicit binder-type
  ascription; (iii) an "omit audit" subtlety about `DecidableEq ι` being referenced via `team ∩
  team` inside `Consistent` and hence not omittable, with "a spurious 'declaration uses sorry'
  at `glues_of_acyclic` (the known cascade signature — fix the omit, the cascade clears)"; (iv)
  an unused-simp-arg lint. **"Process breach, logged honestly."** — explicit self-report: "The
  first Write of the file carried two literal `sorry` placeholders in a stubbed perm lift — the
  SECOND firing of the FiveWayPi failure mode (never-sorry applies to drafts on disk). Caught
  at session resume before any compile; the tail was rewritten complete. The standing rule is
  reaffirmed and strengthened: hold the Write until every proof in the file is complete; a hard
  lemma is written FIRST, not stubbed last." This is a first-person process-integrity
  admission, not a mathematical claim; recorded verbatim per the carrier's Pl-kill honesty
  mandate — a `sorry` was written to disk twice (this file states it is the "SECOND firing"),
  caught before compilation, and the incident is used to reaffirm a standing house rule.
  Γ-yield item 1: "The decidability face is closed. `Acyclic`... is DECIDABLE via the bridge...
  With `decidableConsistent`, the amalgamation theorem now has FULLY CHECKABLE hypotheses:
  `glues_of_acyclic` is a certified decision procedure for gluing over acyclic covers, closing
  the PI's rigor request (order-independence answered by theorem, not by choice of face)."
  Γ-yield item 2: "Reusable infrastructure: `exists_perm_map_eq` (generic perm lift along any
  map — any future list-of-bundles vs list-of-projections bridge consumes this) and the
  card-as-fuel pattern for decidable elimination procedures on `Finset`." Γ-yield item 3 names
  forward edges: "general cyclic converse (every cycle hosts a parity-style non-gluing family);
  deterministic-greedy confluence; C-JLeib≤; the measure-level lift of
  `glues_of_rip`/`glues_of_acyclic` (consistent measure families — where PhysLean's quantum
  marginal instances land, now unblocked on loogle)."

## Citations

**None found.** Across all four files in this slice (`Amalgamation.lean`,
`AMALGAMATION_URS.md`, `GrahamBridge.lean`, `GRAHAM_BRIDGE_URS.md`), there is no named external
work — no author, no year, no paper title, no arXiv id, no DOI. Per the carrier's mandate to
"transcribe every citation VERBATIM with its id and never fabricate one," I record explicitly:
**no citation exists in my slice**; I invent none.

Two unattributed proper-noun references appear and are recorded here for completeness, tagged
precisely as what they are (not treated as citations since no author/year/id is given):

1. "Vorob'ev" — appears in both `Amalgamation.lean`'s module docstring ("the positive Vorob'ev
   direction, certificate form") and in `projS_joinFam`'s theorem docstring ("positive
   Vorob'ev, certificate form") and in `AMALGAMATION_URS.md`'s title header ("Vorob'ev positive
   direction"). No first name, year, title, or id is given anywhere in my four files. This is a
   named mathematician/theorem-family reference (presumably to N.N. Vorob'ev's classical
   consistency/realizability theorem for families of probability distributions), used as
   terminology, not backed by a resolvable citation in my slice.
2. "Graham" / "GYO" — the bridge file's own name and the task title ("Graham/GYO bridge") both
   invoke this name; `GRAHAM_BRIDGE_URS.md`'s named-edge list uses the literal string
   "vertex-ear GYO equivalence." No author/year/id is given. "GYO" is presumably an acronym
   (Graham-Yu-Özsoyoğlu, standard in the acyclic-database-schema literature) but this expansion
   and any literature source are NOT stated anywhere in my slice — I record only that the bare
   term appears, and flag that I am not asserting the expansion as fact from my slice's text
   (see Agent-axis ignorance).

No claim in my slice is supported by, or attributed to, a verifiable external citation. This
section is empty of resolvable references by design, not by omission.

## Literature-audit verdicts

**None found.** My slice contains no PROBE-tagged literature-audit verdict in the carrier's
sense (no "no-ancestor," "killed target," "boundary/Pl-kill," or "appears in no examined work"
statement with a stated search scope, field list, or standard). The closest adjacent material
is the D1 remark in `GRAHAM_BRIDGE_URS.md` ("the textbook proofs route through join-tree
characterizations, not naive deletion") — this is an unattributed, unscoped interpretive claim
about "the textbook proofs" with no named textbook, author, count of works searched, or field
specified. I do NOT record it as a literature-audit verdict because it lacks the scope
specification the carrier requires for that category; I record it instead as a [STANCE] claim
under Theorems and definitions (D1, GrahamBridge URS) and flag its unverifiable status here.

## Cross-tree / divergence notes

1. **Naming divergence: planned vs. shipped declaration names (Amalgamation).**
   `AMALGAMATION_URS.md`'s "γ — deliverables" section names the headline theorem
   `joinFam_realizes` and lists `subset_cover_of_mem` and `projS_joinFam_singleton` (base) as
   deliverables. The shipped `Amalgamation.lean` names the headline theorem `projS_joinFam`
   instead, and I find no top-level declarations named `subset_cover_of_mem` or
   `projS_joinFam_singleton` — the base case is proved inline inside `projS_joinFam`'s `rcases
   hhead with rfl | ...` branch rather than factored to a standalone lemma. This is a naming/
   factoring divergence between the plan (written before the tick) and the shipped artifact; no
   content appears to be missing (the base case's content is present, just inlined), but I flag
   it as a divergence rather than silently reconciling it, per the carrier's instruction to
   report duplication or contradiction precisely.
2. **Naming divergence: `RIP_iff_ripCover` vs `rip_iff_ripCover` (GrahamBridge).**
   `GRAHAM_BRIDGE_URS.md`'s deliverables list writes `RIP_iff_ripCover` (capital RIP); the
   shipped lemma in `GrahamBridge.lean` is `rip_iff_ripCover` (lowercase). Cosmetic, but
   recorded as a literal transcription mismatch.
3. **Self-reported theorem-strength deviation, honestly logged (Amalgamation → GrahamBridge
   arc).** `AMALGAMATION_URS.md`'s Verdicts section states outright that `speckerFam_no_rip`
   is weaker than originally intended: it "quantifies over the six explicit orderings, not
   `List.Perm`... the order-free `Perm`/`Acyclic`-quantified form is scheduled with the Graham
   tick." This is exactly fulfilled one file later: `GrahamBridge.lean`'s
   `speckerCover_not_acyclic` is described in its own docstring as "the order-free triangle
   fact... replacing the six-orderings enumeration with the order-free statement," and
   `GRAHAM_BRIDGE_URS.md` explicitly confirms: "the six-orderings hack (`speckerFam_no_rip`) is
   retired as the load-bearing form; the order-free statement now lives in its natural home."
   This is a clean, fully-closed cross-tree loop within my slice: a self-identified weaker
   result in file 1-2 is explicitly strengthened and the strengthening explicitly cross-
   referenced in file 3-4. I record it as a positive finding, not a contradiction — the two
   documents agree with each other about the deviation and its resolution.
4. **The confluence gap is a real, explicitly-scoped non-result — not silently dropped.**
   `GRAHAM_BRIDGE_URS.md`'s D1 documents a genuine proof attempt that failed (deterministic
   greedy ear-elimination confluence), locates the failure precisely, and the corresponding
   Verdicts section confirms: "confluence was never needed" for the shipped bridge, and
   "Deterministic-greedy confluence remains a named strengthening edge (linear-time decision),
   untouched and unsmuggled." I flag this as a Pl-kill that is correctly NOT hidden: the
   nondeterministic `GrahamN` in the shipped `.lean` file is real and complete, but a strictly
   stronger/more standard deterministic-greedy result is explicitly named as NOT proved and NOT
   claimed. No overclaim is made in the .lean docstrings — the module docstring of
   `GrahamBridge.lean` itself states this directly: "The DETERMINISTIC greedy... needs a
   genuine confluence lemma whose naive deletion proof has a real gap... it is a named
   strengthening edge, not assumed here."
5. **A `sorry`-on-disk incident, self-reported and resolved within the file (agent-axis note,
   reported per carrier honesty mandate, not asserted as a current defect).**
   `GRAHAM_BRIDGE_URS.md` states under "Process breach, logged honestly": two literal `sorry`
   placeholders were written to disk in a draft of `GrahamBridge.lean` before being caught and
   rewritten complete, prior to any compilation. The file explicitly states this was "the
   SECOND firing of the FiveWayPi failure mode" (referencing an incident/pattern named
   elsewhere, outside my slice — I cannot verify the "FiveWayPi" reference itself, see
   Agent-axis ignorance). The final `GrahamBridge.lean` I read contains **zero** occurrences of
   the string `sorry` (verified by full read) — the incident is historical/process-internal to
   the URS ledger, not a property of the shipped kernel artifact. I record this per the
   carrier's Pl-kill-is-content mandate but stress: the shipped file is clean.
6. **`Acyclic` is defined twice at different levels, correctly distinguished, not a
   contradiction.** `Amalgamation.lean`'s own D2 (in its URS) anticipates `Acyclic 𝒞 := ∃
   order, order.toFinset = 𝒞 ∧ RIP order` as a forward-pointer sketch. The shipped
   `GrahamBridge.lean` defines `Acyclic 𝒞 := ∃ order : List (Finset ι), order.Nodup ∧
   order.toFinset = 𝒞 ∧ RIPCover order` — note the shipped version adds `order.Nodup` (absent
   from the AMALGAMATION_URS.md sketch) and quantifies over `RIPCover` (team-level, defined in
   GrahamBridge.lean) rather than the family-level `RIP` (defined in Amalgamation.lean, over
   `LocalStruct`). This is a refinement between the sketch and the shipped definition, not a
   contradiction — `RIPCover` and `RIP` are bridged by the file's own
   `rip_iff_ripCover : RIP fam ↔ RIPCover (fam.map (·.team))`. I flag the `Nodup` addition as an
   unremarked-upon refinement (the D2 sketch in AMALGAMATION_URS.md did not mention
   duplicate-freedom as a requirement; the shipped `GrahamBridge.lean` needs it for the perm-lift
   machinery in `glues_of_acyclic`'s hypothesis `(fam.map (·.team)).Nodup`).
7. **Terminology: "GYO" appears only in my slice's task title and in one named-edge line, never
   expanded or cited.** See Citations section above. I do not resolve or assert what GYO stands
   for as fact extracted from the files — the files themselves never spell it out.
8. **Dependency boundary, not a contradiction:** `projS`, `projS_image_restrict₂` (used at the
   load-bearing `hkey` step of `projS_joinFam`) come from `Marginals.lean` (imported, outside my
   slice); `S01,S12,S02,diag01,diag12,anti02,specker_not_glues` (the Specker triangle's concrete
   data and its base non-gluing fact) come from `HigherObstruction.lean` (imported, outside my
   slice). Both files use these imports correctly and consistently across both `.lean` files in
   my slice (the same six Specker names are reused identically in `Amalgamation.lean`'s
   `speckerFam` and `GrahamBridge.lean`'s `speckerCover_not_acyclic`/`pathCover_acyclic`) — I
   note this as a coherent, non-contradictory cross-file reuse, not a duplication concern.

## Agent-axis ignorance (Γ)

Per the carrier's mandate, my own ignorance as a miner, kept strictly separate from the object
axis above.

1. **Upstream imports not read.** `Marginals.lean` and `HigherObstruction.lean` are imported by
   my slice's files and load-bearing for `projS_joinFam` (via `projS_image_restrict₂`) and for
   the Specker-triangle facts (via `S01,S12,S02,diag01,diag12,anti02,specker_not_glues`), but
   they are outside my assigned slice and I did not read them. I cannot independently verify
   the definitions of `projS`, `projS_image_restrict₂`, or the Specker triangle objects beyond
   how they are used (their type signatures as inferred from call sites) in my two `.lean`
   files. This is an intentional slice boundary, not an oversight, but I flag it as a genuine
   coverage gap for the orchestrator: if `Marginals.lean` or `HigherObstruction.lean` are
   assigned to another miner, my theorem transcriptions above for `projS_joinFam` and
   `speckerFam_not_glues` should be cross-checked against that miner's output for consistency
   on what `projS` and `specker_not_glues` actually state.
2. **"FiveWayPi failure mode" is an unresolved cross-reference.** `GRAHAM_BRIDGE_URS.md` names
   "the SECOND firing of the FiveWayPi failure mode" without defining what the "FiveWayPi
   failure mode" is or where its first firing was documented. This is outside my slice; I
   cannot resolve it and record it as UK (unknown-unknown from my vantage — I don't know which
   file, if any, in the broader corpus documents this pattern).
3. **"the FiberProduct lesson, D1 there" is an unresolved cross-reference.**
   `AMALGAMATION_URS.md`'s D1 references "the FiberProduct pattern... (two proofs banked)" and
   "the FiberProduct lesson, D1 there, applied again" as a prior tick's URS, presumably a
   `FIBER_PRODUCT_URS.md` or similarly named file elsewhere in the HC directory tree. Not in my
   slice; I did not read it and cannot verify the claimed lesson content, only that my slice
   references it twice, consistently, as a justification for the "no subtype-pi accumulation"
   design choice in `joinFam` and for the splice construction's dite-pattern.
4. **"C-JLeib≤" is named as a forward edge with no definition in my slice.** Appears
   identically in both URS files' Γ-yield sections ("the interface-tightening inequality") but
   is never defined, stated, or explained within my four files. I record it as a bare forward-
   pointer term, not a theorem I can transcribe.
5. **"parity3" is referenced in AMALGAMATION_URS.md's D5 as a planned kernel-check subject**
   ("parity3's full-marginal family over the triangle is consistent AND glues") but I found no
   declaration of this name anywhere in either `.lean` file in my slice. Either (a) it landed
   under a different name than planned (as happened with `joinFam_realizes`→`projS_joinFam`,
   see Cross-tree note 1), (b) it lives in a file outside my slice (likely
   `HigherObstruction.lean`, given "parity" terminology appears there via `specker_not_glues`
   and the anti/diag naming), or (c) it was deferred and never shipped within my slice. I could
   not determine which from my four files alone; flagged as UK, not asserted either way.
6. **"PhysLean's quantum marginal instances"** is named as a downstream consumer in both URS
   files' Γ-yield ("where PhysLean's quantum marginal instances land") but PhysLean is an
   external project I have no access to verify from my slice; I record the claim as an
   unverified forward-pointer, not a confirmed integration.
7. **I did not attempt to independently re-verify any Lean proof term-by-term against the
   actual Lean kernel** (no `lake build` or equivalent was run by me) — per my operator
   constraints (`act(describe)`/`act(search)` reliable, `act(imagine)` gated, and the carrier's
   instruction that "The mathematics is kernel-verified. Your job is not to re-verify or doubt
   it"), I transcribed the theorem statements and proof sketches as written and trusted the
   URS files' self-reported "All deliverables GREEN, 0 sorry" verdicts rather than
   independently compiling. This is the carrier's intended division of labor, not a gap I
   consider a defect, but I record it for completeness: my "0 sorry" confirmation above (for
   `GrahamBridge.lean`) is from my own textual grep-equivalent read of the file (I read every
   line and saw no `sorry` token), which is a real independent check; but I did not run the
   Lean kernel myself for either file.
8. **No `act(imagine)` was used.** I did not speculate about connections between this slice and
   other slices of the fan (e.g., how Amalgamation/Graham relates to the oscillation theorem
   mentioned once in passing, or to Marginals/HigherObstruction content). Where the files
   themselves state such a connection (e.g., "The oscillation theorem's discrete engine is now
   a proved implication, not a narrative" — a direct quote from `AMALGAMATION_URS.md`'s
   Γ-yield), I transcribed it as [STANCE] under Theorems and definitions; I did not extend,
   verify, or elaborate on it myself.

**Coverage statement:** all four assigned files were read completely, end to end, with no
truncation or skipping. `coverageComplete = true`. The ignorance items above are boundary/
cross-reference gaps (material outside my assigned slice), not incomplete reads within it.
