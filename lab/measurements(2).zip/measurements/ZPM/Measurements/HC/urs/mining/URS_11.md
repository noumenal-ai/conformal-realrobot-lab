# URS 11 — Information-theory backbone: KL, Pinsker, total correlation, MI

Miner: Sonnet miner 11. Slice: `InformationTheory/` KL/Pinsker/TotalCorrelation/MutualInformation/CrossEntropy backbone (25 files, as assigned; the sibling `KullbackLeibler/Gaussian/` subdirectory — 6 files — is confirmed present on disk but **not** in this slice and is not mined here).

## Files mined

All 25 assigned files read end to end via the `Read` tool. No truncation.

1. `ZPM/InformationTheory/Basic.lean` — top-level import aggregator (4 imports, no content of its own).
2. `ZPM/InformationTheory/Pinsker/Basic.lean` — import aggregator (3 imports).
3. `ZPM/InformationTheory/Pinsker/Binary.lean` — binary Pinsker inequality.
4. `ZPM/InformationTheory/Pinsker/Bridge.lean` — `klBin`-to-`klFun` bridge, Jensen, DPI for indicators.
5. `ZPM/InformationTheory/Pinsker/General.lean` — the per-set squared bound and general Pinsker.
6. `ZPM/InformationTheory/KullbackLeibler/Basic.lean` — import aggregator (3 imports).
7. `ZPM/InformationTheory/KullbackLeibler/Real.lean` — `klDivReal` definition and bridge theorems.
8. `ZPM/InformationTheory/KullbackLeibler/Fintype.lean` — `FintypePMF.klDiv` (discrete, sum-based).
9. `ZPM/InformationTheory/KullbackLeibler/FiniteSupport.lean` — `klDivReal` as a finite weighted sum on discrete spaces.
10. `ZPM/InformationTheory/KullbackLeibler/CondChainRule.lean` — integral form of the conditional KL chain rule.
11. `ZPM/InformationTheory/KullbackLeibler/MapEquiv.lean` — KL invariance under measurable equivalence.
12. `ZPM/InformationTheory/KullbackLeibler/NormLlr.lean` — L¹ bound on the log-likelihood ratio.
13. `ZPM/InformationTheory/KullbackLeibler/Tensorization.lean` — KL of finite product measures splits as a sum.
14. `ZPM/InformationTheory/KullbackLeibler/Binary/Basic.lean` — import aggregator (4 imports).
15. `ZPM/InformationTheory/KullbackLeibler/Binary/Def.lean` — `klBin` definition and boundary-value lemmas.
16. `ZPM/InformationTheory/KullbackLeibler/Binary/Derivatives.lean` — derivatives of `klBin` and of `g(q) = klBin p q − 2(p−q)²`.
17. `ZPM/InformationTheory/KullbackLeibler/Binary/Monotonicity.lean` — monotonicity of `g` on the two half-intervals around `p`.
18. `ZPM/InformationTheory/KullbackLeibler/Binary/TwoSqLeNegLog.lean` — the two boundary inequalities `2q² ≤ −log(1−q)` and `2(1−q)² ≤ −log q`.
19. `ZPM/InformationTheory/TotalCorrelation/Def.lean` — `totalCorrelationReal` definition and its reduction to MI at `Fin 2`.
20. `ZPM/InformationTheory/MutualInformation/Basic.lean` — import aggregator (3 imports).
21. `ZPM/InformationTheory/MutualInformation/Def.lean` — `mutualInformationReal` definition.
22. `ZPM/InformationTheory/MutualInformation/Nonneg.lean` — MI nonnegativity.
23. `ZPM/InformationTheory/MutualInformation/ZeroIffProduct.lean` — MI = 0 ⟺ joint is product of marginals.
24. `ZPM/InformationTheory/CrossEntropy/Basic.lean` — import aggregator (1 import).
25. `ZPM/InformationTheory/CrossEntropy/Fintype.lean` — `FintypePMF.crossEntropy` definition.

All files carry the header `Copyright (c) 2026 Dhruv Gupta. All rights reserved. Released under Apache 2.0 license... Authors: Dhruv Gupta`.

## Theorems and definitions (each tagged)

Organized by sub-area, in dependency order. Tag legend: [KV] kernel-verified theorem, [decide] finite decidable check, [CONJ] named conjecture, [PROBE] literature-audit verdict, [STANCE] interpretive/positioning claim, [def] a definition, [infra] import-aggregator file with no mathematical content of its own.

### Binary KL divergence (`KullbackLeibler/Binary/`)

- **`klBin`** [def], `Binary/Def.lean:20`. `klBin p q := p·log(p/q) + (1−p)·log((1−p)/(1−q))`, the Bernoulli(p)-vs-Bernoulli(q) KL divergence.
- **`klBin_self`** [KV], `Binary/Def.lean:24`. `klBin p p = 0` for `p ∈ (0,1)`.
- **`klBin_zero_left`** [KV], `Binary/Def.lean:33`. `klBin 0 q = −log(1−q)`.
- **`klBin_one_left`** [KV], `Binary/Def.lean:42`. `klBin 1 q = −log q`.
- **`klBin_expand`** [KV], `Binary/Def.lean:51`. Algebraic re-expansion into four separated log terms — used to compute the derivative w.r.t. `q`.
- **`hasDerivAt_klBin_q`** [KV], `Binary/Derivatives.lean:23`. `d/dq klBin p q = (q−p)/(q(1−q))` for `p, q ∈ (0,1)`.
- **`hasDerivAt_sub_sq`** [KV], `Binary/Derivatives.lean:54`. `d/dq (p−q)² = −2(p−q)`.
- **`hasDerivAt_g`** [KV], `Binary/Derivatives.lean:65`. Derivative of `g(q) := klBin p q − 2(p−q)²` factors as `(q−p)(1−2q)²/(q(1−q))` — the algebraic core the whole binary-Pinsker argument pivots on: the sign of `g'` is exactly `sign(q−p)`.
- **`deriv_factor_nonneg`** [KV], `Binary/Monotonicity.lean:26`. `(1−2q)²/(q(1−q)) ≥ 0` on `(0,1)`.
- **`deriv_g_nonneg_of_ge`** [KV], `Binary/Monotonicity.lean:32`. `g'(q) ≥ 0` on `q ≥ p`.
- **`deriv_g_nonpos_of_le`** [KV], `Binary/Monotonicity.lean:40`. `g'(q) ≤ 0` on `q ≤ p`.
- **`continuousOn_klBin_Ico`**, **`continuousOn_klBin_Ioc`**, **`continuousOn_sub_sq`**, **`continuousOn_g_Ico`**, **`continuousOn_g_Ioc`** [KV, private helper lemmas], `Binary/Monotonicity.lean:48–78`. Continuity side-conditions feeding the mean-value-theorem-based monotonicity lemmas.
- **`monotoneOn_g`** [KV], `Binary/Monotonicity.lean:81`. `g` is `MonotoneOn (Set.Ico p 1)`.
- **`antitoneOn_g`** [KV], `Binary/Monotonicity.lean:96`. `g` is `AntitoneOn (Set.Ioc 0 p)`.
- **`hasDerivAt_h_zero`** [KV, private], `Binary/TwoSqLeNegLog.lean:23`. Derivative of the boundary auxiliary `h(q) = −log(1−q) − 2q²` is `(2q−1)²/(1−q)`.
- **`monotoneOn_h_zero`** [KV, private], `Binary/TwoSqLeNegLog.lean:49`. `h` is monotone on `[0,1)`.
- **`two_sq_le_neg_log_one_sub`** [KV], `Binary/TwoSqLeNegLog.lean:65`. `2q² ≤ −log(1−q)` for `q ∈ [0,1)`. This is the `p = 0` boundary case fed directly into `binary_pinsker`.
- **`two_sq_le_neg_log`** [KV], `Binary/TwoSqLeNegLog.lean:74`. `2(1−q)² ≤ −log q` for `q ∈ (0,1]`, obtained by substituting `r = 1−q` into the previous. This is the `p = 1` boundary case.

### Binary Pinsker (`Pinsker/Binary.lean`)

- **`binary_pinsker`** [KV], `Pinsker/Binary.lean:22`. **`2(p−q)² ≤ klBin p q`** for `p ∈ [0,1]`, `q ∈ (0,1)`. Docstring explicitly claims "Sharp constant `2`" [STANCE — the sharpness claim itself is not separately proved as a matching-upper-bound theorem in this slice; it is asserted in the docstring]. Proof strategy: case-split on `p = 0` (via `klBin_zero_left` + `two_sq_le_neg_log_one_sub`), `p = 1` (via `klBin_one_left` + `two_sq_le_neg_log`), and `p ∈ (0,1)` further split on `p ≤ q` (via `monotoneOn_g`) vs `q ≤ p` (via `antitoneOn_g`), each reducing to `klBin p p − 2(p−p)² = 0` (via `klBin_self`) plus the monotonicity fact.

### Bridge to Mathlib's `klFun` (`Pinsker/Bridge.lean`)

- **`klBin_eq_klFun_sum`** [KV], `Pinsker/Bridge.lean:35`. Algebraic identity: `klBin p q = q·klFun(p/q) + (1−q)·klFun((1−p)/(1−q))`, where `klFun` is Mathlib's convex function underlying its KL machinery (imported from `Mathlib.InformationTheory.KullbackLeibler.KLFun`).
- **`klFun_integral_ge_of_measurableSet`** [KV], `Pinsker/Bridge.lean:46`. Jensen's inequality restricted to a measurable subset `A`: `Q.real A · klFun((Q.real A)⁻¹ ∫_A f dQ) ≤ ∫_A klFun(f) dQ`. Proved via `convexOn_klFun.map_set_average_le` (a Mathlib convexity lemma).
- **`klBin_le_klDivReal`** [KV], `Pinsker/Bridge.lean:79`. **Data-processing inequality for indicators**: `klBin(P(A), Q(A)) ≤ klDivReal P Q` for probability measures `P ≪ Q` with integrable log-likelihood ratio, for any measurable set `A`. Proof: rewrites `klDivReal` as `∫ klFun(dP/dQ) dQ`, splits the integral over `A` and `Aᶜ` (`integral_add_compl`), applies the Jensen lemma on each piece, and reassembles using `klBin_eq_klFun_sum`. Case-splits on `Q(A) = 0` and `Q(A) = 1` are handled separately (both collapse `klBin` to `0`, trivially ≤ a nonnegative integral).

### The per-set bound and general Pinsker (`Pinsker/General.lean`)

- **`two_sq_sub_le_klDivReal`** [KV], `Pinsker/General.lean:35`. **THE THEOREM THIS SLICE NOTE ASKS ME TO TRACE TO.** Statement: for probability measures `P, Q` with `P ≪ Q` and integrable log-likelihood ratio, and any measurable set `A`:
  ```
  2 * (P.real A - Q.real A)^2 ≤ klDivReal P Q
  ```
  Proof: direct chain `2(P(A)−Q(A))² ≤ klBin(P(A),Q(A)) ≤ klDivReal P Q`, i.e. `binary_pinsker` composed with `klBin_le_klDivReal`, wrapped in edge-case handling for `Q(A) = 0` and `Q(A) = 1` (in each case one side collapses to `0 ≤ klDivReal P Q`, discharged by `klDivReal_nonneg`).
- **`pinsker_proof`** [KV], `Pinsker/General.lean:86`. **Pinsker's inequality, sharp constant**: `tvDistReal P Q ≤ sqrt(klDivReal P Q / 2)` for probability measures `P ≪ Q` with finite KL. Proof: unfolds `tvDistReal` as a `csSup` over `{|P(A) − Q(A)| : A measurable}` (imported from `ZPM.MeasureTheory.ProbabilityMeasure.TotalVariation.Real`, out of this slice), rewrites the absolute value as `sqrt(square)`, and applies `two_sq_sub_le_klDivReal` pointwise inside the `sSup`.

**The full derivation chain the slice note asks for, `binary_pinsker → klBin_le_klDivReal → two_sq_sub_le_klDivReal`, is exactly:**
```
two_sq_le_neg_log_one_sub, two_sq_le_neg_log   (boundary bounds, TwoSqLeNegLog.lean)
        │
        ├── klBin_self, klBin_zero_left, klBin_one_left, monotoneOn_g, antitoneOn_g
        ▼
   binary_pinsker : 2(p−q)² ≤ klBin p q                       (Pinsker/Binary.lean)
        │
        │   klBin_eq_klFun_sum, klFun_integral_ge_of_measurableSet  (Pinsker/Bridge.lean, Jensen)
        ▼
   klBin_le_klDivReal : klBin(P(A),Q(A)) ≤ klDivReal P Q       (Pinsker/Bridge.lean, DPI)
        │
        ▼
   two_sq_sub_le_klDivReal : 2(P(A)−Q(A))² ≤ klDivReal P Q     (Pinsker/General.lean)  ← the target
        │
        ▼
   pinsker_proof : tvDistReal P Q ≤ sqrt(klDivReal P Q / 2)    (Pinsker/General.lean)
```
This is the "Pinsker set bound used by the approximate five-way" the slice note names. I did not find, within my assigned 25 files, any file that itself *invokes* `two_sq_sub_le_klDivReal` downstream (no file in my slice imports `Pinsker/General.lean` or calls the theorem by name) — the consuming site (presumably in the "approximate five-way" machinery under `Measurements/HC/` or similar) is outside my slice. This is recorded as agent-axis ignorance below.

### Real-valued KL divergence, the Mathlib bridge (`KullbackLeibler/Real.lean`)

- **`klDivReal`** [def], `Real.lean:42`. `klDivReal P Q := if P ≪ Q then ∫ log(dP/dQ) dP else 0`. Docstring states this is "the same proof-engineering specialization as `FintypePMF` relative to `Mathlib.PMF`, documented in `CHARTER.md` under 'Duplicate rule exception'" [STANCE — a positioning claim about the project's own engineering governance, not a mathematical claim; `CHARTER.md` was confirmed to exist on disk at `design-lab/measurements/CHARTER.md` but its content is outside this slice].
- **`integrand_eq_llr`** [KV], `Real.lean:49`. `klDivReal`'s integrand is definitionally Mathlib's `llr P Q` (`rfl`-provable).
- **`klDivReal_eq_toReal_klDiv`** [KV], `Real.lean:55`. For probability measures with `P ≪ Q`, `klDivReal P Q = (klDiv P Q).toReal` — the bridge from Mathlib's `ℝ≥0∞`-valued `klDiv` to this project's `ℝ`-valued layer.
- **`klDivReal_nonneg`** [KV], `Real.lean:66`. `0 ≤ klDivReal P Q` for probability measures.
- **`klDivReal_eq_zero_iff`** [KV], `Real.lean:81`. `klDivReal P Q = 0 ↔ P = Q`, under `P ≪ Q` and finite `klDiv`. Docstring is explicit that "the finite-KL hypothesis is essential: a non-integrable log-likelihood ratio makes the Bochner integral collapse to 0 even when `P ≠ Q`" [STANCE, but this is a correct mathematical remark about the Bochner-integral convention, matched by the theorem's explicit `hfin` hypothesis — not a Pl-kill, a genuine documented caveat].

### Discrete/finite specializations (`KullbackLeibler/Fintype.lean`, `FiniteSupport.lean`)

- **`FintypePMF.klDiv`** [def], `Fintype.lean:30`. `klDiv Q P := ∑ h, if Q.prob h = 0 then 0 else Q.prob h · log(Q.prob h / P.prob h)`, a `Finset.sum`-based specialization on `Fintype`-indexed discrete distributions. Docstring again invokes the "proof-engineering specialization clause of `CHARTER.md`" [STANCE].
- **`absolutelyContinuous_of_forall_singleton`** [KV], `FiniteSupport.lean:29`. On a finite space with measurable singletons, absolute continuity `P ≪ Q` follows from a check on singleton masses: `∀ x, Q{x}=0 → P{x}=0`.
- **`klDivReal_fintype`** [KV], `FiniteSupport.lean:41`. **`klDivReal P Q = ∑ x, P{x}·log(P{x}/Q{x})`** on a finite discrete space with `P ≪ Q` — the explicit finite-sum form of KL. Docstring frames this as "the engine of the quantitative (approximate) five-way's counting leg" [STANCE — names a downstream consumer, "the approximate five-way," by role but that consumer is not in this slice].

### Conditional / chain-rule form (`KullbackLeibler/CondChainRule.lean`)

- **`rnDeriv_compProd_right`** [KV], `CondChainRule.lean:39`. The Radon-Nikodym derivative of a shared-first-marginal `compProd` is the pointwise kernel derivative: `∂(μ⊗ₘκ)/∂(μ⊗ₘη)(x,y) = κ.rnDeriv η x y` a.e., for Markov kernels `κ, η` under `μ⊗ₘκ ≪ μ⊗ₘη` and a countable/countably-generated hypothesis on `D, O`.
- **`klDivReal_compProd`** [KV], `CondChainRule.lean:63`. **Integral form of the conditional KL chain rule**: `klDivReal(μ⊗ₘκ)(μ⊗ₘη) = ∫ x, klDivReal(κ x)(η x) ∂μ`. Docstring explicitly frames this as filling a gap: "the direction that the additive chain rule `InformationTheory.klDiv_compProd_eq_add` does not provide (it is vacuous on a shared first marginal)" — a [PROBE]-flavored claim about what Mathlib's existing chain rule *cannot* do, stated as an engineering rationale rather than a formal literature-audit verdict, so tagged [STANCE].
- **`klDivReal_compProd_prod`** [KV], `CondChainRule.lean:92`. Specialization to a constant second kernel (`η = const Q`): `klDivReal(μ⊗ₘκ)(μ.prod Q) = ∫ x, klDivReal(κ x) Q ∂μ`. Docstring states this is "the shape consumed by the PAC-privacy variational bound `mutualInformationReal_le_condKL`" [STANCE — names a specific downstream theorem by name; **this named theorem is NOT defined anywhere in the ZPM tree** per my grep check below, flagged as agent-axis ignorance / dangling forward-reference].

### Invariance under measurable equivalence (`KullbackLeibler/MapEquiv.lean`)

- **`klDivReal_map_measurableEquiv`** [KV], `MapEquiv.lean:32`. `klDivReal (P.map e) (Q.map e) = klDivReal P Q` for a measurable equivalence `e : α ≃ᵐ β` and σ-finite `P, Q`.
- **`llr_map_equiv`** [KV], `MapEquiv.lean:68`. The log-likelihood ratio transports a.e. under `e`: `llr (μ.map e)(ν.map e)(e x) =ᵐ[ν] llr μ ν`.
- **`klDiv_map_equiv`** [KV], `MapEquiv.lean:77`. The `ℝ≥0∞`-valued analogue: `klDiv (μ.map e)(ν.map e) = klDiv μ ν` for finite measures. Docstring: "This is the change-of-variables engine behind the whitening reduction of the multivariate Gaussian KL closed form" [STANCE — names the `Gaussian/Whitening.lean` file, which is confirmed to exist on disk but is explicitly out of this slice].

### L¹ control on the log-likelihood ratio (`KullbackLeibler/NormLlr.lean`)

- **`mul_negPart_log_le_one`** [KV, private], `NormLlr.lean:36`. `f · max(−log f, 0) ≤ 1` for `f ≥ 0` — pointwise bound feeding the integral estimate.
- **`integral_norm_llr_le_klDivReal_add`** [KV], `NormLlr.lean:53`. **`∫ ‖llr P R x‖ dP ≤ klDivReal P R + 2`**, for finite `P ≪ R`, `R` a probability measure, `llr` integrable. Docstring is explicit and specific about the literature gap: "Mathlib has the finiteness criterion (`klDiv_ne_top_iff`) but not this quantitative `L¹` control." [STANCE — a claim about what Mathlib does/doesn't contain, phrased as an engineering rationale, not a formal search-scoped literature-audit verdict, so tagged STANCE rather than PROBE.] Also states the intended downstream use: "composed over a Markov kernel it dominates the per-input `∫‖llr‖` by a divergence-plus-constant that is integrable in the input" [STANCE, forward-looking, consumer not in this slice].

### Tensorization over finite products (`KullbackLeibler/Tensorization.lean`)

- **`klDiv_prod_same_left`** [KV], `Tensorization.lean:34`. `klDiv(μ.prod ν)(μ.prod ν') = klDiv ν ν'` when the first marginal is shared — proved by swapping coordinates (`MeasurableEquiv.prodComm`) and reducing to Mathlib's `klDiv_compProd_left`.
- **`klDiv_prod`** [KV], `Tensorization.lean:52`. **Binary KL tensorization**: `klDiv(μ.prod ν)(μ'.prod ν') = klDiv μ μ' + klDiv ν ν'` for probability measures.
- **`klDiv_pi`** [KV], `Tensorization.lean:64`. **KL tensorization over a `Fin n`-indexed finite product**: `klDiv(Measure.pi P)(Measure.pi Q) = ∑ i, klDiv(P i)(Q i)`. Proved by induction on `n` via `piFinSuccAbove` peeling off the first coordinate.
- **`klDivReal_pi`** [KV], `Tensorization.lean:100`. Real-valued analogue of `klDiv_pi` under per-coordinate absolute continuity and finiteness hypotheses.
- **`klDiv_pi'`** [KV], `Tensorization.lean:119`. Reindexing of `klDiv_pi` to an arbitrary `Fintype` index (not just `Fin n`), via `Fintype.equivFin` and `klDiv_map_equiv`.
- **`klDivReal_pi'`** [KV], `Tensorization.lean:138`. Real-valued analogue of `klDiv_pi'`.
- Docstring states this tensorization machinery "is the step that lets a diagonalized multivariate Gaussian KL split into its `d` one-dimensional Gaussian-Gaussian factors" [STANCE — again pointing at `Gaussian/Diagonal.lean`, confirmed to exist, out of scope here].

### Total correlation (`TotalCorrelation/Def.lean`)

- **`totalCorrelationReal`** [def], `TotalCorrelation/Def.lean:30`. `totalCorrelationReal P := klDivReal P (∏ᵢ P.map(eval i))` — the KL divergence of a joint law on a finite product against the product of its own marginals. Docstring: "the multivariate generalization of mutual information (Watanabe's total correlation)" [STANCE — attributes the concept to Watanabe by name but gives **no year, no title, no arXiv/DOI**; this is a bare attributional mention, not a full citation, and is recorded verbatim under Citations below since it names a specific person as originator].
- **`totalCorrelationReal_fin_two`** [KV], `TotalCorrelation/Def.lean:36`. **Total correlation over a two-element index equals mutual information of the paired law**: `totalCorrelationReal P = mutualInformationReal (P.map (MeasurableEquiv.piFinTwo X))`. Proof: shows the marginals of the paired law equal the coordinate marginals, that the product-of-marginals transports correctly under the pairing equivalence, and invokes `klDivReal_map_measurableEquiv`.

### Mutual information (`MutualInformation/Def.lean`, `Nonneg.lean`, `ZeroIffProduct.lean`)

- **`mutualInformationReal`** [def], `MutualInformation/Def.lean:23`. `mutualInformationReal P := klDivReal P ((P.map Prod.fst).prod (P.map Prod.snd))` — KL of the joint against the product of its two marginals. ℝ-valued.
- **`mutualInformationReal_nonneg`** [KV], `MutualInformation/Nonneg.lean:22`. `0 ≤ mutualInformationReal P` for probability measures. Delegates directly to `klDivReal_nonneg` after instance-establishing that the marginal product is itself a probability measure.
- **`mutualInformationReal_eq_zero_iff_product`** [KV], `MutualInformation/ZeroIffProduct.lean:26`. **`mutualInformationReal P = 0 ↔ P = (P.map Prod.fst).prod (P.map Prod.snd)`**, under absolute continuity of the joint w.r.t. the marginal product and finite KL. Docstring again flags the necessity of the finite-KL hypothesis for the forward direction (same Bochner-integral-collapse caveat as `klDivReal_eq_zero_iff`) [STANCE, consistent caveat, not a Pl-kill].

### Cross-entropy (`CrossEntropy/Fintype.lean`)

- **`FintypePMF.crossEntropy`** [def], `CrossEntropy/Fintype.lean:24`. `crossEntropy Q P := ∑ h, Q.prob h · log(1/P.prob h)`. Docstring states the identity "Related to KL by `H(Q,P) = H(Q) + KL(Q‖P)` where `H(Q)` is Shannon entropy" [STANCE — this decomposition identity is **asserted in prose, not proved as a theorem anywhere in this file or the rest of this slice**; no `crossEntropy_eq_entropy_add_klDiv`-style theorem exists in my 25 files. Flagged as a Pl-kill candidate: a docstring claims a relationship the Lean in this slice does not state as a proved theorem.]

### Import-aggregator files (no mathematical content)

`Basic.lean` (top-level), `Pinsker/Basic.lean`, `KullbackLeibler/Basic.lean`, `KullbackLeibler/Binary/Basic.lean`, `MutualInformation/Basic.lean`, `CrossEntropy/Basic.lean` — all [infra], each containing only `import` statements that wire the sub-files into a shared namespace. No `def`/`theorem`/`lemma` in any of these six files.

## Citations

Verbatim extraction of every named work found across the 25 files. **This slice's citation content is extremely thin** — almost the entire corpus consists of self-referential engineering docstrings (naming other files/theorems in the *same* project) rather than external literature citations.

### Attributional mention (name only, no full citation)

> "the multivariate generalization of mutual information (Watanabe's total correlation)"

— source: `ZPM/InformationTheory/TotalCorrelation/Def.lean`, docstring lines 13–14 (module doc header). Supports the claim that total correlation is Watanabe's construct. **No year, no title, no arXiv id, no DOI is given anywhere in this file or any other file in my slice.** Per the carrier's instruction, transcribed exactly as written; no id fabricated. Recorded as an attributional mention rather than a full citation, since the four required fields (author, year, title, id) are only partially present (author name only).

### Internal project document reference (not external literature)

> "the same proof-engineering specialization as `FintypePMF` relative to `Mathlib.PMF`, documented in `CHARTER.md` under 'Duplicate rule exception.'"

— source: `ZPM/InformationTheory/KullbackLeibler/Real.lean`, docstring lines 19–21. Also repeated near-verbatim in `ZPM/InformationTheory/KullbackLeibler/Fintype.lean`, docstring lines 15–17: "admitted under the proof-engineering specialization clause of `CHARTER.md` for the same reason as `FintypePMF` itself." This is a reference to an internal governance document, not an external citation. I confirmed via `find` that `CHARTER.md` exists on disk at `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/CHARTER.md` (and a duplicate under a worktree path) — so this is a real, resolvable internal reference, not a fabrication, but it is not literature and I did not read its content (out of slice).

### No external mathematical-literature citations (Pinsker, KL, chain rule)

Despite this slice covering Pinsker's inequality, the KL chain rule, and mutual information — all classical information-theory results with well-known literature origins (Pinsker 1960/1964, Csiszár, Cover & Thomas, etc.) — **no file in this slice cites any external paper, textbook, or author for these results** beyond the single bare "Watanabe" mention above. All results are presented as self-contained Lean derivations with engineering-style docstrings pointing at sibling files/theorems within the same project, not at external sources. This absence is itself a finding, recorded precisely so as not to be mistaken for an oversight on my part: I read every docstring in all 25 files and this is the complete citation content.

## Literature-audit verdicts

**None found in this slice.** No file among the 25 contains a `[PROBE]`-style literature-audit verdict (no "novelty," "no-ancestor," "appears in no examined work," "boundary/Pl-kill," or similarly scoped search claim with a stated search breadth/standard). This sub-library reads as pure mathematical infrastructure (KL divergence, Pinsker, tensorization, mutual information) with engineering-rationale docstrings, not as HC-programme novelty-claiming material. This is consistent with the slice note's suggestion that "this sublibrary may be general-purpose Mathlib-adjacent infrastructure."

## Cross-tree / divergence notes

- **HC-specificity assessment (as requested by the slice note).** Of the 25 files, the overwhelming majority are **general-purpose information-theory infrastructure** with no HC-specific content: `klBin` and its full derivative/monotonicity apparatus, `klDivReal` and its Mathlib bridge, `klDivReal_fintype`, `klDivReal_map_measurableEquiv`, `klDivReal_compProd` (chain rule), `klDiv_pi`/`klDiv_pi'` (tensorization), `mutualInformationReal` and its two basic properties, `totalCorrelationReal`, and `FintypePMF.crossEntropy`/`klDiv` are all reusable, self-contained mathematical results that would sit naturally in (or adjacent to) Mathlib's own `InformationTheory` folder. None of the 25 files import anything from `Measurements/HC/` or reference HC/five-way/discovery-invariance concepts directly. **The only HC-specific hooks are in the docstrings, as forward-pointers to consuming code outside this slice**: (a) `FiniteSupport.lean`'s docstring names "the quantitative (approximate) five-way's counting leg" as the consumer of `klDivReal_fintype`; (b) `Pinsker/General.lean`'s docstring explicitly frames the whole Pinsker derivation as feeding "the approximate five-way" (matching the slice note's own framing); (c) `CondChainRule.lean`'s docstring names `mutualInformationReal_le_condKL` as "the PAC-privacy variational bound" consumer. So: **this sublibrary is general-purpose infrastructure that the HC programme consumes, not HC-specific mathematics itself.** The actual HC-specific content (the five-way, the variational bound, the discovery-invariance argument) lives elsewhere in the tree, outside this slice.
- **Dangling forward-reference: `mutualInformationReal_le_condKL`.** Named in the docstrings of both `CondChainRule.lean` (mine) and `Gaussian/AbsolutelyContinuous.lean` (confirmed via `grep`, not mine) as "the PAC-privacy variational bound." I searched the entire `ZPM/` tree for a `theorem`/`lemma` declaration of this exact name and found **none**. Either (a) it is defined somewhere outside the `ZPM/` tree entirely, (b) it is planned but not yet written, or (c) it was renamed and the docstrings were not updated. I cannot resolve which from my slice alone. Flagged precisely so the Opus synthesis can check other miners' slices or the wider repo for this theorem.
- **Sibling directory confirmed out-of-scope: `KullbackLeibler/Gaussian/`.** Six files (`AbsolutelyContinuous.lean`, `AffineImage.lean`, `ClosedForm.lean`, `Diagonal.lean`, `OneDim.lean`, `Whitening.lean`) exist on disk under the same `KullbackLeibler/` parent as several of my assigned files, but were **not** in my assignment list and I did not read them. Three of my files' docstrings point at this directory by role (`MapEquiv.lean` → "the whitening reduction of the multivariate Gaussian KL closed form"; `Tensorization.lean` → "a diagonalized multivariate Gaussian KL split[ting] into its `d` one-dimensional Gaussian-Gaussian factors"). These are presumably another miner's slice; I note the dependency direction (my files are imported *by* the Gaussian files, based on the docstring framing, not the reverse) but did not verify this by reading the Gaussian files' import lists.
- **Internal consistency check: no contradictions found.** Across the 25 files I found no two lemmas that assert incompatible things about the same object. The two places where a finite-KL hypothesis is flagged as "essential" (`klDivReal_eq_zero_iff` in `Real.lean` and `mutualInformationReal_eq_zero_iff_product` in `ZeroIffProduct.lean`) are consistent with each other and both correctly reflect the theorem's own stated hypothesis (`hfin`/`InformationTheory.klDiv P Q ≠ ⊤`), so this is documentation-of-hypothesis, not overclaiming.
- **Possible Pl-kill candidate: `crossEntropy` decomposition identity not proved.** As noted above under Theorems, `CrossEntropy/Fintype.lean`'s docstring asserts `H(Q,P) = H(Q) + KL(Q‖P)` but no theorem with this content appears anywhere in the 25 files (nor, as far as I can tell without reading it, in `Basic.lean`, which is a pure import-aggregator with zero content of its own). This is either (a) proved elsewhere outside my slice, (b) planned but not yet formalized, or (c) an aspirational docstring note. I flag it rather than assert or hide it, per the carrier's A4 instruction.
- **Naming duplication note (not a contradiction, a documentation observation).** `KullbackLeibler/Binary/Basic.lean` (file 14, the import aggregator for the `Binary/` subfolder) and `KullbackLeibler/Binary/Def.lean` (file 15, which actually defines `klBin`) are distinct files with distinct roles despite the superficially similar naming pattern (`Basic.lean` = imports-only, `Def.lean` = the actual definitions) — this pattern (`Basic.lean` as a pure re-export shim, with real content one level down in `Def.lean`/specific-topic files) recurs identically at every level of this sub-tree (top `Basic.lean`, `Pinsker/Basic.lean`, `KullbackLeibler/Basic.lean`, `MutualInformation/Basic.lean`, `CrossEntropy/Basic.lean`) and appears to be a deliberate, consistent project convention rather than an accident — recorded as a structural observation, not a finding requiring action.

## Agent-axis ignorance (Γ)

- **Unresolved cross-reference: `mutualInformationReal_le_condKL`.** As detailed above, this theorem is named twice (by two different files, one in-slice, one confirmed-out-of-slice) but its actual `theorem`/`lemma` declaration was not found anywhere in the `ZPM/` tree via exhaustive `grep`. I cannot determine whether it exists elsewhere in the repo (outside `ZPM/`), is unwritten, or was renamed. This is UK on my agent axis: I know the gap exists, I do not know its resolution.
- **No direct consumer of `two_sq_sub_le_klDivReal` found in-slice.** The slice note frames this theorem as "the Pinsker set bound used by the approximate five-way," but none of my 25 files themselves invoke it downstream (it is the terminal theorem of `Pinsker/General.lean`, consumed only by `pinsker_proof` in the same file). The actual "approximate five-way" consuming code is, by construction, outside this slice — I was not asked to trace forward past my file list, and did not attempt to (per the carrier: I mine my assigned files, I do not chase every reference wherever it leads). I flag this so the Opus synthesis knows the forward link is asserted by docstring only, not independently verified by me against consuming code.
- **`Watanabe` attribution left unresolved.** I recorded the bare name "Watanabe" for total correlation exactly as it appears, with no year/title/id, per the explicit anti-fabrication instruction ("If an identifier is absent, write 'no id given'" — here even more is absent than just the id, so I have recorded the full absence rather than inventing any of the missing fields). I did not attempt to independently identify which Watanabe paper this might reference — that would be `act(search)` reaching into external knowledge beyond what's literally in the files, which the carrier scopes as within my reliable operators only for citations *actually present* in the corpus, not for backfilling missing ones.
- **`CHARTER.md` content not read.** I confirmed the file's existence and path (twice, once in a worktree) but did not read its content, since it sits outside my assigned 25-file slice (`design-lab/measurements/CHARTER.md`, a project-root document, not part of `ZPM/InformationTheory/`). I cannot independently verify that its "Duplicate rule exception" clause says what the two docstrings claim it says. Recorded as UK, not asserted as PLAUSIBLE or CONFIRMED.
- **`Gaussian/` subfolder not read.** Six files confirmed to exist on disk under `KullbackLeibler/Gaussian/` were named by role in three of my files' docstrings but were explicitly excluded from my assignment. I have not verified the truth of those forward-pointing docstring claims (e.g., that `klDiv_map_equiv` really is "the change-of-variables engine behind the whitening reduction") against the actual Gaussian-file proofs — I can only report that the docstrings *assert* this relationship, tagged [STANCE], not independently confirm it.
- **No independent check of Mathlib-side lemma names.** Several proofs in my slice invoke Mathlib lemmas by name (e.g., `convexOn_klFun.map_set_average_le`, `Measure.rnDeriv_withDensity`, `klDiv_compProd_eq_add`, `klDiv_compProd_left`, `Real.log_le_sub_one_of_pos`, `measurePreserving_piFinSuccAbove`, `Fintype.equivFin`). I transcribed these names as they appear in the source (`import` lines and proof terms) but did not independently verify against a live Mathlib checkout that each name resolves to a lemma with the stated content — the carrier instructs me to treat the corpus (kernel-verified Lean) as strictly true, and since this is compiled/kernel-checked code, I extend that trust to the Mathlib invocations without separately re-deriving them.
- **`crossEntropy`-KL decomposition: not independently checked against `Basic.lean` aggregator or beyond.** I noted this as a possible Pl-kill (docstring asserts an identity not proved in-slice) but did not chase whether it is proved in some file entirely outside `ZPM/InformationTheory/` (e.g., under `Measurements/` or an `Entropy/` folder elsewhere in the tree) — that would be outside my assigned 25 files and I did not go looking, consistent with staying in my lane.

**Coverage statement:** all 25 assigned files were read in full via the `Read` tool, with no `offset`/`limit` truncation on any of them (each file was short enough — the longest, `Pinsker/Bridge.lean`, is 176 lines — to read whole in one call). I additionally ran two `grep`/`find` checks purely to resolve cross-references named in docstrings (locating `mutualInformationReal_le_condKL`'s definition site, if any, and confirming `CHARTER.md`'s existence) — these are agent-axis bookkeeping, not additional mining beyond my slice, and I did not read the content of any file outside my 25-file assignment.
