# URS_08 — Vorob'ev converse, Dirac, and the cyclic-converse ledger

Miner: Sonnet miner 08. Slice: `VorobevConverse.lean`, `Dirac.lean`, `CYCLIC_CONVERSE_URS.md`.
Method: `act(describe)` and `act(search)` only, per the noological carrier. No `act(imagine)`.
Object axis (γ) and agent axis (Γ) are reported in separate sections as instructed.

---

## Files mined

| # | Path | Lines (1-indexed, Read tool) | Coverage |
|---|------|-------------------------------|----------|
| 1 | `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/VorobevConverse.lean` | 589 | Full, one Read call, no truncation |
| 2 | `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/Dirac.lean` | 1116 | Full, two Read calls (offset 1–856, then 857–1116); first call was truncated by the harness at 856/1116 with an explicit notice, second call completed it |
| 3 | `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/CYCLIC_CONVERSE_URS.md` | 707 | Full, one Read call, no truncation notice returned |

`wc -l` cross-check (0-indexed, no trailing-newline count): 588 / 1115 / 706 — consistent with the Read tool's 1-indexed totals (589 / 1116 / 707). No gap between the two counting conventions; full coverage confirmed independently of the Read tool's own pagination.

Also read in full: the carrier document `NOOLOGICAL_CARRIER.md` (operating instructions, not part of the mined object-axis content).

---

## Theorems and definitions

Organized by file, in file order. Each entry tagged per the carrier's typology: **[KV]** kernel-proved theorem, **[decide]** finite decidable check, **[CONJ]** named conjecture, **[PROBE]** literature-audit verdict, **[STANCE]** interpretive/positioning claim, **[def]** a Lean definition (not itself a truth-claim), **[infra]** supporting Lean-engineering machinery (private lemmas, casts, technical scaffolding) recorded for completeness but not claimed as a "result."

### `VorobevConverse.lean`

**Header docstring claims [STANCE]:**
- The file implements "the chain of CYCLIC_CONVERSE_URS D26": primal grammar, parity bridge, two FINDERS feeding `clean_system_obstruction`, the one-step GYO collapse, and the assembly `capstone_of_core`.
- **[STANCE]** "Dirac's lemma (the single named classical obligation, absent from Mathlib) upgrades this to the chordal/conformal dichotomy" — this is the file's own claim about Mathlib's coverage, tagged STANCE because it is an assertion in a docstring, not a Lean-checked fact; corroborated independently by the URS's own PROBE-level statement (see Literature-audit verdicts, "Mathlib floor: chordality theory").

**Parity bridge:**
- `mem_xorSum` **[KV]**: `i ∈ xorSum D ↔ Odd (D.filter (i ∈ ·)).card` — membership in an F2 (XOR) sum of a finset-of-finsets equals odd incidence count. Proved by `Finset.induction_on`.
- `xorSum_eq_empty_iff` **[KV]**: `xorSum D = ∅ ↔ ∀ i : ι, ¬ Odd (D.filter (i ∈ ·)).card` — an F2 sum vanishes iff every incidence count is even.

**Primal grammar:**
- `Adj` **[def]**: `Adj 𝒞 u v := u ≠ v ∧ ∃ T ∈ 𝒞, u ∈ T ∧ v ∈ T` — primal adjacency: distinct co-hosted vertices.
- Decidable instance for `Adj` **[infra]**.
- `Adj.symm'` **[KV]**: `Adj 𝒞 u v → Adj 𝒞 v u`.
- `adj_or_eq_of_cohosted` **[KV]**: co-hosted vertices (both in some team `V ∈ 𝒞`) are adjacent or equal.
- `IsClique` **[def]**: `IsClique 𝒞 K := ∀ u ∈ K, ∀ v ∈ K, u ≠ v → Adj 𝒞 u v` — a clique of the primal graph.
- `Covered` **[def]**: `Covered 𝒞 K := ∃ T ∈ 𝒞, K ⊆ T` — a vertex set covered by a single team.
- `Conformal` **[def]**: `Conformal 𝒞 := ∀ K ⊆ coverU 𝒞, IsClique 𝒞 K → Covered 𝒞 K` — every clique inside the cover is covered.
- Decidable instances for `IsClique`, `Covered`, `Conformal` **[infra]**.
- `mem_coverU` **[KV]**: `v ∈ coverU 𝒞 ↔ ∃ T ∈ 𝒞, v ∈ T`.
- `covered_of_card_le_two` **[KV]**: small cliques (card ≤ 2: empty set with nonempty cover, singletons, edges) are automatically covered.

**The clique datum:**
- `erase_union_erase` **[infra]** (private): `K.erase i ∪ K.erase j = K` for `i ≠ j`.
- `clean_system_of_uncovered_clique` **[KV]** — **THE CLIQUE DATUM**. Given a nonempty, non-conformal cover `𝒞`, produces a nonempty finset-of-finsets `𝒲` of nonempty sets, each hosted by some team of `𝒞`, pairwise-distinct under any single-team hosting (the "clean system" condition: `∀ V ∈ 𝒞, ∀ w₁ w₂ ∈ 𝒲, w₁ ⊆ V → w₂ ⊆ V → w₁ = w₂`), with `xorSum 𝒲 = ∅`. Proof: extracts a cardinality-minimal non-covered clique `K` (via `Finset.exists_min_image`), shows `K.card ≥ 3`, shows every erase-set `K.erase s` is covered by minimality, and splits on parity of `K.card`: even case constructs `𝒲 = {K.erase i, K.erase j, {i,j}}` for two distinct `i,j ∈ K` via the three-fold symmetric-difference identity; odd case constructs `𝒲 = K.image (fun s => K.erase s)` (all erase-sets), with the odd-incidence-count computation discharged via `Finset.card_image_of_injOn` and `Nat.odd_iff` plus `omega`.

**The one-step GYO collapse:**
- `shared` **[def]**: `shared 𝒞 := (coverU 𝒞).filter (fun v => 1 < (𝒞.filter (v ∈ ·)).card)` — the shared vertices of a cover (in ≥ 2 teams).
- `mem_shared` **[KV]**: `v ∈ shared 𝒞 ↔ ∃ T T' ∈ 𝒞, T ≠ T' ∧ v ∈ T ∧ v ∈ T'`.
- `bndry_eq_inter_shared` **[KV]**: `T ∩ coverU (𝒞.erase T) = T ∩ shared 𝒞` for `T ∈ 𝒞` — a team's boundary equals its intersection with the shared vertices.
- `isEarOf_of_simplicial` **[KV]** — **THE ONE-STEP GYO COLLAPSE**. In a conformal cover, a simplicial shared vertex `v` (i.e. `v ∈ shared 𝒞` such that any two of its `Adj`-neighbors within `shared 𝒞` are themselves adjacent) yields an ear: `∃ T ∈ 𝒞, IsEarOf 𝒞 T`. Proof: the closed shared neighborhood of `v` is a clique `K`, conformality covers it by some `T₀`; `v` shared implies a second team `T ≠ T₀` containing `v`; every boundary vertex of `T` lies in `K` and hence in `T₀`.

**Chain extraction and transfer:**
- `exists_earFree_core_chain` **[KV]** — **CHAIN EXTRACTION**. A non-Graham-reducible cover `𝒞` has an ear-free core `𝒞' ⊆ 𝒞` such that any vertex set inside the core's cover, hosted anywhere in `𝒞`, is hosted inside `𝒞'`. Proved by `Finset.strongInductionOn` on `𝒞`.
- `capstone_of_core` **[KV]** — **THE TRANSFER**. A clean system on the chained ear-free core `𝒞'` (given `𝒞' ⊆ 𝒞` and the chain property) is a clean system on the full cover `𝒞`, producing the final `∃ fam : List (LocalStruct ι (fun _ => ZMod 2)), fam.map (·.team) = 𝒞.toList ∧ Consistent fam ∧ (∀ L ∈ fam, L.rel.Nonempty) ∧ ¬ Glues fam` obstruction shape, consuming the (externally banked, imported) `clean_system_obstruction`. Requires `[Fintype ι]`.

**The chordless-cycle datum:**
- `IsChordlessCycle` **[def]**: a list `l` is a chordless cycle in `𝒞` iff it is duplicate-free, has length ≥ 4, every cyclically-consecutive pair is hosted by some team, and the only `Adj`-adjacencies among its members are the cyclically-consecutive ones (formalized via index arithmetic mod `l.length`).
- `clean_of_chordlessCycle` **[KV]** — **CHORDLESSNESS IS CLEANLINESS**. No team hosts two distinct pairs of a chordless cycle. Proof is a substantial case analysis: for two hosted cycle-pairs at list-positions `a` and `b`, uses `adj_or_eq_of_cohosted` on the endpoints, then a trichotomy on the resulting adjacency/equality possibilities, chased through `mod_succ_cases` atom-equations and `omega`.
- `obstruction_of_chordlessCycle` **[KV]**: the chordless-cycle rung of the converse, consuming the externally-imported `cycle_obstruction` with the cleanliness fact just proved. Requires `[Fintype ι]`.
- `clean_system_of_chordlessCycle` **[KV]**: the clique-datum-shaped packaging of a chordless cycle — same four-part clean-system conclusion as `clean_system_of_uncovered_clique`, built from `(cyclePairs l).toFinset`.
- `capstone_of_dichotomy` **[KV]** — **THE CAPSTONE, MODULO THE DICHOTOMY**. Given `¬ GrahamReducible 𝒞` and, for every ear-free core `𝒞' ⊆ 𝒞`, the dichotomy `¬ Conformal 𝒞' ∨ ∃ l, IsChordlessCycle 𝒞' l` (supplied as a hypothesis `hdi`, NOT yet proved in this file — the dichotomy hypothesis is what `Dirac.lean` later discharges), produces the full obstruction: a pairwise-consistent family of nonempty local relations over `𝒞.toList` that does not glue. Requires `[Fintype ι]`.

### `Dirac.lean`

**Header docstring claims [STANCE]:**
- "The final leg of the Vorob'ev converse (CYCLIC_CONVERSE_URS D27)." Over the primal graph, with the global hypothesis of no chordless cycle, every nonempty vertex set has a simplicial vertex (`dirac_simplicial` — note: the docstring names this `dirac_simplicial`, but the theorem actually compiled and appearing in the file is named `dirac_strong`; see Cross-tree/divergence notes).
- "The proof is the classical minimal-separator argument, run entirely over the fixed primal graph so that the induction only shrinks a `Finset` of vertices."
- Consequences named in the docstring: `earFree_dichotomy`, the capstone `exists_consistent_not_glues_of_not_acyclic`, and the headline `acyclic_iff_forall_consistent_glues`, "closing the discrete Vorob'ev programme: a cover is acyclic exactly when pairwise consistency forces gluing."

**Walks, paths, reachability:**
- `IsWalkOn` **[def]**: `IsWalkOn 𝒞 P p := List.IsChain (Adj 𝒞) p ∧ ∀ v ∈ p, P v` — a walk constrained to a vertex-predicate `P`.
- `ReachOn` **[def]**: `ReachOn 𝒞 P u v := ∃ p, IsWalkOn 𝒞 P p ∧ p.Nodup ∧ p.head? = some u ∧ p.getLast? = some v` — reachability within `P` via a duplicate-free walk.
- `isChain_take`, `isChain_drop` **[infra]** (private): `List.IsChain` is preserved under `take`/`drop`.
- `reachOn_of_walk` **[KV]**: every chained walk contains a duplicate-free path (i.e. `ReachOn`) with the same endpoints and constrained vertices — proved by strong induction on path length, splicing out duplicate-position pairs.

**Reachability combinators [KV], all straightforward from the above:**
- `reachOn_refl`, `reachOn_symm`, `reachOn_trans`, `reachOn_extend` (extending a reach by one adjacent, `P`-satisfying vertex), `reachOn_of_mem_walk` (every vertex on a walk is reachable from its head).

**Minimal connectors:**
- `exists_min_path` **[infra]** (private): existence of a length-minimizer among paths satisfying a predicate `Q`, via `Nat.sInf`.
- `exists_connector` **[infra]** (private): **A connector** — given `x ≠ y`, `x` adjacent to some `u₁`, `y` adjacent to some `u₂`, `u₁` reaching `u₂` within `Q`, and `x, y ∉ Q`, produces a duplicate-free `x`-`y` path whose interior lies in `Q`.
- `no_chord_of_minimal` **[infra]** (private) — **MINIMALITY KILLS CHORDS**: a length-minimal constrained `x`-`y` path has no `Adj`-edge between positions at list-distance ≥ 2.

**The separator is a clique — the central technical lemma:**
- `head_getElem`, `getLast_getElem` **[infra]** (private): positional (`getElem`) restatements of `head?`/`getLast?`.
- `sep_clique_step` **[KV]** (private) — **THE ASSEMBLED-CYCLE CONTRADICTION**. Under `set_option maxHeartbeats 1000000`: two length-minimal `x`-`y` connectors through disjoint, mutually non-adjacent sides `QA`, `QB` cannot coexist with global chordless-cycle-freeness when `x` and `y` are non-adjacent. This is the lemma that assembles the two connectors into a single cycle `c := pA ++ intB` (the reversed `B`-interior appended to the full `A`-connector), shows it is nodup, length ≥ 4, and consecutively adjacent (including the wrap edge), then derives a contradiction from the assumed non-chordlessness by chasing the forced chord through four zones (within-`A`, within-`B`, `A`-`x`-endpoint, `A`-`y`-endpoint cases) using `no_chord_of_minimal` on both sides plus the cross-side non-adjacency `hABnadj`.
- `gcast_list` **[infra]** (private): a generic index-cast helper for `getElem` under `s = t`.

**Minimal separators have neighbors on both sides:**
- `erase_separates` **[KV]** (private) — if vertex `x` has no `A`-reachable neighbor, then `Sep.erase x` still separates `a` from `b`: proved via a first-`x`-occurrence-on-the-violating-path argument.

**Dirac's lemma:**
- `SimpIn` **[def]**: `SimpIn 𝒞 S v := v ∈ S ∧ ∀ x ∈ S, ∀ y ∈ S, Adj 𝒞 v x → Adj 𝒞 v y → x ≠ y → Adj 𝒞 x y` — `v` is simplicial within vertex set `S`.
- `dirac_strong` **[KV]** — **DIRAC'S LEMMA, STRONG FORM**. Under `set_option maxHeartbeats 1600000`: in a chordless-cycle-free adjacency structure, every finite vertex set `S` either is complete (`∀ x y ∈ S, x ≠ y → Adj 𝒞 x y`), or contains two distinct, non-adjacent, simplicial-in-`S` vertices. Proved by `Finset.strongInduction`: takes a non-adjacent pair `a, b ∈ S`; extracts `Sep`, a card-minimal `(a,b)`-separator inside `S \ {a,b}` (via `Nat.sInf_mem` over the set of separator cardinalities); defines the reach-sets `A`, `B` of `a`, `b` within `S \ Sep`; shows `A ∩ B = ∅` and no `A`-`B` adjacency; shows every separator vertex has neighbors in both `A` and `B` (via `erase_separates`, contraposed against minimality); shows `Sep` is a clique (`hSepClq`, via `sep_clique_step`); then applies the induction hypothesis to the strictly smaller sets `A ∪ Sep` and `B ∪ Sep` (strictly smaller because `b ∉ A ∪ Sep`, `a ∉ B ∪ Sep`), lifting a simplicial vertex from each side back up to `S` via a `SimpIn`-lifting argument (`extract`, `hlift`, `hnbr`).

**The dichotomy and the capstone:**
- `shared_nonempty_of_earFree` **[KV]**: an ear-free cover has a nonempty `shared` set — every team has nonempty boundary.
- `earFree_dichotomy` **[KV]** — **THE EAR-FREE DICHOTOMY**. An ear-free cover is non-conformal or contains a chordless cycle: `¬ Conformal 𝒞 ∨ ∃ l, IsChordlessCycle 𝒞 l`. Proof: by contradiction, assumes conformal and no chordless cycle, applies `dirac_strong` to `shared 𝒞`, gets either a complete `shared 𝒞` or two non-adjacent simplicial vertices, and in either branch produces a simplicial shared vertex, which `isEarOf_of_simplicial` (from `VorobevConverse.lean`) turns into an ear, contradicting ear-freeness.
- `exists_consistent_not_glues_of_not_acyclic` **[KV]** — **THE CAPSTONE, unconditional**. For `¬ Acyclic 𝒞` (with `[Fintype ι]`), produces the full obstruction family. Assembled by feeding `earFree_dichotomy` (now proved, no longer a hypothesis) into `capstone_of_dichotomy` from `VorobevConverse.lean`, discharging that theorem's `hdi` hypothesis and its `¬ GrahamReducible` hypothesis via the (externally banked) `acyclic_iff_grahamReducible`.
- `acyclic_iff_forall_consistent_glues` **[KV]** — **THE HEADLINE / THE DISCRETE VOROB'EV THEOREM**. `Acyclic 𝒞 ↔ ∀ fam, (team-list matches ∧ Consistent fam ∧ nonempty rels) → Glues fam`. Forward direction via the (externally banked) `glues_of_acyclic`; converse via the just-proved capstone, by contraposition.

---

## Citations

Every named external work, verbatim as it appears in the mined files, organized by the claim it supports. Per the carrier's rule, no citation is fabricated or completed beyond what is literally written; where the file omits a formal identifier, that omission is preserved rather than filled in.

### Supporting the resolution of Q-CLASSICAL (whether the ZMod-2 affine witness class is complete for the capstone)

> "Q-CLASSICAL: RESOLVED by import (Atserias-Kolaitis, arXiv:2312.02023, generalizing BFMY 1983): the classical cyclic witnesses are TSEITIN GADGETS — congruence constraints ≡ 0 mod d on all teams, ≡ 1 on one, contradiction by summing: OUR ENGINE at modulus d. Their reduction: every non-acyclic hypergraph safe-deletes to an induced-reduced C_k (non-chordality, k ≥ 4) or H_k = all (k−1)-subsets of k vertices (non-conformality, k ≥ 3; H₃ = C₃), and counterexamples LIFT back through vertex-pinning (= our dite-splice) and covered-edge marginals (= our replication). Their mod-d domains serve arbitrary-monoid uniformity, not Boolean necessity." — `CYCLIC_CONVERSE_URS.md`, line 469.

**Citation as given, verbatim identifiers:** authors "Atserias-Kolaitis" (hyphenated form as written, no first names given in-file), arXiv id `2312.02023`, no title given, no venue/DOI given, no year given for the Atserias-Kolaitis paper itself (only that it "generalizes" the separately-referenced "BFMY 1983"). This is the sole citation in the mined slice carrying a resolvable external identifier (an arXiv id).

### Supporting the classical antecedent named "BFMY" (the acyclicity-gluing/join-consistency converse this whole file formalizes a discrete skeleton of)

Multiple bare mentions, no full citation ever given in the mined files (no author list beyond the acronym, no title, no venue, no id):

> "(iii) alphabet growth (the classical BFMY fallback) only if the whole linear game dies." — `CYCLIC_CONVERSE_URS.md`, line 68.

> "This is a genuinely paper-grade combinatorial lemma (the hard kernel of the classical BFMY converse, sharpened to the affine witness class); it gets its own tick, not a rushed proof." — `CYCLIC_CONVERSE_URS.md`, line 395–396.

> "(Q-CLASSICAL) what witness class does the classical BFMY converse construction use — and if its domains grow beyond {0,1}, is that evidence the affine class cannot be complete, so D23-as-stated is FALSE and the ladder needs an ALPHABET rung, not a proof?" — `CYCLIC_CONVERSE_URS.md`, line 439–441.

> "| Q-CLASSICAL | the BFMY converse witness uses domains beyond {0,1} or non-affine relations | UNKNOWN — if affine-expressible, evidence FOR D23; if not, evidence the ladder needs an alphabet rung |" — `CYCLIC_CONVERSE_URS.md`, line 464.

> "Q-CLASSICAL: RESOLVED by import (Atserias-Kolaitis, arXiv:2312.02023, generalizing BFMY 1983): ..." — `CYCLIC_CONVERSE_URS.md`, line 469 (repeated from above; the phrase "generalizing BFMY 1983" is the only year ever attached to BFMY anywhere in the mined slice).

**Agent-axis note on this citation:** "BFMY" is not expanded anywhere in the three mined files (no author surnames beyond the acronym, e.g. no "Beeri, Fagin, Maier, Yannakakis" spelled out in-text). The acronym is standard in the database-theory/hypergraph literature for the paper on acyclic database schemes usually cited as Beeri, Fagin, Maier, Yannakakis (1983), "On the Desirability of Acyclic Database Schemes" — but this expansion does NOT appear literally in any mined file, so per the carrier's anti-fabrication rule I do not assert it as the file's citation; I record only that the file writes "BFMY 1983" and "BFMY" with no further identifying detail, and flag the gap explicitly under Agent-axis ignorance below.

### Supporting the "single named classical obligation absent from Mathlib" claim (Dirac's lemma)

No external citation given for Dirac's lemma itself in either Lean file or the URS — it is referred to throughout purely by the name "Dirac" / "Dirac's lemma" / "dirac_strong", with no author-year-title reference to the graph-theory literature (e.g., no citation to Dirac's original chordal-graph paper). The URS's own docstring-adjacent commentary states only:

> "**STATEMENT** (chosen for zero-friction consumption): over the FIXED primal graph of 𝒞 ... **(DIRAC) a finite nonempty graph with no chordless cycle of length ≥ 4 has a simplicial vertex**" — `VorobevConverse.lean` docstring for `capstone_of_dichotomy` (line 587–588) and `CYCLIC_CONVERSE_URS.md` D27 (line 613–615).

This is treated in the mined material as a "classical" / "floor" result (see Literature-audit verdicts below) rather than as a citation with a resolvable external identifier.

### No other named external works

A full grep for `arxiv|doi|et al` (case-insensitive) across `CYCLIC_CONVERSE_URS.md` returned exactly two hits: the word "constraints" (false-positive substring match on nothing relevant, actually matched on the unrelated word "constraints" containing no citation content — recorded for transparency of method) and the Atserias-Kolaitis line already transcribed above. No `arxiv|doi|et al` strings appear at all in `VorobevConverse.lean` or `Dirac.lean`. No other author-year bracketed citations (`[Name, Year]` style) appear anywhere in the three files.

---

## Literature-audit verdicts

Per the carrier's instruction, every literature-audit verdict (novelty, no-ancestor, boundary/Pl-kill claim) with its source location and the exact scope of search claimed.

### Mathlib floor: no chordality theory

**[PROBE]** — "Mathlib has NO chordality theory (floored: zero names)." — `VorobevConverse.lean` docstring for `capstone_of_dichotomy`, and independently at `CYCLIC_CONVERSE_URS.md` line 590: "Mathlib has NO chordality theory (floored: zero names)."

**Scope of search claimed:** the phrase "floored: zero names" is the entirety of the scope statement given — no further detail (which Mathlib version, what search method — grep, `loogle`, `exact?`, manual browsing — or what search terms) is recorded in either file. This is a bare zero-result assertion, not a documented search protocol.

**Corroborating detail from the same block:** "Alternatives audited and rejected: MCS-correctness (needs the same path-lemma), single-vertex-removal induction (the classic pitfall: does not induct), direct everywhere-non-simplicial ⟹ chordless-cycle (IS Dirac's contrapositive), clique-tree route (circular). The separator proof is the floor." — `CYCLIC_CONVERSE_URS.md`, D27, line 608–611. This documents a design-space audit of *proof strategies* (four named alternatives, each rejected with a one-clause reason), separate from the Mathlib-coverage claim.

### Mathlib pin correction: `Chain'` → `List.IsChain`

**[PROBE]/[decide]-adjacent, a build-environment fact recorded as a "grammar correction":** "D27 named `chain'_append` / `chain'_iff_getElem`; this Mathlib pin (fabf563a) renamed the API to `List.IsChain`. Floored via regex before writing: `isChain_iff_getElem`, `isChain_append` (seam `∀ x ∈ l₁.getLast?, ∀ y ∈ l₂.head?`), `isChain_reverse`, `isChain_pair`, `IsChain.imp`." — `CYCLIC_CONVERSE_URS.md`, line 669–672. This records a specific Mathlib commit hash (`fabf563a`) as the pin at which the rename occurred, and states the correction method used ("floored via regex before writing") — this is closer to a build/engineering verification than a literature-novelty claim, but is recorded here as it is the only instance in the slice of a literal search-scope statement with a concrete artifact (a commit hash) attached.

### Novelty/significance assessment, the closing η-line

**[STANCE]**, self-assessed, not a search-scoped claim: "η (validated novelty per effort): HIGH. The programme's single remaining lemma is closed; the discrete Vorob'ev converse — the discrete skeleton of the HC gluing question — is now a theorem with a checkable axiom profile." — `CYCLIC_CONVERSE_URS.md`, line 701–703. No external comparison set is named for this HIGH rating; it is an internal effort/novelty self-report, not a literature-search verdict, and is tagged STANCE rather than PROBE for that reason.

### "No ancestor" / boundary-style claims

None found. The mined slice contains no explicit "appears in no examined work," "no-ancestor," or "boundary/Pl-kill" phrasing of the kind the carrier flags as the load-bearing PROBE category — the closest analogues are the two Mathlib-floor statements above (zero names in Mathlib) and the Q-CLASSICAL resolution (which is a *positive* ancestor-found result: the classical construction WAS located, via the Atserias-Kolaitis import, and shown to be an instance of the file's own engine at modulus d — this is the inverse of a no-ancestor verdict).

---

## Cross-tree / divergence notes

Discrepancies, naming mismatches, and internal-consistency observations across the three files, reported per the carrier's instruction that "duplication or contradiction" is itself content.

1. **Docstring names `dirac_simplicial`; the compiled theorem is `dirac_strong`.** `Dirac.lean`'s file-level docstring (line 13) reads: "every nonempty vertex set has a SIMPLICIAL vertex (`dirac_simplicial`)." No declaration named `dirac_simplicial` exists anywhere in the 1116-line file I read in full; the actual theorem discharging this role is `dirac_strong` (line 804), whose statement is the *strong* disjunctive form (complete-or-two-nonadjacent-simplicial), not a bare existence-of-one-simplicial-vertex statement. This is a docstring/code naming drift — either the docstring was written against an earlier planned name that was refactored away, or it is a loose gloss. Flagged, not resolved (per the carrier: "If a docstring claims a result the Lean does not obviously state, flag it").

2. **`VorobevConverse.lean`'s `capstone_of_dichotomy` takes the dichotomy as a HYPOTHESIS (`hdi`); `Dirac.lean` later proves that hypothesis as a THEOREM (`earFree_dichotomy`) and discharges it.** This is not a contradiction but a deliberate two-stage architecture explicitly narrated by the URS: `VorobevConverse.lean`'s docstring even says "The assembly (`capstone_of_core`)... " and its final theorem is captioned "**The capstone, modulo the dichotomy**" (line 571), i.e. the file's own docstring flags its own incompleteness. `CYCLIC_CONVERSE_URS.md`'s "Verdicts, round 5" section states this explicitly: "**The one-shot verdict, honest:** NOT complete — one lemma stands." (line 584). Recorded here as a cross-file structural dependency, correctly self-documented in both files and in the ledger — no divergence in substance, only noted because it is exactly the kind of "awaiting an input" relationship the carrier asks to be made explicit.

3. **Ledger self-corrections recorded as kills, not hidden.** The URS's own internal history shows three (later stated as four, see below) rounds of conjecture-then-refutation before the final architecture: "D3 (KILL 1 — team-parity DBC refuted in-model)" (line 29), "D5 (KILL 2 — the two-move disjunction refuted in-model)" (line 42), "D9 (A4 ALARM — ♠ as swept is VACUOUS)" (line 110, a self-caught methodological error rather than a mathematical refutation), and "D17 (KILL 3 — HeartB and the boundary-parity engine are FALSE; found by construction)" (line 319). The text at line 435–464 (D24) explicitly frames a fourth possible kill ("kill #4") as a live open question before resolving it via the Atserias-Kolaitis import at D25. This is recorded as internal ledger content, not as a divergence between files, but is flagged here because a naive reading of only the two Lean files (which show only the final GREEN, 0-sorry state) would miss that the underlying mathematical claim ♠ / team-parity-DBC / the two-move-disjunction / HeartB were each conjectured, tested, and REJECTED before the surviving construction (the affine engine consuming `ClosedAt`/`CoherentAt`/hosted-odd-dependency data) was found. The two Lean files show no trace of the rejected constructions — they are pure end-state.

4. **"D23-as-stated is neither proved nor refuted: BYPASSED"** — `CYCLIC_CONVERSE_URS.md`, D25 point 5 (line 497–500). This is an explicit non-closure of a named conjecture (C-ENGINE / D23, "the boundary-privacy/blocked-vs-landing decomposition") — the ledger states plainly that the frame itself ("the blocked/landing decomposition") was "the wrong frame" and that the eventual proof route (chordal-vs-conformal, consuming Dirac) supersedes it rather than resolving it on its own terms. This is recorded verbatim because it is exactly the kind of "claim not actually closed, but superseded" event the carrier's A4-honesty instruction asks to be surfaced rather than smoothed over.

5. **No discrepancy found between the URS's D26/D27 derivation plans and the actually-compiled Lean.** Cross-checking the D26 block (line 513–563, all seven "L1"–"L8" derivation links) against the actual declarations in `VorobevConverse.lean` and `Dirac.lean`: every named link (`mem_xorSum`=L1, the primal grammar=L2, `clean_system_of_uncovered_clique`=L3, `isEarOf_of_simplicial`=L4, `clean_of_chordlessCycle`=L5, Dirac=L6, `exists_earFree_core_chain`=L7, the assembly=L8) has a corresponding compiled declaration with a matching name or an explicitly-noted name substitution (see item 6 below). The "Verdicts, round 5" section (line 565–603) and "D27 CLOSURE" section (line 648–706) both narrate this correspondence explicitly and note exactly one grammar-level naming drift (`Chain'` → `List.IsChain`, see Literature-audit verdicts above) and one simplification that "HELD" (the assembled-cycle segment count collapsing from a planned four segments to two: `c := pA ++ intB` rather than `x·intA·y·rev(intB)` — `CYCLIC_CONVERSE_URS.md` line 678–685). I independently confirm this in the Lean source: `Dirac.lean` line 498, `set c : List ι := pA ++ intB with hc`, matches the ledger's description exactly.

6. **Two-part naming: `sep_clique_step` vs. the URS's "Sep-clique" language.** The URS refers to the technical crux generically as "Sep is a clique" / "CLAIM (Sep is a clique)" (`CYCLIC_CONVERSE_URS.md` line 623). The compiled Lean names the assembled-cycle-contradiction lemma `sep_clique_step` (private, `Dirac.lean` line 404) and the top-level clique fact `hSepClq` (a local `have` inside `dirac_strong`, `Dirac.lean` line 913). No divergence — the URS's prose name maps cleanly onto two Lean artifacts (an exported-shape private lemma plus a local proof-term), consistent with the D27 audit's own description of the proof shape.

---

## Agent-axis ignorance (Γ)

Per the carrier: "Files or sections you could not fully parse, citations you could not resolve, claims that read as circular or that you could not map to a theorem, cross-references you could not follow, duplication or contradiction you noticed."

1. **"BFMY" never expanded in-file.** As recorded under Citations, "BFMY" (used at least five times across the URS) is never spelled out to author names in any of the three mined files. I know from general domain knowledge that this acronym conventionally refers to Beeri–Fagin–Maier–Yannakakis (1983) in the database-theory/acyclic-hypergraph literature, but per the carrier's explicit instruction ("Never fabricate a citation... If an identifier is absent, write 'no id given'") I have NOT written that expansion into the Citations section as if it were textually present — I only report the acronym and year fragment ("BFMY 1983") exactly as written, and flag the expansion as something I could not verify was intended by the author versus something I am supplying from outside knowledge. This is a genuine boundary case: is completing "BFMY" to its standard database-theory expansion an act of `act(search)` (reliable, permitted) or `act(imagine)` (gated, forbidden) under the carrier's operator taxonomy? I have treated it as closer to imagine-risk and left it unexpanded in the object-axis Citations section, reporting the ambiguity here instead.

2. **The Atserias–Kolaitis paper's title, venue, and full author list are not given in-file.** Only surname pair, arXiv id, and the relational claim ("generalizing BFMY 1983") are present. I did not attempt to independently resolve the arXiv id against external sources (no web search was performed — this is a pure-extraction mining task per the carrier's `act(search)` = "note every citation... exactly as written," not an act of literature verification, which is a distinct downstream task per the available `verify-citations` skill, not invoked here since it was not requested and the carrier scopes this run to extraction). Flagged as an unresolved-but-not-fabricated identifier.

3. **`clean_system_obstruction`, `cycle_obstruction`, `glues_of_acyclic`, `acyclic_iff_grahamReducible`, `GrahamReducible`, `Acyclic`, `EarFree`, `IsEarOf`, `LocalStruct`, `Consistent`, `Glues`, `coverU`, `xorSum`, `xorSumL`, `xorSumL_eq_xorSum`, `cyclePairs`, `nodup_cyclePairs`, `xorSumL_cyclePairs`, `cyclePairs_ne_empty`, `length_cyclePairs`, `getElem_cyclePairs`, `mod_succ_cases` are all IMPORTED/consumed by my two Lean files but not DEFINED in them.** `VorobevConverse.lean` imports `ZPM.Measurements.HC.CyclicConverse`, and its content plainly builds on prior barrel layers (the URS itself narrates these as "banked" in earlier ticks: `HC/AffineEngine.lean` as the "seventeenth barrel layer" and `HC/CyclicConverse.lean` as the "eighteenth layer," both referenced but neither assigned to my slice). I record every name I could not resolve to a definition within my three files, per the carrier's instruction to report "cross-references you could not follow." These are not files I was asked to mine, so this is expected structural incompleteness of MY slice rather than a defect in the corpus — but I flag it explicitly rather than silently treating imported names as self-evident. `coverageComplete` for MY assigned slice is still true (I read every line of my three files); this note is about the corpus's larger dependency graph extending beyond my slice, which the carrier's cross-miner fan presumably covers elsewhere.

4. **I could not independently verify the Lean proofs compile** (no kernel access invoked by me in this mining task — I did not run `lake build` or any Lean tooling). Per the carrier: "The mathematics is kernel-verified. Your job is not to re-verify or doubt it." I have taken every `theorem`/`lemma` in the two `.lean` files as [KV] on the strength of this instruction plus the URS's own repeated "GREEN, 0 sorry" self-reports (e.g. `CYCLIC_CONVERSE_URS.md` line 567: "GREEN: 588 lines, 0 sorry, axioms propext/Classical.choice/Quot.sound. Six compile rounds," and line 649–651 for `Dirac.lean`: "GREEN + installed, barrel at TWENTY layers, 1115 lines, 24 declarations, 0 sorry, axioms `[propext, Classical.choice, Quot.sound]` only (decide-free proof; no `native_decide`)"). I did not myself run a `sorry`/`axiom`-grep over the files as an independent check; I note this as a methodological limit of my mining pass, though it is consistent with the carrier's explicit instruction not to re-verify.

   **Partial self-check performed:** I did do a `grep` for "Mathlib" and "floor" mentions across both Lean files as part of citation-hunting (reported above), which incidentally would have surfaced a `sorry` or `axiom` keyword had grep been run for those terms — it was not, so this is not a substitute verification, only a note that my greps happened to touch the full text of both files without incident.

5. **`24 declarations` claimed for `Dirac.lean` (line 649) — I did not independently count.** The URS states "1115 lines, 24 declarations" for `Dirac.lean`. I read and tagged every `theorem`/`lemma`/`def` I encountered in my full read of the file (listed in full above) but did not perform a separate mechanical count against this figure to confirm exactly 24. This is recorded as an unverified [PROBE]-adjacent numeric claim from the file itself, not independently cross-checked by me.

6. **No divergence found between my two Lean files and each other or the URS beyond what is listed above** — this is a completeness statement about MY search, not a claim that no further divergence exists in the wider corpus (which extends to files outside my slice, per item 3).

7. **The carrier's own instruction to route unstated regularities to Γ as UK, never promoted to findings, was followed** — I noticed, but do not report as a finding, that the overall shape of the ledger (repeated conjecture → adversarial sweep/probe → kill-or-hold → structural expansion) recurs as a pattern across all seven "derivation blocks." I flag this once, here, as an UK-level pattern-noticing on my own part (per the carrier's explicit allowance: "record it once as UK on the agent axis (Γ), explicitly flagged as conjecture. Never promote it to a finding") and do not elevate it into the Theorems/Citations/Verdicts sections above.

**Coverage statement:** I read all three assigned files end to end, with no line ranges skipped. The one harness-level truncation (on `Dirac.lean`, first Read call, lines 1–856 of 1116) was fully remediated by a second Read call at offset 857 covering the remainder (857–1116) in the same turn, before any analysis was written. `coverageComplete = true`.
