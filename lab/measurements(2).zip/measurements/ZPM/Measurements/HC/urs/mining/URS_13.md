# URS_13 — Field-level docs and cross-tree divergence audit

Miner: Sonnet 13. Slice: Theory.md (v0.2 field note), FOUNDATIONS.md (puremath-only
meta-mathematical analysis), FOL/Amalgamation.lean (both trees), FOL/NOOLOGY_URS.md
(both trees), plus a full cross-tree file-presence audit of `ZPM/Measurements/HC/`.

Object axis (γ) and agent axis (Γ) are kept separate throughout, per the carrier.
Every claim is tagged **[KV]** / **[decide]** / **[CONJ]** / **[PROBE]** / **[STANCE]**
/ **[DEF]** / **[infra]** exactly as it appears in source; no tag is upgraded.

---

## Files mined

1. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/Theory.md`
   — read end to end, 571 lines (12 numbered sections + ledger + closing sentence).
2. `/Users/polaris/Documents/Epistemology and Zetesis/Projects/zetesis-puremath/ZPM/Measurements/HC/FOUNDATIONS.md`
   — read end to end, 303 lines (11 numbered sections, §9–11 are the confirmed-CONJ
   verification and the thesis statement).
3. `/Users/polaris/Documents/Epistemology and Zetesis/Projects/zetesis-puremath/ZPM/Measurements/HC/FOL/Amalgamation.lean`
   — read end to end, 161 lines. Puremath version.
4. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/FOL/Amalgamation.lean`
   — read end to end, 139 lines. Design-lab version, read for the diff task.
5. `/Users/polaris/Documents/Epistemology and Zetesis/Projects/zetesis-puremath/ZPM/Measurements/HC/FOL/NOOLOGY_URS.md`
   — read end to end, 209 lines. Puremath version.
6. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/FOL/NOOLOGY_URS.md`
   — read end to end, 197 lines. Design-lab version, read for the diff task.

Additionally, for the divergence audit specifically requested by the slice, I ran
exhaustive `diff`/`comm` passes (not full reads, since these are outside the four
assigned files) over:
- `Theory.md` in both trees — confirmed **byte-identical** (found via `diff`, no
  output; both 570 `wc -l` lines).
- All nine files under `FOL/` common to both trees other than `Amalgamation.lean` and
  `NOOLOGY_URS.md` — confirmed **byte-identical** by `diff -q`
  (`FiveWayCI.lean`, `FiveWayInterpolation.lean`, `FiveWayStructural.lean`,
  `LegIVBridge.lean`, `Polish.lean`, `SupportDistributionSeparation.lean`,
  `TypeSpaceCompact.lean`, `TypeSpaceSeparation.lean`, `TypeSpaceTopology.lean`).
- All seven top-level `HC/` files common to both trees other than `Theory.md` —
  confirmed **byte-identical** (`Abstract.lean`, `Combinatorial.lean`, `Fibered.lean`,
  `FiberedInterpolation.lean`, `MutualInformation.lean`, `Spekkens.lean`).
- The full top-level file listing of `HC/` in both trees (`.lean` and `.md`), and the
  full listing of `ZPM/InformationTheory/` (note: **not** under `HC/`, corrected below)
  in both trees, via `find`/`comm` set-differencing.

---

## Theorems and definitions

### From `Theory.md` (the field note)

- **[def]** *Ignorance structure.* "a relation `κ ⊆ ∏ᵢ Xᵢ` over a finite index of
  sorts, with a distinguished partition into a shared interface `S` and private
  parts — the record of *which* joint configurations are admissible, prior to and
  independent of any weighting." (§2)
- **[def]** *Projections, rectangular hull, `hcComb`.* `πᵢ(κ)` = what the interface
  exposes of each part; `⊗κ = ∏ᵢ πᵢ(κ)` = the rectangular hull, "the maximal ignorance
  consistent with those exposures"; `hcComb(κ) = |⊗κ| − |κ|` grades the gap — "the
  configurations the marginals license that the joint excludes." (§2) Three
  characterizing adjectives given: **constructive** (finite cardinality, decidable,
  kernel-verifiable — against subjective plausibility and against entropy), **domain-
  free** (no valuation domain, no ordering, no ℝ), **distribution-free** (invariant
  across every probability measure supported on `κ`). (§2)
- **[KV]** *Central theorem (the five/six-way).* "the vanishing of this one number is
  simultaneously a combinatorial statement (κ is a rectangle), a logical statement
  (Craig interpolation holds across the interface), a model-theoretic statement
  (amalgamation), an information-theoretic statement (mutual information vanishes at
  the canonical measure), and a geometric statement (the fiber product surjects; a
  global section exists)." (§0) Witnesses named: `fiveWay_full`, `fiveWay_fol` (§1).
- **[KV]** *`hcComb_eq_zero_iff_isRect`* — the combinatorial layer, cross-recombination.
  (§3, propositional stack)
- **[KV]** *`fiveWay_uniform`* — the mutual-information leg via genuine measure theory,
  built on uniform measure via `PMF.uniformOfFinset`, "absolute continuity and finite KL
  discharged." (§3)
- **[KV]** *The oscillation theorem* — "proved from no axioms at all (not even
  choice)"; stated informally: "a trajectory of ignorance structures that ever
  exhibits a cross-domain discovery cannot have been factorable at every step — the
  obstruction must spike. Discovery has a conservation law, and `hcComb` is what it
  conserves against." (§3)
- **[KV]** *The FOL/type-space carrier.* `CompleteType T α` topologized by its clopen
  formula base, proved compact (Alexander subbase + the compactness theorem), totally
  separated, Polish, Borel — "the Stone-dual carrier on which the infinite theory
  lives." (§3)
- **[KV]** *`fiveWay_fol`* — the Set-based five-way over the type-space carrier. (§3)
- **[KV]** *Genuine type-reduct amalgamation at `St(S ⊕ A ⊕ B)`* — with real
  `L[[·]]`-sentence vocabularies. "the reverse direction (non-amalgamable ⟹ no shared
  interpolant: the first-order hidden channel) is unconditional and the forward
  direction is Beth-conditional — the precise, honest locus where first-order logic
  exacts its price." (§3)
- **[KV]** *`support_prod`* — "the support of a product measure is the product of
  supports — a general lemma absent from Mathlib." (§3)
- **[KV]** *`mi_zero_imp_rectangular_support`* — the one-way bridge. (§3)
- **[KV]** *The separation witness `Pcorr`* — mass 3/8 diagonal, 1/8 off-diagonal:
  rectangular support, non-product measure. "Support-level and distribution-level
  factorization are therefore separated in general and unified exactly at the
  canonical measure — the measure-theoretic form of the CHSH boundary." (§3)
- **[KV, partial]** *EMX/Kuratowski reverse direction closed.* "The reverse direction
  of the Ben-David–Hrubeš–Moran–Shpilka–Yehudayoff compression theorem (learnability
  undecidability, Nature MI 2019) is closed in Kuratowski form — a compression scheme
  forces the aleph bound; the forward direction is a documented axiom-of-choice seam."
  (§3)
- **[KV]** *The discrete local-to-global stack* (§3, the v0.2 headline arc):
  - `glues_of_acyclic` — "the positive half: a pairwise-consistent, duplicate-free
    family over an acyclic cover always glues (the order-free amalgamation theorem,
    run over a running-intersection order extracted from acyclicity)."
  - `acyclic_iff_grahamReducible` — "acyclicity is decidable: it coincides with
    Graham/GYO ear-reduction, so the hypothesis of the positive half is
    machine-checkable (`decide`, never `native_decide`)."
  - `affine_obstruction`, `clean_system_obstruction` — "the affine obstruction engine
    — an F₂-linear constraint system with per-team constants and a hosted odd
    dependency yields a consistent family of nonempty local relations that provably
    does not glue: the explicit non-splitting cocycle."
  - `exists_consistent_not_glues_of_not_acyclic` — "the converse, unconditional: every
    non-acyclic cover hosts such a family." Proof route stated: "reduces, via a
    chordal/conformal dichotomy (Atserias–Kolaitis) and a one-step GYO collapse, to a
    graph lemma — Dirac's lemma (`dirac_strong`: a chordless-cycle-free vertex set is
    a clique or holds two nonadjacent simplicial vertices), formalized here from first
    principles over a bespoke path grammar because Mathlib carries no chordality
    theory."
  - `acyclic_iff_forall_consistent_glues` — "the headline: a cover is acyclic exactly
    when pairwise consistency forces gluing. The Specker triangle (three 2-element
    teams closing a 3-cycle) is the minimal witness of the negative side, produced
    unconditionally by the engine — the smallest arity-3 amalgamation failure,
    kernel-checked."
  - **[infra]** All of the above: axioms `[propext, Classical.choice, Quot.sound]`,
    zero `sorry`. Characterized in the note as "the local-to-global obstruction of the
    field made constructive on the nerve — the discrete form of the flagship's
    H¹-side (§8)."
- **[def]** *The fibration frame (§4).* `F : measures ↦ supports`. The **fibre** over
  a support `κ` is the space of weightings of that shape (where Kolmogorov's
  probability theory and Cuzzolin's simplicial geometry of belief functions live). The
  **base** is the space of shapes; the field "equips it with" a geometry that is
  "topological and cohomological (Stone base, presheaf obstruction), not metric."
- **[KV]** *`hcComb(κ) = 0 ⟺ MI = 0` at the canonical measure* — stated as the exact
  and only place the two tines (weight-first vs shape-first) touch. (§4)
- **[CONJ]** *The canonical measure on infinite carriers* — "uniform on finite
  supports, conjecturally the generically-stable Keisler measure under NIP on infinite
  ones." (§4)
- **[STANCE]** *Formal identity: graded cylindric set algebras* (§5). "The variety of
  graded cylindric set algebras — the Henkin–Monk–Tarski signature (Booleans,
  cylindrifications, diagonals), enriched with one new primitive, a monotone grading
  `h` into a constructive ordered monoid, and one new law, the coherence `h(a) = 0 ⟺ a
  rectangular ⟺ interpolation ⟺ amalgamation ⟺ CI ⟺ fiber-product`." Explicitly framed
  as inheriting substrate + logic pair, contributing grading + cross-domain coherence.
- **[CONJ]** *Grading codomain open decision* — "ℕ for the bipartite case, a
  commutative monoid or semiring for multi-interface and higher arity, where the
  Atserias–Kolaitis monoid-consistency parameter (below) suggests the codomain and the
  support↔distribution knob may be the same dial." (§5)
- **[CONJ]** *The flagship: the cohomological-roots theorem* (§8, transcribed near-
  verbatim as it is the field's deepest claim): "Construct a cochain complex
  canonically attached to an ignorance structure `κ` such that (i) the factorization
  obstruction is a class in its cohomology `H•`, with `H• trivial ⟺ κ rectangular ⟺
  the five-way`; and (ii) `hcComb(κ)` is its degree-zero invariant — an Euler
  characteristic." Two named traps: **the degree-zero trap** (the trivial two-term
  inclusion-complex reading proves nothing, is "admissible only as explicitly-labeled
  scaffolding") and **the context trap** (`hcComb` is single-context; sheaf
  contextuality is multi-context; the flagship's complex is "not literally Abramsky's
  Ȟ¹" but a Čech complex of the row/column cover of the hull).
- **[KV]** *What v0.2 lands on the flagship (§8).* "The discrete gluing stack (§3)
  builds exactly the multi-context object the flagship needs ... and proves, in the
  kernel, the qualitative core of the intended H¹ statement: a global section exists
  for every consistent local family ⟺ the nerve is acyclic
  (`acyclic_iff_forall_consistent_glues`), with the obstruction, when acyclicity
  fails, an explicit non-splitting F₂ cocycle rather than a mere existence claim." Two
  things remain **[CONJ]**: **the counting identity `χ = hcComb`** (tying nerve
  acyclicity to the cardinality grading `|⊗κ| − |κ|`) and **the abelian complex** (the
  genuine cochain complex whose higher cohomology "casts the shadow" is "still to be
  constructed paper-first").
- **[STANCE]** *§9, the epistemic lens.* "The field did not begin as mathematics; it
  began as an ignorance question — when is a causal learner finished? — and the
  mathematics is what that question precipitated under formalization." `κ` = "structured
  ignorance itself"; hull = "the maximal ignorance the interface admits"; `hcComb`
  counts "the regularity present in the joint but unarticulable through the shared
  vocabulary — in the lens's terms, the unarticulated (UK) content trapped behind an
  interface, the exact pressure that forces grammar expansion." Explicit discipline
  clause: "the mathematics stands without it; the lens is not an axiom of the system...
  Each illuminates the other; neither leans."
- **[DEF]** *Standing non-claims (§10).* "No leverage on P vs NP (the
  feasible-interpolation route is a name collision, crypto-barriered; our own
  `PvNPInFrame` formalizes the collapse of the naive reframing — the field proves its
  own limits...). Quantum reach is to quantum advantage, not to classical separations.
  Subjective uncertainty calculi are corridors, never foundations."

### From `FOUNDATIONS.md` (puremath-only meta-mathematical analysis)

- **[DEF]** *Ignorance structure (restated with [DEF] tag explicit in-file).* "an
  ignorance structure is the set of co-admissible configurations over a structured
  domain — formally a relation `κ ⊆ ∏ᵢ Xᵢ` with a distinguished partition into a
  shared interface `S` and private parts." (§1)
  - The document's own status discipline (quoted verbatim, §0): "This is foundational
    design (`act(imagine)`), with Dhruv as the expert verifier. Three labels are used
    throughout: **[KV]** kernel-verified / established mathematics; **[DEF]** a
    definitional commitment we are choosing (not forced, but identity-fixing);
    **[CONJ]** a substrate-mapping conjecture to verify against the literature before
    banking. The constructivist constraint is standing: route through subjective
    frameworks (Halpern plausibility), never anchor in them."
- **[DEF]** *What kind of theory.* "A constructive, support-first theory of relational
  decomposition — not a measure theory... SIF inverts the primacy: the support (an
  order/logic object) is primary; the distribution is a secondary weighting." (§1)
- **[DEF]** *Axiom 1 — ignorance-as-admissibility.* "Ignorance is structured and
  generative, not a measure-theoretic lack. Its primary datum is co-possibility — a
  relation / an order / a consistent theory — which is a logical, not a
  measure-theoretic, object." (§2)
- **[KV]/[CONJ] split** — "There is a forgetful functor `F : IgnoranceStructures →
  ProbabilityStructures` that drops order-primacy and adds a weighting... The proven
  support↔distribution separation is exactly the statement that `F` is not faithful
  (rectangular support does not determine the measure; the canonical measure is the
  section that would invert it). **[KV]** (separation witness) / **[CONJ]** (the
  functor framing)." (§2) — Note the file itself annotates the exact split between
  what is kernel-verified (the separation witness) and what is conjectural framing
  (the functor language).
- **[DEF]** *Strong definition of an ignorance structure* (§3, formal box): fixed
  finite index set and base sorts `(Xᵢ)`; projection (cylindrification) operators
  `πⱼ`; rectangular hull `⊗κ = ∏ᵢ πᵢ(κ)`; factorization grading `h(κ) = |⊗κ| − |κ|`
  valued in a constructive ordered monoid (`ℕ`, or free commutative monoid for
  multi-interface); `κ` is factorable when `h(κ) = 0`. **Signature**: `⟨
  Boolean/relational base ; projections πⱼ ; hull ⊗ ; constructive grading h ⟩`.
- **[DEF]** *Why logic orders are first-class (§4).* "the carrier is an order, not a
  measure... interpolation says the shared vocabulary suffices to mediate the parts,
  amalgamation says local order-pieces agreeing on the interface glue to a global
  one. These are not corollaries that happen to hold; they are the object seen
  syntactically."
- **§5, candidate homes, each independently tagged:**
  - **[CONJ — strongest]** Abstract algebraic logic: cylindric & polyadic algebras
    (Henkin–Monk–Tarski). "SIF is then a constructively-graded fragment of
    cylindric-type algebra."
  - **[KV]** Sheaf/topos & monoid-consistency (Abramsky; Atserias–Kolaitis
    monoid-consistency).
  - **[KV]** Model theory (amalgamation, types, the FOL type-space lift).
  - **[KV]** Combinatorics/complexity (rectangle defect ↔ nonnegative rank ↔
    extension complexity, Yannakakis; marginal-problem ladder NP-hard→QMA).
  - **[KV]** Information theory (Gács–Körner support-shadow of MI).
- **§7, the axiom-addition question, answered in two parts:**
  - **"As a theory: no."** — `hcComb` + the five-way "are kernel-verified and
    definable in ZFC / finite combinatorics. Well-definedness is not in question.
    **[KV]**"
  - **"As an independent formal system: the move is a signature, not a new
    mathematical axiom."** Recommendation: promote `⟨ πⱼ , ⊗ , h ⟩` to a primitive
    algebraic signature, four laws: (1) **[KV import]** projection laws (cylindric
    closure/commuting); (2) **[KV]** hull law; (3) **[DEF — the new primitive]**
    grading law; (4) **[DEF]** coherence law — "the five-way as an axiom of the
    variety, not an instance theorem."
- **§9, the cylindric-placement verification — CONFIRMED (was CONJ, now established).**
  Four Q/A pairs, each independently verdicted (transcribed under Literature-audit
  verdicts below, since these are [PROBE]-grade audit results embedded in the
  document).
- **[STANCE]/[DEF]** *§10, the pinned formal system:* "the variety of graded
  cylindric set algebras" — signature enriched with exactly one new primitive `h : A
  → (constructive ordered monoid)`, monotone, with coherence law `h(a) = 0 ⟺ a is
  rectangular ⟺ interpolation ⟺ amalgamation ⟺ CI ⟺ fiber-product`.
- **[STANCE, labeled THESIS in-file]** *§11, the interpretation.* "Uncertainty is
  defined here geometrically, not measure-theoretically. The object of study is the
  possibility-structure ... and uncertainty is the cohomological obstruction to
  reconstructing the whole from its parts over a shared interface. `hcComb` is the
  magnitude of that obstruction: an integer invariant of a geometric object (an
  Euler-characteristic / Betti-number reading), whose roots are cohomological, not
  arithmetic." Named "the Kolmogorov-dual foundation": Kolmogorov works in the
  fibre, SIF works in the base; canonical measure is a section.
- **[CONJ]** *The cohomological-roots theorem, restated (§11, "= the Rosetta stone,
  reframed").* Construct `H•` on ignorance structures such that (i) the
  factorization obstruction is a class in `H•` (`H•` trivial ⟺ rectangular ⟺
  five-way), and (ii) `hcComb` is its degree-0 invariant/Euler characteristic. "this
  is the field's deepest and hardest claim; everything else is the scaffolding that
  makes it well-posed."
- **[KV]** *Status-discipline closing line of §11:* "the carrier-as-Stone-space and
  the obstruction-as-cohomology (contextuality side: Abramsky–Mansfield–Barbosa; CSP
  side: Ó Conghaile) are [KV]; `hcComb` as the Euler characteristic of a single
  unifying `H•` is [CONJ]; 'geometric foundation for uncertainty' is the
  thesis/stance this conjecture, if proved, establishes."
- **§11.1, the fibre-side sibling.** Cuzzolin's geometry of uncertainty characterized
  as **[KV program; complementarity interpretive]**: represents belief functions as
  points in `ℝ^(2^|Θ|−2)`, derives `R[b]` from orthogonality — "a real, developed
  geometric foundation for uncertainty — but it geometrizes the measure side: the
  simplex of belief functions = the fibre of `F`." Explicit discipline instruction
  (transcribed verbatim): "**Discipline (route through, never home — same rule as
  Halpern).** Dempster–Shafer belief functions are a credal/subjective framework...
  So: cite him as the fibre-side sibling, borrow the geometry→measure method
  (sharpened by contrast: his measure is an angle, SIF's is an Euler characteristic),
  use belief functions — mass on subsets — as the concrete meeting point of the two
  geometries — but never anchor home there. SIF's home stays the constructive,
  cohomological base." Cross-reference tag present in file:
  `[[feedback_route_through_plausibility_not_home]]`.

### From `FOL/Amalgamation.lean` (puremath, the complete 161-line version)

- **[def]** `Params S A B : Type w := S ⊕ A ⊕ B` — the full parameter type (shared
  block + two private blocks).
- **[def]** `incS`, `incSA`, `incSB` — inclusions of shared / shared+left /
  shared+right parameter subsets into the full parameter type.
- **[def]** `SatT` — a type satisfies a sentence iff it contains it (`φ ∈ p`).
- **[def]** `IsSharedT`, `IsLeftT`, `IsRightT` — a sentence is shared/left/right when
  pulled in from `L[[S]]` / `L[[S⊕A]]` / `L[[S⊕B]]` along the inclusions, via
  `lhomWithConstantsMap ... .onSentence`.
- **[def]** `SharedEqT p q` — two types agree on every shared sentence.
- **[def]** `TypeAmalgamable κ := IsDecomposable SatT SharedEqT IsLeftT IsRightT κ ∅`
  — "the factorization of structured ignorance, in the type category," per docstring.
- **[def]** `HasTypeInterpolationProperty κ` — every valid left⇒right entailment over
  `κ` has a shared interpolant.
- **[KV]** `sharedInvariantT` — "Shared sentences cannot distinguish shared-equivalent
  types — immediate from the definition of `SharedEqT`. This discharges the
  `SharedInvariant` hypothesis of the abstract layer at the type carrier." Proof: one
  line, `intro χ hχ p q hpq; exact hpq χ hχ`.
- **[KV]** `typeReverse_direction` — **the first-order hidden channel, reverse
  direction.** Statement (transcribed): if two admissible types `p₁, p₂` agree on
  every shared sentence yet `p₁` satisfies a left sentence `φ` while `p₂` refutes a
  right sentence `ψ` that `φ` entails over `κ`, then no shared interpolant mediates
  `φ ⇒ ψ`. Docstring gloss: "The shared vocabulary is blind to the coupling between
  the private blocks." Proved by direct application of `reverse_direction` from the
  abstract layer.
- **[KV]** `typeAmalgamable_imp_interp` — **the first-order Maksimova correspondence,
  forward direction, Beth-conditional.** "Genuine type amalgamation together with
  Beth shared-definability reconstructs the interpolant for every valid left⇒right
  entailment. The Beth hypothesis is the genuine first-order content: the shared
  witness must be an actual `L[[S]]`-sentence." Hypotheses: `TypeAmalgamable κ` and
  `HasSharedDefinability SatT SharedEqT IsSharedT IsLeftT κ ∅`.
- **[KV]** `typeOscillation` — **the oscillation theorem over the first-order type
  space. Present ONLY in the puremath tree — absent from design-lab.** Full statement
  transcribed: "Along a trajectory of type-ignorance states `κseq`, if every state is
  Beth-shared-definable and some state exhibits a cross-domain discovery (a
  non-interpolable left⇒right entailment), then the states cannot all be
  type-amalgamable: the factorization obstruction must spike (`HC > 0`) at some
  step." Docstring further states: "This is a direct instantiation of the
  substrate-neutral `oscillation_theorem` at the genuine type carrier — the proof is
  `oscillation_theorem` itself. Its one substantive feature is the explicit
  `HasSharedDefinability` (Beth) hypothesis: that is exactly where the first-order
  content enters. In real first-order logic Beth's definability theorem holds, so
  this hypothesis is always dischargeable and oscillation is unconditional — but Beth
  is not in Mathlib, so it is carried as a hypothesis. The same hypothesis is false in
  full second-order logic, so this is the precise point at which oscillation could
  break under the FOL→SOL shift." Signature: `{Step : Type*} (κseq : Step → Set
  (CompleteType T (Params S A B))) (hBeth : ∀ t, HasSharedDefinability SatT SharedEqT
  IsSharedT IsLeftT (κseq t) ∅) (hcross : ∃ t, HasCrossDiscovery SatT IsSharedT
  IsLeftT IsRightT (κseq t) ∅) : ¬ ∀ t, TypeAmalgamable (κseq t)`. Proof:
  `oscillation_theorem SatT SharedEqT IsSharedT IsLeftT IsRightT κseq (fun _ => (∅ :
  Set _)) hBeth hcross` — a direct instantiation, not a fresh proof.
- **[infra]** Module docstring's own framing of the design choice: the geometry legs
  of the Five-Way (`FOL/FiveWayStructural.lean`) are carrier-agnostic (proofs never
  touch type-space structure), so amalgamation there "collapses to the trivial
  set-recombination `FiberProductSurjective`. That is not genuine first-order
  amalgamation." This file exists specifically to give the genuine version.

**All items above are byte-identical between the two trees except `typeOscillation`,
which exists only in puremath** (verified both by direct read and by `diff`).

### From `FOL/NOOLOGY_URS.md` (both trees; substantive divergence isolated to one
section, "Leg-iv")

Common content (byte-identical in both trees, lines 1–181 and the closing `## η`),
tagged from the Γ-axis ledger's own vocabulary (`Pl_imagine`, `Coh_ens↔Will`, `R`-move,
etc. — these are the noological-urs skill's own instrument, reproduced as the source
uses them, not asserted by me as claims about the field):

- **[infra]** *A — Will snapshot.* "Re-derive HC over FOL by lifting the carrier, not
  re-deriving the legs: the axiom-free `Abstract` layer stays untouched, the
  propositional cube `{T,F}^σ` generalizes to the compact Stone space of the formula
  algebra."
- **[infra]** *R — the grammar move.* Carrier `{T,F}^σ` → `St(B) =
  FirstOrder.Language.Theory.CompleteType T α`. "The propositional model is the
  finite-Stone special case." Under Stone duality, `SharedEq`, `IsLeft/IsRight/
  IsShared`, the fibration, and the measure substrate "all fall out of the same
  dualization — one R-move, the abstract layer invariant under it."
- **[KV]** *R1 — Stone topology + clopen base. CLOSED 2026-06-23.*
  `FOL/TypeSpaceTopology.lean`: `instTopologicalSpace := generateFrom (range
  typesWith)`; `isClopen_typesWith`. Sorry-free, axiom-clean
  (`[propext, Classical.choice, Quot.sound]`; `isOpen` even `[Quot.sound]`).
- **[KV]** *R2 — compact + T2 + totally-disconnected. CLOSED 2026-06-23.* Separation
  half in `TypeSpaceSeparation.lean` (`instTotallySeparatedSpace` via disjoint clopen
  partition `typesWith φ ⊔ typesWith ∼φ`). Compactness in `TypeSpaceCompact.lean` via
  **Alexander's subbasis theorem** `isCompact_generateFrom` — noted as "a genuine
  simplification-FREE improvement" superseding a planned cube-embedding route. FIP
  argument transcribed: "a basic cover `univ ⊆ ⋃ typesWith φᵢ` ⇒ the negation theory
  `onTheory T ∪ {∼φᵢ}` has empty type-set (`setOf_subset_eq_empty_iff`) ⇒
  unsatisfiable ⇒ (compactness thm `isSatisfiable_iff_isFinitelySatisfiable`) a finite
  unsatisfiable subtheory ⇒ a finite subcover."
- **[KV]** *R3 — Polish + Borel. CLOSED 2026-06-23.* `FOL/Polish.lean`, under
  `[Countable (L[[α]].Sentence)]`. Chain: `instSecondCountableTopology` ⇒
  `instMetrizableSpace` (via Urysohn `metrizableSpace_of_t3_secondCountable`) ⇒
  `instCompletelyMetrizable` ⇒ `instPolishSpace` ⇒ `instMeasurableSpace := borel _` +
  `instBorelSpace`.
- **[KV]** *"BUILD PLAN R1–R3 COMPLETE."* "The first-order type space `CompleteType T
  α` is now a compact Polish Borel Stone space... This is exactly the carrier ZPM's
  Choquet/analytic tower and the FLT borel→analytic bridge consume."
- **[KV]** *FOL Five-Way R1–R5, all legs closed.* `FOL/FiveWayStructural.lean`
  (Set-based `Decomposable`, `FiberRect`, `FiberProductSurjective`,
  `fiveWayStructural_tfae`, `decomposable_iff_fps` "needs no axioms");
  `FOL/FiveWayInterpolation.lean` (`fiveWay_fol` ties R1/R2/R3/R5 into one TFAE — with
  a noted reuse fact: "The proofs carried over from the Finset template verbatim (they
  were first-order logic over membership; the `DecidableEq` instances were never
  used)."); `FOL/FiveWayCI.lean` (R4, reframed per Dhruv per the ledger: "the
  measurability obstruction is the load-bearing leg" — `analytic_nullMeasurable`,
  `marginal_nullMeasurable`, `mi_eq_zero_iff_product`).
- **[STANCE, ledger-internal]** *"DEEP FINDING" (Dhruv probe: "clean lift, or a 7th
  leg?").* The five clean legs lift cleanly "because they are carrier-agnostic" —
  `FiveWayStructural` never touches type-space structure, "it would hold for finite
  sets, reals, anything," so that lift is "shallow (not deeply first-order)." The
  genuinely first-order content is identified as living in exactly two places: (a)
  Leg iv changing interpretation (support→distribution, since there is no uniform
  measure on the infinite type space) without changing strength — explicitly ruled
  NOT a 7th leg unless a canonical measure is fixed; (b) amalgamation collapsing to
  `FiberProductSurjective` in the carrier-agnostic model but becoming genuine (and
  fallible) at the single type space `St(S⊕A⊕B)`.
- **[KV]** *Genuine FOL amalgamation, closed 2026-06-23* (ledger's own account of the
  Lean file mined directly above): `sharedInvariantT`, `typeReverse_direction`, and
  `typeAmalgamable_imp_interp` (Beth-conditional), landed "sorry-free, axiom-clean
  ([Quot.sound] only)." Ledger frames the Beth condition as "the genuine discovery":
  "in the carrier-agnostic case `shared_definability` was a finitary ∃ and provable;
  over real types the shared witness must be an actual `L[[S]]`-sentence = Beth
  definability... So the lift is honestly non-clean here, and amalgamation
  *strengthens* into a real model-theoretic property." **Note for the record: the
  ledger's own prose here does not mention `typeOscillation` even though the ledger is
  otherwise identical in both trees** — the theorem's absence from design-lab is a
  pure Lean-file gap, not reflected as a gap in either ledger's prose (see divergence
  section).
- **[KV]** *η.* "HIGH throughout — every leg instantiated existing, verified machinery
  at the new carrier (the R1–R3 build was the hard part; the legs were assembly).
  R1/R4 each closed in one build; R2/R3/R5 in one. FOL Five-Way: 5 legs over ~2
  ticks."

**The one substantively divergent section — "Leg-iv" (design-lab title: "Leg-iv
reconnection (one-way bridge)"; puremath title: "Leg-iv FOL end — COMPLETE"):**

- **Design-lab version [KV, but incomplete relative to puremath]:** states only
  `support_prod` and `mi_zero_imp_rectangular_support` (the one-way, "easy" bridge
  direction), then frames the converse as still open: "**Remaining converse = the
  canonical support→measure map** (uniform for finite κ; generically-stable Keisler
  measure under NIP for infinite κ) — the same boundary as the propositional **CHSH
  Pl-kill** (HC is support-level). That is the genuine next construction, not a defect
  of the lift."
- **Puremath version [KV, complete]:** states the same one-way bridge, **plus** the
  separation witness (`FOL/SupportDistributionSeparation.lean`:
  `support_distribution_separation`, the concrete `Pcorr` on `Bool×Bool`, mass 3/8
  diagonal / 1/8 off, with `Pcorr_support_rectangular` and `Pcorr_ne_product`
  ("`Pcorr{(tt,tt)}=3/8 ≠ 1/2·1/2=1/4`")), **plus** the unification witness (already
  in `MutualInformation.lean`): `mutualInformationReal_uniform_eq_zero_iff_isRect` —
  "at the canonical/uniform measure, support ⇔ distribution. They coincide exactly
  there." Puremath's closing paragraph (verbatim): "So support-level and
  distribution-level HC are separated in general, unified only at the canonical
  measure — the precise measure-theoretic form of the CHSH Pl-kill (HC is
  support-level). The only remaining converse, for the general infinite case, is the
  canonical support→measure map (generically-stable Keisler measure under NIP) — a
  genuine construction, not a defect; the FOL-end characterization itself is now
  complete."
- **Reading the delta as content, not just prose difference:** the puremath ledger
  documents two additional closed Lean results — the separation witness `Pcorr` (in
  `FOL/SupportDistributionSeparation.lean`, which is present, byte-identical, in
  *both* trees per my file-level diff) and the pointer to the unification witness
  already in `MutualInformation.lean` (also present, byte-identical, in both trees).
  **This means the underlying Lean artifacts these paragraphs describe already exist
  identically in design-lab; only the ledger's narration of them is stale/incomplete
  in design-lab.** This is a pure documentation lag, not a missing-proof lag — see
  Cross-tree divergence notes for the precise implication.

---

## Citations

Organized by the claim each supports, verbatim as extracted, with source location and
"no id given" flagged wherever true.

### Supporting: the field's namesake collision and the seventy-year cylindric literature

- **Monk** — *Leon Henkin and Cylindric Algebras* [title only, no year/id given in
  either source file]. Supports: "a is rectangular iff c(Γ)a · c(Δ)a = c(Γ∩Δ)a — the
  equational form of 'a product of its projections'" (Theory.md §5, PROBE); "the
  substrate is a literal structural fit... Cylindrification = coordinate projection
  (Monk: `CᵢX = {a : ∃b∈X, aⱼ=bⱼ for all j≠i}`)" (FOUNDATIONS.md §9).
- **Sayed Ahmed**, arXiv:1309.0681. Supports: the interpolation⟺(super)amalgamation
  attachment in the cylindric/polyadic setting (FOUNDATIONS.md §9, "CONFIRMED. It is a
  named theorem"); also cited as the survey in which "'rectangular' does not even
  appear in the 977 KB Sayed Ahmed survey" (FOUNDATIONS.md §9, Q2, supporting the
  absent-grading finding).
- **Mann**, arXiv:0711.4376. Cited as one of the four primary sources grounding the
  cylindric-placement probe (FOUNDATIONS.md §9 preamble). No specific quoted claim
  attributed to Mann individually beyond the group citation.
- **Kohlas**, arXiv:1804.02840. Supports: Q4's rejection of Kohlas CI as a fit —
  "Kohlas CI = valuation/information-algebra substrate, not cylindric" (FOUNDATIONS.md
  §9, Q4).
- **Maksimova** [no year/id given]. Supports: "the canonical Maksimova form 'logic has
  Craig interpolation iff the variety has the super-amalgamation property'"
  (FOUNDATIONS.md §9, Q3); also Theory.md §5 ("the interpolation⟺superamalgamation
  correspondence is a classical theorem of the variety (Maksimova; Madarász; Sayed
  Ahmed; Németi)" [PROBE]) and Theory.md §1 ("Maksimova's interpolation⟺amalgamation
  correspondence is fifty years old and stays inside algebraic logic" [PROBE]).
- **Madarász** [no year/id given]. Co-cited with Maksimova, Sayed Ahmed, Németi for the
  interpolation⟺superamalgamation correspondence (Theory.md §5; FOUNDATIONS.md §9,
  Q3).
- **Sági** [no year/id given]. Co-cited with Sayed Ahmed and Madarász for Q3 in
  FOUNDATIONS.md §9 only (not present in the Theory.md §5 citation list — a minor
  citation-list difference between the two documents' co-citing of the same
  correspondence).
- **Németi** [no year/id given]. Co-cited alongside Maksimova, Madarász, Sayed Ahmed
  (Theory.md §5; FOUNDATIONS.md §9, Q3).

### Supporting: the two-pass ancestor audit and near-neighbour comparisons (Theory.md §6)

- **Abramsky–Brandenburger** [sheaf contextuality; no year/id given in Theory.md].
  Supports: "the deepest sibling, and the field's own lineage for the cohomological
  reading. Shares the support-level obstruction-to-global-section. Its gradings are
  binary (strong contextuality), LP-fractional (contextual fraction — a distance
  between distributions), or cohomological classes; none is a cardinality defect, and
  the logic legs are absent." [PROBE]
- **Mayer's structural independence** (2024) [no further id given]. Supports:
  "support-level and distribution-free, the right instincts; but binary
  (history-set disjointness), ungraded, with no information bridge and no logic
  legs." [PROBE]
- **Studený's imsets** [no year/id given]. Supports: "the most developed
  combinatorial-algebraic CI theory; its grading lives in the dual supermodular cone
  over a distribution. Combinatorial, but fibre-graded." [PROBE]
- **Cuzzolin's geometry of uncertainty** — Springer 2021 monograph title not given in
  Theory.md (cited there only by name); **fully given in FOUNDATIONS.md §11.1**:
  "geometry of relative plausibility and relative belief of singletons, Ann. Math.
  Artif. Intell. 2010" plus the Springer 2021 book (title of the book itself not
  quoted verbatim in either file — only "geometry of uncertainty" as the working
  name). Supports (Theory.md §4/§6): "a genuine geometry, of the fibre, and metric.
  The complement, not a competitor." Supports (FOUNDATIONS.md §11.1, extended): "belief
  functions as points in `ℝ^(2^|Θ|−2)`... deriving an uncertainty measure `R[b]` from
  orthogonality." **[KV program; complementarity interpretive]** per FOUNDATIONS.md's
  own tag.
- **Baudot–Bennequin; Vigneaux** — information cohomology. Supports (Theory.md §6):
  "the nearest cohomological program, and the decisive check. Its cocycles are
  entropy and Shannon MI as functions of a law or a histogram: cohomology of the
  fibre, again." Vigneaux specifically: "Vigneaux's nondegenerate-product definition
  invokes the exact inclusion `ι : E_XY ↪ E_X × E_Y` — the very support-versus-hull
  comparison this field grades — as a nondegeneracy hypothesis, a condition assumed
  to hold so that the entropy cocycle is determined, and never grades the defect
  itself." [PROBE] Exact arXiv ids given **in the ledger table only** (Theory.md §12):
  "Vigneaux 1709.07807, 2003.02021."

### Supporting: the classical local-to-global / gluing literature (Theory.md §3)

- **Vorob'ev 1962** [no title/id given]. Supports: "The classical answer (Vorob'ev
  1962; Beeri–Fagin–Maier–Yannakakis 1983) is that gluing is forced exactly when the
  cover is acyclic."
- **Beeri–Fagin–Maier–Yannakakis 1983** [no title/id given]. Co-cited with Vorob'ev
  1962 for the same classical acyclicity result.
- **Atserias–Kolaitis** [no year/id given; referenced multiple times]. Supports: the
  "chordal/conformal dichotomy" used in the converse's proof route (Theory.md §3); the
  "monoid-consistency parameter" as the suggested grading codomain (Theory.md §5,
  §10); "monoid-consistency, where support/bags/probability are one monoid knob"
  (FOUNDATIONS.md §5).

### Supporting: landed contact with hard external problems (Theory.md §3)

- **Ben-David–Hrubeš–Moran–Shpilka–Yehudayoff**, *Nature MI 2019* [no arXiv/DOI given
  in either source file — only the venue "Nature MI 2019"]. Supports: "the
  Ben-David–Hrubeš–Moran–Shpilka–Yehudayoff compression theorem (learnability
  undecidability, Nature MI 2019) is closed in Kuratowski form."
- **Kolmogorov, 1933** [no title/id given]. Supports (Theory.md §4): "In 1933
  Kolmogorov founded uncertainty on measure: a σ-additive weighting, real-valued, with
  the distribution as the primary object." Also FOUNDATIONS.md §11: "Kolmogorov grounds
  uncertainty in measure (σ-additivity over ℝ — analytic/arithmetic roots)."
- **Yannakakis** [no year/id given]. Supports (FOUNDATIONS.md §5): "Rectangle defect ↔
  nonnegative rank ↔ extension complexity (Yannakakis)."
- **Krajíček–Pudlák; BPR; Schmid et al.** [no years/ids given, cited as a group in the
  ledger only]. Supports the ledger-table PROBE verdict: "Contextuality reaches
  quantum advantage, not P vs NP; feasible-interpolation route barriered" (Theory.md
  §12).
- **Gács–Körner** [no year/id given]. Supports (Theory.md §7, item 5; FOUNDATIONS.md
  §5): "the corridor from Gács–Körner common information through nonnegative rank to
  extension complexity."
- **Goodrick–Kim–Kolesnikov** [no year/id given, "lineage" only]. Supports (Theory.md
  §8): "identify the model-theoretic obstruction (amalgamation homology,
  Goodrick–Kim–Kolesnikov lineage)."
- **Abramsky–Mansfield–Barbosa** [no year/id given]. Supports (FOUNDATIONS.md §11,
  closing status line): "the obstruction-as-cohomology (contextuality side:
  Abramsky–Mansfield–Barbosa..." — tagged **[KV]** in-file as an established fact
  about the literature, not the field's own novel claim.
- **Ó Conghaile** [no year/id given]. Supports (FOUNDATIONS.md §11, same line): "CSP
  side: Ó Conghaile) are [KV]."

### Supporting: the naming collision flag (Theory.md §11)

- **Federer** [no year/id given]. Supports: "'geometric measure theory' is Federer's
  field (rectifiability, currents, Hausdorff measure) and cannot be the name" — a
  disambiguation citation, not a substantive claim-support citation.

### No id given, summary flag

Every citation above marked "[no year/id given]" or "[no title/id given]" is recorded
here explicitly per the carrier's instruction to write "no id given" rather than
inventing one. The only citations carrying resolvable identifiers anywhere in my
slice are: Sayed Ahmed (arXiv:1309.0681), Mann (arXiv:0711.4376), Kohlas
(arXiv:1804.02840), Vigneaux (arXiv:1709.07807, arXiv:2003.02021), and Cuzzolin's 2010
paper (venue given as "Ann. Math. Artif. Intell. 2010," no arXiv/DOI). No citation in
my slice was fabricated or embellished beyond what the source states; several (Vorob'ev
1962, Beeri–Fagin–Maier–Yannakakis 1983, Kolmogorov 1933, Ben-David et al./Nature MI
2019) carry only a year and no further identifier in the source text itself.

---

## Literature-audit verdicts

Extracted from FOUNDATIONS.md §9 (the cylindric-placement verification) and Theory.md
§1/§6/§12, with source location and stated scope of search.

1. **Q1 [PROBE, CONFIRMED].** "the object IS a cylindric set algebra; 'rectangular' is
   a NAMED notion. CONFIRMED (direct, not analogy)." Grounded in Monk and the
   `c(Γ)a · c(Δ)a = c(Γ∩Δ)a` definition; dimension theory (`Δx`, 0-dimensional
   elements) present. Source: FOUNDATIONS.md §9.
2. **Q2 [PROBE, DECISIVE — ABSENT].** "no constructive cardinality grading of
   non-rectangularity exists in cylindric / polyadic / relation algebra. ABSENT.
   Rectangularity is a Boolean predicate; the dimension set is index-valued, not
   numeric; 'rectangular' does not even appear in the 977 KB Sayed Ahmed survey.
   `hcComb(κ) = |∏ᵢπᵢ(κ)| − |κ|` is a genuine new primitive laid on the cylindric
   substrate — not a rediscovery." Source: FOUNDATIONS.md §9. Scope stated: the 977 KB
   Sayed Ahmed survey specifically, plus Monk/Mann/Kohlas.
3. **Q3 [PROBE, CONFIRMED].** "interpolation ⟺ (super)amalgamation attaches precisely.
   CONFIRMED. It is a named theorem in the cylindric/polyadic setting (Sayed Ahmed;
   Madarász; Sági; Németi), the canonical Maksimova form." Source: FOUNDATIONS.md §9.
4. **Q4 [PROBE, ABSENT].** "the CI/MI leg and the fiber-product/global-section leg are
   ABSENT from algebraic logic. ('IF-cylindric independence' = Hintikka
   quantifier-independence, rejected vacuous; Kohlas CI = valuation/information-
   algebra substrate, not cylindric.) The five-way's information + geometric bridges
   are SIF's own, not pre-existing." Source: FOUNDATIONS.md §9. Explicit anti-vacuity
   discipline stated in the paragraph preamble: "A strict-relevance probe (anti-
   vacuity discipline: generic 'relations + projections' matches rejected as
   non-findings)."
5. **Net verdict [PROBE].** "SIF is, established, a constructively-graded fragment of
   cylindric set algebra. Substrate + logic legs are INHERITED (a 70-year
   Henkin–Monk–Tarski toolkit comes with them); the constructive grading and the
   cross-domain bridges (CI, fiber-product) are the new primitives." Source:
   FOUNDATIONS.md §9, closing paragraph. Dated: "2026-06-30," per the section header
   "[was CONJ, now established by primary sources, 2026-06-30]."
6. **Two-pass ancestor audit [PROBE].** "The two-pass ancestor audit (ten works,
   primary sources, strict 'no summing of siblings' rule) returned no direct
   ancestor." Source: Theory.md §6. Scope stated explicitly: **ten works**, primary
   sources, "strict anti-vacuity rule (generic resemblance = non-finding)" (Theory.md
   header claim-discipline block) and "strict 'no summing of siblings' rule" (§6).
7. **The bridge finding [PROBE, the single strongest novelty claim in the slice].**
   "the bridge from the logic pair (interpolation/amalgamation) to the information
   side (MI/CI) appears in no examined work in any field." Source: Theory.md §1.
8. **Base/fibre split confirmed as literature fact [PROBE].** "Three independent
   audits confirmed the base/fibre split as a fact about the literature rather than a
   framing choice." Source: Theory.md §4. Three components named: Cuzzolin's program
   geometrizes the fibre metrically; the separation witness proves `F` is not
   faithful; information cohomology "turns out to be, precisely, cohomology of the
   fibre."
9. **Moonshine [REJECTED, per Theory.md §12 ledger].** "Moonshine direct fit —
   REJECTED (parked, first-principles, gated)." Source: Theory.md §10, §12. Stated
   scope: "four-channel probe." Explicitly the one target that "died" in the
   falsification protocol described in §1: "we adversarially tried to dissolve the
   field into its neighbours five separate times — the ancestor audit, the cylindric
   probe, the information-cohomology probe, the complexity probes, the Moonshine test
   — with explicit license to return 'kill.' One target died (Moonshine, correctly)."
10. **Cylindric substrate PROBE verdicts, ledger-table compressed form (Theory.md
    §12):** "Cylindric substrate literal; grading absent there; CI/fiber legs absent
    there — PROBE — Monk; Sayed Ahmed corpus." This is Theory.md's own compressed
    restatement of FOUNDATIONS.md §9's Q1–Q4, confirming the two documents are
    reporting the *same* audit, not two independent audits (no double-counting of
    novelty).
11. **Contextuality/complexity boundary [PROBE].** "Contextuality reaches quantum
    advantage, not P vs NP; feasible-interpolation route barriered — PROBE —
    Krajíček–Pudlák; BPR; Schmid et al." Source: Theory.md §12.

**Cross-check note (agent axis):** I confirmed FOUNDATIONS.md §9's four Q/A verdicts
and Theory.md §12's ledger-table row "Cylindric substrate literal..." are the *same*
underlying audit reported at two altitudes (detailed in FOUNDATIONS.md, compressed in
Theory.md's ledger). I did not find a second, independent cylindric audit — treating
them as one PROBE event, not two, avoids inflating the verdict count.

---

## Cross-tree / divergence notes

This is the deliverable my slice specifically asks for. All findings below were
verified by direct `diff`/`comm`, not inferred from prose, except where explicitly
marked as a prose-only observation.

### 1. Corrections to the slice note's own claims (agent-axis, reported per carrier
   instruction — "a gap named is content")

- The slice note states the InformationTheory divergence files live under
  `HC/InformationTheory/{Gaussian, CondChainRule, ...}`. **This path does not exist in
  either tree.** The actual location is a *sibling* of `HC/`, at
  `ZPM/Measurements/ZPM/InformationTheory/`... precisely:
  `/.../measurements/ZPM/InformationTheory/` (one level up from `HC/`, under
  `ZPM/Measurements/`, not nested inside `HC/`). I flag this as a path
  imprecision in the carrier/slice note, not a discovery about the field. The file
  *set* the note describes is otherwise accurate (see item 3 below).
- The slice note's list of "design-lab HC files ABSENT from puremath" implies
  `Theory.md` is part of the new/design-lab-only work by omission (it doesn't mention
  Theory.md as shared). **I confirmed `Theory.md` is present, and byte-identical, in
  both trees** — it is not a divergence point at all. This is worth surfacing because
  a synthesis reader could otherwise assume the flagship field note itself is
  unsynced; it is fully synced.

### 2. `HC/` top-level file-presence divergence (exhaustive `comm` set-difference)

**Design-lab has, puremath lacks** (23 files, confirmed by `comm -23` over sorted
`find` listings of `*.lean`/`*.md` at `HC/` top level):
- Lean (14): `AffineEngine.lean`, `Amalgamation.lean` (root-level; distinct file from
  `FOL/Amalgamation.lean` — see note below), `ApproximateFiveWay.lean`,
  `CyclicConverse.lean`, `Dirac.lean`, `FiberProduct.lean`, `FiveWayPi.lean`,
  `GrahamBridge.lean`, `HigherObstruction.lean`, `Marginals.lean`, `Multipartite.lean`,
  `ParityFamily.lean`, `ProductLaw.lean`, `VorobevConverse.lean`.
- Markdown/URS ledgers (9): `AMALGAMATION_URS.md`, `APPROX_FIVEWAY_DISCOVERY_URS.md`,
  `APPROX_FIVEWAY_NOOLOGICAL_URS.md`, `CYCLIC_CONVERSE_URS.md`, `FIBER_PRODUCT_URS.md`,
  `GRAHAM_BRIDGE_URS.md`, `HIGHER_OBSTRUCTION_DISCOVERY_URS.md`,
  `HIGHER_OBSTRUCTION_NOOLOGICAL_URS.md`, `PRODUCT_LAW_URS.md`.

  This confirms the slice note's list exactly (all 14 named Lean files present; the 9
  URS ledgers present, matching the note's "plus all `*_URS.md` ledgers" clause). I
  peeked at the first lines of each ledger only (not a full read, since these are
  outside my four assigned files) to characterize them: all nine are Γ⟷γ
  discovery/noological instrument pairs for the discrete gluing-stack build (the
  amalgamation leg, the cyclic-converse capstone, the fiber-product join, the
  Graham-bridge decidability face, the product-law grading-codomain decision, and the
  approximate-five-way / higher-obstruction typing-derivation pair). Line counts:
  `AMALGAMATION_URS.md` 105, `CYCLIC_CONVERSE_URS.md` 706 (by far the largest — the
  "capstone" ledger), `FIBER_PRODUCT_URS.md` 95, `GRAHAM_BRIDGE_URS.md` 120,
  `PRODUCT_LAW_URS.md` 120, `APPROX_FIVEWAY_DISCOVERY_URS.md` 214,
  `APPROX_FIVEWAY_NOOLOGICAL_URS.md` 89, `HIGHER_OBSTRUCTION_DISCOVERY_URS.md` 159,
  `HIGHER_OBSTRUCTION_NOOLOGICAL_URS.md` 119. **These are unread by me beyond their
  opening lines and are not otherwise represented in this URS** — flagging as
  agent-axis ignorance below, since a full mining of them is a natural follow-up slice
  but was not mine.

**Puremath has, design-lab lacks** (1 file): `FOUNDATIONS.md` — confirmed, and fully
mined above (see Files mined, item 2).

**Present in both, content-identical** (7 files, all confirmed `diff`-clean):
`Abstract.lean`, `Combinatorial.lean`, `Fibered.lean`, `FiberedInterpolation.lean`,
`MutualInformation.lean`, `Spekkens.lean`, `Theory.md`.

### 3. `ZPM/InformationTheory/` divergence (sibling of `HC/`, corrected path — see item 1)

**Design-lab has, puremath lacks** (12 files, confirmed by `comm -23`):
`KullbackLeibler/CondChainRule.lean`, `KullbackLeibler/FiniteSupport.lean`,
`KullbackLeibler/Gaussian/AbsolutelyContinuous.lean`,
`KullbackLeibler/Gaussian/AffineImage.lean`, `KullbackLeibler/Gaussian/ClosedForm.lean`,
`KullbackLeibler/Gaussian/Diagonal.lean`, `KullbackLeibler/Gaussian/OneDim.lean`,
`KullbackLeibler/Gaussian/Whitening.lean`, `KullbackLeibler/MapEquiv.lean`,
`KullbackLeibler/NormLlr.lean`, `KullbackLeibler/Tensorization.lean`,
`TotalCorrelation/Def.lean`.

This matches the slice note's list exactly by content (Gaussian [6 sub-files],
CondChainRule, FiniteSupport, MapEquiv, NormLlr, Tensorization, TotalCorrelation — all
7 named clusters confirmed present, with Gaussian expanding to 6 concrete files).

**Puremath has, design-lab lacks:** none — `comm -13` returned empty. This is a
strictly one-directional divergence (puremath is a proper subset of design-lab's
`InformationTheory/` file set).

**I did not read the contents of any `InformationTheory/` file** — this directory is
outside my four assigned files and outside `HC/` proper (it is a shared-infrastructure
tree, not part of the HC field's own module). I confirm only file *presence*, per the
slice's explicit divergence-audit request, not content. Flagged under Agent-axis
ignorance.

### 4. `FOL/Amalgamation.lean` — the precise substantive diff (my core assigned task)

Confirmed by direct `diff`: **lines 1–138 are byte-identical between design-lab (139
lines total) and puremath (161 lines total).** The entire divergence is puremath's
extra 22 lines (139–160), which is exactly one additional theorem:
`typeOscillation` — the direct instantiation of the substrate-neutral
`oscillation_theorem` at the genuine FOL type carrier (full statement transcribed
above under Theorems and definitions).

**What this means for the field, read conservatively (γ):** design-lab's `FOL/`
subtree proves genuine type-reduct amalgamation (`TypeAmalgamable`), the reverse
hidden-channel direction (`typeReverse_direction`), and the Beth-conditional forward
Maksimova correspondence (`typeAmalgamable_imp_interp`) — but does **not** yet state,
in that tree, the oscillation theorem's FOL-carrier instance. Puremath does. Since
`typeOscillation`'s proof is *only* an application of `oscillation_theorem` (already
present, byte-identical, in both trees' `Abstract.lean`) plus the already-present
`sharedInvariantT`/`typeAmalgamable_imp_interp` machinery, **this is very likely a
sync gap rather than a proof gap**: nothing in design-lab's `Abstract.lean` or its
other FOL files is missing the ingredients `typeOscillation`'s one-line proof term
needs. I flag this inference as **[CONJ]**-grade on my own part (agent axis, not a
field claim) since I did not attempt to compile or re-derive it — see Agent-axis
ignorance.

### 5. `FOL/NOOLOGY_URS.md` — the precise substantive diff (my core assigned task)

Confirmed by direct `diff`: **lines 1–181 are byte-identical.** The sole divergence is
in the "Leg-iv" section (design-lab: 10 lines, puremath: 23 lines, plus puremath has a
5-line synthesis paragraph after it that design-lab lacks entirely — full text of both
versions transcribed above under Theorems and definitions).

**Design-lab's ledger** documents only the one-way bridge (`support_prod`,
`mi_zero_imp_rectangular_support`) and frames the separation-witness converse as
**open** ("Remaining converse... That is the genuine next construction, not a defect
of the lift").

**Puremath's ledger** documents the one-way bridge **plus** the separation witness
(`Pcorr`, in `FOL/SupportDistributionSeparation.lean`) **plus** the unification
witness (`mutualInformationReal_uniform_eq_zero_iff_isRect`, in
`MutualInformation.lean`), and states the leg is **complete**.

**The critical cross-check finding:** both `FOL/SupportDistributionSeparation.lean`
and `MutualInformation.lean` — the two files puremath's fuller ledger paragraph is
*about* — are **already present and byte-identical in design-lab** (confirmed above,
§2 for `MutualInformation.lean`; confirmed identical for
`SupportDistributionSeparation.lean` in the full FOL/ identity check). **This means
the Lean proofs the puremath ledger narrates already exist, verbatim, in design-lab.
Only design-lab's ledger prose has not been updated to describe them.** This is
documentation lag on a completed result, not a missing-proof gap — structurally
different from the `typeOscillation` case (§4 above), where the Lean artifact itself,
not just its narration, is genuinely absent from design-lab.

### 6. Precise sync-delta (the deliverable, stated directly)

**What design-lab must gain** (to reach puremath parity on the two audited files):
1. The `typeOscillation` theorem (22 lines) appended to
   `.../design-lab/.../HC/FOL/Amalgamation.lean` — a genuine proof-content gap, though
   very likely a trivial port since every dependency it needs already exists
   byte-identical in design-lab.
2. The updated "Leg-iv" narration (design-lab's 10-line stub → puremath's 23-line +
   5-line synthesis version) in
   `.../design-lab/.../HC/FOL/NOOLOGY_URS.md` — a pure documentation update; zero new
   Lean content required since the underlying files are already synced.

**What puremath must gain** (to reach design-lab parity, tree-wide, per the slice's
divergence audit beyond the two named files):
1. All 14 root-level `HC/` Lean files enumerated in §2 above (the entire discrete
   local-to-global stack: affine obstruction engine, Dirac's lemma, the Vorob'ev
   converse capstone, Graham/GYO bridge, the higher-obstruction and approximate-
   five-way machinery, the multipartite/marginals/parity-family/product-law
   infrastructure, and the root-level positive-amalgamation `Amalgamation.lean`
   distinct from the FOL one).
2. All 9 root-level `*_URS.md` ledgers enumerated in §2.
3. All 12 `ZPM/InformationTheory/` files enumerated in §3 (Gaussian KL sub-theory,
   conditional chain rule, finite-support KL, map-equivariance, norm-LLR bounds,
   tensorization, total correlation).

**Conflicts:** none found. Every divergence in every file pair I checked is
**strictly directional** — one tree is a superset of the other on every file compared,
with zero cases of both trees having independently-diverged, mutually-incompatible
content on the same named entity. Puremath is strictly ahead on the two `FOL/` files
in my core assigned diff; design-lab is strictly ahead on everything else audited
(the root-level `HC/` stack and `InformationTheory/`). `Theory.md` is the one file
proving the two tree owners keep at least the flagship field note in lockstep despite
the module-level lag elsewhere.

### 7. A structural observation on the divergence's shape (STANCE-grade, my own
   reading, flagged as such — not a field claim)

**[STANCE — my own inference, not sourced from either file]** The pattern across
items 4–6 (Lean content ahead in puremath on `FOL/`; Lean content ahead in design-lab
everywhere else; ledger narration in puremath ahead of design-lab specifically where
puremath's Lean is ahead) is consistent with puremath being the tree where the
*original* FOL lift work happened and was later selectively back-ported into
design-lab (explaining why `TypeSpaceTopology.lean` through
`SupportDistributionSeparation.lean` port cleanly and only the *last* result
(`typeOscillation`) plus its ledger entry didn't make the port), while design-lab is
where the *newer* discrete gluing-stack arc (§3 of Theory.md, the "v0.2" material)
originated and has not yet been forward-ported to puremath at all. I flag this as
STANCE/CONJ on the agent axis because I did not read commit history, timestamps beyond
the "2026-06-23" / "2026-06-30" / "2026-07-02/03" dates already quoted above, or any
sync-tooling documentation — it is a plausible reading of the file-level evidence
only, not a verified fact.

---

## Agent-axis ignorance (Γ)

Reported precisely and separately, per the carrier's instruction that "a gap named is
content, a gap hidden is a coverage failure."

1. **The nine design-lab-only `*_URS.md` ledgers** (`AMALGAMATION_URS.md`,
   `APPROX_FIVEWAY_DISCOVERY_URS.md`, `APPROX_FIVEWAY_NOOLOGICAL_URS.md`,
   `CYCLIC_CONVERSE_URS.md`, `FIBER_PRODUCT_URS.md`, `GRAHAM_BRIDGE_URS.md`,
   `HIGHER_OBSTRUCTION_DISCOVERY_URS.md`, `HIGHER_OBSTRUCTION_NOOLOGICAL_URS.md`,
   `PRODUCT_LAW_URS.md`) were confirmed present and I read only their opening 1–3
   lines each for characterization. I did **not** mine their theorems, definitions, or
   citations — that content is entirely unrepresented in this URS beyond title, opening
   line, and line count. `CYCLIC_CONVERSE_URS.md` at 706 lines is likely the single
   largest undocumented ledger in the whole corpus and almost certainly contains the
   detailed Γ⟷γ record of the Dirac's-lemma / cyclic-converse capstone work that
   Theory.md §3 summarizes in a few sentences. This is a genuine, large coverage gap
   relative to the full corpus, though it is **outside my assigned slice** (my slice
   named exactly 4 files to read fully plus a file-presence audit, not full extraction
   of every design-lab-only ledger).
2. **The 14 design-lab-only root-level `HC/` Lean files** (`AffineEngine.lean`,
   `Amalgamation.lean` root-level, `ApproximateFiveWay.lean`, `CyclicConverse.lean`,
   `Dirac.lean`, `FiberProduct.lean`, `FiveWayPi.lean`, `GrahamBridge.lean`,
   `HigherObstruction.lean`, `Marginals.lean`, `Multipartite.lean`,
   `ParityFamily.lean`, `ProductLaw.lean`, `VorobevConverse.lean`) were confirmed
   present by filename only (via `find`/`comm`) and I read the docstring header of
   exactly one (`Amalgamation.lean` root-level, to disambiguate it from
   `FOL/Amalgamation.lean`). Their actual theorem statements are not transcribed here
   — Theory.md §3's prose summary of them (`glues_of_acyclic`,
   `acyclic_iff_grahamReducible`, `affine_obstruction`, `clean_system_obstruction`,
   `exists_consistent_not_glues_of_not_acyclic`, `dirac_strong`,
   `acyclic_iff_forall_consistent_glues`, `specker_hosts_nonglue`) is transcribed
   above as [KV] under Theorems and definitions, sourced from the field note, not from
   independently reading the Lean.
3. **The 12 design-lab-only `ZPM/InformationTheory/` files** were confirmed present by
   filename only; zero content read. This is intentional per my slice's scope
   (file-presence audit, not content audit, for this directory) but is recorded here
   as a real, not-hidden gap.
4. **`typeOscillation` port feasibility.** My claim in Cross-tree note §4 that the
   `typeOscillation` gap is "very likely a sync gap rather than a proof gap" is my own
   inference from reading that every Lean symbol its proof term references
   (`oscillation_theorem`, `SatT`, `SharedEqT`, `IsSharedT`, `IsLeftT`, `IsRightT`,
   `HasSharedDefinability`, `HasCrossDiscovery`, `TypeAmalgamable`) already exists,
   byte-identical, elsewhere in design-lab's tree. I did **not** attempt to actually
   compile or paste the 22 lines into design-lab's file to verify this — it is a
   plausibility judgment (`Pl_imagine`, in the corpus's own vocabulary), not a
   verified fact, and I have tagged it as such (CONJ-grade, agent axis) in the note
   itself.
5. **Commit history / provenance for the divergence's directionality.** My §7
   "structural observation" about *why* the divergence has the shape it does (puremath
   led on `FOL/`, design-lab leads on the discrete stack) is explicitly flagged STANCE/
   my-own-inference and is not grounded in any timestamp, git log, or sync-tool
   documentation I read — only in the file-content dates already quoted from the
   ledgers themselves (2026-06-23 for the FOL work, 2026-07-02/03 for the discrete
   stack). A miner or the synthesis pass with access to git history could confirm or
   refute this cheaply; I flag it as open rather than asserting it.
6. **Sayed Ahmed, Mann, Kohlas — no verification beyond the arXiv id string itself.**
   I transcribed the ids exactly as given (`arXiv:1309.0681`, `arXiv:0711.4376`,
   `arXiv:1804.02840`) but did not independently resolve them against arXiv or any
   external database (this URS mining task is extraction, not citation verification —
   consistent with the carrier's instruction that I "extract and organize faithfully,"
   not re-verify). If a later pass wants citation verification proper, the
   `verify-citations` skill is the appropriate tool, not this mining pass.
7. **`Sági` citation asymmetry.** I noted (Citations section) that FOUNDATIONS.md §9
   Q3 lists "Sayed Ahmed; Madarász; Sági; Németi" while Theory.md §5 lists "Maksimova;
   Madarász; Sayed Ahmed; Németi" — Sági appears only in FOUNDATIONS.md, Maksimova only
   in Theory.md's version of the same citation cluster (though Maksimova is also named
   independently elsewhere in FOUNDATIONS.md). I flag this as a minor asymmetry I could
   not resolve further (whether it is deliberate — different aspects of the same
   correspondence — or a drafting inconsistency between the two documents) without
   further context outside my slice.
8. **No compile/kernel-check performed.** Per the carrier's explicit instruction, I did
   not attempt to re-verify any [KV] claim against the actual Lean kernel — all [KV]
   tags above are transcribed from source docstrings/ledgers/field-note prose exactly
   as asserted, per the carrier's "treat the corpus as strictly true" instruction. This
   is by design, not a gap, but I record it for completeness of the ignorance ledger.

**Coverage of the four assigned files: complete.** All four files named in my slice
(`Theory.md`, `FOUNDATIONS.md`, `FOL/Amalgamation.lean` both trees,
`FOL/NOOLOGY_URS.md` both trees) were read end to end, in full, with no truncation.
The divergence audit beyond those four files (the file-presence sweep across all of
`HC/` and `ZPM/InformationTheory/`) was completed exhaustively at the *presence* level
(every file accounted for, set differences computed precisely) but not at the
*content* level for the design-lab-only files, which was explicitly out of scope for
this slice's file list.
