# URS 04 — Multipartite, higher obstruction and parity

Miner: Sonnet miner 04. Slice: Multipartite substrate, marginals/presheaf law, the first higher
obstruction (shadow-blindness + Specker non-gluing), the n-ary parity family, and the exact
five-way at arity n. Object axis (γ) and agent axis (Γ) kept strictly separate throughout, per the
carrier.

## Files mined

All seven assigned files read in full, end to end, via the Read tool.

1. `HC/Multipartite.lean` (82 lines) — full read.
2. `HC/Marginals.lean` (143 lines) — full read.
3. `HC/HigherObstruction.lean` (118 lines) — full read.
4. `HC/ParityFamily.lean` (172 lines) — full read.
5. `HC/FiveWayPi.lean` (197 lines) — full read.
6. `HC/HIGHER_OBSTRUCTION_DISCOVERY_URS.md` (160 lines) — full read.
7. `HC/HIGHER_OBSTRUCTION_NOOLOGICAL_URS.md` (120 lines) — full read.

No file was truncated. `coverageComplete = true`.

## Theorems and definitions

Organized by file, in file order. Each item tagged per the carrier's kind-of-truth taxonomy.

### `HC/Multipartite.lean`

Docstring frames this file as "the multipartite substrate for the quantitative five-way": a
relation `κ ⊆ ∏ᵢ Xᵢ` as a `Finset` of dependent functions, its projections, its rectangular hull,
and the combinatorial defect `hcCombPi κ = |∏ᵢ πᵢ(κ)| − |κ|` — the arity-n generalization of
`hcComb`. **[STANCE]**, docstring framing.

- **`projPi`** [def]. `def projPi (κ : Finset (∀ i, X i)) (i : ι) : Finset (X i) := κ.image (fun f => f i)`.
  The coordinate projection: what the interface exposes of part `i`.
- **`hullPi`** [def]. `def hullPi (κ : Finset (∀ i, X i)) : Finset (∀ i, X i) := Fintype.piFinset (fun i => projPi κ i)`.
  The rectangular hull: product of the coordinate projections, "the maximal ignorance consistent
  with the marginal exposures" **[STANCE]**.
- **`hcCombPi`** [def]. `def hcCombPi (κ : Finset (∀ i, X i)) : ℕ := (hullPi κ).card - κ.card`.
  The multipartite combinatorial hidden-channel defect.
- **`IsRectPi`** [def]. `def IsRectPi (κ : Finset (∀ i, X i)) : Prop := κ = hullPi κ`.
  Multipartite rectangularity: the relation is its own rectangular hull.
- **`subset_hullPi`** [KV]. `lemma subset_hullPi (κ : Finset (∀ i, X i)) : κ ⊆ hullPi κ`. A
  relation is contained in its rectangular hull.
- **`card_hullPi`** [KV]. `lemma card_hullPi (κ : Finset (∀ i, X i)) : (hullPi κ).card = ∏ i, (projPi κ i).card`.
  The hull's cardinality is the product of the projection cardinalities (via `Fintype.card_piFinset`).
- **`hcCombPi_eq_zero_iff_isRectPi`** [KV]. `theorem hcCombPi_eq_zero_iff_isRectPi (κ) : hcCombPi κ = 0 ↔ IsRectPi κ`.
  Marked in-file as "the zero-set anchor tying `hcCombPi` to the five-way" **[STANCE]**. Proved
  via `Finset.eq_of_subset_of_card_le` (forward) and `Nat.sub_self` (backward).
- **`card_hullPi_sdiff`** [KV]. `lemma card_hullPi_sdiff (κ) : (hullPi κ \ κ).card = hcCombPi κ`.
  The forbidden region has exactly `hcCombPi κ` elements. File docstring explicitly names this
  "the set whose product-measure mass drives the quantitative lower leg of the approximate
  five-way" **[STANCE]** — a cross-reference to `ApproximateFiveWay.lean`, a file outside this
  slice (noted, not mined).
- **`countPi`** [def]. `def countPi (κ) (i : ι) (a : X i) : ℕ := (κ.filter (fun f => f i = a)).card`.
  Per-coordinate multiplicity of a value in the relation.
- **`countPi_pos`** [KV]. `lemma countPi_pos (κ) (i) {a} (ha : a ∈ projPi κ i) : 0 < countPi κ i a`.
  Exposed values have positive multiplicity. Note the `omit [Fintype ι] [DecidableEq ι] in` —
  this lemma holds without the ambient Fintype/DecidableEq instances on the index type.

### `HC/Marginals.lean`

Docstring frames this file as establishing that "the marginal family is a presheaf over the subset
lattice" **[STANCE]**, with the hull as "an endomorphism of the marginal presheaf, the object any
Čech-type complex over the coordinate cover is built on" **[STANCE]**. The docstring explicitly
flags a sharpness/boundary result up front: "The nonemptiness in `hullPi_projS` is sharp: for the
empty relation and the empty sub-team the left side is the singleton empty function ... while the
right side is empty — a kernel-checked counterexample, found by the extension argument's failure."
**[STANCE]**, but describing a **[KV]**-grade sharpness fact (the counterexample itself is a
kernel-checked disagreement, i.e. a Pl-kill of the naive unconditional law).

- **`projS`** [def]. `def projS (κ : Finset (∀ i, X i)) (S : Finset ι) : Finset (∀ i : S, X i) := κ.image S.restrict`.
  The marginal of a multipartite relation over a sub-team `S`: image under `Finset.restrict`.
- **`decidableIsRectPi`** [KV/infra]. `instance decidableIsRectPi [Fintype ι] [DecidableEq ι] (κ) : Decidable (IsRectPi κ)`.
  Rectangularity is decidable via `decidable_of_iff (κ = hullPi κ) Iff.rfl`. Tagged infra: this is
  the instance whose provenance is explicitly discussed in the discovery URS as blocking every
  quantified `decide` downstream (see Literature/discovery-audit notes below).
- **`projS_image_restrict₂`** [KV]. **"The presheaf law"** (in-file bolded label) **[STANCE]** for
  the mathematical content, but the equation itself is **[KV]**:
  `theorem projS_image_restrict₂ (κ) {S T : Finset ι} (hST : S ⊆ T) : (projS κ T).image (Finset.restrict₂ hST) = projS κ S`.
  Docstring: "the restriction map carries the T-marginal onto the S-marginal. This is the
  compatibility any Čech-type complex over the marginal family consumes" **[STANCE]**. Proved via
  `Finset.image_image` + `Finset.restrict₂_comp_restrict` (a Mathlib composition lemma).
- **`projPi_projS`** [KV]. `theorem projPi_projS (κ) (S) (i : S) : projPi (projS κ S) i = projPi κ ↑i`.
  Coordinate projections factor through marginals; "the i-th projection of the S-marginal is the
  i-th projection of the relation, homogeneously in `Finset (X i)`" **[STANCE]** (a typing remark).
- **`piFinset_image_restrict`** [KV]. Infrastructure lemma, not separately bolded but load-bearing:
  `theorem piFinset_image_restrict [Fintype ι] [DecidableEq ι] {F : ∀ i, Finset (X i)} (hF : ∀ i, (F i).Nonempty) (S) : (Fintype.piFinset F).image S.restrict = Fintype.piFinset (fun i : S => F ↑i)`.
  "The restriction image of a product of nonempty factors is the product of the restricted
  factors: a section over S extends to a global section whenever every dropped factor is
  nonempty" **[STANCE]**. Named in the discovery URS as "the genuinely new combinatorial lemma."
- **`hullPi_projS`** [KV]. **"The hull commutes with marginalization"** (bolded in-file)
  **[STANCE]** for the framing, **[KV]** for the statement:
  `theorem hullPi_projS [Fintype ι] [DecidableEq ι] (κ) (hκ : κ.Nonempty) (S) : hullPi (projS κ S) = projS (hullPi κ) S`.
  Explicitly marked sharp: "fails for κ = ∅, S = ∅" **[STANCE]**, describing a **[KV]**-grade
  fact via the discovery URS's `hc_probe4` (see Literature-audit / experiment ledger below).
- **`hcCombPi_projS_le`** [KV]. **"The defect is monotone along marginalization"** (bolded)
  **[STANCE]** framing, **[KV]** statement:
  `theorem hcCombPi_projS_le [Fintype ι] [DecidableEq ι] (κ) (hκ : κ.Nonempty) (S) : hcCombPi (projS κ S) ≤ hcCombPi κ`.
  Explicitly named "the monotone-grading law of the graded signature" **[STANCE]** (cross-reference
  to an AK-monoid / graded-cylindric-signature vocabulary defined outside this slice, noted not
  mined). Sharp: "fails for κ = ∅, S = ∅ (the marginal of the empty relation over no parts has
  defect one)" **[STANCE]/[KV]**. Proof is a fiber-counting argument over the restriction map:
  decomposes `(hullPi κ).card` and `κ.card` fiberwise over `projS (hullPi κ) S` via
  `Finset.card_eq_sum_card_fiberwise`, shows the marginal is the set of configurations with a
  nonempty κ-fiber, and closes with a pointwise `calc` chain plus `omega`.

### `HC/HigherObstruction.lean`

Docstring states the thesis of this file directly: "The hidden-channel defect is irreducibly
higher-degree: it is not a function of any proper family of marginal shadows." **[STANCE]**. Two
"kernel-verified witnesses over three binary parts" are named: shadow-blindness and failure of
amalgamation. The docstring frames these together as "the acceptance test for the
cohomological-roots programme: any candidate complex attached to an ignorance structure must
vanish on every proper shadow of `parity3` yet detect its global defect, and must obstruct the
gluing of the Specker family." **[STANCE]** — this is an explicit forward-looking acceptance-test
claim, not yet a theorem about any complex (no complex is constructed in this file).

**Shadow-blindness block:**

- **`parity3`** [def]. `def parity3 : Finset (∀ _ : Fin 3, Fin 2) := Finset.univ.filter (fun f => f 0 + f 1 + f 2 = 0)`.
  The 3-ary parity relation.
- **`parity3_shadow_blind`** [decide]. **"Shadow-blindness"** (bolded) **[STANCE]** label for
  **[decide]**-grade content:
  `theorem parity3_shadow_blind : (∀ S ∈ (Finset.univ.erase Finset.univ : Finset (Finset (Fin 3))), IsRectPi (projS parity3 S)) ∧ hcCombPi parity3 = 4 := by decide`.
  Every proper sub-team marginal of the parity relation is rectangular; the global defect is 4.
  Docstring: "the hidden channel is invisible to all proper shadows" **[STANCE]**.
- **`parity3_proper_marginals_rect`** [KV, corollary of decide]. `theorem parity3_proper_marginals_rect (S) (hS : S ≠ Finset.univ) : IsRectPi (projS parity3 S)`.
- **`hcCombPi_parity3`** [KV, corollary of decide]. `theorem hcCombPi_parity3 : hcCombPi parity3 = 4`.
- **`parity3_not_isRectPi`** [KV/decide-derived]. `theorem parity3_not_isRectPi : ¬ IsRectPi parity3`.
  "The parity relation is not rectangular: the global hidden channel is real" **[STANCE]**. Proved
  via `hcCombPi_eq_zero_iff_isRectPi` + `hcCombPi_parity3` + a `decide` on `4 ≠ 0`.

**Failure-of-amalgamation block (Specker triangle):**

- **`S01`, `S12`, `S02`** [def]. Sub-teams `{0,1}`, `{1,2}`, `{0,2}` of `Fin 3`.
- **`diag01`** [def]. `Finset.univ.filter (fun g => g ⟨0,_⟩ = g ⟨1,_⟩)`. Perfect correlation on `{0,1}`.
- **`diag12`** [def]. Perfect correlation on `{1,2}`.
- **`anti02`** [def]. `Finset.univ.filter (fun g => g ⟨0,_⟩ ≠ g ⟨2,_⟩)`. Perfect anticorrelation on
  `{0,2}`.
- **`specker_consistent`** [decide]. **"The Specker triangle is 1-consistent"** (bolded)
  **[STANCE]** label:
  `theorem specker_consistent : projPi diag01 ⟨0,_⟩ = projPi anti02 ⟨0,_⟩ ∧ projPi diag01 ⟨1,_⟩ = projPi diag12 ⟨1,_⟩ ∧ projPi diag12 ⟨2,_⟩ = projPi anti02 ⟨2,_⟩ := by decide`.
  "On every shared coordinate the three pairwise structures expose the same projection (the full
  Fin 2). Consistency is what makes the failure to glue an obstruction rather than an accident."
  **[STANCE]**.
- **`specker_not_glues`** [KV]. **"The Specker triangle does not glue"** (bolded) **[STANCE]**
  label, **[KV]**-grade proved statement (this is a hand-written proof, NOT `decide` — see
  Literature-audit note below on the `decide`-attempt-then-abandoned history):
  `theorem specker_not_glues : ¬ ∃ κ : Finset (∀ _ : Fin 3, Fin 2), projS κ S01 = diag01 ∧ projS κ S12 = diag12 ∧ projS κ S02 = anti02`.
  Docstring: "no multipartite relation has the three consistent pairwise structures as its
  marginals ... Consistent local sections, no global section — the first nonzero Čech-type
  obstruction, in kernel-checkable form." **[STANCE]** — again an explicit cohomological-analogy
  claim, prose-only, no actual Čech complex constructed in this file. Proof: extracts a witness
  `f` from the nonempty `κ` (via `diag01`'s nonemptiness transported backward through `h01`), then
  derives `f 0 = f 1` (from `m01`), `f 1 = f 2` (from `m12`), and `f 0 ≠ f 2` (from `m02`), and
  contradicts by transitivity — a direct 12-line parity contradiction, not an enumeration.

### `HC/ParityFamily.lean`

Docstring: "The n-ary parity relation `parityRel n = {f : Fin n → ZMod 2 | ∑ f i = 0}` upgrades
the three-part witness of `HigherObstruction` to a theorem schema" **[STANCE]**. States the two
core claims of the file: proper sub-team marginals are the full cube (`projS_parityRel`), and the
defect is `2^(n-1)` (`hcCombPi_parityRel`). Also states the schema conclusion: "at every arity the
hidden channel can be maximally invisible: all strict shadows report nothing while the global
defect grows geometrically (`parityRel_shadow_blind`)" **[STANCE]**. Sharpness note up front: "The
lower boundary is sharp and kernel-witnessed: at n = 1 the parity relation is a singleton with
defect 0, so the defect formula genuinely requires n ≥ 2." **[STANCE]/[KV]**.

- **`parityRel`** [def]. `def parityRel (n : ℕ) : Finset (∀ _ : Fin n, ZMod 2) := Finset.univ.filter (fun f => ∑ i, f i = 0)`.
- **`parityRel_three`** [decide]. `theorem parityRel_three : parityRel 3 = parity3 := by decide`.
  "The three-part parity relation of `HigherObstruction` is the n = 3 member" — direct
  cross-tie-in confirming schema-meets-witness within this slice (both files are in-slice).
- **`exists_extension`** [KV, private lemma]. **"The extension engine"** (bolded) **[STANCE]**:
  `private lemma exists_extension {n} (S : Finset (Fin n)) (hS : S ≠ Finset.univ) (g : ∀ _ : S, ZMod 2) : ∃ f ∈ parityRel n, S.restrict f = g`.
  "Any assignment on a proper sub-team extends to a parity configuration — an index outside the
  sub-team absorbs the parity" **[STANCE]**. Constructive proof: picks `j₀ ∉ S`, defines `f` to
  equal `g` on `S`, `-∑ g` at `j₀`, and `0` elsewhere; verifies the sum vanishes via
  `Finset.sum_add_sum_compl`.
- **`projS_parityRel`** [KV]. **"Fullness of proper marginals"** (bolded) **[STANCE]**:
  `theorem projS_parityRel {n} (S) (hS : S ≠ Finset.univ) : projS (parityRel n) S = Finset.univ`.
  "The parity relation's marginal over any proper sub-team is the full cube — every strict shadow
  is maximal ignorance" **[STANCE]**. Note: this is stated as `= Finset.univ`, strictly stronger
  than mere rectangularity — flagged explicitly in the discovery URS as "the statement upgraded
  from rectangular during typing" (see below).
- **`isRectPi_univ`** [KV]. `lemma isRectPi_univ {ι} [Fintype ι] [DecidableEq ι] {X} [∀ i, Fintype (X i)] [∀ i, DecidableEq (X i)] [∀ i, Nonempty (X i)] : IsRectPi (Finset.univ : Finset (∀ i, X i))`.
  The full relation is rectangular (given nonempty parts).
- **`isRectPi_projS_parityRel`** [KV, corollary]. `theorem isRectPi_projS_parityRel {n} (S) (hS) : IsRectPi (projS (parityRel n) S)`.
- **`card_parityRel`** [KV]. **"The parity relation has 2^(n-1) configurations"** (bolded)
  **[STANCE]** label, **[KV]** statement: `theorem card_parityRel (n) (hn : 1 ≤ n) : (parityRel n).card = 2 ^ (n - 1)`.
  "The restriction away from one index is injective on parity (the dropped coordinate is
  determined) onto the full cube" **[STANCE]**. Proof shows the sum constraint determines the
  erased coordinate (`hsum`), the restriction to the co-singleton is injective on parity
  (`hinj`), and counts through `Finset.card_image_of_injOn` + `projS_parityRel`.
- **`hullPi_parityRel`** [KV]. `theorem hullPi_parityRel (n) (hn : 2 ≤ n) : hullPi (parityRel n) = Finset.univ`.
  "For n ≥ 2 the parity relation's hull is the full cube: every coordinate projection is already
  full." **[STANCE]**.
- **`hcCombPi_parityRel`** [KV]. **"The parity defect"** (bolded) **[STANCE]**:
  `theorem hcCombPi_parityRel (n) (hn : 2 ≤ n) : hcCombPi (parityRel n) = 2 ^ (n - 1)`.
  "For n ≥ 2, `hcCombPi (parityRel n) = 2^(n-1)` — half the hull. Sharp at the boundary: for n = 1
  the defect is 0." **[STANCE]/[KV]**.
- **`parityRel_shadow_blind`** [KV]. **"Shadow-blindness at every arity (the theorem schema)"**
  (bolded) **[STANCE]** label:
  `theorem parityRel_shadow_blind (n) (hn : 2 ≤ n) : (∀ S : Finset (Fin n), S ≠ Finset.univ → IsRectPi (projS (parityRel n) S)) ∧ 0 < hcCombPi (parityRel n)`.
  "The hidden channel is irreducibly n-body, at every n." **[STANCE]** — a positioning claim (not
  a stated equivalence with the earlier "= 4" style equality; here the RHS is a positivity bound
  `0 < hcCombPi`, not the exact `2^(n-1)` value, though that exact value is available separately
  via `hcCombPi_parityRel`).

### `HC/FiveWayPi.lean`

Docstring: "The multipartite upgrade of `fiveWay_uniform`" **[STANCE]** — an explicit
cross-reference to a bipartite theorem `fiveWay_uniform` defined outside this slice (noted, not
mined; presumably in `ApproximateFiveWay.lean` or a related file). States the five equivalent legs
directly in prose before the formal TFAE. "The information leg rides the measure identity
`uniformMeasurePi_eq_pi_of_isRectPi`... a positive defect forces positive total correlation (the
quantitative lower leg of the approximate five-way)" **[STANCE]**, cross-referencing
`totalCorrelationReal_uniform_pos`, a lemma outside this slice's files (imported via
`ApproximateFiveWay`, not itself mined here). "The counting leg's backbone is the fiber count of a
product (`Fintype.card_filter_piFinset_eq`)" — an explicit Mathlib-attribution note, confirming
`countPi_piFinset` reduces to an upstream Mathlib lemma (see Literature-audit section).

**The counting backbone (§):**

- **`prod_prod_erase`** [KV, private lemma]. **"The double-product identity"** (bolded)
  **[STANCE]**: `private lemma prod_prod_erase {M} [CommMonoid M] (c : ι → M) : ∏ i, ∏ j ∈ Finset.univ.erase i, c j = (∏ j, c j) ^ (Fintype.card ι - 1)`.
  "Erasing each index in turn multiplies every factor n-1 times" **[STANCE]**. Proved via
  `Finset.prod_comm'` (swap order of the double product) + `Finset.prod_const` +
  `Finset.card_erase_of_mem` + `Finset.prod_pow`.
- **`countPi_piFinset`** [KV, private lemma]. `private lemma countPi_piFinset (F) (i) (a) : countPi (Fintype.piFinset F) i a = if a ∈ F i then ∏ j ∈ Finset.univ.erase i, (F j).card else 0`.
  Explicitly proved as `Fintype.card_filter_piFinset_eq F i a` — a direct Mathlib lemma
  application (no independent derivation needed).
- **`prod_countPi_of_isRectPi`** [KV]. **"The counting backbone"** (bolded) **[STANCE]**:
  `lemma prod_countPi_of_isRectPi {κ} (hrect : IsRectPi κ) (f) : ∏ i, countPi κ i (f i) = if f ∈ κ then κ.card ^ (Fintype.card ι - 1) else 0`.
  "On a rectangular relation the product of the coordinate multiplicities is |κ|^(n-1) on
  admissible configurations and 0 off them." **[STANCE]**.

**The factorization of the canonical measure (§):**

- **`uniformMeasurePi_singleton`** [KV, private lemma]. `private lemma uniformMeasurePi_singleton (κ) (hκ) (f) : uniformMeasurePi κ hκ {f} = if f ∈ κ then (κ.card : ℝ≥0∞)⁻¹ else 0`.
  (Uses `uniformMeasurePi`, a definition presumably from `ApproximateFiveWay.lean` — outside
  slice, noted as import-only.)
- **`uniformMeasurePi_eq_pi_of_isRectPi`** [KV]. **"On a rectangular relation the canonical
  measure is the product of its own marginals"** (bolded) **[STANCE]** label:
  `theorem uniformMeasurePi_eq_pi_of_isRectPi (κ) (hκ) (hrect : IsRectPi κ) : uniformMeasurePi κ hκ = Measure.pi (fun i => (uniformMeasurePi κ hκ).map (fun f => f i))`.
  "The measure-theoretic face of rectangularity" **[STANCE]**. Proof via `Measure.ext_of_singleton`,
  `Set.univ_pi_singleton`, `Measure.pi_pi`, `marginalPi_singleton` (external, from
  `ApproximateFiveWay`), the counting backbone, and a case split on `Fintype.card ι = 0` (handled
  via an `IsEmpty ι` singleton argument establishing `κ.card = 1`) versus `> 0` (handled via
  `ENNReal.mul_inv_cancel` after splitting one inverse factor).

**The exact five-way (§):**

- **`totalCorrelationReal_uniformPi_eq_zero_iff`** [KV]. **"The information leg, exactly"**
  (bolded) **[STANCE]** label: `theorem totalCorrelationReal_uniformPi_eq_zero_iff (κ) (hκ) : totalCorrelationReal (uniformMeasurePi κ hκ) = 0 ↔ IsRectPi κ`.
  Forward direction by contraposition through `totalCorrelationReal_uniform_pos` (external
  lemma, cross-referenced not mined); backward direction through the measure-factorization theorem
  and `klDivReal_eq_zero_iff` at `klDiv_self` (both external/Mathlib-or-adjacent, not mined here).
- **`fiveWay_uniformPi`** [KV]. **"The exact five-way at arity n"** (bolded) **[STANCE]** label
  for a **[KV]** `List.TFAE` bundling five legs:
  ```
  theorem fiveWay_uniformPi (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty) :
      List.TFAE
        [ IsRectPi κ,
          hcCombPi κ = 0,
          totalCorrelationReal (uniformMeasurePi κ hκ) = 0,
          ∀ f : ∀ i, X i, (∀ i, f i ∈ projPi κ i) → f ∈ κ,
          ∀ f : ∀ i, X i, ∏ i, countPi κ i (f i)
            = if f ∈ κ then κ.card ^ (Fintype.card ι - 1) else 0 ]
  ```
  The five legs, exactly as they appear: (1) rectangularity, (2) vanishing combinatorial defect,
  (3) vanishing total correlation of the canonical measure, (4) cross-closure (every configuration
  whose coordinates are all exposed is admissible), (5) the counting identity. Proved via `tfae_have`
  chains: `1 ↔ 2` from `hcCombPi_eq_zero_iff_isRectPi`; `3 ↔ 1` from
  `totalCorrelationReal_uniformPi_eq_zero_iff`; `1 → 4` direct; `4 → 1` via
  `Finset.Subset.antisymm`; `1 → 5` via `prod_countPi_of_isRectPi`; `5 → 4` via a positivity
  argument (`countPi_pos` gives every factor positive, so if the product formula's zero-branch is
  taken the product would have to be `0`, contradiction) — a genuinely nontrivial converse leg,
  not a formal symmetrization.

## Citations

**No citations to any external work (author/year/title/arXiv/DOI) appear anywhere in my assigned
slice.** I searched every file — the five `.lean` files and the two `.md` URS files — for named
authors, years, paper titles, arXiv identifiers, or DOIs, and found none in the Lean source
docstrings or comments.

The only named non-Lean/Mathlib concepts invoked, all unattributed to any specific published
source (no author, year, or identifier given anywhere in these seven files):

- "Čech-type complex" / "Čech complex" — invoked repeatedly as a structural analogy
  (`Marginals.lean` docstring, `HigherObstruction.lean` docstring, discovery URS D1/D3,
  noological URS D1/D3) but with no citation to any specific text on Čech cohomology. Named as
  the target structure the presheaf infrastructure is "built on," never as a cited external
  result.
- "Specker triangle" — a named combinatorial object (the 3-cycle
  correlation/correlation/anticorrelation gadget) invoked without citation. No reference to Ernst
  Specker or any specific paper is given anywhere in these seven files. This is a bare name for a
  gadget, not a literature citation — I record this explicitly rather than supply an attribution,
  per the carrier's "never fabricate a citation" rule. **No id given.**
- "Vorob'ev acyclicity" / "the Vorob'ev acyclicity horizon" — named twice, in the discovery URS
  ("Vorob'ev acyclicity horizon for the amalgamation leg," OUTCOME 1 and OUTCOME 2) and echoed in
  code comments elsewhere in the slice's cross-references. No author-year-title citation is given
  anywhere in my seven files; it functions as a named-but-uncited technical term pointing at a
  follow-up edge, presumably resolved by content in `VorobevConverse.lean` and/or
  `AMALGAMATION_URS.md`/`Amalgamation.lean`, both of which are **outside my assigned slice** (I
  confirmed their existence via a directory listing but did not read them — see Cross-tree notes
  and Agent-axis ignorance below). **No id given.**
- "AK-monoid" / "the AK-monoid grading" / "the graded-cylindric signature (field note §5)" —
  named repeatedly (discovery URS OUTCOME 1, OUTCOME 2, OUTCOME 3; noological URS) as a
  vocabulary/grading structure that `hcCombPi_projS_le` instantiates as "the monotone-grading
  law." Explicitly cross-referenced to "field note §5" — a document not among my assigned files
  (I did not locate or read it; noted as an unresolved cross-reference under Agent-axis
  ignorance). **No id given** for "field note."
- "fiveWay_uniform" and "totalCorrelationReal_uniform_pos" — named Lean identifiers presumed
  defined in `ApproximateFiveWay.lean` (imported by `FiveWayPi.lean`), which is **outside my
  assigned slice**. These are internal cross-references to sibling theorems, not literature
  citations, and I did not verify their statements by reading that file.

**Conclusion on citations: zero external literature citations (author/year/title/id) exist within
this slice's seven files.** This is itself a reportable fact, not a gap in my search — the
carrier instructs me to extract "every named work," and my search found none present to extract.

## Literature-audit verdicts

**No formal literature-audit verdict (in the sense of "no-ancestor," "killed target," or
"boundary/Pl-kill" against a named external corpus) appears anywhere in this slice.** None of the
seven files contain a `[PROBE]`-style verdict of the form "appears in no examined work," a stated
search scope (how many works/fields/standard), or an explicit novelty claim measured against
outside literature.

What the slice DOES contain, and which I record here as the closest analogues, correctly typed
as internal (not literature-scope) verdicts:

- **The `hullPi_projS` sharpness verdict** [KV, describing a decide-level Pl-kill]. The docstring
  of `Marginals.lean` states plainly: "The nonemptiness in `hullPi_projS` is sharp: for the empty
  relation and the empty sub-team the left side is the singleton empty function (an empty product
  over no parts) while the right side is empty — a kernel-checked counterexample, found by the
  extension argument's failure." This is an internal Pl-kill against the miner's own imagined
  unconditional law (D3 in the noological URS), not a literature-audit verdict. The discovery URS
  narrates the same event as "the D3 story, a full oscillation of the method": "The imagined hull
  commutation law survived three #eval refutation sweeps (parity3, asymmetric kA, ∅ at fixed S) —
  then the GENERAL PROOF ATTEMPT exposed the case my sweep never exercised (κ = ∅, S = ∅: empty
  product over no parts is a singleton), the counterexample was kernel-verified (`hc_probe4`,
  exit 0), and the law landed with its sharp Nonempty hypothesis." **[STANCE]** narrating a
  **[KV]**-grade refutation event, with a specific named artifact `hc_probe4` (an experiment
  script/lemma name, not further specified in my slice — no file with that exact name appears
  among the seven I read, so I cannot independently verify its content; flagged under Agent-axis
  ignorance).
- **The `hcCombPi_projS_le` sharpness verdict** [KV, same pattern]. Discovery URS OUTCOME 2: "The
  law was derived in-model with a fiber-counting sketch; the UNIVERSAL decide-sweep (every
  structure, every sub-team, n = 2 and 3) REFUTED it — the sketch was wrong at the same (∅, ∅)
  corner that broke hull-commutation. The corner was confirmed as the sole failure class
  (`hcCombPi (projS ∅ ∅) = 1 > 0`), the law resharpened with κ.Nonempty, re-swept clean
  universally, then proved." A second explicitly named refutation-then-repair cycle, same
  boundary corner as the first. **[STANCE]** narration of **[KV]**-grade content.
  A second, distinct sharpness event is also named: "Second engineered refutation: L2 stated
  over-sharp (n = 1 included) fell exactly at n = 1, carving `hn : 2 ≤ n`" — this matches the
  explicit `n = 1` boundary noted in `ParityFamily.lean`'s own docstring (defect is 0 at n = 1,
  formula requires n ≥ 2), confirming internal consistency between the discovery-URS narration
  and the actual Lean statement's hypothesis `hn : 2 ≤ n`.
- **The fifth-leg promotion verdict** [KV, same pattern]. Discovery URS OUTCOME 3: "The over-sharp
  converse probe — does the counting identity CHARACTERIZE rectangularity? — SURVIVED the
  universal sweep at n = 2, 3, so the identity was promoted from proof-internal backbone to a leg
  of the TFAE (5 → 4: a permitted-but-forbidden configuration has all counts positive,
  contradicting the vanishing branch)." This describes a converse probe that was NOT refuted
  (unlike the two above), and which is why `fiveWay_uniformPi` has five legs rather than four.
  This maps directly and verifiably to the `5 → 4` direction I read in `FiveWayPi.lean`'s actual
  proof, which is exactly the positivity argument described.
- **`specker_not_glues` proof-method verdict** [STANCE/KV]. Discovery URS: "`specker_not_glues`
  (manual 12-line parity contradiction — the kernel's decide over 256 candidate relations hit
  maxRecDepth, so the informative proof replaced the enumerative one)." This is a directly
  verifiable claim against the actual file: `HigherObstruction.lean`'s `specker_not_glues` is
  indeed NOT proved `by decide` (unlike `specker_consistent`, which is); it is a hand-written
  12-ish-line tactic proof using `rintro`, `have`, and `Finset.mem_filter.mp`, exactly matching
  the discovery URS's description. I count the actual tactic-proof body at 8 non-comment
  tactic-lines (lines 103–115 of the file, excluding the 2 explanatory `--` comments), close to
  but not exactly "12-line" as stated in the URS — this is a minor descriptive imprecision I flag
  under Agent-axis ignorance below rather than silently correcting.

**Formal "no-ancestor"/"boundary" style literature verdicts: none found in this slice.**

## Cross-tree / divergence notes

- **Docstring cross-reference chain within slice, internally consistent.** `FiveWayPi.lean`'s
  docstring explicitly calls itself "the multipartite upgrade of `fiveWay_uniform`," and its
  content (`fiveWay_uniformPi`) is structurally the direct n-ary generalization of the bipartite
  five-way pattern implied by that name. `Multipartite.lean`'s docstring in turn calls `hcCombPi`
  "the arity-n form of `hcComb`," confirming a consistent bipartite-to-multipartite naming
  discipline (`hcComb` → `hcCombPi`, presumably `fiveWay_uniform` → `fiveWay_uniformPi`) running
  through the corpus, though the bipartite originals (`hcComb`, `fiveWay_uniform`,
  `totalCorrelationReal_uniform_pos`, `marginalPi_singleton`) live in files outside my slice
  (most likely `Combinatorial.lean` and `ApproximateFiveWay.lean`, confirmed present in the
  directory listing but not read by me).
- **`parityRel_three` ties the schema file to the witness file, both in-slice.** `ParityFamily.lean`
  proves `parityRel 3 = parity3 := by decide`, directly connecting the general-n schema back to
  the specific 3-ary witness of `HigherObstruction.lean`. Both files are in my slice, so this
  cross-tie is independently verifiable by me: I confirm `parity3` in `HigherObstruction.lean` is
  defined over `Fin 3 → Fin 2` with sum `f 0 + f 1 + f 2 = 0`, and `parityRel n` in
  `ParityFamily.lean` is defined over `Fin n → ZMod 2` with sum `∑ i, f i = 0` — these are
  definitionally different domains (`Fin 2` vs `ZMod 2`, which happen to be isomorphic as types
  with matching arithmetic at this cardinality) reconciled by `decide`, not by a general
  type-level identification. This is worth flagging precisely: the equality `parityRel_three` is
  a `decide`-checked propositional equality of two `Finset`s of functions into isomorphic-but-not-
  syntactically-identical codomains, not a definitional unfold.
- **`projS_parityRel` states fullness (`= Finset.univ`), stronger than the mere rectangularity
  used by `parity3_proper_marginals_rect`.** The discovery URS flags this explicitly as "the
  statement upgraded from rectangular during typing" (OUTCOME 2 entry for `ParityFamily.lean`).
  This is a genuine strengthening as one moves from the arity-3 witness (`HigherObstruction.lean`,
  which only proves `IsRectPi`) to the arity-n schema (`ParityFamily.lean`, which proves the
  strictly stronger `= Finset.univ`, from which `IsRectPi (projS (parityRel n) S)` is then derived
  as a corollary via `isRectPi_projS_parityRel`). No contradiction — a strict strengthening,
  correctly derived and both directions present and consistent in the actual files.
- **Terminology drift: "shadow-blind" bundles different logical shapes across the two files.**
  In `HigherObstruction.lean`, `parity3_shadow_blind` bundles an **equality** (`hcCombPi parity3 =
  4`) with the universal-rectangularity clause. In `ParityFamily.lean`,
  `parityRel_shadow_blind` bundles a **strict inequality** (`0 < hcCombPi (parityRel n)`, not the
  exact `= 2^(n-1)` value) with the same universal-rectangularity clause, even though the exact
  value IS separately available as `hcCombPi_parityRel`. I flag this as a minor asymmetry in
  theorem-statement strength between the n=3 witness and the general-n schema's headline
  "shadow-blind" theorem — not a contradiction, since the exact value is provable and proved
  elsewhere in the same file, but the schema's own "shadow-blind" theorem opts for the weaker
  positivity form. This could be read as intentional (the schema theorem is meant to isolate the
  qualitative "genuinely n-body" claim from the quantitative value) or as an incompleteness
  relative to the n=3 case; I do not adjudicate, only note the asymmetry.
- **Named forward-references to material outside my slice, all consistent, none contradicted.**
  Both URS files and the Lean docstrings repeatedly point at follow-up material not in my slice:
  the "AK-monoid product law" / "graded-cylindric signature" (presumably `ProductLaw.lean`,
  present in the directory but unread by me), the "Vorob'ev acyclicity horizon" (presumably
  `VorobevConverse.lean` and/or `Amalgamation.lean`/`AMALGAMATION_URS.md`, present but unread),
  and "the flagship complex" (not yet built anywhere in my slice — explicitly future work in every
  outcome block I read). I did not follow any of these; I confirm only that the directory listing
  shows files with matching names exist, consistent with these being real forward-pointers rather
  than dangling references to nothing.
- **`decidableIsRectPi`'s significance is asserted only in the discovery URS, not in the Lean
  docstring itself.** The discovery URS calls it "the instance whose absence blocked every
  quantified decide downstream (probe-diagnosed)" — a strong claim about its load-bearing role.
  The Lean file itself (`Marginals.lean`) gives it only a one-line doc comment ("Rectangularity is
  decidable: the hull is a computable finset") with no such framing. I flag this asymmetry: the
  narrative significance is asserted in the meta-document, not evidenced in-line in the source I
  can independently check beyond confirming the instance exists and type-checks as stated.
- **No contradiction found between the two URS documents and the Lean source.** Every specific
  claim in `HIGHER_OBSTRUCTION_DISCOVERY_URS.md` and `HIGHER_OBSTRUCTION_NOOLOGICAL_URS.md` that I
  could map to an actual theorem/definition in the five `.lean` files matched what the Lean
  source actually states (modulo the minor line-count imprecision on `specker_not_glues` noted
  above, and the "shadow-blind" strength asymmetry also noted above). I found no place where a
  URS narrated a theorem the Lean does not state — no Pl-kill of the meta-documents themselves
  within my slice.

## Agent-axis ignorance (Γ)

Precise, itemized record of what I could not resolve, per the carrier's instruction that "a gap
named is content, a gap hidden is a coverage failure."

1. **`hc_probe4` — named experiment artifact, content unverified.** The discovery URS names a
   specific kernel-verified counterexample script/lemma `hc_probe4` as the source of the
   `hullPi_projS` sharpness refutation at `(κ = ∅, S = ∅)`. No file named `hc_probe4` (or
   containing a definition by that name) appears among my seven assigned files. I did not search
   outside my slice for it (out of scope per my task), so I cannot independently confirm its
   exact statement or that "exit 0" refers to what I infer (a successful `#eval`/`decide` run). I
   report the discovery URS's characterization as **[STANCE]** narration of a **[KV]**-grade
   event, not as directly verified by me.
2. **"Field note §5" — uncited, unlocated document.** `Marginals.lean`'s docstring for
   `hcCombPi_projS_le` and the discovery URS both refer to "the graded-cylindric signature (field
   note §5)" as the source of the "monotone grading into an ordered monoid" vocabulary. I did not
   locate any file in the directory listing obviously named "field note," and none of my seven
   files is that document. This is a genuine unresolved cross-reference: I cannot confirm what
   "field note §5" is, whether it is itself part of this corpus or an external document, or what
   exactly it claims about AK-monoids.
3. **Bipartite originals not verified, only named.** `hcComb`, `fiveWay_uniform`,
   `totalCorrelationReal_uniform_pos`, `marginalPi_singleton`, and `uniformMeasurePi` (the
   underlying non-Pi definition presumably parameterizing `uniformMeasurePi`, `uniformMeasurePi`
   itself likely defined in `ApproximateFiveWay.lean`) are all invoked by name and used
   (imported/applied) in my slice's files but their actual definitions/statements are NOT in my
   assigned files. I confirmed via `import` lines that `Multipartite.lean` imports
   `ZPM.Measurements.HC.Combinatorial` and `FiveWayPi.lean` imports
   `ZPM.Measurements.HC.ApproximateFiveWay`, and via the directory listing that both
   `Combinatorial.lean` and `ApproximateFiveWay.lean` exist, but I did not read either file. Any
   claim in my slice that depends on the exact statement of these external lemmas (e.g., whether
   `totalCorrelationReal_uniform_pos` truly gives strict positivity under exactly the hypotheses
   I'd expect) is taken on trust from the docstring's characterization, not independently
   verified by me against the source.
4. **`κ.Nonempty` "sharp" claims for `hullPi_projS` and `hcCombPi_projS_le`: I verified the
   theorem statements carry the hypothesis as stated, but did NOT independently re-derive or
   re-run the refutation myself** (e.g., I did not execute a `#eval` to confirm
   `hcCombPi (projS ∅ ∅) = 1` with my own tooling — I report it as stated in the discovery URS and
   cross-check only that the corresponding theorem's hypothesis list matches the narrated
   sharpness, which it does: both `hullPi_projS` and `hcCombPi_projS_le` in `Marginals.lean` do
   carry `(hκ : κ.Nonempty)` as an explicit hypothesis).
5. **Minor imprecision, not a gap but worth flagging as a possible transcription drift:** the
   discovery URS describes `specker_not_glues`'s proof as "manual 12-line parity contradiction";
   my own count of the actual tactic-proof lines (excluding signature and comments) in
   `HigherObstruction.lean` gives roughly 8 lines of tactics across the `rintro`/`have`/`obtain`/
   final-`exact` structure (lines 102–115, 14 lines total including 2 comment lines and blank
   space, so "12" and "8" are both plausible countings depending on what one includes — I flag
   this as an unresolved counting ambiguity rather than a substantive discrepancy, since I have
   no way to know which counting convention the original author used).
6. **The exact relationship between `parityRel_shadow_blind`'s positivity form and
   `hcCombPi_parityRel`'s exact-value form is not explained anywhere in my slice** (see Cross-tree
   note above) — I do not know whether the weaker positivity form in the "shadow-blind" theorem
   name is a deliberate design choice (isolating the qualitative claim) or an artifact of
   composition order. I did not find text in either URS file directly addressing this design
   choice, so I record it as an open descriptive question rather than resolving it myself
   (resolving it would require `act(imagine)`, which is gated for this task).
7. **I did not read `Combinatorial.lean`, `ApproximateFiveWay.lean`, `ProductLaw.lean`,
   `VorobevConverse.lean`, `Amalgamation.lean`, `AMALGAMATION_URS.md`, `PRODUCT_LAW_URS.md`, or any
   other file in the HC directory beyond my seven assigned files.** These are explicitly outside
   my slice per my task instructions, and other miners are presumably covering them. I list them
   here only so the orchestrator/synthesis step knows which adjacent files I confirmed EXIST
   (via `ls`) but did not mine, to avoid a false impression that I verified their content.
8. **No truncation occurred.** All seven files were read via a single Read call each, in full,
   with no `limit`/`offset` truncation warnings from the tool. `coverageComplete = true` is
   accurate, not a placeholder.

Nothing in this slice was imagined, invented, or extrapolated beyond what is written in the seven
files. Every theorem statement transcribed above is copied verbatim (modulo whitespace
normalization for readability) from the actual Lean source I read.
