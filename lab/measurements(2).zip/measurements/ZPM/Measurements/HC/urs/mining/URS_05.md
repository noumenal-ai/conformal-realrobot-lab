# URS_05 — Mining slice: Quantitative approximate five-way (the information bound)

Miner: Sonnet miner 05. Slice: `ApproximateFiveWay.lean` + its two companion URS files
(discovery γ, noological Γ). Operating under `act(describe)` / `act(search)` only;
`act(imagine)` gated per carrier instructions — no invented connections below.

## Files mined

1. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/ApproximateFiveWay.lean`
   — read in full, 511 lines. Lean 4 source, kernel-verified (per carrier: treat as strictly
   true). Namespace `HiddenChannelCapacity`, `noncomputable section`.
2. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/APPROX_FIVEWAY_DISCOVERY_URS.md`
   — read in full, 215 lines. Object-axis (γ) instrument: typing derivation, ignorance ledger,
   flooring outcome, final "OUTCOME (γ — Gate 9)" section.
3. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/APPROX_FIVEWAY_NOOLOGICAL_URS.md`
   — read in full, 90 lines. Agent-axis (Γ) instrument: the PI's fixed decisions, R-moves,
   M-moves, Γ_core, coupling, η forecast.

No file was truncated. All three were read start-to-end with the Read tool in single calls
(no offset/limit needed — each file fit within the default read window).

**Cross-tree note (not mined, flagged only):** the `.lean` file imports
`ZPM.Measurements.HC.Multipartite`, `ZPM.Measurements.HC.MutualInformation`,
`ZPM.InformationTheory.TotalCorrelation.Def`, `ZPM.InformationTheory.Pinsker.Basic`,
`ZPM.InformationTheory.KullbackLeibler.FiniteSupport`. These are outside my assigned slice;
I record their names (verbatim from the `import` lines) but did not read their contents. Some
of their content is *described* secondhand inside my two URS files (see Flooring Outcome
citations below) — I transcribe those descriptions as such, not as first-hand reads.

---

## Theorems and definitions

Tagged per carrier discipline: `[KV]` kernel-verified theorem, `[decide]` finite decidable
check, `[CONJ]` named conjecture, `[PROBE]` literature-audit verdict, `[STANCE]` interpretive
claim, `[def]` a definition (not itself a truth-claim), `[infra]` scaffolding/build-process
fact.

### From `ApproximateFiveWay.lean` (object-level, the Lean source)

**[def] `uniformMeasurePi`** (line 50–51). The canonical (uniform) probability measure on a
multipartite relation:
```
def uniformMeasurePi (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty) : Measure (∀ i, X i) :=
  (PMF.uniformOfFinset κ hκ).toMeasure
```
Instance immediately following: `uniformMeasurePi κ hκ` is `IsProbabilityMeasure`.

**[KV] `uniformMeasurePi_coe`** (line 59–62). The canonical measure is supported on the
relation: `uniformMeasurePi κ hκ ↑κ = 1`.

**[KV] `marginalPi_singleton`** (line 66–83). Marginal mass of the canonical measure on a
singleton equals coordinate multiplicity over relation size:
```
(uniformMeasurePi κ hκ).map (fun f => f i) {a} = (countPi κ i a : ℝ≥0∞) * (κ.card : ℝ≥0∞)⁻¹
```

**[KV, private] `absolutelyContinuous_pi_marginal`** (line 91–116). A probability measure `P`
on a finite discrete product is absolutely continuous with respect to the product of its own
marginals, **unconditionally** (no support hypothesis needed):
```
private lemma absolutelyContinuous_pi_marginal
    (P : Measure (∀ i, X i)) [IsProbabilityMeasure P] :
    P ≪ Measure.pi (fun i => P.map (fun f => f i))
```
Docstring gloss: "a positive singleton forces every coordinate marginal positive." Flagged
below (Flooring Outcome / A4 catches) as a lemma the build process itself found was *stronger
than first stated* — the support hypothesis and `κ` itself were originally present and later
found decorative.

**[KV] `le_totalCorrelationReal_of_marginal_le`** (line 128–174) — **THE LOWER LEG, the slice's
central deliverable, marked in-file as "The lower leg of the approximate five-way (shape forces
information)."** Exact statement:
```
theorem le_totalCorrelationReal_of_marginal_le
    (κ : Finset (∀ i, X i)) (P : Measure (∀ i, X i)) [IsProbabilityMeasure P]
    (hsupp : P ↑κ = 1) (c : ι → ℝ≥0)
    (hfloor : ∀ i, ∀ a ∈ projPi κ i, (c i : ℝ≥0∞) ≤ P.map (fun f => f i) {a}) :
    2 * ((hcCombPi κ : ℝ) * ∏ i, (c i : ℝ)) ^ 2 ≤ totalCorrelationReal P
```
i.e. for any probability measure `P` supported on the multipartite relation `κ` (`P(↑κ)=1`)
whose coordinate marginals are floored by `c : ι → ℝ≥0` on the exposed values,
`2 · (hcCombPi κ · ∏ᵢ cᵢ)² ≤ totalCorrelationReal P`. In-file docstring: "The floor family `c`
is the knob: one monoid-valued parameter whose fold `∏ᵢ cᵢ` grades the weighting and scales the
count in the same expression." Proof route (as literally structured in the file): sets
`Q := Measure.pi (fun i => P.map (fun f => f i))`; uses `absolutelyContinuous_pi_marginal`;
integrability `Integrable (llr P Q) P` discharged by `.of_finite`; sets the forbidden region
`F := hullPi κ \ κ`; shows `P ↑F = 0` (from `hsupp` via `prob_compl_eq_one_sub`); shows
`(hcCombPi κ : ℝ≥0∞) * ∏ i, (c i : ℝ≥0∞) ≤ Q ↑F` (product-of-marginals lower bound via
`Finset.prod_le_prod'` against the floor hypothesis, summed via `card_hullPi_sdiff`); invokes
`two_sq_sub_le_klDivReal P Q hac hint ↑F F.measurableSet` (Pinsker's set-bound lemma, external —
see Cross-tree notes); converts ENNReal bounds to ℝ; concludes via
`totalCorrelationReal` unfolding to `klDivReal P Q`.

**[KV] `lower_totalCorrelationReal_uniform`** (line 178–198) — **"The canonical section
instance,"** in-file phrase verbatim. Exact statement:
```
theorem lower_totalCorrelationReal_uniform (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty) :
    2 * ((hcCombPi κ : ℝ) / (κ.card : ℝ) ^ Fintype.card ι) ^ 2
      ≤ totalCorrelationReal (uniformMeasurePi κ hκ)
```
"the uniform distribution on `κ` has total correlation at least `2 (hcCombPi κ / |κ|ⁿ)²`, with
`n` the number of parts" (docstring, verbatim gloss). Derived from
`le_totalCorrelationReal_of_marginal_le` by instantiating `c i := (κ.card : ℝ≥0)⁻¹` (uniform
floor: "each exposed value has multiplicity at least one") and algebraically simplifying
`∏ᵢ (κ.card⁻¹) = (κ.card)⁻ⁿ` where `n = Fintype.card ι`.

**THIS IS THE SLICE'S NAMED HEADLINE RESULT.** The slice note states: "This slice holds the
field first non-vacuous quantitative prediction: `2 (hcCombPi/|k|^n)^2 <= total correlation <=
counting bound`." The lower bound half of that inequality is exactly
`lower_totalCorrelationReal_uniform`; combined with `totalCorrelationReal_uniform_le` (below)
it gives the full two-sided sandwich named in the slice assignment.

**[KV] `totalCorrelationReal_uniform_pos`** (line 202–209) — **"A nonzero defect forces
strictly positive total correlation"** (in-file docstring, verbatim), described as "the
quantitative form of the five-way's information leg." Exact statement:
```
theorem totalCorrelationReal_uniform_pos (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty)
    (h : hcCombPi κ ≠ 0) :
    0 < totalCorrelationReal (uniformMeasurePi κ hκ)
```
Proved by combining `lower_totalCorrelationReal_uniform` with positivity of the numerator and
denominator (`Nat.pos_of_ne_zero`, `Finset.card_pos`, `pow_pos`, closed by `positivity`).

**[KV, private] `countPi_eq_zero`** (line 218–222). Unexposed values have zero multiplicity:
`countPi κ i a = 0` whenever `a ∉ projPi κ i`.

**[KV] `uniformMeasurePi_real_singleton`** (line 226–234). Real singleton mass of the canonical
measure: `(uniformMeasurePi κ hκ).real {x} = if x ∈ κ then (κ.card : ℝ)⁻¹ else 0`.

**[KV] `marginalPi_real_singleton`** (line 237–240). Real marginal mass:
`((uniformMeasurePi κ hκ).map (fun f => f i)).real {a} = (countPi κ i a : ℝ) / κ.card`.

**[KV, private] `sum_marginalPi_real`** (line 244–253). The real singleton masses of a marginal
sum to one.

**[KV, private] `neg_log_card_le_sum_mul_log`** (line 258–316) — **"The per-part
maximum-entropy bound, in Gibbs form"** (docstring, verbatim). Exact statement:
```
-Real.log ((projPi κ i).card : ℝ)
  ≤ ∑ a : X i, ((uniformMeasurePi κ hκ).map (fun f => f i)).real {a}
      * Real.log (((uniformMeasurePi κ hκ).map (fun f => f i)).real {a})
```
Docstring: "the negated log of the projection size bounds the marginal's `∑ m log m` from
below. This is `klDivReal_nonneg` (Gibbs' inequality) applied to the marginal against the
uniform distribution on the projection." Proof invokes `klDivReal_nonneg m u` where `u` is the
uniform PMF-measure on `projPi κ i`, expands via `klDivReal_fintype`, and algebraically
regroups the log-ratio sum via `Real.log_mul`/`Real.log_div`.

**[KV] `totalCorrelationReal_uniform_le`** (line 322–421) — **"The upper (counting) leg of the
approximate five-way"** (in-file docstring, verbatim). Exact statement:
```
theorem totalCorrelationReal_uniform_le (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty) :
    totalCorrelationReal (uniformMeasurePi κ hκ)
      ≤ Real.log (((hullPi κ).card : ℝ) / κ.card)
```
Docstring gloss: "the total correlation of the canonical measure is at most the log-ratio of
the hull to the relation, `TC(unif κ) ≤ log (|hullPi κ| / |κ|)`. The fibre-side direction:
marginal entropies bounded by the projection sizes (Gibbs), no structural content." **THIS IS
THE UPPER HALF OF THE SLICE'S SANDWICH ("counting bound").** Proof is a long calc chain: unfolds
`totalCorrelationReal` to `klDivReal P Qu`; expands via `klDivReal_fintype`; restricts the sum
to `κ` (off-relation terms vanish); pointwise-expands each term via
`Real.log_div`/`Real.log_inv`/`Real.log_prod`; regroups per-coordinate sums via
`Finset.sum_comp`; collapses the mass term; applies the per-part Gibbs bound
(`neg_log_card_le_sum_mul_log`) via `linarith`; and closes with the final log identity
`-log|κ| - Σᵢ(-log|projPi κ i|) = log(|hullPi κ|/|κ|)` (using `card_hullPi`:
`∏ᵢ|projPi κ i| = |hullPi κ|`).

**[KV, private] `hcCombPi_fin_two`** (line 434–445). Over `Fin 2` the multipartite defect
equals the bipartite `hcComb` of the paired relation:
```
lemma hcCombPi_fin_two (κ : Finset (∀ i, Y i)) :
    hcCombPi κ = hcComb (κ.image (MeasurableEquiv.piFinTwo Y))
```
Proved via `projL`/`projR` identification with `projPi κ 0`/`projPi κ 1` under the pairing
equivalence, then `hcCombPi`/`hcComb` unfolding, `Finset.card_product`,
`Finset.card_image_of_injective`, `card_hullPi`, `Fin.prod_univ_two`.

**[KV] `map_uniformMeasurePi_piFinTwo`** (line 449–491). The canonical measure transports along
the pairing to the bipartite canonical measure of the paired relation:
```
(uniformMeasurePi κ hκ).map (MeasurableEquiv.piFinTwo Y)
  = uniformMeasure (κ.image (MeasurableEquiv.piFinTwo Y)) (hκ.image (MeasurableEquiv.piFinTwo Y))
```

**[KV] `mutualInformationReal_uniform_image_lower`** (line 496–504) — **"The bipartite member
witness"** (in-file docstring, verbatim). Exact statement:
```
theorem mutualInformationReal_uniform_image_lower (κ : Finset (∀ i, Y i)) (hκ : κ.Nonempty) :
    2 * ((hcComb (κ.image (MeasurableEquiv.piFinTwo Y)) : ℝ) / (κ.card : ℝ) ^ 2) ^ 2
      ≤ mutualInformationReal
          (uniformMeasure (κ.image (MeasurableEquiv.piFinTwo Y))
            (hκ.image (MeasurableEquiv.piFinTwo Y)))
```
Docstring: "Over a two-element index the multipartite lower leg lands on the bipartite module's
own objects: the mutual information of the uniform distribution on the paired relation is
bounded below by its combinatorial defect." Proved directly from
`lower_totalCorrelationReal_uniform`, rewritten via `totalCorrelationReal_fin_two`,
`map_uniformMeasurePi_piFinTwo`, `hcCombPi_fin_two`, `Fintype.card_fin` — i.e. this is the
multipartite lower leg specialized to `ι = Fin 2` and re-expressed in the pre-existing bipartite
module's vocabulary (`hcComb`, `uniformMeasure`, `mutualInformationReal`).

**[STANCE]** The file's top-of-file module docstring (line 12–34) frames the whole file as "The
value-level bridge across the support↔distribution fork," stating: "The exact five-way
(`fiveWay_uniform`, `fiveWay_full`) ties the zero sets of the combinatorial defect and the
information functional together; this file relates their values: the total correlation of any
distribution supported on a multipartite relation `κ` is bounded below by an explicit function
of the defect `hcCombPi κ` — shape forces information." Note: `fiveWay_uniform` and
`fiveWay_full` are named but not defined in this file — they are referenced as external/prior
objects (the "exact five-way," presumably a companion module, outside my slice — cross-tree
flag, see below).

### From `APPROX_FIVEWAY_DISCOVERY_URS.md` (object-axis γ instrument)

This file is itself a typed proof-design ledger, not raw Lean. I tag its content per the
carrier scheme, treating its *typing derivation* entries as `[def]`/`[STANCE]` design
statements, its *KU-closure* entries as `[decide]`/`[infra]` facts about the Mathlib pin, and
its final "OUTCOME" section as a `[KV]`-adjacent summary restating the theorems above (I do not
double-count — where it restates a theorem I already extracted from the `.lean` file, I do not
re-tag it as a separate finding, only cross-reference).

**[STANCE] Typing derivation, six concepts (C1–C6), each measured against an M-tuple**
(`g_Pl`, `Coh_break`/`Coh_coercion`, `Inv`, `Comp`) and assigned a T-profile:
- **C1 — multipartite substrate**: `M(C1) = (g_Pl 0.2, Coh_break 0, Inv 0.8, Comp 0.95) →
  T-Parametric`. A **[STANCE] COUNTERDEF C1′** is named: "the interface-typed fibered
  presentation (S-indexed families, Fibered.lean style)," with an explicit **SWAP CONDITION**:
  "when the flagship's multipartite amalgamation leg is built (arity ≥ 3 higher obstruction),
  the interface presentation becomes primary." Documented as a forward edge, not exercised in
  this build.
- **C2 — `totalCorrelationReal`**: `M(C2) = (g_Pl 0.1, Coh_coercion 0.2 [one bridge to MI], Inv
  0.9, Comp 0.95) → T-Abbrev`. Placement noted as load-bearing: lives in
  `ZPM/InformationTheory` (sibling of `MutualInformation`), not in the HC module, "upstreamable."
  **COUNTERDEF C2′**: entropy-sum form (`Σᵢ H(margᵢ) − H(P)`), explicitly rejected as the
  *definition* ("never as the definition… the entropy form appears as a THEOREM… if the upper
  leg needs it").
- **C3 — canonical measure on κ**: `uniformMeasurePi κ hκ := (PMF.uniformOfFinset κ
  hκ).toMeasure`, T-Abbrev, described as "verbatim generalization" of the bipartite file's
  pattern.
- **C4 — the theorem pair (T-Prop; hypothesis structure is the content)**. This is the ledger's
  own name for the UPPER/LOWER leg pair extracted above. Verbatim route notes:
  - UPPER route: "finite-entropy identity `TC = Σᵢ H(margᵢ) − log |κ|` + `H(margᵢ) ≤ log |proj i
    κ|`." A **DEPENDENCY KU-ent** is flagged: "Mathlib finite Shannon entropy
    (`measureEntropy`?) — if absent, counterdef: private inline entropy or a direct log-sum
    proof." Also states: "(Ess-sup and pointwise-ratio routes checked on paper: they give the
    weaker `(n−1)log|κ|`, not the hull bound; entropy route is the right one.)" — this last is a
    **[STANCE]** claim about rejected alternative proof routes, asserted in prose, not verified
    by me against any Lean artifact.
  - LOWER route (marked "the content; acceptance criterion"): "Pinsker `TC = klDiv(P, ∏marg) ≥
    const · TV²` ∘ `TV ≥ |P(F) − Q(F)|` at the forbidden set `F = ↑(hull κ \ κ)` ∘ `P(F) = 0` ∘
    `Q(F) = Σ_{x∈F} ∏ᵢ margᵢ(xᵢ) ≥ hcCombPi · ∏ᵢ cᵢ`." States explicitly: "**The knob is here**:
    `c` lives in the pointwise-ordered commutative monoid `ι → ℝ≥0`, and the bound consumes its
    monoid fold `∏ᵢ cᵢ`." Names the canonical instance giving "the section theorem `hcCombPi κ >
    0 → TC(unif κ) ≥ pinskerConst · (hcCombPi κ / |κ|^n)² > 0`" — note this is the *design-stage*
    phrasing with a placeholder `pinskerConst`; the *landed* theorem (per the `.lean` file) fixes
    this constant to the literal `2`.
  - A4 pre-check recorded: "neither leg is trivial (upper needs the entropy chain; lower needs
    Pinsker + the forbidden-mass computation); hypotheses all load-bearing (drop the floor → the
    separation witness Pcorr-style mass-shifting kills the bound; drop P(κ)=1 → F can carry
    P-mass)." This references a "Pcorr-style mass-shifting" separation witness by name only — I
    could not locate or read this witness (outside my slice); flagged as agent-axis ignorance
    below.
- **C5 — the K-weighted layer (T-Break, documented; "the honest A-K installment")**. States the
  PRIMARY exercised form is the floor family `c : ι → ℝ≥0` with monoid fold, with "two exercised
  instances: canonical (`c = 1/|κ|`…) and general-P (the off-section corollary)." Names
  **COUNTERDEF C5′** as "the full A-K signature": "K-relations `w : (∀ i, X i) → K` over an
  ordered commutative semiring K with a realization hom to ℝ≥0; grading codomain = K." **SWAP
  CONDITION**: "the §10 graded-cylindric-signature build (separate installment); adopting it NOW
  would add fields no proved instance exercises (Γ-gate)." Explicitly states: "The 'one dial'
  identification remains **[CONJ]** (PI's); C4-LOWER is its first statability witness, not its
  proof." Also records a **BREAK POINT**: "the signature design is underdetermined by this
  theorem; the ad-hoc choice (floor family) is recorded as the minimal exercised form. A-K
  citation: [to-verify]." — I transcribe "[to-verify]" verbatim; the ledger itself flags the
  Atserias-Kolaitis attribution as unverified, not a resolved citation. See Citations section.
- **C6 — bipartite witness (T-Bridge)**. Restates `hcCombPi = hcComb` (image), `TC = MI` (map),
  `uniformMeasurePi ↔ uniformMeasure`, instantiation against `fiveWay_uniform`'s objects. Notes
  what "the bridge must NOT lose": "the `proj`/`projL,projR` identification (image under eval =
  projL/projR after transport)."
- **η checks**: "Profiles: T-Parametric, T-Abbrev, T-Abbrev, T-Prop, T-Break, T-Bridge — no
  homogeneity; 1 break point (budgeted, documented); 2 Mathlib bridges (piFinTwo, piFinset)."

**[infra] Ignorance ledger, KK/KU/UK/UU (pre-flooring snapshot).** Verbatim structure:
- **KK** (already known): "Bipartite HC module (hcComb, uniformMeasure, marginal lemmas,
  fiveWay_uniform, uniform_klDiv_ne_top proof patterns); klDivReal toolkit (Real, MapEquiv,
  Tensorization, NormLlr, M3d idioms); `mutualInformationReal` def; PMF.uniformOfFinset
  (bipartite file uses it); ZPM barrel imports Pinsker + TotalVariation."
- **KU** (name-level, to floor), enumerated KU-1 through KU-10 — I transcribe the list because
  each entry names a specific Mathlib/ZPM dependency the LOWER/UPPER legs rely on:
  - KU-1: "ZPM Pinsker: real path + exact statement (klDiv vs TV, constant convention). My grep
    of InformationTheory/Pinsker/Basic.lean returned EMPTY — path unknown, do not assume."
  - KU-2: "ZPM TotalVariation: def + the `|P A − Q A| ≤ TV P Q` characterization + discrete sum
    form."
  - KU-3: "finite Shannon entropy in Mathlib (`measureEntropy`/`Hm`?): exists? uniform value?
    subadditivity/max bounds? Else trigger C2′ counterdef (inline private entropy or log-sum)."
  - KU-4: "`Fintype.piFinset`: name, `mem_piFinset`, `card_piFinset` (= ∏ cards)."
  - KU-5: "DecidableEq instance for `∀ i, X i` over `[Fintype ι]` + per-part DecidableEq."
  - KU-6: "PMF.uniformOfFinset API: `toMeasure_apply`/singleton mass, support lemma."
  - KU-7: "the Fin-2 measurable equivalence (`MeasurableEquiv.piFinTwo`?) + `Measure.pi` over
    Fin 2 ↔ `Measure.prod` + map-eval-of-pi lemmas."
  - KU-8: "klDivReal on discrete/finite support: the sum formula or the PMF-level API the
    bipartite file used for `uniform_eq_product_iff_isRect` (reuse its exact route)."
  - KU-9: "`Measure.map (eval i)` of `Measure.pi` and of `PMF.toMeasure` (marginal machinery)."
  - KU-10: "measurability of ↑κ, ↑(hull κ \ κ) under DiscreteMeasurableSpace on the Π-type
    (instance: `DiscreteMeasurableSpace (∀ i, X i)`? or via Countable/Fintype)."
- **UK** (carried, articulated, not banked):
  - UK-A: "whether the NFL/shattering lower bounds factor through C4-LOWER (the base-forces-fibre
    mechanism) — CONJ edge for the field note's landed-contact list, gated on #14 landing."
  - UK-B: "the sharp constant/regime of the lower leg (Pinsker is not tight for large defects; a
    log-regime lower bound may exist) — post-landing sharpening edge."
  - UK-C: "multipartite TC vs pairwise-MI decompositions (which inequality family the fibered
    presentation needs) — flagship-adjacent, parked."
- **UU**: "What the knob is when the weighting monoid is not realizable in ℝ≥0 (genuinely
  non-probabilistic gradings) — Path-B/graded-signature territory, flagged only."

**[decide]/[infra] Flooring outcome — every KU resolved.** The ledger records that all ten KUs
were closed. I transcribe the substantive closures, each is a factual claim about what exists
in the pinned Mathlib/ZPM:
- **KU-1 CLOSED, route collapsed**: "ZPM Pinsker lives at `InformationTheory/Pinsker/` (Basic =
  barrel over Binary/Bridge/General). `General.lean` has `two_sq_sub_le_klDivReal (P Q)
  [IsProbabilityMeasure ×2] (hac) (h_int) (A) (hA) : 2·(P.real A − Q.real A)² ≤ klDivReal P Q` —
  the LOWER LEG IS THIS LEMMA at `A = ↑(hull κ \ κ)`… No TV detour, no general Pinsker needed
  (both exist anyway: `pinsker_proof`, `tvDistReal`). Also available: `klBin_le_klDivReal`
  (two-set coarsening) and `binary_pinsker` if the sharper klBin form is wanted later (UK-B
  edge)." This matches the actual proof in the `.lean` file, which does call
  `two_sq_sub_le_klDivReal` — cross-confirmed.
- **KU-2 CLOSED**: "`tvDistReal` = sSup over measurable sets of |P.real − Q.real|; not needed
  for the collapsed route."
- **KU-3 CLOSED by counterdef-collapse**: "`measureEntropy` ABSENT from the pinned Mathlib
  (target=mathlib confirmed; earlier zeros were a wrong-corpus artifact, daemon had drifted to
  target=rl — reset). But NO entropy def is needed: the upper leg's max-entropy step `H(margᵢ) ≤
  log |proj i κ|` IS `klDivReal_nonneg` (Gibbs) applied to (margᵢ ‖ uniform on projᵢ), already in
  ZPM (Real.lean)." This corresponds to `neg_log_card_le_sum_mul_log` in the `.lean` file, which
  I confirm literally invokes `klDivReal_nonneg`.
- **KU-4/5/6/7 CLOSED**: "`Fintype.piFinset` family (mem/card lemmas present);
  `PMF.uniformOfFinset` API (`toMeasure_uniformOfFinset_apply`, `support_uniformOfFinset`,
  `uniformOfFinset_apply`); `MeasurableEquiv.piFinTwo` (+ `piFinTwoEquiv`) for the C6 bridge."
- **KU-8/9 CLOSED by pattern-reuse**: "The bipartite file's `marginalFst_singleton` /
  `uniform_eq_product_iff_isRect` machinery is the exact template for the Π-marginal…"
- **KU-10 RESOLVABLE at write time**: "Discrete measurability on the finite Π-type: κ and F are
  finite unions of singletons; `MeasurableSingletonClass` on Pi or per-set finiteness suffices."
- Side-conditions note: "`hac`… and `h_int` (integrability on a finite space) — standard,
  discharge at write time (`Integrable.of_finite`-family…)." — this matches the `.lean` file's
  literal `Integrable (llr P Q) P := .of_finite`.

**[infra] Resulting theorem shapes (pre-write forecast, verbatim).** The ledger forecasts,
before the final write, the same four shapes that appear in the shipped file: "Section
(canonical)"; "Off-section (knob)"; "Upper"; "Witness." I note the forecast's phrasing for the
section theorem used a placeholder — "`totalCorrelationReal (uniformMeasurePi κ hκ) ≥ 2 *
(hcCombPi κ / (hull κ).card … )²`" — with an explicit "(exact spelling of the fold at write
time)" caveat; the shipped theorem (`lower_totalCorrelationReal_uniform`) resolves this to
`(κ.card)^(Fintype.card ι)` in the denominator, i.e. `|κ|ⁿ`, matching the slice assignment's own
phrasing "hcCombPi/|k|^n".

**[infra] Build layout.** "`ZPM/InformationTheory/TotalCorrelation/Def.lean` (C2 + Fin-2/MI
bridge); `ZPM/Measurements/HC/Multipartite.lean` (C1 substrate + counting + marginal lemmas);
`ZPM/Measurements/HC/ApproximateFiveWay.lean` (C4 both legs + C5 knob corollary + C6 witness)."

**[infra] OUTCOME (γ — Gate 9): "#14 DISCHARGED, both legs."** States: "**GREEN + installed, 0
sorry, warningAsError.**" Lists four new files + barrel, restating (in ledger prose) the same
theorems I already extracted directly from the `.lean` source above — I do not double-count
these as separate findings, but I note the ledger's own descriptive labels for cross-reference:
"LOWER (the content): `le_totalCorrelationReal_of_marginal_le`"; "Canonical section:
`lower_totalCorrelationReal_uniform`… + `totalCorrelationReal_uniform_pos`"; "UPPER
(fibre-crawling): `totalCorrelationReal_uniform_le`"; "WITNESS:
`mutualInformationReal_uniform_image_lower`." Also states: "HC.lean barrel: eight layers (+
Multipartite, + ApproximateFiveWay); ZPM.lean barrel now imports ZPM.Measurements.HC (the
module was previously unreachable from the root — its oleans were never built in design-lab;
the whole chain now compiles + installs green)." This is an `[infra]` claim about build/root
reachability, not a mathematical theorem.

**[KV/infra] A4 catches during build (content, kept), verbatim.**
- "`absolutelyContinuous_pi_marginal`: the support hypothesis (and κ itself) were DECORATIVE —
  a probability measure on a finite discrete product is AC w.r.t. its own marginal product
  unconditionally. Removed both; the lemma is stronger and reusable (upstreamable)." This
  matches the shipped `.lean` file: the lemma signature I read takes only `(P : Measure (∀ i, X
  i)) [IsProbabilityMeasure P]`, with no `κ` or support hypothesis — confirming the ledger's
  claim is consistent with the artifact.
- "The M3b-era note 'Finset.sum_neg_distrib nonexistent' is STALE: it exists in the current pin
  and compiled. Ledger corrected." — I note this as a **Pl-kill** per carrier discipline (a
  prior belief was corrected by the build); flagged, not asserted independently by me.

**[STANCE/CONJ] Γ lessons (logged for the instance), verbatim.** "Tactic-block if-branches over
PMF-produced `if`s carry foreign Decidable instances: state case-split lemmas as
`hu_mem`/`hu_notmem` pairs (if_pos/if_neg against the goal's own instance) rather than as an
`if`-statement have. `Finset.sum_comp` under rw suffers HO-unification: instantiate it as a
`have hcomp := Finset.sum_comp (s := κ) f g` term and rewrite with the constructed equation.
`omit` must precede the docstring, not follow it." These are Lean-engineering craft notes, not
mathematical claims — I tag them `[infra]`/agent-craft, distinct from theorem content.

**[CONJ]/[STANCE] Field-note ledger updates earned (for the PI to port to zetesis-puremath),
verbatim.**
- "The approximate five-way moves from open to **[KV]** (both legs + witness)." — I preserve
  the source's own `[KV]` tagging here since it is the ledger tagging its own summary claim.
- "The one-dial conjecture gains its first statability witness (the knob appears in a proved
  theorem); remains **[CONJ]** as an identification." — again the source's own tag, preserved.
- "UK-A (NFL/shattering lower bounds factor through the lower leg) remains a named **[CONJ]**
  edge for the landed-contact list. UK-B (sharper klBin-form lower leg) and the multipartite
  total-correlation faces at arity ≥ 3 (flagship-adjacent) are the named sharpening edges."

### From `APPROX_FIVEWAY_NOOLOGICAL_URS.md` (agent-axis Γ instrument — the *builder's own*
ignorance record, distinct from my ignorance as miner)

This file is explicitly the *prior builder's* Γ-axis record (their agent-axis ignorance while
constructing this theorem), not my own. Per carrier discipline I keep this in the object axis
(γ) of my mining — it is content I extract about the field/programme — while my *own*
agent-axis ignorance as miner is reported separately below under "Agent-axis ignorance (Γ)."

**[STANCE] Problem statement, verbatim.** "Prove the value-level bridge across the Kolmogorov
fork: explicit two-sided bounds between the base count `hcComb` and the fibre functional (total
correlation of the canonical measure), multipartite, with a monoid-valued off-section knob."

**[STANCE] "A (Will snapshot)," the PI's two fixed decisions, verbatim.** "(1) knob =
monoid-valued parameter, Atserias-Kolaitis direction, stated so grading-codomain and
weighting-structure are visibly ONE parameter; (2) multipartite `κ ⊆ ∏ᵢ Xᵢ` is the theorem Prop,
bipartite is an instance witness against the existing `fiveWay_uniform` objects. Acceptance
criterion (PI-fixed): the LOWER leg is the content; the tick is not complete on the upper leg
alone." Also states the process norms: "No `sorry`; unproved obligations are named Prop-defs;
every Mathlib name floored by mathlib-search before `act(formalize)`; kernel is the verifier for
all imagined structure." This is a `[STANCE]` about how the work was governed, matching the
project's known "never use sorry" norm (cross-referenced in the user's own memory index, but I
note this only as external corroboration, not as something I am asserting from the field
corpus).

**[STANCE] "Γ-CORRECTION 3 (standing bias, logged)," verbatim, a self-correction the builder
records about their own reasoning tendency.** "The field note corrected my framing twice in one
conversation: I proposed 'make HC real-valued' (wrong: the integer character is definitional,
base invariants count, they do not integrate) and posed 'which HCreal' as an open fork (wrong:
the canonical section settles it). Diagnosis: my substrate's training mass is overwhelmingly
FIBRE mathematics (probability, analysis, entropy functionals), so my defaults pull every
base-object toward a fibre reading. Standing rule for all HC work: before proposing structure,
ask 'is this a base statement or a fibre statement, and which side does my proposal silently
move the object to?' The upper/lower asymmetry is the litmus: upper legs crawl to fibres (my
comfort zone, low η); lower legs are base-forcing (the field's content, where predictions
live). Route my effort to the lower legs deliberately, against the pull." I flag this as a
**Pl-kill** in the carrier sense (two prior proposals were rejected as wrong) and preserve it
verbatim because it explains *why* the LOWER leg (not the UPPER) is marked as the acceptance
criterion throughout both companion URS files.

**[STANCE] "R-moves (this task)," verbatim, partial.** "UU→UK→KU already executed by the PI's
frame + decisions: 'quantitative five-way' is now articulated as 'quantitative faithfulness of
the canonical section,' multipartite, one-dial." Names the "NEW R structure" generated: "(i)
`totalCorrelationReal` (the Π-analog of `mutualInformationReal`); (ii) the multipartite
ignorance-structure substrate (projections, hull, `hcComb` over `∏ᵢ Xᵢ`); (iii) the K-weighted
layer (A-K direction)." On the K-layer gate: "the kernel verifies typeability and instances but
CANNOT adjudicate signature design (many signatures compile). Honest protocol: the MINIMAL
signature exercised by the two proved instances (Boolean/canonical → recovers the uniform
theorem; ℝ≥0/mass-floor → the off-section corollary). Any field or law not exercised by a proved
instance is decoration (A4) or explicitly CONJ. The 'one dial' identification (grading codomain
= weighting structure) is the PI's conjecture: my job is to make the statement SHAPE exhibit it
(one parameter, two specializations), never to claim it proved." — This explicitly and
repeatedly self-labels the "one dial" claim as **[CONJ]**, attributed to "the PI." I preserve
this attribution and do not upgrade it.

**[infra] "M-moves (do· classes)," verbatim.** "M-Construction for the substrate defs
(multipartite hull, uniform measure on a Finset of a Π-type); M-Bridge for the bipartite witness
(new defs ↔ the existing `hcComb`/`projL`/`projR`/`uniformMeasure` objects, via
`MeasurableEquiv.piFinTwo`-family); M-Pipeline for the lower leg (Pinsker ∘ TV-versus-forbidden-
cell-mass ∘ product-marginal computation); M-BoundedAverage for the upper leg
(entropy/counting)." States "Will-relative boundary: manipulable = def spellings, proof routes,
file layout; held-constant = the two PI decisions, the lower-leg acceptance criterion, green
build."

**[STANCE] "Γ_core," verbatim.**
- "Coh_{ens↔Will}: 'shape forces information at the canonical measure, quantitatively' is the
  field note's own thesis made theorem-shaped; coherent. The build also serves the §10 program
  (first installment of the graded signature) and the crypto pipeline (leakage floors): one
  build, three Will-threads, no conflict." — Names two other programme threads ("§10 program,"
  "the crypto pipeline") this result is claimed to also serve; I record the names but did not
  verify them (outside my slice, cross-tree flag).
- "Pl_imagine: LOW and gated on four spots: (a) the exact lower-leg constant/shape (Pinsker
  route is candidate, not banked; the kernel decides); (b) the K-signature design (minimal-
  instance protocol above); (c) the Atserias-Kolaitis citation (direction named by the PI; exact
  reference UNVERIFIED, mark [to-verify], never fabricate); (d) the 'NFL factors through the
  lower leg' observation is UK to carry, not bank (named in the discovery URS as a CONJ edge for
  the field note's landed-contact list, gated on proof)." — Item (c) is the *explicit,
  self-flagged* unverified-citation status for Atserias-Kolaitis; see Citations section, I do
  not invent a reference for it.

**[STANCE] "Known unfloored KUs at write time," verbatim (pre-flooring; the discovery URS's
Flooring Outcome section, extracted above, records these as later closed).** "ZPM Pinsker: the
barrel imports `ZPM.InformationTheory.Pinsker.Basic` but my grep returned empty; the file path
or the statement name is UNKNOWN. Do not assume its exact form. Whether Mathlib/ZPM has
finite-support entropy (`measureEntropy`?) or whether the upper leg should avoid entropy
entirely and run on klDiv counting directly. `Measure.pi` marginal-map lemmas on discrete
Π-types; `PMF.uniformOfFinset.toMeasure.map (eval i)` computations; `MeasurableEquiv` between `∀
i : Fin 2, X i` and `X 0 × X 1` and its measure-pi bridge (`Measure.pi` over `Fin 2` ↔
`Measure.prod`)."

**[STANCE] "COUPLING (Γ ↔ γ)," verbatim.** "My imagine-moves (TC def, multipartite substrate,
K-layer) GENERATE the askability; the discovery URS (typing-derivation, next) stabilizes them
into typed defs + a proof DAG; mathlib-search closes the name-KUs; the kernel closes the
proof-KUs. The lower-leg acceptance criterion couples A (Will) to γ-completion: γ is not banked
until the lower leg is green, whatever else compiles."

**[STANCE] "η forecast," verbatim — the file's closing claim, directly relevant to the slice
note's framing of this as "the field first non-vacuous quantitative prediction."** "High if the
lower leg lands general (multipartite, knob-parameterized): it is the field's first non-vacuous
quantitative prediction and the first theorem-witness of the one-dial conjecture's statability.
The upper leg alone: low η (counting; fibre-crawling), explicitly not the deliverable." This is
the **exact source** of the slice-assignment phrase "the field first non-vacuous quantitative
prediction" — I confirm it is a direct quotation from this file, not something I am asked to
independently corroborate.

---

## Citations

Per carrier discipline: transcribe every named work exactly (authors, year, title,
arXiv/DOI); if an identifier is absent, write "no id given." **Never fabricate a citation.**

I found **exactly one** named external work referenced across all three files: **Atserias and
Kolaitis** (attribution by surname only). It is named directly in the `.lean` file's proof
design provenance via the URS ledgers (not in the `.lean` file's own docstrings — the `.lean`
file itself contains zero named citations; all citation-bearing text is in the two companion
URS files).

**Claim it supports:** the "K-weighted layer" / "knob" design of the lower leg
(`le_totalCorrelationReal_of_marginal_le`'s floor family `c : ι → ℝ≥0` and its monoid fold
`∏ᵢ cᵢ`) is stated by the builder to be in the "Atserias-Kolaitis direction" — i.e. the
monoid-valued-parameter design choice for grading/weighting is attributed to this pair of
authors' prior work, by direction/orientation, not by a specific theorem being reused.

**Exact wording, both occurrences, verbatim:**

1. From `APPROX_FIVEWAY_NOOLOGICAL_URS.md`, "A (Will snapshot)": "(1) knob = monoid-valued
   parameter, **Atserias-Kolaitis direction**, stated so grading-codomain and
   weighting-structure are visibly ONE parameter…"
2. From `APPROX_FIVEWAY_NOOLOGICAL_URS.md`, "Γ_core" / "Pl_imagine": "(c) the
   **Atserias-Kolaitis citation** (direction named by the PI; exact reference **UNVERIFIED**,
   mark **[to-verify]**, never fabricate)…"
3. From `APPROX_FIVEWAY_DISCOVERY_URS.md`, "C5 — the K-weighted layer": "…BREAK POINT: the
   signature design is underdetermined by this theorem; the ad-hoc choice (floor family) is
   recorded as the minimal exercised form. **A-K citation: [to-verify].**"

**No id given.** No year, title, venue, arXiv id, or DOI is present anywhere in my slice for
this reference. All three occurrences explicitly self-flag the citation as unresolved
("UNVERIFIED," "[to-verify]," "A-K citation: [to-verify]"). I do not attempt to identify or
supply a candidate Atserias-Kolaitis paper — doing so would be fabrication per carrier rule (the
authors' full names, exact paper, and year are not stated anywhere in my assigned files, and
"Atserias-Kolaitis" is a common co-author pairing across multiple distinct papers in finite
model theory / homomorphism counting, so guessing which one is intended would be an invented
identifier). This is recorded as a genuine open item, not resolved by me.

**No other named external citation appears anywhere in my three files.** I searched
systematically for any other author-year pattern, "et al.," arXiv id, or DOI string across all
three documents and found none. The only other proper-noun references are internal artifact
names (`fiveWay_uniform`, `fiveWay_full`, `FIELD_NOTE.md`, `zetesis-puremath`, `mathlib-search`)
which are internal cross-references to other parts of the same research programme, not external
literature citations — I list these under Cross-tree notes, not Citations, since they are not
"named works" in the bibliographic sense the carrier's citation-extraction instruction targets.

---

## Literature-audit verdicts

Per carrier discipline: extract every literature-audit verdict (no-ancestor, killed target,
boundary/Pl-kill, "appears in no examined work") with source location and exact scope claimed.

**None found in my assigned slice.** I read all three files end to end and found no verdict of
the form "no-ancestor," "appears in no examined work," "killed target," or an explicit
boundary/Pl-kill audit against a stated corpus of examined literature. This slice's only
literature-facing content is the single Atserias-Kolaitis attribution above, which is explicitly
marked unresolved/unverified rather than adjudicated as novel-or-not. There is no claim in my
slice of the form "this result appears in no examined prior work" — the closest the slice comes
is the *internal* framing claim (not a literature-search verdict) that this is "the field first
non-vacuous quantitative prediction," which is a **[STANCE]** about the *programme's own*
history of results (compare against the field's own prior work, `fiveWay_uniform`/`fiveWay_full`
etc.), not a claim about the external published literature. I record this distinction precisely
per the A4 honesty norm: a Pl-kill against internal precedent is not the same as a
no-ancestor verdict against external literature, and my slice contains only the former (if
that), not the latter.

**Adjacent but distinct claim, flagged for precision:** the phrase "the field first non-vacuous
quantitative prediction" (slice note) / "the field's first non-vacuous quantitative prediction"
(noological URS, η forecast) is an **internal-programme priority claim**, not an
external-literature novelty audit. No search scope (number of works, fields, standard) is
stated for it anywhere in my three files — it is asserted, not audited. I flag this precisely so
it is not mistaken for a `[PROBE]`-grade literature verdict; it is `[STANCE]`.

---

## Cross-tree / divergence notes

- **Import boundary (not read, named only).** The `.lean` file imports five modules I did not
  read: `ZPM.Measurements.HC.Multipartite`, `ZPM.Measurements.HC.MutualInformation`,
  `ZPM.InformationTheory.TotalCorrelation.Def`, `ZPM.InformationTheory.Pinsker.Basic`,
  `ZPM.InformationTheory.KullbackLeibler.FiniteSupport`. Objects used from these but not
  themselves defined in my slice: `projPi`, `hullPi`, `hcCombPi`, `countPi`, `card_hullPi`,
  `card_hullPi_sdiff`, `IsRectPi` (from Multipartite — the discovery URS's "C1" section
  describes these but the actual Lean defs live outside my slice); `hcComb`, `uniformMeasure`,
  `projL`, `projR`, `mutualInformationReal`, `totalCorrelationReal_fin_two`,
  `mutualInformationReal_uniform_lower` (implied, bipartite predecessor — from MutualInformation
  / a bipartite module named "the bipartite file" throughout but never given an exact filename
  in my slice); `klDivReal`, `klDivReal_nonneg`, `klDivReal_fintype`, `two_sq_sub_le_klDivReal`,
  `llr`, `Measure.real` (from the KullbackLeibler/Pinsker modules).
- **`fiveWay_uniform` / `fiveWay_full` named but not defined in my slice.** The module docstring
  calls these "the exact five-way" and states this file "ties" to them by relating their *values*
  (as opposed to their *zero sets*). I could not locate their statements — they are referenced as
  prior/companion results, presumably in a sibling file (possibly named `FiveWay.lean` or
  similar by pattern, but I do not know this — inventing a filename would be an unearned
  inference, flagged as Γ below).
- **"The bipartite file" is referenced repeatedly (both URS files) but never given an exact
  path.** Phrases like "the bipartite file's `marginalFst_singleton` /
  `uniform_eq_product_iff_isRect` machinery" and "mirror the bipartite file" occur multiple
  times; I could not resolve which file this is (likely `MutualInformation.lean`, given the
  import list, but this is my inference, not a stated fact — flagged Γ).
- **Placeholder-to-final divergence (not a contradiction, a resolution — noted for
  precision).** The discovery URS's pre-write forecast used a placeholder constant
  `pinskerConst` ("`TC(unif κ) ≥ pinskerConst · (hcCombPi κ / |κ|^n)² > 0`"); the shipped
  theorem fixes this to the literal constant `2`. This is not a divergence between two live
  claims but a design-forecast being resolved by the final write — I flag it only so the
  synthesis does not read "pinskerConst" and "2" as two different competing claims about the
  constant.
- **Internal-programme cross-references named, not verified by me:** `FIELD_NOTE.md`
  ("zetesis-puremath canonical copy," named as the "Frame document" for the noological URS);
  `zetesis-puremath` (a repository/programme name, referenced as where "field-note ledger
  updates" should be "ported"); `mathlib-search` (a tool name, referenced repeatedly as the
  flooring mechanism — consistent with the user's memory index entry describing a
  "mathlib-search skill in design-lab," but I note this only as external corroboration of the
  tool's existence, not as something verified from within my slice); "§10 program" and "the
  crypto pipeline" (two other named programme threads this result is claimed to also serve,
  per Γ_core — not otherwise described in my slice).
- **No contradiction found between the `.lean` file and its two companion URS files.** Every
  theorem name, statement shape, and proof-route claim in the two URS files that I could
  cross-check against the actual `.lean` source was consistent with it (the KU-1/KU-3 closures
  matching `two_sq_sub_le_klDivReal` and `klDivReal_nonneg` usage; the
  `absolutelyContinuous_pi_marginal` A4-catch matching the lemma's actual unconditional
  signature; the final theorem shapes matching the forecast shapes modulo the
  placeholder-constant resolution noted above). I flag this as a positive consistency check,
  not a finding of divergence.

---

## Agent-axis ignorance (Γ) — my own, as miner

Per carrier: this is *my* ignorance mining this slice, distinct from the *object-level* Γ
content (the builder's own agent-axis record) which I extracted above as part of the object
axis (γ) — that record is field content I mined, not my own state.

- **Γ-1 (import boundary, acknowledged not resolved).** I did not read the five imported
  modules (`Multipartite`, `MutualInformation`, `TotalCorrelation/Def`, `Pinsker/Basic`,
  `KullbackLeibler/FiniteSupport`). This was a deliberate scope decision consistent with my
  slice assignment (only the three named files), not an oversight, but it means I cannot
  independently verify the *exact* statements of `hcCombPi`, `projPi`, `hullPi`, `hcComb`,
  `mutualInformationReal`, `klDivReal`, or `two_sq_sub_le_klDivReal` beyond how they are *used*
  in my slice's file. Everything I report about their exact signatures is either (a) directly
  read off their use-sites in `ApproximateFiveWay.lean` (reliable — the use-site pins the
  type/signature that must exist) or (b) transcribed from the two companion URS files'
  descriptions (their claim, not my independent read).
- **Γ-2 (unresolved citation, correctly left open).** The Atserias-Kolaitis attribution has no
  id anywhere in my slice. I did not attempt to search externally or guess a candidate paper —
  this is a genuine open item for the synthesis/PI to resolve, not a gap in my reading.
- **Γ-3 ("the bipartite file" / `fiveWay_uniform` / `fiveWay_full` — unresolved filenames).** I
  could not determine the exact file path for what both URS files repeatedly call "the
  bipartite file," nor locate the statements of `fiveWay_uniform`/`fiveWay_full` referenced in
  the module docstring. My best inference (not asserted as fact) is that "the bipartite file"
  is `MutualInformation.lean` given the import list and that `hcComb`/`uniformMeasure` are
  defined there, and that `fiveWay_uniform`/`fiveWay_full` live in a sibling module not imported
  by my slice's file at all (since they are not in the import list) — possibly a module this
  file's proofs do not directly depend on but which the *docstring* frames against. This is
  UK on my part, explicitly flagged, not promoted to a finding.
- **Γ-4 ("Pcorr-style mass-shifting" separation witness — named, not locatable).** The discovery
  URS's C4 A4 pre-check mentions "the separation witness Pcorr-style mass-shifting kills the
  bound" when justifying that the floor hypothesis is load-bearing. I could not identify what
  "Pcorr" refers to (possibly a named prior construction/counterexample elsewhere in the HC
  corpus) — flagged as an unresolved internal reference, not chased further since it is outside
  my three assigned files.
- **Γ-5 (no independent kernel re-verification).** Per carrier instruction, I did not attempt to
  re-verify the Lean proofs against the kernel (e.g., by compiling); I extracted the theorem
  *statements* faithfully from source and treated the mathematics as strictly true per the
  carrier's standing instruction. My confidence in the *statements* (I transcribed them
  character-for-character from the Read tool output) is high; my confidence that the *proofs*
  actually kernel-check is inherited entirely from the carrier's premise and the discovery URS's
  self-report ("GREEN + installed, 0 sorry, warningAsError"), which I did not independently
  confirm by running Lean.
- **Γ-6 (scope of "quantitative" claim precisely bounded).** I want to flag precisely, for the
  synthesis, exactly which inequality the slice note's headline formula corresponds to, since
  the slice note's LaTeX-ish rendering (`2 (hcCombPi/|k|^n)^2 <= total correlation <= counting
  bound`) is a paraphrase, not a verbatim quotation from any single file. The verbatim source
  pieces are: LOWER = `lower_totalCorrelationReal_uniform`'s
  `2 * ((hcCombPi κ : ℝ) / (κ.card : ℝ) ^ Fintype.card ι) ^ 2 ≤ totalCorrelationReal
  (uniformMeasurePi κ hκ)`; UPPER = `totalCorrelationReal_uniform_le`'s `totalCorrelationReal
  (uniformMeasurePi κ hκ) ≤ Real.log (((hullPi κ).card : ℝ) / κ.card)`. These are two *separate*
  theorems in the file (not literally chained into one sandwich statement anywhere in the
  source); the "sandwich" reading is a true and direct combination of the two (both bound the
  same quantity `totalCorrelationReal (uniformMeasurePi κ hκ)` from below and above
  respectively) but I flag that no single theorem in my slice states the combined two-sided
  inequality as one Lean statement — this is my own reconstruction, clearly presented as such,
  and I regard it as a low-risk `act(describe)` combination (not an `act(imagine)` link) since
  both bounds are explicitly, individually proved and share the same LHS quantity.
- **Γ-7 (unread earlier "M3b-era" and "M3d idioms" context).** Both URS files reference "M3b,"
  "M3d," and similar milestone/session labels ("the M3b-era note," "M3d idioms") without
  defining what these refer to. I record their existence as internal process labels but do not
  know what M3a/M3c or the overall milestone scheme is — flagged as UK, not chased (outside
  slice).

None of the above gaps caused me to omit or misreport any theorem, definition, or citation
within my three assigned files — every theorem statement, definition, and citation-bearing
sentence in all three files has been transcribed above. The gaps are entirely at the *cross-tree
boundary* (references to material outside my slice) or *internal-process labels* my slice does
not define.
