# URS_03 — Mutual information and product law

Miner: Sonnet miner 03. Slice: **Mutual information and product law**. Corpus: HC / Hidden
Channel Capacity / "Shape of Ignorance" programme (Layer 3, mined not invoked). Object axis
(γ) and agent axis (Γ) are kept in separate sections throughout, per the noological carrier.

## Files mined

All three assigned files were read in full, end to end, via the Read tool on their absolute
paths.

1. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/MutualInformation.lean`
   (430 lines, full file). Closes the information-theoretic leg of the Five-Way equivalence.
2. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/ProductLaw.lean`
   (159 lines, full file). Proves the Leibniz rule for the defect under juxtaposition
   (disjoint-interface product) of ignorance structures.
3. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/PRODUCT_LAW_URS.md`
   (121 lines, full file). The URS instrument that predicted, then verdicted, the candidate
   product laws for `ProductLaw.lean`; contains the Γ (imagination) record and the Γ-yield
   (rotation back into field content) for the AK-monoid codomain decision.

I additionally performed bounded, citation-grounding lookups (grep + targeted partial reads,
not full-file reads) into files outside my slice, strictly to transcribe *verbatim* the exact
statements my slice's theorems compose with or my slice's URS names by identifier. These are
recorded as cross-tree references in their own section below, not claimed as "mined" content
of this slice:
   - `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/InformationTheory/MutualInformation/ZeroIffProduct.lean`
     (read in full — 42 lines — because `MutualInformation.lean`'s headline theorem literally
     rewrites with this lemma; its statement is load-bearing for correctly tagging my slice's
     own headline result).
   - `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/Combinatorial.lean`
     (grep for specific def/theorem signatures only: `projL`, `projR`, `IsRect`, `hcComb`,
     `hcComb_eq_zero_iff_isRect`, `isRect_iff_cross_closed` — partial read of lines 75-104 to
     get exact statements of the two theorems my `fiveWay_uniform` composes with).
   - `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/Multipartite.lean`
     (grep for specific def signatures only: `projPi`, `hullPi`, `hcCombPi`, `subset_hullPi`).
   - Grep-only existence checks (no content read) confirming `hcCombPi_projS_le` lives in
     `Marginals.lean` and `totalCorrelationReal_uniform_le` lives in `ApproximateFiveWay.lean`,
     both named by `PRODUCT_LAW_URS.md` as evidence for its Γ-yield claims — these two files
     belong to other miners' slices and are NOT mined here beyond confirming the identifier
     exists at the named location.

## Theorems and definitions (each tagged)

### From `MutualInformation.lean`

**Purpose statement [STANCE]** (docstring, lines 12-33): "The combinatorial layer
(`ZPM.Measurements.HC.Combinatorial`) proves `hcComb κ = 0 ↔ IsRect κ`: the support-level
hidden channel capacity vanishes exactly when `κ ⊆ α × β` factors as the product of its
marginal supports. This file adds the **information-theoretic** characterization and closes
the Five-Way equivalence." The docstring frames the claim as: put the uniform probability
distribution on the admissible set `κ`; then `mutualInformationReal (uniformMeasure κ hκ) = 0
↔ IsRect κ`. It further states the proof-strategy rationale [STANCE]: "The mutual information
is the Kullback–Leibler divergence of the joint from the product of its marginals... on a
finite discrete space the relevant absolute-continuity and finite-KL side conditions hold
automatically, so MI `= 0` collapses to the joint equalling the product of marginals, which at
singleton level is precisely cross-closedness of the support."

- **`uniformMeasure`** [def] (line 55) — `def uniformMeasure (κ : Finset (α × β)) (hκ :
  κ.Nonempty) : Measure (α × β) := (PMF.uniformOfFinset κ hκ).toMeasure`. The uniform
  probability measure on the admissible set `κ`, built from Mathlib's `PMF.uniformOfFinset`.
- **Probability-measure instance** [KV] (line 58-60) — `uniformMeasure κ hκ` is an
  `IsProbabilityMeasure`, proved by unfolding and `infer_instance`.
- **`card_pos_enn`** [KV] (lines 65-69) — `κ.card` is positive as an `ℝ≥0∞` when `κ` is
  nonempty.
- **`cardinv_pos`** [KV] (lines 74-77) — `(κ.card : ℝ≥0∞)⁻¹` is positive.
- **`uniformMeasure_singleton`** [KV] (lines 81-88) — the joint mass on a singleton `x` is
  `(κ.card)⁻¹` if `x ∈ κ`, else `0`.
- **`uniformMeasure_singleton_pos`** [KV] (lines 91-96) — a pair has positive joint mass iff it
  is admissible (`x ∈ κ`).
- **`rowCount`** [def] (line 101) — `def rowCount (κ : Finset (α × β)) (a : α) : ℕ :=
  (κ.filter (fun p => p.1 = a)).card`. The left-fiber (row) count.
- **`colCount`** [def] (line 104) — `def colCount (κ : Finset (α × β)) (b : β) : ℕ :=
  (κ.filter (fun p => p.2 = b)).card`. The right-fiber (column) count.
- **`marginalFst_singleton`** [KV] (lines 106-130) — the left-marginal mass on a singleton
  `{a}` equals `rowCount κ a / κ.card` (in `ℝ≥0∞`).
- **`marginalSnd_singleton`** [KV] (lines 132-155) — the right-marginal mass on `{b}` equals
  `colCount κ b / κ.card`.
- **`rowCount_pos_iff`** [KV] (lines 160-169) — `rowCount κ a > 0 ↔ a ∈ projL κ`.
- **`colCount_pos_iff`** [KV] (lines 174-183) — `colCount κ b > 0 ↔ b ∈ projR κ`.
- **`marginalFst_pos_iff`** [KV] (lines 186-195) — left-marginal singleton mass positive `↔ a
  ∈ projL κ`.
- **`marginalSnd_pos_iff`** [KV] (lines 198-207) — right-marginal singleton mass positive `↔ b
  ∈ projR κ`.
- **`product_singleton`** [KV] (lines 213-221) — the mass of `{x}` under the product of
  marginals factors as `(marginal fst {x.1}) * (marginal snd {x.2})`, via `{x} = {x.1} ×ˢ {x.2}`
  and `Measure.prod_prod`.
- **`product_singleton_pos_iff`** [KV] (lines 224-235) — a singleton has positive
  product-of-marginals mass iff both coordinates lie in their respective projected supports
  (`x.1 ∈ projL κ ∧ x.2 ∈ projR κ`).
- **`uniform_absolutelyContinuous`** [KV] (lines 240-274) — the joint is absolutely continuous
  w.r.t. the product of its marginals. Proved by reducing to singletons: if the product mass on
  `{x}` is `0`, membership fails one side of `product_singleton_pos_iff`, hence `x ∉ κ`, hence
  the joint mass is `0` too; then extended from singletons to arbitrary (finite) sets via
  `sum_measure_singleton`.
- **`uniform_klDiv_ne_top`** [KV] (lines 278-287) — on a finite discrete space the KL divergence
  of the joint from the product of its marginals is finite (`≠ ⊤`), via
  `InformationTheory.klDiv_ne_top` plus `Integrable.of_finite`.
- **`uniform_eq_product_iff_isRect`** [KV] (lines 292-397) — **the bridge lemma**: `uniformMeasure
  κ hκ = product of its marginals ↔ IsRect κ`. Forward direction: joint = product implies, for
  every `a ∈ projL κ`, `b ∈ projR κ`, that `(a,b)` has positive product mass hence positive
  joint mass hence `(a,b) ∈ κ`, which via `isRect_iff_cross_closed` gives `IsRect κ`. Reverse
  direction: given `IsRect κ` (hence cross-closedness), shows joint and product agree on every
  singleton via `Measure.ext_of_singleton`, working out `rowCount`/`colCount` explicitly as
  `(projR κ).card`/`(projL κ).card` (or `0`) depending on membership in `projL κ`/`projR κ`, and
  using `κ.card = (projL κ).card * (projR κ).card` (from `κ = projL κ ×ˢ projR κ`) to cancel the
  `ENNReal` arithmetic down to equality. This is the longest, most computational proof in the
  slice.
- **`mutualInformationReal_uniform_eq_zero_iff_isRect`** [KV] — **THE HEADLINE THEOREM** (lines
  401-411). Docstring [STANCE]: "**The information-theoretic leg of HC.** The uniform
  distribution on the admissible set `κ` has zero mutual information between its two
  coordinates iff `κ` is rectangular (factors as the product of its marginal supports)."
  Statement: `InformationTheory.mutualInformationReal (uniformMeasure κ hκ) = 0 ↔ IsRect κ`.
  Proof: rewrites with the imported `InformationTheory.mutualInformationReal_eq_zero_iff_product`
  (instantiated with `uniform_absolutelyContinuous` and `uniform_klDiv_ne_top` as the two side
  conditions), then closes with `uniform_eq_product_iff_isRect`.
- **`fiveWay_uniform`** [KV] — **FIVE-WAY CLOSURE** (lines 413-425). Docstring [STANCE]:
  "**Five-Way closure.** All four legs are equivalent: rectangularity, zero combinatorial
  defect, zero mutual information of the uniform distribution, and cross-closedness of the
  support." Statement: `List.TFAE [IsRect κ, hcComb κ = 0, InformationTheory.mutualInformationReal
  (uniformMeasure κ hκ) = 0, (∀ a ∈ projL κ, ∀ b ∈ projR κ, (a, b) ∈ κ)]`. Proved via
  `tfae_have`/`tfae_finish` chaining three biconditionals: `1 ↔ 2` is
  `hcComb_eq_zero_iff_isRect` (imported from `Combinatorial.lean`, symm'd), `1 ↔ 3` is this
  file's own `mutualInformationReal_uniform_eq_zero_iff_isRect` (symm'd), `1 ↔ 4` is
  `isRect_iff_cross_closed` (imported from `Combinatorial.lean`). NOTE despite the theorem's
  docstring saying "Five-Way" and "four legs," the `TFAE` list literally contains exactly four
  items — see Agent-axis ignorance below for the naming tension this raises (not resolved
  within this slice; likely resolved by a fifth leg proved elsewhere in the tree, outside my
  files).

### From `ProductLaw.lean`

**Purpose statement [STANCE]** (docstring, lines 12-30): "Juxtaposition and the derivation
law. The disjoint-interface product of ignorance structures: for `κ₁` over `ι₁` and `κ₂` over
`ι₂`, `sumRel κ₁ κ₂` is the relation over `ι₁ ⊕ ι₂` whose configurations restrict to a `κ₁`-
and a `κ₂`-configuration." States three properties under this operation: size is
multiplicative (`card_sumRel`), hull is multiplicative on nonempty structures
(`hullPi_sumRel`), and the defect obeys the **Leibniz rule** (`hcCombPi_sumRel`): `hcCombPi (κ₁
⊗ κ₂) = hcCombPi κ₁ · |hull κ₂| + |κ₁| · hcCombPi κ₂`. Further [STANCE]: "The defect is a
derivation, not a homomorphism: the kernel-swept refutations of the multiplicative and
additive candidate laws are recorded in `PRODUCT_LAW_URS.md`. The homomorphic invariant under
juxtaposition is the pair (hull size, size) in `(ℕ × ℕ, ×)`; the defect is its
difference-derivation, and the additive form of the grading is `log(|hull|/|κ|)` — exactly the
counting bound of the approximate five-way's upper leg. Nonemptiness in the hull and Leibniz
laws is sharp at the empty-index corner (the hull of the empty structure over no parts is the
unit configuration, not empty), the third independent appearance of that boundary."

- **`instDecidableEqSumElim`** [KV/def] (lines 40-44) — instance: decidable equality on a
  summed family `Sum.elim X₁ X₂ i`, componentwise, given decidable equality on each factor
  family.
- **`instFintypeSumElim`** [KV/def] (lines 46-50) — instance: finiteness of a summed family,
  componentwise.
- **`sumRel`** [def] — **JUXTAPOSITION** (lines 55-59). Docstring [STANCE]: "the disjoint-
  interface product: the relation over `ι₁ ⊕ ι₂` whose configurations restrict to a `κ₁`- and a
  `κ₂`-configuration." Statement: `def sumRel (κ₁ : Finset (∀ i, X₁ i)) (κ₂ : Finset (∀ i, X₂
  i)) : Finset (∀ i : ι₁ ⊕ ι₂, Sum.elim X₁ X₂ i) := (κ₁ ×ˢ κ₂).image (Equiv.prodPiEquivSumPi X₁
  X₂)`. Built from the product `κ₁ ×ˢ κ₂` pushed forward along Mathlib's
  `Equiv.prodPiEquivSumPi` (the "pi-over-sum" equivalence).
- **`mem_sumRel`** [KV] (lines 63-75) — membership in a juxtaposition is componentwise
  membership: `f ∈ sumRel κ₁ κ₂ ↔ (fun i => f (Sum.inl i)) ∈ κ₁ ∧ (fun i => f (Sum.inr i)) ∈
  κ₂`.
- **`card_sumRel`** [KV] — **MULTIPLICATIVITY OF SIZE** under juxtaposition (lines 78-81).
  Statement: `(sumRel κ₁ κ₂).card = κ₁.card * κ₂.card`. Proved via `card_image_of_injective`
  (the equivalence is injective) composed with `Finset.card_product`. Holds unconditionally —
  no `Nonempty` hypothesis needed (confirmed also by the verdict table in
  `PRODUCT_LAW_URS.md`, see below).
- **`projPi_sumRel_inl`** [KV] (lines 84-99) — the left projections of a juxtaposition equal
  the left factor's projections, GIVEN the right partner `κ₂` is nonempty (`hκ₂ : κ₂.Nonempty`).
  Statement: `projPi (sumRel κ₁ κ₂) (Sum.inl i) = projPi κ₁ i`.
- **`projPi_sumRel_inr`** [KV] (lines 101-117) — symmetric statement for the right projections,
  given `κ₁` nonempty.
- **`hullPi_sumRel`** [KV] — **MULTIPLICATIVITY OF THE HULL** under juxtaposition, on nonempty
  structures (lines 119-138). Docstring [STANCE] flags the sharpness boundary explicitly:
  "Sharp at the empty-index corner: the hull of the empty structure over no parts is the unit
  configuration." Statement: given `hκ₁ : κ₁.Nonempty`, `hκ₂ : κ₂.Nonempty`, `hullPi (sumRel κ₁
  κ₂) = sumRel (hullPi κ₁) (hullPi κ₂)`.
- **`hcCombPi_sumRel`** [KV] — **THE LEIBNIZ RULE FOR THE DEFECT**, the file's headline result
  (lines 140-156). Docstring [STANCE]: "under juxtaposition the hidden-channel defect is a
  derivation over the multiplicative pair (hull size, size)... The defect is not a
  homomorphism (the multiplicative and additive candidate laws are refuted by kernel sweep);
  the homomorphic invariant is the bi-grading, and the defect is its difference-derivation."
  Statement: given `hκ₁ : κ₁.Nonempty`, `hκ₂ : κ₂.Nonempty`, `hcCombPi (sumRel κ₁ κ₂) = hcCombPi
  κ₁ * (hullPi κ₂).card + κ₁.card * hcCombPi κ₂`. Proof: uses `κ₁.card ≤ (hullPi κ₁).card` and
  `κ₂.card ≤ (hullPi κ₂).card` (from `subset_hullPi`, imported from `Multipartite.lean`),
  rewrites `hcCombPi` and `hullPi_sumRel`/`card_sumRel`, then closes the `ℕ`-truncated-
  subtraction identity by lifting to `ℤ` (`zify` with the two `≤` facts plus
  `Nat.mul_le_mul h1 h2` to license the lift of the product term) and finishing with `ring`.

### From `PRODUCT_LAW_URS.md`

This is a URS instrument document, not raw Lean — it contains explicit Γ (agent-imagination)
content and γ (field/object) content in labeled, separated sections, matching the noological
carrier's own two-axis discipline. I record its structure faithfully, tagging each piece.

**Γ section — "the imagination, engineered" (lines 9-54)**

- **[STANCE] Will snapshot (A)**: "Decide what the grading codomain must be by PROVING the law
  family the juxtaposition operation forces, on the kernel. The field note (§5) says 'a
  monotone grading into a constructive ordered monoid' with the codomain open — this tick is
  the experiment that closes part of that KU." [Note: "the field note (§5)" is referenced but
  not identified further within this document — I cannot resolve which document "the field
  note" is; flagged under Agent-axis ignorance.]
- **[STANCE] Operation algebra (R-move)**: three operations are named as "composable" on "the
  substrate grammar": (1) `⊗` juxtaposition/disjoint interface — "THIS TICK'S OBJECT," the
  subject of `ProductLaw.lean`; (2) `∪` same-index union — flagged: "hull can JUMP
  (cross-recombination — the oscillation theorem's own mechanism), so no valuation-like law is
  expected; a refutation here is a boundary worth one sweep, not a build" [CONJ/STANCE,
  predictive, pre-sweep]; (3) `×_S` fiber product over a shared interface — "the AK-consistency
  operation proper; degenerates to ⊗ at S = ∅. Where the Leibniz law should FAIL is where H¹
  lives — flagship-adjacent, scheduled AFTER Vorob'ev... NOT this tick." [STANCE, explicitly
  scoped out of this document's build.]
- **[STANCE] Pl_imagine self-audit**: "My token-level prior pattern-matches 'defect' to
  'norm/valuation' and wants d(⊗) = d·d' or d + d'. That analogy is EXACTLY the kind of
  plausible structure 2.3 gates: recorded below as L-mult/L-add with verdict EXPECT-KILL,
  because the in-model arithmetic (next) contradicts them — the sweep will arbitrate between my
  arithmetic and my analogy." This is explicit first-person Γ-axis self-audit by the document's
  author, distinguishing a plausible-but-wrong analogical prior from an in-model derived
  prediction, BEFORE the kernel sweep. Tagged [STANCE] (interpretive/positioning,
  author-labeled as imagination).
- **[CONJ] The in-model derivation** (imagine, explicitly gated per the document's own
  labeling): writing `Hᵢ = |hullᵢ|`, `kᵢ = |κᵢ|`, `dᵢ = Hᵢ − kᵢ`, "IF hull and card are
  multiplicative under `⊗` (L-hull, L-card below), THEN `d(κ⊗κ') = H₁H₂ − k₁k₂ = (H₁−k₁)H₂ +
  k₁(H₂−k₂) = d₁H₂ + k₁d₂`" — named explicitly as "the Leibniz rule of a derivation, not a
  homomorphism law." Two consequences are drawn, both flagged as pre-experiment predictions:
  1. "The homomorphic invariant under `⊗` is the PAIR `(H, k)` in `(ℕ × ℕ, ×)`; the defect is
     the difference-derivation of that bi-grading. The AK 'codomain knob' answer this predicts:
     the ordered-monoid codomain of the signature is the bi-graded `ℕ × ℕ` (equivalently the
     fill-fraction `k/H` multiplicatively), and `hcComb` alone is its shadow — monotone (proved,
     `hcCombPi_projS_le`) but not homomorphic." [Note: `hcCombPi_projS_le` is cited here as
     already proved, located (per my bounded grep) in `Marginals.lean` — outside my slice.]
  2. "The ADDITIVE form: `log(H/k)` is additive under `⊗` — and `log(H/k)` is exactly the
     counting bound of the approximate five-way's upper leg (`totalCorrelationReal_uniform_le`).
     So the additive grading the monoid wants is the same quantity the information face
     already bounds: a three-face coincidence (combinatorial bi-grading, additive log-form, TC
     upper bound) predicted in-model. If the sweep sustains L-hull/L-card, this coincidence is a
     theorem chain." [Note: `totalCorrelationReal_uniform_le` cited here, located (per my
     bounded grep) in `ApproximateFiveWay.lean` — outside my slice. This is a **PROBE-adjacent
     predictive claim of a "three-face coincidence"** — I flag it as [CONJ], made explicitly
     pre-sweep, contingent on "if the sweep sustains."]
- **[CONJ] The (∅, ∅)-corner standing hypothesis**: "Twice now (hull-commutation,
  monotonicity) the sole failure class was the empty structure/empty index. Prediction: L-hull
  fails at empty FACTORS... and is repaired by `Nonempty` on both; the empty-INDEX corners are
  benign (a factor over no parts is the unit `{emptyFn}` of `⊗`... another monoid datum). Sweep
  includes all corners." This references two prior instances ("hull-commutation,
  monotonicity") of the same boundary pattern, located elsewhere in the tree (not in my
  slice — cannot verify file locations from my assigned files alone; flagged under Agent-axis
  ignorance).

**γ section — "the candidate family (recorded BEFORE kernel contact)" (lines 57-77)**

Object under test: `sumRel κ₁ κ₂ : Finset (∀ i : ι₁ ⊕ ι₂, Sum.elim X₁ X₂ i)`, "the image of
`κ₁ ×ˢ κ₂` under the pi-over-sum equivalence."

Candidate-law table, transcribed verbatim [each row tagged CONJ at time of recording — these
are pre-sweep predictions with named provenance and named expected verdicts]:

| id | statement | Γ-provenance | expected |
|----|-----------|--------------|----------|
| L-card | `(sumRel κ₁ κ₂).card = κ₁.card * κ₂.card` | image of a product under an injection | HOLD (uncond.) |
| L-hull | `hullPi (sumRel κ₁ κ₂) = sumRel (hullPi κ₁) (hullPi κ₂)` | projections of a product are factor projections, IF partner nonempty | HOLD with both `Nonempty`; KILL at an empty factor |
| L-Leibniz | `hcCombPi (sumRel κ₁ κ₂) = hcCombPi κ₁ * (hullPi κ₂).card + κ₁.card * hcCombPi κ₂` | the in-model arithmetic above | HOLD with both `Nonempty` |
| L-mult | `hcCombPi (sumRel κ₁ κ₂) = hcCombPi κ₁ * hcCombPi κ₂` | norm-analogy (Pl_imagine, gated) | KILL |
| L-add | `hcCombPi (sumRel κ₁ κ₂) = hcCombPi κ₁ + hcCombPi κ₂` | valuation-analogy (Pl_imagine, gated) | KILL |
| L-unit | `sumRel` with the empty-index unit `{emptyFn}` is identity (up to the equiv) | monoid structure of `⊗` | HOLD (statement deferred: reindexing equiv needed; recorded, not this build) |
| B-union | `hcCombPi (κ₁ ∪ κ₂) ≤ hcCombPi κ₁ + hcCombPi κ₂` (same index, both nonempty) | subadditivity guess (Pl_imagine, gated); hull-jump argues AGAINST | sweep-only; verdict = boundary datum either way |

**[STANCE] Coupling-points note** (lines 73-77): "L-mult/L-add are kept IN the record although
the in-model arithmetic already contradicts them: if the sweep kills them (expected), the kill
certifies the arithmetic AND the Γ-yield 'the grading is a derivation, not a homomorphism'
becomes evidence-backed, not narrative. If the sweep SUSTAINS one of them, my in-model
arithmetic is wrong somewhere upstream (L-card or L-hull) — either way the rotation produces
content." This is an explicit falsifiability design note: the document commits, in writing, to
what each possible sweep outcome would mean, before running the sweep.

**Verdicts + Γ-yield section (lines 79-121)**

Verdict table, transcribed verbatim [each row tagged: the "verdict" column is [decide] — a
finite/kernel check outcome — the "disposition" column names the corresponding proved Lean
artifact where applicable, [KV]]:

| id | verdict (sweep) | disposition |
|----|-----------------|-------------|
| L-card | HOLD, unconditional (incl. empties, incl. empty index) | PROVED `card_sumRel` |
| L-hull | HOLD universally at nonempty INDICES (empty factors benign — better than predicted); KILLED at empty index with nonempty κ₁, empty κ₂ (hull of ∅ over no parts = unit); guarded form re-swept clean | PROVED `hullPi_sumRel` with both `Nonempty` |
| L-Leibniz | same profile as L-hull | PROVED `hcCombPi_sumRel` (zify+ring on the ℕ-sub) |
| L-mult | KILLED at n = (2,2) | recorded: the defect is NOT multiplicative |
| L-add | KILLED at n = (2,2) | recorded: the defect is NOT additive |
| L-unit | deferred (reindexing equiv) | named edge |
| B-union | KILLED (both-nonempty subadditivity fails) | boundary datum: the hull-jump under union is real; the grading is not a valuation. The jump is the oscillation theorem's mechanism, now with a quantitative witness class |

**[STANCE/PROBE-adjacent] Γ-yield — "the rotation's return leg (the codomain decision)"**
(lines 93-111), transcribed with tags per numbered point:

1. [STANCE, evidence-grounded per the table above] "The kill-pattern certifies the in-model
   arithmetic over the norm/valuation analogies: the defect is a **derivation**, not a
   homomorphism. The homomorphic invariant of `⊗` is the bi-grading `(|hull|, |κ|)` in `(ℕ ×
   ℕ, ×)`; `hcCombPi` is its difference-derivation (Leibniz), monotone along restriction
   (`hcCombPi_projS_le`), NOT monotone under union."
2. [STANCE] **"Signature revision recommended to the field note (§5)"**: "'a monotone grading
   into a constructive ordered monoid' should read: *the grading is the bi-graded pair `(hull,
   size) : ℕ × ℕ` (multiplicative under juxtaposition, componentwise monotone along
   restriction); the hidden-channel defect is its difference-derivation; the additive scalar
   form is `log(hull/size)`, which the information face independently bounds
   (`totalCorrelationReal_uniform_le`).* The AK 'monoid knob' answer at the disjoint interface:
   `(ℕ × ℕ, ×)`, with the scalar shadows (ℕ-difference, ℝ-log-ratio) derived, not primitive."
   This is explicitly a *recommendation to revise* another document ("the field note (§5)"),
   not itself a claim that the revision has been made — flagged accordingly.
3. [STANCE] "The Γ-corner ledger: the empty-index/empty-structure boundary appeared a THIRD
   independent time (hull-commutation, monotonicity, now the product laws), always via 'the
   empty product over no parts is the unit.' This is now a named structural constant of the
   theory (the `⊗`-unit), not a nuisance: L-unit's deferred statement will make it the monoid
   identity." [The prior two instances, "hull-commutation" and "monotonicity," are named but
   not located within my slice — flagged under Agent-axis ignorance.]
4. [STANCE] "Prediction-audit: my corner-prediction for L-hull was wrong in the BENIGN
   direction (empty factors are fine; only the empty index bites). Recorded to recalibrate: the
   corner lives in the INDEX grammar, not the structure lattice." This is an explicit
   post-sweep self-correction of the pre-sweep prediction recorded in the Γ section — the
   author's own prediction ("KILL at an empty factor," per the L-hull row of the candidate
   table) is here marked as having been wrong, and the actual failure mode (empty index, not
   empty factor) is recorded as the corrected lesson.

**[STANCE] Build note** (lines 113-115): "`HC/ProductLaw.lean` GREEN + installed, 0 sorry —
`sumRel`, `mem_sumRel`, `card_sumRel`, `projPi_sumRel_inl/inr`, `hullPi_sumRel`,
`hcCombPi_sumRel` (the Leibniz rule), with the componentwise `Sum.elim` instances. Barrel at
thirteen layers." [The phrase "Barrel at thirteen layers" is not explained further within my
assigned files — flagged under Agent-axis ignorance; I did not find an obvious referent in
`ProductLaw.lean` or `MutualInformation.lean` for what a "barrel" or its "layer" count means.]

**[STANCE] Next-edges note** (lines 117-120): "the fiber product `×_S` over a genuine
interface (where Leibniz should FAIL and H¹ lives — the Vorob'ev-adjacent tick; PhysLean now on
loogle for the quantum instances after that); L-unit as the `⊗`-monoid identity; the
total-correlation additivity under `⊗` at the measure level (the informational face of the
Leibniz law)." These are explicitly named as future/deferred work, not claims of completed
results. `FiberProduct.lean` and `VorobevConverse.lean` exist as sibling files in the HC
directory (confirmed by directory listing only, not content-read — see the file-listing note
under Agent-axis ignorance) and plausibly correspond to this deferred work, but I make no claim
about their content since they are outside my slice.

## Citations

**No citations to external literature (authors/year/title/arXiv-id/DOI) appear anywhere in
any of my three assigned files.** I read all three files in full and found zero instances of
named external works. All references in my slice are internal cross-references to other files
or theorems within the same Lean project (e.g., `Combinatorial.lean`, `Multipartite.lean`,
`ZeroIffProduct.lean`, `Marginals.lean`, `ApproximateFiveWay.lean`, and the unresolved "field
note (§5)"), none of which constitute a literature citation in the sense the carrier's citation
protocol targets (author, year, title, arXiv/DOI). Per the carrier's explicit instruction
("Never fabricate a citation... If an identifier is absent, write 'no id given'"), I report
truthfully: **no external citations exist in this slice** rather than inventing a citations
table to fill the deliverable's structure. I do not infer or backfill outside knowledge about
what such citations might have been (e.g., standard information-theory references for mutual
information / KL divergence) since the carrier explicitly gates `act(imagine)` and forbids
inventing connections.

## Literature-audit verdicts

**No literature-audit verdicts (no-ancestor, killed target, boundary/Pl-kill, "appears in no
examined work," novelty claims against external literature) appear in any of my three assigned
files.** The verdicts present in `PRODUCT_LAW_URS.md` are **kernel-sweep verdicts** (HOLD/KILL
against Lean-provable candidate laws, i.e., internal decidable/proof-search checks against the
formalization itself — tagged [decide]/[KV] above), not literature-search verdicts against
external published work. I distinguish these carefully per the carrier's KV/PROBE distinction:
the carrier defines [PROBE] specifically as "a literature-audit verdict (novelty, no-ancestor,
boundary), asserted in prose" — none of the verdicts in my slice are of that kind. I flag this
explicitly rather than mistagging a kernel-sweep HOLD/KILL as a [PROBE] literature verdict.

## Cross-tree / divergence notes

- **Docstring vs. TFAE-list count tension.** `MutualInformation.lean`'s `fiveWay_uniform`
  theorem is documented as "**Five-Way closure.** All four legs are equivalent" (docstring,
  line 414) yet the `List.TFAE` it proves literally contains four items (`IsRect κ`, `hcComb κ =
  0`, MI `= 0`, cross-closed), not five. The docstring itself says "four legs" in the very next
  clause, so the docstring is internally consistent (naming the theorem "Five-Way" while
  describing "four legs" proved here) — but this raises the question of where the fifth leg of
  a "Five-Way" equivalence is proved. I cannot resolve this from my slice alone; a fifth leg
  (likely a support-cardinality or entropy-based criterion) is presumably proved in a sibling
  file (candidates by name alone, not content: `FiveWayPi.lean`, `ApproximateFiveWay.lean` —
  both siblings in the HC directory per file listing). This is recorded as an open
  cross-reference, not resolved.
- **`PRODUCT_LAW_URS.md`'s "field note (§5)" is never identified.** The document twice
  references "the field note (§5)" as the source of the phrase "a monotone grading into a
  constructive ordered monoid" and as the target of a recommended signature revision. No
  filename or path is given anywhere in my three assigned files. This is a genuine unresolved
  cross-reference (see Agent-axis ignorance).
- **`PRODUCT_LAW_URS.md` cites two theorems as already-proved evidence
  (`hcCombPi_projS_le`, `totalCorrelationReal_uniform_le`) that live outside my slice.** I
  confirmed by grep (not content-read) that `hcCombPi_projS_le` is declared in
  `HC/Marginals.lean` (line 92) and `totalCorrelationReal_uniform_le` is declared in
  `HC/ApproximateFiveWay.lean` (line 322), and that both are referenced again in
  `HC/HIGHER_OBSTRUCTION_DISCOVERY_URS.md` and `HC/APPROX_FIVEWAY_DISCOVERY_URS.md`
  respectively (filenames only, from grep — I did not read these documents' content). This
  strongly suggests these two results and their associated URS documents belong to a different
  miner's slice in this fan; I flag the connection explicitly so the Opus synthesis can stitch
  the "three-face coincidence" claim ((1) combinatorial bi-grading Leibniz, (2) additive
  log-form, (3) total-correlation upper bound) across slices, since no single slice (mine
  included) contains all three legs' proofs.
- **The `PRODUCT_LAW_URS.md` document is itself an exemplar of the carrier's own Γ/γ
  discipline.** It is worth flagging structurally (not as a finding to imagine, but as an
  observed fact about the corpus): this URS separates "Γ — the imagination, engineered" from
  "γ — the candidate family" from "Verdicts + Γ-yield" as three explicit, labeled sections,
  and each candidate law in the γ table carries a "Γ-provenance" column naming exactly which
  imaginative move (analogy, in-model derivation, monoid-structure expectation) produced it.
  This is a docstring/URS-level methodological pattern, present in the object being mined, and
  I record its existence as [STANCE] content of the corpus rather than adopting or extending
  the pattern myself.
- **Internal consistency check: my slice's Lean matches its own URS's disposition table.**
  Cross-checking `ProductLaw.lean`'s actual theorem names against the "disposition" column of
  `PRODUCT_LAW_URS.md`'s verdict table: `card_sumRel`, `hullPi_sumRel`, `hcCombPi_sumRel` all
  exist in the Lean file exactly as named in the URS's disposition column, with the stated
  hypotheses (`Nonempty` guards on `hullPi_sumRel`/`hcCombPi_sumRel`, unconditional
  `card_sumRel`). No divergence found between the URS's claimed build state and the actual
  `.lean` file content for these three. `mem_sumRel`, `projPi_sumRel_inl`, `projPi_sumRel_inr`
  also exist and match the "componentwise `Sum.elim` instances" and helper-lemma description in
  the URS's build note, though these are not separately named in the disposition table (they
  are auxiliary lemmas feeding the three headline results). No contradiction found; this is a
  positive consistency finding, recorded because the carrier asks me to note both duplication
  AND contradiction, and a clean match is worth stating explicitly rather than leaving silent.
  I did NOT independently re-verify the Lean compiles (no kernel/build access in this mining
  task; I take the URS's "GREEN + installed, 0 sorry" claim as [STANCE] per the corpus's own
  self-report, consistent with the carrier's instruction to treat the corpus as strictly true
  while tagging the kind of truth — this is the document's own self-report of a build state,
  which I have not independently re-run).

## Agent-axis ignorance (Γ)

Per the carrier's explicit instruction, these are gaps in **my own** parsing/resolution as a
miner, kept strictly separate from the object-axis content above.

1. **"The field note (§5)" is an unresolved reference.** `PRODUCT_LAW_URS.md` references this
   document twice (as the source of "a monotone grading into a constructive ordered monoid"
   and as the target of a recommended revision) but gives no filename. I could not identify it
   from my three assigned files alone. This is a UK on my agent axis: I know the reference
   exists and roughly what it says, but not which file it names.
2. **"Hull-commutation" and "monotonicity," named as the first two of "three independent"
   occurrences of the empty-index/empty-structure boundary, are not located within my
   slice.** `PRODUCT_LAW_URS.md` names them but does not give file paths. I did not search for
   them beyond my assigned files (this would be scope creep into other miners' territory per
   the fan design), so I record this as an unresolved cross-reference rather than guessing
   which sibling file(s) they live in.
3. **"Barrel at thirteen layers"** (build note, `PRODUCT_LAW_URS.md` line 115) is a phrase I
   could not parse to a concrete referent within my three files. I do not know what a "barrel"
   is in this codebase's vocabulary (possibly an import-aggregation file, given the term's
   common use in some language ecosystems, but I explicitly decline to assert this since it
   would be `act(imagine)`-gated speculation dressed as fact) or what "thirteen layers" counts.
   Recorded as UK, not resolved.
4. **The "fifth leg" of `fiveWay_uniform`'s implied "Five-Way" naming is not in my slice.**
   As noted in Cross-tree notes above, the theorem is named `fiveWay_uniform` and its docstring
   says "Five-Way closure... four legs," proving exactly four TFAE items. I do not know,
   from my slice alone, whether a numerically-fifth leg exists elsewhere in the tree, whether
   "Five-Way" is simply the historical/canonical name of the overall equivalence class (of
   which this file proves a four-item sub-tuple), or whether some other naming convention
   applies. I did not read `FiveWayPi.lean` or other sibling files to resolve this, since doing
   so would exceed my assigned slice; flagged for the Opus synthesis to reconcile against
   whichever other miner's slice covers those files.
5. **I did not read `Combinatorial.lean` or `Multipartite.lean` in full**, only grepped and
   partially read (lines 75-104 of `Combinatorial.lean`) the exact minimum needed to transcribe
   the precise statements of definitions and theorems my slice's files cite by name (`projL`,
   `projR`, `IsRect`, `hcComb`, `hcComb_eq_zero_iff_isRect`, `isRect_iff_cross_closed`,
   `projPi`, `hullPi`, `hcCombPi`, `subset_hullPi`). This was a deliberate, bounded scope
   decision to correctly tag cross-references without inventing meaning, not a coverage gap in
   my assigned slice — but I flag it so the synthesis knows these two files' FULL content
   (docstrings, additional lemmas, any [STANCE]/[PROBE] material they carry) is not covered by
   my URS and must come from whichever miner's slice is assigned those files.
6. **I did not read `ZPM.InformationTheory.MutualInformation.Def`** (the further import of
   `ZeroIffProduct.lean`, which itself defines `mutualInformationReal` and presumably `klDiv`,
   `klDivReal_eq_zero_iff`). I read only `ZeroIffProduct.lean` in full (42 lines) since it is
   the direct, single-hop dependency my headline theorem rewrites with; I did not chase the
   further transitive import chain, which is outside my slice and would grow unboundedly if
   followed to every transitive Mathlib/ZPM dependency. This is a deliberate scope boundary,
   not an oversight, but recorded per the carrier's instruction to report precisely.
7. **No genuine circularity, contradiction, or Pl-kill was found within my slice.** I want to
   record this as a negative finding explicitly (per the carrier: "If two files duplicate or
   seem to contradict, note it") rather than let its absence be read as an oversight: I checked
   the URS's claimed disposition table against the actual Lean theorem names/signatures (see
   Cross-tree notes) and found a clean match, and I checked the docstring claims in both `.lean`
   files against their proved statements and found the docstrings accurately describe what is
   proved (no docstring in my slice claims a stronger result than the Lean states). The one
   naming tension I did find (item 5 above, "Five-Way"/"four legs") is a naming-convention
   question, not a substantive claim-vs-proof mismatch.
8. **Coverage of my three assigned files is complete.** All three files were read via the Read
   tool with no `limit`/`offset` truncation applied (`MutualInformation.lean`: lines 1-430
   returned in full by the tool with no cutoff indicated; `ProductLaw.lean`: lines 1-159 in
   full; `PRODUCT_LAW_URS.md`: lines 1-121 in full). I did not skip or summarize any section of
   any of the three assigned files.
