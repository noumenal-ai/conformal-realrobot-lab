# URS_12 — Information-theory Gaussian KL sublibrary (scope check)

Miner: Sonnet miner 12. Slice: `ZPM/InformationTheory/KullbackLeibler/Gaussian/` (6 files).
Mission: extract every theorem/definition/citation, and determine whether this sublibrary
belongs to the core Shape-of-Ignorance (HC) programme or to an offshoot module (PAC-privacy /
crypto-learning-theory).

## Files mined

All six read end to end, full text, no truncation.

1. `ZPM/InformationTheory/KullbackLeibler/Gaussian/AbsolutelyContinuous.lean` (157 lines)
2. `ZPM/InformationTheory/KullbackLeibler/Gaussian/AffineImage.lean` (108 lines)
3. `ZPM/InformationTheory/KullbackLeibler/Gaussian/ClosedForm.lean` (203 lines)
4. `ZPM/InformationTheory/KullbackLeibler/Gaussian/Diagonal.lean` (135 lines)
5. `ZPM/InformationTheory/KullbackLeibler/Gaussian/OneDim.lean` (175 lines)
6. `ZPM/InformationTheory/KullbackLeibler/Gaussian/Whitening.lean` (134 lines)

Supplementary files read (not part of the assigned slice, read only to resolve the scope
question with primary evidence rather than inference):

- `ZPM/InformationTheory/KullbackLeibler/CondChainRule.lean` — full read, to check the docstring
  claim in `AbsolutelyContinuous.lean` that names it as a consumer.
- `ZPM/Probability/QuadraticFormExpectation.lean` — full read, to check the "Gaussian PAC-privacy
  log-det surrogate" claim in its own docstring.
- `ZPM/Measurements/HC/HIGHER_OBSTRUCTION_NOOLOGICAL_URS.md` (lines 1–45) — spot-read, to resolve
  a grep hit on "Gaussian" inside the core HC tree.
- `ZPM/Measurements/HC/AffineEngine.lean`, `ZPM/Measurements/HC/ApproximateFiveWay.lean`,
  `ZPM/Measurements/HC/APPROX_FIVEWAY_DISCOVERY_URS.md`, `ZPM/Measurements/HC/CYCLIC_CONVERSE_URS.md`
  — grep-context-only (not full-read; these are outside my slice and outside scope of my mandate,
  I only inspected the matched lines to disambiguate false-positive substring hits on "Gaussian"
  and "KullbackLeibler").

## Slice-note verdict: scope determination

**Verdict: this is an OFFSHOOT module (PAC-privacy / crypto-learning-theory support library), not
part of the core HC/Shape-of-Ignorance discovery tree.** Confidence: high, based on triangulated
import-graph and git-tracking evidence below, not inference from prose alone.

Evidence marshalled ([infra] tags — these are facts about the repository, not Lean theorems):

- **[infra] Import graph, exhaustive.** I grepped every file under `ZPM/` for
  `KullbackLeibler.Gaussian` (whole sublibrary) and separately for each of the six file basenames.
  The only importers of any `Gaussian/*.lean` file are other files inside
  `Gaussian/` itself:
  - `AffineImage` ← imported by `Diagonal`, `Whitening`
  - `Diagonal` ← imported by `ClosedForm`, `AbsolutelyContinuous`
  - `OneDim` ← imported by `Diagonal`
  - `Whitening` ← imported by `ClosedForm`, `AbsolutelyContinuous`
  - `AbsolutelyContinuous`, `ClosedForm` ← imported by nothing found.
  No file outside `Gaussian/` imports any file inside `Gaussian/`. The sublibrary is a closed
  leaf in the ZPM dependency graph as it currently stands.
- **[infra] The only outward pointer is prose, not code, and it points away from HC.** The
  module docstring of `AbsolutelyContinuous.lean` states verbatim: "These are the analytic
  side-conditions the PAC-privacy variational bound (`mutualInformationReal_le_condKL`) and the
  conditional-KL chain rule (`klDivReal_compProd_prod`) require of the additive-Gaussian-noise
  mechanism against its marginal-matching Gaussian reference." I traced both named lemmas:
  - `klDivReal_compProd_prod` exists, in `ZPM/InformationTheory/KullbackLeibler/CondChainRule.lean`,
    whose own docstring for the sibling theorem `klDivReal_compProd_prod` says it is "the shape
    consumed by the PAC-privacy variational bound `mutualInformationReal_le_condKL`."
  - `mutualInformationReal_le_condKL` itself does **not exist anywhere in the ZPM tree** — grepped
    for the exact name across all of `ZPM/`; the only two hits are the two docstring mentions just
    quoted (one in each file), never a `theorem`/`lemma` declaration. This is a forward reference
    to unbuilt/external work, not a discharged obligation. [PROBE-worthy Pl-kill: flagged, not
    hidden — see Agent-axis ignorance below.]
  - `ZPM/Probability/QuadraticFormExpectation.lean` independently corroborates the same target: its
    docstring states the file "is the analytic core of the Gaussian PAC-privacy log-det surrogate
    (Xiao-Devadas, arXiv:2210.03458): integrating the per-sample multivariate Gaussian KL closed
    form over the data distribution turns its mean term into `tr((Σ + Σ_B)⁻¹ Σ)`" — an explicit,
    independent citation of the same external literature target (Xiao-Devadas PAC-Privacy) that
    the user's own memory record (`project_crypto_learning_theory_pac_privacy.md`, referenced in
    this session's system context) names as "PAC-Privacy, option B... certified estimator for
    Xiao-Devadas MI surrogate."
- **[infra] git-tracked status confirms this is one coherent, currently uncommitted wave, and
  the HC tree does not touch it.** `git status --short` on `design-lab` (repo root, confirmed via
  `git rev-parse --show-toplevel`) shows the entire `Gaussian/` directory as untracked (`??`),
  alongside `CondChainRule.lean`, `FiniteSupport.lean`, `MapEquiv.lean`, `NormLlr.lean`,
  `Tensorization.lean` (siblings in `KullbackLeibler/`), `TotalCorrelation/Def.lean`, and
  `Probability/QuadraticFormExpectation.lean`. All of these are new, not yet committed. By
  contrast `KullbackLeibler/Real.lean` and `Binary.lean` are tracked (pre-existing, swept in by
  the `bc480d6 chore: rename pure-math/ -> measurements/` commit) — they are the pre-existing KL
  infrastructure the new wave builds on.
  - Of this whole new wave, **only `FiniteSupport.lean` is imported by the core HC tree**
    (`ZPM/Measurements/HC/ApproximateFiveWay.lean` imports
    `ZPM.InformationTheory.KullbackLeibler.FiniteSupport`, confirmed by direct read of that
    import line and cross-checked against `APPROX_FIVEWAY_DISCOVERY_URS.md`'s own file-list,
    which independently names `InformationTheory/KullbackLeibler/FiniteSupport.lean` as a
    "reusable atom").
  - **None of the six `Gaussian/*.lean` files, `CondChainRule.lean`, `MapEquiv.lean`,
    `Tensorization.lean`, `NormLlr.lean`, `QuadraticFormExpectation.lean`, or
    `TotalCorrelation/Def.lean` are imported anywhere in `Measurements/HC/`.** I grepped the
    entire `Measurements/HC/` subtree for `Gaussian`, `KullbackLeibler`, `PAC.privacy`, and
    `PACPrivacy`; the only genuine hits are (a) `FiniteSupport` (a different file, confirmed
    HC-consumed, NOT in my slice), and (b) five occurrences of the string "Gaussian" in
    `AffineEngine.lean` and two of its accompanying URS files, all of which are **false-positive
    substring matches on "Gaussian elimination"** (a linear-algebra proof technique over `ZMod 2`
    parity systems, unrelated to Gaussian probability measures) — confirmed by reading the
    matched lines directly, e.g. "The solvability core (`exists_parity_solution`) is elementary
    Gaussian elimination over..." One further hit,
    `HIGHER_OBSTRUCTION_NOOLOGICAL_URS.md:31`, names the Mathlib lemma
    `measurePreserving_restrict₂_multivariateGaussian` as prior art for restriction-map design
    ("Mathlib already fixed this grammar... I saw [it] in the Gaussian marginal API during the
    M3d build") — this is a **different, Mathlib-native lemma about marginals/restriction**, not
    one defined in any of my six files, and it is cited only as design precedent, not as an
    imported dependency. No genuine cross-import exists.
- **[STANCE, from the docstrings themselves] The files self-describe as infrastructure "the
  PAC-privacy variational bound... require[s]"** (`AbsolutelyContinuous.lean`) and as "the
  analytic core of the Gaussian PAC-privacy log-det surrogate" (`QuadraticFormExpectation.lean`,
  outside my slice but corroborating). No docstring in my six files makes any claim about HC,
  hidden channel capacity, Pl/Coh/Inv/Comp, η, or ignorance quadrants. The self-description is
  uniformly and exclusively PAC-privacy-facing.

**Net reading:** this is real, kernel-verified mathematics (multivariate Gaussian KL closed
form, absolute continuity, whitening) built explicitly as a dependency for a PAC-privacy /
crypto-learning-theory module (the "option B" project named in this session's memory context),
staged as a currently self-contained, uncommitted leaf that the core HC discovery tree does not
yet import and whose own stated consumer theorem (`mutualInformationReal_le_condKL`) does not yet
exist in the tree. It should be catalogued as offshoot infrastructure, not asserted as part of
the HC/Shape-of-Ignorance discovery corpus proper, unless and until an actual import edge from
`Measurements/HC/` appears.

## Theorems and definitions

Organized by file, in file order. Every `theorem`, `lemma`, `def`, and `private` variant is
listed; `private` helper lemmas are tagged as such. All are `[KV]` (Lean-kernel-proved) unless
otherwise noted — this whole sublibrary contains no `decide`, no `CONJ`, and no `axiom`.

### 1. `AbsolutelyContinuous.lean`

- **`posDef_whitened`** [KV, private]. For positive-definite `S₁, S₂ : Matrix ι ι ℝ`, the
  whitened covariance `((√S₂)⁻¹ √S₁)((√S₂)⁻¹ √S₁)ᴴ` is positive definite. Proved as a congruence
  of the identity by the invertible matrix `(√S₂)⁻¹ √S₁`.
- **`klDiv_multivariateGaussian_diagonal_stdGaussian_ne_top`** [KV, private]. For
  `μ : EuclideanSpace ℝ ι`, `d : ι → ℝ` strictly positive entrywise,
  `klDiv (multivariateGaussian μ (Matrix.diagonal d)) (stdGaussian (EuclideanSpace ℝ ι)) ≠ ⊤`.
  Reduces the two `toLp 2`-pushed products to `Measure.pi`, tensorizes via `klDiv_pi`, and closes
  each coordinate with the scalar `klDiv_gaussianReal_ne_top`.
- **`klDiv_multivariateGaussian_stdGaussian_ne_top`** [KV]. For `w : EuclideanSpace ℝ ι` and
  positive-definite `C`, `klDiv (multivariateGaussian w C) (stdGaussian (EuclideanSpace ℝ ι)) ≠ ⊤`.
  Diagonalizes `C` by its eigenvector unitary (`Matrix.IsHermitian.eigenvectorUnitary`) and
  transports the divergence to the diagonal case.
- **`klDiv_multivariateGaussian_ne_top`** [KV]. **Headline finiteness result.** For
  positive-definite `S₁, S₂`,
  `klDiv (multivariateGaussian m₁ S₁) (multivariateGaussian m₂ S₂) ≠ ⊤`. Whitens by
  `(gaussianAffineEquiv m₂ hS₂).symm` and applies the standard-Gaussian finiteness result above.
- **`multivariateGaussian_absolutelyContinuous`** [KV]. For positive-definite `S₁, S₂`,
  `(multivariateGaussian m₁ S₁).AbsolutelyContinuous (multivariateGaussian m₂ S₂)`, from finite
  KL via `klDiv_ne_top_iff`.
- **`integrable_llr_multivariateGaussian`** [KV]. For positive-definite `S₁, S₂`,
  `llr (multivariateGaussian m₁ S₁) (multivariateGaussian m₂ S₂)` is integrable against
  `multivariateGaussian m₁ S₁`. The other half of `klDiv_ne_top_iff` applied to the finiteness
  result.

Module docstring [STANCE]: states these are "the analytic side-conditions the PAC-privacy
variational bound (`mutualInformationReal_le_condKL`) and the conditional-KL chain rule
(`klDivReal_compProd_prod`) require of the additive-Gaussian-noise mechanism against its
marginal-matching Gaussian reference," and explicitly notes "Mathlib records neither the
multivariate-Gaussian density nor its absolute continuity, so these facts are proved here."
[PROBE, in-docstring, self-reported]: a claim about what Mathlib does *not* contain — I did not
independently verify this against Mathlib source; recorded as asserted, not confirmed by me.

### 2. `AffineImage.lean`

- **`adjoint_toEuclideanCLM`** [KV]. For `B : Matrix ι ι ℝ`,
  `(toEuclideanCLM (𝕜 := ℝ) B).adjoint = toEuclideanCLM (𝕜 := ℝ) Bᴴ`. `toEuclideanCLM` is a star
  algebra equivalence carrying conjugate transpose to operator adjoint.
- **`inner_adjoint_toEuclideanCLM`** [KV]. For `B` and `x, y : EuclideanSpace ℝ ι`,
  `⟪(toEuclideanCLM B).adjoint x, (toEuclideanCLM B).adjoint y⟫ = x ⬝ᵥ (B * Bᴴ) *ᵥ y`.
- **`map_stdGaussian_affine`** [KV]. **Foundational result.** The affine image
  `z ↦ a + toEuclideanCLM B z` of the standard Gaussian on `EuclideanSpace ℝ ι` equals
  `multivariateGaussian a (B * Bᴴ)`. Proved via `IsGaussian.ext` matching means (both `a`) and
  covariances (both `x ⬝ᵥ (B * Bᴴ) *ᵥ y`).
- **`map_multivariateGaussian_affine`** [KV]. **General affine-transport result.** For
  positive-semidefinite `S`, the affine pushforward `x ↦ a + toEuclideanCLM B x` of
  `multivariateGaussian μ S` equals `multivariateGaussian (a + toEuclideanCLM B μ) (B * S * Bᴴ)`.
  Docstring calls this "the covariance-transport engine of the diagonalization step." Proved by
  composing affine maps and reducing to `map_stdGaussian_affine`, using `√S · √Sᴴ = √S · √S = S`.

Module docstring [KV-adjacent framing]: "the affine pushforward `z ↦ a + B z` of the standard
Gaussian on `EuclideanSpace ℝ ι` is the multivariate Gaussian with mean `a` and covariance
`B * Bᴴ`. This is the foundation of the whitening reduction used to derive the closed form..."

### 3. `ClosedForm.lean`

- **`normSq_toEuclideanCLM_of_isometry`** [KV, private]. For `M` with `Mᴴ * M = 1` (orthogonal),
  `‖toEuclideanCLM M w‖² = ‖w‖²` — orthogonal changes of variables preserve Euclidean norm.
- **`klDivReal_multivariateGaussian_stdGaussian`** [KV]. **Closed form vs. standard Gaussian.**
  For positive-definite `C`:
  `klDivReal (multivariateGaussian w C) (stdGaussian (EuclideanSpace ℝ ι))
    = ½ (-log(det C) + tr C + ‖w‖² - d)`, `d = Fintype.card ι`.
  Proved by diagonalize-and-tensorize: spectral theorem `C = U diag(λ) Uᴴ`, orthogonal change of
  variables `x ↦ Uᴴ x`, reduce to `klDivReal_multivariateGaussian_diagonal_stdGaussian` (from
  `Diagonal.lean`), reassemble via `∑ log λᵢ = log det C`, `∑ λᵢ = tr C`, isometry `‖Uᴴw‖ = ‖w‖`.
- **`conjTranspose_cfcSqrt`** [KV, private]. The functional-calculus square root of a matrix is
  self-adjoint: `(CFC.sqrt S)ᴴ = CFC.sqrt S`.
- **`conjTranspose_cfcSqrt_inv`** [KV, private]. `((CFC.sqrt S)⁻¹)ᴴ = (CFC.sqrt S)⁻¹`.
- **`cfcSqrt_inv_mul_self`** [KV, private]. For positive-definite `S`,
  `(CFC.sqrt S)⁻¹ * (CFC.sqrt S)⁻¹ = S⁻¹`.
- **`posDef_whitened`** [KV, private]. (Restated locally in this file, same statement as in
  `AbsolutelyContinuous.lean`.) The whitened covariance
  `((√S₂)⁻¹ √S₁)((√S₂)⁻¹ √S₁)ᴴ` is positive-definite. **[Cross-tree note: duplicated lemma
  name+statement across two files — see Cross-tree/divergence notes below.]**
- **`det_whitened`** [KV, private]. `det(whitened covariance) = det S₁ / det S₂`.
- **`trace_whitened`** [KV, private]. `tr(whitened covariance) = tr(S₂⁻¹ S₁)`.
- **`normSq_cfcSqrt_inv_apply`** [KV, private]. For positive-definite `S₂`,
  `‖toEuclideanCLM ((√S₂)⁻¹) v‖² = v ⬝ᵥ S₂⁻¹ *ᵥ v` — the whitening map preserves the quadratic
  form.
- **`klDivReal_multivariateGaussian`** [KV]. **THE headline closed-form theorem, labelled "M3b"
  in-docstring.** For positive-definite `S₁, S₂`:
  `KL(N(m₁,S₁) ‖ N(m₂,S₂)) = ½ ( log(det S₂ / det S₁) + tr(S₂⁻¹ S₁) + ⟪m₁-m₂, S₂⁻¹(m₁-m₂)⟫ - d )`.
  This is the standard multivariate-Gaussian-Gaussian KL closed form from the information theory
  literature (matches Cover & Thomas / standard textbook formula), here fully kernel-proved for
  `EuclideanSpace ℝ ι` with `Fintype ι`. Proved via `klDivReal_multivariateGaussian_whiten`
  (from `Whitening.lean`) composed with `klDivReal_multivariateGaussian_stdGaussian` and the
  three whitened-covariance invariant lemmas above.

Module docstring [STANCE]: "This is the reduced (whitened) form of the multivariate Gaussian KL
closed form," describing the diagonalize-and-tensorize proof route explicitly, and a second
docstring block "### Invariants of the whitened covariance" [STANCE] explaining these are "kept
separate so the closed form reads as an assembly."

### 4. `Diagonal.lean`

- **`multivariateGaussian_diagonal_eq_map_pi`** [KV]. **Product-structure result.** For `d ≥ 0`
  entrywise, `multivariateGaussian μ (Matrix.diagonal d)` equals the image under `toLp 2` of the
  product measure `∏ᵢ gaussianReal μᵢ dᵢ`. Docstring: "the 'coordinates are independent' fact for
  a diagonal covariance." Proof explicitly avoids computing `CFC.sqrt (diagonal d)` directly, using
  `map_stdGaussian_affine` with `diagonal √d` instead.
- **`toLpMeasurableEquiv`** [def]. `noncomputable def toLpMeasurableEquiv : (ι → ℝ) ≃ᵐ
  EuclideanSpace ℝ ι` — the Euclidean identification `toLp 2` packaged as a measurable
  equivalence, "used to transport the tensorization of `Measure.pi` onto `EuclideanSpace`."
- **`coe_toLpMeasurableEquiv`** [KV, simp]. `⇑toLpMeasurableEquiv = (toLp 2 : (ι → ℝ) →
  EuclideanSpace ℝ ι)`.
- **`klDivReal_multivariateGaussian_diagonal_stdGaussian`** [KV]. **Tensorized diagonal closed
  form.** For strictly positive diagonal `d`:
  `klDivReal (mvG μ (diagonal d)) stdGaussian = ∑ᵢ ½(-log dᵢ + dᵢ + μᵢ² - 1)` — the coordinatewise
  sum of scalar Gaussian-Gaussian KL closed forms. Docstring: "the diagonalized-and-tensorized leg
  of the multivariate Gaussian KL closed form." Consumed by `ClosedForm.lean`'s
  `klDivReal_multivariateGaussian_stdGaussian`.

Module docstring [STANCE]: names this "the leg that lets the diagonalized multivariate KL split
into `d` scalar Gaussian KLs."

### 5. `OneDim.lean`

- **`rnDeriv_gaussianReal_ratio`** [KV, private]. The Radon-Nikodym derivative of one real
  Gaussian w.r.t. another equals, volume-a.e., the ratio of their densities
  `gaussianPDF m₁ v₁ x / gaussianPDF m₂ v₂ x`.
- **`log_gaussianPDFReal`** [KV, private]. `log(gaussianPDFReal m v x) = -½ log(2πv) -
  (x-m)²/(2v)` for `v ≠ 0`.
- **`integral_sub_mean_self`** [KV, private]. `∫(x - m₁) ∂gaussianReal m₁ v₁ = 0`.
- **`integral_sq_sub_mean_self`** [KV, private]. `∫(x - m₁)² ∂gaussianReal m₁ v₁ = v₁`.
- **`integral_sq_sub_const`** [KV, private]. `∫(x - m₂)² ∂gaussianReal m₁ v₁ = v₁ + (m₁-m₂)²`
  — the bias-variance decomposition.
- **`klDivReal_gaussianReal`** [KV]. **Scalar closed form.**
  `KL(N(m₁,v₁) ‖ N(m₂,v₂)) = ½ ( log(v₂/v₁) + (v₁ + (m₁-m₂)²)/v₂ - 1 )` for `v₁, v₂ ≠ 0`.
  Docstring: "This is the one-dimensional atom of the diagonalized route to the multivariate
  Gaussian KL closed form."
- **`klDiv_gaussianReal_ne_top`** [KV]. **Scalar finiteness result.** `klDiv (gaussianReal m₁ v₁)
  (gaussianReal m₂ v₂) ≠ ⊤` for `v₁, v₂ ≠ 0`. Docstring: "the integrability side-condition that
  `klDivReal_pi` requires per coordinate: the log-likelihood ratio is `P`-a.e. an explicit
  quadratic, whose square-integrability against `P` is the finiteness of the second moment."

Module docstring cites: T. M. Cover and J. A. Thomas, *Elements of Information Theory* — see
Citations section below.

### 6. `Whitening.lean`

- **`toEuclideanLE`** [def]. `noncomputable def toEuclideanLE (M : Matrix ι ι ℝ) (hM : IsUnit
  M.det) : EuclideanSpace ℝ ι ≃ₗ[ℝ] EuclideanSpace ℝ ι` — an invertible matrix as a linear
  equivalence, inverse given by the matrix inverse through `toEuclideanCLM`.
- **`toEuclideanCLE`** [def]. `noncomputable def toEuclideanCLE ... : EuclideanSpace ℝ ι ≃L[ℝ]
  EuclideanSpace ℝ ι` — the continuous-linear-equivalence upgrade of `toEuclideanLE`.
- **`toEuclideanCLE_apply`** [KV, simp]. `toEuclideanCLE M hM x = toEuclideanCLM M x`.
- **`isUnit_det_cfcSqrt`** [KV]. For positive-definite `S`, `IsUnit (CFC.sqrt S).det` — the
  functional-calculus square root has invertible determinant, since `(CFC.sqrt S).det² = S.det >
  0`.
- **`gaussianAffineEquiv`** [def]. `noncomputable def gaussianAffineEquiv (m : EuclideanSpace ℝ
  ι) {S} (hS : S.PosDef) : EuclideanSpace ℝ ι ≃ᵐ EuclideanSpace ℝ ι` — the defining affine map
  `z ↦ m + √S z` of `multivariateGaussian m S`, packaged as a measurable equivalence for
  positive-definite `S`.
- **`gaussianAffineEquiv_apply`** [KV, simp]. `gaussianAffineEquiv m hS z = m + toEuclideanCLM
  (CFC.sqrt S) z`.
- **`multivariateGaussian_eq_map_gaussianAffineEquiv`** [KV]. `multivariateGaussian m S =
  (stdGaussian (EuclideanSpace ℝ ι)).map (gaussianAffineEquiv m hS)`.
- **`toEuclideanCLE_symm_apply`** [KV, simp]. `(toEuclideanCLE M hM).symm x = toEuclideanCLM
  M⁻¹ x`.
- **`gaussianAffineEquiv_symm_apply`** [KV, simp]. **The whitening map itself.**
  `(gaussianAffineEquiv m hS).symm z = toEuclideanCLM (CFC.sqrt S)⁻¹ (z - m)`.
- **`klDivReal_multivariateGaussian_whiten`** [KV]. **The whitening reduction theorem.** For
  positive-definite `S₂`, pushing both `multivariateGaussian m₁ S₁` and `multivariateGaussian m₂
  S₂` through the whitening equivalence `(gaussianAffineEquiv m₂ hS₂).symm` reduces
  `klDivReal (multivariateGaussian m₁ S₁) (multivariateGaussian m₂ S₂)` to
  `klDivReal (multivariateGaussian (√S₂⁻¹(m₁-m₂)) ((√S₂⁻¹√S₁)(√S₂⁻¹√S₁)ᴴ)) (stdGaussian
  (EuclideanSpace ℝ ι))` — a KL against the standard Gaussian with the stated whitened mean and
  covariance. Consumed directly by `ClosedForm.lean`'s main theorem.

Module docstring [STANCE]: "Building blocks for the whitening reduction of the multivariate
Gaussian KL divergence. An invertible real matrix acts on `EuclideanSpace ℝ ι` as a continuous
linear equivalence... and hence as a measurable equivalence."

## Proof-architecture summary (object axis, descriptive only)

The six files form one linear reduction chain, confirmed by the import graph (not inferred):
`OneDim` (scalar atom) → `Diagonal` (tensorize scalars into a product, needs `AffineImage` +
`OneDim`) → `Whitening` (package the defining affine map as a measurable equivalence, needs only
`AffineImage`) → `ClosedForm` (diagonalize by spectral theorem + whiten, needs `Diagonal` +
`Whitening`) → `AbsolutelyContinuous` (upgrade the `klDivReal` finiteness to `ℝ≥0∞`-valued
`klDiv ≠ ⊤`, absolute continuity, and llr-integrability, needs `Whitening` + `Diagonal`). This
matches every docstring's self-description of the "diagonalize-and-tensorize" / "whitening"
route verbatim.

## Citations

Verbatim, organized by the claim each supports.

### Supporting the scalar and general multivariate Gaussian KL closed form

> T. M. Cover and J. A. Thomas, *Elements of Information Theory*, 2nd ed., Wiley, 2006.

— Appears in `OneDim.lean` module docstring under "Reference:", supporting the 1-D
Gaussian-Gaussian KL closed-form claim `klDivReal_gaussianReal`. Also appears (bulleted, as first
of two references under "## References") in `AffineImage.lean`'s module docstring, supporting the
general affine-image-of-standard-Gaussian framing. No arXiv id or DOI given for this book;
recorded as "no id given" per carrier instructions — a 2nd-edition textbook citation, standard
form (author, title, edition, publisher, year), no identifier expected for a book of this kind.

### Supporting the operator/infinite-dimensional generalization (explicitly marked as NOT proved here)

> H. Q. Minh, *Regularized Divergences Between Covariance Operators and Gaussian Measures on
> Hilbert Spaces*, J. Theoret. Probab. **34** (2021), arXiv:1904.05352.

— Appears in `AffineImage.lean`'s module docstring, second bullet under "## References",
introduced by: "For the operator / infinite-dimensional generalization (covariance operators on
Hilbert spaces), see...". This is explicitly scoped as *out of scope* for the file's own content
(finite-dimensional `EuclideanSpace ℝ ι` only) — a pointer to related literature, not a claim
that this file implements or extends that result. [STANCE, self-limiting scope note.]

### Supporting the PAC-privacy consumer claim (the scope-determining citation)

> Xiao-Devadas, arXiv:2210.03458

— Appears (in this exact abbreviated form, "Xiao-Devadas, arXiv:2210.03458") in
`ZPM/Probability/QuadraticFormExpectation.lean`'s module docstring (outside my assigned slice,
read only to corroborate the scope verdict): "This is the analytic core of the Gaussian
PAC-privacy log-det surrogate (Xiao-Devadas, arXiv:2210.03458): integrating the per-sample
multivariate Gaussian KL closed form over the data distribution turns its mean term into
`tr((Σ + Σ_B)⁻¹ Σ)`." **This citation is abbreviated in-source (surname pair + arXiv id only, no
full title, no year stated explicitly beyond what the arXiv id encodes, no venue).** I am
transcribing it exactly as written and NOT expanding or completing it, per the carrier's
"never fabricate a citation" instruction — a fuller bibliographic form (full author list, title,
year, venue) is not present in the source file and I decline to reconstruct one from training
knowledge, since that would risk mis-attribution the carrier explicitly forbids. This is the
literature target that the "PAC-privacy variational bound" language in `AbsolutelyContinuous.lean`
implicitly refers to (see Literature-audit verdicts below), though `AbsolutelyContinuous.lean`
itself never states this citation directly — it only names the *internal* Lean identifier
`mutualInformationReal_le_condKL`.

## Literature-audit verdicts

None of my six files contain an explicit `[PROBE]`-style novelty/no-ancestor/boundary verdict in
prose (no "this appears in no examined work," no "boundary/Pl-kill" language, no stated search
scope with a count of works surveyed). This sublibrary's docstrings are architectural/proof-route
explanations, not literature-audit reports. The one quasi-audit-like claim present is:

> "Mathlib records neither the multivariate-Gaussian density nor its absolute continuity, so
> these facts are proved here" — `AbsolutelyContinuous.lean` module docstring, verbatim.

[PROBE, weak form]: this is a claim about Mathlib's coverage (a "no-ancestor-in-Mathlib" style
verdict), but it states no search methodology, no version pinned, and no scope beyond the bare
assertion. I did not independently re-verify it against Mathlib source (out of my mandate as
carrier defines it — extraction, not re-verification). Recorded as asserted-in-docstring, unverified
by me.

No other file in my slice makes a comparable claim. **I found zero instances, across all six
files, of language like "no ancestor found," "killed target," "appears in no examined work," or
any stated count of works/fields searched.** This is a negative finding, reported precisely per
the carrier's honesty clause.

## Cross-tree / divergence notes

- **Duplicated lemma: `posDef_whitened`.** The private lemma `posDef_whitened` — same name,
  identical statement (`((√S₂)⁻¹√S₁)((√S₂)⁻¹√S₁)ᴴ.PosDef` for positive-definite `S₁, S₂`), and
  essentially identical proof term — appears independently in both
  `AbsolutelyContinuous.lean` (lines 42–52) and `ClosedForm.lean` (lines 137–147). Both are marked
  `private`, so this is not a naming collision at the Lean-elaboration level (each file gets its
  own private copy), but it is a real proof-duplication: the same fact is proved twice,
  word-for-word, in two files that both import `Whitening.lean` and could plausibly have shared it
  from a common location. Flagged as duplication per the carrier's honesty clause ("if two files
  duplicate or seem to contradict, note it"); this is duplication, not contradiction — both
  copies state and prove the identical fact.
- **Two independent "M3b"/PAC-privacy corroborating citations.** `AbsolutelyContinuous.lean` and
  `QuadraticFormExpectation.lean` (the latter outside my slice) independently name the same
  external target concept (PAC-privacy / Xiao-Devadas surrogate) from two different files with no
  shared docstring text — this is consistent triangulation, not duplication, and strengthens
  (rather than undermines) the scope verdict above.
  `ClosedForm.lean`'s headline theorem `klDivReal_multivariateGaussian` is explicitly labelled
  "(M3b)" in its own docstring — a milestone-numbering convention I cannot resolve (no "M3a," "M1,"
  etc. appear anywhere in my six files) — see Agent-axis ignorance below.
- **Forward reference to an unbuilt theorem.** `mutualInformationReal_le_condKL`, named twice
  (once in my slice, once in `CondChainRule.lean`) as the ultimate consumer of this
  infrastructure, does not exist as a declaration anywhere in the `ZPM/` tree at the time of this
  read. This is a live forward reference / Pl-kill candidate: the infrastructure is built, but its
  stated purpose is not yet discharged in-kernel. Flagged, not hidden, per carrier instruction.
- **No divergence with the core HC tree.** As established in the scope-verdict section, there is
  no import edge, no shared lemma name, and no shared docstring language between my six files and
  anything under `Measurements/HC/`. The apparent hits from a blind grep were false positives
  (substring "Gaussian" inside "Gaussian elimination," a different technique entirely) or a
  citation-as-precedent to an unrelated Mathlib lemma
  (`measurePreserving_restrict₂_multivariateGaussian`). I report this as a clean negative
  (no divergence because no contact), not as an unresolved tension.
- **`Real.lean` vs. the new wave.** `KullbackLeibler/Real.lean` (imported by `OneDim.lean`) is
  git-tracked, pre-existing infrastructure (swept in under the `bc480d6` rename commit); all six
  files in my slice, plus their sibling new files (`CondChainRule.lean`, `FiniteSupport.lean`,
  `MapEquiv.lean`, `NormLlr.lean`, `Tensorization.lean`, `Probability/QuadraticFormExpectation.lean`,
  `InformationTheory/TotalCorrelation/Def.lean`), are uncommitted (`git status --short` shows `??`
  for all of them). This is infrastructure evidence, not a content claim: the whole PAC-privacy
  support wave is being built in one sitting on top of the pre-existing, committed KL core.

## Agent-axis ignorance (Γ)

Reported precisely and separately from the object-axis content above, per the carrier's
instruction that "a gap named is content, a gap hidden is a coverage failure."

1. **I did not verify the "Mathlib records neither the multivariate-Gaussian density nor its
   absolute continuity" claim** (`AbsolutelyContinuous.lean` docstring) against actual Mathlib
   source. I read this as an asserted, unverified [PROBE]-adjacent claim. My mandate per the
   carrier is extraction, not re-verification of the underlying mathematics, but this specific
   claim is about *coverage of another library*, which is exactly the kind of claim the carrier
   says to flag if unverifiable — I flag it as unverified by me, not as false.
2. **I cannot resolve the "M3b" milestone label** on `klDivReal_multivariateGaussian` in
   `ClosedForm.lean`. No other milestone labels ("M1," "M2," "M3a," etc.) appear anywhere in my
   six assigned files, so I cannot reconstruct what numbering scheme this belongs to or what M3a
   might be. This may well be resolved by another miner's slice (if an M3a-labelled file exists
   elsewhere in the PAC-privacy wave) — recorded as UK, explicitly flagged, not promoted to a
   finding, per the carrier's `act(imagine)`-gate instruction.
3. **I did not exhaustively read `CondChainRule.lean` and `QuadraticFormExpectation.lean`'s
   surrounding context beyond what was needed to resolve the scope question** — I read both files
   in full for accuracy, but they were not part of my assigned slice, so I have not attempted to
   extract *their* theorems/citations into this URS as first-class content (only quoted the
   specific lines relevant to my scope determination). If another miner's slice covers these two
   files directly, that miner's URS is authoritative for their content; mine only borrows load-
   bearing sentences as scope evidence.
4. **The identity and content of `mutualInformationReal_le_condKL` is unknown to me** — it is
   named twice but not defined anywhere I could find in `ZPM/`. I do not know if it exists
   elsewhere outside `ZPM/` (e.g., a separate, not-yet-created file), in a different branch, or is
   purely aspirational/planned. Recorded as UK on the object axis, surfaced here since it bears
   directly on the scope verdict's confidence.
5. **I did not check whether the "PAC-Privacy, option B" project named in this session's system
   context (`project_crypto_learning_theory_pac_privacy.md`, referenced only as a memory-index
   entry, not read in full by me) is the SAME project this Gaussian sublibrary serves, versus a
   coincidentally similar but distinct effort.** I inferred the connection from independent
   in-source textual evidence (the Xiao-Devadas citation appearing in both the user's memory
   index description and in `QuadraticFormExpectation.lean`'s docstring) rather than from reading
   the memory file itself, which I did not have direct file access to beyond the one-line index
   description surfaced in the system reminder. This inference is well-supported by the two
   independent Xiao-Devadas mentions but I flag the memory-file cross-reference specifically as
   something I did not verify by direct file read.
6. **I did not attempt to formally re-derive or spot-check any Lean proof term** for
   mathematical correctness beyond what is visible in the statement and docstring. Per the
   carrier, the mathematics is kernel-verified and my job is extraction, not re-verification; I
   note this explicitly so the boundary of my checking is clear (I checked import graphs, git
   status, and cross-file textual consistency — all infra-level facts — not proof-term semantics).

No file or section was truncated; no citation was invented; every named work above is transcribed
exactly as it appears in source with no completion of missing bibliographic fields.
