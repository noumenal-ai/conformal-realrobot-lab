# URS_02 — Bipartite five-way: fibered and fiber-product

Miner: Sonnet miner 02. Slice: `Fibered.lean`, `FiberedInterpolation.lean`, `FiberProduct.lean`,
`FIBER_PRODUCT_URS.md`. All four files read end to end via the Read tool; no truncation.

## Files mined

1. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/Fibered.lean`
   (200 lines, read in full). Imports `ZPM.Measurements.HC.Combinatorial`,
   `ZPM.Measurements.HC.MutualInformation`.
2. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/FiberedInterpolation.lean`
   (269 lines, read in full). Imports `ZPM.Measurements.HC.Fibered`,
   `ZPM.Measurements.HC.Abstract`.
3. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/FiberProduct.lean`
   (194 lines, read in full). Imports `ZPM.Measurements.HC.Marginals`,
   `ZPM.Measurements.HC.HigherObstruction`.
4. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/FIBER_PRODUCT_URS.md`
   (96 lines, read in full). The Γ⟷γ discovery ledger for `FiberProduct.lean`.

All four files sit in namespace `HiddenChannelCapacity`. The two `Fibered*` files develop one
model (the shared-coordinate / fibered Five-Way, generalizing the two-way combinatorial equivalence
of `Combinatorial.lean` to `S × A × B`). `FiberProduct.lean` + its URS develop a structurally
distinct construction (the natural join over a genuine multi-team interface, building on
`Marginals.lean` and `HigherObstruction.lean`). Both share the word "fiber" but are different
constructions at different levels of the corpus's architecture; I report them as two sub-clusters
of one slice, not one unified object.

## Theorems and definitions

Tag key: [KV] kernel-verified theorem; [decide] finite decidable check; [CONJ] named conjecture;
[PROBE] literature-audit verdict; [STANCE] interpretive/positioning claim; [def] a definition
(not a proposition to prove); [infra] structural/bookkeeping lemma feeding a headline result.

### Sub-cluster A — `Fibered.lean` (the shared-coordinate model, structural + informational legs)

**Docstring framing [STANCE].** "The combinatorial layer (`ZPM.Measurements.HC.Combinatorial`)
studies a single coupling `κ ⊆ α × β` and proves the support-level equivalence
`hcComb κ = 0 ↔ IsRect κ`. This file generalizes to a **shared-coordinate** (fibered) model
`κ ⊆ S × A × B`: each value of the shared coordinate `s : S` indexes a *fiber* `fiber κ s ⊆ A × B`,
and the Five-Way equivalence is asked fiberwise." The docstring explicitly enumerates which leg
is which Roman numeral: `FiberRect κ` is (iii), `Decomposable κ` is (ii), `FiberProductSurjective κ`
is (v), `FiberCI κ` is (iv), and states "The interpolation leg (i) is added in
`ZPM.Measurements.HC.FiberedInterpolation`, completing the genuine Five-Way equivalence."

- **`fiber` [def].** `fiber (κ : Finset (S × A × B)) (s : S) : Finset (A × B) := (κ.filter (fun t => t.1 = s)).image (fun t => (t.2.1, t.2.2))`.
  The slice of admissible `(a,b)` pairs whose shared coordinate is `s`.

- **`Decomposable κ` [def].** `∀ s a₁ b₁ a₂ b₂, (s, a₁, b₁) ∈ κ → (s, a₂, b₂) ∈ κ → (s, a₁, b₂) ∈ κ`.
  Docstring: "each fiber is closed under cross-recombination. If `(s, a₁, b₁)` and `(s, a₂, b₂)`
  are admissible then so is the cross element `(s, a₁, b₂)`. This is the fibered amalgamation /
  decomposability leg (ii)."

- **`FiberRect κ` [def].** `∀ s, IsRect (fiber κ s)`. "every fiber factors as the product of its
  marginal supports. This is the fibered rectangularity leg (iii)." (`IsRect` is imported from
  `Combinatorial.lean`, outside this slice — not mined here.)

- **`FiberProductSurjective κ` [def].** `∀ s a b, (∃ b', (s, a, b') ∈ κ) → (∃ a', (s, a', b) ∈ κ) → (s, a, b) ∈ κ`.
  "in each fiber, if `a` appears (with some right value) and `b` appears (with some left value),
  then `(s, a, b)` is admissible. This is the fiber-product surjectivity leg (v)."

- **`mem_fiber` [KV, infra, `@[simp]`].** `(a, b) ∈ fiber κ s ↔ (s, a, b) ∈ κ`. Proved by unfolding
  `fiber`, `Finset.mem_image`, and a `Finset.mem_filter` destructuring argument on the triple.

- **`mem_projL_fiber` [KV, infra].** `a ∈ projL (fiber κ s) ↔ ∃ b, (s, a, b) ∈ κ`.

- **`mem_projR_fiber` [KV, infra].** `b ∈ projR (fiber κ s) ↔ ∃ a, (s, a, b) ∈ κ`.

- **`fiberRect_iff_fps` [KV].** `FiberRect κ ↔ FiberProductSurjective κ`. "**Fiber
  rectangularity ⇔ fiber-product surjectivity** (iii ⇔ v). Each fiber factors as a rectangle
  exactly when the support is fiber-product surjective." Proof uses `isRect_iff_cross_closed`
  (imported, `Combinatorial.lean`) together with `mem_projL_fiber`/`mem_projR_fiber`/`mem_fiber`.

- **`decomposable_iff_fps` [KV].** `Decomposable κ ↔ FiberProductSurjective κ`, proved with the
  `DecidableEq` instances explicitly `omit`ted ("direct first-order logic"). Docstring:
  "**Decomposability ⇔ fiber-product surjectivity**: direct first-order logic."

- **`fiberRect_iff_decomposable` [KV].** `FiberRect κ ↔ Decomposable κ`. "**Fiber rectangularity
  ⇔ decomposability** (iii ⇔ ii)." Proved as the composite
  `(fiberRect_iff_fps κ).trans (decomposable_iff_fps κ).symm`.

- **`FiberCI κ` [def].** In section `Information`, requires `[Fintype A] [Fintype B]
  [MeasurableSpace A] [MeasurableSpace B] [DiscreteMeasurableSpace A] [DiscreteMeasurableSpace B]`
  on top of the structural section's `DecidableEq` hypotheses.
  `∀ s (h : (fiber κ s).Nonempty), InformationTheory.mutualInformationReal (uniformMeasure (fiber κ s) h) = 0`.
  "`κ` satisfies **fiber conditional independence**: the uniform distribution on each nonempty
  fiber has zero mutual information between its two coordinates. This is the conditional-
  independence leg (iv)." (`InformationTheory.mutualInformationReal` and `uniformMeasure` are
  imported from `MutualInformation.lean`, outside this slice.)

- **`isRect_empty` [KV, infra].** `IsRect (∅ : Finset (A × B))`. "The empty coupling is
  rectangular: both marginal supports are empty." (The measurability/Fintype typeclasses on `A B`
  are explicitly `omit`ted for this lemma since it is purely combinatorial.)

- **`fiberRect_iff_fiberCI` [KV].** `FiberRect κ ↔ FiberCI κ`. "**Fiber rectangularity ⇔ fiber
  conditional independence** (iii ⇔ iv). On each nonempty fiber the mutual-information bridge
  applies; empty fibers are vacuously rectangular." Proof invokes an external bridge lemma
  `mutualInformationReal_uniform_eq_zero_iff_isRect` (imported, not in this slice) at each
  nonempty fiber, and `isRect_empty` for the empty-fiber case via `Finset.not_nonempty_iff_eq_empty`.

- **`fiveWay_fibered` [KV, headline].** 
  ```
  theorem fiveWay_fibered (κ : Finset (S × A × B)) :
      List.TFAE [FiberRect κ, Decomposable κ, FiberProductSurjective κ, FiberCI κ]
  ```
  "**Four-Way fiberwise equivalence.** The structural and informational legs of fibered HC are
  mutually equivalent: fiber rectangularity (iii), decomposability (ii), fiber-product
  surjectivity (v), and fiber conditional independence (iv). The interpolation leg (i) is added
  in `FiberedInterpolation`." Proved via `tfae_have`/`tfae_finish` chaining 1↔2, 1↔3, 1↔4 from the
  three iff-lemmas above. **This is explicitly named a Four-Way, not yet the Five-Way** — the
  docstring is precise that interpolation (i) is still missing at this point in the corpus, and
  is added in the next file.

### Sub-cluster A — `FiberedInterpolation.lean` (adding the interpolation leg, closing the genuine Five-Way)

**Docstring framing [STANCE].** "`ZPM.Measurements.HC.Fibered` proved the Four-Way fiberwise
equivalence between fiber rectangularity (iii), decomposability (ii), fiber-product
surjectivity (v), and fiber conditional independence (iv). This file adds the **interpolation**
leg (i) by instantiating the substrate-neutral interpolation layer
(`ZPM.Measurements.HC.Abstract`) at the finite, shared-coordinate model." The docstring states the
model-theoretic dictionary explicitly: "worlds to be admissible triples `S × A × B`, formulas to
be predicates on triples, satisfaction to be function application, and the shared/left/right
partition to be 'depends only on the `S` coordinate / on the `(S, A)` coordinates / on the
`(S, B)` coordinates'."

- **`SatP` [def].** `SatP : (S × A × B) → ((S × A × B) → Prop) → Prop := fun w φ => φ w`.
  "Satisfaction in the fibered model: a formula is a predicate on triples, and satisfaction is
  function application."

- **`SharedEqP` [def].** `SharedEqP : (S × A × B) → (S × A × B) → Prop := fun w w' => w.1 = w'.1`.
  "Two worlds are **shared-equivalent** when they agree on the shared coordinate."

- **`IsSharedP φ` [def].** `∀ w w', w.1 = w'.1 → (φ w ↔ φ w')`. "A formula is **shared** when it
  depends only on the shared coordinate."

- **`IsLeftP φ` [def].** `∀ w w', w.1 = w'.1 → w.2.1 = w'.2.1 → (φ w ↔ φ w')`. "A formula is
  **left** when it depends only on the shared and left coordinates."

- **`IsRightP φ` [def].** `∀ w w', w.1 = w'.1 → w.2.2 = w'.2.2 → (φ w ↔ φ w')`. "A formula is
  **right** when it depends only on the shared and right coordinates."

- **`HasInterpolationProperty κ` [def].**
  ```
  ∀ φ ψ, IsLeftP φ → IsRightP ψ →
    (∀ w ∈ Abd SatP (↑κ) (∅), SatP w φ → SatP w ψ) →
    HasInterpolant SatP IsSharedP (↑κ) (∅) φ ψ
  ```
  "`κ` has the **interpolation property**: every valid left-to-right entailment over the
  admissible worlds has a shared interpolant. This is the interpolation leg (i) of the Five-Way."
  (`Abd` and `HasInterpolant` are imported from `Abstract.lean`, outside this slice.)

- **`Amalgamable κ` [def].** `IsDecomposable SatP SharedEqP IsLeftP IsRightP (↑κ) (∅)`. "`κ` is
  **amalgamable**: the existential-amalgam form of decomposability — the abstract amalgamation
  property (`HiddenChannelCapacity.IsDecomposable`) instantiated at the fibered model. Any two
  shared-equivalent admissible worlds have a common amalgam agreeing with each on its private
  side. Equivalent to `Decomposable κ` via `decomposable_iff_absDecomposable`; this is
  amalgamation leg (ii) in its model-theoretic form." (`IsDecomposable` imported from
  `Abstract.lean`.)

- **`mem_Abd_empty` [KV, infra].** `w ∈ Abd SatP (↑κ) (∅) ↔ w ∈ κ`. "With no background evidence
  (`E = ∅`) the admissible worlds are exactly the elements of `κ`."

- **`shared_invariant` [KV, infra].** `SharedInvariant (World := S × A × B) SatP SharedEqP IsSharedP`.
  "Shared invariance holds: shared formulas cannot tell apart shared-equivalent worlds. Immediate
  from `IsSharedP`." (`SharedInvariant` imported from `Abstract.lean`.)

- **`shared_definability` [KV, infra].** `HasSharedDefinability SatP SharedEqP IsSharedP IsLeftP (↑κ) (∅)`.
  "Shared definability holds: every left formula is witnessed by the shared formula 'some
  admissible world with the same shared coordinate satisfies `φ`'." Constructive witness:
  `fun w => ∃ w', w' ∈ κ ∧ φ w' ∧ w'.1 = w.1`.

- **`decomposable_iff_absDecomposable` [KV].** `Decomposable κ ↔ IsDecomposable SatP SharedEqP IsLeftP IsRightP (↑κ) (∅)`.
  "Fibered decomposability coincides with the abstract decomposability of the instantiated
  layer." Forward direction builds the cross element `(w₁.1, w₁.2.1, w₂.2.2)` explicitly and
  verifies it agrees with `w₁` on left formulas and `w₂` on right formulas. Reverse direction
  extracts the cross element from abstract decomposability by testing two custom indicator
  formulas `fun u => u.1 = s ∧ u.2.1 = a₁` (shown `IsLeftP`) and `fun u => u.1 = s ∧ u.2.2 = b₂`
  (shown `IsRightP`).

- **`interp_iff_decomposable` [KV, headline].** `HasInterpolationProperty κ ↔ Decomposable κ`.
  "**Interpolation ⇔ decomposability** (i ⇔ ii). The interpolation property of the fibered model
  holds exactly when the support is decomposable." The forward direction (Interp ⟹ Decomposable)
  is proved by contrapositive: assuming a missing cross element `(s, a₁, b₂) ∉ κ`, it constructs
  explicit left/right formulas `φ := fun w => w.1 = s ∧ w.2.1 = a₁` and
  `ψ := fun w => ¬(w.1 = s ∧ w.2.2 = b₂)`, shows the entailment `φ → ψ` holds over admissible
  worlds (using the missing-cross-element hypothesis), and then invokes an external
  `reverse_direction` lemma (from `Abstract.lean`) to derive a contradiction with the assumed
  interpolation property. The reverse direction (Decomposable ⟹ Interp) invokes the abstract
  `forward_direction` lemma (from `Abstract.lean`) using `decomposable_iff_absDecomposable` and
  `shared_definability` as premises.

- **`fiveWay_full` [KV, headline, the slice's central deliverable].**
  ```
  theorem fiveWay_full (κ : Finset (S × A × B)) :
      List.TFAE
        [ HasInterpolationProperty κ,
          Decomposable κ,
          Amalgamable κ,
          FiberRect κ,
          FiberCI κ,
          FiberProductSurjective κ ]
  ```
  "**The genuine Five-Way equivalence of the fibered HC model**, with both forms of the
  decomposability leg made explicit. In monograph order: interpolation (i), decomposability (ii)
  and its model-theoretic amalgamation form (ii′), fiber rectangularity (iii), fiber conditional
  independence (iv), and fiber-product surjectivity (v) are all mutually equivalent." Note this
  is a **six**-element `TFAE` list realizing a **Five**-Way equivalence — decomposability appears
  twice, once as `Decomposable κ` (leg ii, first-order/combinatorial form) and once as
  `Amalgamable κ` (leg ii′, model-theoretic/abstract-amalgamation form), and the docstring is
  explicit that these are "both forms of the decomposability leg made explicit," not a sixth
  independent leg. Proved via `tfae_have`/`tfae_finish` chaining: 1↔2 (`interp_iff_decomposable`),
  2↔3 (`decomposable_iff_absDecomposable`), 2↔4 (`(fiberRect_iff_decomposable κ).symm`),
  4↔5 (`fiberRect_iff_fiberCI`), 4↔6 (`fiberRect_iff_fps`).

### Sub-cluster B — `FiberProduct.lean` (the natural join over a genuine multi-team interface)

**Docstring framing [STANCE], verbatim from the module header:**
"The natural join over a genuine interface: for sub-teams `T₁ T₂ : Finset ι` and structures on
their marginal types, `join T₁ T₂ κ₁ κ₂` is the largest relation whose marginals lie inside the
factors." Three results are previewed in the docstring:

1. "**The defect decomposition** (`hcCombPi_eq_join_add_gap`): under a cover `T₁ ∪ T₂ = univ`,
   `hcCombPi κ = hcCombPi (join of κ's own marginals) + (|join| − |κ|)` — the defect splits into
   the join-level defect plus the RECONSTRUCTION GAP, the quantitative failure of two-locality.
   On the parity relation the gap is the whole defect (its marginals are full):
   shadow-blindness, quantified."
2. "**Two-cover amalgamation** (`projS_join_left`, `projS_join_right`): two structures whose
   interface marginals agree always glue — the join realizes both factors exactly. With
   `specker_not_glues` this completes the asymmetry: two consistent structures always
   amalgamate; three can fail."
3. "**Leibniz fails at genuine interfaces** (`hcCombPi_join_ne_leibniz`): the juxtaposition law of
   `ProductLaw` does not survive a shared part — kernel-checked on the diagonal structures of the
   Specker file. The swept one-sided form (the Leibniz expression as an UPPER bound for the
   interfaced defect) is recorded as a conjecture in `FIBER_PRODUCT_URS.md`."

- **`join` [def, headline construction].**
  ```
  join (T₁ T₂ : Finset ι) (κ₁ : Finset (∀ i : T₁, X i)) (κ₂ : Finset (∀ i : T₂, X i)) :
      Finset (∀ i, X i) :=
    Finset.univ.filter (fun f => T₁.restrict f ∈ κ₁ ∧ T₂.restrict f ∈ κ₂)
  ```
  "**The natural join**: the largest relation whose `T₁`- and `T₂`-marginals lie inside the
  factors."

- **`mem_join` [KV, infra].** `f ∈ join T₁ T₂ κ₁ κ₂ ↔ T₁.restrict f ∈ κ₁ ∧ T₂.restrict f ∈ κ₂`.
  Proved by `simp [join]`.

- **`subset_join_projS` [KV].** `κ ⊆ join T₁ T₂ (projS κ T₁) (projS κ T₂)`. "Every relation embeds
  in the join of its own marginals." Holds **unconditionally**, no cover hypothesis needed (this
  is echoed explicitly as SJ1 in the URS ledger: "HOLD uncond.").

- **`projPi_join_projS` [KV, infra].** Under `hcover : T₁ ∪ T₂ = Finset.univ`:
  `projPi (join T₁ T₂ (projS κ T₁) (projS κ T₂)) i = projPi κ i`. "Under a cover, the join of a
  relation's own marginals has the relation's projections." (`projPi`, `projS` imported from
  `Marginals.lean`, outside this slice.)

- **`hcCombPi_eq_join_add_gap` [KV, headline, "THE DECOMPOSITION"].**
  ```
  theorem hcCombPi_eq_join_add_gap {T₁ T₂ : Finset ι} (hcover : T₁ ∪ T₂ = Finset.univ)
      (κ : Finset (∀ i, X i)) :
      hcCombPi κ
        = hcCombPi (join T₁ T₂ (projS κ T₁) (projS κ T₂))
          + ((join T₁ T₂ (projS κ T₁) (projS κ T₂)).card - κ.card)
  ```
  "**The defect decomposition along a two-team cover**: the hidden-channel defect splits into the
  defect of the two-local reconstruction plus the reconstruction gap... The gap is the
  quantitative failure of two-locality: it vanishes iff `κ` is its own join. On the parity
  relation the entire defect is gap." Proof combines: (a) `hullPi (join own) = hullPi κ` under
  the cover (via `projPi_join_projS`, funext over `i`); (b) the sandwich
  `κ.card ≤ (join own).card ≤ (hullPi (join own)).card`; (c) `omega` closes the arithmetic once
  `hullPi` is rewritten. (`hcCombPi`, `hullPi` imported from `Marginals.lean`.)

- **`join_comm` [KV, infra].** `join T₁ T₂ κ₁ κ₂ = join T₂ T₁ κ₂ κ₁`. "The join is symmetric."
  Proved by `ext f; simp [mem_join, and_comm]`.

- **`projS_join_left` [KV, headline].**
  ```
  theorem projS_join_left {T₁ T₂ : Finset ι} (hcover : T₁ ∪ T₂ = Finset.univ)
      {κ₁ : Finset (∀ i : T₁, X i)} {κ₂ : Finset (∀ i : T₂, X i)}
      (hcons : κ₁.image (Finset.restrict₂ inter_subset_left)
          = κ₂.image (Finset.restrict₂ inter_subset_right)) :
      projS (join T₁ T₂ κ₁ κ₂) T₁ = κ₁
  ```
  "**Two-cover amalgamation, left leg**: under a cover, two structures whose interface marginals
  agree glue — the join realizes the left factor exactly. The gluing takes the left configuration
  on `T₁` and any interface-compatible right configuration elsewhere." Proof constructs an
  explicit glue function `fun i => if hi : i ∈ T₁ then g ⟨i, hi⟩ else h ⟨i, _⟩` using the `hcons`
  hypothesis to find a compatible `h ∈ κ₂` for each `g ∈ κ₁` (via `Finset.mem_image` on the
  interface restriction), verifies the restriction identities `T₁.restrict glue = g` and
  `T₂.restrict glue = h`, then shows `glue ∈ join T₁ T₂ κ₁ κ₂`.

- **`projS_join_right` [KV, headline, "by symmetry"].** The mirror statement
  `projS (join T₁ T₂ κ₁ κ₂) T₂ = κ₂` under the same hypotheses, with an independently written
  (not merely `join_comm`-derived) mirrored proof using the symmetric glue function
  `fun i => if hi : i ∈ T₂ then h ⟨i, hi⟩ else g ⟨i, _⟩`.

- **`hcCombPi_join_ne_leibniz` [KV, decide, headline negative result].**
  ```
  theorem hcCombPi_join_ne_leibniz :
      hcCombPi (join (X := fun _ : Fin 3 => Fin 2) S01 S12 diag01 diag12)
        ≠ hcCombPi diag01 * (hullPi diag12).card + diag01.card * hcCombPi diag12 := by
    decide
  ```
  "**The Leibniz law dies at a genuine interface**: the juxtaposition law of `ProductLaw`,
  applied verbatim to the join of the two diagonal structures over the interface `{1}`, is false.
  Kernel-checked." This is a `[decide]`-tagged finite computational fact, not a general theorem —
  it exhibits ONE instance (the diagonal structures `diag01`, `diag12` over teams `S01 = {0,1}`,
  `S12 = {1,2}` in ambient `ι = Fin 3`, `X = fun _ => Fin 2`) where the equality fails. The
  quantities `S01`, `S12`, `diag01`, `diag12` are **imported from `HigherObstruction.lean`**
  (confirmed by grep; not part of my mining slice, see Cross-tree notes below), reused here as the
  counterexample witnesses. The URS ledger (`FIBER_PRODUCT_URS.md`, verdict SJ5) records the
  concrete numeric refutation: "6 ≠ 12."

### Sub-cluster B — `FIBER_PRODUCT_URS.md` (the Γ⟷γ discovery ledger for `FiberProduct.lean`)

This file is structured as the corpus's own Γ (in-model derivation, before kernel contact) / γ
(candidate table) / Verdicts+Γ-yield (after kernel contact) discovery protocol — I record its
CONTENT faithfully but note it is itself a first-person artifact of the field's own methodology,
distinct from my miner-instance Γ below.

**Γ — the derivations, verbatim structure (D1–D4), each explicitly self-tagged in-source:**

- **D1 [STANCE, "type route" decision].** "The fiber product of structures on OVERLAPPING index
  sets types painfully as a three-block sum (reindexing hell). The grammar already owns the clean
  formulation: one ambient `ι`, two sub-teams `T₁ T₂ : Finset ι`, factors living on the MARGINAL
  types, and the join `join T₁ T₂ κ₁ κ₂ := univ.filter (fun f => T₁.restrict f ∈ κ₁ ∧ T₂.restrict f ∈ κ₂)`
  — the natural join / largest structure with marginals inside the factors. At `S = T₁ ∩ T₂ = ∅`
  and `T₁ ∪ T₂ = univ` it degenerates to the ⊗ of ProductLaw (a coherence check, deferred)."
  **Note:** this coherence check ("degenerates to ⊗ of ProductLaw at empty interface") is
  explicitly flagged "(a coherence check, deferred)" — i.e. NOT proved in this file or its ledger;
  I record this as an open/deferred item, not a theorem.

- **D2 [STANCE, "the headline, derived in-model"].** Restates the defect-decomposition derivation
  in prose before the Lean proof existed: "`hcCombPi κ = hcCombPi (join own) + (|join own| − |κ|)`
  — the defect splits into the join-level defect plus the RECONSTRUCTION GAP. The gap is the
  quantitative 2-locality failure: `gap = 0 ⟺ κ decomposes along (T₁, T₂)`." Includes a predicted
  sanity instance: "parity3 with T₁ = {0,1}, T₂ = {1,2}: marginals full ⟹ join = full cube ⟹
  d(join) = 0, gap = 4 = the whole defect. Shadow-blindness, quantified by the split."

- **D3 [STANCE, "positive half of the Specker asymmetry"].** In-model derivation preceding
  `projS_join_left`/`projS_join_right`: "Two structures with AGREEING interface marginals always
  glue... Construction: for `g ∈ κ₁` pick `h ∈ κ₂` with the same interface restriction (exists by
  hcons), glue by `fun i => if hi : i ∈ T₁ then g ⟨i, hi⟩ else h ⟨i, _⟩` (the else-branch's
  membership from the cover). No nonemptiness needed: consistency transfers emptiness. This
  completes the pair with `specker_not_glues`: two consistent structures ALWAYS amalgamate; three
  can fail."

- **D4 [STANCE, "Pl_imagine audit"].** "The ⊗-Leibniz law verbatim at a genuine interface is the
  gated analogy of this tick (provenance: pattern-continuation from ProductLaw). The in-model
  prediction is KILL: the interface correlates the factors, so the (hull,size) bi-grading is no
  longer multiplicative. Its kill is the tick's purpose: 'Leibniz fails at genuine interfaces' as
  a kernel-fact, marking where the flagship's H¹ must carry the correction." This is the field's
  own methodological self-report of a "gated" (i.e. flagged, low-trust, pattern-continuation)
  imaginative move made BEFORE kernel contact, subsequently checked.

**γ — the candidate table, verbatim, ambient `ι = Fin 3, T₁ = {0,1}, T₂ = {1,2}` (interface `{1}`),
`X = ZMod 2`:**

| id | statement | provenance | expected |
|----|-----------|------------|----------|
| SJ1 | `κ ⊆ join T₁ T₂ (projS κ T₁) (projS κ T₂)` (no cover needed) | D2 | HOLD uncond. |
| SJ2 | hull(join own) = hull(κ), under cover | D2 hull argument | HOLD ∀ κ at this ι (∅ benign: both ∅); sweep incl. ∅ |
| SJ3 | `hcCombPi κ = hcCombPi (join own) + (\|join own\| − \|κ\|)`, under cover | D2 arithmetic | HOLD (nonempty κ at least) |
| SJ3p | parity3 instance: d(join own) = 0 ∧ gap = 4 | D2 sanity | HOLD |
| SJ4 | amalgamation: cover + hcons → `projS (join) T₁ = κ₁ ∧ projS (join) T₂ = κ₂` | D3 construction | HOLD |
| SJ5 | ⊗-Leibniz verbatim at the {1}-interface: `d(join κ₁ κ₂) = d₁·\|hull κ₂\| + k₁·d₂` | D4 gated analogy | KILL |
| SJ6 | the ≤ direction of SJ5 (boundary probe) | D4 | sweep-only datum |

**Verdicts + Γ-yield — verbatim, filled after kernel contact:**

| id | verdict | disposition |
|----|---------|-------------|
| SJ1 | HOLD uncond. | PROVED `subset_join_projS` |
| SJ2 | HOLD (swept incl. ∅) | PROVED `projPi_join_projS` (under cover) |
| SJ3 | HOLD | PROVED `hcCombPi_eq_join_add_gap` — THE DECOMPOSITION |
| SJ3p | HOLD (whole parity defect = gap) | sweep-fact; the decomposition quantifies shadow-blindness |
| SJ4 | sweep blocked (instance synthesis under double binder); D3's construction validated instead by GENERAL PROOF | PROVED `projS_join_left` + `projS_join_right` (direct mirrored gluing; join_comm as API) |
| SJ5 | KILLED | kernel-fact `hcCombPi_join_ne_leibniz` (diag/diag over interface {1}: 6 ≠ 12) |
| SJ6 | HOLD at swept ambient | **CONJECTURE C-JLeib≤**: `hcCombPi (join κ₁ κ₂) ≤ d₁·\|hull κ₂\| + k₁·d₂` at genuine interfaces — one-ambient evidence, unproved; the "interface only tightens" direction |

- **SJ6 / `C-JLeib≤` [CONJ, named].** This is a **named, explicitly unproved conjecture** — the
  ONE conjecture in my slice. Verbatim: "**CONJECTURE C-JLeib≤**: `hcCombPi (join κ₁ κ₂) ≤
  d₁·|hull κ₂| + k₁·d₂` at genuine interfaces — one-ambient evidence, unproved; the 'interface
  only tightens' direction." The evidentiary basis is stated explicitly as "one-ambient evidence"
  (i.e. checked/swept at a single ambient configuration, `ι = Fin 3` etc., not proved in general)
  — I flag this precisely as a Pl-relevant scope limit: the HOLD verdict for SJ6 is a sweep
  result at one ambient, not a kernel theorem, and the corpus itself does not claim otherwise.

**Γ-yield, the rotation's return leg — verbatim, three numbered points:**

1. "The Leibniz EQUALITY is exactly the zero-interface phenomenon: proved at S = ∅ (ProductLaw),
   kernel-refuted at S = {1} (FiberProduct). The failure locus of the derivation law IS the
   interface — the flagship's H¹ must carry precisely the correction term
   `d₁·H₂ + k₁·d₂ − d(join)`, which SJ6 conjectures is nonnegative." **Note:** the claim "proved
   at S = ∅ (ProductLaw)" refers to a theorem in `ProductLaw.lean`, which is OUTSIDE my mining
   slice — I record the cross-reference as made, without verifying or mining the referenced
   theorem's statement.
2. "The DECOMPOSITION is the first rung of the cohomological ladder built: defect = (2-local
   defect) + (2-locality failure). Iterating along a junction tree is the Vorob'ev induction; the
   gap term is what a Čech H¹ over the cover must compute." [STANCE — positions the result within
   a larger, not-yet-built cohomological programme; "Čech H¹" is used as an interpretive gloss,
   not as a formalized Lean object in this slice.]
3. "Prediction-audit: all four HOLD-expectations held, both KILL-expectations killed, and SJ4's
   instrument failure (not the law) was routed around by proving the general theorem — the
   correct disposition when the probe, not the claim, is the blocker." [STANCE, methodological
   self-audit: explicitly distinguishes "the probe failed" (SJ4's specific sweep-instance
   synthesis under a double binder) from "the claim failed" — the claim was instead established
   by a stronger, general proof (`projS_join_left`/`projS_join_right`) rather than a swept
   instance check.]

**Vorob'ev readiness — verbatim, final paragraph [STANCE, forward-looking/planning]:**
"the amalgamation engine (two-cover case) is proved — it is the induction STEP. Missing grammar
for the Vorob'ev tick: (a) general cover-families (`fam : ∀ T ∈ cover, Finset (∀ i : T, X i)`)
with pairwise consistency and Glues — small, generalizes P2's inline Specker vocabulary; (b) the
ACYCLICITY formalization — the genuine R-expansion and typing decision: running-intersection-
property LIST of teams (induction-friendly, primary candidate) vs Graham-reduction predicate
(decidable, sweep-friendly) — the RIP-list is the recommended primary with Graham as a later
decidability bridge. Positive half = RIP-induction over `projS_join_left/right`; converse = cycle
→ generalized Specker family (parity machinery). PhysLean instances enter after." This is an
explicit **open-problem / roadmap** statement, not a completed result — I flag it as such. I note
the corpus's own directory listing (via `ls`, not full mining) shows files named
`GrahamBridge.lean` / `GRAHAM_BRIDGE_URS.md` and `VorobevConverse.lean` / `CYCLIC_CONVERSE_URS.md`
already present with later timestamps than `FiberProduct.lean`, suggesting this roadmap may have
since been substantially executed elsewhere in the corpus — outside my slice, not mined, flagged
only as an existence observation from a directory listing, not content I read.

## Citations

**No named external literature citations (author, year, title, arXiv id, or DOI) appear anywhere
in my four assigned files.** I searched every docstring, module header, and prose passage in
`Fibered.lean`, `FiberedInterpolation.lean`, `FiberProduct.lean`, and `FIBER_PRODUCT_URS.md` for
author names, years, or identifiers, and found none. All cross-references in this slice are
INTERNAL to the corpus (other `.lean`/`.md` files in the same `ZPM.Measurements.HC` namespace,
e.g. `Combinatorial.lean`, `MutualInformation.lean`, `Abstract.lean`, `Marginals.lean`,
`HigherObstruction.lean`, `ProductLaw.lean`, the "Specker file"). Per the carrier's
"never fabricate a citation" directive, I report this as a definite null result rather than
inventing or omitting silently: **zero verbatim external citations found in this slice.**

## Literature-audit verdicts

**No literature-audit verdicts (novelty claim, no-ancestor claim, "appears in no examined work,"
boundary/Pl-kill against an external result) appear in my four assigned files.** The only
"audit"-flavored language in the slice is the INTERNAL prediction/verdict protocol of
`FIBER_PRODUCT_URS.md` (candidates SJ1–SJ6 predicted before kernel contact, then checked against
the Lean kernel) — this is a self-audit against the corpus's OWN prior in-model derivation, not
against an external literature. I record the one component that superficially resembles a
literature-boundary claim, flagged precisely for what it is and is not:

- The docstring of `FiberProduct.lean` states the Leibniz-failure result is "kernel-checked on the
  diagonal structures of the Specker file," and D4 of the URS calls the ⊗-Leibniz-at-interface
  probe "the gated analogy of this tick (provenance: pattern-continuation from ProductLaw)" — this
  is a claim about internal derivation lineage (this result continues a pattern from an earlier
  internal result, `ProductLaw`), NOT a claim about the work's position relative to external
  published literature. I do not classify it as a [PROBE] literature-audit verdict; I classify the
  surrounding language as [STANCE].

## Cross-tree / divergence notes

1. **"Fiber" is used for two distinct constructions across sub-clusters A and B of this slice.**
   In `Fibered.lean`/`FiberedInterpolation.lean`, "fiber" denotes the slice `fiber κ s ⊆ A × B` of
   a ternary relation `κ ⊆ S × A × B` over a fixed value `s` of a SINGLE shared coordinate — a
   two-team (`A`, `B`) model with one shared axis. In `FiberProduct.lean`, the "fiber product" /
   `join` construction is over an ARBITRARY finite index set `ι` (via `Fintype ι`) with two
   sub-TEAMS `T₁ T₂ : Finset ι` that may overlap on any subset (`T₁ ∩ T₂`, the "interface"), not
   just a single named coordinate — a strictly more general multi-team model. I flag this as a
   naming/scope divergence for the Opus synthesis to resolve: are these presented anywhere in the
   corpus as instances of one single "fiber" concept, or are they two independently motivated
   constructions that happen to share vocabulary? Nothing in my four files states an explicit
   reduction of one to the other (the `FIBER_PRODUCT_URS.md` D1 entry does gesture at a
   degeneration of `join` to `ProductLaw`'s `⊗` at empty interface, explicitly flagged
   "(a coherence check, deferred)" — but this is a different reduction, to `ProductLaw`, not to
   the shared-coordinate `Fibered.lean` model). I did not find, anywhere in my slice, a theorem or
   docstring claiming `Fibered.lean`'s `fiber`/`FiberRect`/etc. are a special case of
   `FiberProduct.lean`'s `join` (e.g. at `ι = S ⊕ A ⊕ B`-style encodings) or vice versa. This
   should be checked against the corpus's other files (outside my slice) before any synthesis
   claims a unification.

2. **`Fibered.lean`'s Four-Way vs `FiberedInterpolation.lean`'s Five-/Six-element Five-Way.** The
   corpus is internally precise and consistent about this staging: `fiveWay_fibered` in
   `Fibered.lean` is explicitly named and docstring-labeled a "Four-Way fiberwise equivalence,"
   with the docstring stating in the SAME file "The interpolation leg (i) is added in
   `ZPM.Measurements.HC.FiberedInterpolation`, completing the genuine Five-Way equivalence." This
   promise is then kept: `FiberedInterpolation.lean`'s `fiveWay_full` docstring opens "`Fibered`
   proved the Four-Way fiberwise equivalence... This file adds the interpolation leg (i)," and
   the resulting `fiveWay_full` theorem is a `List.TFAE` over SIX propositions (interpolation,
   decomposable, amalgamable, fiber-rect, fiber-CI, fiber-product-surjective), NOT five, because
   decomposability is deliberately represented in both its first-order form (`Decomposable κ`,
   leg ii) and its model-theoretic form (`Amalgamable κ`, leg ii′) — the docstring is explicit
   this is "both forms of the decomposability leg made explicit," not a genuine sixth leg. I flag
   this precisely so the Opus synthesis does not report "Six-Way" as a new equivalence class
   distinct from "Five-Way" — the corpus's own naming is "the genuine Five-Way equivalence,"
   the sixth list-element is a duplicate-with-different-form, not a new leg.

3. **`FiberProduct.lean`'s `hcCombPi_join_ne_leibniz` reuses external witnesses from
   `HigherObstruction.lean` (outside my slice).** Confirmed by grep: `S01`, `S12`, `diag01`,
   `diag12` are `def`-ined in `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/HigherObstruction.lean`
   (lines 66, 69, 75, 79 respectively), and `specker_not_glues` is a `theorem` at line 99 of the
   same file. `FiberProduct.lean` imports `ZPM.Measurements.HC.HigherObstruction` and reuses these
   definitions verbatim as its counterexample witnesses and as the complementary asymmetry result
   cited in its module docstring ("With `specker_not_glues` this completes the asymmetry: two
   consistent structures always amalgamate; three can fail."). I did NOT mine
   `HigherObstruction.lean`'s content (its own theorems, docstrings, or the meaning/construction
   of `S01`/`S12`/`diag01`/`diag12`/`specker_not_glues` beyond their bare type signatures found by
   grep) — that file is presumably another miner's slice. This is a hard external dependency the
   synthesis should be aware of: `FiberProduct.lean`'s negative result and its "asymmetry"
   narrative are NOT self-contained within my four files.

4. **`FIBER_PRODUCT_URS.md` D2's referenced "parity3" instance is not defined in my slice.** The
   ledger predicts and later confirms (SJ3p) a "parity3" sanity instance ("parity3 with
   T₁ = {0,1}, T₂ = {1,2}: marginals full ⟹ join = full cube ⟹ d(join) = 0, gap = 4"), but neither
   `FiberProduct.lean` nor `FIBER_PRODUCT_URS.md` defines what "parity3" is (no `def parity3`
   appears in either file I read). This is presumably defined in `ParityFamily.lean` (visible in
   the directory listing, not part of my slice) — I flag this as an external dependency I could
   not resolve within my assigned files, consistent with the carrier's instruction to report
   unresolvable cross-references precisely rather than guess.

5. **The `omit [...] in` pattern appears three times in my slice**, each time to strip unused
   `DecidableEq`/`Fintype`/measurability typeclass hypotheses from a single lemma that does not
   need them, inside a `section` that otherwise carries them for its other lemmas
   (`decomposable_iff_fps` in `Fibered.lean`; `isRect_empty` in `Fibered.lean`; and four times in
   `FiberedInterpolation.lean`'s `section Interp` — `mem_Abd_empty`, `shared_invariant`,
   `shared_definability`, `decomposable_iff_absDecomposable` — all `omit [DecidableEq S]
   [DecidableEq A] [DecidableEq B] in`). I note this as a recurring micro-pattern in the corpus's
   Lean style (minimal-hypothesis discipline per lemma) rather than a mathematical finding; I flag
   it because a miner reading only theorem statements without noting `omit` clauses might
   over-attribute typeclass requirements to lemmas that do not actually need them.

6. **No divergence or contradiction detected between the four files themselves.** Sub-cluster A's
   two files form a strict linear narrative (Four-Way → Five-Way via interpolation) with no
   internal tension. Sub-cluster B's file and its URS are consistent: every theorem name promised
   in the `.lean` docstring (`hcCombPi_eq_join_add_gap`, `projS_join_left`, `projS_join_right`,
   `hcCombPi_join_ne_leibniz`) is exactly the theorem proved in the file body, and every verdict
   in the URS's "Verdicts" table names the exact theorem that discharges it, with one exception
   (SJ6/`C-JLeib≤`) explicitly and honestly left as an unproved conjecture rather than silently
   promoted — I verified this is NOT stated as a theorem anywhere in `FiberProduct.lean`'s body
   (grep-equivalent: I read the whole file; no lemma named anything resembling `C-JLeib` or
   containing a `≤` version of the Leibniz bound appears).

## Agent-axis ignorance (Γ)

Per the carrier's mandate to separate my own ignorance as a miner from the field's content, filed
here precisely rather than folded into the object-axis sections above.

1. **I did not mine the content of imported files outside my slice.** `Fibered.lean` imports
   `Combinatorial.lean` (source of `IsRect`, `projL`, `projR`, `isRect_iff_cross_closed`) and
   `MutualInformation.lean` (source of `InformationTheory.mutualInformationReal`, `uniformMeasure`,
   `mutualInformationReal_uniform_eq_zero_iff_isRect`); `FiberedInterpolation.lean` imports
   `Abstract.lean` (source of `Abd`, `HasInterpolant`, `SharedInvariant`, `HasSharedDefinability`,
   `IsDecomposable`, `reverse_direction`, `forward_direction`); `FiberProduct.lean` imports
   `Marginals.lean` (source of `projPi`, `projS`, `hcCombPi`, `hullPi`, `subset_hullPi`,
   `projPi_projS`, `Finset.restrict₂`) and `HigherObstruction.lean` (source of `S01`, `S12`,
   `diag01`, `diag12`, `specker_not_glues`). I recorded these names exactly as they appear
   (verified by grep where the carrier's completeness demand warranted it, e.g. for the Leibniz
   counterexample witnesses) but did NOT read the statements, docstrings, or proofs of these
   imported lemmas/theorems themselves — that is out of scope for my slice and presumably another
   miner's assignment. This is a deliberate, not accidental, gap.
2. **`ParityFamily.lean` (the likely home of "parity3") is not in my slice**, so I cannot confirm
   the exact statement of the "parity3" instance referenced in `FIBER_PRODUCT_URS.md` D2/SJ3p
   beyond what the ledger states in prose. Flagged above in Cross-tree note 4.
3. **`ProductLaw.lean` (the source of the "⊗-Leibniz law" being refuted) is not in my slice.** I
   record faithfully that `FiberProduct.lean`'s docstring and its URS's D4/SJ5 entries refer to
   "the juxtaposition law of `ProductLaw`" and "`C-JLeib≤`... the flagship's H¹ must carry the
   correction," but I have not read `ProductLaw.lean` itself, so I cannot independently confirm
   the exact original Leibniz-equality statement being contradicted — I report only what my slice
   states about it, attributed as such.
4. **The forward/reverse "direction" lemmas from `Abstract.lean` (`forward_direction`,
   `reverse_direction`, `shared_invariant`'s underlying `SharedInvariant` predicate) are treated
   as black-box premises in `interp_iff_decomposable`'s proof.** I transcribed how they are USED
   (their call sites and argument order) but did not verify their own statements since
   `Abstract.lean` is outside my slice. This means my report of `interp_iff_decomposable`'s proof
   strategy is accurate about the LOCAL proof structure in `FiberedInterpolation.lean` but is
   necessarily incomplete about WHY the invoked abstract lemmas hold.
5. **No citations or literature-audit verdicts were found — I flag the possibility, without
   assertion, that these exist elsewhere in the corpus** (e.g. in `Theory.md`, visible in the
   directory listing but outside my slice) and simply do not appear in the four specific files I
   was assigned. My "zero found" claim is scoped strictly to my four files, not to the corpus as a
   whole; I do not want this null result over-read as "this programme has no literature
   engagement" — that would be an inference beyond my slice's evidence and beyond my mandate.
6. **I did not attempt to independently re-verify the `[decide]` claim in
   `hcCombPi_join_ne_leibniz`** (i.e. I did not re-run the Lean kernel or manually recompute
   `hcCombPi (join S01 S12 diag01 diag12)` vs. `hcCombPi diag01 * (hullPi diag12).card + diag01.card * hcCombPi diag12`
   to confirm "6 ≠ 12" myself) — per the carrier, the mathematics is kernel-verified and my job is
   extraction, not re-verification. I report the ledger's stated numeric values (6, 12) as-is,
   attributed to `FIBER_PRODUCT_URS.md`'s SJ5 verdict row, without independently confirming them.
7. **Coverage of my four assigned files is complete: all were read end to end with the Read tool,
   no offset/limit truncation was used, and no section was skipped.** File line counts read in
   full: `Fibered.lean` (200 lines), `FiberedInterpolation.lean` (269 lines), `FiberProduct.lean`
   (194 lines), `FIBER_PRODUCT_URS.md` (96 lines). I additionally ran two small `grep` checks
   (for cross-referenced symbol definitions and for citation-shaped strings) strictly to resolve
   agent-axis ignorance about cross-file dependencies, not as a substitute for reading — these
   greps did not touch content outside my four files' own citations/cross-references, and did not
   constitute mining of other miners' slices.
