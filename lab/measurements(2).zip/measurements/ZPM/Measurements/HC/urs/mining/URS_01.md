# URS_01 — Abstract core and Spekkens instance

Miner: Sonnet miner 01. Slice: `Abstract.lean`, `Combinatorial.lean`, `Spekkens.lean` under
`ZPM/Measurements/HC/`. Operating discipline: `act(describe)` and `act(search)` only;
`act(imagine)` gated off. Object axis (γ) and agent axis (Γ) kept separate throughout.

## Files mined

1. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/Abstract.lean`
   — 149 lines, read in full. Namespace `HiddenChannelCapacity`. Substrate-neutral abstract
   layer: polymorphic over `World` and `Formula`, no imports beyond `Mathlib.Data.Set.Basic`.
2. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/Combinatorial.lean`
   — 179 lines, read in full. Namespace `HiddenChannelCapacity`. Finite combinatorial support
   layer over `Finset (α × β)`, imports `Mathlib.Data.Finset.{Card,Prod,Image,Filter}`.
3. `/Users/polaris/Documents/Epistemology and Zetesis/Noumenal/design-lab/measurements/ZPM/Measurements/HC/Spekkens.lean`
   — 138 lines, read in full. Namespace `HiddenChannelCapacity.Spekkens`, opens
   `HiddenChannelCapacity`. Imports `ZPM.Measurements.HC.Combinatorial`,
   `Mathlib.Data.Fintype.Prod`, `Mathlib.Data.Fin.Basic`. Concrete instance over
   `Fin 4 × Fin 4`.

All three files were read end to end with the Read tool; no truncation occurred (each file is
short enough to fit in a single read). Both `Abstract.lean` and `Combinatorial.lean` carry a
module docstring stating **[STANCE]** "zero `sorry`" / "All decidable; zero `sorry`" — I did not
independently re-verify this by kernel-checking (out of scope for a mining pass; the carrier
instructs me to treat the corpus as strictly true and catalogue, not re-verify). No `sorry`,
`axiom`, or `admit` token appears anywhere in the text of any of the three files as read.

## Theorems and definitions (each tagged)

### Abstract.lean — substrate-neutral core

**Definitions [def]**

- `Abd (Sat) (kappa) (E) : Set World` — "The admissible worlds compatible with evidence `E`:
  those in `κ` that satisfy every formula of `E`." Formally
  `{w | w ∈ kappa ∧ ∀ φ ∈ E, Sat w φ}`.
- `SharedInvariant (Sat) (SharedEq) (IsShared) : Prop` — "Shared formulas cannot tell apart
  shared-equivalent worlds." Formally `∀ ⦃χ⦄, IsShared χ → ∀ ⦃w₁ w₂⦄, SharedEq w₁ w₂ → (Sat w₁ χ
  ↔ Sat w₂ χ)`.
- `IsDecomposable (Sat) (SharedEq) (IsLeft IsRight) (kappa) (E) : Prop` — "`κ` is
  **decomposable** (amalgamable): any two admissible worlds sharing a type can be amalgamated
  into an admissible world agreeing with the first on the left vocabulary and the second on the
  right. This is the factorization property whose failure `HC` measures." Formally: for
  admissible, shared-equivalent `w₁ w₂`, `∃ w` admissible agreeing with `w₁` on left formulas and
  `w₂` on right formulas.
- `HasInterpolant (Sat) (IsShared) (kappa) (E) (φ ψ) : Prop` — "There is a shared interpolant
  mediating `φ ⇒ ψ` over the admissible worlds." Formally `∃ χ, IsShared χ ∧ (∀ w ∈ Abd …, Sat w
  φ → Sat w χ) ∧ (∀ w ∈ Abd …, Sat w χ → Sat w ψ)`.
- `HasSharedDefinability (Sat) (SharedEq) (IsShared IsLeft) (kappa) (E) : Prop` — "Shared
  definability: every left formula is approximated by a shared formula that is, in turn,
  witnessed by an admissible world satisfying the left formula." Formally `∀ φ, IsLeft φ → ∃ χ,
  IsShared χ ∧ (∀ w ∈ Abd …, Sat w φ → Sat w χ) ∧ (∀ w, Sat w χ → ∃ w', w' ∈ Abd … ∧ Sat w' φ ∧
  SharedEq w' w)`.
- `HasCrossDiscovery (Sat) (IsShared IsLeft IsRight) (kappa) (E) : Prop` — "A cross-domain
  discovery: a non-interpolable left-to-right entailment." Formally `∃ φ ψ, IsLeft φ ∧ IsRight ψ
  ∧ (∀ w ∈ Abd …, Sat w φ → Sat w ψ) ∧ ¬ HasInterpolant Sat IsShared kappa E φ ψ`.

**Theorems [KV]** (all four proved, no `sorry`; module docstring states this layer "contains
the full content of the interpolation–amalgamation biconditional and the oscillation theorem
(monograph §4, §7) with no `sorry`" — tagged **[STANCE]** for the self-attribution of
completeness, **[KV]** for the theorem statements themselves)

- `reverse_direction` — labelled in-docstring as **monograph Thm 4.6**. Statement: given
  `SharedInvariant`, admissible `w₁ w₂` with `SharedEq w₁ w₂`, and a valid cross-entailment
  `φ → ψ` over admissible worlds, if `Sat w₁ φ` holds but `¬ Sat w₂ ψ`, then
  `¬ HasInterpolant Sat IsShared kappa E φ ψ`. Docstring gloss: "If shared invariance holds and
  two admissible, shared-equivalent worlds disagree across a valid cross-entailment, then no
  shared interpolant exists. Shared vocabulary cannot witness the hidden coupling." Proof: one
  `rintro` destructuring an assumed interpolant witness `⟨χ, hχ, hφχ, hχψ⟩`, then direct
  contradiction via `h_inv` and the assumed disagreement — 2 lines.
- `forward_direction` — labelled **monograph Thm 4.7**. Statement: given `IsDecomposable` and
  `HasSharedDefinability`, for any `φ` in `IsLeft`, `ψ` in `IsRight` with a valid
  cross-entailment, `HasInterpolant Sat IsShared kappa E φ ψ` holds. Docstring gloss:
  "Decomposability together with shared definability reconstructs an interpolant for any valid
  cross-entailment. A factoring `κ` always interpolates." Proof: obtains the shared witness `χ`
  from `h_def`, then for any admissible `w₂` satisfying `χ`, obtains a matching `w₁` via the
  definability witness, amalgamates `w₁,w₂` into `wstar` via `h_decomp`, and chains entailment
  through `wstar` — roughly 8 lines, constructive.
- `no_discovery_under_decomposability` — labelled **monograph Thm 7.5**. Statement: given
  `IsDecomposable` and `HasSharedDefinability`, `¬ HasCrossDiscovery Sat IsShared IsLeft IsRight
  kappa E`. Docstring gloss: "A decomposable, shared-definable state admits no cross-domain
  discovery." Proof: direct corollary of `forward_direction` — destructure an assumed
  cross-discovery witness and refute it by constructing the interpolant the forward direction
  guarantees.
- `oscillation_theorem` — labelled **monograph Thm 7.7**. Statement: for a step-indexed family
  `kappaSeq, ESeq : Step → …`, if shared definability holds at every step (`h_def`) and
  cross-discovery holds at *some* step (`h_cross`), then it is **not** the case that
  decomposability holds at every step. Docstring gloss: "If a shared-definable trajectory
  exhibits cross-domain discovery at some step, then it cannot be decomposable at every step:
  the factorization obstruction must become positive somewhere. Via the combinatorial layer this
  reads `∃ t, HC(κₜ) > 0`." Proof: destructure the existential witness step `t`, apply
  `no_discovery_under_decomposability` at that step to the assumed universal decomposability,
  contradiction.

Module-level docstring also states **[STANCE]** these results "are polymorphic over `World` and
`Formula`; the finite combinatorial instance (`ZPM.Measurements.HC.Combinatorial`) supplies the
measurable `hidden channel capacity` whose vanishing is exactly decomposability" — this is the
declared bridge from the abstract layer to the combinatorial layer, asserted in prose, not
itself a Lean-checked link between the two files (no shared type or explicit reduction lemma
connects `IsDecomposable`/`HasInterpolant` in `Abstract.lean` to `IsRect`/`hcComb` in
`Combinatorial.lean`; the connection is asserted via the shared informal name "HC" and the
narrative, not via an explicit interpretation theorem in either file).

### Combinatorial.lean — finite support-level instance

**Definitions [def]**

- `projL (κ) : Finset α := κ.image Prod.fst` — "Left marginal support of `κ`."
- `projR (κ) : Finset β := κ.image Prod.snd` — "Right marginal support of `κ`."
- `IsRect (κ) : Prop := κ = projL κ ×ˢ projR κ` — "`κ` is **rectangular**: it equals the product
  of its marginal supports. At support level this is fiber-product surjectivity /
  decomposability."
- `hcComb (κ) : ℕ := (projL κ ×ˢ projR κ).card - κ.card` — "The **combinatorial hidden channel
  capacity**: the number of admissible configurations missing from the full product of the
  marginals. Zero iff `κ` factors." Docstring identifies this as "the monograph's combinatorial
  proxy `HCcomb`" **[STANCE]**.
- `restrictL (κ) (keep) : Finset (α × β) := κ.filter (fun p => p.1 ∈ keep)` — "Private/shared
  evidence on the left component: keep only pairs whose left coordinate lies in `keep` (row
  restriction in the fiber)."
- `restrictR (κ) (keep) : Finset (α × β) := κ.filter (fun p => p.2 ∈ keep)` — symmetric, "column
  restriction in the fiber."

**Theorems [KV]** (all proved with explicit tactic terms, no `decide` in this file — every proof
is a hand-written Finset argument)

- `subset_prod (κ)` — `κ ⊆ projL κ ×ˢ projR κ`. "Every admissible pair lies in the product of the
  marginals." Proof via `Finset.mem_product` and `Finset.mem_image_of_mem` on each coordinate.
- `hcComb_eq_zero_iff_isRect (κ)` — `hcComb κ = 0 ↔ IsRect κ`. "The defect vanishes exactly when
  `κ` is rectangular (factors as a product of its marginals). This is `HC = 0 ⇔ factorization`
  at the support level." This is the layer's headline biconditional. Proof: uses `subset_prod`
  for the cardinality inequality, then `Finset.eq_of_subset_of_card_le` (forward) and a direct
  `omega` cardinality argument (backward).
- `isRect_iff_cross_closed (κ)` — `IsRect κ ↔ ∀ a ∈ projL κ, ∀ b ∈ projR κ, (a, b) ∈ κ`.
  "Rectangularity is equivalent to the support being closed under cross recombination: if `a`
  and `b` are each individually admissible (in the marginals) then the pair `(a, b)` is
  admissible. This is the support-level decomposability ⇔ rectangle equivalence — the precise
  statement that `HC = 0` means 'no hidden coupling between the components.'" Proof via
  `Finset.Subset.antisymm` with `subset_prod` supplying one direction.
- `isRect_of_projL_card_le_one (κ)` — `(projL κ).card ≤ 1 → IsRect κ`. "If the left marginal has
  at most one element, `κ` is rectangular: a single admissible left value forces the support to
  be a full product." Proof: `Finset.Subset.antisymm`, uses `Finset.card_le_one.mp` to force
  equality of left coordinates among any two witnesses in `projL κ`, then `Prod.ext_iff`.
- `isRect_of_projR_card_le_one (κ)` — symmetric statement for the right marginal, mirror proof.
- `isRect_restrictL_singleton (κ) (a)` — `IsRect (restrictL κ {a})`. "**Singleton private
  evidence resolves** (monograph Thm 8.5): restricting the left component to a single value
  always yields a rectangular (factoring) support — the coupling is resolved." Proof:
  `isRect_of_projL_card_le_one` applied after bounding `(projL (restrictL κ {a})).card ≤ 1` via
  a subset-into-`{a}` argument and `Finset.card_singleton`.
- `isRect_restrictR_singleton (κ) (b)` — symmetric statement for right-restriction, mirror proof.
- `hcComb_restrictL_singleton (κ) (a)` — `hcComb (restrictL κ {a}) = 0`. "Corollary: singleton
  private evidence drives the combinatorial HC to zero." Direct corollary of
  `hcComb_eq_zero_iff_isRect` and `isRect_restrictL_singleton`. Note: no symmetric
  `hcComb_restrictR_singleton` corollary is stated in this file (the right-restriction analogue
  of `isRect_restrictR_singleton` is proved but not carried through to an `hcComb`-corollary
  here) — recorded as a **Γ** observation below, not asserted as a gap in the field's total
  corpus since a symmetric lemma could exist elsewhere outside my slice.

Module docstring states **[STANCE]**/**[CONJ]**-adjacent forward pointer: "The real-valued
mutual-information form `HC(κ) = maxₛ I(P₁;P₂ ∣ S=s)` (whose vanishing coincides with `hcComb =
0` via `ZPM.InformationTheory.MutualInformation`) is a planned extension on top of this support
skeleton." This is an explicit forward-reference to a file (`ZPM.InformationTheory.MutualInformation`)
that is **outside my assigned slice** — I did not open it (recorded under Γ below; note this
import path differs from the sibling file `MutualInformation.lean` that sits directly in
`ZPM/Measurements/HC/`, listed in the directory but also outside my slice — I cannot resolve
whether `ZPM.InformationTheory.MutualInformation` and `ZPM/Measurements/HC/MutualInformation.lean`
name the same module or two different ones from the docstring text alone).

### Spekkens.lean — Spekkens toy-model instance

**Abbreviations / definitions [def]**

- `Ontic := Fin 4` — "One elementary system's ontic states (two bits)."
- `BiOntic := Ontic × Ontic` — "A bipartite ontic configuration."
- `kId : Finset BiOntic := {(0, 0), (1, 1), (2, 2), (3, 3)}` — "Identity correlation `(i, i)` —
  maximally entangled."
- `kX : Finset BiOntic := {(0, 1), (1, 0), (2, 3), (3, 2)}` — "`X`-flip correlation — maximally
  entangled."
- `kZ : Finset BiOntic := {(0, 2), (1, 3), (2, 0), (3, 1)}` — "`Z`-flip correlation — maximally
  entangled."
- `kY : Finset BiOntic := {(0, 3), (1, 2), (2, 1), (3, 0)}` — "`Y`-flip correlation — maximally
  entangled."
- `kSep : Finset BiOntic := {(0, 0), (0, 1), (1, 0), (1, 1)}` — "A separable (product) state
  `{0,1} × {0,1}`."
- `kFull : Finset BiOntic := Finset.univ` — "Full ignorance: every configuration admissible."
- `kPartial : Finset BiOntic := {(0, 0), (1, 1), (2, 2), (2, 3), (3, 2), (3, 3)}` — "A partially
  entangled state (`hcComb = 10`, intermediate)."
- `oscillationTrajectory : List (Finset BiOntic) := [kFull, kId, restrictL kId {0, 1}, restrictL
  kId {0}]` — "The four-step oscillation trajectory `κ_full → κ_id → κ_id|_(A∈{0,1}) →
  κ_id|_(A=0)`."

**Theorems, decidable-check class [decide]** (all discharged by `by decide`, i.e. finite kernel
evaluation — module docstring: "The decidable computations are discharged by `decide` (kernel
evaluation), keeping them axiom-clean" **[STANCE]** for the axiom-clean framing, **[decide]** for
each individual fact)

- `kId_hcComb : hcComb kId = 12`
- `kX_hcComb : hcComb kX = 12`
- `kZ_hcComb : hcComb kZ = 12`
- `kY_hcComb : hcComb kY = 12`
- `kSep_hcComb : hcComb kSep = 0`
- `kFull_hcComb : hcComb kFull = 0`
- `kPartial_hcComb : hcComb kPartial = 10`
- `kId_restrictR_pair_unresolved : hcComb (restrictR kId {0, 1}) = 2` — "**Shared evidence cannot
  resolve.** Restricting the right wing of the identity state to the pair `{0,1}` leaves a
  non-rectangular support with `hcComb = 2 > 0`."
- `kId_restrictL_pair_unresolved : hcComb (restrictL kId {0, 1}) = 2` — "**Private pair does not
  resolve.** A left-wing pair restriction likewise keeps `hcComb = 2`."
- `oscillationTrajectory_profile : oscillationTrajectory.map hcComb = [0, 12, 2, 0]` — "The
  combinatorial capacity profile along the trajectory: `0 → 12 → 2 → 0`."

**Theorems, derived from the abstract/combinatorial layer [KV]** (proved by composing the
already-proved lemmas from `Combinatorial.lean`, not by `decide`)

- `kId_not_isRect : ¬ IsRect kId` — "The identity-correlated state does not factor (is
  entangled). Derived from the measured capacity `hcComb kId = 12 ≠ 0`." Proof: assumes `IsRect
  kId`, derives `hcComb kId = 0` via `hcComb_eq_zero_iff_isRect`, contradicts `kId_hcComb` via
  `omega`.
- `kSep_isRect : IsRect kSep` — "The separable state factors. Derived from `hcComb kSep = 0`."
  Proof: direct application of `(hcComb_eq_zero_iff_isRect kSep).mp kSep_hcComb`.
- `kId_restrictL_singleton_resolves (a : Ontic) : hcComb (restrictL kId {a}) = 0` — "**Private
  singleton resolves**, for every left value — obtained from the general structural theorem
  `isRect_restrictL_singleton`, not by computation." Proof: direct application of
  `hcComb_restrictL_singleton kId a`. Explicitly contrasted in-docstring with the `decide`-based
  facts above: this one is universally quantified over all `a : Ontic` and is proved by the
  *general* theorem from `Combinatorial.lean`, not by finite case-check (since `decide` alone
  could not discharge a `∀ a` statement as efficiently / at all in the same style — the docstring
  itself draws this contrast).
- `spekkens_oscillation_witness : hcComb kFull = 0 ∧ 0 < hcComb kId ∧ 0 < hcComb (restrictL kId
  {0, 1}) ∧ hcComb (restrictL kId {0}) = 0` — "**Spekkens witnesses oscillation.** Both endpoints
  of the trajectory factor (`hcComb = 0`) yet the interior states do not (`hcComb > 0`): the rise
  and the fall are both realized, so the `0 → >0 → 0` shape is non-vacuous." Proof: conjunction
  assembled from `kFull_hcComb`, `kId_hcComb` (via `omega`), `kId_restrictL_pair_unresolved` (via
  `omega`), and `kId_restrictL_singleton_resolves 0`.
- `spekkens_not_perpetually_rectangular : ¬ ∀ κ ∈ oscillationTrajectory, IsRect κ` — "Mirror of
  `oscillation_theorem`'s conclusion at the support level: the trajectory is not rectangular at
  every step (the identity-correlated state is the non-factoring witness, exactly as the
  abstract theorem forces)." Proof: one-line function taking the universal hypothesis `h`,
  instantiated at `kId` (membership by `simp [oscillationTrajectory]`), refuted by
  `kId_not_isRect`.

Module docstring frames the layer's overall content as a set of **predictions beyond Spekkens'
binary classification** **[STANCE]**: "Beyond Spekkens' binary entangled/separable label, HC
predicts" the three bullet points (shared-evidence-cannot-resolve, private-singleton-resolves,
private-pair-does-not-resolve), and explicitly labels itself **[STANCE]**: "This is an
illustrative instance of the support layer, not core pure mathematics."

The final docstring block ("Witness to the oscillation theorem") makes an explicit
**interpretive claim [STANCE]** connecting the concrete trajectory to the abstract theorem: "The
measurement trajectory from full ignorance, through the learned identity correlation, to a
resolved (single-row) state realizes the necessary `HC : 0 → >0 → 0` shape of
`HiddenChannelCapacity.oscillation_theorem`: one cannot pass from an unstructured state to a
resolved state *through* genuine cross-correlation without a transient rise in the factorization
obstruction." I flag (per carrier A4 instructions) that this is a narrative gloss, not a Lean
theorem that literally invokes `oscillation_theorem` as a lemma — `spekkens_not_perpetually_rectangular`
and `spekkens_oscillation_witness` are proved directly from the combinatorial facts, not by
instantiating the abstract `oscillation_theorem` with `Sat := (fun w φ => …)` etc. specialized to
this instance. The connection between the abstract theorem and this concrete witness is asserted
in prose, not machine-checked as an instantiation in this file. This is not a claim the Lean does
not obviously support (the numerical shape `0 → 12 → 2 → 0` genuinely instantiates the pattern
`0 → >0 → 0`) — it is a correctly-scoped illustrative claim, but the *mechanism* (deriving the
concrete facts as an instance of the abstract theorem, versus deriving them independently and
noting the shape matches) differs from what a casual reading of "witness to the oscillation
theorem" might suggest. Recorded here as a precise, not inflated, Pl-adjacent observation per the
carrier's A4 clause.

## Citations (verbatim, organized by claim)

Exactly one named external work appears anywhere in my three files:

- **"Spekkens 2007"** — verbatim occurrence, `Spekkens.lean` line 14: "The combinatorial HC
  computed on Spekkens' bipartite epistemic states over the ontic space `Fin 4 × Fin 4`
  (Spekkens 2007)." No author full name given beyond the surname "Spekkens," no title given, no
  arXiv id given, no DOI given. **No id given.** Supports the claim: the toy-model construction
  (ontic space `Fin 4 × Fin 4`, bipartite epistemic states, entangled/separable binary
  classification) formalized by `kId, kX, kZ, kY, kSep, kFull, kPartial` and the associated
  theorems in `Spekkens.lean` is an instance of (attributed to) this cited 2007 work. I searched
  the entire `ZPM/Measurements/HC/` tree (all `.lean` and `.md` files, via `grep -rn -i
  "spekkens"`) for any fuller citation (arXiv id, DOI, title) that might resolve this reference
  elsewhere in the corpus; the only other occurrences are three bare mentions of the surname
  "Spekkens" in `Theory.md` (lines 145, 170, 364, 404 — all narrative references to "the
  Spekkens instance" or "Spekkens oscillation," none carrying a full citation). No fuller
  citation exists anywhere in the tree that I could locate. This is recorded, not fabricated: I
  am not supplying the standard external identifier for Spekkens' 2007 toy-model paper myself,
  since the carrier's rule against fabrication applies regardless of whether I might "know" the
  correct id from general background — the corpus itself does not carry it, and my mandate is to
  transcribe only what is present.

No other citations, references to external papers, arXiv ids, or DOIs appear in `Abstract.lean`,
`Combinatorial.lean`, or `Spekkens.lean`. In particular, monograph-internal cross-references
("monograph Thm 4.6," "monograph Thm 4.7," "monograph Thm 7.5," "monograph Thm 7.7," "monograph
Thm 8.5," "monograph §4, §7") are *not* external citations — they are internal pointers to
`Theory.md` (or whatever document constitutes "the monograph") within the same research
programme, transcribed verbatim above alongside each theorem, not listed here as bibliographic
citations.

## Literature-audit verdicts

None of my three files contains a literature-audit verdict in the sense the carrier defines
(no-ancestor claim, killed-target claim, boundary/Pl-kill claim, or an "appears in no examined
work" scope statement). No PROBE-tagged content exists in `Abstract.lean`, `Combinatorial.lean`,
or `Spekkens.lean`. The only literature contact in my slice is the single "Spekkens 2007"
attribution recorded above under Citations, which is a positive attribution (this construction
*is* an instance of that prior work), not a novelty or no-ancestor claim. I did not encounter any
scope statement of the form "searched N works" or "no ancestor found in field X" within my
assigned files. (I note, without reading it, that other files in the HC directory — e.g.
`Theory.md`, and possibly some of the `*_URS.md` / `*_DISCOVERY_URS.md` files listed in the
directory but outside my slice — plausibly carry literature-audit verdicts about landed contact
with named external results, e.g. the line I incidentally saw while grepping Theory.md for
cross-references: "The reverse direction of the Ben-David–Hrubeš–Moran–Shpilka–Yehudayoff
compression theorem (learnability undecidability, Nature MI 2019) is closed in Kuratowski form."
This is **not** in my slice — I did not read the file section containing it, I saw only this one
line via a targeted grep while checking for cross-references to my own theorem names, and I
record it here only as a pointer for the orchestrator/synthesizer to route to whichever miner
owns that content, not as a finding I am claiming coverage of. I did not verify this citation's
accuracy, completeness, or exact wording beyond what appears in the single line quoted.)

## Cross-tree / divergence notes

These notes come from two sources: (a) internal consistency across my own three files, and (b) a
narrowly-targeted `grep` I ran against `Theory.md` (the monograph, not in my slice) purely to
locate cross-references to identifiers *from my own files* — I did not read `Theory.md` beyond
the specific lines returned by that grep, and I claim no coverage of it.

**(a) Internal to my slice**

- The bridge between `Abstract.lean`'s polymorphic `IsDecomposable`/`HasInterpolant` machinery
  and `Combinatorial.lean`'s concrete `IsRect`/`hcComb` machinery is **asserted in prose only**
  within my slice. `Abstract.lean`'s module docstring states: "the finite combinatorial instance
  (`ZPM.Measurements.HC.Combinatorial`) supplies the measurable `hidden channel capacity` whose
  vanishing is exactly decomposability" — but no theorem in either `Abstract.lean` or
  `Combinatorial.lean` formally instantiates the abstract `World`/`Formula`/`Sat` triple with the
  concrete `Finset (α × β)` structure and *proves* that `IsDecomposable` (abstract) coincides
  with `IsRect` (concrete) under that instantiation. The two layers are conceptually parallel
  (both produce a "defect vanishes iff factors" biconditional: `reverse_direction` +
  `forward_direction` abstractly, `hcComb_eq_zero_iff_isRect` concretely) but are not linked by
  an explicit Lean term inside my slice. This is exactly the kind of "reads as circular /
  could-not-map" observation the carrier asks me to flag as content, not hide — recorded here as
  γ-content (a structural fact about the corpus), and additionally as a Γ item below (I was
  unable, within my slice, to locate the actual reduction).
- `Combinatorial.lean` proves `isRect_of_projR_card_le_one` and `isRect_restrictR_singleton`
  (the right-marginal mirror lemmas) but stops one step short of a symmetric
  `hcComb_restrictR_singleton` corollary — only the left-hand corollary
  `hcComb_restrictL_singleton` is stated. `Spekkens.lean` only ever uses the left-restriction
  corollary (`kId_restrictL_singleton_resolves`), consistent with this asymmetry, and never
  needs a right-restriction `hcComb`-corollary. This reads as a deliberate economy (the
  Spekkens instance only exercises the left leg) rather than an oversight, but I record the
  asymmetry precisely since the carrier asks me to note anything that "reads as circular or
  incomplete."
- `Combinatorial.lean`'s docstring forward-references `ZPM.InformationTheory.MutualInformation`
  (a *planned* mutual-information form of HC) as the source of the eventual real-valued
  `HC(κ) = maxₛ I(P₁;P₂ ∣ S=s)` measure. I could not resolve, from within my slice, whether this
  import path is the same module as the file `MutualInformation.lean` that I saw listed directly
  in the `ZPM/Measurements/HC/` directory (different namespace path: `ZPM.InformationTheory.*`
  vs. a file sitting in `ZPM/Measurements/HC/`) — recorded as Γ below.

**(b) Against the monograph (`Theory.md`), via targeted grep only, not full-file coverage**

- `Theory.md` (§3, "What is actually proven," lines ~136-148 as I saw them) states **[PROBE /
  STANCE]**, verbatim: "the abstract interpolation–amalgamation biconditional and the
  **oscillation theorem** — notably proved from **no axioms at all** (not even choice)." This
  is an axiom-freedom claim about exactly the four theorems I catalogued in `Abstract.lean`
  (`reverse_direction`, `forward_direction`, `no_discovery_under_decomposability`,
  `oscillation_theorem`). I did not independently run `#print axioms` against these theorems to
  verify this claim (out of scope for a mining pass) — I flag it as a **[STANCE]**-tagged claim
  made about my slice's content from outside my slice, worth the synthesizer's attention since
  it is a strong, checkable claim (axiom-freedom is a `#print axioms` away from verification) and
  should probably be independently confirmed at some point in the discovery pipeline, not
  because I have any reason to doubt it.
- Same passage states, verbatim: "the combinatorial layer (`hcComb_eq_zero_iff_isRect`,
  cross-recombination)" — this matches exactly the two headline theorems I catalogued
  (`hcComb_eq_zero_iff_isRect` and `isRect_iff_cross_closed`, the latter being the
  "cross-recombination" result). Consistent, no divergence.
- Same passage states, verbatim: "the Spekkens instance, including an explicit oscillation
  trajectory. The oscillation theorem is the dynamical heart: a trajectory of ignorance
  structures that ever exhibits a cross-domain discovery cannot have been factorable at every
  step — the obstruction must spike. Discovery has a conservation law, and `hcComb` is what it
  conserves against." This is a **[STANCE]** interpretive gloss ("discovery has a conservation
  law") layered on top of the **[KV]** `oscillation_theorem` and its Spekkens witness — the
  "conservation law" framing itself is not a Lean-stated theorem anywhere in my slice; it is
  monograph narrative. Flagged, not endorsed or denied.
- Line ~170 of `Theory.md`: "The CHSH support/distribution boundary and the Spekkens oscillation
  witness are formalized." Consistent with my slice (the Spekkens oscillation witness is indeed
  formalized, via `spekkens_oscillation_witness` and `spekkens_not_perpetually_rectangular`). I
  cannot speak to the CHSH support/distribution boundary claim — that content is not in my
  slice.
- I noted, purely incidentally while grepping for my own identifiers, one line at `Theory.md`
  line ~554 in a comparison table: "Discrete `H¹`-side of the flagship (set-valued gluing ⟺
  acyclic nerve) | **KV** (qualitative); `χ = hcComb` still **CONJ** | §3, §8" — this suggests
  the monograph itself distinguishes a **[KV]**-qualitative reading of `hcComb`'s vanishing from
  a still-**[CONJ]**ectural *quantitative* identification of `hcComb` with an Euler
  characteristic `χ` of some cohomological construction. This is squarely outside my slice (no
  Euler characteristic, no `H¹`, no cohomology appears anywhere in `Abstract.lean`,
  `Combinatorial.lean`, or `Spekkens.lean`), but I record it because it directly bears on how
  "final" or "provisional" the reader should take `hcComb` itself to be: within my slice
  `hcComb` is a fully proved, decidable, `[KV]` natural-number invariant with a proved
  biconditional characterization; the monograph's own accounting (per this one line) treats a
  *further*, cohomological reading of that same invariant as still open. Both statements are
  true simultaneously and are not in tension — flagged only so the synthesizer does not conflate
  "hcComb is proved to vanish iff rectangular" (true, in my slice) with "hcComb's cohomological
  meaning is proved" (not claimed anywhere in my slice, and per this line, explicitly still
  CONJ elsewhere in the corpus).

## Agent-axis ignorance (Γ)

Precise, itemized record of what I personally could not resolve, verify, or fully parse, kept
strictly separate from the object-axis content above.

1. **Citation identifier gap (Spekkens 2007).** My slice cites "Spekkens 2007" with no arXiv id,
   DOI, or title. I searched the entire HC tree via grep and found no fuller citation anywhere
   in the corpus. I am reporting this as a corpus-level gap (not filling it myself), per the
   carrier's absolute rule against fabricating identifiers. This is a UK on the discovery axis
   in the sense that the *field's own corpus* does not (yet) carry a resolvable citation for a
   construction it explicitly attributes to prior work — worth flagging to whoever maintains
   the bibliography.
2. **Unresolved abstract-to-combinatorial bridge.** I could not locate, within my assigned
   files, any Lean term that formally instantiates the abstract layer's `World`/`Formula`/`Sat`
   machinery with the combinatorial layer's `Finset (α × β)` structure and proves the two
   "defect vanishes iff factors" biconditionals coincide under that instantiation. It is
   possible such a bridge lemma exists in one of the many other files in the HC directory I was
   not assigned (e.g. `Fibered.lean`, `FiberedInterpolation.lean`, `FiberProduct.lean`,
   `Marginals.lean` are plausible candidates by name alone) — I have not opened any of them and
   make no claim about their contents. This is UK on my own agent axis: I do not know whether
   the bridge exists elsewhere in the tree or is simply asserted narratively throughout the
   whole corpus.
3. **Unresolved import-path identity.** `Combinatorial.lean`'s docstring references
   `ZPM.InformationTheory.MutualInformation`; the directory listing (seen only as a listing, not
   opened) shows a sibling file `MutualInformation.lean` sitting directly under
   `ZPM/Measurements/HC/`. I cannot determine from my slice alone whether these name the same
   module (i.e., whether the docstring's namespace path is stale, aspirational, or accurate) —
   recorded as UK, not resolved.
4. **No independent kernel re-verification performed.** Per the carrier's instructions, I did
   not run `lake build`, `#print axioms`, or any other kernel-level check against my three
   files. I am relying on (i) the absence of `sorry`/`axiom`/`admit` tokens in the text as read,
   and (ii) the module docstrings' own **[STANCE]** self-attributions of being `sorry`-free and
   (per `Theory.md`, outside my slice) axiom-free. Both are plausible and consistent with what I
   read, but neither is something I personally verified by execution — flagged as a limit of
   this mining pass, not a doubt about the claim.
5. **Bounded, deliberate under-reading of `Theory.md`.** I ran four targeted `grep` calls against
   `Theory.md` (in the parent HC directory) solely to trace cross-references to identifiers from
   my own three files, and read only the specific line-ranges those greps surfaced (roughly
   lines 130-175, plus isolated single lines near 240, 364-420, 450-492, 554-560). I did **not**
   read `Theory.md` end to end and claim zero coverage of it beyond these targeted excerpts.
   Whoever is assigned `Theory.md` as their slice should treat my "Cross-tree" section above as
   a set of pointers to check, not as a substitute for their own full read.
6. **No verification of numeric correctness performed.** The `decide`-discharged facts in
   `Spekkens.lean` (e.g. `hcComb kId = 12`, `hcComb kPartial = 10`) are, per the file's own
   claim, kernel-checked by finite evaluation. I did not independently recompute these by hand
   (e.g. I did not manually verify that `|projL kId ×ˢ projR kId| − |kId| = 16 − 4 = 12`, though
   this arithmetic is easy to sanity-check and is consistent with `kId` having 4 elements and
   full marginals of size 4 each). I note this only as a boundary of what "mining" entailed for
   me, not as a doubt.
7. **Scope discipline note (not a gap, a confirmation).** I did not open any file outside my
   assigned three (`Abstract.lean`, `Combinatorial.lean`, `Spekkens.lean`) except for the
   permitted directory listing and the narrowly-targeted `Theory.md` greps described in item 5,
   which I treat as within the carrier's citation/cross-reference tracing allowance rather than
   as scope creep into another miner's slice. I record this explicitly so the orchestrator can
   judge whether that allowance was used appropriately.

**coverageComplete:** I read all three assigned files end to end via the Read tool, with no
truncation (files are 149, 179, and 138 lines respectively — each read in a single call with no
`limit` or `offset` needed, confirmed by the tool's own line-count output matching the files'
actual lengths). I set `coverageComplete = true` for the structured-schema return. The Γ items
above are genuine open questions and boundary notes, not evidence of skipped or truncated
reading within my slice.
