/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Combinatorial
import ZPM.InformationTheory.MutualInformation.ZeroIffProduct
import Mathlib.Probability.Distributions.Uniform
import Mathlib.Probability.ProbabilityMassFunction.Constructions
import Mathlib.MeasureTheory.Measure.Dirac

/-!
# Hidden Channel Capacity — the mutual-information leg

The combinatorial layer (`ZPM.Measurements.HC.Combinatorial`) proves
`hcComb κ = 0 ↔ IsRect κ`: the support-level hidden channel capacity
vanishes exactly when `κ ⊆ α × β` factors as the product of its marginal
supports. This file adds the **information-theoretic** characterization and
closes the Five-Way equivalence.

The leg runs base-first: the shape of the base structure `κ` governs the
information a distribution laid over it can carry. Put the *uniform*
probability distribution on the admissible set `κ` (the canonical section of
the fibration, the one place base and fibre coincide). The claim is:

> `mutualInformationReal (uniformMeasure κ hκ) = 0  ↔  IsRect κ`.

That is, the two coordinates of a uniformly random admissible pair are
statistically independent exactly when the base support is rectangular; the
discovered base structure decides what this canonical fibre-side measurement can
report. The
mutual information is the Kullback–Leibler divergence of the joint from the
product of its marginals (`ZPM.InformationTheory.MutualInformation`); on a
finite discrete space the relevant absolute-continuity and finite-KL side
conditions hold automatically, so MI `= 0` collapses to the joint equalling
the product of marginals, which at singleton level is precisely
cross-closedness of the support.

## Main results

* `mutualInformationReal_uniform_eq_zero_iff_isRect` — the headline
  equivalence MI `= 0 ↔ IsRect`.
* `fiveWay_uniform` — the four legs (`IsRect`, `hcComb = 0`, MI `= 0`,
  cross-closed) are mutually equivalent (`List.TFAE`).
-/

noncomputable section

open MeasureTheory InformationTheory
open scoped ENNReal

namespace HiddenChannelCapacity

variable {α β : Type*} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
  [MeasurableSpace α] [MeasurableSpace β]
  [DiscreteMeasurableSpace α] [DiscreteMeasurableSpace β]

/-- The uniform probability measure on the admissible set `κ`. -/
def uniformMeasure (κ : Finset (α × β)) (hκ : κ.Nonempty) : Measure (α × β) :=
  (PMF.uniformOfFinset κ hκ).toMeasure

instance (κ : Finset (α × β)) (hκ : κ.Nonempty) :
    IsProbabilityMeasure (uniformMeasure κ hκ) := by
  unfold uniformMeasure; infer_instance

omit [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
  [MeasurableSpace α] [MeasurableSpace β]
  [DiscreteMeasurableSpace α] [DiscreteMeasurableSpace β] in
/-- `κ.card` is positive when `κ` is nonempty (as an `ℝ≥0∞`). -/
lemma card_pos_enn (κ : Finset (α × β)) (hκ : κ.Nonempty) :
    (0 : ℝ≥0∞) < (κ.card : ℝ≥0∞) := by
  have : 0 < κ.card := Finset.card_pos.mpr hκ
  exact_mod_cast this

omit [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
  [MeasurableSpace α] [MeasurableSpace β]
  [DiscreteMeasurableSpace α] [DiscreteMeasurableSpace β] in
/-- `(κ.card : ℝ≥0∞)⁻¹` is positive and finite. -/
lemma cardinv_pos (κ : Finset (α × β)) :
    (0 : ℝ≥0∞) < (κ.card : ℝ≥0∞)⁻¹ :=
  ENNReal.inv_pos.mpr (by exact_mod_cast ENNReal.natCast_ne_top κ.card)

/-! ### Singleton masses of the joint -/

/-- The joint mass on a singleton: `(κ.card)⁻¹` on admissible pairs, `0`
elsewhere. -/
lemma uniformMeasure_singleton (κ : Finset (α × β)) (hκ : κ.Nonempty) (x : α × β) :
    uniformMeasure κ hκ {x} = if x ∈ κ then (κ.card : ℝ≥0∞)⁻¹ else 0 := by
  unfold uniformMeasure
  rw [PMF.toMeasure_apply_singleton _ _ (MeasurableSet.of_discrete),
    PMF.uniformOfFinset_apply]
  congr 1

/-- A pair has positive joint mass iff it is admissible. -/
lemma uniformMeasure_singleton_pos (κ : Finset (α × β)) (hκ : κ.Nonempty) (x : α × β) :
    0 < uniformMeasure κ hκ {x} ↔ x ∈ κ := by
  rw [uniformMeasure_singleton]
  by_cases hx : x ∈ κ
  · simp [hx, cardinv_pos κ]
  · simp [hx]

/-! ### Singleton masses of the marginals -/

/-- The number of admissible pairs in row `a` (left-fiber count). -/
def rowCount (κ : Finset (α × β)) (a : α) : ℕ := (κ.filter (fun p => p.1 = a)).card

/-- The number of admissible pairs in column `b` (right-fiber count). -/
def colCount (κ : Finset (α × β)) (b : β) : ℕ := (κ.filter (fun p => p.2 = b)).card

/-- Left-marginal mass on a singleton equals `rowCount a / κ.card`. -/
lemma marginalFst_singleton (κ : Finset (α × β)) (hκ : κ.Nonempty) (a : α) :
    (uniformMeasure κ hκ).map Prod.fst {a}
      = (rowCount κ a : ℝ≥0∞) * (κ.card : ℝ≥0∞)⁻¹ := by
  unfold uniformMeasure
  rw [Measure.map_apply measurable_fst (MeasurableSet.of_discrete),
    PMF.toMeasure_apply_fintype]
  -- Each indicator term is `c` on the row-fiber of `a`, `0` elsewhere.
  have hterm : ∀ x : α × β, (Prod.fst ⁻¹' {a}).indicator (PMF.uniformOfFinset κ hκ) x
      = if x ∈ κ.filter (fun p => p.1 = a) then (κ.card : ℝ≥0∞)⁻¹ else 0 := by
    intro x
    classical
    rw [Set.indicator_apply, PMF.uniformOfFinset_apply]
    have hmemf : (x ∈ κ.filter (fun p => p.1 = a)) ↔ (x ∈ κ ∧ x.1 = a) :=
      Finset.mem_filter
    have hmemp : (x ∈ Prod.fst ⁻¹' {a}) ↔ (x.1 = a) := by
      simp [Set.mem_preimage]
    by_cases hxa : x.1 = a
    · rw [if_pos (hmemp.mpr hxa)]
      by_cases hxk : x ∈ κ
      · rw [if_pos hxk, if_pos (hmemf.mpr ⟨hxk, hxa⟩)]
      · rw [if_neg hxk, if_neg (fun h => hxk (hmemf.mp h).1)]
    · rw [if_neg (fun h => hxa (hmemp.mp h)), if_neg (fun h => hxa (hmemf.mp h).2)]
  simp_rw [hterm]
  rw [Finset.sum_ite_mem, Finset.univ_inter, Finset.sum_const, rowCount, nsmul_eq_mul]

/-- Right-marginal mass on a singleton equals `colCount b / κ.card`. -/
lemma marginalSnd_singleton (κ : Finset (α × β)) (hκ : κ.Nonempty) (b : β) :
    (uniformMeasure κ hκ).map Prod.snd {b}
      = (colCount κ b : ℝ≥0∞) * (κ.card : ℝ≥0∞)⁻¹ := by
  unfold uniformMeasure
  rw [Measure.map_apply measurable_snd (MeasurableSet.of_discrete),
    PMF.toMeasure_apply_fintype]
  have hterm : ∀ x : α × β, (Prod.snd ⁻¹' {b}).indicator (PMF.uniformOfFinset κ hκ) x
      = if x ∈ κ.filter (fun p => p.2 = b) then (κ.card : ℝ≥0∞)⁻¹ else 0 := by
    intro x
    classical
    rw [Set.indicator_apply, PMF.uniformOfFinset_apply]
    have hmemf : (x ∈ κ.filter (fun p => p.2 = b)) ↔ (x ∈ κ ∧ x.2 = b) :=
      Finset.mem_filter
    have hmemp : (x ∈ Prod.snd ⁻¹' {b}) ↔ (x.2 = b) := by
      simp [Set.mem_preimage]
    by_cases hxb : x.2 = b
    · rw [if_pos (hmemp.mpr hxb)]
      by_cases hxk : x ∈ κ
      · rw [if_pos hxk, if_pos (hmemf.mpr ⟨hxk, hxb⟩)]
      · rw [if_neg hxk, if_neg (fun h => hxk (hmemf.mp h).1)]
    · rw [if_neg (fun h => hxb (hmemp.mp h)), if_neg (fun h => hxb (hmemf.mp h).2)]
  simp_rw [hterm]
  rw [Finset.sum_ite_mem, Finset.univ_inter, Finset.sum_const, colCount, nsmul_eq_mul]

omit [Fintype α] [Fintype β] [DecidableEq β]
  [MeasurableSpace α] [MeasurableSpace β]
  [DiscreteMeasurableSpace α] [DiscreteMeasurableSpace β] in
/-- `rowCount κ a` is positive iff `a` is in the left support. -/
lemma rowCount_pos_iff (κ : Finset (α × β)) (a : α) :
    0 < rowCount κ a ↔ a ∈ projL κ := by
  rw [rowCount, Finset.card_pos, projL, Finset.mem_image]
  constructor
  · rintro ⟨p, hp⟩
    rw [Finset.mem_filter] at hp
    exact ⟨p, hp.1, hp.2⟩
  · rintro ⟨p, hp, rfl⟩
    exact ⟨p, Finset.mem_filter.mpr ⟨hp, rfl⟩⟩

omit [Fintype α] [Fintype β] [DecidableEq α]
  [MeasurableSpace α] [MeasurableSpace β]
  [DiscreteMeasurableSpace α] [DiscreteMeasurableSpace β] in
/-- `colCount κ b` is positive iff `b` is in the right support. -/
lemma colCount_pos_iff (κ : Finset (α × β)) (b : β) :
    0 < colCount κ b ↔ b ∈ projR κ := by
  rw [colCount, Finset.card_pos, projR, Finset.mem_image]
  constructor
  · rintro ⟨p, hp⟩
    rw [Finset.mem_filter] at hp
    exact ⟨p, hp.1, hp.2⟩
  · rintro ⟨p, hp, rfl⟩
    exact ⟨p, Finset.mem_filter.mpr ⟨hp, rfl⟩⟩

/-- Left marginal singleton mass is positive iff `a ∈ projL κ`. -/
lemma marginalFst_pos_iff (κ : Finset (α × β)) (hκ : κ.Nonempty) (a : α) :
    0 < (uniformMeasure κ hκ).map Prod.fst {a} ↔ a ∈ projL κ := by
  rw [marginalFst_singleton κ hκ a, ← rowCount_pos_iff κ a, ENNReal.mul_pos_iff]
  constructor
  · intro h
    have := h.1
    rwa [pos_iff_ne_zero, Ne, Nat.cast_eq_zero, ← Ne, ← pos_iff_ne_zero] at this
  · intro h
    refine ⟨?_, cardinv_pos κ⟩
    exact_mod_cast h

/-- Right marginal singleton mass is positive iff `b ∈ projR κ`. -/
lemma marginalSnd_pos_iff (κ : Finset (α × β)) (hκ : κ.Nonempty) (b : β) :
    0 < (uniformMeasure κ hκ).map Prod.snd {b} ↔ b ∈ projR κ := by
  rw [marginalSnd_singleton κ hκ b, ← colCount_pos_iff κ b, ENNReal.mul_pos_iff]
  constructor
  · intro h
    have := h.1
    rwa [pos_iff_ne_zero, Ne, Nat.cast_eq_zero, ← Ne, ← pos_iff_ne_zero] at this
  · intro h
    refine ⟨?_, cardinv_pos κ⟩
    exact_mod_cast h

/-! ### Singleton mass of the product of marginals -/

omit [DecidableEq α] [DecidableEq β]
  [DiscreteMeasurableSpace α] [DiscreteMeasurableSpace β] in
/-- The product-of-marginals mass on a singleton factors through the marginal
singleton masses. -/
lemma product_singleton (κ : Finset (α × β)) (hκ : κ.Nonempty) (x : α × β) :
    (((uniformMeasure κ hκ).map Prod.fst).prod ((uniformMeasure κ hκ).map Prod.snd)) {x}
      = ((uniformMeasure κ hκ).map Prod.fst) {x.1}
        * ((uniformMeasure κ hκ).map Prod.snd) {x.2} := by
  have hx : ({x} : Set (α × β)) = {x.1} ×ˢ {x.2} := by
    ext y; simp [Prod.ext_iff]
  rw [hx, Measure.prod_prod]

/-- A singleton has positive product-of-marginals mass iff both coordinates lie
in their respective supports. -/
lemma product_singleton_pos_iff (κ : Finset (α × β)) (hκ : κ.Nonempty) (x : α × β) :
    0 < (((uniformMeasure κ hκ).map Prod.fst).prod
          ((uniformMeasure κ hκ).map Prod.snd)) {x}
      ↔ x.1 ∈ projL κ ∧ x.2 ∈ projR κ := by
  rw [product_singleton κ hκ x]
  rw [← marginalFst_pos_iff κ hκ x.1, ← marginalSnd_pos_iff κ hκ x.2]
  constructor
  · intro h
    exact ⟨(ENNReal.mul_pos_iff.mp h).1, (ENNReal.mul_pos_iff.mp h).2⟩
  · rintro ⟨h1, h2⟩
    exact ENNReal.mul_pos h1.ne' h2.ne'

/-! ### Absolute continuity and finite KL -/

/-- The joint is absolutely continuous with respect to the product of its
marginals: on a discrete finite space it suffices to check singletons. -/
lemma uniform_absolutelyContinuous (κ : Finset (α × β)) (hκ : κ.Nonempty) :
    (uniformMeasure κ hκ).AbsolutelyContinuous
      (((uniformMeasure κ hκ).map Prod.fst).prod
        ((uniformMeasure κ hκ).map Prod.snd)) := by
  -- Key singleton implication: zero product mass ⇒ zero joint mass.
  have hsingle : ∀ x : α × β,
      (((uniformMeasure κ hκ).map Prod.fst).prod
        ((uniformMeasure κ hκ).map Prod.snd)) {x} = 0 → uniformMeasure κ hκ {x} = 0 := by
    intro x hprod0
    have hnotpos : ¬ (0 < (((uniformMeasure κ hκ).map Prod.fst).prod
        ((uniformMeasure κ hκ).map Prod.snd)) {x}) := by rw [hprod0]; exact lt_irrefl 0
    rw [product_singleton_pos_iff κ hκ x] at hnotpos
    rw [not_and] at hnotpos
    have hxnk : x ∉ κ := by
      intro hxk
      have hL : x.1 ∈ projL κ := Finset.mem_image_of_mem Prod.fst hxk
      have hR : x.2 ∈ projR κ := Finset.mem_image_of_mem Prod.snd hxk
      exact absurd (hnotpos hL) (by simpa using hR)
    rw [uniformMeasure_singleton]
    simp [hxnk]
  refine Measure.AbsolutelyContinuous.mk ?_
  intro s _ hs0
  classical
  -- Reduce both measures of `s` to sums over the singletons of `s.toFinset`.
  have hfin : s.Finite := Set.toFinite s
  have hsf : s = (↑hfin.toFinset : Set (α × β)) := by simp
  rw [hsf, ← sum_measure_singleton]
  rw [hsf, ← sum_measure_singleton] at hs0
  -- Each singleton mass of the product vanishes, hence each joint singleton mass.
  apply Finset.sum_eq_zero
  intro x hx
  refine hsingle x ?_
  -- A single term of a vanishing sum of nonnegatives is zero.
  exact (Finset.sum_eq_zero_iff.mp hs0) x hx

/-- On a finite discrete space the KL of the joint from the product of its
marginals is finite. -/
lemma uniform_klDiv_ne_top (κ : Finset (α × β)) (hκ : κ.Nonempty) :
    InformationTheory.klDiv (uniformMeasure κ hκ)
        (((uniformMeasure κ hκ).map Prod.fst).prod
          ((uniformMeasure κ hκ).map Prod.snd)) ≠ ⊤ := by
  haveI : IsProbabilityMeasure ((uniformMeasure κ hκ).map Prod.fst) :=
    Measure.isProbabilityMeasure_map measurable_fst.aemeasurable
  haveI : IsProbabilityMeasure ((uniformMeasure κ hκ).map Prod.snd) :=
    Measure.isProbabilityMeasure_map measurable_snd.aemeasurable
  refine InformationTheory.klDiv_ne_top (uniform_absolutelyContinuous κ hκ) ?_
  exact Integrable.of_finite

/-! ### Bridge: joint = product of marginals ↔ rectangular -/

/-- The joint equals the product of its marginals iff `κ` is rectangular. -/
lemma uniform_eq_product_iff_isRect (κ : Finset (α × β)) (hκ : κ.Nonempty) :
    uniformMeasure κ hκ
        = ((uniformMeasure κ hκ).map Prod.fst).prod ((uniformMeasure κ hκ).map Prod.snd)
      ↔ IsRect κ := by
  constructor
  · -- joint = product ⇒ membership in κ ↔ membership in projL ×ˢ projR ⇒ IsRect.
    intro hpe
    rw [isRect_iff_cross_closed]
    intro a ha b hb
    have hpos : 0 < (((uniformMeasure κ hκ).map Prod.fst).prod
        ((uniformMeasure κ hκ).map Prod.snd)) {(a, b)} := by
      rw [product_singleton_pos_iff κ hκ (a, b)]
      exact ⟨ha, hb⟩
    rw [← hpe] at hpos
    exact (uniformMeasure_singleton_pos κ hκ (a, b)).mp hpos
  · -- IsRect ⇒ agree on every singleton ⇒ measures equal (discrete extensionality).
    intro hrect
    apply Measure.ext_of_singleton
    intro x
    -- compare the joint mass and the product mass on `{x}`.
    rw [product_singleton κ hκ x, marginalFst_singleton κ hκ x.1,
      marginalSnd_singleton κ hκ x.2, uniformMeasure_singleton]
    -- With κ = projL ×ˢ projR: rowCount, colCount are determined by membership.
    have hcross : ∀ a ∈ projL κ, ∀ b ∈ projR κ, (a, b) ∈ κ :=
      (isRect_iff_cross_closed κ).mp hrect
    -- rowCount a = (projR κ).card if a ∈ projL κ else 0.
    have hrow : (rowCount κ x.1 : ℝ≥0∞) =
        if x.1 ∈ projL κ then ((projR κ).card : ℝ≥0∞) else 0 := by
      by_cases hL : x.1 ∈ projL κ
      · rw [if_pos hL]
        congr 1
        rw [rowCount]
        -- the row over a ∈ projL is in bijection with projR.
        have : κ.filter (fun p => p.1 = x.1) = (projR κ).image (fun b => (x.1, b)) := by
          ext p
          rw [Finset.mem_filter, Finset.mem_image]
          constructor
          · rintro ⟨hp, hp1⟩
            exact ⟨p.2, Finset.mem_image_of_mem Prod.snd hp, by rw [← hp1]⟩
          · rintro ⟨b, hb, rfl⟩
            exact ⟨hcross x.1 hL b hb, rfl⟩
        rw [this, Finset.card_image_of_injective]
        intro b1 b2 h12
        simpa using h12
      · rw [if_neg hL]
        rw [rowCount, Nat.cast_eq_zero, Finset.card_eq_zero, Finset.filter_eq_empty_iff]
        intro p hp hp1
        apply hL
        rw [← hp1]
        exact Finset.mem_image_of_mem Prod.fst hp
    have hcol : (colCount κ x.2 : ℝ≥0∞) =
        if x.2 ∈ projR κ then ((projL κ).card : ℝ≥0∞) else 0 := by
      by_cases hR : x.2 ∈ projR κ
      · rw [if_pos hR]
        congr 1
        rw [colCount]
        have : κ.filter (fun p => p.2 = x.2) = (projL κ).image (fun a => (a, x.2)) := by
          ext p
          rw [Finset.mem_filter, Finset.mem_image]
          constructor
          · rintro ⟨hp, hp2⟩
            exact ⟨p.1, Finset.mem_image_of_mem Prod.fst hp, by rw [← hp2]⟩
          · rintro ⟨a, ha, rfl⟩
            exact ⟨hcross a ha x.2 hR, rfl⟩
        rw [this, Finset.card_image_of_injective]
        intro a1 a2 h12
        simpa using h12
      · rw [if_neg hR]
        rw [colCount, Nat.cast_eq_zero, Finset.card_eq_zero, Finset.filter_eq_empty_iff]
        intro p hp hp2
        apply hR
        rw [← hp2]
        exact Finset.mem_image_of_mem Prod.snd hp
    rw [hrow, hcol]
    -- card κ = (projL κ).card * (projR κ).card since κ = projL ×ˢ projR.
    have hcard : (κ.card : ℝ≥0∞) = ((projL κ).card : ℝ≥0∞) * ((projR κ).card : ℝ≥0∞) := by
      have hc : κ.card = (projL κ ×ˢ projR κ).card := congrArg Finset.card hrect
      rw [hc, Finset.card_product]
      push_cast
      ring
    -- membership of x in κ ↔ membership in projL × projR.
    have hmem : (x ∈ κ) ↔ (x.1 ∈ projL κ ∧ x.2 ∈ projR κ) := by
      constructor
      · intro hxk
        exact ⟨Finset.mem_image_of_mem Prod.fst hxk,
          Finset.mem_image_of_mem Prod.snd hxk⟩
      · rintro ⟨hL, hR⟩
        have := hcross x.1 hL x.2 hR
        simpa using this
    -- finiteness/nonvanishing of `κ.card` as `ℝ≥0∞`.
    have hcard_ne_zero : (κ.card : ℝ≥0∞) ≠ 0 := (card_pos_enn κ hκ).ne'
    have hcard_ne_top : (κ.card : ℝ≥0∞) ≠ ⊤ := ENNReal.natCast_ne_top κ.card
    by_cases hL : x.1 ∈ projL κ <;> by_cases hR : x.2 ∈ projR κ
    · rw [if_pos hL, if_pos hR, if_pos (hmem.mpr ⟨hL, hR⟩)]
      -- (↑R * c) * (↑L * c) = c, using ↑L * ↑R = κ.card and κ.card * c = 1.
      rw [show ((projR κ).card : ℝ≥0∞) * (κ.card : ℝ≥0∞)⁻¹
              * (((projL κ).card : ℝ≥0∞) * (κ.card : ℝ≥0∞)⁻¹)
            = (((projL κ).card : ℝ≥0∞) * ((projR κ).card : ℝ≥0∞)) * (κ.card : ℝ≥0∞)⁻¹
              * (κ.card : ℝ≥0∞)⁻¹ by ring]
      rw [← hcard, ENNReal.mul_inv_cancel hcard_ne_zero hcard_ne_top, one_mul]
    · rw [if_pos hL, if_neg hR, if_neg (by rw [hmem]; exact fun h => hR h.2)]
      simp
    · rw [if_neg hL, if_pos hR, if_neg (by rw [hmem]; exact fun h => hL h.1)]
      simp
    · rw [if_neg hL, if_neg hR, if_neg (by rw [hmem]; exact fun h => hR h.2)]
      simp

/-! ### Headline theorem and Five-Way closure -/

/-- **The information-theoretic leg of HC.** The uniform distribution on the
admissible set `κ` has zero mutual information between its two coordinates iff
`κ` is rectangular (factors as the product of its marginal supports). -/
theorem mutualInformationReal_uniform_eq_zero_iff_isRect
    (κ : Finset (α × β)) (hκ : κ.Nonempty) :
    InformationTheory.mutualInformationReal (uniformMeasure κ hκ) = 0 ↔ IsRect κ := by
  rw [InformationTheory.mutualInformationReal_eq_zero_iff_product
        (uniformMeasure κ hκ)
        (uniform_absolutelyContinuous κ hκ)
        (uniform_klDiv_ne_top κ hκ)]
  exact uniform_eq_product_iff_isRect κ hκ

/-- **Five-Way closure.** All four legs are equivalent: rectangularity, zero
combinatorial defect, zero mutual information of the uniform distribution, and
cross-closedness of the support. -/
theorem fiveWay_uniform (κ : Finset (α × β)) (hκ : κ.Nonempty) :
    List.TFAE
      [ IsRect κ,
        hcComb κ = 0,
        InformationTheory.mutualInformationReal (uniformMeasure κ hκ) = 0,
        (∀ a ∈ projL κ, ∀ b ∈ projR κ, (a, b) ∈ κ) ] := by
  tfae_have 1 ↔ 2 := (hcComb_eq_zero_iff_isRect κ).symm
  tfae_have 1 ↔ 3 := (mutualInformationReal_uniform_eq_zero_iff_isRect κ hκ).symm
  tfae_have 1 ↔ 4 := isRect_iff_cross_closed κ
  tfae_finish

end HiddenChannelCapacity

end
