/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.CechK

/-!
# The keystone: local-end blindness and the cohomology-structure of global ignorance

The thesis-level statements of the completion arc, in the programme's own vocabulary. HC
measures BASE structure, and these theorems say what discovering it yields that no amount of
fibre-side, local measurement can. Every component is banked in the layers below; this file
states what they jointly say about SUPPORT/STRUCTURE, IGNORANCE ABOUT STRUCTURE, and the
STRUCTURE OF IGNORANCE, in the same statement-discipline as the identification arc's keystone
(fiber width is a functional of forced support geometry alone): the theorem IS the thesis.
The direction is base-to-local throughout, from the discovered base class to what local
measurement can and cannot achieve.

* **Local-end blindness** (`completability_not_support_functional`): two prescription
  families on the SAME cyclic cover with IDENTICAL (full) local supports and OPPOSITE
  completability verdicts. Global extendability is not a functional of the local ends:
  fixing every prescription and its support, the most structural the fibre-side data can be,
  still leaves the global coordinate undetermined. The base is the seeing party; the local
  ends are blind to it. The completion-arc sibling of the identification arc's
  `parity_boundary`.
* **Base-side sufficiency** (`completability_class_functional`): one base-derived observable
  decides the verdict, the family's pairing against the nonzero degree-1 class of the nerve:
  completable iff that class evaluation lies within the facet bound. What the local ends
  cannot see is not amorphous; it is exactly one Čech class of the base, with moduli, and
  reading that single class settles completability.
* **One class, three strata, the base deciding uniformly** (`three_strata_one_class`): the
  SAME base class decides the possibilistic verdict (gluing iff the class vanishes: Boolean
  coefficients), the distributional verdict (completable iff the moduli constraint: real
  coefficients), and the quantum verdict (identical, through the diagonal transport arrow).
  The base decides across every coefficient stratum. The Lauritzen–Zwiernik resolution
  (`qjt_not_local`) is the shadow of this structure at the quantum stratum: no strengthening
  of local data can see a global class, because local data lives in the fibres of the
  support fibration and the class does not.
-/

namespace HiddenChannelCapacity

/-- The interior of the moduli is genuinely completable (named instance at `r = 1/2`). -/
theorem cycleFam_completable_half :
    ∃ q, IsCompletionC (X := fun _ => ZMod 2) cyc
      (fun j => edgeDist (1/2) (by norm_num) (by norm_num) j) q :=
  (cycleFam_completable_iff (by norm_num) (by norm_num)).mpr (by norm_num)

/-- **KEYSTONE, local-end blindness**: two families on the same cyclic cover with
IDENTICAL local supports (both full) and OPPOSITE completability. Global extendability is
not a functional of the local ends: the deciding coordinate lives on the base, above every
prescription and its support, and the local ends are blind to it. -/
theorem completability_not_support_functional :
    ∃ (r₁ r₂ : ℝ) (h₁₀ : 0 ≤ r₁) (h₁₁ : r₁ ≤ 1) (h₂₀ : 0 ≤ r₂) (h₂₁ : r₂ ≤ 1),
      (∀ (j : Fin 4) (g : ∀ _i : (cyc j : Finset (Fin 4)), ZMod 2),
        (0 < ((edgeDist r₁ h₁₀ h₁₁ j) g : ℝ) ↔ 0 < ((edgeDist r₂ h₂₀ h₂₁ j) g : ℝ)))
      ∧ (∃ q, IsCompletionC (X := fun _ => ZMod 2) cyc
          (fun j => edgeDist r₁ h₁₀ h₁₁ j) q)
      ∧ ¬ (∃ q, IsCompletionC (X := fun _ => ZMod 2) cyc
          (fun j => edgeDist r₂ h₂₀ h₂₁ j) q) := by
  refine ⟨1/2, 7/8, by norm_num, by norm_num, by norm_num, by norm_num,
    fun j g => iff_of_true
      (edgeDist_full_support (by norm_num) (by norm_num) j g)
      (edgeDist_full_support (by norm_num) (by norm_num) j g),
    cycleFam_completable_half, cycleFam_not_completableC⟩

/-- **KEYSTONE, base-side sufficiency**: completability of the smoothed family is a
functional of its pairing against the nonzero degree-1 class of the cycle nerve. One
base-derived observable decides the verdict: the single class evaluation
`|⟨family, [tw]⟩| ≤ 2`. -/
theorem completability_class_functional {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    (∃ q, IsCompletionC (X := fun _ => ZMod 2) cyc
      (fun j => edgeDist r hr0 hr1 j) q)
      ↔ |∑ j : Fin 4, corrE (tw j) (edgeDist r hr0 hr1 j)| ≤ 2 := by
  rw [cycleFam_completable_iff hr0 hr1,
    Finset.sum_congr rfl fun j _ => corrE_edgeDist hr0 hr1 j,
    Finset.sum_const, Finset.card_univ]
  simp only [Fintype.card_fin, nsmul_eq_mul]
  rw [abs_le]
  constructor
  · rintro ⟨h1, h2⟩
    constructor <;> push_cast <;> linarith
  · rintro ⟨h1, h2⟩
    push_cast at h1 h2
    constructor <;> linarith

/-- **KEYSTONE, one class, three strata, the base deciding uniformly**: the degree-1
cohomology of the cycle nerve (one nonzero class, `H¹ ≅ F₂` via `holF2`, CechCycle) decides
the possibilistic verdict (gluing iff the twist's class vanishes, for EVERY twist), the
distributional verdict (completable iff the moduli constraint, along the smoothing of the
nonzero class's representative `tw`), and the quantum verdict (identical, through the
transport arrow). Ignorance about global structure is blind to the local ends and carried by
the base class, uniformly across coefficient systems. -/
theorem three_strata_one_class :
    (∀ t : Fin 4 → ZMod 2,
      (joinFam (parityBox t)).Nonempty ↔ holF2 t = 0)
    ∧ (∀ (r : ℝ) (hr0 : 0 ≤ r) (hr1 : r ≤ 1),
      (∃ q, IsCompletionC (X := fun _ => ZMod 2) cyc
        (fun j => edgeDist r hr0 hr1 j) q) ↔ (1/4 ≤ r ∧ r ≤ 3/4))
    ∧ (∀ (r : ℝ) (hr0 : 0 ≤ r) (hr1 : r ≤ 1),
      (∃ ω, IsCompletionQ (X := fun _ => ZMod 2) cyc
        (fun j => MState.ofClassical (edgeDist r hr0 hr1 j)) ω)
        ↔ (1/4 ≤ r ∧ r ≤ 3/4)) := by
  refine ⟨fun t => ?_, fun r hr0 hr1 => cycleFam_completable_iff hr0 hr1,
    fun r hr0 hr1 => cycleFam_completableQ_iff hr0 hr1⟩
  rw [Finset.nonempty_iff_ne_empty, ne_eq, parityBox_joinFam_empty_iff t]
  exact (by decide : ∀ u : ZMod 2, ¬u = 1 ↔ u = 0) (holF2 t)

end HiddenChannelCapacity
