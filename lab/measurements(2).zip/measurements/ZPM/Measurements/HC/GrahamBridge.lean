/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Amalgamation

/-!
# The Graham bridge: decidable acyclicity

Acyclicity is a base-structure property of the cover, and this file makes it decidable. `Acyclic
𝒞` says some duplicate-free enumeration of the cover is a running-intersection order;
`GrahamReducible 𝒞` says nondeterministic ear elimination empties the cover, with the cover's
size as fuel. The bridge (`acyclic_iff_grahamReducible`) is a pair of fuel inductions (an RIP
order's head IS an ear whose removal leaves an RIP tail; an elimination run IS an RIP order read
forward), and yields the payoff: the cover's base structure is DECIDABLE.

Consequences: `glues_of_acyclic`, the order-free amalgamation headline, says an acyclic cover
forces every pairwise-consistent family to glue (the permutation between any two duplicate-free
enumerations lifts along the team map), so the discovered base structure licenses the global
verdict machine-checkably; and the kernel facts `speckerCover_not_acyclic` / `pathCover_acyclic`
replace the six-orderings enumeration with the order-free statement.

The DETERMINISTIC greedy ("any ear may be eliminated first") needs a genuine confluence lemma
whose naive deletion proof has a real gap (the ear's home may precede the member that cited
it); it is a named strengthening edge, not assumed here — the nondeterministic form carries the
full bridge without it.
-/

namespace HiddenChannelCapacity

open Finset

section CoverLevel

variable {ι : Type*} [DecidableEq ι]

/-- The union of a list of teams. -/
def listCover : List (Finset ι) → Finset ι
  | [] => ∅
  | T :: rest => T ∪ listCover rest

/-- Team-level running intersection property: each team meets the union of the later teams
inside a single later team. -/
def RIPCover : List (Finset ι) → Prop
  | [] => True
  | T :: rest => (rest = [] ∨ ∃ T' ∈ rest, T ∩ listCover rest ⊆ T') ∧ RIPCover rest

instance decidableRIPCover : ∀ l : List (Finset ι), Decidable (RIPCover l)
  | [] => .isTrue trivial
  | T :: rest =>
    haveI : Decidable (RIPCover rest) := decidableRIPCover rest
    inferInstanceAs (Decidable
      ((rest = [] ∨ ∃ T' ∈ rest, T ∩ listCover rest ⊆ T') ∧ RIPCover rest))

/-- The union of a finite set of teams. -/
def coverU (𝒞 : Finset (Finset ι)) : Finset ι := 𝒞.sup id

lemma listCover_eq_coverU (l : List (Finset ι)) : listCover l = coverU l.toFinset := by
  induction l with
  | nil => simp [listCover, coverU]
  | cons T rest ih =>
    rw [listCover, ih, coverU, coverU, List.toFinset_cons, Finset.sup_insert]
    rfl

/-- The ear condition: the team meets the union of the others inside a single other team (or
there are no others). -/
def IsEarOf (𝒞 : Finset (Finset ι)) (T : Finset ι) : Prop :=
  𝒞.erase T = ∅ ∨ ∃ T' ∈ 𝒞.erase T, T ∩ coverU (𝒞.erase T) ⊆ T'

instance decidableIsEarOf (𝒞 : Finset (Finset ι)) (T : Finset ι) :
    Decidable (IsEarOf 𝒞 T) := by
  unfold IsEarOf
  infer_instance

/-- Nondeterministic ear elimination, fueled. -/
def GrahamN : ℕ → Finset (Finset ι) → Prop
  | 0, 𝒞 => 𝒞 = ∅
  | n + 1, 𝒞 => 𝒞 = ∅ ∨ ∃ T ∈ 𝒞, IsEarOf 𝒞 T ∧ GrahamN n (𝒞.erase T)

instance decidableGrahamN : ∀ (n : ℕ) (𝒞 : Finset (Finset ι)), Decidable (GrahamN n 𝒞)
  | 0, 𝒞 => inferInstanceAs (Decidable (𝒞 = ∅))
  | n + 1, 𝒞 =>
    haveI : ∀ D : Finset (Finset ι), Decidable (GrahamN n D) := decidableGrahamN n
    inferInstanceAs (Decidable (𝒞 = ∅ ∨ ∃ T ∈ 𝒞, IsEarOf 𝒞 T ∧ GrahamN n (𝒞.erase T)))

/-- **Graham reducibility**: ear elimination empties the cover; the cover's size is fuel enough
since every elimination removes exactly one team. -/
def GrahamReducible (𝒞 : Finset (Finset ι)) : Prop := GrahamN 𝒞.card 𝒞

instance (𝒞 : Finset (Finset ι)) : Decidable (GrahamReducible 𝒞) := by
  unfold GrahamReducible
  infer_instance

/-- **Order-free acyclicity**: some duplicate-free enumeration of the cover is a
running-intersection order. -/
def Acyclic (𝒞 : Finset (Finset ι)) : Prop :=
  ∃ order : List (Finset ι), order.Nodup ∧ order.toFinset = 𝒞 ∧ RIPCover order

/-- An RIP order eliminates from the front: its head is an ear and the tail remains RIP. -/
lemma grahamN_of_ripCover :
    ∀ order : List (Finset ι), order.Nodup → RIPCover order →
      GrahamN order.length order.toFinset
  | [], _, _ => by simp [GrahamN]
  | T :: rest, hnd, hrip => by
    obtain ⟨hhead, hripr⟩ := hrip
    have hTnotin : T ∉ rest := (List.nodup_cons.mp hnd).1
    have hndr : rest.Nodup := (List.nodup_cons.mp hnd).2
    have htf : (T :: rest).toFinset.erase T = rest.toFinset := by
      rw [List.toFinset_cons, Finset.erase_insert (by simpa using hTnotin)]
    refine Or.inr ⟨T, by simp, ?_, ?_⟩
    · rcases hhead with rfl | ⟨T', hT', hsub⟩
      · left
        rw [htf]
        simp
      · right
        refine ⟨T', ?_, ?_⟩
        · rw [htf]
          simpa using hT'
        · rw [htf, ← listCover_eq_coverU]
          exact hsub
    · rw [htf]
      exact grahamN_of_ripCover rest hndr hripr

/-- An elimination run is a running-intersection order read forward. -/
lemma exists_ripCover_of_grahamN :
    ∀ (n : ℕ) (𝒞 : Finset (Finset ι)), GrahamN n 𝒞 →
      ∃ order : List (Finset ι), order.Nodup ∧ order.toFinset = 𝒞 ∧ RIPCover order
  | 0, 𝒞, h => ⟨[], by simp, by simpa [GrahamN] using h.symm, trivial⟩
  | n + 1, 𝒞, h => by
    rcases h with rfl | ⟨T, hT, hear, hrec⟩
    · exact ⟨[], by simp, by simp, trivial⟩
    · obtain ⟨order', hnd', htf', hrip'⟩ := exists_ripCover_of_grahamN n _ hrec
      have hTnotin : T ∉ order' := by
        rw [← List.mem_toFinset, htf']
        exact Finset.notMem_erase T 𝒞
      refine ⟨T :: order', List.nodup_cons.mpr ⟨hTnotin, hnd'⟩, ?_, ?_, hrip'⟩
      · rw [List.toFinset_cons, htf', Finset.insert_erase hT]
      · rcases hear with hempty | ⟨T', hT', hsub⟩
        · left
          have : order'.toFinset = ∅ := htf'.trans hempty
          simpa using this
        · right
          refine ⟨T', ?_, ?_⟩
          · rw [← List.mem_toFinset, htf']
            exact hT'
          · rw [listCover_eq_coverU, htf']
            exact hsub

/-- **The Graham bridge**: acyclicity is exactly Graham reducibility. -/
theorem acyclic_iff_grahamReducible (𝒞 : Finset (Finset ι)) :
    Acyclic 𝒞 ↔ GrahamReducible 𝒞 := by
  constructor
  · rintro ⟨order, hnd, htf, hrip⟩
    have hlen : order.length = 𝒞.card := by
      rw [← htf, List.toFinset_card_of_nodup hnd]
    rw [GrahamReducible, ← hlen, ← htf]
    exact grahamN_of_ripCover order hnd hrip
  · intro h
    exact exists_ripCover_of_grahamN _ _ h

/-- **Acyclicity is decidable** — the payoff of the bridge. -/
instance decidableAcyclic (𝒞 : Finset (Finset ι)) : Decidable (Acyclic 𝒞) :=
  decidable_of_iff _ (acyclic_iff_grahamReducible 𝒞).symm

end CoverLevel

section FamilyLevel

variable {ι : Type*} [DecidableEq ι] {X : ι → Type*} [∀ i, DecidableEq (X i)]

omit [DecidableEq ι] [∀ i, DecidableEq (X i)] in
lemma famCover_eq_listCover [DecidableEq ι] (fam : List (LocalStruct ι X)) :
    famCover fam = listCover (fam.map (·.team)) := by
  induction fam with
  | nil => rfl
  | cons L rest ih => rw [famCover, List.map_cons, listCover, ih]

omit [∀ i, DecidableEq (X i)] in
/-- The family-level running intersection property reads only the teams. -/
lemma rip_iff_ripCover (fam : List (LocalStruct ι X)) :
    RIP fam ↔ RIPCover (fam.map (·.team)) := by
  induction fam with
  | nil => simp [RIP, RIPCover]
  | cons L rest ih =>
    rw [RIP, List.map_cons, RIPCover]
    refine and_congr (or_congr ?_ ?_) ih
    · simp
    · rw [← famCover_eq_listCover]
      constructor
      · rintro ⟨L', hL', hsub⟩
        exact ⟨L'.team, List.mem_map_of_mem hL', hsub⟩
      · rintro ⟨T', hT', hsub⟩
        obtain ⟨L', hL', rfl⟩ := List.mem_map.mp hT'
        exact ⟨L', hL', hsub⟩

omit [DecidableEq ι] [∀ i, DecidableEq (X i)] in
/-- A permutation of a mapped list lifts along the map. -/
lemma exists_perm_map_eq {α β : Type*} {g : α → β} :
    ∀ {σ : List β} {l : List α}, σ.Perm (l.map g) → ∃ l' : List α, l'.Perm l ∧ l'.map g = σ := by
  intro σ
  induction σ with
  | nil =>
    intro l hp
    have hmap : l.map g = [] := hp.symm.eq_nil
    exact ⟨[], by rw [List.map_eq_nil_iff.mp hmap], rfl⟩
  | cons b σ' ih =>
    intro l hp
    -- the head occurs in the mapped list; split there
    have hb : b ∈ l.map g := hp.mem_iff.mp List.mem_cons_self
    obtain ⟨a, ha, rfl⟩ := List.mem_map.mp hb
    obtain ⟨s, t, rfl⟩ := List.append_of_mem ha
    -- cancel the head across the permutation
    have hmid : ((s ++ a :: t).map g).Perm (g a :: (s ++ t).map g) := by
      rw [List.map_append, List.map_cons, List.map_append]
      exact List.perm_middle
    have hσ' : σ'.Perm ((s ++ t).map g) := (hp.trans hmid).cons_inv
    obtain ⟨l'', hl'', hmap⟩ := ih hσ'
    exact ⟨a :: l'', (hl''.cons a).trans List.perm_middle.symm, by rw [List.map_cons, hmap]⟩

/-- Pairwise consistency is permutation-invariant. -/
lemma consistent_of_perm {fam fam' : List (LocalStruct ι X)} (h : fam'.Perm fam)
    (hc : Consistent fam) : Consistent fam' := fun A hA B hB =>
  hc A (h.mem_iff.mp hA) B (h.mem_iff.mp hB)

omit [DecidableEq ι] in
/-- Gluing is permutation-invariant. -/
lemma glues_of_perm [Fintype ι] [∀ i, Fintype (X i)] {fam fam' : List (LocalStruct ι X)}
    (h : fam'.Perm fam) (hg : Glues fam') : Glues fam :=
  let ⟨κ, hκ⟩ := hg
  ⟨κ, fun L hL => hκ L (h.mem_iff.mpr hL)⟩

/-- **The order-free amalgamation theorem**: an acyclic cover forces every pairwise-consistent
family with duplicate-free teams to glue. The base structure, acyclicity, is decidable, so the
sufficiency is machine-checkable. -/
theorem glues_of_acyclic [Fintype ι] [∀ i, Fintype (X i)] [∀ i, Nonempty (X i)]
    (fam : List (LocalStruct ι X)) (hcons : Consistent fam)
    (hnd : (fam.map (·.team)).Nodup)
    (hacyc : Acyclic (fam.map (·.team)).toFinset) :
    Glues fam := by
  obtain ⟨σ, hndσ, htfσ, hripσ⟩ := hacyc
  have hperm : σ.Perm (fam.map (·.team)) :=
    List.perm_of_nodup_nodup_toFinset_eq hndσ hnd htfσ
  obtain ⟨fam', hpermf, hmapf⟩ := exists_perm_map_eq hperm
  have hrip' : RIP fam' := (rip_iff_ripCover fam').mpr (by rw [hmapf]; exact hripσ)
  exact glues_of_perm hpermf (glues_of_rip fam' hrip' (consistent_of_perm hpermf hcons))

/-- The Specker cover is not acyclic: the order-free triangle fact, by `decide` through the
bridge's decidability instance. -/
theorem speckerCover_not_acyclic :
    ¬ Acyclic ({S01, S12, S02} : Finset (Finset (Fin 3))) := by decide

/-- The path cover is acyclic. -/
theorem pathCover_acyclic : Acyclic ({S01, S12} : Finset (Finset (Fin 3))) := by decide

end FamilyLevel

end HiddenChannelCapacity
