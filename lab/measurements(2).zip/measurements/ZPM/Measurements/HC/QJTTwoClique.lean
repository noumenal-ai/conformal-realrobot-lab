/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.QuantumMarginal
import QuantumInfo.Entropy.SSA
import QuantumInfo.Entropy.DPI

/-!
# The two-clique quantum junction tree theorem (Lauritzen–Zwiernik Theorem 3.1)

Rung L2a of the QJT arc (QJT_URS): the COMPLETE two-clique case of the Markov marginal
problem for density operators, after Lauritzen–Zwiernik, "The Markov Marginal Problem
for Density Operators", arXiv:2605.19453v2 (2026); all definition citations below are
to that paper (extraction record: QJT_LEDGER.md).

Read base-first, this is the ACYCLIC control. The two-clique cover is the minimal junction
tree (two cliques glued on a shared separator `c`), and over an acyclic base the geometry
licenses base-side sufficiency: the local marginals reconstruct the whole. The theorem below
makes that precise. The base's own compatibility datum `Tr T(R)` decides whether the local
ends glue, and when they do the global completion is unique and canonical. It is the
positive counterpart to the cyclic base of `PRBox.lean`/`QJTOpenProblem.lean`, where the
base instead licenses a global observable no local end can emulate.

Setting: three finite subsystems `a`, `c`, `b` with the SHARED system `c` in the middle;
the global carrier is `a × c × b` (right-associated), matching the vendored `qcmi`
convention `I(A;B|C)` with the conditioner in the middle slot. Given strictly positive
consistent marginals `ρAC` on `a × c` and `ρCB` on `c × b` (LZ §3.1), the logarithmic
candidate is `T(R) = exp(log ρAC + log ρCB − log ρC)` with every operator embedded by
tensoring with identities BEFORE taking `exp` (LZ eq. 5, p. 7; embeddings p. 23). The
theorem: `Tr T(R) ≤ 1` always, and `Tr T(R) = 1` iff `T(R)` is a completion iff a
quantum Markov completion exists; the Markov completion is then unique and equals
`T(R)` (LZ Theorem 3.1, p. 8).

PROOF ROUTE (recorded in QJT_URS, L2a front-load): the trace bound is proved WITHOUT
Lieb's three-matrix inequality, by specializing LZ's own chordal argument (eq. 13,
p. 14) to the two-clique case: the engine is Lemma 3.2 (p. 8) in NORMALIZED form
(divergences against the normalized candidate `σ = T(R)/Tr T(R)`; equivalent to the
paper's statement via `log T(R) = log Tr T(R) + log σ`), whose right side is
`I(A:B|C)_ω + Δ_R(ω) ≥ 0` by strong subadditivity (vendored `qcmi_nonneg`) and the
data-processing inequality (vendored `sandwichedRenyiEntropy_DPI` at α = 1).

This file also supplies two pieces the vendor lacks (QJT_URS floor table F1):
* the FAITHFULNESS of quantum relative entropy in real inner-product form
  (`inner_log_faithful`: `⟪ρ, log ρ − log σ⟫ = 0 → ρ = σ` for strictly positive `σ`),
  proved from a shared-eigenbasis double-sum expansion (`inner_cfc_cfc`, generalizing
  the vendored `inner_eq_doubly_stochastic_sum` to pairs of matrix functions) plus the
  strict scalar Klein inequality (Klein's inequality: LZ p. 5, citing Ruskai 2002,
  Thm 3);
* the real-valued divergence `qDivR` (the α = 1 Umegaki form `Tr[ρ (log ρ − log σ)]`,
  LZ eq. 4 restricted to density operators; equal to the vendored ENNReal
  `qRelativeEnt` via `qRelativeEnt_rank` when `σ` is nonsingular) with its DPI.
-/

open scoped HermitianMat Kronecker RealInnerProductSpace ComplexOrder Matrix

/-! ### The scalar Klein layer

The pointwise function whose positivity drives Klein's inequality (LZ p. 5, Ruskai 2002
Thm 3): `φ x y = x log x − x log y − x + y ≥ 0` for `x ≥ 0 < y`, vanishing iff `x = y`.
-/

namespace HiddenChannelCapacity

/-- The scalar Klein term `x log x − x log y − x + y` (the integrand of Klein's
inequality, LZ p. 5 / Ruskai 2002 Thm 3). -/
noncomputable def kleinTerm (x y : ℝ) : ℝ :=
  x * Real.log x - x * Real.log y - x + y

lemma kleinTerm_nonneg {x y : ℝ} (hx : 0 ≤ x) (hy : 0 < y) : 0 ≤ kleinTerm x y := by
  rcases hx.eq_or_lt with rfl | hx'
  · simp only [kleinTerm, zero_mul, sub_zero, zero_add]
    exact hy.le
  · have hyx : 0 < y / x := div_pos hy hx'
    have hlog := Real.log_le_sub_one_of_pos hyx
    have hexp : Real.log (y / x) = Real.log y - Real.log x :=
      Real.log_div hy.ne' hx'.ne'
    have h1 : x * (Real.log y - Real.log x) ≤ x * (y / x - 1) :=
      mul_le_mul_of_nonneg_left (hexp ▸ hlog) hx'.le
    have h2 : x * (y / x - 1) = y - x := by
      field_simp
    unfold kleinTerm
    nlinarith [h1, h2]

lemma kleinTerm_eq_zero_iff {x y : ℝ} (hx : 0 ≤ x) (hy : 0 < y) :
    kleinTerm x y = 0 ↔ x = y := by
  constructor
  · intro h0
    rcases hx.eq_or_lt with rfl | hx'
    · exfalso
      simp only [kleinTerm, zero_mul, sub_zero, zero_add] at h0
      exact hy.ne' h0
    · by_contra hxy
      have hyx : 0 < y / x := div_pos hy hx'
      have hne : y / x ≠ 1 := by
        intro h
        rw [div_eq_one_iff_eq hx'.ne'] at h
        exact hxy h.symm
      have hlog := Real.log_lt_sub_one_of_pos hyx hne
      have hexp : Real.log (y / x) = Real.log y - Real.log x :=
        Real.log_div hy.ne' hx'.ne'
      have h1 : x * (Real.log y - Real.log x) < x * (y / x - 1) :=
        mul_lt_mul_of_pos_left (hexp ▸ hlog) hx'
      have h2 : x * (y / x - 1) = y - x := by
        field_simp
      unfold kleinTerm at h0
      nlinarith [h1, h2]
  · rintro rfl
    unfold kleinTerm
    ring

end HiddenChannelCapacity

/-! ### The shared-eigenbasis double sum

`inner_cfc_cfc` generalizes the vendored `HermitianMat.inner_eq_doubly_stochastic_sum`
(QuantumInfo, Inner.lean) from the pair `(A, B)` to `(A.cfc f, B.cfc g)`, with the SAME
overlap matrix `C = U_A† U_B`: the single shared kernel `w i j = ‖C i j‖²` then carries
all the divergence pairings at once, which is what the faithfulness argument needs. -/

namespace HermitianMat

variable {d : Type*} [Fintype d] [DecidableEq d]

private lemma trace_single_mul (X : Matrix d d ℂ) (i : d) :
    (Matrix.single i i (1 : ℂ) * X).trace = X i i := by
  classical
  simp only [Matrix.trace, Matrix.diag_apply, Matrix.mul_apply, Matrix.single_apply]
  rw [Finset.sum_eq_single i]
  · rw [Finset.sum_eq_single i]
    · simp
    · intro m _ hm
      simp [Ne.symm hm]
    · simp
  · intro k _ hk
    rw [Finset.sum_eq_zero]
    intro m _
    simp [Ne.symm hk]
  · simp

private lemma trace_single_conj (C : Matrix d d ℂ) (i j : d) :
    (Matrix.single i i (1 : ℂ) * C * Matrix.single j j 1 * Cᴴ).trace
      = C i j * star (C i j) := by
  classical
  have h1 : Matrix.single i i (1 : ℂ) * C * Matrix.single j j 1 * Cᴴ
      = Matrix.single i i (1 : ℂ) * (C * (Matrix.single j j 1 * Cᴴ)) := by
    rw [Matrix.mul_assoc, Matrix.mul_assoc]
  rw [h1, trace_single_mul]
  simp only [Matrix.mul_apply, Matrix.single_apply, Matrix.conjTranspose_apply]
  rw [Finset.sum_eq_single j]
  · rw [Finset.sum_eq_single j]
    · simp
    · intro p _ hp
      simp [Ne.symm hp]
    · simp
  · intro n _ hn
    rw [Finset.sum_eq_zero]
    · simp
    intro p _
    simp [Ne.symm hn]
  · simp


/-- `A.log` is `cfc` at `Real.log`, definitionally (QuantumInfo LogExp.lean). -/
private lemma log_eq_cfc (A : HermitianMat d ℂ) : A.log = A.cfc Real.log :=
  rfl

/-- **The shared-basis double sum** (generalizing the vendored
`inner_eq_doubly_stochastic_sum` from `(A, B)` to `(A.cfc f, B.cfc g)` with the SAME
overlap kernel): the inner product of two matrix functions expands over the pair of
eigenbases with weights `‖C i j‖²`, `C = U_A† U_B`. All four divergence pairings of the
faithfulness argument are instances of this one lemma at a single shared kernel. -/
theorem inner_cfc_cfc (A B : HermitianMat d ℂ) (f g : ℝ → ℝ) :
    ⟪A.cfc f, B.cfc g⟫ = ∑ i, ∑ j,
      f (A.H.eigenvalues i) * g (B.H.eigenvalues j)
        * ‖(A.H.eigenvectorUnitary.val.conjTranspose * B.H.eigenvectorUnitary.val) i j‖ ^ 2 := by
  classical
  set U : Matrix d d ℂ := A.H.eigenvectorUnitary.val with hU
  set V : Matrix d d ℂ := B.H.eigenvectorUnitary.val with hV
  set C : Matrix d d ℂ := Uᴴ * V with hCdef
  have hterm : ∀ i j,
      ((U * Matrix.single i i 1 * Uᴴ) * (V * Matrix.single j j 1 * Vᴴ)).trace
        = ((‖C i j‖ ^ 2 : ℝ) : ℂ) := by
    intro i j
    have hcyc : ((U * Matrix.single i i 1 * Uᴴ) * (V * Matrix.single j j 1 * Vᴴ)).trace
        = (Matrix.single i i (1 : ℂ) * C * Matrix.single j j 1 * Cᴴ).trace := by
      have hCH : Cᴴ = Vᴴ * U := by
        simp [hCdef, Matrix.conjTranspose_mul]
      rw [hCH, hCdef]
      rw [show U * Matrix.single i i (1 : ℂ) * Uᴴ * (V * Matrix.single j j 1 * Vᴴ)
          = U * (Matrix.single i i (1 : ℂ) * (Uᴴ * V) * Matrix.single j j 1 * (Vᴴ)) from by
        noncomm_ring]
      rw [Matrix.trace_mul_comm]
      noncomm_ring
    rw [hcyc, trace_single_conj]
    simp [Complex.mul_conj, Complex.normSq_eq_norm_sq]
  have hexp : (A.cfc f).mat * (B.cfc g).mat
      = ∑ i, ∑ j, (f (A.H.eigenvalues i) * g (B.H.eigenvalues j)) •
          ((U * Matrix.single i i 1 * Uᴴ) * (V * Matrix.single j j 1 * Vᴴ)) := by
    rw [cfc_toMat_eq_sum_smul_proj, cfc_toMat_eq_sum_smul_proj]
    rw [Finset.sum_mul_sum]
    refine Finset.sum_congr rfl fun i _ => Finset.sum_congr rfl fun j _ => ?_
    rw [smul_mul_smul_comm]
  have hmain : ((A.cfc f).mat * (B.cfc g).mat).trace
      = ((∑ i, ∑ j, f (A.H.eigenvalues i) * g (B.H.eigenvalues j)
          * ‖C i j‖ ^ 2 : ℝ) : ℂ) := by
    rw [hexp, Matrix.trace_sum]
    push_cast
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [Matrix.trace_sum]
    refine Finset.sum_congr rfl fun j _ => ?_
    rw [Matrix.trace_smul, hterm i j, Complex.real_smul]
    push_cast
    ring
  rw [inner_eq_re_trace, hmain]
  exact RCLike.ofReal_re _

/-- Rows of the shared-basis kernel sum to one (`C` is unitary). -/
theorem overlap_row_sum (A B : HermitianMat d ℂ) (i : d) :
    ∑ j, ‖(A.H.eigenvectorUnitary.val.conjTranspose * B.H.eigenvectorUnitary.val) i j‖ ^ 2
      = 1 := by
  classical
  set U : Matrix d d ℂ := A.H.eigenvectorUnitary.val with hU
  set V : Matrix d d ℂ := B.H.eigenvectorUnitary.val with hV
  have hUV : (Uᴴ * V) * (Uᴴ * V)ᴴ = 1 := by
    have h1 : (Uᴴ * V)ᴴ = Vᴴ * U := by simp [Matrix.conjTranspose_mul]
    rw [h1, Matrix.mul_assoc, ← Matrix.mul_assoc V Vᴴ U]
    have hV2 : V * Vᴴ = 1 := by
      have := B.H.eigenvectorUnitary.2.2
      simpa [Matrix.star_eq_conjTranspose] using this
    have hU2 : Uᴴ * U = 1 := by
      have := A.H.eigenvectorUnitary.2.1
      simpa [Matrix.star_eq_conjTranspose] using this
    rw [hV2, Matrix.one_mul, hU2]
  have hentry : ((Uᴴ * V) * (Uᴴ * V)ᴴ) i i = 1 := by
    rw [hUV, Matrix.one_apply_eq]
  rw [Matrix.mul_apply] at hentry
  have hsum : ∑ j, (((‖(Uᴴ * V) i j‖ ^ 2 : ℝ)) : ℂ) = 1 := by
    calc ∑ j, (((‖(Uᴴ * V) i j‖ ^ 2 : ℝ)) : ℂ)
        = ∑ j, (Uᴴ * V) i j * star ((Uᴴ * V) i j) := by
          refine Finset.sum_congr rfl fun j _ => ?_
          simp [Complex.mul_conj, Complex.normSq_eq_norm_sq]
      _ = ∑ j, (Uᴴ * V) i j * ((Uᴴ * V)ᴴ) j i := by
          refine Finset.sum_congr rfl fun j _ => ?_
          rw [Matrix.conjTranspose_apply]
      _ = 1 := hentry
  exact_mod_cast hsum

/-- Columns of the shared-basis kernel sum to one. -/
theorem overlap_col_sum (A B : HermitianMat d ℂ) (j : d) :
    ∑ i, ‖(A.H.eigenvectorUnitary.val.conjTranspose * B.H.eigenvectorUnitary.val) i j‖ ^ 2
      = 1 := by
  classical
  set U : Matrix d d ℂ := A.H.eigenvectorUnitary.val with hU
  set V : Matrix d d ℂ := B.H.eigenvectorUnitary.val with hV
  have hUV : (Uᴴ * V)ᴴ * (Uᴴ * V) = 1 := by
    have h1 : (Uᴴ * V)ᴴ = Vᴴ * U := by simp [Matrix.conjTranspose_mul]
    rw [h1, Matrix.mul_assoc, ← Matrix.mul_assoc U Uᴴ V]
    have hU2 : U * Uᴴ = 1 := by
      have := A.H.eigenvectorUnitary.2.2
      simpa [Matrix.star_eq_conjTranspose] using this
    have hV2 : Vᴴ * V = 1 := by
      have := B.H.eigenvectorUnitary.2.1
      simpa [Matrix.star_eq_conjTranspose] using this
    rw [hU2, Matrix.one_mul, hV2]
  have hentry : ((Uᴴ * V)ᴴ * (Uᴴ * V)) j j = 1 := by
    rw [hUV, Matrix.one_apply_eq]
  rw [Matrix.mul_apply] at hentry
  have hsum : ∑ i, (((‖(Uᴴ * V) i j‖ ^ 2 : ℝ)) : ℂ) = 1 := by
    calc ∑ i, (((‖(Uᴴ * V) i j‖ ^ 2 : ℝ)) : ℂ)
        = ∑ i, ((Uᴴ * V)ᴴ) j i * (Uᴴ * V) i j := by
          refine Finset.sum_congr rfl fun i _ => ?_
          rw [Matrix.conjTranspose_apply]
          rw [show star ((Uᴴ * V) i j) * (Uᴴ * V) i j
            = (Uᴴ * V) i j * star ((Uᴴ * V) i j) from mul_comm _ _]
          simp [Complex.mul_conj, Complex.normSq_eq_norm_sq]
      _ = 1 := hentry
  exact_mod_cast hsum

end HermitianMat


/-! ### Faithfulness of the relative-entropy form

The vendored corpus proves nonnegativity of `⟪ρ, log ρ − log σ⟫` (Klein's inequality,
LZ p. 5 / Ruskai 2002 Thm 3) but not its EQUALITY case. `inner_log_faithful` supplies
it in the strictly positive regime: the shared-basis double sum turns the inner product
into `∑ᵢⱼ wᵢⱼ · kleinTerm pᵢ qⱼ` with `w` doubly stochastic, each term vanishes, and the
three Frobenius pairings collapse to `‖ρ − σ‖² = 0`. -/

namespace HiddenChannelCapacity

open HermitianMat

variable {d : Type*} [Fintype d] [DecidableEq d]

/-- **Faithfulness of quantum relative entropy** (the equality case of Klein's
inequality, LZ p. 5, Ruskai 2002 Thm 3; not present in the vendored corpus): for a
state `ρ` and a STRICTLY POSITIVE state `σ`, `Tr[ρ(log ρ − log σ)] = 0` forces
`ρ = σ`. -/
theorem inner_log_faithful (ρ σ : MState d) (hσ : σ.m.PosDef)
    (h0 : ⟪ρ.M, ρ.M.log - σ.M.log⟫ = 0) : ρ = σ := by
  classical
  set p : d → ℝ := ρ.M.H.eigenvalues with hp_def
  set q : d → ℝ := σ.M.H.eigenvalues with hq_def
  set w : d → d → ℝ := fun i j =>
    ‖(ρ.M.H.eigenvectorUnitary.val.conjTranspose * σ.M.H.eigenvectorUnitary.val) i j‖ ^ 2
    with hw_def
  have hp : ∀ i, 0 ≤ p i := fun i =>
    (HermitianMat.zero_le_iff.mp ρ.nonneg).eigenvalues_nonneg i
  have hq : ∀ j, 0 < q j := fun j => hσ.eigenvalues_pos j
  have hw : ∀ i j, 0 ≤ w i j := fun i j => by positivity
  have hrow : ∀ i, ∑ j, w i j = 1 := fun i => overlap_row_sum ρ.M σ.M i
  have hcol : ∀ j, ∑ i, w i j = 1 := fun j => overlap_col_sum ρ.M σ.M j
  have hsum_p : ∑ i, p i = 1 := by
    rw [hp_def, HermitianMat.sum_eigenvalues_eq_trace]
    exact ρ.tr
  have hsum_q : ∑ j, q j = 1 := by
    rw [hq_def, HermitianMat.sum_eigenvalues_eq_trace]
    exact σ.tr
  -- the self-overlap kernels are Kronecker deltas
  have hself : ∀ (X : MState d) (h : ℝ → ℝ),
      ⟪X.M, X.M.cfc h⟫ = ∑ i, X.M.H.eigenvalues i * h (X.M.H.eigenvalues i) := by
    intro X h
    have h1 := inner_cfc_cfc X.M X.M id h
    rw [HermitianMat.cfc_id] at h1
    have hU : X.M.H.eigenvectorUnitary.val.conjTranspose * X.M.H.eigenvectorUnitary.val
        = 1 := by
      have := X.M.H.eigenvectorUnitary.2.1
      simpa [Matrix.star_eq_conjTranspose] using this
    rw [h1]
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [Finset.sum_eq_single i]
    · rw [hU, Matrix.one_apply_eq]
      simp
    · intro j _ hj
      rw [hU, Matrix.one_apply_ne (Ne.symm hj)]
      simp
    · simp
  -- the four pairings
  have I1 : ⟪ρ.M, ρ.M.log⟫ = ∑ i, p i * Real.log (p i) := by
    rw [log_eq_cfc]
    exact hself ρ Real.log
  have I2 : ⟪ρ.M, σ.M.log⟫ = ∑ i, ∑ j, p i * Real.log (q j) * w i j := by
    have h1 := inner_cfc_cfc ρ.M σ.M id Real.log
    rw [HermitianMat.cfc_id] at h1
    rw [log_eq_cfc]
    exact h1
  have I3 : ⟪ρ.M, σ.M⟫ = ∑ i, ∑ j, p i * q j * w i j := by
    have h1 := inner_cfc_cfc ρ.M σ.M id id
    rw [HermitianMat.cfc_id, HermitianMat.cfc_id] at h1
    exact h1
  have I4 : ⟪ρ.M, ρ.M⟫ = ∑ i, p i * p i := by
    have h1 := hself ρ id
    rw [HermitianMat.cfc_id] at h1
    exact h1
  have I5 : ⟪σ.M, σ.M⟫ = ∑ j, q j * q j := by
    have h1 := hself σ id
    rw [HermitianMat.cfc_id] at h1
    exact h1
  -- the master telescope: the double Klein sum equals the divergence
  have hS : ∑ i, ∑ j, w i j * kleinTerm (p i) (q j) = 0 := by
    have hexpand : ∑ i, ∑ j, w i j * kleinTerm (p i) (q j)
        = (∑ i, p i * Real.log (p i)) - (∑ i, ∑ j, p i * Real.log (q j) * w i j)
          - (∑ i, p i) + (∑ j, q j) := by
      have h1 : ∀ i, ∑ j, w i j * kleinTerm (p i) (q j)
          = p i * Real.log (p i) - (∑ j, p i * Real.log (q j) * w i j)
            - p i + (∑ j, w i j * q j) := by
        intro i
        have h2 : ∀ j, w i j * kleinTerm (p i) (q j)
            = p i * Real.log (p i) * w i j - p i * Real.log (q j) * w i j
              - p i * w i j + w i j * q j := by
          intro j
          unfold kleinTerm
          ring
        rw [Finset.sum_congr rfl fun j _ => h2 j]
        rw [Finset.sum_add_distrib, Finset.sum_sub_distrib, Finset.sum_sub_distrib]
        simp only [← Finset.mul_sum, hrow, mul_one]
      rw [Finset.sum_congr rfl fun i _ => h1 i]
      rw [Finset.sum_add_distrib, Finset.sum_sub_distrib, Finset.sum_sub_distrib]
      have hq_swap : ∑ i, ∑ j, w i j * q j = ∑ j, q j := by
        rw [Finset.sum_comm]
        refine Finset.sum_congr rfl fun j _ => ?_
        rw [← Finset.sum_mul, hcol, one_mul]
      rw [hq_swap]
    rw [hexpand, hsum_p, hsum_q]
    rw [HermitianMat.inner_sub_left, I1, I2] at h0
    linarith
  -- every Klein term vanishes
  have hzero : ∀ i j, w i j * kleinTerm (p i) (q j) = 0 := by
    have houter : ∀ i ∈ Finset.univ, (0 : ℝ) ≤ ∑ j, w i j * kleinTerm (p i) (q j) :=
      fun i _ => Finset.sum_nonneg fun j _ =>
        mul_nonneg (hw i j) (kleinTerm_nonneg (hp i) (hq j))
    have hin := (Finset.sum_eq_zero_iff_of_nonneg houter).mp hS
    intro i j
    have hinner : ∀ j ∈ Finset.univ, (0 : ℝ) ≤ w i j * kleinTerm (p i) (q j) :=
      fun j _ => mul_nonneg (hw i j) (kleinTerm_nonneg (hp i) (hq j))
    exact (Finset.sum_eq_zero_iff_of_nonneg hinner).mp (hin i (Finset.mem_univ i)) j
      (Finset.mem_univ j)
  have hkey : ∀ i j, w i j ≠ 0 → p i = q j := by
    intro i j hwij
    rcases mul_eq_zero.mp (hzero i j) with h | h
    · exact absurd h hwij
    · exact (kleinTerm_eq_zero_iff (hp i) (hq j)).mp h
  -- the three Frobenius pairings coincide
  have hI3p : ∑ i, ∑ j, p i * q j * w i j = ∑ i, p i * p i := by
    refine Finset.sum_congr rfl fun i _ => ?_
    have h1 : ∀ j, p i * q j * w i j = p i * p i * w i j := by
      intro j
      rcases eq_or_ne (w i j) 0 with h | h
      · rw [h, mul_zero, mul_zero]
      · rw [hkey i j h]
    rw [Finset.sum_congr rfl fun j _ => h1 j, ← Finset.mul_sum]
    rw [hrow, mul_one]
  have hI3q : ∑ i, ∑ j, p i * q j * w i j = ∑ j, q j * q j := by
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun j _ => ?_
    have h1 : ∀ i, p i * q j * w i j = q j * q j * w i j := by
      intro i
      rcases eq_or_ne (w i j) 0 with h | h
      · rw [h, mul_zero, mul_zero]
      · rw [hkey i j h]
    rw [Finset.sum_congr rfl fun i _ => h1 i, ← Finset.mul_sum]
    rw [hcol, mul_one]
  -- ‖ρ − σ‖² = 0
  have hdiff : ⟪ρ.M - σ.M, ρ.M - σ.M⟫ = 0 := by
    rw [HermitianMat.inner_sub_right, HermitianMat.inner_sub_left,
      HermitianMat.inner_sub_left]
    have hcomm : ⟪σ.M, ρ.M⟫ = ⟪ρ.M, σ.M⟫ := HermitianMat.inner_comm _ _
    have e1 : ⟪ρ.M, σ.M⟫ = ∑ i, p i * p i := by
      rw [I3]
      exact hI3p
    have e2 : ⟪ρ.M, σ.M⟫ = ∑ j, q j * q j := by
      rw [I3]
      exact hI3q
    linarith [I4, I5, e1, e2, hcomm]
  have hM : ρ.M = σ.M := by
    have hnorm : ‖ρ.M - σ.M‖ = 0 := by
      rw [HermitianMat.norm_eq_sqrt_inner_self]
      rw [show (inner ℝ (ρ.M - σ.M) (ρ.M - σ.M) : ℝ) = 0 from hdiff]
      exact Real.sqrt_zero
    exact sub_eq_zero.mp (norm_eq_zero.mp hnorm)
  exact MState.ext hM

end HiddenChannelCapacity

/-! ### The two-clique scenario

Carrier convention: the global system is `a × c × b` (right-associated), with the SHARED
system `c` in the middle, matching the vendored `qcmi` convention (`qcmi` on
`MState (dA × dB × dC)` is `I(A;C|B)` conditioning on the middle factor; with our
assignment `(dA, dB, dC) := (a, c, b)` it is exactly LZ's `I(A:B|C)`, Definition 2.4).
The marginal maps are the vendor composites, so `qcmi` unfolds DEFINITIONALLY to their
entropy combination. -/

namespace HiddenChannelCapacity

variable {a c b : Type*}
  [Fintype a] [DecidableEq a] [Nonempty a]
  [Fintype c] [DecidableEq c] [Nonempty c]
  [Fintype b] [DecidableEq b] [Nonempty b]

/-- The `A∪C`-marginal of a global state (LZ p. 4: reduced density operator). -/
noncomputable def margAC (ω : MState (a × c × b)) : MState (a × c) :=
  ω.assoc'.traceRight

/-- The `C∪B`-marginal of a global state. -/
noncomputable def margCB (ω : MState (a × c × b)) : MState (c × b) :=
  ω.traceLeft

/-- The `C`-marginal (the separator marginal), as the vendor composite the `qcmi`
definition consumes. -/
noncomputable def margC (ω : MState (a × c × b)) : MState c :=
  (margAC ω).traceLeft

omit [Nonempty a] [Nonempty c] [Nonempty b] in
/-- The vendored associator is the plain `prodAssoc` relabel. -/
lemma assoc'_eq_relabel (ω : MState (a × c × b)) :
    ω.assoc' = ω.relabel (Equiv.prodAssoc a c b) := by
  simp only [MState.assoc', MState.assoc, MState.SWAP, MState.relabel_comp]
  congr 1

omit [Nonempty a] [Nonempty c] [Nonempty b] in
/-- The `AC`-marginal in `traceAlong` form (the L0 primitive). -/
lemma margAC_eq_traceAlong (ω : MState (a × c × b)) :
    margAC ω = ω.traceAlong (Equiv.prodAssoc a c b).symm := by
  rw [margAC, assoc'_eq_relabel]
  rfl

omit [Nonempty a] [Nonempty c] [Nonempty b] in
/-- Coherence of the two separator-marginal routes (iterated marginalization, LZ
Lem 2.2): tracing `a` then `b` is tracing `b` then `a`. -/
lemma margC_eq_CBright (ω : MState (a × c × b)) :
    margC ω = (margCB ω).traceRight := by
  refine MState.ext_m ?_
  funext x y
  show ∑ z : a, (margAC ω).m (z, x) (z, y) = ∑ w : b, (margCB ω).m (x, w) (y, w)
  have hL : ∀ z, (margAC ω).m (z, x) (z, y)
      = ∑ w : b, ω.m (z, (x, w)) (z, (y, w)) := by
    intro z
    rw [margAC, assoc'_eq_relabel]
    rfl
  have hR : ∀ w, (margCB ω).m (x, w) (y, w)
      = ∑ z : a, ω.m (z, (x, w)) (z, (y, w)) := fun _ => rfl
  rw [Finset.sum_congr rfl fun z _ => hL z, Finset.sum_congr rfl fun w _ => hR w]
  exact Finset.sum_comm

/-! ### The real divergence layer

`qDivR` is the α = 1 Umegaki form `Tr[ρ (log ρ − log σ)]` (LZ eq. 4 restricted to
density operators) as a REAL number: the identity layer of the proof lives in `ℝ`
(the ENNReal `qRelativeEnt` is bridged across exactly one seam per imported
inequality, via the vendored `qRelativeEnt_rank`). -/

/-- The quantum relative entropy in real form, `Tr[ρ (log ρ − log σ)]` (LZ eq. 4 on
density operators; equals the vendored `qRelativeEnt` by `qRelativeEnt_rank` when `σ`
is nonsingular). -/
noncomputable def qDivR {d : Type*} [Fintype d] [DecidableEq d] (ρ σ : MState d) : ℝ :=
  ⟪ρ.M, ρ.M.log - σ.M.log⟫

section DivR

variable {d : Type*} [Fintype d] [DecidableEq d]

lemma qDivR_self (ρ : MState d) : qDivR ρ ρ = 0 := by
  rw [qDivR, sub_self, HermitianMat.inner_zero_right]

lemma ker_le_of_posDef {ρ σ : MState d} (hσ : σ.m.PosDef) : σ.M.ker ≤ ρ.M.ker := by
  haveI := HermitianMat.nonSingular_of_posDef hσ
  rw [HermitianMat.nonSingular_ker_bot]
  exact bot_le

/-- Klein nonnegativity in real form (vendored core: `inner_log_sub_log_nonneg`). -/
lemma qDivR_nonneg {ρ σ : MState d} (hσ : σ.m.PosDef) : 0 ≤ qDivR ρ σ :=
  inner_log_sub_log_nonneg (ker_le_of_posDef hσ)

private lemma toReal_bridge {x : ENNReal} {r : ℝ} (hx : x ≠ ⊤)
    (h : (x : EReal) = (r : EReal)) : x.toReal = r := by
  lift x to NNReal using hx
  rw [show ((x : ENNReal) : EReal) = ((x : ℝ) : EReal) from by norm_cast] at h
  rw [EReal.coe_eq_coe_iff] at h
  simpa using h

/-- The single ENNReal-to-ℝ seam: `qDivR` equals the vendored relative entropy.
(LZ p. 5; vendored `qRelativeEnt_rank`.) -/
lemma qDivR_eq_toReal {ρ σ : MState d} (hσ : σ.m.PosDef) :
    qDivR ρ σ = (qRelativeEnt ρ σ).toReal := by
  haveI := HermitianMat.nonSingular_of_posDef hσ
  exact (toReal_bridge qRelativeEnt_ne_top qRelativeEnt_rank).symm

/-- **DPI for the real divergence under the left partial trace** (monotonicity of
relative entropy, LZ Prop A.7; imported from the vendored channel DPI
`sandwichedRenyiEntropy_DPI_eq_one` at the partial-trace channel). -/
lemma qDivR_dpi_traceLeft {d₁ d₂ : Type*} [Fintype d₁] [DecidableEq d₁]
    [Fintype d₂] [DecidableEq d₂] (ρ σ : MState (d₁ × d₂))
    (hσ : σ.m.PosDef) (hσL : σ.traceLeft.m.PosDef) :
    qDivR ρ.traceLeft σ.traceLeft ≤ qDivR ρ σ := by
  rw [qDivR_eq_toReal hσL, qDivR_eq_toReal hσ]
  haveI := HermitianMat.nonSingular_of_posDef hσ
  refine ENNReal.toReal_mono qRelativeEnt_ne_top ?_
  have h := sandwichedRenyiEntropy_DPI_eq_one ρ σ CPTPMap.traceLeft
  simp only [CPTPMap.traceLeft_eq_MState_traceLeft] at h
  exact h

end DivR

/-! ### Embeddings and dualities (LZ eq. 5 embeddings, eq. 2 duality) -/

/-- Embed a `C∪B`-local operator into the global system (tensoring with the identity,
LZ p. 23). -/
noncomputable def embedCB (L : HermitianMat (c × b) ℂ) : HermitianMat (a × c × b) ℂ :=
  (1 : HermitianMat a ℂ) ⊗ₖ L

/-- Embed a `C`-local operator into the global system. -/
noncomputable def embedC (L : HermitianMat c ℂ) : HermitianMat (a × c × b) ℂ :=
  (1 : HermitianMat a ℂ) ⊗ₖ (L ⊗ₖ (1 : HermitianMat b ℂ))

/-- Embed an `A∪C`-local operator into the global system. -/
noncomputable def embedAC (L : HermitianMat (a × c) ℂ) : HermitianMat (a × c × b) ℂ :=
  (L ⊗ₖ (1 : HermitianMat b ℂ)).reindex (Equiv.prodAssoc a c b)

omit [Nonempty a] [Nonempty c] [Nonempty b] in
/-- Duality for the `C∪B`-embedding: testing the state against an embedded observable
is testing the marginal (LZ eq. 2). -/
lemma inner_embedCB (ω : MState (a × c × b)) (L : HermitianMat (c × b) ℂ) :
    ⟪ω.M, embedCB L⟫ = ⟪(margCB ω).M, L⟫ := by
  rw [HermitianMat.inner_eq_re_trace, HermitianMat.inner_eq_re_trace]
  congr 1
  show (ω.m * (embedCB L).mat).trace = ((margCB ω).m * L.mat).trace
  have h1 : (embedCB L).mat
      = Matrix.kroneckerMap (fun x1 x2 => x1 * x2) (1 : Matrix a a ℂ) L.mat := by
    simp [embedCB]
  rw [h1, ← Matrix.traceLeft_trace
      (ω.m * Matrix.kroneckerMap (fun x1 x2 => x1 * x2) (1 : Matrix a a ℂ) L.mat)]
  exact congrArg Matrix.trace (Matrix.traceLeft_mul_one_kron ω.m L.mat)

omit [Nonempty a] [Nonempty c] [Nonempty b] in
/-- Duality for a right-identity Kronecker factor on any bipartite carrier. -/
lemma inner_kron_one {d₁ d₂ : Type*} [Fintype d₁] [DecidableEq d₁]
    [Fintype d₂] [DecidableEq d₂] (X : MState (d₁ × d₂)) (L : HermitianMat d₁ ℂ) :
    ⟪X.M, L ⊗ₖ (1 : HermitianMat d₂ ℂ)⟫ = ⟪X.traceRight.M, L⟫ := by
  rw [HermitianMat.inner_eq_re_trace, HermitianMat.inner_eq_re_trace]
  congr 1
  show (X.m * (L ⊗ₖ (1 : HermitianMat d₂ ℂ)).mat).trace
      = (X.traceRight.m * L.mat).trace
  have h1 : (L ⊗ₖ (1 : HermitianMat d₂ ℂ)).mat
      = Matrix.kroneckerMap (fun x1 x2 => x1 * x2) L.mat (1 : Matrix d₂ d₂ ℂ) := by
    simp
  rw [h1, ← Matrix.traceRight_trace
      (X.m * Matrix.kroneckerMap (fun x1 x2 => x1 * x2) L.mat (1 : Matrix d₂ d₂ ℂ))]
  exact congrArg Matrix.trace (Matrix.traceRight_mul_kron_one X.m L.mat)

omit [Nonempty a] [Nonempty c] [Nonempty b] in
/-- Duality for the `C`-embedding (two-step pull-out; uses the marginal coherence
`margC_eq_CBright`, LZ Lem 2.2). -/
lemma inner_embedC (ω : MState (a × c × b)) (L : HermitianMat c ℂ) :
    ⟪ω.M, embedC L⟫ = ⟪(margC ω).M, L⟫ := by
  have h1 : embedC (a := a) (b := b) L = embedCB (L ⊗ₖ (1 : HermitianMat b ℂ)) := rfl
  rw [h1, inner_embedCB, inner_kron_one, margC_eq_CBright]

omit [Nonempty a] [Nonempty c] [Nonempty b] in
/-- Duality for the `A∪C`-embedding (via the L0 primitive `traceAlong_duality`). -/
lemma inner_embedAC (ω : MState (a × c × b)) (L : HermitianMat (a × c) ℂ) :
    ⟪ω.M, embedAC L⟫ = ⟪(margAC ω).M, L⟫ := by
  rw [HermitianMat.inner_eq_re_trace, HermitianMat.inner_eq_re_trace]
  congr 1
  show (ω.m * (embedAC L).mat).trace = ((margAC ω).m * L.mat).trace
  have h1 : (embedAC L).mat
      = Matrix.embedAlong (Equiv.prodAssoc a c b).symm L.mat := by
    simp [embedAC, Matrix.embedAlong, Matrix.reindex]
  rw [h1, margAC_eq_traceAlong, Matrix.trace_mul_comm,
    MState.traceAlong_duality ω (Equiv.prodAssoc a c b).symm L.mat]
  exact Matrix.trace_mul_comm _ _

/-! ### The logarithmic candidate T(R) (LZ eq. 5) -/

variable (ρAC : MState (a × c)) (ρCB : MState (c × b))

/-- The Hermitian exponent of the logarithmic candidate: the sum of the embedded
logarithms of the marginals (`log ρ_{AC} + log ρ_{CB} − log ρ_C`, every operator
embedded BEFORE `exp`; LZ eq. 5 with the p. 23 embedding convention; the separator
marginal is taken from the `AC` side). -/
noncomputable def Tmat : HermitianMat (a × c × b) ℂ :=
  embedAC ρAC.M.log + embedCB ρCB.M.log - embedC (ρAC.traceLeft).M.log

/-- **The logarithmic candidate** `T(R) = exp(log ρ_{AC} + log ρ_{CB} − log ρ_C)`
(LZ eq. 5). A Hermitian matrix, NOT a priori a state: its trace deficit is the
subject of the theorem. -/
noncomputable def TR : HermitianMat (a × c × b) ℂ :=
  (Tmat ρAC ρCB).exp

/-- The trace of the logarithmic candidate. -/
noncomputable def trC : ℝ :=
  (TR ρAC ρCB).trace

lemma trC_pos : 0 < trC ρAC ρCB := by
  rw [trC, TR, HermitianMat.exp, HermitianMat.trace_cfc_eq]
  exact Finset.sum_pos (fun i _ => Real.exp_pos _) Finset.univ_nonempty

/-- `exp` then `log` is the identity on Hermitian matrices (unconditionally: both are
`cfc` transports and `Real.log ∘ Real.exp = id`). -/
lemma exp_log_id {d : Type*} [Fintype d] [DecidableEq d] (A : HermitianMat d ℂ) :
    A.exp.log = A := by
  rw [HermitianMat.exp, HermitianMat.log, ← HermitianMat.cfc_comp,
    show Real.log ∘ Real.exp = id from funext Real.log_exp, HermitianMat.cfc_id]

/-- **The normalized candidate** `σ(R) = T(R)/Tr T(R)`: the state the equivalences of
LZ Thm 3.1 are about. -/
noncomputable def sigT : MState (a × c × b) where
  M := (trC ρAC ρCB)⁻¹ • TR ρAC ρCB
  nonneg := smul_nonneg (le_of_lt (inv_pos.mpr (trC_pos ρAC ρCB)))
    (HermitianMat.exp_nonneg _)
  tr := by
    rw [HermitianMat.trace_smul]
    exact inv_mul_cancel₀ (trC_pos ρAC ρCB).ne'

lemma sigT_posDef : (sigT ρAC ρCB).m.PosDef := by
  have hTR : (TR ρAC ρCB).mat.PosDef := by
    show ((Tmat ρAC ρCB).cfc Real.exp).mat.PosDef
    rw [HermitianMat.cfc_posDef]
    exact fun i => Real.exp_pos _
  have h3 : (0 : ℝ) < (trC ρAC ρCB)⁻¹ := inv_pos.mpr (trC_pos ρAC ρCB)
  show ((trC ρAC ρCB)⁻¹ • TR ρAC ρCB).mat.PosDef
  exact hTR.smul h3

/-- The log of the normalized candidate splits into the trace constant and the
embedded-log sum (`log T(R) = log Tr T(R) + log σ(R)`, the normalization step of the
LZ eq. 13 route). -/
lemma log_sigT :
    (sigT ρAC ρCB).M.log
      = Real.log ((trC ρAC ρCB)⁻¹) • (1 : HermitianMat (a × c × b) ℂ)
        + Tmat ρAC ρCB := by
  haveI : (TR ρAC ρCB).NonSingular := HermitianMat.nonSingular_exp _
  have h1 : (sigT ρAC ρCB).M = (trC ρAC ρCB)⁻¹ • TR ρAC ρCB := rfl
  rw [h1, HermitianMat.log_smul (by
    have := trC_pos ρAC ρCB
    positivity)]
  rw [TR, exp_log_id]

end HiddenChannelCapacity


/-! ### Strictly positive marginals -/

namespace HiddenChannelCapacity

/-- The partial trace of a strictly positive state is strictly positive (marginals of
elements of `S₁⁺` stay in `S₁⁺`, LZ p. 4). -/
lemma posDef_traceLeft {d₁ d₂ : Type*} [Fintype d₁] [DecidableEq d₁] [Nonempty d₁]
    [Fintype d₂] [DecidableEq d₂] {σ : MState (d₁ × d₂)} (hσ : σ.m.PosDef) :
    σ.traceLeft.m.PosDef := by
  classical
  refine Matrix.PosDef.of_dotProduct_mulVec_pos σ.traceLeft.M.H ?_
  intro y hy
  set e : d₁ → (d₁ × d₂ → ℂ) := fun z => fun p => if p.1 = z then y p.2 else 0 with he
  have hexp : star y ⬝ᵥ σ.traceLeft.m *ᵥ y
      = ∑ z : d₁, star (e z) ⬝ᵥ σ.m *ᵥ (e z) := by
    simp only [dotProduct, Matrix.mulVec, Pi.star_apply]
    have hL1 : ∀ p, (∑ q, σ.traceLeft.m p q * y q)
        = ∑ z, ∑ q, σ.m (z, p) (z, q) * y q := by
      intro p
      have h0 : ∀ q, σ.traceLeft.m p q * y q = ∑ z, σ.m (z, p) (z, q) * y q := by
        intro q
        show (∑ z, σ.m (z, p) (z, q)) * y q = _
        rw [Finset.sum_mul]
      rw [Finset.sum_congr rfl fun q _ => h0 q]
      exact Finset.sum_comm
    have hR1 : ∀ z, (∑ u : d₁ × d₂, star (e z u) * ∑ v : d₁ × d₂, σ.m u v * e z v)
        = ∑ p, star (y p) * ∑ q, σ.m (z, p) (z, q) * y q := by
      intro z
      have hinner : ∀ u : d₁ × d₂,
          (∑ v : d₁ × d₂, σ.m u v * e z v) = ∑ q, σ.m u (z, q) * y q := by
        intro u
        rw [Fintype.sum_prod_type]
        rw [Finset.sum_eq_single z]
        · refine Finset.sum_congr rfl fun q _ => ?_
          simp [he]
        · intro w _ hw
          rw [Finset.sum_eq_zero]
          intro q _
          simp [he, hw]
        · simp
      rw [Finset.sum_congr rfl fun u _ => congrArg (star (e z u) * ·) (hinner u)]
      rw [Fintype.sum_prod_type]
      rw [Finset.sum_eq_single z]
      · refine Finset.sum_congr rfl fun p _ => ?_
        simp [he]
      · intro w _ hw
        rw [Finset.sum_eq_zero]
        intro p _
        simp [he, hw]
      · simp
    rw [Finset.sum_congr rfl fun z _ => hR1 z]
    calc ∑ p, star (y p) * ∑ q, σ.traceLeft.m p q * y q
        = ∑ p, ∑ z, star (y p) * ∑ q, σ.m (z, p) (z, q) * y q := by
          refine Finset.sum_congr rfl fun p _ => ?_
          rw [hL1 p, Finset.mul_sum]
      _ = ∑ z, ∑ p, star (y p) * ∑ q, σ.m (z, p) (z, q) * y q := Finset.sum_comm
  rw [hexp]
  refine Finset.sum_pos (fun z _ => hσ.dotProduct_mulVec_pos ?_) Finset.univ_nonempty
  obtain ⟨p₂, hp₂⟩ := Function.ne_iff.mp hy
  refine Function.ne_iff.mpr ⟨(z, p₂), ?_⟩
  simpa [he] using hp₂

end HiddenChannelCapacity

/-! ### Lemma 3.2 and Theorem 3.1 (LZ arXiv:2605.19453) -/

namespace HiddenChannelCapacity

variable {a c b : Type*}
  [Fintype a] [DecidableEq a] [Nonempty a]
  [Fintype c] [DecidableEq c] [Nonempty c]
  [Fintype b] [DecidableEq b] [Nonempty b]
  (ρAC : MState (a × c)) (ρCB : MState (c × b))

/-- **LZ Lemma 3.2, normalized form**: for EVERY state `ω`,
`D(ω‖σ(R)) − log Tr T(R) = I(A:B|C)_ω + Δ_R(ω)` with
`Δ_R(ω) := D(ω_AC‖ρ_AC) + D(ω_CB‖ρ_CB) − D(ω_C‖ρ_C)`. This is the paper's divergence
identity (p. 8) restated against the NORMALIZED candidate via
`log T(R) = log Tr T(R) + log σ(R)` (the presentation variant recorded in QJT_URS;
pure real algebra over the duality, no positivity hypotheses). -/
lemma lem_3_2 (ω : MState (a × c × b)) :
    qDivR ω (sigT ρAC ρCB) - Real.log (trC ρAC ρCB)
      = qcmi ω + (qDivR (margAC ω) ρAC + qDivR (margCB ω) ρCB
          - qDivR (margC ω) (ρAC.traceLeft)) := by
  have hq : qcmi ω
      = -⟪(margAC ω).M, (margAC ω).M.log⟫ + ⟪ω.M, ω.M.log⟫
        - ⟪(margCB ω).M, (margCB ω).M.log⟫ + ⟪(margC ω).M, (margC ω).M.log⟫ := by
    show qConditionalEnt ω.assoc'.traceRight - qConditionalEnt ω = _
    unfold qConditionalEnt
    rw [show Sᵥₙ (ω.assoc'.traceRight) = Sᵥₙ (margAC ω) from rfl,
      show Sᵥₙ (ω.assoc'.traceRight).traceLeft = Sᵥₙ (margC ω) from rfl,
      show Sᵥₙ ω.traceLeft = Sᵥₙ (margCB ω) from rfl,
      Sᵥₙ_eq_neg_trace_log, Sᵥₙ_eq_neg_trace_log, Sᵥₙ_eq_neg_trace_log,
      Sᵥₙ_eq_neg_trace_log,
      HermitianMat.inner_comm (margAC ω).M.log, HermitianMat.inner_comm ω.M.log,
      HermitianMat.inner_comm (margCB ω).M.log,
      HermitianMat.inner_comm (margC ω).M.log]
    ring
  have hexp : qDivR ω (sigT ρAC ρCB)
      = ⟪ω.M, ω.M.log⟫
        - (Real.log ((trC ρAC ρCB)⁻¹)
          + (⟪(margAC ω).M, ρAC.M.log⟫ + ⟪(margCB ω).M, ρCB.M.log⟫
            - ⟪(margC ω).M, (ρAC.traceLeft).M.log⟫)) := by
    rw [qDivR, HermitianMat.inner_sub_left, log_sigT,
      HermitianMat.inner_add_right, HermitianMat.inner_smul_right,
      HermitianMat.inner_one, ω.tr, mul_one,
      show Tmat ρAC ρCB = embedAC ρAC.M.log + embedCB ρCB.M.log
        - embedC (ρAC.traceLeft).M.log from rfl,
      HermitianMat.inner_sub_left, HermitianMat.inner_add_right,
      inner_embedAC, inner_embedCB, inner_embedC]
  have hdAC : qDivR (margAC ω) ρAC
      = ⟪(margAC ω).M, (margAC ω).M.log⟫ - ⟪(margAC ω).M, ρAC.M.log⟫ := by
    rw [qDivR, HermitianMat.inner_sub_left]
  have hdCB : qDivR (margCB ω) ρCB
      = ⟪(margCB ω).M, (margCB ω).M.log⟫ - ⟪(margCB ω).M, ρCB.M.log⟫ := by
    rw [qDivR, HermitianMat.inner_sub_left]
  have hdC : qDivR (margC ω) (ρAC.traceLeft)
      = ⟪(margC ω).M, (margC ω).M.log⟫ - ⟪(margC ω).M, (ρAC.traceLeft).M.log⟫ := by
    rw [qDivR, HermitianMat.inner_sub_left]
  rw [hexp, hq, hdAC, hdCB, hdC, Real.log_inv]
  ring

variable {ρAC ρCB} in
omit [Nonempty c] [Nonempty b] in
/-- `Δ_R(ω) ≥ 0`: one DPI application plus Klein nonnegativity (LZ Lem 3.2's
nonnegativity clause, via Prop A.7 imported through the vendored channel DPI). -/
lemma deltaR_nonneg (hAC : ρAC.m.PosDef) (hCB : ρCB.m.PosDef)
    (ω : MState (a × c × b)) :
    0 ≤ qDivR (margAC ω) ρAC + qDivR (margCB ω) ρCB
        - qDivR (margC ω) (ρAC.traceLeft) := by
  have hC : (ρAC.traceLeft).m.PosDef := posDef_traceLeft hAC
  have h1 : qDivR (margC ω) (ρAC.traceLeft) ≤ qDivR (margAC ω) ρAC :=
    qDivR_dpi_traceLeft (margAC ω) ρAC hAC hC
  have h2 : 0 ≤ qDivR (margCB ω) ρCB := qDivR_nonneg hCB
  linarith

variable {ρAC ρCB} in
/-- **LZ Theorem 3.1, the trace bound**: `Tr T(R) ≤ 1`. Proved WITHOUT Lieb's
three-matrix inequality, by the eq. 13 route specialized to two cliques (Lemma 3.2 at
`ω = σ(R)` plus SSA and DPI); see the QJT_URS L2a front-load. -/
theorem trC_le_one (hAC : ρAC.m.PosDef) (hCB : ρCB.m.PosDef) :
    trC ρAC ρCB ≤ 1 := by
  have h32 := lem_3_2 ρAC ρCB (sigT ρAC ρCB)
  rw [qDivR_self] at h32
  have hq := qcmi_nonneg (sigT ρAC ρCB)
  have hd := deltaR_nonneg hAC hCB (sigT ρAC ρCB)
  by_contra hgt
  have := Real.log_pos (not_le.mp hgt)
  linarith

/-- A completion: a global state with the prescribed marginals (LZ `M(R)`, p. 7). -/
def IsCompletion (ω : MState (a × c × b)) : Prop :=
  margAC ω = ρAC ∧ margCB ω = ρCB

/-- A quantum Markov completion: a completion with `I(A:B|C) = 0` (LZ Def 2.4 quantum
conditional independence + the Markov completion of p. 7). -/
def IsMarkovCompletion (ω : MState (a × c × b)) : Prop :=
  IsCompletion ρAC ρCB ω ∧ qcmi ω = 0

variable {ρAC ρCB} in
/-- **LZ Theorem 3.1, uniqueness direction**: any quantum Markov completion forces
`Tr T(R) = 1` and equals the normalized candidate `σ(R)`. -/
theorem markov_completion_eq_sigT (hAC : ρAC.m.PosDef) (hCB : ρCB.m.PosDef)
    (hcons : ρAC.traceLeft = ρCB.traceRight)
    (ω : MState (a × c × b)) (hω : IsMarkovCompletion ρAC ρCB ω) :
    trC ρAC ρCB = 1 ∧ ω = sigT ρAC ρCB := by
  obtain ⟨⟨hMAC, hMCB⟩, hMk⟩ := hω
  have h32 := lem_3_2 ρAC ρCB ω
  have hACd : qDivR (margAC ω) ρAC = 0 := by
    rw [hMAC]
    exact qDivR_self _
  have hCBd : qDivR (margCB ω) ρCB = 0 := by
    rw [hMCB]
    exact qDivR_self _
  have hCeq : margC ω = ρAC.traceLeft := by
    rw [margC_eq_CBright, hMCB]
    exact hcons.symm
  have hCd : qDivR (margC ω) (ρAC.traceLeft) = 0 := by
    rw [hCeq]
    exact qDivR_self _
  rw [hMk, hACd, hCBd, hCd] at h32
  have hDge : 0 ≤ qDivR ω (sigT ρAC ρCB) := qDivR_nonneg (sigT_posDef ρAC ρCB)
  have hlog_le : Real.log (trC ρAC ρCB) ≤ 0 :=
    Real.log_nonpos (le_of_lt (trC_pos ρAC ρCB)) (trC_le_one hAC hCB)
  have hD0 : qDivR ω (sigT ρAC ρCB) = 0 := by linarith
  have hlog0 : Real.log (trC ρAC ρCB) = 0 := by linarith
  have hc1 : trC ρAC ρCB = 1 := by
    rw [← Real.exp_log (trC_pos ρAC ρCB), hlog0, Real.exp_zero]
  exact ⟨hc1, inner_log_faithful ω (sigT ρAC ρCB) (sigT_posDef ρAC ρCB) hD0⟩

variable {ρAC ρCB} in
/-- **LZ Theorem 3.1, existence direction**: if `Tr T(R) = 1` then the normalized
candidate IS a quantum Markov completion (extraction of `Δ_R = 0` via DPI and the
faithfulness of relative entropy, in the order recorded in the QJT_URS front-load). -/
theorem sigT_markov_of_trC_eq_one (hAC : ρAC.m.PosDef) (hCB : ρCB.m.PosDef)
    (hcons : ρAC.traceLeft = ρCB.traceRight) (h1 : trC ρAC ρCB = 1) :
    IsMarkovCompletion ρAC ρCB (sigT ρAC ρCB) := by
  have h32 := lem_3_2 ρAC ρCB (sigT ρAC ρCB)
  rw [qDivR_self, h1, Real.log_one] at h32
  have hq := qcmi_nonneg (sigT ρAC ρCB)
  have hd := deltaR_nonneg hAC hCB (sigT ρAC ρCB)
  have hq0 : qcmi (sigT ρAC ρCB) = 0 := by linarith
  have hd0 : qDivR (margAC (sigT ρAC ρCB)) ρAC + qDivR (margCB (sigT ρAC ρCB)) ρCB
      - qDivR (margC (sigT ρAC ρCB)) (ρAC.traceLeft) = 0 := by linarith
  have hC : (ρAC.traceLeft).m.PosDef := posDef_traceLeft hAC
  have hdpi : qDivR (margC (sigT ρAC ρCB)) (ρAC.traceLeft)
      ≤ qDivR (margAC (sigT ρAC ρCB)) ρAC :=
    qDivR_dpi_traceLeft (margAC (sigT ρAC ρCB)) ρAC hAC hC
  have hCB0 : qDivR (margCB (sigT ρAC ρCB)) ρCB = 0 := by
    have := qDivR_nonneg (ρ := margCB (sigT ρAC ρCB)) hCB
    linarith
  have hMCB : margCB (sigT ρAC ρCB) = ρCB :=
    inner_log_faithful _ _ hCB hCB0
  have hCeq : margC (sigT ρAC ρCB) = ρAC.traceLeft := by
    rw [margC_eq_CBright, hMCB]
    exact hcons.symm
  have hC0 : qDivR (margC (sigT ρAC ρCB)) (ρAC.traceLeft) = 0 := by
    rw [hCeq]
    exact qDivR_self _
  have hAC0 : qDivR (margAC (sigT ρAC ρCB)) ρAC = 0 := by linarith
  have hMAC : margAC (sigT ρAC ρCB) = ρAC :=
    inner_log_faithful _ _ hAC hAC0
  exact ⟨⟨hMAC, hMCB⟩, hq0⟩

variable {ρAC ρCB} in
/-- **The two-clique quantum junction tree theorem** (Lauritzen–Zwiernik,
arXiv:2605.19453, Theorem 3.1): over the acyclic two-clique base, the base's compatibility
datum decides base-side reconstruction. For strictly positive consistent marginals, a
quantum Markov completion exists iff `Tr T(R) = 1`; the completion is then unique and equals
the normalized logarithmic candidate `σ(R) = T(R)/Tr T(R)`. Together with
`trC_le_one` (the trace bound) this is the full theorem. -/
theorem lz_theorem_3_1 (hAC : ρAC.m.PosDef) (hCB : ρCB.m.PosDef)
    (hcons : ρAC.traceLeft = ρCB.traceRight) :
    (trC ρAC ρCB = 1 ↔ ∃ ω, IsMarkovCompletion ρAC ρCB ω)
      ∧ ∀ ω, IsMarkovCompletion ρAC ρCB ω → ω = sigT ρAC ρCB := by
  refine ⟨⟨fun h1 => ⟨sigT ρAC ρCB, sigT_markov_of_trC_eq_one hAC hCB hcons h1⟩,
    ?_⟩, fun ω hω => (markov_completion_eq_sigT hAC hCB hcons ω hω).2⟩
  rintro ⟨ω, hω⟩
  exact (markov_completion_eq_sigT hAC hCB hcons ω hω).1

end HiddenChannelCapacity
