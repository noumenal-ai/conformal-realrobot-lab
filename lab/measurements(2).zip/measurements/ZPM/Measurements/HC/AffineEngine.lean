/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Amalgamation
import Mathlib.Data.Finset.SymmDiff
import Mathlib.Data.ZMod.Basic
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.Ring

/-!
# The affine obstruction engine

The witness machinery of the Vorob'ev-converse programme, packaged independently of any
acyclicity grammar so that any cover analysis can consume it. The direction is base-first: the
object it reads is a base-side structure (a hosted odd F2 dependency carried by the cover's
incidence geometry), and what that structure licenses is a verdict on local measurement, a
family of local relations over `ZMod 2` that is pairwise consistent yet realizes no global
structure. The F2 linear algebra is the proof instrument, not the thesis.

A constraint is a support `w : Finset ι` with a constant `c w : ZMod 2`. Constants attach to
VECTORS, not teams, so replication across teams never constrains them. Each team enforces
every constraint whose support it contains (`affLocal`, the uniform replication rule). Three
hypotheses drive everything:

* `ClosedAt` — intra-team subset sums of supports stay in the system (or vanish);
* `CoherentAt` — constants vanish on every intra-team dependency;
* an ODD HOSTED DEPENDENCY — supports summing to `∅` with constant sum `1`, every member
  hosted by some team.

The engine yields: every local relation is nonempty (`affLocal_nonempty`), interface marginals
compute exactly (`imarg_affLocal`: the interface sees precisely the visible constraints, so
consistency is definitional equality of visible systems, `consistent_affFam`), and no global
structure realizes the family (`not_glues_affFam`): a global would satisfy every hosted
constraint, and the odd base dependency sums those satisfactions to `0 = 1`. The bundle is
`affine_obstruction`.

The solvability core (`exists_parity_solution`) is elementary Gaussian elimination over
LIST-presented systems (per-entry constants, so no image-collision bookkeeping): eliminate one
vertex of one support, transform the tail, and lift dependencies of the transformed system
back along `List.sublist_map_iff`.
-/

namespace HiddenChannelCapacity

open Finset
open scoped symmDiff

variable {ι : Type*} [DecidableEq ι]

/-! ### Parity grammar -/

/-- Parity of a global configuration over a support. -/
def parityOn (w : Finset ι) (f : ι → ZMod 2) : ZMod 2 := ∑ i ∈ w, f i

set_option linter.unusedVariables false in
/-- Parity of a team configuration over the team part of a support. -/
def wsum (V w : Finset ι) (f : ∀ i : V, ZMod 2) : ZMod 2 :=
  ∑ i ∈ V.attach, if (i : ι) ∈ w then f i else 0

private lemma zmod2_add_self : ∀ a : ZMod 2, a + a = 0 := by decide

lemma wsum_restrict {V w : Finset ι} (hw : w ⊆ V) (f : ι → ZMod 2) :
    wsum V w (V.restrict f) = parityOn w f := by
  calc wsum V w (V.restrict f)
      = ∑ j ∈ V, if j ∈ w then f j else 0 :=
        Finset.sum_attach V (fun j => if j ∈ w then f j else 0)
    _ = ∑ j ∈ V ∩ w, f j := Finset.sum_ite_mem V w f
    _ = parityOn w f := by rw [Finset.inter_eq_right.mpr hw, parityOn]

set_option linter.unusedVariables false in
/-- Transport of team parities along nested restriction: the value only reads the support. -/
lemma wsum_restrict₂ {V S w : Finset ι} (hS : S ⊆ V) (hw : w ⊆ S)
    (F : ∀ i : V, ZMod 2) :
    wsum S w (Finset.restrict₂ (π := fun _ => ZMod 2) hS F) = wsum V w F := by
  classical
  set f : ι → ZMod 2 := fun j => if h : j ∈ V then F ⟨j, h⟩ else 0 with hf
  have hFf : F = Finset.restrict (π := fun _ => ZMod 2) V f := by
    funext i
    show F i = if h : (i : ι) ∈ V then F ⟨(i : ι), h⟩ else 0
    rw [dif_pos (show (i : ι) ∈ V from i.2)]
  have hres : Finset.restrict₂ (π := fun _ => ZMod 2) hS F =
      Finset.restrict (π := fun _ => ZMod 2) S f := by
    rw [hFf]
    funext i
    rfl
  rw [hres, wsum_restrict hw, hFf, wsum_restrict (hw.trans hS)]

lemma parityOn_symmDiff (w w' : Finset ι) (f : ι → ZMod 2) :
    parityOn (w ∆ w') f = parityOn w f + parityOn w' f := by
  have hw : parityOn w f = ∑ i ∈ w \ w', f i + ∑ i ∈ w ∩ w', f i := by
    rw [← Finset.sum_union (Finset.disjoint_sdiff_inter w w'), Finset.sdiff_union_inter]
    rfl
  have hw' : parityOn w' f = ∑ i ∈ w' \ w, f i + ∑ i ∈ w ∩ w', f i := by
    rw [Finset.inter_comm,
      ← Finset.sum_union (Finset.disjoint_sdiff_inter w' w), Finset.sdiff_union_inter]
    rfl
  have hΔ : parityOn (w ∆ w') f = ∑ i ∈ w \ w', f i + ∑ i ∈ w' \ w, f i := by
    rw [parityOn, symmDiff_def, Finset.sup_eq_union, Finset.sum_union (disjoint_sdiff_sdiff)]
  rw [hΔ, hw, hw']
  linear_combination - zmod2_add_self (∑ i ∈ w ∩ w', f i)

/-! ### F2 sums of support collections -/

attribute [local instance] symmDiff_isCommutative symmDiff_isAssociative

/-- F2 sum of a finite collection of supports. -/
def xorSum (D : Finset (Finset ι)) : Finset ι := D.fold (· ∆ ·) ∅ id

/-- F2 sum of a list of supports. -/
def xorSumL (l : List (Finset ι)) : Finset ι := l.foldr (· ∆ ·) ∅

@[simp] lemma xorSumL_nil : xorSumL ([] : List (Finset ι)) = ∅ := rfl

@[simp] lemma xorSumL_cons (w : Finset ι) (l : List (Finset ι)) :
    xorSumL (w :: l) = w ∆ xorSumL l := rfl

lemma symmDiff_empty (a : Finset ι) : a ∆ (∅ : Finset ι) = a := by
  rw [← Finset.bot_eq_empty, symmDiff_bot]

lemma xorSumL_append (a b : List (Finset ι)) :
    xorSumL (a ++ b) = xorSumL a ∆ xorSumL b := by
  induction a with
  | nil => rw [List.nil_append, xorSumL_nil, bot_eq_empty.symm, bot_symmDiff]
  | cons w a ih => rw [List.cons_append, xorSumL_cons, xorSumL_cons, ih, symmDiff_assoc]

lemma xorSumL_eq_xorSum : ∀ {l : List (Finset ι)}, l.Nodup → xorSumL l = xorSum l.toFinset
  | [], _ => rfl
  | w :: l, h => by
    rw [xorSumL_cons, List.toFinset_cons, xorSum,
      Finset.fold_insert (by simpa using (List.nodup_cons.mp h).1),
      xorSumL_eq_xorSum (List.nodup_cons.mp h).2]
    rfl

lemma xorSum_subset {V : Finset ι} {𝒲 : Finset (Finset ι)} :
    ∀ {D : Finset (Finset ι)}, D ⊆ 𝒲.filter (· ⊆ V) → xorSum D ⊆ V := by
  intro D
  induction D using Finset.induction_on with
  | empty => intro _; rw [xorSum, Finset.fold_empty]; exact Finset.empty_subset V
  | @insert w D hw ih =>
    intro hins
    rw [xorSum, Finset.fold_insert hw]
    have h₁ : w ≤ V := (Finset.mem_filter.mp (hins (Finset.mem_insert_self w D))).2
    have h₂ : xorSum D ≤ V := ih (fun T hT => hins (Finset.mem_insert_of_mem hT))
    show id w ∆ xorSum D ≤ V
    exact le_trans symmDiff_le_sup (sup_le h₁ h₂)

lemma parityOn_xorSum (D : Finset (Finset ι)) (f : ι → ZMod 2) :
    parityOn (xorSum D) f = ∑ w ∈ D, parityOn w f := by
  induction D using Finset.induction_on with
  | empty => simp [xorSum, parityOn]
  | @insert w D hw ih =>
    rw [xorSum, Finset.fold_insert hw, id, parityOn_symmDiff, Finset.sum_insert hw, ← xorSum, ih]

/-! ### The solvability core: elementary Gaussian elimination on list systems -/

/-- Coherence of a list-presented parity system: constants vanish on every dependency. -/
def SysCoherent (L : List (Finset ι × ZMod 2)) : Prop :=
  ∀ sub : List (Finset ι × ZMod 2), sub.Sublist L →
    xorSumL (sub.map Prod.fst) = ∅ → (sub.map Prod.snd).sum = 0

/-- The Gaussian transform bookkeeping: transforming the x-containing entries by `∆ w₀`
shifts the F2 sum by `w₀` per transformed entry, and the constants by `c₀` likewise. -/
private lemma transform_bookkeeping (x : ι) (w₀ : Finset ι) (c₀ : ZMod 2) :
    ∀ sub : List (Finset ι × ZMod 2),
      xorSumL ((sub.map (fun p => if x ∈ p.1 then (p.1 ∆ w₀, p.2 + c₀) else p)).map Prod.fst) =
        xorSumL (sub.map Prod.fst) ∆
          (if sub.countP (fun p : Finset ι × ZMod 2 => decide (x ∈ p.1)) % 2 = 1 then w₀ else ∅) ∧
      ((sub.map (fun p => if x ∈ p.1 then (p.1 ∆ w₀, p.2 + c₀) else p)).map Prod.snd).sum =
        (sub.map Prod.snd).sum +
          (if sub.countP (fun p : Finset ι × ZMod 2 => decide (x ∈ p.1)) % 2 = 1 then c₀ else 0) := by
  intro sub
  induction sub with
  | nil =>
    refine ⟨?_, ?_⟩
    · show (∅ : Finset ι) = ∅ ∆ (if 0 % 2 = 1 then w₀ else ∅)
      rw [if_neg (by omega), symmDiff_self, bot_eq_empty]
    · show (0 : ZMod 2) = 0 + (if 0 % 2 = 1 then c₀ else 0)
      rw [if_neg (by omega), add_zero]
  | cons q sub ih =>
    obtain ⟨ihΔ, ihS⟩ := ih
    by_cases hq : x ∈ q.1
    · have hK : (q :: sub).countP (fun p : Finset ι × ZMod 2 => decide (x ∈ p.1)) =
          sub.countP (fun p : Finset ι × ZMod 2 => decide (x ∈ p.1)) + 1 := by
        rw [List.countP_cons]
        simp [hq]
      rcases Nat.mod_two_eq_zero_or_one (sub.countP (fun p : Finset ι × ZMod 2 => decide (x ∈ p.1))) with hk | hk
      · refine ⟨?_, ?_⟩
        · simp only [List.map_cons, if_pos hq, xorSumL_cons, hK, ihΔ]
          rw [if_neg (show ¬ sub.countP (fun p : Finset ι × ZMod 2 => decide (x ∈ p.1)) % 2 = 1 by omega),
            if_pos (show (sub.countP (fun p : Finset ι × ZMod 2 => decide (x ∈ p.1)) + 1) % 2 = 1 by omega),
            symmDiff_empty, symmDiff_assoc,
            symmDiff_comm w₀ (xorSumL (List.map Prod.fst sub)), ← symmDiff_assoc]
        · simp only [List.map_cons, if_pos hq, List.sum_cons, hK, ihS]
          rw [if_neg (show ¬ sub.countP (fun p : Finset ι × ZMod 2 => decide (x ∈ p.1)) % 2 = 1 by omega),
            if_pos (show (sub.countP (fun p : Finset ι × ZMod 2 => decide (x ∈ p.1)) + 1) % 2 = 1 by omega),
            add_zero]
          ring
      · refine ⟨?_, ?_⟩
        · simp only [List.map_cons, if_pos hq, xorSumL_cons, hK, ihΔ]
          rw [if_pos hk,
            if_neg (show ¬ (sub.countP (fun p : Finset ι × ZMod 2 => decide (x ∈ p.1)) + 1) % 2 = 1 by omega),
            symmDiff_empty, symmDiff_comm (xorSumL (List.map Prod.fst sub)) w₀, symmDiff_assoc,
            ← symmDiff_assoc w₀ w₀ (xorSumL (List.map Prod.fst sub)), symmDiff_self,
            bot_symmDiff]
        · simp only [List.map_cons, if_pos hq, List.sum_cons, hK, ihS]
          rw [if_pos hk,
            if_neg (show ¬ (sub.countP (fun p : Finset ι × ZMod 2 => decide (x ∈ p.1)) + 1) % 2 = 1 by omega),
            add_zero]
          linear_combination zmod2_add_self c₀
    · have hK : (q :: sub).countP (fun p : Finset ι × ZMod 2 => decide (x ∈ p.1)) =
          sub.countP (fun p : Finset ι × ZMod 2 => decide (x ∈ p.1)) := by
        rw [List.countP_cons]
        simp [hq]
      refine ⟨?_, ?_⟩
      · simp only [List.map_cons, if_neg hq, xorSumL_cons, hK, ihΔ]
        rw [← symmDiff_assoc]
      · simp only [List.map_cons, if_neg hq, List.sum_cons, hK, ihS]
        ring

/-- **The solvability core**: a coherent list-presented parity system has a solution.
Elementary Gaussian elimination, by induction on the list. -/
theorem exists_parity_solution :
    ∀ L : List (Finset ι × ZMod 2), SysCoherent L →
      ∃ f : ι → ZMod 2, ∀ p ∈ L, parityOn p.1 f = p.2
  | [], _ => ⟨0, by simp⟩
  | (w₀, c₀) :: rest, hco => by
    classical
    rcases w₀.eq_empty_or_nonempty with rfl | ⟨x, hx⟩
    · -- empty support: the constant is forced to zero; solve the tail
      have hc₀ : c₀ = 0 := by
        have h := hco [(∅, c₀)] ((List.nil_sublist rest).cons_cons (∅, c₀))
          (by simp [xorSumL_cons, symmDiff_self])
        simpa using h
      obtain ⟨f, hf⟩ := exists_parity_solution rest
        (fun sub hs => hco sub (hs.cons (∅, c₀)))
      refine ⟨f, ?_⟩
      rintro p hp
      rcases List.mem_cons.mp hp with rfl | hp
      · simp [parityOn, hc₀]
      · exact hf p hp
    · -- Gaussian step at the vertex x of w₀
      set g : Finset ι × ZMod 2 → Finset ι × ZMod 2 :=
        fun p => if x ∈ p.1 then (p.1 ∆ w₀, p.2 + c₀) else p with hg
      have hco' : SysCoherent (rest.map g) := by
        intro sub' hs' hΔ'
        obtain ⟨sub, hsub, rfl⟩ := List.sublist_map_iff.mp hs'
        obtain ⟨hbΔ, hbS⟩ := transform_bookkeeping x w₀ c₀ sub
        rw [← hg] at hbΔ hbS
        rw [hbΔ] at hΔ'
        rw [hbS]
        rcases Nat.mod_two_eq_zero_or_one (sub.countP (fun p : Finset ι × ZMod 2 => decide (x ∈ p.1))) with hk | hk
        · rw [if_neg (show ¬ sub.countP (fun p : Finset ι × ZMod 2 => decide (x ∈ p.1)) % 2 = 1 by omega),
            symmDiff_empty] at hΔ'
          rw [if_neg (show ¬ sub.countP (fun p : Finset ι × ZMod 2 => decide (x ∈ p.1)) % 2 = 1 by omega),
            add_zero]
          exact hco sub (hsub.cons (w₀, c₀)) hΔ'
        · rw [if_pos hk] at hΔ'
          rw [if_pos hk]
          rw [← bot_eq_empty] at hΔ'
          have hX : xorSumL (sub.map Prod.fst) = w₀ := symmDiff_eq_bot.mp hΔ'
          have h := hco ((w₀, c₀) :: sub) (hsub.cons_cons (w₀, c₀))
            (by rw [List.map_cons, xorSumL_cons, hX, symmDiff_self, bot_eq_empty])
          rw [List.map_cons, List.sum_cons] at h
          linear_combination h
      obtain ⟨f', hf'⟩ := exists_parity_solution (rest.map g) hco'
      set v : ZMod 2 := c₀ + ∑ i ∈ w₀.erase x, f' i with hv
      have hupd_off : ∀ w : Finset ι, x ∉ w →
          parityOn w (Function.update f' x v) = parityOn w f' := by
        intro w hw
        exact Finset.sum_update_of_notMem hw f' v
      have hw₀sat : parityOn w₀ (Function.update f' x v) = c₀ := by
        rw [parityOn, ← Finset.sum_erase_add _ _ hx,
          Finset.sum_update_of_notMem (Finset.notMem_erase x w₀), Function.update_self, hv]
        linear_combination zmod2_add_self (∑ i ∈ w₀.erase x, f' i)
      refine ⟨Function.update f' x v, ?_⟩
      rintro p hp
      rcases List.mem_cons.mp hp with rfl | hp
      · exact hw₀sat
      · have hgp := hf' (g p) (List.mem_map_of_mem hp)
        by_cases hxp : x ∈ p.1
        · rw [hg] at hgp
          simp only [if_pos hxp] at hgp
          have hoff : x ∉ p.1 ∆ w₀ := by
            simp [Finset.mem_symmDiff, hxp, hx]
          have h1 : parityOn (p.1 ∆ w₀) (Function.update f' x v) = p.2 + c₀ := by
            rw [hupd_off _ hoff]; exact hgp
          have h2 : parityOn p.1 (Function.update f' x v) =
              parityOn (p.1 ∆ w₀) (Function.update f' x v) +
                parityOn w₀ (Function.update f' x v) := by
            rw [← parityOn_symmDiff, symmDiff_symmDiff_cancel_right]
          rw [h2, h1, hw₀sat]
          linear_combination zmod2_add_self c₀
        · rw [hg] at hgp
          simp only [if_neg hxp] at hgp
          rw [hupd_off _ hxp]
          exact hgp
  termination_by L => L.length
  decreasing_by
    · simp
    · simp [List.length_map]

/-! ### Local structures by uniform replication -/

/-- The team `V` with every constraint of the system that fits inside it: the uniform
replication rule. -/
def affLocal (V : Finset ι) (𝒲 : Finset (Finset ι)) (c : Finset ι → ZMod 2) :
    LocalStruct ι (fun _ => ZMod 2) :=
  ⟨V, Finset.univ.filter (fun F => ∀ w ∈ 𝒲, w ⊆ V → wsum V w F = c w)⟩

lemma mem_affLocal_rel {V : Finset ι} {𝒲 : Finset (Finset ι)} {c : Finset ι → ZMod 2}
    {F : V → ZMod 2} :
    F ∈ (affLocal V 𝒲 c).rel ↔ ∀ w ∈ 𝒲, w ⊆ V → wsum V w F = c w :=
  ⟨fun h => (Finset.mem_filter.mp h).2,
   fun h => Finset.mem_filter.mpr ⟨Finset.mem_univ F, h⟩⟩

/-- Intra-team span closure: subset sums of the constraints hosted by `V` vanish or stay in
the system. -/
def ClosedAt (𝒲 : Finset (Finset ι)) (V : Finset ι) : Prop :=
  ∀ D ∈ (𝒲.filter (· ⊆ V)).powerset, xorSum D = ∅ ∨ xorSum D ∈ 𝒲

/-- Intra-team coherence: constants vanish on the dependencies hosted by `V`. -/
def CoherentAt (𝒲 : Finset (Finset ι)) (c : Finset ι → ZMod 2) (V : Finset ι) : Prop :=
  ∀ D ∈ (𝒲.filter (· ⊆ V)).powerset, xorSum D = ∅ → ∑ w ∈ D, c w = 0

instance decidableClosedAt (𝒲 : Finset (Finset ι)) (V : Finset ι) :
    Decidable (ClosedAt 𝒲 V) := by
  unfold ClosedAt
  infer_instance

instance decidableCoherentAt (𝒲 : Finset (Finset ι)) (c : Finset ι → ZMod 2) (V : Finset ι) :
    Decidable (CoherentAt 𝒲 c V) := by
  unfold CoherentAt
  infer_instance

/-- The hosted constraints of `V`, as a list system. -/
private noncomputable def hostedList (V : Finset ι) (𝒲 : Finset (Finset ι))
    (c : Finset ι → ZMod 2) : List (Finset ι × ZMod 2) :=
  (𝒲.filter (· ⊆ V)).toList.map (fun w => (w, c w))

omit [DecidableEq ι] in
private lemma map_fst_pair (c : Finset ι → ZMod 2) (l : List (Finset ι)) :
    (l.map (fun w => (w, c w))).map Prod.fst = l := by
  induction l with
  | nil => rfl
  | cons a l ih => simp [ih]

omit [DecidableEq ι] in
private lemma map_snd_pair (c : Finset ι → ZMod 2) (l : List (Finset ι)) :
    (l.map (fun w => (w, c w))).map Prod.snd = l.map c := by
  induction l with
  | nil => rfl
  | cons a l ih => simp [ih]

omit [DecidableEq ι] in
private lemma map_fst_pin (g₀ : ι → ZMod 2) (l : List ι) :
    (l.map (fun i => (({i} : Finset ι), g₀ i))).map Prod.fst = l.map ({·} : ι → Finset ι) := by
  induction l with
  | nil => rfl
  | cons a l ih => simp [ih]

omit [DecidableEq ι] in
private lemma map_snd_pin (g₀ : ι → ZMod 2) (l : List ι) :
    (l.map (fun i => (({i} : Finset ι), g₀ i))).map Prod.snd = l.map g₀ := by
  induction l with
  | nil => rfl
  | cons a l ih => simp [ih]

private lemma sysCoherent_hostedList {V : Finset ι} {𝒲 : Finset (Finset ι)}
    {c : Finset ι → ZMod 2} (hco : CoherentAt 𝒲 c V) :
    SysCoherent (hostedList V 𝒲 c) := by
  intro sub hs hΔ
  obtain ⟨l, hl, rfl⟩ := List.sublist_map_iff.mp hs
  have hnd : l.Nodup := (Finset.nodup_toList _).sublist hl
  have hsub : l.toFinset ∈ (𝒲.filter (· ⊆ V)).powerset := by
    rw [Finset.mem_powerset]
    intro w hw
    exact (Finset.mem_toList).mp (hl.subset ((List.mem_toFinset).mp hw))
  rw [map_fst_pair, xorSumL_eq_xorSum hnd] at hΔ
  rw [map_snd_pair, ← List.sum_toFinset c hnd]
  exact hco l.toFinset hsub hΔ

/-- Every local relation of a coherent system is nonempty. -/
theorem affLocal_nonempty {V : Finset ι} {𝒲 : Finset (Finset ι)} {c : Finset ι → ZMod 2}
    (hco : CoherentAt 𝒲 c V) : (affLocal V 𝒲 c).rel.Nonempty := by
  obtain ⟨f, hf⟩ := exists_parity_solution (hostedList V 𝒲 c) (sysCoherent_hostedList hco)
  refine ⟨V.restrict f, mem_affLocal_rel.mpr ?_⟩
  intro w hw hwV
  rw [wsum_restrict hwV]
  exact hf (w, c w) (List.mem_map_of_mem
    ((Finset.mem_toList).mpr (Finset.mem_filter.mpr ⟨hw, hwV⟩)))

/-! ### The exact marginal computation -/

private lemma xorSumL_singletons :
    ∀ {l : List ι}, l.Nodup → xorSumL (l.map ({·} : ι → Finset ι)) = l.toFinset
  | [], _ => rfl
  | i :: l, h => by
    have ih := xorSumL_singletons (List.nodup_cons.mp h).2
    have hi : i ∉ l.toFinset := by simpa using (List.nodup_cons.mp h).1
    rw [List.map_cons, xorSumL_cons, ih, List.toFinset_cons]
    ext j
    by_cases hj : j = i
    · subst hj
      simp [Finset.mem_symmDiff, hi]
    · simp [Finset.mem_symmDiff, hj]

/-- The pinned system: hosted constraints of `V` plus a singleton pin at every `S`-coordinate
of a visible-constraint-satisfying trace. Coherent, by closedness. -/
private lemma sysCoherent_pinned {V S : Finset ι} {𝒲 : Finset (Finset ι)}
    {c : Finset ι → ZMod 2} (hcl : ClosedAt 𝒲 V) (hco : CoherentAt 𝒲 c V)
    (g₀ : ι → ZMod 2) (hg : ∀ w ∈ 𝒲, w ⊆ S → parityOn w g₀ = c w) :
    SysCoherent (hostedList V 𝒲 c ++ S.toList.map (fun i => ({i}, g₀ i))) := by
  intro sub hs hΔ
  obtain ⟨s₁, s₂, rfl, h₁, h₂⟩ := List.sublist_append_iff.mp hs
  obtain ⟨l₁, hl₁, rfl⟩ := List.sublist_map_iff.mp h₁
  obtain ⟨l₂, hl₂, rfl⟩ := List.sublist_map_iff.mp h₂
  have hnd₁ : l₁.Nodup := (Finset.nodup_toList _).sublist hl₁
  have hnd₂ : l₂.Nodup := (Finset.nodup_toList _).sublist hl₂
  set D₁ : Finset (Finset ι) := l₁.toFinset with hD₁
  set P : Finset ι := l₂.toFinset with hP
  have hD₁sub : D₁ ∈ (𝒲.filter (· ⊆ V)).powerset := by
    rw [Finset.mem_powerset]
    intro w hw
    exact (Finset.mem_toList).mp (hl₁.subset ((List.mem_toFinset).mp hw))
  have hPS : P ⊆ S := by
    intro i hi
    exact (Finset.mem_toList).mp (hl₂.subset ((List.mem_toFinset).mp hi))
  have hD₁sub' : D₁ ⊆ 𝒲.filter (· ⊆ V) := Finset.mem_powerset.mp hD₁sub
  -- the F2 sum splits into the hosted part and the pin part
  rw [List.map_append, xorSumL_append, map_fst_pair, map_fst_pin, xorSumL_eq_xorSum hnd₁,
    xorSumL_singletons hnd₂, ← hD₁, ← hP, ← bot_eq_empty, symmDiff_eq_bot] at hΔ
  -- constants split likewise
  have hsnd₁ : ((l₁.map (fun w => (w, c w))).map Prod.snd).sum = ∑ w ∈ D₁, c w := by
    rw [map_snd_pair, hD₁, ← List.sum_toFinset c hnd₁]
  have hsnd₂ : ((l₂.map (fun i => (({i} : Finset ι), g₀ i))).map Prod.snd).sum =
      parityOn P g₀ := by
    show ((l₂.map (fun i => (({i} : Finset ι), g₀ i))).map Prod.snd).sum = ∑ i ∈ P, g₀ i
    rw [map_snd_pin, hP, ← List.sum_toFinset g₀ hnd₂]
  rw [List.map_append, List.sum_append, hsnd₁, hsnd₂, ← hΔ]
  -- close via the intra-team dichotomy
  rcases hcl D₁ hD₁sub with hzero | hmem
  · -- the hosted part vanishes: the pins vanish with it
    rw [hzero]
    have : parityOn (∅ : Finset ι) g₀ = 0 := by simp [parityOn]
    rw [this, hco D₁ hD₁sub hzero, add_zero]
  · -- the hosted part is a visible member: its constant is pinned by g₀
    have hvS : xorSum D₁ ⊆ S := hΔ ▸ hPS
    have hvg : parityOn (xorSum D₁) g₀ = c (xorSum D₁) := hg _ hmem hvS
    rw [hvg]
    by_cases hvD : xorSum D₁ ∈ D₁
    · have herase : xorSum (D₁.erase (xorSum D₁)) = ∅ := by
        have hins : xorSum D₁ = xorSum D₁ ∆ xorSum (D₁.erase (xorSum D₁)) := by
          conv_lhs => rw [← Finset.insert_erase hvD, xorSum,
            Finset.fold_insert (Finset.notMem_erase _ _)]
          rfl
        have := symmDiff_eq_left.mp hins.symm
        rwa [bot_eq_empty] at this
      have hesub : D₁.erase (xorSum D₁) ∈ (𝒲.filter (· ⊆ V)).powerset :=
        Finset.mem_powerset.mpr ((Finset.erase_subset _ _).trans hD₁sub')
      have hsum := hco _ hesub herase
      rw [← Finset.sum_erase_add _ _ hvD, hsum, zero_add]
      exact zmod2_add_self _
    · have hins : xorSum (insert (xorSum D₁) D₁) = ∅ := by
        rw [xorSum, Finset.fold_insert hvD]
        change xorSum D₁ ∆ xorSum D₁ = ∅
        rw [symmDiff_self, bot_eq_empty]
      have hinsub : insert (xorSum D₁) D₁ ∈ (𝒲.filter (· ⊆ V)).powerset :=
        Finset.mem_powerset.mpr (Finset.insert_subset
          (Finset.mem_filter.mpr ⟨hmem, xorSum_subset hD₁sub'⟩) hD₁sub')
      have hsum := hco _ hinsub hins
      rw [Finset.sum_insert hvD] at hsum
      linear_combination hsum

/-- **The exact marginal computation**: the interface marginal of a closed coherent local
structure is exactly the local structure of the interface — the interface sees precisely the
visible constraints. -/
theorem imarg_affLocal {V S : Finset ι} {𝒲 : Finset (Finset ι)} {c : Finset ι → ZMod 2}
    (hS : S ⊆ V) (hcl : ClosedAt 𝒲 V) (hco : CoherentAt 𝒲 c V) :
    (affLocal V 𝒲 c).imarg (hS : S ⊆ (affLocal V 𝒲 c).team) = (affLocal S 𝒲 c).rel := by
  classical
  apply Finset.Subset.antisymm
  · -- the marginal satisfies the visible constraints
    intro g hg
    obtain ⟨F, hF, rfl⟩ := Finset.mem_image.mp hg
    have hFc := mem_affLocal_rel.mp hF
    refine mem_affLocal_rel.mpr ?_
    intro w hw hwS
    rw [wsum_restrict₂ (V := (affLocal V 𝒲 c).team) hS hwS]
    exact hFc w hw (hwS.trans hS)
  · -- every visible-constraint solution extends: pin the trace, solve
    intro g hgmem
    have hgc := mem_affLocal_rel.mp hgmem
    set g₀ : ι → ZMod 2 := fun j => if h : j ∈ S then g ⟨j, h⟩ else 0 with hg₀
    have hgres : Finset.restrict (π := fun _ => ZMod 2) S g₀ = g := by
      funext i
      show (if h : (i : ι) ∈ S then g ⟨(i : ι), h⟩ else 0) = g i
      rw [dif_pos (show (i : ι) ∈ S from i.2)]
    have hvis : ∀ w ∈ 𝒲, w ⊆ S → parityOn w g₀ = c w := by
      intro w hw hwS
      rw [← wsum_restrict hwS g₀, hgres]
      exact hgc w hw hwS
    obtain ⟨f, hf⟩ := exists_parity_solution _ (sysCoherent_pinned hcl hco g₀ hvis)
    refine Finset.mem_image.mpr ⟨V.restrict f, mem_affLocal_rel.mpr ?_, ?_⟩
    · intro w hw hwV
      rw [wsum_restrict hwV]
      exact hf (w, c w) (List.mem_append_left _ (List.mem_map_of_mem
        ((Finset.mem_toList).mpr (Finset.mem_filter.mpr ⟨hw, hwV⟩))))
    · funext i
      have hpin := hf ({(i : ι)}, g₀ i) (List.mem_append_right _
        (List.mem_map_of_mem ((Finset.mem_toList).mpr i.2)))
      have : parityOn {(i : ι)} f = f i := by simp [parityOn]
      rw [this] at hpin
      show (V.restrict f) ⟨(i : ι), hS i.2⟩ = g i
      calc (V.restrict f) ⟨(i : ι), hS i.2⟩ = f i := rfl
        _ = g₀ i := hpin
        _ = g i := by
          show (if h : (i : ι) ∈ S then g ⟨(i : ι), h⟩ else 0) = g i
          rw [dif_pos (show (i : ι) ∈ S from i.2)]

/-! ### The family: consistency and non-gluing -/

/-- The affine family over a cover: every team with its fitting constraints. -/
def affFam (teams : List (Finset ι)) (𝒲 : Finset (Finset ι)) (c : Finset ι → ZMod 2) :
    List (LocalStruct ι (fun _ => ZMod 2)) :=
  teams.map (fun V => affLocal V 𝒲 c)

/-- Closed coherent affine families are pairwise consistent: both interface marginals ARE the
interface's visible system. -/
theorem consistent_affFam {teams : List (Finset ι)} {𝒲 : Finset (Finset ι)}
    {c : Finset ι → ZMod 2} (hcl : ∀ V ∈ teams, ClosedAt 𝒲 V)
    (hco : ∀ V ∈ teams, CoherentAt 𝒲 c V) :
    Consistent (affFam teams 𝒲 c) := by
  intro L₁ h₁ L₂ h₂
  obtain ⟨V₁, hV₁, rfl⟩ := List.mem_map.mp h₁
  obtain ⟨V₂, hV₂, rfl⟩ := List.mem_map.mp h₂
  exact (imarg_affLocal Finset.inter_subset_left (hcl V₁ hV₁) (hco V₁ hV₁)).trans
    (imarg_affLocal Finset.inter_subset_right (hcl V₂ hV₂) (hco V₂ hV₂)).symm

/-- **The obstruction theorem**: a hosted odd dependency (a base-side witness) forecloses every
global structure; any global realizing all the local relations would satisfy every hosted
constraint, and the dependency sums those satisfactions to `0 = 1`. -/
theorem not_glues_affFam [Fintype ι] {teams : List (Finset ι)} {𝒲 : Finset (Finset ι)}
    {c : Finset ι → ZMod 2} (hne : teams ≠ [])
    (hco : ∀ V ∈ teams, CoherentAt 𝒲 c V)
    (D : Finset (Finset ι)) (hD : D ⊆ 𝒲) (hΔ : xorSum D = ∅)
    (hodd : ∑ w ∈ D, c w = 1)
    (hhost : ∀ w ∈ D, ∃ V ∈ teams, w ⊆ V) :
    ¬ Glues (affFam teams 𝒲 c) := by
  rintro ⟨κ, hκ⟩
  -- the head team's relation is nonempty, so κ is nonempty
  obtain ⟨V₀, hV₀⟩ := List.exists_mem_of_ne_nil teams hne
  have hmem₀ : affLocal V₀ 𝒲 c ∈ affFam teams 𝒲 c := List.mem_map_of_mem hV₀
  have hrel₀ : (affLocal V₀ 𝒲 c).rel.Nonempty := affLocal_nonempty (hco V₀ hV₀)
  rw [← hκ _ hmem₀] at hrel₀
  obtain ⟨f, hf⟩ := Finset.image_nonempty.mp hrel₀
  -- f satisfies every hosted constraint
  have hsat : ∀ w ∈ D, parityOn w f = c w := by
    intro w hw
    obtain ⟨V, hV, hwV⟩ := hhost w hw
    have hmem : affLocal V 𝒲 c ∈ affFam teams 𝒲 c := List.mem_map_of_mem hV
    have : V.restrict f ∈ (affLocal V 𝒲 c).rel := by
      rw [← hκ _ hmem]
      exact Finset.mem_image_of_mem _ hf
    have hc := mem_affLocal_rel.mp this
    rw [← wsum_restrict hwV f]
    exact hc w (hD hw) hwV
  -- sum the satisfactions along the dependency
  have h0 : parityOn (xorSum D) f = 1 := by
    rw [parityOn_xorSum, Finset.sum_congr rfl hsat, hodd]
  rw [hΔ] at h0
  simp [parityOn] at h0

/-- **The affine obstruction engine, packaged**: from a base-side hosted odd dependency (over a
closed coherent system) follows a verdict on local measurement, a family of nonempty local
relations that is pairwise consistent yet realizes no global structure. -/
theorem affine_obstruction [Fintype ι] {teams : List (Finset ι)} {𝒲 : Finset (Finset ι)}
    {c : Finset ι → ZMod 2} (hne : teams ≠ [])
    (hcl : ∀ V ∈ teams, ClosedAt 𝒲 V)
    (hco : ∀ V ∈ teams, CoherentAt 𝒲 c V)
    (D : Finset (Finset ι)) (hD : D ⊆ 𝒲) (hΔ : xorSum D = ∅)
    (hodd : ∑ w ∈ D, c w = 1)
    (hhost : ∀ w ∈ D, ∃ V ∈ teams, w ⊆ V) :
    Consistent (affFam teams 𝒲 c) ∧ (∀ L ∈ affFam teams 𝒲 c, L.rel.Nonempty) ∧
      ¬ Glues (affFam teams 𝒲 c) := by
  refine ⟨consistent_affFam hcl hco, ?_, not_glues_affFam hne hco D hD hΔ hodd hhost⟩
  intro L hL
  obtain ⟨V, hV, rfl⟩ := List.mem_map.mp hL
  exact affLocal_nonempty (hco V hV)

end HiddenChannelCapacity
