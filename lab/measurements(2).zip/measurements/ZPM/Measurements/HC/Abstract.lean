/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import Mathlib.Data.Set.Basic

/-!
# Hidden Channel Capacity — abstract structural layer

The substrate-neutral core of `κ`-restricted interpolation: an admissible class
`κ` of worlds, a notion of shared-equivalence, and a left/right/shared
partition of formulas. HC is read here as a measurement of the base structure
`κ`: its shape is discovered first, and that discovery decides what the shared
interface can and cannot reconstruct. The headline results are the structural
backbone of that reading:

* `reverse_direction` — shared invariance blocks any interpolation witness for a
  failing cross-entailment (a non-factoring `κ` licenses no interpolant);
* `forward_direction` — decomposability (amalgamation) plus shared definability
  reconstruct an interpolant (a factoring `κ` always interpolates);
* `no_discovery_under_decomposability` — a perpetually decomposable trajectory
  admits no cross-domain discovery;
* `oscillation_theorem` — a cross-domain discovery certifies that the base
  structure failed to decompose at some step, so `HC > 0` there.

These are polymorphic over `World` and `Formula`; the finite combinatorial
instance (`ZPM.Measurements.HC.Combinatorial`) supplies the measurable
`hidden channel capacity` whose vanishing is exactly decomposability.

This layer is deliberately assumption-light and contains the full content of the
interpolation–amalgamation biconditional and the oscillation theorem (monograph
§4, §7) with no `sorry`.
-/

namespace HiddenChannelCapacity

variable {World Formula : Type*}

/-- The admissible worlds compatible with evidence `E`: those in `κ` that satisfy
every formula of `E`. -/
def Abd (Sat : World → Formula → Prop) (kappa : Set World) (E : Set Formula) :
    Set World :=
  {w | w ∈ kappa ∧ ∀ φ ∈ E, Sat w φ}

/-- Shared formulas cannot tell apart shared-equivalent worlds. -/
def SharedInvariant (Sat : World → Formula → Prop) (SharedEq : World → World → Prop)
    (IsShared : Formula → Prop) : Prop :=
  ∀ ⦃χ⦄, IsShared χ → ∀ ⦃w₁ w₂⦄, SharedEq w₁ w₂ → (Sat w₁ χ ↔ Sat w₂ χ)

/-- `κ` is **decomposable** (amalgamable): any two admissible worlds sharing a
type can be amalgamated into an admissible world agreeing with the first on the
left vocabulary and the second on the right. This is the factorization property
whose failure `HC` measures. -/
def IsDecomposable (Sat : World → Formula → Prop) (SharedEq : World → World → Prop)
    (IsLeft IsRight : Formula → Prop) (kappa : Set World) (E : Set Formula) : Prop :=
  ∀ ⦃w₁ w₂⦄, w₁ ∈ Abd Sat kappa E → w₂ ∈ Abd Sat kappa E → SharedEq w₁ w₂ →
    ∃ w, w ∈ Abd Sat kappa E ∧
      (∀ φ, IsLeft φ → (Sat w φ ↔ Sat w₁ φ)) ∧
      (∀ φ, IsRight φ → (Sat w φ ↔ Sat w₂ φ))

/-- There is a shared interpolant mediating `φ ⇒ ψ` over the admissible worlds. -/
def HasInterpolant (Sat : World → Formula → Prop) (IsShared : Formula → Prop)
    (kappa : Set World) (E : Set Formula) (φ ψ : Formula) : Prop :=
  ∃ χ, IsShared χ ∧
    (∀ w ∈ Abd Sat kappa E, Sat w φ → Sat w χ) ∧
    (∀ w ∈ Abd Sat kappa E, Sat w χ → Sat w ψ)

/-- Shared definability: every left formula is approximated by a shared formula
that is, in turn, witnessed by an admissible world satisfying the left formula. -/
def HasSharedDefinability (Sat : World → Formula → Prop) (SharedEq : World → World → Prop)
    (IsShared IsLeft : Formula → Prop) (kappa : Set World) (E : Set Formula) : Prop :=
  ∀ φ, IsLeft φ → ∃ χ, IsShared χ ∧
    (∀ w ∈ Abd Sat kappa E, Sat w φ → Sat w χ) ∧
    (∀ w, Sat w χ → ∃ w', w' ∈ Abd Sat kappa E ∧ Sat w' φ ∧ SharedEq w' w)

/-- A cross-domain discovery: a non-interpolable left-to-right entailment. -/
def HasCrossDiscovery (Sat : World → Formula → Prop)
    (IsShared IsLeft IsRight : Formula → Prop) (kappa : Set World) (E : Set Formula) :
    Prop :=
  ∃ φ ψ, IsLeft φ ∧ IsRight ψ ∧
    (∀ w ∈ Abd Sat kappa E, Sat w φ → Sat w ψ) ∧
    ¬ HasInterpolant Sat IsShared kappa E φ ψ

/-- **Reverse direction** (monograph Thm 4.6). If shared invariance holds and two
admissible, shared-equivalent worlds disagree across a valid cross-entailment,
then no shared interpolant exists. Shared vocabulary cannot witness the hidden
coupling. -/
theorem reverse_direction (Sat : World → Formula → Prop)
    (SharedEq : World → World → Prop)
    (IsShared : Formula → Prop) (kappa : Set World) (E : Set Formula)
    (h_inv : SharedInvariant Sat SharedEq IsShared)
    {w₁ w₂ : World} (hw₁ : w₁ ∈ Abd Sat kappa E) (hw₂ : w₂ ∈ Abd Sat kappa E)
    (h_shared : SharedEq w₁ w₂)
    {φ ψ : Formula} (hφ : Sat w₁ φ) (hψ : ¬ Sat w₂ ψ)
    (_h_entail : ∀ w ∈ Abd Sat kappa E, Sat w φ → Sat w ψ) :
    ¬ HasInterpolant Sat IsShared kappa E φ ψ := by
  rintro ⟨χ, hχ, hφχ, hχψ⟩
  exact hψ (hχψ w₂ hw₂ ((h_inv hχ h_shared).mp (hφχ w₁ hw₁ hφ)))

/-- **Forward direction** (monograph Thm 4.7). Decomposability together with
shared definability reconstructs an interpolant for any valid cross-entailment.
A factoring `κ` always interpolates. -/
theorem forward_direction (Sat : World → Formula → Prop) (SharedEq : World → World → Prop)
    (IsShared IsLeft IsRight : Formula → Prop) (kappa : Set World) (E : Set Formula)
    (h_decomp : IsDecomposable Sat SharedEq IsLeft IsRight kappa E)
    (h_def : HasSharedDefinability Sat SharedEq IsShared IsLeft kappa E)
    {φ ψ : Formula} (hφ_left : IsLeft φ) (hψ_right : IsRight ψ)
    (h_entail : ∀ w ∈ Abd Sat kappa E, Sat w φ → Sat w ψ) :
    HasInterpolant Sat IsShared kappa E φ ψ := by
  obtain ⟨χ, hχ_shared, hφχ, hχ_wit⟩ := h_def φ hφ_left
  refine ⟨χ, hχ_shared, hφχ, ?_⟩
  intro w₂ hw₂ hw₂χ
  obtain ⟨w₁, hw₁, hw₁φ, h_eq⟩ := hχ_wit w₂ hw₂χ
  obtain ⟨wstar, hwstar, hL, hR⟩ := h_decomp hw₁ hw₂ h_eq
  have hwstar_φ : Sat wstar φ := (hL φ hφ_left).mpr hw₁φ
  have hwstar_ψ : Sat wstar ψ := h_entail wstar hwstar hwstar_φ
  exact (hR ψ hψ_right).mp hwstar_ψ

/-- **No discovery under perpetual decomposability** (monograph Thm 7.5). A
decomposable, shared-definable state admits no cross-domain discovery. -/
theorem no_discovery_under_decomposability (Sat : World → Formula → Prop)
    (SharedEq : World → World → Prop) (IsShared IsLeft IsRight : Formula → Prop)
    (kappa : Set World) (E : Set Formula)
    (h_decomp : IsDecomposable Sat SharedEq IsLeft IsRight kappa E)
    (h_def : HasSharedDefinability Sat SharedEq IsShared IsLeft kappa E) :
    ¬ HasCrossDiscovery Sat IsShared IsLeft IsRight kappa E := by
  rintro ⟨φ, ψ, hφ, hψ, h_entail, h_noInterp⟩
  exact h_noInterp
    (forward_direction Sat SharedEq IsShared IsLeft IsRight kappa E h_decomp h_def
      hφ hψ h_entail)

/-- **Oscillation theorem** (monograph Thm 7.7). If a shared-definable trajectory
exhibits cross-domain discovery at some step, then it cannot be decomposable at
every step: the base structure must fail to factor somewhere, so `HC` is positive
there. Via the combinatorial layer this reads `∃ t, HC(κₜ) > 0`. -/
theorem oscillation_theorem (Sat : World → Formula → Prop)
    (SharedEq : World → World → Prop) (IsShared IsLeft IsRight : Formula → Prop)
    {Step : Type*} (kappaSeq : Step → Set World) (ESeq : Step → Set Formula)
    (h_def : ∀ t, HasSharedDefinability Sat SharedEq IsShared IsLeft
      (kappaSeq t) (ESeq t))
    (h_cross : ∃ t, HasCrossDiscovery Sat IsShared IsLeft IsRight
      (kappaSeq t) (ESeq t)) :
    ¬ ∀ t, IsDecomposable Sat SharedEq IsLeft IsRight (kappaSeq t) (ESeq t) := by
  rintro h_all
  obtain ⟨t, hcross⟩ := h_cross
  exact no_discovery_under_decomposability Sat SharedEq IsShared IsLeft IsRight
    (kappaSeq t) (ESeq t) (h_all t) (h_def t) hcross

end HiddenChannelCapacity
