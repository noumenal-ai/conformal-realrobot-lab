/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.ApproximateFiveWay
import Mathlib.Tactic.TFAE

/-!
# The exact five-way at arity `n`

The multipartite upgrade of `fiveWay_uniform`: one discovered base fact about a nonempty relation
`κ` over `n` parts — its rectangularity — read five equivalent ways, the fibre-side information
face among them (`fiveWay_uniformPi`):

1. `κ` is rectangular (its own hull);
2. the combinatorial defect vanishes, `hcCombPi κ = 0`;
3. the total correlation of the canonical measure vanishes,
   `totalCorrelationReal (uniformMeasurePi κ hκ) = 0`;
4. cross-closure: every configuration whose coordinates are all exposed is admissible;
5. the counting identity `∏ᵢ countPi κ i (f i) = if f ∈ κ then |κ|^(n-1) else 0` — the discrete
   shadow of the factorization of the canonical measure.

The information leg rides the measure identity `uniformMeasurePi_eq_pi_of_isRectPi`: on a
rectangular relation the canonical measure is the product of its own marginals, so its divergence
against that product vanishes; conversely a positive defect forces positive total correlation
(the quantitative lower leg of the approximate five-way). The counting leg's backbone is the
fiber count of a product (`Fintype.card_filter_piFinset_eq`) and the double-product identity
`∏ᵢ ∏_{j ≠ i} c j = (∏ c)^(n-1)` (each factor occurs once per erased index).
-/

open MeasureTheory ProbabilityTheory InformationTheory Finset
open scoped ENNReal

noncomputable section

namespace HiddenChannelCapacity

variable {ι : Type*} [Fintype ι] [DecidableEq ι] {X : ι → Type*}
  [∀ i, Fintype (X i)] [∀ i, DecidableEq (X i)]
  [∀ i, MeasurableSpace (X i)] [∀ i, DiscreteMeasurableSpace (X i)]

/-! ### The counting backbone -/

omit [∀ i, Fintype (X i)] [∀ i, DecidableEq (X i)] [∀ i, MeasurableSpace (X i)]
  [∀ i, DiscreteMeasurableSpace (X i)] in
/-- The double-product identity: erasing each index in turn multiplies every factor `n - 1`
times, `∏ᵢ ∏_{j ≠ i} c j = (∏ c)^(n-1)`. -/
private lemma prod_prod_erase {M : Type*} [CommMonoid M] (c : ι → M) :
    ∏ i, ∏ j ∈ Finset.univ.erase i, c j = (∏ j, c j) ^ (Fintype.card ι - 1) := by
  rw [Finset.prod_comm' (t' := Finset.univ) (s' := fun j => Finset.univ.erase j)
      (fun i j => by simp [Finset.mem_erase, ne_comm, and_comm])]
  calc ∏ j, ∏ _i ∈ Finset.univ.erase j, c j
      = ∏ j, c j ^ (Fintype.card ι - 1) := by
        refine Finset.prod_congr rfl fun j _ => ?_
        rw [Finset.prod_const, Finset.card_erase_of_mem (Finset.mem_univ j), Finset.card_univ]
    _ = (∏ j, c j) ^ (Fintype.card ι - 1) := Finset.prod_pow _ _ _

omit [∀ i, Fintype (X i)] [∀ i, MeasurableSpace (X i)] [∀ i, DiscreteMeasurableSpace (X i)] in
/-- The coordinate multiplicity of a product relation is the fiber count of the product. -/
private lemma countPi_piFinset (F : ∀ i, Finset (X i)) (i : ι) (a : X i) :
    countPi (Fintype.piFinset F) i a
      = if a ∈ F i then ∏ j ∈ Finset.univ.erase i, (F j).card else 0 := by
  rw [countPi]
  exact Fintype.card_filter_piFinset_eq F i a

omit [∀ i, Fintype (X i)] [∀ i, MeasurableSpace (X i)] [∀ i, DiscreteMeasurableSpace (X i)] in
/-- **The counting backbone**: on a rectangular relation the product of the coordinate
multiplicities is `|κ|^(n-1)` on admissible configurations and `0` off them. -/
lemma prod_countPi_of_isRectPi {κ : Finset (∀ i, X i)} (hrect : IsRectPi κ)
    (f : ∀ i, X i) :
    ∏ i, countPi κ i (f i)
      = if f ∈ κ then κ.card ^ (Fintype.card ι - 1) else 0 := by
  rw [hrect, hullPi]
  simp only [countPi_piFinset]
  by_cases hf : ∀ i, f i ∈ projPi κ i
  · rw [if_pos (Fintype.mem_piFinset.mpr hf)]
    calc ∏ i, (if f i ∈ projPi κ i then ∏ j ∈ Finset.univ.erase i, (projPi κ j).card else 0)
        = ∏ i, ∏ j ∈ Finset.univ.erase i, (projPi κ j).card :=
          Finset.prod_congr rfl fun i _ => if_pos (hf i)
      _ = (∏ j, (projPi κ j).card) ^ (Fintype.card ι - 1) := prod_prod_erase _
      _ = (Fintype.piFinset (projPi κ)).card ^ (Fintype.card ι - 1) := by
          rw [Fintype.card_piFinset]
  · obtain ⟨i, hi⟩ := not_forall.mp hf
    rw [if_neg (fun hmem => hi (Fintype.mem_piFinset.mp hmem i)),
      Finset.prod_eq_zero (Finset.mem_univ i) (if_neg hi)]

/-! ### The factorization of the canonical measure -/

omit [DecidableEq ι] in
/-- Singleton mass of the canonical measure, `ℝ≥0∞`-valued. -/
private lemma uniformMeasurePi_singleton (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty)
    (f : ∀ i, X i) :
    uniformMeasurePi κ hκ {f} = if f ∈ κ then (κ.card : ℝ≥0∞)⁻¹ else 0 := by
  by_cases hf : f ∈ κ
  · rw [if_pos hf]
    unfold uniformMeasurePi
    rw [PMF.toMeasure_apply_singleton _ _ (measurableSet_singleton f),
      PMF.uniformOfFinset_apply, if_pos hf]
  · rw [if_neg hf]
    unfold uniformMeasurePi
    rw [PMF.toMeasure_apply_singleton _ _ (measurableSet_singleton f),
      PMF.uniformOfFinset_apply, if_neg hf]

/-- **On a rectangular relation the canonical measure is the product of its own marginals** —
the measure-theoretic face of rectangularity. -/
theorem uniformMeasurePi_eq_pi_of_isRectPi (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty)
    (hrect : IsRectPi κ) :
    uniformMeasurePi κ hκ
      = Measure.pi (fun i => (uniformMeasurePi κ hκ).map (fun f => f i)) := by
  have hcard0 : (κ.card : ℝ≥0∞) ≠ 0 := by exact_mod_cast Finset.card_ne_zero.mpr hκ
  have hcardtop : (κ.card : ℝ≥0∞) ≠ ⊤ := ENNReal.natCast_ne_top _
  refine Measure.ext_of_singleton fun f => ?_
  have hpi : Measure.pi (fun i => (uniformMeasurePi κ hκ).map (fun g => g i)) {f}
      = if f ∈ κ then (κ.card : ℝ≥0∞)⁻¹ else 0 := by
    rw [← Set.univ_pi_singleton f, Measure.pi_pi]
    calc ∏ i, (uniformMeasurePi κ hκ).map (fun g => g i) {f i}
        = ∏ i, ((countPi κ i (f i) : ℝ≥0∞) * (κ.card : ℝ≥0∞)⁻¹) :=
          Finset.prod_congr rfl fun i _ => marginalPi_singleton κ hκ i (f i)
      _ = ((∏ i, countPi κ i (f i) : ℕ) : ℝ≥0∞) * ((κ.card : ℝ≥0∞)⁻¹) ^ Fintype.card ι := by
          rw [Finset.prod_mul_distrib, Finset.prod_const, Finset.card_univ, Nat.cast_prod]
      _ = if f ∈ κ then (κ.card : ℝ≥0∞)⁻¹ else 0 := by
          rw [prod_countPi_of_isRectPi hrect f]
          by_cases hf : f ∈ κ
          · rw [if_pos hf, if_pos hf, Nat.cast_pow]
            rcases Nat.eq_zero_or_pos (Fintype.card ι) with h0 | hpos
            · -- empty index: the relation is a singleton, its size is one
              haveI : IsEmpty ι := Fintype.card_eq_zero_iff.mp h0
              have hone : κ.card = 1 := le_antisymm
                (by
                  have h := Finset.card_le_card κ.subset_univ
                  rwa [Finset.card_univ, Fintype.card_pi, Finset.univ_eq_empty,
                    Finset.prod_empty] at h)
                (Finset.card_pos.mpr hκ)
              simp [hone]
            · -- split one inverse factor off and cancel the rest
              have hsplit : ((κ.card : ℝ≥0∞)⁻¹) ^ Fintype.card ι
                  = ((κ.card : ℝ≥0∞)⁻¹) ^ (Fintype.card ι - 1) * (κ.card : ℝ≥0∞)⁻¹ := by
                rw [← pow_succ]
                congr 1
                omega
              rw [hsplit, ← mul_assoc, ← mul_pow,
                ENNReal.mul_inv_cancel hcard0 hcardtop, one_pow, one_mul]
          · rw [if_neg hf, if_neg hf, Nat.cast_zero, zero_mul]
  rw [hpi, uniformMeasurePi_singleton κ hκ f]

/-! ### The exact five-way -/

/-- **The information leg, exactly**: the total correlation of the canonical measure vanishes
iff the relation is rectangular. -/
theorem totalCorrelationReal_uniformPi_eq_zero_iff (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty) :
    totalCorrelationReal (uniformMeasurePi κ hκ) = 0 ↔ IsRectPi κ := by
  constructor
  · intro h
    by_contra hrect
    exact (totalCorrelationReal_uniform_pos κ hκ
      (fun h0 => hrect ((hcCombPi_eq_zero_iff_isRectPi κ).mp h0))).ne' h
  · intro hrect
    haveI : IsProbabilityMeasure (uniformMeasurePi κ hκ) := inferInstance
    rw [totalCorrelationReal, ← uniformMeasurePi_eq_pi_of_isRectPi κ hκ hrect]
    exact (klDivReal_eq_zero_iff _ _ Measure.AbsolutelyContinuous.rfl
      (by rw [klDiv_self]; exact ENNReal.zero_ne_top)).mpr rfl

/-- **The exact five-way at arity `n`**: rectangularity, vanishing defect, vanishing total
correlation of the canonical measure, cross-closure, and the counting identity are equivalent
for nonempty multipartite relations. -/
theorem fiveWay_uniformPi (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty) :
    List.TFAE
      [ IsRectPi κ,
        hcCombPi κ = 0,
        totalCorrelationReal (uniformMeasurePi κ hκ) = 0,
        ∀ f : ∀ i, X i, (∀ i, f i ∈ projPi κ i) → f ∈ κ,
        ∀ f : ∀ i, X i, ∏ i, countPi κ i (f i)
          = if f ∈ κ then κ.card ^ (Fintype.card ι - 1) else 0 ] := by
  tfae_have 1 ↔ 2 := (hcCombPi_eq_zero_iff_isRectPi κ).symm
  tfae_have 3 ↔ 1 := totalCorrelationReal_uniformPi_eq_zero_iff κ hκ
  tfae_have 1 → 4 := by
    intro h f hf
    rw [h]
    exact Fintype.mem_piFinset.mpr hf
  tfae_have 4 → 1 :=
    fun h => Finset.Subset.antisymm (subset_hullPi κ)
      (fun f hf => h f (Fintype.mem_piFinset.mp hf))
  tfae_have 1 → 5 := fun h f => prod_countPi_of_isRectPi h f
  tfae_have 5 → 4 := by
    intro h5 f hf
    by_contra hfκ
    have h0 := h5 f
    rw [if_neg hfκ] at h0
    have hpos : 0 < ∏ i, countPi κ i (f i) :=
      Finset.prod_pos fun i _ => countPi_pos κ i (hf i)
    omega
  tfae_finish

end HiddenChannelCapacity

end
