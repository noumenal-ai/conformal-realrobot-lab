/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.CechNerve
import Mathlib.LinearAlgebra.BilinearForm.Orthogonal
import Mathlib.LinearAlgebra.Matrix.Rank

/-!
# Field-general coefficients: the Fredholm alternative for arbitrary matrices,
and the two-engine cross-validation

The instrument at its most general, banked: the field-general rung named by CechNerve. The
base-measurement claims are proved here by a parent that has NO Čech vocabulary at all: for
an arbitrary matrix over an arbitrary field, the range of `mulVec` is exactly the
dot-orthogonal of the kernel of the transpose, the finite-dimensional Fredholm alternative
(the four-subspaces relation; Strang, *Linear Algebra and Its Applications*, the fundamental
theorem of linear algebra). This is machinery, not thesis; every cover-shaped base claim is
one of its instances:

* **K1** (`range_mulVecLin_eq_orthogonal_ker_transpose`, `mem_range_mulVecLin_iff`,
  `mulVec_solvable_iff`): `range M = (ker Mᵀ)ᗮ` under the dot-product bilinear form
  `dotB` (nondegenerate over every field, `dotB_nondegenerate`). Proof: adjointness
  (`Matrix.dotProduct_mulVec`) for `⊆`, and the dimension count
  `finrank (ker Mᵀ)ᗮ = dim − (dim − rank Mᵀ) = rank M = finrank (range M)`
  (Mathlib `LinearMap.BilinForm.finrank_orthogonal`, `Matrix.rank_transpose`,
  `LinearMap.finrank_range_add_finrank_ker`, `Submodule.eq_of_le_of_finrank_le`).
* **K2** (`incidenceM`, `incidence_section_iff_K`): the incidence matrix of any cover,
  its entry calculus (`mulVec` = team sums, transpose `mulVec` = site-incidence sums),
  and the field-general support-stratum (base) criterion: prescribed team sums over `K`
  are realizable iff orthogonal to every `K`-cocycle of the transpose, so the base geometry
  of the cover decides. At `K = ℝ` or `ℚ` this is the affine-relaxation stratum of the same
  nerve; at `K = ZMod 2` it meets the possibilistic stratum below.
* **K3** (`even_orthogonal_iff_cocycle_orthogonal`): the TWO-ENGINE CROSS-VALIDATION.
  The even-subcover criterion (computed by the banked Gaussian elimination,
  `exists_section_iff_even_orthogonal`) and the `ZMod 2` cocycle criterion (computed by the
  rank argument, K1) are equivalent, proved by CHAINING the two engines through the section
  space, so the equivalence is exactly the statement that two independent computations of
  the degree-1 obstruction agree. A direct combinatorial dictionary (indicator cochains ↔
  subset supports through `mem_xorSum`) exists; the chain proof is preferred precisely
  because it makes the consistency the theorem.

Next rungs stated, not claimed: non-invertible cover morphisms; degrees ≥ 2;
coefficient SYSTEMS beyond constant fields (presheaf coefficients).
-/

namespace HiddenChannelCapacity

open Finset LinearMap Matrix

variable {K : Type*} [Field K] {m n : Type*} [Fintype m] [Fintype n]

/-! ### The dot-product bilinear form and its nondegeneracy -/

/-- The dot-product bilinear form on `m → K`. -/
def dotB : LinearMap.BilinForm K (m → K) :=
  LinearMap.mk₂ K (· ⬝ᵥ ·) add_dotProduct smul_dotProduct
    dotProduct_add dotProduct_smul

@[simp] lemma dotB_apply (v w : m → K) : dotB v w = v ⬝ᵥ w := rfl

/-- The dot form is nondegenerate over every field (evaluate against basis vectors). -/
lemma dotB_nondegenerate [DecidableEq m] : (dotB (K := K) (m := m)).Nondegenerate := by
  constructor
  · intro v hv
    funext i
    have h := hv (Pi.single i 1)
    rw [dotB_apply, dotProduct_single, mul_one] at h
    exact h
  · intro v hv
    funext i
    have h := hv (Pi.single i 1)
    rw [dotB_apply, single_dotProduct, one_mul] at h
    exact h

/-! ### K1: the Fredholm alternative for arbitrary matrices -/

/-- **The Fredholm alternative** (finite-dimensional, any field): the range of a matrix
is exactly the dot-orthogonal of the kernel of its transpose. -/
theorem range_mulVecLin_eq_orthogonal_ker_transpose [DecidableEq m]
    (M : Matrix m n K) :
    LinearMap.range M.mulVecLin
      = dotB.orthogonal (LinearMap.ker Mᵀ.mulVecLin) := by
  have hle : LinearMap.range M.mulVecLin
      ≤ dotB.orthogonal (LinearMap.ker Mᵀ.mulVecLin) := by
    rintro y ⟨x, rfl⟩ z hz
    show dotB z (M.mulVecLin x) = 0
    rw [dotB_apply, Matrix.mulVecLin_apply, Matrix.dotProduct_mulVec,
      show M.vecMul z = Mᵀ.mulVec z from by
        rw [← Matrix.transpose_transpose M, Matrix.vecMul_transpose,
          Matrix.transpose_transpose],
      show Mᵀ.mulVec z = 0 from hz, zero_dotProduct]
  refine Submodule.eq_of_le_of_finrank_le hle ?_
  have horth := LinearMap.BilinForm.finrank_orthogonal
    (dotB_nondegenerate (K := K) (m := m)) (LinearMap.ker Mᵀ.mulVecLin)
  have hrn := LinearMap.finrank_range_add_finrank_ker Mᵀ.mulVecLin
  have hrt : Mᵀ.rank = M.rank := Matrix.rank_transpose M
  have hrank : Module.finrank K (LinearMap.ker Mᵀ.mulVecLin)
      = Module.finrank K (m → K) - M.rank := by
    have : Mᵀ.rank + Module.finrank K (LinearMap.ker Mᵀ.mulVecLin)
        = Module.finrank K (m → K) := hrn
    omega
  have hbound : M.rank ≤ Module.finrank K (m → K) := by
    have : Mᵀ.rank + Module.finrank K (LinearMap.ker Mᵀ.mulVecLin)
        = Module.finrank K (m → K) := hrn
    omega
  rw [horth, hrank]
  show Module.finrank K (m → K) - (Module.finrank K (m → K) - M.rank)
    ≤ Module.finrank K (LinearMap.range M.mulVecLin)
  have : Module.finrank K (m → K) - (Module.finrank K (m → K) - M.rank) = M.rank := by
    omega
  rw [this]
  exact le_refl _

/-- Membership form of the Fredholm alternative. -/
theorem mem_range_mulVecLin_iff [DecidableEq m] (M : Matrix m n K) (y : m → K) :
    y ∈ LinearMap.range M.mulVecLin
      ↔ ∀ z : m → K, Mᵀ.mulVec z = 0 → z ⬝ᵥ y = 0 := by
  rw [range_mulVecLin_eq_orthogonal_ker_transpose]
  constructor
  · intro h z hz
    exact h z (by rwa [LinearMap.mem_ker, Matrix.mulVecLin_apply])
  · intro h z hz
    exact h z (by rwa [LinearMap.mem_ker, Matrix.mulVecLin_apply] at hz)

/-- Solvability form: `Mx = y` has a solution iff `y` annihilates every solution of
the transposed homogeneous system. -/
theorem mulVec_solvable_iff [DecidableEq m] (M : Matrix m n K) (y : m → K) :
    (∃ x : n → K, M.mulVec x = y)
      ↔ ∀ z : m → K, Mᵀ.mulVec z = 0 → z ⬝ᵥ y = 0 := by
  rw [← mem_range_mulVecLin_iff]
  exact ⟨fun ⟨x, hx⟩ => ⟨x, by rwa [Matrix.mulVecLin_apply]⟩,
    fun ⟨x, hx⟩ => ⟨x, by rwa [Matrix.mulVecLin_apply] at hx⟩⟩

/-! ### K2: the incidence instance -/

variable {ι : Type*} [DecidableEq ι] [Fintype ι]

/-- The incidence matrix of a cover over `K`: teams × sites, `1` on membership. -/
def incidenceM (cover : Finset (Finset ι)) : Matrix (↥cover) ι K :=
  Matrix.of fun T i => if i ∈ T.1 then 1 else 0

/-- Incidence `mulVec` is the family of team sums (the `K`-general coboundary). -/
lemma incidenceM_mulVec (cover : Finset (Finset ι)) (x : ι → K) (T : ↥cover) :
    ((incidenceM (K := K) cover).mulVec x) T = ∑ i ∈ T.1, x i := by
  show (∑ i, (if i ∈ T.1 then (1 : K) else 0) * x i) = ∑ i ∈ T.1, x i
  rw [Finset.sum_congr rfl fun i _ => (by split_ifs <;> ring :
    (if i ∈ T.1 then (1 : K) else 0) * x i = if i ∈ T.1 then x i else 0),
    Finset.sum_ite_mem, Finset.univ_inter]

omit [Fintype ι] in
/-- Transpose-incidence `mulVec` is the family of site-incidence sums. -/
lemma incidenceM_transpose_mulVec (cover : Finset (Finset ι)) (c : ↥cover → K)
    (i : ι) :
    ((incidenceM (K := K) cover)ᵀ.mulVec c) i
      = ∑ T : ↥cover, (if i ∈ T.1 then c T else 0) := by
  show (∑ T : ↥cover, (if i ∈ T.1 then (1 : K) else 0) * c T) = _
  exact Finset.sum_congr rfl fun T _ => by split_ifs <;> ring

/-- **The field-general support-stratum (base) criterion**: prescribed team sums over any
field are realizable iff orthogonal to every cocycle of the transpose, so the base geometry
of the cover decides realizability. -/
theorem incidence_section_iff_K (cover : Finset (Finset ι)) (t : ↥cover → K) :
    (∃ x : ι → K, ∀ T : ↥cover, (∑ i ∈ T.1, x i) = t T)
      ↔ ∀ c : ↥cover → K,
          (∀ i, (∑ T : ↥cover, (if i ∈ T.1 then c T else 0)) = 0) → c ⬝ᵥ t = 0 := by
  rw [show (∃ x : ι → K, ∀ T : ↥cover, (∑ i ∈ T.1, x i) = t T)
      ↔ ∃ x, (incidenceM (K := K) cover).mulVec x = t from
    exists_congr fun x => by
      rw [funext_iff]
      exact forall_congr' fun T => by rw [incidenceM_mulVec],
    mulVec_solvable_iff]
  refine forall_congr' fun c => ?_
  rw [funext_iff]
  exact imp_congr (forall_congr' fun i => by
    rw [incidenceM_transpose_mulVec, Pi.zero_apply]) Iff.rfl

/-! ### K3: the two-engine cross-validation -/

/-- **The two-engine cross-validation.** The even-subcover criterion (computed by the
banked Gaussian elimination of the affine engine) and the `ZMod 2` cocycle criterion
(computed by the rank argument K1) are equivalent, PROVED by chaining the two engines
through the section space: this equivalence is the statement that two independent
computations of the degree-1 obstruction of the incidence complex agree. A direct
combinatorial dictionary (indicator cochains ↔ subset supports via `mem_xorSum`)
also exists; the chain proof is chosen because the consistency is the content. -/
theorem even_orthogonal_iff_cocycle_orthogonal (cover : Finset (Finset ι))
    (t : Finset ι → ZMod 2) :
    (∀ D ⊆ cover, xorSum D = ∅ → ∑ T ∈ D, t T = 0)
      ↔ ∀ c : ↥cover → ZMod 2,
          (∀ i, (∑ T : ↥cover, (if i ∈ T.1 then c T else 0)) = 0) →
            c ⬝ᵥ (fun T : ↥cover => t T.1) = 0 := by
  rw [← exists_section_iff_even_orthogonal cover t,
    ← incidence_section_iff_K cover (fun T : ↥cover => t T.1)]
  constructor
  · rintro ⟨x, hx⟩
    exact ⟨x, fun T => hx T.1 T.2⟩
  · rintro ⟨x, hx⟩
    exact ⟨x, fun T hT => hx ⟨T, hT⟩⟩

end HiddenChannelCapacity
