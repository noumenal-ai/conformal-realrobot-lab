/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Combinatorial
import Mathlib.Data.Fintype.BigOperators

/-!
# Multipartite ignorance structures

The multipartite substrate for the quantitative five-way: a relation `κ ⊆ ∏ᵢ Xᵢ` as a `Finset`
of dependent functions, its coordinate projections `projPi`, the rectangular hull
`hullPi κ = ∏ᵢ πᵢ(κ)` (the maximal relation with the same marginal exposures), and the
combinatorial hidden-channel defect

`hcCombPi κ = |∏ᵢ πᵢ(κ)| − |κ|`,

the arity-`n` form of `hcComb`: the number of configurations the interface permits but the joint
forbids. Read base-first, `hcCombPi` grades the shape of the discovered relation directly, a
verdict fixed by the support alone and independent of any weighting the local ends place over it.
The defect vanishes exactly at multipartite rectangularity
(`hcCombPi_eq_zero_iff_isRectPi`), and the forbidden region `hullPi κ \ κ` has exactly
`hcCombPi κ` elements (`card_hullPi_sdiff`) — the set whose product-measure mass drives the
quantitative lower leg of the approximate five-way.
-/

namespace HiddenChannelCapacity

open Finset

variable {ι : Type*} [Fintype ι] [DecidableEq ι] {X : ι → Type*} [∀ i, DecidableEq (X i)]

/-- The coordinate projection of a multipartite relation: what the interface exposes of part `i`. -/
def projPi (κ : Finset (∀ i, X i)) (i : ι) : Finset (X i) := κ.image (fun f => f i)

/-- The rectangular hull: the product of the coordinate projections, the maximal ignorance
consistent with the marginal exposures. -/
def hullPi (κ : Finset (∀ i, X i)) : Finset (∀ i, X i) := Fintype.piFinset (fun i => projPi κ i)

/-- The multipartite combinatorial hidden-channel defect
`hcCombPi κ = |hullPi κ| − |κ|`. -/
def hcCombPi (κ : Finset (∀ i, X i)) : ℕ := (hullPi κ).card - κ.card

/-- Multipartite rectangularity: the relation is its own rectangular hull. -/
def IsRectPi (κ : Finset (∀ i, X i)) : Prop := κ = hullPi κ

/-- A relation is contained in its rectangular hull. -/
lemma subset_hullPi (κ : Finset (∀ i, X i)) : κ ⊆ hullPi κ := fun _ hf =>
  Fintype.mem_piFinset.mpr fun _ => Finset.mem_image_of_mem _ hf

/-- The hull's cardinality is the product of the projection cardinalities. -/
lemma card_hullPi (κ : Finset (∀ i, X i)) : (hullPi κ).card = ∏ i, (projPi κ i).card :=
  Fintype.card_piFinset _

/-- **The multipartite defect vanishes exactly at rectangularity** — the zero-set anchor tying
`hcCombPi` to the five-way. -/
theorem hcCombPi_eq_zero_iff_isRectPi (κ : Finset (∀ i, X i)) :
    hcCombPi κ = 0 ↔ IsRectPi κ := by
  unfold hcCombPi IsRectPi
  constructor
  · intro h
    exact Finset.eq_of_subset_of_card_le (subset_hullPi κ) (Nat.sub_eq_zero_iff_le.mp h)
  · intro h
    rw [← h, Nat.sub_self]

/-- The forbidden region `hullPi κ \ κ` has exactly `hcCombPi κ` configurations. -/
lemma card_hullPi_sdiff (κ : Finset (∀ i, X i)) : (hullPi κ \ κ).card = hcCombPi κ :=
  Finset.card_sdiff_of_subset (subset_hullPi κ)

/-- The per-coordinate multiplicity of a value in the relation: the number of admissible
configurations exposing `a` at part `i`. -/
def countPi (κ : Finset (∀ i, X i)) (i : ι) (a : X i) : ℕ :=
  (κ.filter (fun f => f i = a)).card

omit [Fintype ι] [DecidableEq ι] in
/-- Exposed values have positive multiplicity. -/
lemma countPi_pos (κ : Finset (∀ i, X i)) (i : ι) {a : X i} (ha : a ∈ projPi κ i) :
    0 < countPi κ i a := by
  obtain ⟨f, hf, rfl⟩ := Finset.mem_image.mp ha
  exact Finset.card_pos.mpr ⟨f, Finset.mem_filter.mpr ⟨hf, rfl⟩⟩

end HiddenChannelCapacity
