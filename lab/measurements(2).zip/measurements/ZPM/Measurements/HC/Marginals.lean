/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Multipartite
import Mathlib.Algebra.Order.BigOperators.Group.Finset

/-!
# Marginals of multipartite ignorance structures

The sub-team marginal `projS κ S = κ.image S.restrict`: what the relation exposes over a subset
`S` of its parts. This marginal family is base structure — the cover geometry over the sub-team
lattice — that the local-to-global instruments consume. It is a presheaf over the subset lattice:
the Mathlib restriction map `Finset.restrict₂` carries the `T`-marginal onto the `S`-marginal for
`S ⊆ T` (`projS_image_restrict₂`), coordinate projections factor through marginals
(`projPi_projS`), and the rectangular hull commutes with marginalization on nonempty relations
(`hullPi_projS`): the hull is an endomorphism of the marginal presheaf, the object any Čech-type
complex over the coordinate cover is built on.

The nonemptiness in `hullPi_projS` is sharp: for the empty relation and the empty sub-team the
left side is the singleton empty function (an empty product over no parts) while the right side
is empty — a kernel-checked counterexample, found by the extension argument's failure.
-/

namespace HiddenChannelCapacity

open Finset

variable {ι : Type*} {X : ι → Type*} [∀ i, DecidableEq (X i)]

/-- The marginal of a multipartite relation over a sub-team `S`: the image under
`Finset.restrict`. -/
def projS (κ : Finset (∀ i, X i)) (S : Finset ι) : Finset (∀ i : S, X i) :=
  κ.image S.restrict

/-- Rectangularity is decidable: the hull is a computable finset. -/
instance decidableIsRectPi [Fintype ι] [DecidableEq ι] (κ : Finset (∀ i, X i)) :
    Decidable (IsRectPi κ) :=
  decidable_of_iff (κ = hullPi κ) Iff.rfl

/-- **The presheaf law**: the restriction map carries the `T`-marginal onto the `S`-marginal.
This is the compatibility any Čech-type complex over the marginal family consumes. -/
theorem projS_image_restrict₂ (κ : Finset (∀ i, X i)) {S T : Finset ι} (hST : S ⊆ T) :
    (projS κ T).image (Finset.restrict₂ hST) = projS κ S := by
  rw [projS, projS, Finset.image_image, Finset.restrict₂_comp_restrict]

/-- Coordinate projections factor through marginals: the `i`-th projection of the `S`-marginal
is the `i`-th projection of the relation, homogeneously in `Finset (X i)`. -/
theorem projPi_projS (κ : Finset (∀ i, X i)) (S : Finset ι) (i : S) :
    projPi (projS κ S) i = projPi κ ↑i := by
  rw [projPi, projS, Finset.image_image, projPi]
  rfl

/-- The restriction image of a product of nonempty factors is the product of the restricted
factors: a section over `S` extends to a global section whenever every dropped factor is
nonempty. -/
theorem piFinset_image_restrict [Fintype ι] [DecidableEq ι]
    {F : ∀ i, Finset (X i)} (hF : ∀ i, (F i).Nonempty) (S : Finset ι) :
    (Fintype.piFinset F).image S.restrict = Fintype.piFinset (fun i : S => F ↑i) := by
  classical
  ext g
  simp only [Finset.mem_image, Fintype.mem_piFinset]
  constructor
  · rintro ⟨h, hh, rfl⟩ i
    exact hh ↑i
  · intro hg
    refine ⟨fun j => if hj : j ∈ S then g ⟨j, hj⟩ else (hF j).choose, fun j => ?_, ?_⟩
    · by_cases hj : j ∈ S
      · simpa [hj] using hg ⟨j, hj⟩
      · simpa [hj] using (hF j).choose_spec
    · funext i
      simp [Finset.restrict, i.2]

/-- **The hull commutes with marginalization** on nonempty relations: marginalizing the maximal
ignorance is the maximal ignorance of the marginal. Sharp: fails for `κ = ∅`, `S = ∅`. -/
theorem hullPi_projS [Fintype ι] [DecidableEq ι]
    (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty) (S : Finset ι) :
    hullPi (projS κ S) = projS (hullPi κ) S := by
  rw [show projS (hullPi κ) S = (Fintype.piFinset (projPi κ)).image S.restrict from rfl,
    piFinset_image_restrict (F := projPi κ) (fun j => hκ.image _) S]
  unfold hullPi
  congr 1
  funext i
  exact projPi_projS κ S i

/-- **The defect is monotone along marginalization** on nonempty relations: a sub-team's hidden
channel never exceeds the team's, `hcCombPi (projS κ S) ≤ hcCombPi κ`. The monotone-grading law
of the graded signature. Sharp: fails for `κ = ∅`, `S = ∅` (the marginal of the empty relation
over no parts has defect one). Fiber counting over the restriction map: every configuration the
marginal's hull permits but its marginal forbids carries a nonempty, `κ`-free fiber of the global
hull. -/
theorem hcCombPi_projS_le [Fintype ι] [DecidableEq ι]
    (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty) (S : Finset ι) :
    hcCombPi (projS κ S) ≤ hcCombPi κ := by
  classical
  rw [hcCombPi, hcCombPi, hullPi_projS κ hκ S]
  -- fiber decompositions of the hull and of `κ` over the hull's marginal
  have hfibH : (hullPi κ).card
      = ∑ g ∈ projS (hullPi κ) S, ((hullPi κ).filter (fun f => S.restrict f = g)).card :=
    Finset.card_eq_sum_card_fiberwise (fun f hf => Finset.mem_image_of_mem _ hf)
  have hfibκ : κ.card
      = ∑ g ∈ projS (hullPi κ) S, (κ.filter (fun f => S.restrict f = g)).card :=
    Finset.card_eq_sum_card_fiberwise (fun f hf =>
      Finset.mem_image_of_mem _ (subset_hullPi κ hf))
  -- the marginal is the set of configurations with a nonempty `κ`-fiber
  have hsub : projS κ S ⊆ projS (hullPi κ) S :=
    Finset.image_subset_image (subset_hullPi κ)
  have hcardκS : (projS κ S).card
      = ∑ g ∈ projS (hullPi κ) S, (if g ∈ projS κ S then 1 else 0) := by
    rw [Finset.sum_ite_mem, Finset.inter_eq_right.mpr hsub, Finset.card_eq_sum_ones]
  -- pointwise: a permitted-but-forbidden configuration has a nonempty hull-fiber
  suffices h : (projS (hullPi κ) S).card + κ.card ≤ (hullPi κ).card + (projS κ S).card by
    omega
  calc (projS (hullPi κ) S).card + κ.card
      = ∑ g ∈ projS (hullPi κ) S,
          (1 + (κ.filter (fun f => S.restrict f = g)).card) := by
        rw [Finset.sum_add_distrib, ← Finset.card_eq_sum_ones, ← hfibκ]
    _ ≤ ∑ g ∈ projS (hullPi κ) S,
          (((hullPi κ).filter (fun f => S.restrict f = g)).card
            + (if g ∈ projS κ S then 1 else 0)) := by
        refine Finset.sum_le_sum fun g hg => ?_
        by_cases hgκ : g ∈ projS κ S
        · -- the `κ`-fiber is inside the hull-fiber
          rw [if_pos hgκ]
          have : (κ.filter (fun f => S.restrict f = g)).card
              ≤ ((hullPi κ).filter (fun f => S.restrict f = g)).card :=
            Finset.card_le_card (Finset.filter_subset_filter _ (subset_hullPi κ))
          omega
        · -- the `κ`-fiber is empty and the hull-fiber is nonempty
          rw [if_neg hgκ]
          have hκfib : (κ.filter (fun f => S.restrict f = g)).card = 0 := by
            rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
            intro f hf hrf
            exact hgκ (hrf ▸ Finset.mem_image_of_mem _ hf)
          have hHfib : 0 < ((hullPi κ).filter (fun f => S.restrict f = g)).card := by
            obtain ⟨f, hf, hrf⟩ := Finset.mem_image.mp hg
            exact Finset.card_pos.mpr ⟨f, Finset.mem_filter.mpr ⟨hf, hrf⟩⟩
          omega
    _ = (hullPi κ).card + (projS κ S).card := by
        rw [Finset.sum_add_distrib, ← hfibH, ← hcardκS]

end HiddenChannelCapacity
