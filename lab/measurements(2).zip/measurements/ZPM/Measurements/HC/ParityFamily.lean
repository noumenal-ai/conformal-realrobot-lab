/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Marginals
import ZPM.Measurements.HC.HigherObstruction
import Mathlib.Data.ZMod.Basic

/-!
# The parity family: shadow-blindness at every arity

The `n`-ary parity relation `parityRel n = {f : Fin n → ZMod 2 | ∑ f i = 0}` upgrades the
three-part witness of `HigherObstruction` to a theorem schema: for every `n ≥ 2`,

* every proper sub-team marginal is the **full** cube (`projS_parityRel`) — any partial
  assignment extends, one free coordinate absorbing the parity — hence rectangular;
* the relation itself has defect `hcCombPi (parityRel n) = 2 ^ (n - 1)` (`hcCombPi_parityRel`),
  half the hull.

So at every arity the discovered base defect is maximally out of local reach: the global defect
grows geometrically while all strict shadows report nothing (`parityRel_shadow_blind`) — base
structure no proper family of local shadows can see. The lower boundary is sharp and
kernel-witnessed: at `n = 1` the parity relation is a singleton with defect `0`, so the defect
formula genuinely requires `n ≥ 2`.
-/

namespace HiddenChannelCapacity

open Finset

/-- The `n`-ary parity relation: admissible configurations of `n` binary parts with even sum. -/
def parityRel (n : ℕ) : Finset (∀ _ : Fin n, ZMod 2) :=
  Finset.univ.filter (fun f => ∑ i, f i = 0)

/-- The three-part parity relation of `HigherObstruction` is the `n = 3` member. -/
theorem parityRel_three : parityRel 3 = parity3 := by decide

/-- **The extension engine**: any assignment on a proper sub-team extends to a parity
configuration — an index outside the sub-team absorbs the parity. -/
private lemma exists_extension {n : ℕ} (S : Finset (Fin n)) (hS : S ≠ Finset.univ)
    (g : ∀ _ : S, ZMod 2) :
    ∃ f ∈ parityRel n, S.restrict f = g := by
  classical
  obtain ⟨j₀, hj₀⟩ : ∃ j, j ∉ S := by
    by_contra h
    push Not at h
    exact hS (Finset.eq_univ_iff_forall.mpr h)
  refine ⟨fun j => if hj : j ∈ S then g ⟨j, hj⟩ else if j = j₀ then -∑ i, g i else 0, ?_, ?_⟩
  · -- the total sum vanishes: the sub-team contributes `∑ g`, the complement `-∑ g`
    rw [parityRel, Finset.mem_filter]
    refine ⟨Finset.mem_univ _, ?_⟩
    rw [← Finset.sum_add_sum_compl S]
    have h1 : (∑ j ∈ S, if hj : j ∈ S then g ⟨j, hj⟩ else if j = j₀ then -∑ i, g i else 0)
        = ∑ i : S, g i := by
      rw [← Finset.sum_coe_sort]
      exact Finset.sum_congr rfl fun i _ => dif_pos i.2
    have h2 : (∑ j ∈ Sᶜ, if hj : j ∈ S then g ⟨j, hj⟩ else if j = j₀ then -∑ i, g i else 0)
        = -∑ i : S, g i := by
      rw [Finset.sum_eq_single_of_mem j₀ (Finset.mem_compl.mpr hj₀)
        (fun j hj hne => by rw [dif_neg (Finset.mem_compl.mp hj), if_neg hne])]
      rw [dif_neg hj₀, if_pos rfl]
    rw [h1, h2, add_neg_cancel]
  · -- the restriction returns the assignment
    funext i
    simp [Finset.restrict, i.2]

/-- **Fullness of proper marginals**: the parity relation's marginal over any proper sub-team is
the full cube — every strict shadow is maximal ignorance. -/
theorem projS_parityRel {n : ℕ} (S : Finset (Fin n)) (hS : S ≠ Finset.univ) :
    projS (parityRel n) S = Finset.univ := by
  refine Finset.eq_univ_iff_forall.mpr fun g => ?_
  obtain ⟨f, hf, hrf⟩ := exists_extension S hS g
  exact hrf ▸ Finset.mem_image_of_mem _ hf

/-- The full relation is rectangular (nonempty parts). -/
lemma isRectPi_univ {ι : Type*} [Fintype ι] [DecidableEq ι] {X : ι → Type*}
    [∀ i, Fintype (X i)] [∀ i, DecidableEq (X i)] [∀ i, Nonempty (X i)] :
    IsRectPi (Finset.univ : Finset (∀ i, X i)) := by
  classical
  rw [IsRectPi, hullPi,
    show (fun i => projPi (Finset.univ : Finset (∀ i, X i)) i) = fun _ => Finset.univ from
      funext fun i => Finset.eq_univ_iff_forall.mpr fun a =>
        Finset.mem_image.mpr
          ⟨Function.update (fun j => Classical.arbitrary (X j)) i a, Finset.mem_univ _, by simp⟩,
    Fintype.piFinset_univ]

/-- Every proper sub-team marginal of the parity relation is rectangular. -/
theorem isRectPi_projS_parityRel {n : ℕ} (S : Finset (Fin n)) (hS : S ≠ Finset.univ) :
    IsRectPi (projS (parityRel n) S) := by
  rw [projS_parityRel S hS]
  exact isRectPi_univ

/-- **The parity relation has `2^(n-1)` configurations**: the restriction away from one index is
injective on parity (the dropped coordinate is determined) onto the full cube. -/
theorem card_parityRel (n : ℕ) (hn : 1 ≤ n) : (parityRel n).card = 2 ^ (n - 1) := by
  classical
  set j₀ : Fin n := ⟨0, hn⟩ with hj₀def
  set S₀ : Finset (Fin n) := Finset.univ.erase j₀ with hS₀
  have hS₀ne : S₀ ≠ Finset.univ := by
    intro h
    have hmem : j₀ ∈ S₀ := by rw [h]; exact Finset.mem_univ j₀
    rw [hS₀] at hmem
    exact Finset.notMem_erase j₀ Finset.univ hmem
  -- the sum constraint determines the erased coordinate
  have hsum : ∀ h ∈ parityRel n, h j₀ = -∑ j ∈ S₀, h j := by
    intro h hh
    have h0 : ∑ j, h j = 0 := (Finset.mem_filter.mp hh).2
    have hsplit := Finset.add_sum_erase Finset.univ h (Finset.mem_univ j₀)
    rw [h0] at hsplit
    exact eq_neg_of_add_eq_zero_left hsplit
  -- hence the restriction to the co-singleton sub-team is injective on parity
  have hinj : Set.InjOn S₀.restrict (↑(parityRel n) : Set (∀ _ : Fin n, ZMod 2)) := by
    intro f hf f' hf' hr
    funext j
    by_cases hj : j ∈ S₀
    · exact congrFun hr ⟨j, hj⟩
    · have hjj : j = j₀ := by
        by_contra hne
        exact hj (Finset.mem_erase.mpr ⟨hne, Finset.mem_univ j⟩)
      subst hjj
      rw [hsum f hf, hsum f' hf']
      congr 1
      exact Finset.sum_congr rfl fun j hj => congrFun hr ⟨j, hj⟩
  -- count through the full co-singleton marginal
  have hcard : (parityRel n).card = (projS (parityRel n) S₀).card :=
    (Finset.card_image_of_injOn hinj).symm
  rw [hcard, projS_parityRel S₀ hS₀ne, Finset.card_univ, Fintype.card_fun, ZMod.card,
    Fintype.card_coe, hS₀, Finset.card_erase_of_mem (Finset.mem_univ j₀), Finset.card_univ,
    Fintype.card_fin]

/-- For `n ≥ 2` the parity relation's hull is the full cube: every coordinate projection is
already full. -/
theorem hullPi_parityRel (n : ℕ) (hn : 2 ≤ n) : hullPi (parityRel n) = Finset.univ := by
  classical
  have hproj : ∀ i : Fin n, projPi (parityRel n) i = Finset.univ := by
    intro i
    have hSne : ({i} : Finset (Fin n)) ≠ Finset.univ := by
      intro h
      have := congrArg Finset.card h
      rw [Finset.card_singleton, Finset.card_univ, Fintype.card_fin] at this
      omega
    refine Finset.eq_univ_iff_forall.mpr fun a => ?_
    obtain ⟨f, hf, hrf⟩ := exists_extension {i} hSne (fun _ => a)
    refine Finset.mem_image.mpr ⟨f, hf, ?_⟩
    have := congrFun hrf ⟨i, Finset.mem_singleton_self i⟩
    exact this
  rw [hullPi, show (fun i => projPi (parityRel n) i) = fun _ => Finset.univ from funext hproj,
    Fintype.piFinset_univ]

/-- **The parity defect**: for `n ≥ 2`, `hcCombPi (parityRel n) = 2^(n-1)` — half the hull.
Sharp at the boundary: for `n = 1` the defect is `0`. -/
theorem hcCombPi_parityRel (n : ℕ) (hn : 2 ≤ n) : hcCombPi (parityRel n) = 2 ^ (n - 1) := by
  rw [hcCombPi, hullPi_parityRel n hn, card_parityRel n (by omega), Finset.card_univ,
    Fintype.card_fun, ZMod.card, Fintype.card_fin]
  have h : 2 ^ n = 2 ^ (n - 1) * 2 := by
    rw [← pow_succ]
    congr 1
    omega
  omega

/-- **Shadow-blindness at every arity** (the theorem schema): for every `n ≥ 2` the parity
relation's proper marginals are all rectangular while its global defect is positive. The hidden
channel is irreducibly `n`-body, at every `n`. -/
theorem parityRel_shadow_blind (n : ℕ) (hn : 2 ≤ n) :
    (∀ S : Finset (Fin n), S ≠ Finset.univ → IsRectPi (projS (parityRel n) S))
      ∧ 0 < hcCombPi (parityRel n) := by
  refine ⟨fun S hS => isRectPi_projS_parityRel S hS, ?_⟩
  rw [hcCombPi_parityRel n hn]
  exact Nat.two_pow_pos _

end HiddenChannelCapacity
