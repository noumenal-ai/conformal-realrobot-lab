/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.GrahamBridge
import ZPM.Measurements.HC.AffineEngine

/-!
# The cyclic converse: stuck cores and the cycle rung

The machine of C-ENGINE. Its object is base structure in the cover: a cover whose base geometry
resists Graham reduction contains an EAR-FREE CORE (`exists_earFree_core`), and an ear-free core
supplies witness data to the affine obstruction engine. This file builds the extraction and the
principal witness rung, the CYCLE:

given a cyclic list of distinct vertices whose consecutive pairs are each hosted by some team,
with no team hosting two distinct pairs (CLEANLINESS), the pair supports `{vᵢ, vᵢ₊₁}` sum to
`∅` over F2 — each vertex lies in exactly two pairs — while cleanliness makes every team host
at most one constraint, so `ClosedAt`/`CoherentAt` are immediate and an indicator constant
assignment is odd on the dependency. The cover's cyclic base structure then licenses the verdict:
`cycle_obstruction` exhibits a pairwise-consistent family of nonempty local relations over the
WHOLE cover that no global structure realizes.

The algebra of the cycle sum: consecutive pairs are the pointwise symmetric differences of the
vertex list against its rotation (`pair_eq_symmDiff`), `xorSumL` is a `∆`-homomorphism on
`zipWith` and is permutation-invariant, and a rotation is a permutation — so the cycle sum
telescopes to `X ∆ X = ∅`.

The remaining rungs (even and landing data, the D14 collapse) and the ladder theorem — every
ear-free core admits one of the three data — arrive with the blocked-case tick
(CYCLIC_CONVERSE_URS D23); `cycle_obstruction` is the rung the B-cycle existence theorem
(URS D20) targets.
-/

namespace HiddenChannelCapacity

open Finset
open scoped symmDiff

variable {ι : Type*} [DecidableEq ι]

/-! ### Stuck cores -/

/-- An ear-free nonempty cover: the stuck core condition. -/
def EarFree (𝒞 : Finset (Finset ι)) : Prop :=
  𝒞.Nonempty ∧ ∀ T ∈ 𝒞, ¬ IsEarOf 𝒞 T

instance (𝒞 : Finset (Finset ι)) : Decidable (EarFree 𝒞) := by
  unfold EarFree
  infer_instance

/-- **Extraction**: a cover that Graham reduction cannot empty contains an ear-free core. -/
theorem exists_earFree_core (𝒞 : Finset (Finset ι)) :
    ¬ GrahamReducible 𝒞 → ∃ 𝒞' ⊆ 𝒞, EarFree 𝒞' := by
  induction 𝒞 using Finset.strongInductionOn with
  | _ 𝒞 ih =>
    intro h
    have hne : 𝒞.Nonempty := by
      rcases 𝒞.eq_empty_or_nonempty with rfl | hne
      · exact absurd (show GrahamReducible (∅ : Finset (Finset ι)) from rfl) h
      · exact hne
    by_cases hear : ∀ T ∈ 𝒞, ¬ IsEarOf 𝒞 T
    · exact ⟨𝒞, Finset.Subset.refl 𝒞, hne, hear⟩
    · simp only [not_forall, not_not] at hear
      obtain ⟨T, hT, hearT⟩ := hear
      have hrec : ¬ GrahamReducible (𝒞.erase T) := by
        intro hred
        apply h
        have hcard : 𝒞.card = (𝒞.erase T).card + 1 := by
          rw [Finset.card_erase_of_mem hT]
          have : 1 ≤ 𝒞.card := Finset.card_pos.mpr ⟨T, hT⟩
          omega
        rw [GrahamReducible, hcard]
        exact Or.inr ⟨T, hT, hearT, hred⟩
      obtain ⟨𝒞', hsub, hef⟩ := ih (𝒞.erase T) (Finset.erase_ssubset hT) hrec
      exact ⟨𝒞', hsub.trans (Finset.erase_subset T 𝒞), hef⟩

/-! ### Cycle pairs and their F2 algebra -/

/-- The consecutive-pair supports of a cyclic vertex list. -/
def cyclePairs (l : List ι) : List (Finset ι) :=
  l.zipWith (fun a b => ({a, b} : Finset ι)) (l.rotate 1)

@[simp] lemma length_cyclePairs (l : List ι) : (cyclePairs l).length = l.length := by
  rw [cyclePairs, List.length_zipWith, List.length_rotate, min_self]

private lemma pair_eq_symmDiff {a b : ι} (h : a ≠ b) :
    ({a, b} : Finset ι) = ({a} : Finset ι) ∆ ({b} : Finset ι) := by
  ext j
  by_cases hja : j = a <;> by_cases hjb : j = b <;>
    simp [Finset.mem_symmDiff, hja, hjb, h, h.symm]

private lemma xorSumL_zipWith_symmDiff :
    ∀ (l₁ l₂ : List (Finset ι)), l₁.length = l₂.length →
      xorSumL (l₁.zipWith (· ∆ ·) l₂) = xorSumL l₁ ∆ xorSumL l₂
  | [], [], _ => by
    rw [List.zipWith_nil_right, xorSumL_nil, symmDiff_empty]
  | [], _ :: _, h => by simp at h
  | _ :: _, [], h => by simp at h
  | a :: l₁, b :: l₂, h => by
    rw [List.zipWith_cons_cons, xorSumL_cons, xorSumL_cons, xorSumL_cons,
      xorSumL_zipWith_symmDiff l₁ l₂ (by simpa using h),
      symmDiff_assoc a b, ← symmDiff_assoc b (xorSumL l₁),
      symmDiff_comm b (xorSumL l₁), symmDiff_assoc (xorSumL l₁),
      ← symmDiff_assoc a]

private lemma xorSumL_perm : ∀ {l₁ l₂ : List (Finset ι)}, l₁.Perm l₂ →
    xorSumL l₁ = xorSumL l₂ := by
  intro l₁ l₂ h
  induction h with
  | nil => rfl
  | cons x _ ih => rw [xorSumL_cons, xorSumL_cons, ih]
  | swap x y l =>
    rw [xorSumL_cons, xorSumL_cons, xorSumL_cons, xorSumL_cons,
      ← symmDiff_assoc, symmDiff_comm y x, symmDiff_assoc]
  | trans _ _ ih₁ ih₂ => rw [ih₁, ih₂]

lemma mod_succ_cases (n i : ℕ) (hi : i < n) :
    (i + 1) % n = i + 1 ∧ i + 1 < n ∨ (i + 1) % n = 0 ∧ i + 1 = n := by
  rcases Nat.lt_or_ge (i + 1) n with hlt | hge
  · exact Or.inl ⟨Nat.mod_eq_of_lt hlt, hlt⟩
  · have h : i + 1 = n := by omega
    exact Or.inr ⟨by rw [h, Nat.mod_self], h⟩

omit [DecidableEq ι] in
private lemma getElem_ne_next (l : List ι) (hl : l.Nodup) (h2 : 2 ≤ l.length) (i : ℕ)
    (hi : i < l.length) :
    l[i] ≠ l[(i + 1) % l.length]'(Nat.mod_lt _ (by omega)) := by
  intro heq
  have hii := (List.Nodup.getElem_inj_iff hl).mp heq
  rcases mod_succ_cases l.length i hi with ⟨hm, hlt⟩ | ⟨hm, hin⟩ <;>
    rw [hm] at hii <;> omega

lemma getElem_cyclePairs (l : List ι) (h0 : 0 < l.length) (i : ℕ)
    (h : i < (cyclePairs l).length) :
    (cyclePairs l)[i] =
      ({l[i]'(by simpa using h), l[(i + 1) % l.length]'(Nat.mod_lt _ h0)} : Finset ι) := by
  show (l.zipWith (fun a b => ({a, b} : Finset ι)) (l.rotate 1))[i]'
      (by simpa [cyclePairs] using h) = _
  rw [List.getElem_zipWith, List.getElem_rotate]

/-- **The cycle sum telescopes**: consecutive pairs of a duplicate-free cyclic list sum to
`∅` over F2 — every vertex lies in exactly two pairs. -/
lemma xorSumL_cyclePairs (l : List ι) (hl : l.Nodup) (h2 : 2 ≤ l.length) :
    xorSumL (cyclePairs l) = ∅ := by
  have h0 : 0 < l.length := by omega
  have hpt : cyclePairs l =
      (l.map ({·} : ι → Finset ι)).zipWith (· ∆ ·)
        ((l.rotate 1).map ({·} : ι → Finset ι)) := by
    apply List.ext_getElem (by simp)
    intro i h₁ h₂
    rw [getElem_cyclePairs l h0 i h₁, List.getElem_zipWith, List.getElem_map,
      List.getElem_map, List.getElem_rotate]
    exact pair_eq_symmDiff (getElem_ne_next l hl h2 i (by simpa using h₁))
  rw [hpt, xorSumL_zipWith_symmDiff _ _ (by simp),
    xorSumL_perm (((l.rotate_perm 1)).map ({·} : ι → Finset ι)),
    symmDiff_self, bot_eq_empty]

/-- Members of the cycle-pair list are nonempty. -/
lemma cyclePairs_ne_empty {l : List ι} (h0 : 0 < l.length)
    {w : Finset ι} (hw : w ∈ cyclePairs l) : w ≠ ∅ := by
  obtain ⟨i, hi, rfl⟩ := List.mem_iff_getElem.mp hw
  rw [getElem_cyclePairs l h0 i hi]
  exact (Finset.insert_nonempty _ _).ne_empty

/-- Distinct positions carry distinct pairs: the pair list is duplicate-free. -/
lemma nodup_cyclePairs (l : List ι) (hl : l.Nodup) (h3 : 3 ≤ l.length) :
    (cyclePairs l).Nodup := by
  have h0 : 0 < l.length := by omega
  rw [List.Nodup, List.pairwise_iff_getElem]
  intro i j hi hj hij
  simp only [length_cyclePairs] at hi hj
  intro heq
  rw [getElem_cyclePairs l h0 i (by simpa using hi),
    getElem_cyclePairs l h0 j (by simpa using hj)] at heq
  have inj : ∀ {a b : ℕ} {ha : a < l.length} {hb : b < l.length},
      l[a]'ha = l[b]'hb → a = b :=
    fun h => (List.Nodup.getElem_inj_iff hl).mp h
  have h1 : l[i] ∈ ({l[j], l[(j + 1) % l.length]'(Nat.mod_lt _ h0)} : Finset ι) := by
    rw [← heq]
    exact Finset.mem_insert_self _ _
  have h2 : l[(i + 1) % l.length]'(Nat.mod_lt _ h0) ∈
      ({l[j], l[(j + 1) % l.length]'(Nat.mod_lt _ h0)} : Finset ι) := by
    rw [← heq]
    exact Finset.mem_insert_of_mem (Finset.mem_singleton_self _)
  simp only [Finset.mem_insert, Finset.mem_singleton] at h1 h2
  rcases mod_succ_cases l.length i hi with ⟨hmi, hi'⟩ | ⟨hmi, hi'⟩ <;>
    rcases mod_succ_cases l.length j hj with ⟨hmj, hj'⟩ | ⟨hmj, hj'⟩ <;>
    rcases h1 with h1 | h1 <;> rcases h2 with h2 | h2 <;>
    · have e1 := inj h1
      have e2 := inj h2
      omega

/-! ### The clean-system obstruction and its rungs -/

/-- **The clean-system obstruction**, the unified consumption theorem of C-ENGINE: a base-side
clean system (a nonempty hosted family of distinct nonempty supports with vanishing F2 sum, no
team hosting two) licenses a verdict on local measurement, a pairwise-consistent family of
nonempty local relations over the whole cover that no global structure realizes. Every witness
rung (chordless cycles, even boundary data, landings, the `H_k` clique parities) differs only as
a FINDER of such a base system. -/
theorem clean_system_obstruction [Fintype ι] (𝒞 : Finset (Finset ι))
    (𝒲 : Finset (Finset ι)) (hne𝒲 : 𝒲.Nonempty)
    (hmem : ∀ w ∈ 𝒲, w ≠ ∅)
    (hhost : ∀ w ∈ 𝒲, ∃ V ∈ 𝒞, w ⊆ V)
    (hclean : ∀ V ∈ 𝒞, ∀ w₁ ∈ 𝒲, ∀ w₂ ∈ 𝒲, w₁ ⊆ V → w₂ ⊆ V → w₁ = w₂)
    (hΔ : xorSum 𝒲 = ∅) :
    ∃ fam : List (LocalStruct ι (fun _ => ZMod 2)),
      fam.map (·.team) = 𝒞.toList ∧ Consistent fam ∧
      (∀ L ∈ fam, L.rel.Nonempty) ∧ ¬ Glues fam := by
  classical
  obtain ⟨w₀, hw₀mem⟩ := hne𝒲
  set c : Finset ι → ZMod 2 := fun w => if w = w₀ then 1 else 0 with hc
  obtain ⟨V₀, hV₀, _⟩ := hhost w₀ hw₀mem
  have hne : 𝒞.toList ≠ [] := by
    intro hnil
    have := Finset.mem_toList.mpr hV₀
    rw [hnil] at this
    exact absurd this (List.not_mem_nil)
  have hDshape : ∀ V ∈ 𝒞.toList, ∀ D ∈ (𝒲.filter (· ⊆ V)).powerset,
      D = ∅ ∨ ∃ w ∈ 𝒲, D = {w} := by
    intro V hV D hD
    rw [Finset.mem_powerset] at hD
    rcases D.eq_empty_or_nonempty with rfl | ⟨w, hw⟩
    · exact Or.inl rfl
    · refine Or.inr ⟨w, (Finset.mem_filter.mp (hD hw)).1, ?_⟩
      apply Finset.Subset.antisymm
      · intro w' hw'
        rw [Finset.mem_singleton]
        have hf' := Finset.mem_filter.mp (hD hw')
        have hf := Finset.mem_filter.mp (hD hw)
        exact hclean V (Finset.mem_toList.mp hV) w' hf'.1 w hf.1 hf'.2 hf.2
      · intro w' hw'
        rw [Finset.mem_singleton] at hw'
        rw [hw']
        exact hw
  have hxor_single : ∀ w : Finset ι, xorSum ({w} : Finset (Finset ι)) = w := by
    intro w
    rw [xorSum, Finset.fold_singleton]
    exact symmDiff_empty w
  have hcl : ∀ V ∈ 𝒞.toList, ClosedAt 𝒲 V := by
    intro V hV D hD
    rcases hDshape V hV D hD with rfl | ⟨w, hwmem, rfl⟩
    · exact Or.inl (by rw [xorSum, Finset.fold_empty])
    · exact Or.inr (by rw [hxor_single]; exact hwmem)
  have hco : ∀ V ∈ 𝒞.toList, CoherentAt 𝒲 c V := by
    intro V hV D hD hΔ'
    rcases hDshape V hV D hD with rfl | ⟨w, hwmem, rfl⟩
    · exact Finset.sum_empty
    · exfalso
      rw [hxor_single] at hΔ'
      exact hmem w hwmem hΔ'
  have hodd : ∑ w ∈ 𝒲, c w = 1 := by
    rw [hc, Finset.sum_ite_eq' 𝒲 w₀ (fun _ => (1 : ZMod 2))]
    rw [if_pos hw₀mem]
  have hhost' : ∀ w ∈ 𝒲, ∃ V ∈ 𝒞.toList, w ⊆ V := by
    intro w hw
    obtain ⟨V, hV, hwV⟩ := hhost w hw
    exact ⟨V, Finset.mem_toList.mpr hV, hwV⟩
  obtain ⟨hcons, hnonempty, hng⟩ :=
    affine_obstruction hne hcl hco 𝒲 (Finset.Subset.refl 𝒲) hΔ hodd hhost'
  refine ⟨affFam 𝒞.toList 𝒲 c, ?_, hcons, hnonempty, hng⟩
  rw [affFam, List.map_map]
  exact List.map_id _

/-- **The cycle rung**: a clean hosted cycle (a base structure of the cover) licenses a
pairwise-consistent family that no global structure realizes; the rung the B-cycle/chordless-
cycle finders target. -/
theorem cycle_obstruction [Fintype ι] (𝒞 : Finset (Finset ι)) (l : List ι)
    (hnd : l.Nodup) (h3 : 3 ≤ l.length)
    (hhost : ∀ w ∈ cyclePairs l, ∃ V ∈ 𝒞, w ⊆ V)
    (hclean : ∀ V ∈ 𝒞, ∀ w₁ ∈ cyclePairs l, ∀ w₂ ∈ cyclePairs l,
      w₁ ⊆ V → w₂ ⊆ V → w₁ = w₂) :
    ∃ fam : List (LocalStruct ι (fun _ => ZMod 2)),
      fam.map (·.team) = 𝒞.toList ∧ Consistent fam ∧
      (∀ L ∈ fam, L.rel.Nonempty) ∧ ¬ Glues fam := by
  have hlen0 : cyclePairs l ≠ [] := by
    intro hnil
    have hl := length_cyclePairs l
    rw [hnil] at hl
    simp at hl
    omega
  refine clean_system_obstruction 𝒞 (cyclePairs l).toFinset
    ⟨(cyclePairs l).head hlen0, List.mem_toFinset.mpr (List.head_mem hlen0)⟩ ?_ ?_ ?_ ?_
  · intro w hw
    exact cyclePairs_ne_empty (l := l) (by omega) (List.mem_toFinset.mp hw)
  · intro w hw
    exact hhost w (List.mem_toFinset.mp hw)
  · intro V hV w₁ hw₁ w₂ hw₂
    exact hclean V hV w₁ (List.mem_toFinset.mp hw₁) w₂ (List.mem_toFinset.mp hw₂)
  · rw [← xorSumL_eq_xorSum (nodup_cyclePairs l hnd h3)]
    exact xorSumL_cyclePairs l hnd (by omega)

end HiddenChannelCapacity
