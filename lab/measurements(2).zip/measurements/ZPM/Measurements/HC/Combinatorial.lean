/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Finset.Image
import Mathlib.Data.Finset.Filter

/-!
# Hidden Channel Capacity — combinatorial support layer

The finite, support-level instance of HC: the base stratum of the fibration,
measured directly. A `κ`-specification is a `Finset (α × β)` of admissible pairs
over a left component `α` and a right component `β`. We define:

* `projL`, `projR` — the marginal supports;
* `IsRect` — `κ` factors as the product of its marginals (fiber-product
  surjectivity at support level);
* `hcComb` — the **combinatorial defect** `|projL ×ˢ projR| − |κ|`, the
  support-level hidden channel capacity (a fully decidable `ℕ`; the
  monograph's combinatorial proxy `HCcomb`);
* `restrictL`, `restrictR` — private (row/column) and shared (selection)
  evidence operations.

The reading runs base-first: `hcComb` is discovered by inspecting the shape of
`κ` itself, and the verdict it returns (factorable, or a hidden channel of
capacity `hcComb`) is fixed by the support alone, hence invariant across every
weighting a local, distribution-side measurement could place on `κ`.

Headline results:

* `hcComb_eq_zero_iff_isRect` — the defect vanishes iff `κ` factors;
* `isRect_iff_cross_closed` — factorization iff the support is closed under
  cross-recombination (the support-level decomposability ⇔ rectangle leg of the
  Five-Way; the base-structural content of `HC = 0` made explicit);
* `isRect_of_projL_card_le_one` / `isRect_restrictL_singleton` — singleton
  private evidence resolves the coupling (monograph Thm 8.5).

All decidable; zero `sorry`. The real-valued mutual-information form
`HC(κ) = maxₛ I(P₁;P₂ ∣ S=s)` (whose vanishing coincides with `hcComb = 0` via
`ZPM.InformationTheory.MutualInformation`) is a planned extension on top of this
support skeleton.
-/

namespace HiddenChannelCapacity

variable {α β : Type*} [DecidableEq α] [DecidableEq β]

/-- Left marginal support of `κ`. -/
def projL (κ : Finset (α × β)) : Finset α := κ.image Prod.fst

/-- Right marginal support of `κ`. -/
def projR (κ : Finset (α × β)) : Finset β := κ.image Prod.snd

/-- `κ` is **rectangular**: it equals the product of its marginal supports.
At support level this is fiber-product surjectivity / decomposability. -/
def IsRect (κ : Finset (α × β)) : Prop := κ = projL κ ×ˢ projR κ

/-- The **combinatorial hidden channel capacity**: the number of admissible
configurations missing from the full product of the marginals. Zero iff `κ`
factors. -/
def hcComb (κ : Finset (α × β)) : ℕ := (projL κ ×ˢ projR κ).card - κ.card

/-- Private/shared evidence on the left component: keep only pairs whose left
coordinate lies in `keep` (row restriction in the fiber). -/
def restrictL (κ : Finset (α × β)) (keep : Finset α) : Finset (α × β) :=
  κ.filter (fun p => p.1 ∈ keep)

/-- Private/shared evidence on the right component: keep only pairs whose right
coordinate lies in `keep` (column restriction in the fiber). -/
def restrictR (κ : Finset (α × β)) (keep : Finset β) : Finset (α × β) :=
  κ.filter (fun p => p.2 ∈ keep)

/-- Every admissible pair lies in the product of the marginals. -/
theorem subset_prod (κ : Finset (α × β)) : κ ⊆ projL κ ×ˢ projR κ := by
  intro p hp
  rw [Finset.mem_product]
  exact ⟨Finset.mem_image_of_mem Prod.fst hp, Finset.mem_image_of_mem Prod.snd hp⟩

/-- The defect vanishes exactly when `κ` is rectangular (factors as a product of
its marginals). This is `HC = 0 ⇔ factorization` at the support level. -/
theorem hcComb_eq_zero_iff_isRect (κ : Finset (α × β)) :
    hcComb κ = 0 ↔ IsRect κ := by
  unfold hcComb IsRect
  have hsub : κ ⊆ projL κ ×ˢ projR κ := subset_prod κ
  have hle : κ.card ≤ (projL κ ×ˢ projR κ).card := Finset.card_le_card hsub
  constructor
  · intro h
    have hcard : (projL κ ×ˢ projR κ).card = κ.card := by omega
    exact Finset.eq_of_subset_of_card_le hsub (le_of_eq hcard)
  · intro h
    rw [← h]
    omega

/-- Rectangularity is equivalent to the support being closed under cross
recombination: if `a` and `b` are each individually admissible (in the
marginals) then the pair `(a, b)` is admissible. This is the support-level
decomposability ⇔ rectangle equivalence — the precise statement that `HC = 0`
means "no hidden coupling between the components." -/
theorem isRect_iff_cross_closed (κ : Finset (α × β)) :
    IsRect κ ↔ ∀ a ∈ projL κ, ∀ b ∈ projR κ, (a, b) ∈ κ := by
  unfold IsRect
  constructor
  · intro h a ha b hb
    rw [h, Finset.mem_product]
    exact ⟨ha, hb⟩
  · intro h
    apply Finset.Subset.antisymm (subset_prod κ)
    intro p hp
    rw [Finset.mem_product] at hp
    simpa using h p.1 hp.1 p.2 hp.2

/-- If the left marginal has at most one element, `κ` is rectangular: a single
admissible left value forces the support to be a full product. -/
theorem isRect_of_projL_card_le_one (κ : Finset (α × β))
    (h : (projL κ).card ≤ 1) : IsRect κ := by
  unfold IsRect
  apply Finset.Subset.antisymm (subset_prod κ)
  intro p hp
  rw [Finset.mem_product] at hp
  obtain ⟨hpL, hpR⟩ := hp
  rw [projR, Finset.mem_image] at hpR
  obtain ⟨q, hq, hq2⟩ := hpR
  have hq1 : q.1 ∈ projL κ := Finset.mem_image_of_mem Prod.fst hq
  have hpq1 : q.1 = p.1 := Finset.card_le_one.mp h q.1 hq1 p.1 hpL
  have hpq : p = q := by
    rw [Prod.ext_iff]; exact ⟨hpq1.symm, hq2.symm⟩
  rw [hpq]; exact hq

/-- Symmetric statement for the right marginal. -/
theorem isRect_of_projR_card_le_one (κ : Finset (α × β))
    (h : (projR κ).card ≤ 1) : IsRect κ := by
  unfold IsRect
  apply Finset.Subset.antisymm (subset_prod κ)
  intro p hp
  rw [Finset.mem_product] at hp
  obtain ⟨hpL, hpR⟩ := hp
  rw [projL, Finset.mem_image] at hpL
  obtain ⟨q, hq, hq1⟩ := hpL
  have hq2 : q.2 ∈ projR κ := Finset.mem_image_of_mem Prod.snd hq
  have hpq2 : q.2 = p.2 := Finset.card_le_one.mp h q.2 hq2 p.2 hpR
  have hpq : p = q := by
    rw [Prod.ext_iff]; exact ⟨hq1.symm, hpq2.symm⟩
  rw [hpq]; exact hq

/-- **Singleton private evidence resolves** (monograph Thm 8.5): restricting the
left component to a single value always yields a rectangular (factoring)
support — the coupling is resolved. -/
theorem isRect_restrictL_singleton (κ : Finset (α × β)) (a : α) :
    IsRect (restrictL κ {a}) := by
  apply isRect_of_projL_card_le_one
  have hsub : projL (restrictL κ {a}) ⊆ {a} := by
    intro x hx
    rw [projL, Finset.mem_image] at hx
    obtain ⟨p, hp, rfl⟩ := hx
    rw [restrictL, Finset.mem_filter] at hp
    exact hp.2
  calc (projL (restrictL κ {a})).card
      ≤ ({a} : Finset α).card := Finset.card_le_card hsub
    _ = 1 := Finset.card_singleton a

/-- Symmetric statement: singleton evidence on the right resolves the coupling. -/
theorem isRect_restrictR_singleton (κ : Finset (α × β)) (b : β) :
    IsRect (restrictR κ {b}) := by
  apply isRect_of_projR_card_le_one
  have hsub : projR (restrictR κ {b}) ⊆ {b} := by
    intro x hx
    rw [projR, Finset.mem_image] at hx
    obtain ⟨p, hp, rfl⟩ := hx
    rw [restrictR, Finset.mem_filter] at hp
    exact hp.2
  calc (projR (restrictR κ {b})).card
      ≤ ({b} : Finset β).card := Finset.card_le_card hsub
    _ = 1 := Finset.card_singleton b

/-- Corollary: singleton private evidence drives the combinatorial HC to zero. -/
theorem hcComb_restrictL_singleton (κ : Finset (α × β)) (a : α) :
    hcComb (restrictL κ {a}) = 0 :=
  (hcComb_eq_zero_iff_isRect _).mpr (isRect_restrictL_singleton κ a)

end HiddenChannelCapacity
