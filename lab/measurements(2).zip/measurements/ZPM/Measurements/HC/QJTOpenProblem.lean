/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.QJTTwoClique
import QuantumInfo.States.Entanglement

/-!
# The open problem: quantum Markov completability off chordal covers is base-decided, not local

Lauritzen–Zwiernik ("The Markov Marginal Problem for Density Operators",
arXiv:2605.19453) prove their trace criterion for two-clique and chordal clique covers
and leave general (non-chordal) covers open, noting (p. 16) that "even in the classical
situation there is no simple condition" off chordal graphs. This file resolves the
LOCALITY form of that open problem in the kernel by reading it base-first. The non-chordal
4-cycle cover's geometry licenses a global observable, the cycle correlation functional,
that no local end (full local supports, pairwise consistency, Markovness, quantization, any
proper subcover, any volume of data) can emulate, and that base observable alone decides
completability. Because it is a base-side quantity it descends identically to the
distributional and quantum strata, so this is not a quantum counterexample but a
base-geometry phenomenon whose quantum shadow settles the open question. The construction:

* **The quantization arrow** (`MState.diagDist`, `diagDist_ptraceS`,
  `completionQ_diag_iff`): the diagonal embedding `MState.ofClassical` and the diagonal
  retraction `diagDist` commute with the ONE marginal presheaf (`ptraceS` over the
  subset lattice) in both directions, so a family of classically-embedded prescriptions
  admits a quantum completion iff it admits a classical one. The base structure is
  quantization-invariant: the possibilistic capstone
  (`acyclic_iff_forall_consistent_glues`), the distributional layer, and the quantum
  marginal problem are one phenomenon read at three strata, not a parallel.
* **The support-obstruction lift** (`no_completionC_of_empty_join`): when the base
  stratum itself is obstructed (the possibilistic join is empty), that base obstruction
  kills every distributional and quantum weighting supported over it. This is base-side
  sufficiency along the fibration `F : measures → supports` of `Theory.md` §4: an
  obstruction in the base forces failure in every fibre.
* **The information-level witness** (`edgeDist`, at smoothing `r = 7/8`): the sharper
  case, where even the base-stratum possibilistic obstruction is absent. The local ends
  have FULL support (so the support-stratum obstruction vanishes identically) and are
  pairwise consistent, every proper subfamily is completable, yet the family admits NO
  global classical or quantum completion (`cycleFam_not_completableC/Q`). The deciding
  quantity is the base's cycle correlation functional: the PR box's parity class
  (`prBox_no_global_section`, the `r = 1` degeneration) is the same base class DESCENDED
  from the support stratum to the information stratum.
* **The locality resolution** (`qjt_not_local`, `subcover_markov_completable`): a
  witness family on the non-chordal 4-cycle for which every local end passes (full
  support, pairwise consistency, and strictly positive, classically Markov, quantum
  Markov completions of every proper subcover) while the base observable forbids any
  global completion. Completability off chordal covers is therefore a base-side quantity
  disjoint from all local data, and any sufficient locality criterion for the
  Lauritzen–Zwiernik completion problem whose hypotheses are implied by those local
  passes is thereby refuted.

Claim discipline (QJT_URS honesty rows): the witness mathematics (cycle marginal
polytope, cut inequality) is classical; LZ Theorem 3.1 is their theorem, mechanized in
`QJTTwoClique.lean`. The new objects here are the machine-checked base-geometry resolution
of the locality question, the quantization-invariance arrow, and the two-sided base/local
(support/information) independence.
-/

open scoped HermitianMat RealInnerProductSpace ComplexOrder Matrix

/-! ### The diagonal retraction (the functor's second leg) -/

namespace MState

variable {d : Type*} [Fintype d] [DecidableEq d]

/-- The diagonal distribution of a state: the classical shadow `x ↦ Re ω(x,x)`.
Together with the embedding `MState.ofClassical` (QuantumInfo) this forms the
quantization arrow; the two naturality squares are `ptraceS_ofClassical`
(QuantumMarginal.lean) and `diagDist_ptraceS` below. -/
noncomputable def diagDist (ω : MState d) : ProbDistribution d :=
  ProbDistribution.mk' (fun x => (ω.m x x).re)
    (fun x => by
      have h := (HermitianMat.zero_le_iff.mp ω.nonneg).diag_nonneg (i := x)
      exact (Complex.le_def.mp h).1)
    (by
      have htr : (ω.m.trace).re = 1 := by
        have h1 : ω.M.trace = 1 := ω.tr
        rw [HermitianMat.trace_eq_re_trace] at h1
        exact h1
      calc ∑ x, (ω.m x x).re = (∑ x, ω.m x x).re := by
            rw [Complex.re_sum]
        _ = (ω.m.trace).re := rfl
        _ = 1 := htr)

@[simp] lemma diagDist_coe (ω : MState d) (x : d) :
    ((ω.diagDist x : ℝ)) = (ω.m x x).re :=
  rfl

/-- Retraction: the diagonal distribution of a classical embedding is the original
distribution. -/
lemma diagDist_ofClassical (p : ProbDistribution d) :
    (MState.ofClassical p).diagDist = p := by
  refine ProbDistribution.ext fun x => ?_
  apply Subtype.ext
  show ((MState.ofClassical p).m x x).re = (p x : ℝ)
  rw [show (MState.ofClassical p).m = Matrix.diagonal (fun y => ((p y : ℝ) : ℂ)) from by
    rw [show (MState.ofClassical p).m = (MState.ofClassical p).M.mat from rfl,
      MState.coe_ofClassical, HermitianMat.diagonal_mat]
    rfl]
  rw [Matrix.diagonal_apply_eq]
  exact Complex.ofReal_re _

end MState

namespace HiddenChannelCapacity

variable {ι : Type*} [DecidableEq ι] {X : ι → Type*}
  [∀ i, Fintype (X i)] [∀ i, DecidableEq (X i)]

/-- Summing over the fiber of `Finset.restrict` is summing over the complement
coordinates (replica of the QJTTwoClique-private helper; kept private here too). -/
private lemma sum_fiber_restrict' [Fintype ι] {M : Type*} [AddCommMonoid M]
    (S : Finset ι) (g : ∀ i : S, X i) (F : (∀ i, X i) → M) :
    ∑ f ∈ Finset.univ.filter (fun f => S.restrict f = g), F f
      = ∑ w : ∀ i : {x // ¬x ∈ S}, X i,
          F ((Equiv.piEquivPiSubtypeProd (· ∈ S) X).symm (g, w)) := by
  refine Finset.sum_nbij' (i := fun f => fun i => f i)
    (j := fun w => (Equiv.piEquivPiSubtypeProd (· ∈ S) X).symm (g, w))
    (fun f _ => Finset.mem_univ _) ?_ ?_ ?_ ?_
  · intro w _
    rw [Finset.mem_filter]
    refine ⟨Finset.mem_univ _, funext fun i => ?_⟩
    show (Equiv.piEquivPiSubtypeProd (· ∈ S) X).symm (g, w) i = g i
    rw [Equiv.piEquivPiSubtypeProd_symm_apply, dif_pos i.2]
  · intro f hf
    have hres : S.restrict f = g := (Finset.mem_filter.mp hf).2
    funext i
    rw [Equiv.piEquivPiSubtypeProd_symm_apply]
    by_cases hi : (i : ι) ∈ S
    · rw [dif_pos hi]
      exact (congrFun hres ⟨i, hi⟩).symm
    · rw [dif_neg hi]
  · intro w _
    funext i
    show (Equiv.piEquivPiSubtypeProd (· ∈ S) X).symm (g, w) i = w i
    rw [Equiv.piEquivPiSubtypeProd_symm_apply, dif_neg i.2]
  · intro f hf
    have hres : S.restrict f = g := (Finset.mem_filter.mp hf).2
    refine congrArg F (funext fun i => ?_)
    rw [Equiv.piEquivPiSubtypeProd_symm_apply]
    by_cases hi : (i : ι) ∈ S
    · rw [dif_pos hi]
      exact congrFun hres ⟨i, hi⟩
    · rw [dif_neg hi]

/-- **The second naturality square**: the diagonal retraction commutes with the
marginal presheaf, `diagDist ∘ ptraceS = marginal ∘ diagDist`. With
`ptraceS_ofClassical` this completes the quantization arrow. -/
theorem diagDist_ptraceS [Fintype ι] (ω : MState (∀ i, X i)) (S : Finset ι) :
    (ptraceS ω S).diagDist = ω.diagDist.marginal S := by
  refine ProbDistribution.ext fun g => ?_
  apply Subtype.ext
  show ((ptraceS ω S).m g g).re = ((ω.diagDist.marginal S) g : ℝ)
  rw [ProbDistribution.marginal_coe,
    sum_fiber_restrict' S g (fun f => ((ω.diagDist) f : ℝ))]
  simp only [MState.diagDist_coe]
  rw [show (ptraceS ω S).m g g
      = ∑ w : ∀ i : {x // ¬x ∈ S}, X i,
          ω.m ((Equiv.piEquivPiSubtypeProd (· ∈ S) X).symm (g, w))
            ((Equiv.piEquivPiSubtypeProd (· ∈ S) X).symm (g, w)) from rfl,
    Complex.re_sum]

/-! ### Completion predicates and the transport theorem -/

variable {J : Type*}

/-- A classical completion of a prescription family over a cover (the distributional
`M(R)` membership, LZ p. 7 read classically). -/
def IsCompletionC [Fintype ι] (team : J → Finset ι)
    (p : ∀ j, ProbDistribution (∀ i : (team j : Finset ι), X i))
    (q : ProbDistribution (∀ i, X i)) : Prop :=
  ∀ j, q.marginal (team j) = p j

/-- A quantum completion of a family of prescribed marginals (LZ `M(R)`, p. 7,
team-indexed). -/
def IsCompletionQ [Fintype ι] (team : J → Finset ι)
    (ρ : ∀ j, MState (∀ i : (team j : Finset ι), X i))
    (ω : MState (∀ i, X i)) : Prop :=
  ∀ j, ptraceS ω (team j) = ρ j

/-- **The transport theorem (quantization invariance)**: the base structure is
quantization-invariant, so a family of classically-embedded prescriptions admits a quantum
completion iff it admits a classical one, on ANY cover at ANY arity. The possibilistic
capstone and the quantum marginal problem are the same base phenomenon read at two strata,
identified by the arrow. -/
theorem completionQ_diag_iff [Fintype ι] (team : J → Finset ι)
    (p : ∀ j, ProbDistribution (∀ i : (team j : Finset ι), X i)) :
    (∃ ω, IsCompletionQ team (fun j => MState.ofClassical (p j)) ω)
      ↔ (∃ q, IsCompletionC team p q) := by
  constructor
  · rintro ⟨ω, hω⟩
    refine ⟨ω.diagDist, fun j => ?_⟩
    rw [← diagDist_ptraceS, hω j, MState.diagDist_ofClassical]
  · rintro ⟨q, hq⟩
    exact ⟨MState.ofClassical q, fun j => by rw [ptraceS_ofClassical, hq j]⟩

/-- Distributions have a point of positive mass. -/
private lemma exists_pos_mass {d : Type*} [Fintype d] [DecidableEq d]
    (q : ProbDistribution d) : ∃ x, 0 < (q x : ℝ) := by
  by_contra h
  have h' : ∀ x, ¬ 0 < (q x : ℝ) := fun x hx => h ⟨x, hx⟩
  have hzero : ∀ x, (q x : ℝ) = 0 := fun x =>
    le_antisymm (not_lt.mp (h' x)) Prob.zero_le_coe
  have hsum : ∑ x, (q x : ℝ) = 1 := q.normalized
  rw [Finset.sum_congr rfl fun x _ => hzero x] at hsum
  simp at hsum

/-- **The support-obstruction lift**: if no global configuration is admissible for the
supports (the possibilistic join is empty), then NO classical completion exists — and
hence, via the transport theorem, no quantum one. Obstructions at the base of the
fibration `F : measures → supports` (Theory.md §4) kill every fibre. -/
theorem no_completionC_of_empty_join [Fintype ι] (team : J → Finset ι)
    (p : ∀ j, ProbDistribution (∀ i : (team j : Finset ι), X i))
    (hjoin : ∀ x : (∀ i, X i), ∃ j, ((p j) ((team j).restrict x) : ℝ) = 0) :
    ¬ ∃ q, IsCompletionC team p q := by
  rintro ⟨q, hq⟩
  obtain ⟨x, hx⟩ := exists_pos_mass q
  obtain ⟨j, hj⟩ := hjoin x
  have hmarg : 0 < ((q.marginal (team j)) ((team j).restrict x) : ℝ) := by
    rw [ProbDistribution.marginal_coe]
    refine lt_of_lt_of_le hx ?_
    refine Finset.single_le_sum (f := fun f => ((q f : ℝ)))
      (fun f _ => Prob.zero_le_coe) ?_
    rw [Finset.mem_filter]
    exact ⟨Finset.mem_univ _, rfl⟩
  rw [hq j, hj] at hmarg
  exact lt_irrefl _ hmarg

end HiddenChannelCapacity

/-! ### The 4-cycle witness: the smoothed parity family

The base is the fixed 4-cycle cover; what varies is only the local weighting placed on it.
Sites `Fin 4` with `ZMod 2` values; teams the cycle edges `{j, j+1}`; the local prescription
on edge `j` puts mass `r/2` on each parity-`tw j` pair and `(1−r)/2` on the others,
with the single twist `tw 3 = 1` (the smoothed PR box: at `r = 1` the local relations are
the banked `prRel` parities of `PRBox.lean`). All computations are symbolic in `r` except
the final threshold, taken at `r = 7/8`. -/

namespace HiddenChannelCapacity

/-- The cycle edge teams. -/
def cyc (j : Fin 4) : Finset (Fin 4) := {j, j + 1}

lemma cyc_ne (j : Fin 4) : j ≠ j + 1 := by
  fin_cases j <;> decide

lemma mem_cyc_left (j : Fin 4) : j ∈ cyc j := by
  simp [cyc]

lemma mem_cyc_right (j : Fin 4) : j + 1 ∈ cyc j := by
  simp [cyc]

/-- The two-point chart of an edge team. -/
def pairEquiv (j : Fin 4) :
    (∀ _i : (cyc j : Finset (Fin 4)), ZMod 2) ≃ ZMod 2 × ZMod 2 where
  toFun g := (g ⟨j, mem_cyc_left j⟩, g ⟨j + 1, mem_cyc_right j⟩)
  invFun ab := fun i => if (i : Fin 4) = j then ab.1 else ab.2
  left_inv g := by
    funext i
    rcases Finset.mem_insert.mp i.2 with h | h
    · show (if (i : Fin 4) = j then g ⟨j, mem_cyc_left j⟩
        else g ⟨j + 1, mem_cyc_right j⟩) = g i
      rw [if_pos h]
      congr 1
      exact Subtype.ext h.symm
    · have hij : (i : Fin 4) = j + 1 := Finset.mem_singleton.mp h
      show (if (i : Fin 4) = j then g ⟨j, mem_cyc_left j⟩
        else g ⟨j + 1, mem_cyc_right j⟩) = g i
      rw [if_neg (by rw [hij]; exact (cyc_ne j).symm)]
      congr 1
      exact Subtype.ext hij.symm
  right_inv ab := by
    refine Prod.ext ?_ ?_
    · simp
    · simp [(cyc_ne j).symm]

/-- Enumerating a `ZMod 2` sum. -/
lemma sum_zmod2 {M : Type*} [AddCommMonoid M] (f : ZMod 2 → M) :
    ∑ x, f x = f 0 + f 1 := by
  rw [show (Finset.univ : Finset (ZMod 2)) = {0, 1} from by decide,
    Finset.sum_insert (by decide), Finset.sum_singleton]

/-- The twist pattern: one anticorrelated edge. -/
def tw : Fin 4 → ZMod 2 := ![0, 0, 0, 1]

/-- The smoothed parity prescription on edge `j` (mass function; `edgeDist` wraps it).
At `r = 1` its support degenerates to the possibilistic `prRel` parity of PRBox.lean. -/
noncomputable def edgeMass (r : ℝ) (t : ZMod 2) {j : Fin 4}
    (g : ∀ _i : (cyc j : Finset (Fin 4)), ZMod 2) : ℝ :=
  if (pairEquiv j g).1 + (pairEquiv j g).2 = t then r / 2 else (1 - r) / 2

lemma edgeMass_nonneg {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (t : ZMod 2)
    {j : Fin 4} (g : ∀ _i : (cyc j : Finset (Fin 4)), ZMod 2) :
    0 ≤ edgeMass r t g := by
  unfold edgeMass
  split_ifs <;> linarith

lemma edgeMass_sum {r : ℝ} (t : ZMod 2) (j : Fin 4) :
    ∑ g : (∀ _i : (cyc j : Finset (Fin 4)), ZMod 2), edgeMass r t g = 1 := by
  rw [← Equiv.sum_comp (pairEquiv j).symm (edgeMass r t)]
  have hcomp : ∀ ab : ZMod 2 × ZMod 2,
      edgeMass r t ((pairEquiv j).symm ab)
        = if ab.1 + ab.2 = t then r / 2 else (1 - r) / 2 := by
    intro ab
    unfold edgeMass
    rw [Equiv.apply_symm_apply]
  rw [Finset.sum_congr rfl fun ab _ => hcomp ab, Fintype.sum_prod_type]
  have hinner : ∀ a : ZMod 2,
      (∑ b, if a + b = t then r / 2 else (1 - r) / 2) = 1 / 2 := by
    intro a
    rw [sum_zmod2 (fun b => if a + b = t then r / 2 else (1 - r) / 2)]
    by_cases h : a + 0 = t
    · rw [if_pos h, if_neg fun h1 => absurd (add_left_cancel (h1.trans h.symm))
        (by decide)]
      ring
    · rw [if_neg h,
        if_pos ((by decide : ∀ a t : ZMod 2, ¬(a + 0 = t) → a + 1 = t) a t h)]
      ring
  rw [Finset.sum_congr rfl fun a _ => hinner a, sum_zmod2 (fun _ => (1 : ℝ) / 2)]
  ring

/-- The smoothed parity prescription on edge `j`, as a distribution. -/
noncomputable def edgeDist (r : ℝ) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (j : Fin 4) :
    ProbDistribution (∀ _i : (cyc j : Finset (Fin 4)), ZMod 2) :=
  ProbDistribution.mk' (edgeMass r (tw j))
    (fun g => edgeMass_nonneg hr0 hr1 (tw j) g)
    (edgeMass_sum (tw j) j)

@[simp] lemma edgeDist_coe (r : ℝ) (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (j : Fin 4)
    (g : ∀ _i : (cyc j : Finset (Fin 4)), ZMod 2) :
    ((edgeDist r hr0 hr1 j) g : ℝ) = edgeMass r (tw j) g :=
  rfl

/-- **Full support**: for `0 < r < 1` every configuration of every edge has positive
mass, so the local ends impose no possibilistic constraint at all. The base-stratum
(support) obstruction of the PR box VANISHES on the smoothed family, leaving the base's
finer global observable as the only thing that can decide completability. -/
theorem edgeDist_full_support {r : ℝ} (hr0 : 0 < r) (hr1 : r < 1) (j : Fin 4)
    (g : ∀ _i : (cyc j : Finset (Fin 4)), ZMod 2) :
    0 < ((edgeDist r hr0.le hr1.le j) g : ℝ) := by
  rw [edgeDist_coe]
  unfold edgeMass
  split_ifs <;> linarith

end HiddenChannelCapacity

/-! ### The cycle correlation functional: the base-licensed global observable -/

namespace HiddenChannelCapacity

/-- The number of edges on which a global configuration disagrees with the twist
pattern. The sign-product contradiction: edge parities telescope to `0` around the
cycle while the twists sum to `1`, so at least one disagreement is forced. -/
def disag (x : ∀ _i : Fin 4, ZMod 2) : ℕ :=
  (Finset.univ.filter (fun j : Fin 4 => x j + x (j + 1) ≠ tw j)).card

/-- Kernel form of the sign-product contradiction: no configuration realizes all four
twisted parities. -/
lemma one_le_disag : ∀ x : (∀ _i : Fin 4, ZMod 2), 1 ≤ disag x := by
  decide

/-- The (twist-referenced) correlation of an edge distribution: mass agreeing with the
twist minus mass disagreeing. -/
noncomputable def corrE {j : Fin 4} (t : ZMod 2)
    (p : ProbDistribution (∀ _i : (cyc j : Finset (Fin 4)), ZMod 2)) : ℝ :=
  ∑ g, (p g : ℝ) * (if (pairEquiv j g).1 + (pairEquiv j g).2 = t then 1 else -1)

/-- The prescribed correlation of the smoothed edge: `2r − 1`. -/
lemma corrE_edgeDist {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (j : Fin 4) :
    corrE (tw j) (edgeDist r hr0 hr1 j) = 2 * r - 1 := by
  unfold corrE
  rw [← Equiv.sum_comp (pairEquiv j).symm
    (fun g => ((edgeDist r hr0 hr1 j) g : ℝ)
      * (if (pairEquiv j g).1 + (pairEquiv j g).2 = tw j then 1 else -1))]
  have hcomp : ∀ ab : ZMod 2 × ZMod 2,
      ((edgeDist r hr0 hr1 j) ((pairEquiv j).symm ab) : ℝ)
        * (if (pairEquiv j ((pairEquiv j).symm ab)).1
            + (pairEquiv j ((pairEquiv j).symm ab)).2 = tw j then (1:ℝ) else -1)
      = (if ab.1 + ab.2 = tw j then r / 2 else (1 - r) / 2)
        * (if ab.1 + ab.2 = tw j then (1:ℝ) else -1) := by
    intro ab
    rw [edgeDist_coe]
    unfold edgeMass
    rw [Equiv.apply_symm_apply]
  rw [Finset.sum_congr rfl fun ab _ => hcomp ab, Fintype.sum_prod_type]
  have hinner : ∀ a : ZMod 2,
      (∑ b, (if a + b = tw j then r / 2 else (1 - r) / 2)
        * (if a + b = tw j then (1:ℝ) else -1)) = r - 1 / 2 := by
    intro a
    rw [sum_zmod2 (fun b => (if a + b = tw j then r / 2 else (1 - r) / 2)
      * (if a + b = tw j then (1:ℝ) else -1))]
    by_cases h : a + 0 = tw j
    · rw [if_pos h, if_pos h, if_neg fun h1 =>
        absurd (add_left_cancel (h1.trans h.symm)) (by decide),
        if_neg fun h1 => absurd (add_left_cancel (h1.trans h.symm)) (by decide)]
      ring
    · rw [if_neg h, if_neg h,
        if_pos ((by decide : ∀ a t : ZMod 2, ¬(a + 0 = t) → a + 1 = t) a (tw j) h),
        if_pos ((by decide : ∀ a t : ZMod 2, ¬(a + 0 = t) → a + 1 = t) a (tw j) h)]
      ring
  rw [Finset.sum_congr rfl fun a _ => hinner a, sum_zmod2 (fun _ => r - (1:ℝ)/2)]
  ring

/-- Both site marginals of every smoothed edge are uniform: the family is pairwise
consistent in the LZ sense (any two edges agree on their shared site; LZ p. 7). -/
lemma edgeDist_site_uniform {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (j : Fin 4)
    (a : ZMod 2) :
    (∑ b, ((edgeDist r hr0 hr1 j) ((pairEquiv j).symm (a, b)) : ℝ)) = 1 / 2
      ∧ (∑ b, ((edgeDist r hr0 hr1 j) ((pairEquiv j).symm (b, a)) : ℝ)) = 1 / 2 := by
  constructor
  · have hval : ∀ b, ((edgeDist r hr0 hr1 j) ((pairEquiv j).symm (a, b)) : ℝ)
        = if a + b = tw j then r / 2 else (1 - r) / 2 := by
      intro b
      rw [edgeDist_coe]
      unfold edgeMass
      rw [Equiv.apply_symm_apply]
    rw [Finset.sum_congr rfl fun b _ => hval b,
      sum_zmod2 (fun b => if a + b = tw j then r / 2 else (1 - r) / 2)]
    by_cases h : a + 0 = tw j
    · rw [if_pos h, if_neg fun h1 =>
        absurd (add_left_cancel (h1.trans h.symm)) (by decide)]
      ring
    · rw [if_neg h,
        if_pos ((by decide : ∀ a t : ZMod 2, ¬(a + 0 = t) → a + 1 = t) a (tw j) h)]
      ring
  · have hval : ∀ b, ((edgeDist r hr0 hr1 j) ((pairEquiv j).symm (b, a)) : ℝ)
        = if b + a = tw j then r / 2 else (1 - r) / 2 := by
      intro b
      rw [edgeDist_coe]
      unfold edgeMass
      rw [Equiv.apply_symm_apply]
    rw [Finset.sum_congr rfl fun b _ => hval b,
      sum_zmod2 (fun b => if b + a = tw j then r / 2 else (1 - r) / 2)]
    by_cases h : (0 : ZMod 2) + a = tw j
    · rw [if_pos h, if_neg fun h1 =>
        absurd (add_right_cancel (h1.trans h.symm)) (by decide)]
      ring
    · rw [if_neg h,
        if_pos ((by decide : ∀ a t : ZMod 2, ¬((0 : ZMod 2) + a = t) → 1 + a = t)
          a (tw j) h)]
      ring

/-- Correlation pull-back: the correlation of a marginal is the expectation of the
edge sign under the global distribution. -/
lemma corrE_marginal (q : ProbDistribution (∀ _i : Fin 4, ZMod 2)) (j : Fin 4)
    (t : ZMod 2) :
    corrE t (q.marginal (cyc j))
      = ∑ x, (q x : ℝ) * (if x j + x (j + 1) = t then 1 else -1) := by
  unfold corrE
  have hsplit : ∀ g, ((q.marginal (cyc j)) g : ℝ)
      * (if (pairEquiv j g).1 + (pairEquiv j g).2 = t then (1:ℝ) else -1)
      = ∑ f ∈ Finset.univ.filter (fun f => (cyc j).restrict f = g),
          (q f : ℝ) * (if f j + f (j + 1) = t then (1:ℝ) else -1) := by
    intro g
    rw [ProbDistribution.marginal_coe, Finset.sum_mul]
    refine Finset.sum_congr rfl fun f hf => ?_
    have hres : (cyc j).restrict f = g := (Finset.mem_filter.mp hf).2
    have hpair : (pairEquiv j g).1 = f j ∧ (pairEquiv j g).2 = f (j + 1) := by
      rw [← hres]
      exact ⟨rfl, rfl⟩
    rw [hpair.1, hpair.2]
  rw [Finset.sum_congr rfl fun g _ => hsplit g]
  exact Finset.sum_fiberwise Finset.univ (fun f => (cyc j).restrict f)
    (fun f => (q f : ℝ) * (if f j + f (j + 1) = t then (1:ℝ) else -1))

/-- **The base-licensed global bound**: the base's cycle correlation functional constrains
every global distribution to the cycle correlation inequality (the cut-polytope facet of
the 4-cycle, from the pointwise sign-product contradiction `one_le_disag`). This is the
global observable the cover's geometry forces, ahead of any local weighting. -/
lemma cycle_bound (q : ProbDistribution (∀ _i : Fin 4, ZMod 2)) :
    (∑ j : Fin 4, corrE (tw j) (q.marginal (cyc j))) ≤ 2 := by
  rw [Finset.sum_congr rfl fun j _ => corrE_marginal q j (tw j), Finset.sum_comm]
  have hpt : ∀ x : (∀ _i : Fin 4, ZMod 2),
      (∑ j : Fin 4, (q x : ℝ) * (if x j + x (j + 1) = tw j then 1 else -1))
        ≤ (q x : ℝ) * 2 := by
    intro x
    rw [← Finset.mul_sum]
    refine mul_le_mul_of_nonneg_left ?_ Prob.zero_le_coe
    have hsum : (∑ j : Fin 4, (if x j + x (j + 1) = tw j then (1:ℝ) else -1))
        = 4 - 2 * (disag x : ℝ) := by
      have hterm : ∀ j : Fin 4, (if x j + x (j + 1) = tw j then (1:ℝ) else -1)
          = 1 - 2 * (if x j + x (j + 1) ≠ tw j then (1:ℝ) else 0) := by
        intro j
        by_cases h : x j + x (j + 1) = tw j
        · rw [if_pos h, if_neg (by simpa using h)]
          ring
        · rw [if_neg h, if_pos h]
          ring
      rw [Finset.sum_congr rfl fun j _ => hterm j, Finset.sum_sub_distrib,
        ← Finset.mul_sum]
      have hcard : (∑ j : Fin 4, (if x j + x (j + 1) ≠ tw j then (1:ℝ) else 0))
          = (disag x : ℝ) := by
        rw [disag, Finset.card_filter]
        push_cast
        rfl
      rw [hcard]
      simp
    rw [hsum]
    have := one_le_disag x
    have h1 : (1 : ℝ) ≤ (disag x : ℝ) := by exact_mod_cast this
    linarith
  calc ∑ x, ∑ j : Fin 4, (q x : ℝ) * (if x j + x (j + 1) = tw j then 1 else -1)
      ≤ ∑ x, (q x : ℝ) * 2 := Finset.sum_le_sum fun x _ => hpt x
    _ = 2 := by
        rw [← Finset.sum_mul, q.normalized, one_mul]

/-- **The information-level obstruction (the open-problem core)**: at smoothing
`r = 7/8` the base's cycle correlation functional already forbids completion, and no local
end can emulate it. The family is strictly positive everywhere (full-support local ends, so
the base-stratum possibilistic obstruction VANISHES) and pairwise consistent, yet admits NO
classical completion, because the prescribed correlation sum is `4(2r − 1) = 3 > 2`. -/
theorem cycleFam_not_completableC :
    ¬ ∃ q, IsCompletionC (X := fun _ => ZMod 2) cyc
      (fun j => edgeDist (7/8) (by norm_num) (by norm_num) j) q := by
  rintro ⟨q, hq⟩
  have hb := cycle_bound q
  have heq : ∀ j : Fin 4, corrE (tw j) (q.marginal (cyc j)) = 2 * (7/8) - 1 := by
    intro j
    rw [hq j]
    exact corrE_edgeDist (by norm_num) (by norm_num) j
  rw [Finset.sum_congr rfl fun j _ => heq j, Finset.sum_const, Finset.card_univ] at hb
  norm_num at hb

/-- **No quantum completion either**: the deciding quantity is a base-side observable, and
because it is quantization-invariant (the quantization arrow) it forbids the quantum
completion exactly as it forbids the classical one. This is not a quantum counterexample but
the quantum shadow of the base geometry, and it settles the locality question for the
Lauritzen–Zwiernik completion problem off chordal covers (LZ arXiv:2605.19453 p. 16 leave
general covers open). The base observable is unreachable from any local end, at the support
stratum (full supports) and above. -/
theorem cycleFam_not_completableQ :
    ¬ ∃ ω, IsCompletionQ (X := fun _ => ZMod 2) cyc
      (fun j => MState.ofClassical (edgeDist (7/8) (by norm_num) (by norm_num) j)) ω := by
  rw [completionQ_diag_iff]
  exact cycleFam_not_completableC

end HiddenChannelCapacity

/-! ### The junction-tree completions: every proper subcover is completable

Removing any edge `j₀` makes the base ACYCLIC: the remaining three edges form a path (a
junction tree), and over an acyclic base the geometry licenses base-side reconstruction. The
classical junction-tree formula (Lauritzen, *Graphical Models*, OUP 1996, §3.2.3;
LZ arXiv:2605.19453 p. 4) then completes the smoothed family on it. The engine is the
shift-sum: `∑ v, M (u + v) = 1` for the local factor `M`, eliminating free sites one
at a time. -/

namespace HiddenChannelCapacity

/-- The local edge factor: mass `r` on the twist-agreeing parity, `1 − r` otherwise.
The junction-tree numerator of `edgeMass` (which is `(1/2) · Mfun`). -/
noncomputable def Mfun (r : ℝ) (t y : ZMod 2) : ℝ := if y = t then r else 1 - r

lemma Mfun_nonneg {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (t y : ZMod 2) :
    0 ≤ Mfun r t y := by
  unfold Mfun
  split_ifs <;> linarith

lemma Mfun_pos {r : ℝ} (hr0 : 0 < r) (hr1 : r < 1) (t y : ZMod 2) :
    0 < Mfun r t y := by
  unfold Mfun
  split_ifs <;> linarith

lemma half_Mfun (r : ℝ) (t y : ZMod 2) :
    1 / 2 * Mfun r t y = if y = t then r / 2 else (1 - r) / 2 := by
  unfold Mfun
  split_ifs <;> ring

/-- The shift-sum: summing the local factor over a shifted argument gives `1`.
The one identity behind every marginal computation in this file. -/
lemma sum_Mfun_right (r : ℝ) (t u : ZMod 2) : ∑ v, Mfun r t (u + v) = 1 := by
  calc ∑ v, Mfun r t (u + v)
      = ∑ v, Mfun r t ((Equiv.addLeft u) v) := rfl
    _ = ∑ v, Mfun r t v := Equiv.sum_comp (Equiv.addLeft u) (Mfun r t)
    _ = Mfun r t 0 + Mfun r t 1 := sum_zmod2 _
    _ = 1 := by
        rcases (by decide : ∀ s : ZMod 2, s = 0 ∨ s = 1) t with h | h <;> subst h
        · rw [Mfun, Mfun, if_pos rfl, if_neg (by decide)]
          ring
        · rw [Mfun, Mfun, if_neg (by decide), if_pos rfl]
          ring

lemma sum_Mfun_left (r : ℝ) (t u : ZMod 2) : ∑ v, Mfun r t (v + u) = 1 := by
  calc ∑ v, Mfun r t (v + u)
      = ∑ v, Mfun r t ((Equiv.addRight u) v) := rfl
    _ = ∑ v, Mfun r t v := Equiv.sum_comp (Equiv.addRight u) (Mfun r t)
    _ = Mfun r t 0 + Mfun r t 1 := sum_zmod2 _
    _ = 1 := by
        rcases (by decide : ∀ s : ZMod 2, s = 0 ∨ s = 1) t with h | h <;> subst h
        · rw [Mfun, Mfun, if_pos rfl, if_neg (by decide)]
          ring
        · rw [Mfun, Mfun, if_neg (by decide), if_pos rfl]
          ring

/-! #### Evaluation charts

Coordinates on full and complement configuration spaces by evaluation at explicitly
enumerated sites, with if-chain inverses. These replace the cumulative-sum chart of the
front-load design: no characteristic-2 telescoping is needed anywhere. -/

/-- Evaluation chart on the full site space at four distinct sites. -/
def quadChart (v₁ v₂ v₃ v₄ : Fin 4)
    (h12 : v₁ ≠ v₂) (h13 : v₁ ≠ v₃) (h14 : v₁ ≠ v₄)
    (h23 : v₂ ≠ v₃) (h24 : v₂ ≠ v₄) (h34 : v₃ ≠ v₄)
    (hcov : ∀ i : Fin 4, i = v₁ ∨ i = v₂ ∨ i = v₃ ∨ i = v₄) :
    (∀ _i : Fin 4, ZMod 2) ≃ ZMod 2 × ZMod 2 × ZMod 2 × ZMod 2 where
  toFun x := (x v₁, x v₂, x v₃, x v₄)
  invFun c := fun i =>
    if i = v₁ then c.1 else if i = v₂ then c.2.1 else if i = v₃ then c.2.2.1 else c.2.2.2
  left_inv x := by
    funext i
    show (if i = v₁ then x v₁ else if i = v₂ then x v₂
      else if i = v₃ then x v₃ else x v₄) = x i
    rcases hcov i with h | h | h | h <;> subst h
    · rw [if_pos rfl]
    · rw [if_neg h12.symm, if_pos rfl]
    · rw [if_neg h13.symm, if_neg h23.symm, if_pos rfl]
    · rw [if_neg h14.symm, if_neg h24.symm, if_neg h34.symm]
  right_inv c := by
    refine Prod.ext ?_ (Prod.ext ?_ (Prod.ext ?_ ?_))
    · show (if v₁ = v₁ then c.1 else if v₁ = v₂ then c.2.1
        else if v₁ = v₃ then c.2.2.1 else c.2.2.2) = c.1
      rw [if_pos rfl]
    · show (if v₂ = v₁ then c.1 else if v₂ = v₂ then c.2.1
        else if v₂ = v₃ then c.2.2.1 else c.2.2.2) = c.2.1
      rw [if_neg h12.symm, if_pos rfl]
    · show (if v₃ = v₁ then c.1 else if v₃ = v₂ then c.2.1
        else if v₃ = v₃ then c.2.2.1 else c.2.2.2) = c.2.2.1
      rw [if_neg h13.symm, if_neg h23.symm, if_pos rfl]
    · show (if v₄ = v₁ then c.1 else if v₄ = v₂ then c.2.1
        else if v₄ = v₃ then c.2.2.1 else c.2.2.2) = c.2.2.2
      rw [if_neg h14.symm, if_neg h24.symm, if_neg h34.symm]

/-- Evaluation chart for a one-site complement. -/
def complChart1 (S : Finset (Fin 4)) (v₁ : Fin 4) (h₁ : ¬v₁ ∈ S)
    (hcov : ∀ i : Fin 4, ¬i ∈ S → i = v₁) :
    (∀ _i : {x : Fin 4 // ¬x ∈ S}, ZMod 2) ≃ ZMod 2 where
  toFun w := w ⟨v₁, h₁⟩
  invFun c := fun _ => c
  left_inv w := by
    funext i
    show w ⟨v₁, h₁⟩ = w i
    congr 1
    exact Subtype.ext (hcov i i.2).symm
  right_inv c := rfl

/-- Evaluation chart for a two-site complement. -/
def complChart2 (S : Finset (Fin 4)) (v₁ v₂ : Fin 4)
    (h₁ : ¬v₁ ∈ S) (h₂ : ¬v₂ ∈ S) (h12 : v₁ ≠ v₂)
    (hcov : ∀ i : Fin 4, ¬i ∈ S → i = v₁ ∨ i = v₂) :
    (∀ _i : {x : Fin 4 // ¬x ∈ S}, ZMod 2) ≃ ZMod 2 × ZMod 2 where
  toFun w := (w ⟨v₁, h₁⟩, w ⟨v₂, h₂⟩)
  invFun c := fun i => if (i : Fin 4) = v₁ then c.1 else c.2
  left_inv w := by
    funext i
    show (if (i : Fin 4) = v₁ then w ⟨v₁, h₁⟩ else w ⟨v₂, h₂⟩) = w i
    rcases hcov i i.2 with h | h
    · rw [if_pos h]
      congr 1
      exact Subtype.ext h.symm
    · rw [if_neg (by rw [h]; exact h12.symm)]
      congr 1
      exact Subtype.ext h.symm
  right_inv c := by
    refine Prod.ext ?_ ?_
    · show (if v₁ = v₁ then c.1 else c.2) = c.1
      rw [if_pos rfl]
    · show (if v₂ = v₁ then c.1 else c.2) = c.2
      rw [if_neg h12.symm]

/-- Evaluation chart for a three-site complement. -/
def complChart3 (S : Finset (Fin 4)) (v₁ v₂ v₃ : Fin 4)
    (h₁ : ¬v₁ ∈ S) (h₂ : ¬v₂ ∈ S) (h₃ : ¬v₃ ∈ S)
    (h12 : v₁ ≠ v₂) (h13 : v₁ ≠ v₃) (h23 : v₂ ≠ v₃)
    (hcov : ∀ i : Fin 4, ¬i ∈ S → i = v₁ ∨ i = v₂ ∨ i = v₃) :
    (∀ _i : {x : Fin 4 // ¬x ∈ S}, ZMod 2) ≃ ZMod 2 × ZMod 2 × ZMod 2 where
  toFun w := (w ⟨v₁, h₁⟩, w ⟨v₂, h₂⟩, w ⟨v₃, h₃⟩)
  invFun c := fun i =>
    if (i : Fin 4) = v₁ then c.1 else if (i : Fin 4) = v₂ then c.2.1 else c.2.2
  left_inv w := by
    funext i
    show (if (i : Fin 4) = v₁ then w ⟨v₁, h₁⟩
      else if (i : Fin 4) = v₂ then w ⟨v₂, h₂⟩ else w ⟨v₃, h₃⟩) = w i
    rcases hcov i i.2 with h | h | h
    · rw [if_pos h]
      congr 1
      exact Subtype.ext h.symm
    · rw [if_neg (by rw [h]; exact h12.symm), if_pos h]
      congr 1
      exact Subtype.ext h.symm
    · rw [if_neg (by rw [h]; exact h13.symm), if_neg (by rw [h]; exact h23.symm)]
      congr 1
      exact Subtype.ext h.symm
  right_inv c := by
    refine Prod.ext ?_ (Prod.ext ?_ ?_)
    · show (if v₁ = v₁ then c.1 else _) = c.1
      rw [if_pos rfl]
    · show (if v₂ = v₁ then c.1 else if v₂ = v₂ then c.2.1 else c.2.2) = c.2.1
      rw [if_neg h12.symm, if_pos rfl]
    · show (if v₃ = v₁ then c.1 else if v₃ = v₂ then c.2.1 else c.2.2) = c.2.2
      rw [if_neg h13.symm, if_neg h23.symm]

end HiddenChannelCapacity

namespace HiddenChannelCapacity

/-- The junction-tree mass for the path obtained by removing edge `j₀` from the cycle:
`(1/2) · ∏` of the local factors of the three remaining edges (Lauritzen, *Graphical
Models*, OUP 1996, §3.2.3: product of clique marginals over separator marginals; here
every separator is a uniform site with mass `1/2`, giving the `(1/2) · M·M·M` form). -/
noncomputable def pathMass (r : ℝ) (j₀ : Fin 4) (x : ∀ _i : Fin 4, ZMod 2) : ℝ :=
  1 / 2 * Mfun r (tw (j₀ + 1)) (x (j₀ + 1) + x (j₀ + 2))
    * Mfun r (tw (j₀ + 2)) (x (j₀ + 2) + x (j₀ + 3))
    * Mfun r (tw (j₀ + 3)) (x (j₀ + 3) + x j₀)

lemma pathMass_nonneg {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (j₀ : Fin 4)
    (x : ∀ _i : Fin 4, ZMod 2) : 0 ≤ pathMass r j₀ x := by
  unfold pathMass
  exact mul_nonneg (mul_nonneg (mul_nonneg (by norm_num)
    (Mfun_nonneg hr0 hr1 _ _)) (Mfun_nonneg hr0 hr1 _ _)) (Mfun_nonneg hr0 hr1 _ _)

lemma pathMass_pos {r : ℝ} (hr0 : 0 < r) (hr1 : r < 1) (j₀ : Fin 4)
    (x : ∀ _i : Fin 4, ZMod 2) : 0 < pathMass r j₀ x := by
  unfold pathMass
  exact mul_pos (mul_pos (mul_pos (by norm_num)
    (Mfun_pos hr0 hr1 _ _)) (Mfun_pos hr0 hr1 _ _)) (Mfun_pos hr0 hr1 _ _)

lemma pathMass_sum (r : ℝ) (j₀ : Fin 4) : ∑ x, pathMass r j₀ x = 1 := by
  rw [← Equiv.sum_comp (quadChart (j₀ + 1) (j₀ + 2) (j₀ + 3) j₀
    ((by decide : ∀ j : Fin 4, j + 1 ≠ j + 2) j₀)
    ((by decide : ∀ j : Fin 4, j + 1 ≠ j + 3) j₀)
    ((by decide : ∀ j : Fin 4, j + 1 ≠ j) j₀)
    ((by decide : ∀ j : Fin 4, j + 2 ≠ j + 3) j₀)
    ((by decide : ∀ j : Fin 4, j + 2 ≠ j) j₀)
    ((by decide : ∀ j : Fin 4, j + 3 ≠ j) j₀)
    (fun i => (by decide : ∀ j i : Fin 4, i = j + 1 ∨ i = j + 2 ∨ i = j + 3 ∨ i = j) j₀ i)).symm
    (pathMass r j₀)]
  set E := quadChart (j₀ + 1) (j₀ + 2) (j₀ + 3) j₀ _ _ _ _ _ _ _ with hE
  have hsummand : ∀ c : ZMod 2 × ZMod 2 × ZMod 2 × ZMod 2,
      pathMass r j₀ (E.symm c)
        = 1 / 2 * Mfun r (tw (j₀ + 1)) (c.1 + c.2.1)
          * Mfun r (tw (j₀ + 2)) (c.2.1 + c.2.2.1)
          * Mfun r (tw (j₀ + 3)) (c.2.2.1 + c.2.2.2) := by
    intro c
    have hq := Equiv.apply_symm_apply E c
    have e1 : E.symm c (j₀ + 1) = c.1 := congrArg Prod.fst hq
    have e2 : E.symm c (j₀ + 2) = c.2.1 := congrArg (fun p => p.2.1) hq
    have e3 : E.symm c (j₀ + 3) = c.2.2.1 := congrArg (fun p => p.2.2.1) hq
    have e4 : E.symm c j₀ = c.2.2.2 := congrArg (fun p => p.2.2.2) hq
    simp only [pathMass, e1, e2, e3, e4]
  rw [Finset.sum_congr rfl fun c _ => hsummand c, Fintype.sum_prod_type]
  have h1 : ∀ c₁ : ZMod 2,
      (∑ p : ZMod 2 × ZMod 2 × ZMod 2,
        1 / 2 * Mfun r (tw (j₀ + 1)) (c₁ + p.1)
          * Mfun r (tw (j₀ + 2)) (p.1 + p.2.1)
          * Mfun r (tw (j₀ + 3)) (p.2.1 + p.2.2)) = 1 / 2 := by
    intro c₁
    rw [Fintype.sum_prod_type]
    have h2 : ∀ c₂ : ZMod 2,
        (∑ p : ZMod 2 × ZMod 2,
          1 / 2 * Mfun r (tw (j₀ + 1)) (c₁ + c₂)
            * Mfun r (tw (j₀ + 2)) (c₂ + p.1)
            * Mfun r (tw (j₀ + 3)) (p.1 + p.2))
          = 1 / 2 * Mfun r (tw (j₀ + 1)) (c₁ + c₂) := by
      intro c₂
      rw [Fintype.sum_prod_type]
      have h3 : ∀ c₃ : ZMod 2,
          (∑ c₄ : ZMod 2,
            1 / 2 * Mfun r (tw (j₀ + 1)) (c₁ + c₂)
              * Mfun r (tw (j₀ + 2)) (c₂ + c₃)
              * Mfun r (tw (j₀ + 3)) (c₃ + c₄))
            = 1 / 2 * Mfun r (tw (j₀ + 1)) (c₁ + c₂)
              * Mfun r (tw (j₀ + 2)) (c₂ + c₃) := by
        intro c₃
        rw [← Finset.mul_sum, sum_Mfun_right, mul_one]
      rw [Finset.sum_congr rfl fun c₃ _ => h3 c₃, ← Finset.mul_sum, sum_Mfun_right,
        mul_one]
    rw [Finset.sum_congr rfl fun c₂ _ => h2 c₂, ← Finset.mul_sum, sum_Mfun_right,
      mul_one]
  rw [Finset.sum_congr rfl fun c₁ _ => h1 c₁, sum_zmod2 (fun _ => (1 : ℝ) / 2)]
  norm_num

/-- The junction-tree completion for the path missing edge `j₀`, as a distribution. -/
noncomputable def pathDist {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (j₀ : Fin 4) :
    ProbDistribution (∀ _i : Fin 4, ZMod 2) :=
  ProbDistribution.mk' (pathMass r j₀)
    (fun x => pathMass_nonneg hr0 hr1 j₀ x)
    (pathMass_sum r j₀)

@[simp] lemma pathDist_coe {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (j₀ : Fin 4)
    (x : ∀ _i : Fin 4, ZMod 2) : ((pathDist hr0 hr1 j₀) x : ℝ) = pathMass r j₀ x :=
  rfl

/-- **The subcover completion law**: the junction-tree completion reproduces every
prescribed edge of the path. -/
theorem pathDist_marginal {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (j₀ e : Fin 4)
    (he : e ≠ j₀) :
    (pathDist hr0 hr1 j₀).marginal (cyc e) = edgeDist r hr0 hr1 e := by
  refine ProbDistribution.ext fun g => ?_
  apply Subtype.ext
  show (((pathDist hr0 hr1 j₀).marginal (cyc e)) g : ℝ) = ((edgeDist r hr0 hr1 e) g : ℝ)
  rw [ProbDistribution.marginal_coe, edgeDist_coe,
    sum_fiber_restrict' (cyc e) g (fun f => ((pathDist hr0 hr1 j₀) f : ℝ))]
  rcases (by decide : ∀ a b : Fin 4, a ≠ b → a = b + 1 ∨ a = b + 2 ∨ a = b + 3) e j₀ he
    with hc | hc | hc <;> subst hc
  · -- e = j₀ + 1 : free sites j₀+3, j₀
    rw [← Equiv.sum_comp (complChart2 (cyc (j₀ + 1)) (j₀ + 3) j₀
      ((by decide : ∀ j : Fin 4, ¬(j + 3) ∈ cyc (j + 1)) j₀)
      ((by decide : ∀ j : Fin 4, ¬j ∈ cyc (j + 1)) j₀)
      ((by decide : ∀ j : Fin 4, j + 3 ≠ j) j₀)
      (fun i hi => (by decide : ∀ j i : Fin 4, ¬i ∈ cyc (j + 1) → i = j + 3 ∨ i = j)
        j₀ i hi)).symm
      (fun w => ((pathDist hr0 hr1 j₀) ((Equiv.piEquivPiSubtypeProd
        (· ∈ cyc (j₀ + 1)) (fun _ => ZMod 2)).symm (g, w)) : ℝ))]
    set C := complChart2 (cyc (j₀ + 1)) (j₀ + 3) j₀ _ _ _ _ with hC
    have hsummand : ∀ c : ZMod 2 × ZMod 2,
        ((pathDist hr0 hr1 j₀) ((Equiv.piEquivPiSubtypeProd
          (· ∈ cyc (j₀ + 1)) (fun _ => ZMod 2)).symm (g, C.symm c)) : ℝ)
        = 1 / 2 * Mfun r (tw (j₀ + 1))
              ((pairEquiv (j₀ + 1) g).1 + (pairEquiv (j₀ + 1) g).2)
            * Mfun r (tw (j₀ + 2)) ((pairEquiv (j₀ + 1) g).2 + c.1)
            * Mfun r (tw (j₀ + 3)) (c.1 + c.2) := by
      intro c
      set X := (Equiv.piEquivPiSubtypeProd (· ∈ cyc (j₀ + 1)) (fun _ => ZMod 2)).symm
        (g, C.symm c) with hX
      have hqc := Equiv.apply_symm_apply C c
      have hw1 : C.symm c ⟨j₀ + 3, _⟩ = c.1 := congrArg Prod.fst hqc
      have hw2 : C.symm c ⟨j₀, _⟩ = c.2 := congrArg Prod.snd hqc
      have hx1 : X (j₀ + 1) = (pairEquiv (j₀ + 1) g).1 := by
        rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply, dif_pos (mem_cyc_left (j₀ + 1))]
        rfl
      have hx2 : X (j₀ + 2) = (pairEquiv (j₀ + 1) g).2 := by
        rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
          dif_pos ((by decide : ∀ j : Fin 4, j + 2 ∈ cyc (j + 1)) j₀)]
        show g ⟨j₀ + 2, _⟩ = g ⟨j₀ + 1 + 1, _⟩
        congr 1
        exact Subtype.ext ((by decide : ∀ j : Fin 4, j + 1 + 1 = j + 2) j₀).symm
      have hx3 : X (j₀ + 3) = c.1 := by
        rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
          dif_neg ((by decide : ∀ j : Fin 4, ¬(j + 3) ∈ cyc (j + 1)) j₀)]
        exact hw1
      have hx4 : X j₀ = c.2 := by
        rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
          dif_neg ((by decide : ∀ j : Fin 4, ¬j ∈ cyc (j + 1)) j₀)]
        exact hw2
      rw [pathDist_coe]
      simp only [pathMass, hx1, hx2, hx3, hx4]
    rw [Finset.sum_congr rfl fun c _ => hsummand c, Fintype.sum_prod_type]
    have h2 : ∀ c₁ : ZMod 2,
        (∑ c₂ : ZMod 2,
          1 / 2 * Mfun r (tw (j₀ + 1))
              ((pairEquiv (j₀ + 1) g).1 + (pairEquiv (j₀ + 1) g).2)
            * Mfun r (tw (j₀ + 2)) ((pairEquiv (j₀ + 1) g).2 + c₁)
            * Mfun r (tw (j₀ + 3)) (c₁ + c₂))
          = 1 / 2 * Mfun r (tw (j₀ + 1))
              ((pairEquiv (j₀ + 1) g).1 + (pairEquiv (j₀ + 1) g).2)
            * Mfun r (tw (j₀ + 2)) ((pairEquiv (j₀ + 1) g).2 + c₁) := by
      intro c₁
      rw [← Finset.mul_sum, sum_Mfun_right, mul_one]
    rw [Finset.sum_congr rfl fun c₁ _ => h2 c₁, ← Finset.mul_sum, sum_Mfun_right,
      mul_one, half_Mfun]
    rfl
  · -- e = j₀ + 2 : free sites j₀, j₀+1
    rw [← Equiv.sum_comp (complChart2 (cyc (j₀ + 2)) j₀ (j₀ + 1)
      ((by decide : ∀ j : Fin 4, ¬j ∈ cyc (j + 2)) j₀)
      ((by decide : ∀ j : Fin 4, ¬(j + 1) ∈ cyc (j + 2)) j₀)
      ((by decide : ∀ j : Fin 4, j ≠ j + 1) j₀)
      (fun i hi => (by decide : ∀ j i : Fin 4, ¬i ∈ cyc (j + 2) → i = j ∨ i = j + 1)
        j₀ i hi)).symm
      (fun w => ((pathDist hr0 hr1 j₀) ((Equiv.piEquivPiSubtypeProd
        (· ∈ cyc (j₀ + 2)) (fun _ => ZMod 2)).symm (g, w)) : ℝ))]
    set C := complChart2 (cyc (j₀ + 2)) j₀ (j₀ + 1) _ _ _ _ with hC
    have hsummand : ∀ c : ZMod 2 × ZMod 2,
        ((pathDist hr0 hr1 j₀) ((Equiv.piEquivPiSubtypeProd
          (· ∈ cyc (j₀ + 2)) (fun _ => ZMod 2)).symm (g, C.symm c)) : ℝ)
        = 1 / 2 * Mfun r (tw (j₀ + 1)) (c.2 + (pairEquiv (j₀ + 2) g).1)
            * Mfun r (tw (j₀ + 2))
              ((pairEquiv (j₀ + 2) g).1 + (pairEquiv (j₀ + 2) g).2)
            * Mfun r (tw (j₀ + 3)) ((pairEquiv (j₀ + 2) g).2 + c.1) := by
      intro c
      set X := (Equiv.piEquivPiSubtypeProd (· ∈ cyc (j₀ + 2)) (fun _ => ZMod 2)).symm
        (g, C.symm c) with hX
      have hqc := Equiv.apply_symm_apply C c
      have hw1 : C.symm c ⟨j₀, _⟩ = c.1 := congrArg Prod.fst hqc
      have hw2 : C.symm c ⟨j₀ + 1, _⟩ = c.2 := congrArg Prod.snd hqc
      have hx1 : X (j₀ + 2) = (pairEquiv (j₀ + 2) g).1 := by
        rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply, dif_pos (mem_cyc_left (j₀ + 2))]
        rfl
      have hx2 : X (j₀ + 3) = (pairEquiv (j₀ + 2) g).2 := by
        rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
          dif_pos ((by decide : ∀ j : Fin 4, j + 3 ∈ cyc (j + 2)) j₀)]
        show g ⟨j₀ + 3, _⟩ = g ⟨j₀ + 2 + 1, _⟩
        congr 1
        exact Subtype.ext ((by decide : ∀ j : Fin 4, j + 2 + 1 = j + 3) j₀).symm
      have hx3 : X j₀ = c.1 := by
        rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
          dif_neg ((by decide : ∀ j : Fin 4, ¬j ∈ cyc (j + 2)) j₀)]
        exact hw1
      have hx4 : X (j₀ + 1) = c.2 := by
        rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
          dif_neg ((by decide : ∀ j : Fin 4, ¬(j + 1) ∈ cyc (j + 2)) j₀)]
        exact hw2
      rw [pathDist_coe]
      simp only [pathMass, hx1, hx2, hx3, hx4]
    rw [Finset.sum_congr rfl fun c _ => hsummand c, Fintype.sum_prod_type]
    have h2 : ∀ c₁ : ZMod 2,
        (∑ c₂ : ZMod 2,
          1 / 2 * Mfun r (tw (j₀ + 1)) (c₂ + (pairEquiv (j₀ + 2) g).1)
            * Mfun r (tw (j₀ + 2))
              ((pairEquiv (j₀ + 2) g).1 + (pairEquiv (j₀ + 2) g).2)
            * Mfun r (tw (j₀ + 3)) ((pairEquiv (j₀ + 2) g).2 + c₁))
          = 1 / 2 * Mfun r (tw (j₀ + 2))
              ((pairEquiv (j₀ + 2) g).1 + (pairEquiv (j₀ + 2) g).2)
            * Mfun r (tw (j₀ + 3)) ((pairEquiv (j₀ + 2) g).2 + c₁) := by
      intro c₁
      rw [Finset.sum_congr rfl fun c₂ _ => (by ring :
        1 / 2 * Mfun r (tw (j₀ + 1)) (c₂ + (pairEquiv (j₀ + 2) g).1)
          * Mfun r (tw (j₀ + 2))
            ((pairEquiv (j₀ + 2) g).1 + (pairEquiv (j₀ + 2) g).2)
          * Mfun r (tw (j₀ + 3)) ((pairEquiv (j₀ + 2) g).2 + c₁)
        = 1 / 2 * Mfun r (tw (j₀ + 2))
            ((pairEquiv (j₀ + 2) g).1 + (pairEquiv (j₀ + 2) g).2)
          * Mfun r (tw (j₀ + 3)) ((pairEquiv (j₀ + 2) g).2 + c₁)
          * Mfun r (tw (j₀ + 1)) (c₂ + (pairEquiv (j₀ + 2) g).1)),
        ← Finset.mul_sum, sum_Mfun_left, mul_one]
    rw [Finset.sum_congr rfl fun c₁ _ => h2 c₁, ← Finset.mul_sum, sum_Mfun_right,
      mul_one, half_Mfun]
    rfl
  · -- e = j₀ + 3 : free sites j₀+2, j₀+1
    rw [← Equiv.sum_comp (complChart2 (cyc (j₀ + 3)) (j₀ + 2) (j₀ + 1)
      ((by decide : ∀ j : Fin 4, ¬(j + 2) ∈ cyc (j + 3)) j₀)
      ((by decide : ∀ j : Fin 4, ¬(j + 1) ∈ cyc (j + 3)) j₀)
      ((by decide : ∀ j : Fin 4, j + 2 ≠ j + 1) j₀)
      (fun i hi => (by decide :
        ∀ j i : Fin 4, ¬i ∈ cyc (j + 3) → i = j + 2 ∨ i = j + 1) j₀ i hi)).symm
      (fun w => ((pathDist hr0 hr1 j₀) ((Equiv.piEquivPiSubtypeProd
        (· ∈ cyc (j₀ + 3)) (fun _ => ZMod 2)).symm (g, w)) : ℝ))]
    set C := complChart2 (cyc (j₀ + 3)) (j₀ + 2) (j₀ + 1) _ _ _ _ with hC
    have hsummand : ∀ c : ZMod 2 × ZMod 2,
        ((pathDist hr0 hr1 j₀) ((Equiv.piEquivPiSubtypeProd
          (· ∈ cyc (j₀ + 3)) (fun _ => ZMod 2)).symm (g, C.symm c)) : ℝ)
        = 1 / 2 * Mfun r (tw (j₀ + 1)) (c.2 + c.1)
            * Mfun r (tw (j₀ + 2)) (c.1 + (pairEquiv (j₀ + 3) g).1)
            * Mfun r (tw (j₀ + 3))
              ((pairEquiv (j₀ + 3) g).1 + (pairEquiv (j₀ + 3) g).2) := by
      intro c
      set X := (Equiv.piEquivPiSubtypeProd (· ∈ cyc (j₀ + 3)) (fun _ => ZMod 2)).symm
        (g, C.symm c) with hX
      have hqc := Equiv.apply_symm_apply C c
      have hw1 : C.symm c ⟨j₀ + 2, _⟩ = c.1 := congrArg Prod.fst hqc
      have hw2 : C.symm c ⟨j₀ + 1, _⟩ = c.2 := congrArg Prod.snd hqc
      have hx1 : X (j₀ + 3) = (pairEquiv (j₀ + 3) g).1 := by
        rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply, dif_pos (mem_cyc_left (j₀ + 3))]
        rfl
      have hx2 : X j₀ = (pairEquiv (j₀ + 3) g).2 := by
        rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
          dif_pos ((by decide : ∀ j : Fin 4, j ∈ cyc (j + 3)) j₀)]
        show g ⟨j₀, _⟩ = g ⟨j₀ + 3 + 1, _⟩
        congr 1
        exact Subtype.ext ((by decide : ∀ j : Fin 4, j + 3 + 1 = j) j₀).symm
      have hx3 : X (j₀ + 2) = c.1 := by
        rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
          dif_neg ((by decide : ∀ j : Fin 4, ¬(j + 2) ∈ cyc (j + 3)) j₀)]
        exact hw1
      have hx4 : X (j₀ + 1) = c.2 := by
        rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
          dif_neg ((by decide : ∀ j : Fin 4, ¬(j + 1) ∈ cyc (j + 3)) j₀)]
        exact hw2
      rw [pathDist_coe]
      simp only [pathMass, hx1, hx2, hx3, hx4]
    rw [Finset.sum_congr rfl fun c _ => hsummand c, Fintype.sum_prod_type]
    have h2 : ∀ c₁ : ZMod 2,
        (∑ c₂ : ZMod 2,
          1 / 2 * Mfun r (tw (j₀ + 1)) (c₂ + c₁)
            * Mfun r (tw (j₀ + 2)) (c₁ + (pairEquiv (j₀ + 3) g).1)
            * Mfun r (tw (j₀ + 3))
              ((pairEquiv (j₀ + 3) g).1 + (pairEquiv (j₀ + 3) g).2))
          = 1 / 2 * Mfun r (tw (j₀ + 2)) (c₁ + (pairEquiv (j₀ + 3) g).1)
            * Mfun r (tw (j₀ + 3))
              ((pairEquiv (j₀ + 3) g).1 + (pairEquiv (j₀ + 3) g).2) := by
      intro c₁
      rw [Finset.sum_congr rfl fun c₂ _ => (by ring :
        1 / 2 * Mfun r (tw (j₀ + 1)) (c₂ + c₁)
          * Mfun r (tw (j₀ + 2)) (c₁ + (pairEquiv (j₀ + 3) g).1)
          * Mfun r (tw (j₀ + 3))
            ((pairEquiv (j₀ + 3) g).1 + (pairEquiv (j₀ + 3) g).2)
        = 1 / 2 * Mfun r (tw (j₀ + 2)) (c₁ + (pairEquiv (j₀ + 3) g).1)
          * Mfun r (tw (j₀ + 3))
            ((pairEquiv (j₀ + 3) g).1 + (pairEquiv (j₀ + 3) g).2)
          * Mfun r (tw (j₀ + 1)) (c₂ + c₁)),
        ← Finset.mul_sum, sum_Mfun_left, mul_one]
    rw [Finset.sum_congr rfl fun c₁ _ => h2 c₁]
    rw [Finset.sum_congr rfl fun c₁ _ => (by ring :
      1 / 2 * Mfun r (tw (j₀ + 2)) (c₁ + (pairEquiv (j₀ + 3) g).1)
        * Mfun r (tw (j₀ + 3))
          ((pairEquiv (j₀ + 3) g).1 + (pairEquiv (j₀ + 3) g).2)
      = 1 / 2 * Mfun r (tw (j₀ + 3))
          ((pairEquiv (j₀ + 3) g).1 + (pairEquiv (j₀ + 3) g).2)
        * Mfun r (tw (j₀ + 2)) (c₁ + (pairEquiv (j₀ + 3) g).1)),
      ← Finset.mul_sum, sum_Mfun_left, mul_one, half_Mfun]
    rfl

end HiddenChannelCapacity

/-! ### The Markov property of the completions, classical factorization form

`Markov completion` in LZ (arXiv:2605.19453, Def. 2.7 and p. 4) means the completion
satisfies the global Markov property of the junction tree. Classically this is
conditional independence across each separator, in factorization form
(Lauritzen, *Graphical Models*, OUP 1996, Prop. 3.1; Dawid 1979):
`q(x) · q_sep(x) = q_left(x) · q_right(x)` for each tree edge. -/

namespace HiddenChannelCapacity

/-- Three consecutive sites (one side of a path separator). -/
def T3 (v : Fin 4) : Finset (Fin 4) := {v, v + 1, v + 2}

/-- A single site (a path separator). -/
def T1 (v : Fin 4) : Finset (Fin 4) := {v}

/-- 3-site marginal of the path completion on the far side of the first separator. -/
lemma pathDist_marg_T3_late {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (j₀ : Fin 4)
    (x : ∀ _i : Fin 4, ZMod 2) :
    (((pathDist hr0 hr1 j₀).marginal (T3 (j₀ + 2))) ((T3 (j₀ + 2)).restrict x) : ℝ)
      = 1 / 2 * Mfun r (tw (j₀ + 2)) (x (j₀ + 2) + x (j₀ + 3))
        * Mfun r (tw (j₀ + 3)) (x (j₀ + 3) + x j₀) := by
  rw [ProbDistribution.marginal_coe,
    sum_fiber_restrict' (T3 (j₀ + 2)) ((T3 (j₀ + 2)).restrict x)
      (fun f => ((pathDist hr0 hr1 j₀) f : ℝ)),
    ← Equiv.sum_comp (complChart1 (T3 (j₀ + 2)) (j₀ + 1)
      ((by decide : ∀ j : Fin 4, ¬(j + 1) ∈ T3 (j + 2)) j₀)
      (fun i hi => (by decide : ∀ j i : Fin 4, ¬i ∈ T3 (j + 2) → i = j + 1) j₀ i hi)).symm
      (fun w => ((pathDist hr0 hr1 j₀) ((Equiv.piEquivPiSubtypeProd
        (· ∈ T3 (j₀ + 2)) (fun _ => ZMod 2)).symm ((T3 (j₀ + 2)).restrict x, w)) : ℝ))]
  set C := complChart1 (T3 (j₀ + 2)) (j₀ + 1) _ _ with hC
  have hsummand : ∀ c : ZMod 2,
      ((pathDist hr0 hr1 j₀) ((Equiv.piEquivPiSubtypeProd
        (· ∈ T3 (j₀ + 2)) (fun _ => ZMod 2)).symm ((T3 (j₀ + 2)).restrict x,
          C.symm c)) : ℝ)
      = 1 / 2 * Mfun r (tw (j₀ + 1)) (c + x (j₀ + 2))
        * Mfun r (tw (j₀ + 2)) (x (j₀ + 2) + x (j₀ + 3))
        * Mfun r (tw (j₀ + 3)) (x (j₀ + 3) + x j₀) := by
    intro c
    set X := (Equiv.piEquivPiSubtypeProd (· ∈ T3 (j₀ + 2)) (fun _ => ZMod 2)).symm
      ((T3 (j₀ + 2)).restrict x, C.symm c) with hX
    have hx1 : X (j₀ + 1) = c := by
      rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
        dif_neg ((by decide : ∀ j : Fin 4, ¬(j + 1) ∈ T3 (j + 2)) j₀)]
      rfl
    have hx2 : X (j₀ + 2) = x (j₀ + 2) := by
      rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
        dif_pos ((by decide : ∀ j : Fin 4, j + 2 ∈ T3 (j + 2)) j₀)]
      rfl
    have hx3 : X (j₀ + 3) = x (j₀ + 3) := by
      rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
        dif_pos ((by decide : ∀ j : Fin 4, j + 3 ∈ T3 (j + 2)) j₀)]
      rfl
    have hx4 : X j₀ = x j₀ := by
      rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
        dif_pos ((by decide : ∀ j : Fin 4, j ∈ T3 (j + 2)) j₀)]
      rfl
    rw [pathDist_coe]
    simp only [pathMass, hx1, hx2, hx3, hx4]
  rw [Finset.sum_congr rfl fun c _ => hsummand c,
    Finset.sum_congr rfl fun c _ => (by ring :
      1 / 2 * Mfun r (tw (j₀ + 1)) (c + x (j₀ + 2))
        * Mfun r (tw (j₀ + 2)) (x (j₀ + 2) + x (j₀ + 3))
        * Mfun r (tw (j₀ + 3)) (x (j₀ + 3) + x j₀)
      = 1 / 2 * Mfun r (tw (j₀ + 2)) (x (j₀ + 2) + x (j₀ + 3))
        * Mfun r (tw (j₀ + 3)) (x (j₀ + 3) + x j₀)
        * Mfun r (tw (j₀ + 1)) (c + x (j₀ + 2))),
    ← Finset.mul_sum, sum_Mfun_left, mul_one]

/-- 3-site marginal of the path completion on the near side of the second separator. -/
lemma pathDist_marg_T3_early {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (j₀ : Fin 4)
    (x : ∀ _i : Fin 4, ZMod 2) :
    (((pathDist hr0 hr1 j₀).marginal (T3 (j₀ + 1))) ((T3 (j₀ + 1)).restrict x) : ℝ)
      = 1 / 2 * Mfun r (tw (j₀ + 1)) (x (j₀ + 1) + x (j₀ + 2))
        * Mfun r (tw (j₀ + 2)) (x (j₀ + 2) + x (j₀ + 3)) := by
  rw [ProbDistribution.marginal_coe,
    sum_fiber_restrict' (T3 (j₀ + 1)) ((T3 (j₀ + 1)).restrict x)
      (fun f => ((pathDist hr0 hr1 j₀) f : ℝ)),
    ← Equiv.sum_comp (complChart1 (T3 (j₀ + 1)) j₀
      ((by decide : ∀ j : Fin 4, ¬j ∈ T3 (j + 1)) j₀)
      (fun i hi => (by decide : ∀ j i : Fin 4, ¬i ∈ T3 (j + 1) → i = j) j₀ i hi)).symm
      (fun w => ((pathDist hr0 hr1 j₀) ((Equiv.piEquivPiSubtypeProd
        (· ∈ T3 (j₀ + 1)) (fun _ => ZMod 2)).symm ((T3 (j₀ + 1)).restrict x, w)) : ℝ))]
  set C := complChart1 (T3 (j₀ + 1)) j₀ _ _ with hC
  have hsummand : ∀ c : ZMod 2,
      ((pathDist hr0 hr1 j₀) ((Equiv.piEquivPiSubtypeProd
        (· ∈ T3 (j₀ + 1)) (fun _ => ZMod 2)).symm ((T3 (j₀ + 1)).restrict x,
          C.symm c)) : ℝ)
      = 1 / 2 * Mfun r (tw (j₀ + 1)) (x (j₀ + 1) + x (j₀ + 2))
        * Mfun r (tw (j₀ + 2)) (x (j₀ + 2) + x (j₀ + 3))
        * Mfun r (tw (j₀ + 3)) (x (j₀ + 3) + c) := by
    intro c
    set X := (Equiv.piEquivPiSubtypeProd (· ∈ T3 (j₀ + 1)) (fun _ => ZMod 2)).symm
      ((T3 (j₀ + 1)).restrict x, C.symm c) with hX
    have hx1 : X (j₀ + 1) = x (j₀ + 1) := by
      rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
        dif_pos ((by decide : ∀ j : Fin 4, j + 1 ∈ T3 (j + 1)) j₀)]
      rfl
    have hx2 : X (j₀ + 2) = x (j₀ + 2) := by
      rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
        dif_pos ((by decide : ∀ j : Fin 4, j + 2 ∈ T3 (j + 1)) j₀)]
      rfl
    have hx3 : X (j₀ + 3) = x (j₀ + 3) := by
      rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
        dif_pos ((by decide : ∀ j : Fin 4, j + 3 ∈ T3 (j + 1)) j₀)]
      rfl
    have hx4 : X j₀ = c := by
      rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
        dif_neg ((by decide : ∀ j : Fin 4, ¬j ∈ T3 (j + 1)) j₀)]
      rfl
    rw [pathDist_coe]
    simp only [pathMass, hx1, hx2, hx3, hx4]
  rw [Finset.sum_congr rfl fun c _ => hsummand c, ← Finset.mul_sum, sum_Mfun_right,
    mul_one]

/-- 1-site marginals of the path completion are uniform (separator marginals). -/
lemma pathDist_marg_T1_mid {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (j₀ : Fin 4)
    (x : ∀ _i : Fin 4, ZMod 2) :
    (((pathDist hr0 hr1 j₀).marginal (T1 (j₀ + 2))) ((T1 (j₀ + 2)).restrict x) : ℝ)
      = 1 / 2 := by
  rw [ProbDistribution.marginal_coe,
    sum_fiber_restrict' (T1 (j₀ + 2)) ((T1 (j₀ + 2)).restrict x)
      (fun f => ((pathDist hr0 hr1 j₀) f : ℝ)),
    ← Equiv.sum_comp (complChart3 (T1 (j₀ + 2)) (j₀ + 1) (j₀ + 3) j₀
      ((by decide : ∀ j : Fin 4, ¬(j + 1) ∈ T1 (j + 2)) j₀)
      ((by decide : ∀ j : Fin 4, ¬(j + 3) ∈ T1 (j + 2)) j₀)
      ((by decide : ∀ j : Fin 4, ¬j ∈ T1 (j + 2)) j₀)
      ((by decide : ∀ j : Fin 4, j + 1 ≠ j + 3) j₀)
      ((by decide : ∀ j : Fin 4, j + 1 ≠ j) j₀)
      ((by decide : ∀ j : Fin 4, j + 3 ≠ j) j₀)
      (fun i hi => (by decide :
        ∀ j i : Fin 4, ¬i ∈ T1 (j + 2) → i = j + 1 ∨ i = j + 3 ∨ i = j) j₀ i hi)).symm
      (fun w => ((pathDist hr0 hr1 j₀) ((Equiv.piEquivPiSubtypeProd
        (· ∈ T1 (j₀ + 2)) (fun _ => ZMod 2)).symm ((T1 (j₀ + 2)).restrict x, w)) : ℝ))]
  set C := complChart3 (T1 (j₀ + 2)) (j₀ + 1) (j₀ + 3) j₀ _ _ _ _ _ _ _ with hC
  have hsummand : ∀ c : ZMod 2 × ZMod 2 × ZMod 2,
      ((pathDist hr0 hr1 j₀) ((Equiv.piEquivPiSubtypeProd
        (· ∈ T1 (j₀ + 2)) (fun _ => ZMod 2)).symm
          ((T1 (j₀ + 2)).restrict x, C.symm c)) : ℝ)
      = 1 / 2 * Mfun r (tw (j₀ + 1)) (c.1 + x (j₀ + 2))
        * Mfun r (tw (j₀ + 2)) (x (j₀ + 2) + c.2.1)
        * Mfun r (tw (j₀ + 3)) (c.2.1 + c.2.2) := by
    intro c
    set X := (Equiv.piEquivPiSubtypeProd (· ∈ T1 (j₀ + 2)) (fun _ => ZMod 2)).symm
      ((T1 (j₀ + 2)).restrict x, C.symm c) with hX
    have hqc := Equiv.apply_symm_apply C c
    have hw1 : C.symm c ⟨j₀ + 1, _⟩ = c.1 := congrArg Prod.fst hqc
    have hw2 : C.symm c ⟨j₀ + 3, _⟩ = c.2.1 := congrArg (fun p => p.2.1) hqc
    have hw3 : C.symm c ⟨j₀, _⟩ = c.2.2 := congrArg (fun p => p.2.2) hqc
    have hx1 : X (j₀ + 1) = c.1 := by
      rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
        dif_neg ((by decide : ∀ j : Fin 4, ¬(j + 1) ∈ T1 (j + 2)) j₀)]
      exact hw1
    have hx2 : X (j₀ + 2) = x (j₀ + 2) := by
      rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
        dif_pos ((by decide : ∀ j : Fin 4, j + 2 ∈ T1 (j + 2)) j₀)]
      rfl
    have hx3 : X (j₀ + 3) = c.2.1 := by
      rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
        dif_neg ((by decide : ∀ j : Fin 4, ¬(j + 3) ∈ T1 (j + 2)) j₀)]
      exact hw2
    have hx4 : X j₀ = c.2.2 := by
      rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
        dif_neg ((by decide : ∀ j : Fin 4, ¬j ∈ T1 (j + 2)) j₀)]
      exact hw3
    rw [pathDist_coe]
    simp only [pathMass, hx1, hx2, hx3, hx4]
  rw [Finset.sum_congr rfl fun c _ => hsummand c, Fintype.sum_prod_type]
  have h2 : ∀ c₁ : ZMod 2,
      (∑ p : ZMod 2 × ZMod 2,
        1 / 2 * Mfun r (tw (j₀ + 1)) (c₁ + x (j₀ + 2))
          * Mfun r (tw (j₀ + 2)) (x (j₀ + 2) + p.1)
          * Mfun r (tw (j₀ + 3)) (p.1 + p.2))
        = 1 / 2 * Mfun r (tw (j₀ + 1)) (c₁ + x (j₀ + 2)) := by
    intro c₁
    rw [Fintype.sum_prod_type]
    have h3 : ∀ c₂ : ZMod 2,
        (∑ c₃ : ZMod 2,
          1 / 2 * Mfun r (tw (j₀ + 1)) (c₁ + x (j₀ + 2))
            * Mfun r (tw (j₀ + 2)) (x (j₀ + 2) + c₂)
            * Mfun r (tw (j₀ + 3)) (c₂ + c₃))
          = 1 / 2 * Mfun r (tw (j₀ + 1)) (c₁ + x (j₀ + 2))
            * Mfun r (tw (j₀ + 2)) (x (j₀ + 2) + c₂) := by
      intro c₂
      rw [← Finset.mul_sum, sum_Mfun_right, mul_one]
    rw [Finset.sum_congr rfl fun c₂ _ => h3 c₂, ← Finset.mul_sum, sum_Mfun_right,
      mul_one]
  rw [Finset.sum_congr rfl fun c₁ _ => h2 c₁,
    Finset.sum_congr rfl fun c₁ _ => (by ring :
      1 / 2 * Mfun r (tw (j₀ + 1)) (c₁ + x (j₀ + 2))
        = Mfun r (tw (j₀ + 1)) (c₁ + x (j₀ + 2)) * (1 / 2)),
    ← Finset.sum_mul, sum_Mfun_left, one_mul]

/-- 1-site marginal at the second separator. -/
lemma pathDist_marg_T1_late {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (j₀ : Fin 4)
    (x : ∀ _i : Fin 4, ZMod 2) :
    (((pathDist hr0 hr1 j₀).marginal (T1 (j₀ + 3))) ((T1 (j₀ + 3)).restrict x) : ℝ)
      = 1 / 2 := by
  rw [ProbDistribution.marginal_coe,
    sum_fiber_restrict' (T1 (j₀ + 3)) ((T1 (j₀ + 3)).restrict x)
      (fun f => ((pathDist hr0 hr1 j₀) f : ℝ)),
    ← Equiv.sum_comp (complChart3 (T1 (j₀ + 3)) (j₀ + 2) (j₀ + 1) j₀
      ((by decide : ∀ j : Fin 4, ¬(j + 2) ∈ T1 (j + 3)) j₀)
      ((by decide : ∀ j : Fin 4, ¬(j + 1) ∈ T1 (j + 3)) j₀)
      ((by decide : ∀ j : Fin 4, ¬j ∈ T1 (j + 3)) j₀)
      ((by decide : ∀ j : Fin 4, j + 2 ≠ j + 1) j₀)
      ((by decide : ∀ j : Fin 4, j + 2 ≠ j) j₀)
      ((by decide : ∀ j : Fin 4, j + 1 ≠ j) j₀)
      (fun i hi => (by decide :
        ∀ j i : Fin 4, ¬i ∈ T1 (j + 3) → i = j + 2 ∨ i = j + 1 ∨ i = j) j₀ i hi)).symm
      (fun w => ((pathDist hr0 hr1 j₀) ((Equiv.piEquivPiSubtypeProd
        (· ∈ T1 (j₀ + 3)) (fun _ => ZMod 2)).symm ((T1 (j₀ + 3)).restrict x, w)) : ℝ))]
  set C := complChart3 (T1 (j₀ + 3)) (j₀ + 2) (j₀ + 1) j₀ _ _ _ _ _ _ _ with hC
  have hsummand : ∀ c : ZMod 2 × ZMod 2 × ZMod 2,
      ((pathDist hr0 hr1 j₀) ((Equiv.piEquivPiSubtypeProd
        (· ∈ T1 (j₀ + 3)) (fun _ => ZMod 2)).symm
          ((T1 (j₀ + 3)).restrict x, C.symm c)) : ℝ)
      = 1 / 2 * Mfun r (tw (j₀ + 1)) (c.2.1 + c.1)
        * Mfun r (tw (j₀ + 2)) (c.1 + x (j₀ + 3))
        * Mfun r (tw (j₀ + 3)) (x (j₀ + 3) + c.2.2) := by
    intro c
    set X := (Equiv.piEquivPiSubtypeProd (· ∈ T1 (j₀ + 3)) (fun _ => ZMod 2)).symm
      ((T1 (j₀ + 3)).restrict x, C.symm c) with hX
    have hqc := Equiv.apply_symm_apply C c
    have hw1 : C.symm c ⟨j₀ + 2, _⟩ = c.1 := congrArg Prod.fst hqc
    have hw2 : C.symm c ⟨j₀ + 1, _⟩ = c.2.1 := congrArg (fun p => p.2.1) hqc
    have hw3 : C.symm c ⟨j₀, _⟩ = c.2.2 := congrArg (fun p => p.2.2) hqc
    have hx1 : X (j₀ + 1) = c.2.1 := by
      rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
        dif_neg ((by decide : ∀ j : Fin 4, ¬(j + 1) ∈ T1 (j + 3)) j₀)]
      exact hw2
    have hx2 : X (j₀ + 2) = c.1 := by
      rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
        dif_neg ((by decide : ∀ j : Fin 4, ¬(j + 2) ∈ T1 (j + 3)) j₀)]
      exact hw1
    have hx3 : X (j₀ + 3) = x (j₀ + 3) := by
      rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
        dif_pos ((by decide : ∀ j : Fin 4, j + 3 ∈ T1 (j + 3)) j₀)]
      rfl
    have hx4 : X j₀ = c.2.2 := by
      rw [hX, Equiv.piEquivPiSubtypeProd_symm_apply,
        dif_neg ((by decide : ∀ j : Fin 4, ¬j ∈ T1 (j + 3)) j₀)]
      exact hw3
    rw [pathDist_coe]
    simp only [pathMass, hx1, hx2, hx3, hx4]
  rw [Finset.sum_congr rfl fun c _ => hsummand c, Fintype.sum_prod_type]
  have h2 : ∀ c₁ : ZMod 2,
      (∑ p : ZMod 2 × ZMod 2,
        1 / 2 * Mfun r (tw (j₀ + 1)) (p.1 + c₁)
          * Mfun r (tw (j₀ + 2)) (c₁ + x (j₀ + 3))
          * Mfun r (tw (j₀ + 3)) (x (j₀ + 3) + p.2))
        = 1 / 2 * Mfun r (tw (j₀ + 2)) (c₁ + x (j₀ + 3)) := by
    intro c₁
    rw [Fintype.sum_prod_type]
    have h3 : ∀ c₂ : ZMod 2,
        (∑ c₃ : ZMod 2,
          1 / 2 * Mfun r (tw (j₀ + 1)) (c₂ + c₁)
            * Mfun r (tw (j₀ + 2)) (c₁ + x (j₀ + 3))
            * Mfun r (tw (j₀ + 3)) (x (j₀ + 3) + c₃))
          = 1 / 2 * Mfun r (tw (j₀ + 1)) (c₂ + c₁)
            * Mfun r (tw (j₀ + 2)) (c₁ + x (j₀ + 3)) := by
      intro c₂
      rw [← Finset.mul_sum, sum_Mfun_right, mul_one]
    rw [Finset.sum_congr rfl fun c₂ _ => h3 c₂,
      Finset.sum_congr rfl fun c₂ _ => (by ring :
        1 / 2 * Mfun r (tw (j₀ + 1)) (c₂ + c₁)
          * Mfun r (tw (j₀ + 2)) (c₁ + x (j₀ + 3))
        = 1 / 2 * Mfun r (tw (j₀ + 2)) (c₁ + x (j₀ + 3))
          * Mfun r (tw (j₀ + 1)) (c₂ + c₁)),
      ← Finset.mul_sum, sum_Mfun_left, mul_one]
  rw [Finset.sum_congr rfl fun c₁ _ => h2 c₁,
    Finset.sum_congr rfl fun c₁ _ => (by ring :
      1 / 2 * Mfun r (tw (j₀ + 2)) (c₁ + x (j₀ + 3))
        = Mfun r (tw (j₀ + 2)) (c₁ + x (j₀ + 3)) * (1 / 2)),
    ← Finset.sum_mul, sum_Mfun_left, one_mul]

/-- Edge marginal value of the path completion, at a restricted global point. -/
lemma pathDist_marg_edge {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (j₀ e : Fin 4)
    (he : e ≠ j₀) (x : ∀ _i : Fin 4, ZMod 2) :
    (((pathDist hr0 hr1 j₀).marginal (cyc e)) ((cyc e).restrict x) : ℝ)
      = 1 / 2 * Mfun r (tw e) (x e + x (e + 1)) := by
  rw [pathDist_marginal hr0 hr1 j₀ e he, edgeDist_coe, half_Mfun]
  rfl

/-- **Classical Markov property** of a global law w.r.t. the path junction tree
missing edge `j₀`: conditional independence across both separators, in factorization
form (Lauritzen 1996, Prop. 3.1; Dawid 1979; the classical reading of LZ Def. 2.7). -/
def IsMarkovOnPath (q : ProbDistribution (∀ _i : Fin 4, ZMod 2)) (j₀ : Fin 4) : Prop :=
  (∀ x : (∀ _i : Fin 4, ZMod 2),
    (q x : ℝ) * ((q.marginal (T1 (j₀ + 2))) ((T1 (j₀ + 2)).restrict x) : ℝ)
      = ((q.marginal (cyc (j₀ + 1))) ((cyc (j₀ + 1)).restrict x) : ℝ)
        * ((q.marginal (T3 (j₀ + 2))) ((T3 (j₀ + 2)).restrict x) : ℝ))
  ∧ (∀ x : (∀ _i : Fin 4, ZMod 2),
    (q x : ℝ) * ((q.marginal (T1 (j₀ + 3))) ((T1 (j₀ + 3)).restrict x) : ℝ)
      = ((q.marginal (T3 (j₀ + 1))) ((T3 (j₀ + 1)).restrict x) : ℝ)
        * ((q.marginal (cyc (j₀ + 3))) ((cyc (j₀ + 3)).restrict x) : ℝ))

/-- The junction-tree completions ARE Markov completions, classically: both separator
factorizations hold, symbolically in `r`. -/
theorem pathDist_isMarkov {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) (j₀ : Fin 4) :
    IsMarkovOnPath (pathDist hr0 hr1 j₀) j₀ := by
  constructor
  · intro x
    rw [pathDist_coe, pathDist_marg_T1_mid hr0 hr1 j₀ x,
      pathDist_marg_edge hr0 hr1 j₀ (j₀ + 1) ((by decide : ∀ j : Fin 4, j + 1 ≠ j) j₀) x,
      pathDist_marg_T3_late hr0 hr1 j₀ x]
    simp only [pathMass]
    rw [show (j₀ + 1 + 1 : Fin 4) = j₀ + 2 from
      (by decide : ∀ j : Fin 4, j + 1 + 1 = j + 2) j₀]
    ring
  · intro x
    rw [pathDist_coe, pathDist_marg_T1_late hr0 hr1 j₀ x,
      pathDist_marg_T3_early hr0 hr1 j₀ x,
      pathDist_marg_edge hr0 hr1 j₀ (j₀ + 3) ((by decide : ∀ j : Fin 4, j + 3 ≠ j) j₀) x]
    simp only [pathMass]
    rw [show (j₀ + 3 + 1 : Fin 4) = j₀ from
      (by decide : ∀ j : Fin 4, j + 3 + 1 = j) j₀]
    ring

/-- **Every proper subcover admits a strictly positive Markov completion**, classically:
dropping any edge leaves an acyclic base, and base-side sufficiency then reconstructs a
completion from the junction tree of the remaining path. -/
theorem subcover_completableC {r : ℝ} (hr0 : 0 < r) (hr1 : r < 1)
    (E : Finset (Fin 4)) (hE : E ≠ Finset.univ) :
    ∃ j₀, j₀ ∉ E ∧ ∃ q : ProbDistribution (∀ _i : Fin 4, ZMod 2),
      (∀ x, 0 < (q x : ℝ)) ∧ IsMarkovOnPath q j₀
        ∧ ∀ j ∈ E, q.marginal (cyc j) = edgeDist r hr0.le hr1.le j := by
  obtain ⟨j₀, hj₀⟩ : ∃ j₀, j₀ ∉ E := by
    by_contra h
    exact hE (Finset.eq_univ_iff_forall.mpr fun j =>
      by_contra fun hj => h ⟨j, hj⟩)
  refine ⟨j₀, hj₀, pathDist hr0.le hr1.le j₀, fun x => ?_,
    pathDist_isMarkov hr0.le hr1.le j₀, fun j hj => ?_⟩
  · rw [pathDist_coe]
    exact pathMass_pos hr0 hr1 j₀ x
  · exact pathDist_marginal hr0.le hr1.le j₀ j (fun h => hj₀ (h ▸ hj))

/-- Every proper subcover admits a quantum completion (the diagonal embedding of the
junction tree; its quantum Markov property is `pathCompletion_qcmi` below). -/
theorem subcover_completableQ {r : ℝ} (hr0 : 0 < r) (hr1 : r < 1)
    (E : Finset (Fin 4)) (hE : E ≠ Finset.univ) :
    ∃ ω : MState (∀ _i : Fin 4, ZMod 2),
      ∀ j ∈ E, ptraceS ω (cyc j) = MState.ofClassical (edgeDist r hr0.le hr1.le j) := by
  obtain ⟨j₀, _, q, _, _, hq⟩ := subcover_completableC hr0 hr1 E hE
  exact ⟨MState.ofClassical q, fun j hj => by rw [ptraceS_ofClassical, hq j hj]⟩

/-- **The base-geometry resolution of the open problem, packaged** (LZ arXiv:2605.19453
leave completability off chordal covers open, p. 16): the base's global observable decides
completability, and no local end reaches it. The smoothed cycle family at `r = 7/8` is
strictly positive everywhere, pairwise consistent, and every proper subcover admits a
strictly positive classical Markov completion and a quantum completion, yet NO global
completion exists, classical or quantum. Completability off chordal covers is a base-side
quantity, disjoint from any proper-subcover data: the deciding observable is irreducibly
global. -/
theorem qjt_not_local :
    (∀ j g, 0 < ((edgeDist (7/8) (by norm_num) (by norm_num) j) g : ℝ))
    ∧ (∀ (E : Finset (Fin 4)), E ≠ Finset.univ →
        ∃ j₀, j₀ ∉ E ∧ ∃ q : ProbDistribution (∀ _i : Fin 4, ZMod 2),
          (∀ x, 0 < (q x : ℝ)) ∧ IsMarkovOnPath q j₀
            ∧ ∀ j ∈ E, q.marginal (cyc j)
              = edgeDist (7/8) (by norm_num) (by norm_num) j)
    ∧ ¬ (∃ q, IsCompletionC (X := fun _ => ZMod 2) cyc
        (fun j => edgeDist (7/8) (by norm_num) (by norm_num) j) q)
    ∧ ¬ (∃ ω, IsCompletionQ (X := fun _ => ZMod 2) cyc
        (fun j => MState.ofClassical (edgeDist (7/8) (by norm_num) (by norm_num) j)) ω) := by
  refine ⟨fun j g => edgeDist_full_support (by norm_num) (by norm_num) j g,
    fun E hE => ?_, cycleFam_not_completableC, cycleFam_not_completableQ⟩
  exact subcover_completableC (by norm_num) (by norm_num) E hE

end HiddenChannelCapacity

/-! ### Diagonal bridges for the quantum Markov property

The vendored corpus has `Sᵥₙ_ofClassical` (von Neumann = Shannon on diagonal states,
QuantumInfo/States/Entanglement.lean) but no interaction lemmas between `ofClassical`
and `relabel`/`traceLeft`/`traceRight`. Built here (A5: absence is an obligation). -/

namespace HiddenChannelCapacity

/-- First marginal of a distribution on a product. -/
noncomputable def PDfst {α β : Type*} [Fintype α] [Fintype β]
    (p : ProbDistribution (α × β)) : ProbDistribution α :=
  ProbDistribution.mk' (fun a => ∑ b, (p (a, b) : ℝ))
    (fun a => Finset.sum_nonneg fun b _ => Prob.zero_le_coe)
    (by
      have h := Fintype.sum_prod_type (f := fun x : α × β => (p x : ℝ))
      rw [← h]
      exact p.normalized)

/-- Second marginal of a distribution on a product. -/
noncomputable def PDsnd {α β : Type*} [Fintype α] [Fintype β]
    (p : ProbDistribution (α × β)) : ProbDistribution β :=
  ProbDistribution.mk' (fun b => ∑ a, (p (a, b) : ℝ))
    (fun b => Finset.sum_nonneg fun a _ => Prob.zero_le_coe)
    (by
      have h := Fintype.sum_prod_type (f := fun x : α × β => (p x : ℝ))
      rw [Finset.sum_comm, ← h]
      exact p.normalized)

@[simp] lemma PDfst_coe {α β : Type*} [Fintype α] [Fintype β]
    (p : ProbDistribution (α × β)) (a : α) :
    ((PDfst p) a : ℝ) = ∑ b, (p (a, b) : ℝ) := rfl

@[simp] lemma PDsnd_coe {α β : Type*} [Fintype α] [Fintype β]
    (p : ProbDistribution (α × β)) (b : β) :
    ((PDsnd p) b : ℝ) = ∑ a, (p (a, b) : ℝ) := rfl

/-- The matrix of a classical embedding is the diagonal of the distribution. -/
private lemma ofClassical_m {d : Type*} [Fintype d] [DecidableEq d]
    (p : ProbDistribution d) :
    (MState.ofClassical p).m = Matrix.diagonal (fun y => ((p y : ℝ) : ℂ)) := by
  rw [show (MState.ofClassical p).m = (MState.ofClassical p).M.mat from rfl,
    MState.coe_ofClassical, HermitianMat.diagonal_mat]
  rfl

/-- Relabeling commutes with the classical embedding. -/
theorem relabel_ofClassical {d₁ d₂ : Type*} [Fintype d₁] [Fintype d₂]
    [DecidableEq d₁] [DecidableEq d₂] (p : ProbDistribution d₁) (e : d₂ ≃ d₁) :
    (MState.ofClassical p).relabel e = MState.ofClassical (p.relabel e) := by
  refine MState.ext_m ?_
  rw [MState.relabel_m, ofClassical_m, ofClassical_m]
  funext x y
  show Matrix.diagonal (fun z => ((p z : ℝ) : ℂ)) (e x) (e y)
    = Matrix.diagonal (fun z => (((p.relabel e) z : ℝ) : ℂ)) x y
  by_cases h : x = y
  · subst h
    rw [Matrix.diagonal_apply_eq, Matrix.diagonal_apply_eq]
    rfl
  · rw [Matrix.diagonal_apply_ne _ (fun hc => h (e.injective hc)),
      Matrix.diagonal_apply_ne _ h]

/-- Tracing out the left factor of a classical embedding gives the embedding of the
second marginal. -/
theorem traceLeft_ofClassical {d₁ d₂ : Type*} [Fintype d₁] [Fintype d₂]
    [DecidableEq d₁] [DecidableEq d₂] (p : ProbDistribution (d₁ × d₂)) :
    (MState.ofClassical p).traceLeft = MState.ofClassical (PDsnd p) := by
  refine MState.ext_m ?_
  funext b b'
  show ∑ a, (MState.ofClassical p).m (a, b) (a, b')
    = (MState.ofClassical (PDsnd p)).m b b'
  rw [ofClassical_m, ofClassical_m]
  by_cases h : b = b'
  · subst h
    rw [Matrix.diagonal_apply_eq,
      Finset.sum_congr rfl fun a _ =>
        Matrix.diagonal_apply_eq (fun z => ((p z : ℝ) : ℂ)) (a, b)]
    rw [PDsnd_coe]
    push_cast
    rfl
  · rw [Matrix.diagonal_apply_ne _ h,
      Finset.sum_congr rfl fun a _ =>
        Matrix.diagonal_apply_ne (fun z => ((p z : ℝ) : ℂ))
          (fun hc => h (congrArg Prod.snd hc)),
      Finset.sum_const_zero]

/-- Tracing out the right factor of a classical embedding gives the embedding of the
first marginal. -/
theorem traceRight_ofClassical {d₁ d₂ : Type*} [Fintype d₁] [Fintype d₂]
    [DecidableEq d₁] [DecidableEq d₂] (p : ProbDistribution (d₁ × d₂)) :
    (MState.ofClassical p).traceRight = MState.ofClassical (PDfst p) := by
  refine MState.ext_m ?_
  funext a a'
  show ∑ b, (MState.ofClassical p).m (a, b) (a', b)
    = (MState.ofClassical (PDfst p)).m a a'
  rw [ofClassical_m, ofClassical_m]
  by_cases h : a = a'
  · subst h
    rw [Matrix.diagonal_apply_eq,
      Finset.sum_congr rfl fun b _ =>
        Matrix.diagonal_apply_eq (fun z => ((p z : ℝ) : ℂ)) (a, b)]
    rw [PDfst_coe]
    push_cast
    rfl
  · rw [Matrix.diagonal_apply_ne _ h,
      Finset.sum_congr rfl fun b _ =>
        Matrix.diagonal_apply_ne (fun z => ((p z : ℝ) : ℂ))
          (fun hc => h (congrArg Prod.fst hc)),
      Finset.sum_const_zero]

end HiddenChannelCapacity

/-! ### The general theorem: classical CI embeds to quantum Markov -/

namespace HiddenChannelCapacity

/-- The `AB`-marginal of a triple-product distribution. -/
noncomputable def margPDab {dA dB dC : Type*} [Fintype dA] [Fintype dB] [Fintype dC]
    (q : ProbDistribution (dA × dB × dC)) : ProbDistribution (dA × dB) :=
  PDfst (q.relabel (Equiv.prodAssoc dA dB dC))

/-- The `BC`-marginal of a triple-product distribution. -/
noncomputable def margPDbc {dA dB dC : Type*} [Fintype dA] [Fintype dB] [Fintype dC]
    (q : ProbDistribution (dA × dB × dC)) : ProbDistribution (dB × dC) :=
  PDsnd q

/-- The `B`-marginal of a triple-product distribution. -/
noncomputable def margPDb {dA dB dC : Type*} [Fintype dA] [Fintype dB] [Fintype dC]
    (q : ProbDistribution (dA × dB × dC)) : ProbDistribution dB :=
  PDsnd (margPDab q)

@[simp] lemma margPDab_coe {dA dB dC : Type*} [Fintype dA] [Fintype dB] [Fintype dC]
    (q : ProbDistribution (dA × dB × dC)) (ab : dA × dB) :
    ((margPDab q) ab : ℝ) = ∑ c, (q (ab.1, ab.2, c) : ℝ) := rfl

@[simp] lemma margPDbc_coe {dA dB dC : Type*} [Fintype dA] [Fintype dB] [Fintype dC]
    (q : ProbDistribution (dA × dB × dC)) (y : dB × dC) :
    ((margPDbc q) y : ℝ) = ∑ a, (q (a, y) : ℝ) := rfl

@[simp] lemma margPDb_coe {dA dB dC : Type*} [Fintype dA] [Fintype dB] [Fintype dC]
    (q : ProbDistribution (dA × dB × dC)) (b : dB) :
    ((margPDb q) b : ℝ) = ∑ a, ∑ c, (q (a, b, c) : ℝ) := rfl

/-- **Classical conditional independence embeds to quantum Markov**: a strictly
positive distribution on `A × B × C` whose separator factorization
`q · q_B = q_AB · q_BC` holds (Lauritzen 1996 Prop. 3.1) embeds via `ofClassical` to a
state with vanishing quantum conditional mutual information `I(A;C|B)` — the LZ global
Markov property (arXiv:2605.19453, Def. 2.7). Route: the diagonal bridges reduce every
`Sᵥₙ` to a Shannon entropy (vendored `Sᵥₙ_ofClassical`), and the factorization gives
the Shannon identity `H(ABC) + H(B) = H(AB) + H(BC)` by log-splitting. -/
theorem qcmi_ofClassical_of_factorization {dA dB dC : Type*}
    [Fintype dA] [Fintype dB] [Fintype dC]
    [DecidableEq dA] [DecidableEq dB] [DecidableEq dC]
    (q : ProbDistribution (dA × dB × dC))
    (hpos : ∀ x, 0 < (q x : ℝ))
    (hfac : ∀ a b c, (q (a, b, c) : ℝ) * ((margPDb q) b : ℝ)
      = ((margPDab q) (a, b) : ℝ) * ((margPDbc q) (b, c) : ℝ)) :
    qcmi (MState.ofClassical q) = 0 := by
  -- nonemptiness of the factors
  have hne : Nonempty (dA × dB × dC) := by
    by_contra h
    rw [not_nonempty_iff] at h
    have h1 := q.normalized
    rw [Finset.univ_eq_empty, Finset.sum_empty] at h1
    exact zero_ne_one h1
  obtain ⟨⟨a₀, b₀, c₀⟩⟩ := hne
  have : Nonempty dA := ⟨a₀⟩
  have : Nonempty dB := ⟨b₀⟩
  have : Nonempty dC := ⟨c₀⟩
  -- positivity of the marginals
  have hAB : ∀ a b, 0 < ((margPDab q) (a, b) : ℝ) := fun a b => by
    rw [margPDab_coe]
    exact Finset.sum_pos (fun c _ => hpos _) Finset.univ_nonempty
  have hBC : ∀ (y : dB × dC), 0 < ((margPDbc q) y : ℝ) := fun y => by
    rw [margPDbc_coe]
    exact Finset.sum_pos (fun a _ => hpos _) Finset.univ_nonempty
  have hB : ∀ b, 0 < ((margPDb q) b : ℝ) := fun b => by
    rw [margPDb_coe]
    exact Finset.sum_pos
      (fun a _ => Finset.sum_pos (fun c _ => hpos _) Finset.univ_nonempty)
      Finset.univ_nonempty
  -- pointwise log-splitting from the factorization
  have hlog : ∀ x : dA × dB × dC, Real.log (q x : ℝ)
      = Real.log ((margPDab q) (x.1, x.2.1) : ℝ)
        + Real.log ((margPDbc q) x.2 : ℝ) - Real.log ((margPDb q) x.2.1 : ℝ) := by
    intro x
    obtain ⟨a, b, c⟩ := x
    have hq : (q (a, b, c) : ℝ)
        = ((margPDab q) (a, b) : ℝ) * ((margPDbc q) (b, c) : ℝ) / ((margPDb q) b : ℝ) :=
      (eq_div_iff (hB b).ne').mpr (hfac a b c)
    rw [hq, Real.log_div (mul_pos (hAB a b) (hBC (b, c))).ne' (hB b).ne',
      Real.log_mul (hAB a b).ne' (hBC (b, c)).ne']
  -- collapse lemmas
  have hcolAB : (∑ x : dA × dB × dC, (q x : ℝ)
        * Real.log ((margPDab q) (x.1, x.2.1) : ℝ))
      = ∑ ab : dA × dB, ((margPDab q) ab : ℝ) * Real.log ((margPDab q) ab : ℝ) := by
    rw [Fintype.sum_prod_type (f := fun x : dA × dB × dC =>
        (q x : ℝ) * Real.log ((margPDab q) (x.1, x.2.1) : ℝ)),
      Fintype.sum_prod_type (f := fun ab : dA × dB =>
        ((margPDab q) ab : ℝ) * Real.log ((margPDab q) ab : ℝ))]
    refine Finset.sum_congr rfl fun a _ => ?_
    rw [Fintype.sum_prod_type (f := fun y : dB × dC =>
      (q (a, y) : ℝ) * Real.log ((margPDab q) (a, y.1) : ℝ))]
    refine Finset.sum_congr rfl fun b _ => ?_
    show (∑ c, (q (a, b, c) : ℝ) * Real.log ((margPDab q) (a, b) : ℝ))
      = ((margPDab q) (a, b) : ℝ) * Real.log ((margPDab q) (a, b) : ℝ)
    rw [← Finset.sum_mul, margPDab_coe]
  have hcolBC : (∑ x : dA × dB × dC, (q x : ℝ) * Real.log ((margPDbc q) x.2 : ℝ))
      = ∑ y : dB × dC, ((margPDbc q) y : ℝ) * Real.log ((margPDbc q) y : ℝ) := by
    rw [Fintype.sum_prod_type (f := fun x : dA × dB × dC =>
      (q x : ℝ) * Real.log ((margPDbc q) x.2 : ℝ)), Finset.sum_comm]
    refine Finset.sum_congr rfl fun y _ => ?_
    show (∑ a, (q (a, y) : ℝ) * Real.log ((margPDbc q) y : ℝ))
      = ((margPDbc q) y : ℝ) * Real.log ((margPDbc q) y : ℝ)
    rw [← Finset.sum_mul, margPDbc_coe]
  have hcolB : (∑ x : dA × dB × dC, (q x : ℝ) * Real.log ((margPDb q) x.2.1 : ℝ))
      = ∑ b : dB, ((margPDb q) b : ℝ) * Real.log ((margPDb q) b : ℝ) := by
    rw [Fintype.sum_prod_type (f := fun x : dA × dB × dC =>
      (q x : ℝ) * Real.log ((margPDb q) x.2.1 : ℝ))]
    rw [Finset.sum_congr rfl fun a _ => Fintype.sum_prod_type (f := fun y : dB × dC =>
      (q (a, y) : ℝ) * Real.log ((margPDb q) y.1 : ℝ))]
    rw [Finset.sum_congr rfl fun a _ => Finset.sum_congr rfl fun b _ =>
      (by rw [← Finset.sum_mul] :
        (∑ c, (q (a, b, c) : ℝ) * Real.log ((margPDb q) b : ℝ))
          = (∑ c, (q (a, b, c) : ℝ)) * Real.log ((margPDb q) b : ℝ)),
      Finset.sum_comm]
    refine Finset.sum_congr rfl fun b _ => ?_
    rw [← Finset.sum_mul, margPDb_coe]
  -- the Shannon identity
  have key : Hₛ q = Hₛ (margPDab q) + Hₛ (margPDbc q) - Hₛ (margPDb q) := by
    show (∑ x, Real.negMulLog (q x : ℝ))
      = (∑ ab, Real.negMulLog ((margPDab q) ab : ℝ))
        + (∑ y, Real.negMulLog ((margPDbc q) y : ℝ))
        - (∑ b, Real.negMulLog ((margPDb q) b : ℝ))
    simp only [Real.negMulLog, neg_mul]
    rw [Finset.sum_neg_distrib, Finset.sum_neg_distrib, Finset.sum_neg_distrib,
      Finset.sum_neg_distrib]
    rw [Finset.sum_congr rfl fun x _ => congrArg (fun t => (q x : ℝ) * t) (hlog x)]
    rw [Finset.sum_congr rfl fun x _ => (by ring :
      (q x : ℝ) * (Real.log ((margPDab q) (x.1, x.2.1) : ℝ)
          + Real.log ((margPDbc q) x.2 : ℝ) - Real.log ((margPDb q) x.2.1 : ℝ))
        = (q x : ℝ) * Real.log ((margPDab q) (x.1, x.2.1) : ℝ)
          + (q x : ℝ) * Real.log ((margPDbc q) x.2 : ℝ)
          - (q x : ℝ) * Real.log ((margPDb q) x.2.1 : ℝ)),
      Finset.sum_sub_distrib, Finset.sum_add_distrib, hcolAB, hcolBC, hcolB]
    ring
  -- the four states and the qcmi assembly
  have hABstate : (MState.ofClassical q).assoc'.traceRight
      = MState.ofClassical (margPDab q) := by
    rw [assoc'_eq_relabel, relabel_ofClassical, traceRight_ofClassical]
    rfl
  have hBCstate : (MState.ofClassical q).traceLeft
      = MState.ofClassical (margPDbc q) :=
    traceLeft_ofClassical q
  unfold qcmi qConditionalEnt
  rw [hABstate, hBCstate, traceLeft_ofClassical, Sᵥₙ_ofClassical, Sᵥₙ_ofClassical,
    Sᵥₙ_ofClassical, Sᵥₙ_ofClassical]
  show Hₛ (margPDab q) - Hₛ (margPDb q) - (Hₛ q - Hₛ (margPDbc q)) = 0
  linarith [key]

end HiddenChannelCapacity

/-! ### The quantum Markov property of the path completions -/

namespace HiddenChannelCapacity

/-- The site-split chart grouping the path as `A = {j₀+1}`, `B = {j₀+2}`,
`C = {j₀+3, j₀}` (the first separator of the path junction tree). -/
def cycSep1 (j₀ : Fin 4) :
    (ZMod 2 × ZMod 2 × ZMod 2 × ZMod 2) ≃ (∀ _i : Fin 4, ZMod 2) :=
  (quadChart (j₀ + 1) (j₀ + 2) (j₀ + 3) j₀
    ((by decide : ∀ j : Fin 4, j + 1 ≠ j + 2) j₀)
    ((by decide : ∀ j : Fin 4, j + 1 ≠ j + 3) j₀)
    ((by decide : ∀ j : Fin 4, j + 1 ≠ j) j₀)
    ((by decide : ∀ j : Fin 4, j + 2 ≠ j + 3) j₀)
    ((by decide : ∀ j : Fin 4, j + 2 ≠ j) j₀)
    ((by decide : ∀ j : Fin 4, j + 3 ≠ j) j₀)
    (fun i => (by decide :
      ∀ j i : Fin 4, i = j + 1 ∨ i = j + 2 ∨ i = j + 3 ∨ i = j) j₀ i)).symm

/-- The site-split chart grouping the path as `A = {j₀+1, j₀+2}`, `B = {j₀+3}`,
`C = {j₀}` (the second separator of the path junction tree). -/
def cycSep2 (j₀ : Fin 4) :
    ((ZMod 2 × ZMod 2) × ZMod 2 × ZMod 2) ≃ (∀ _i : Fin 4, ZMod 2) :=
  (Equiv.prodAssoc (ZMod 2) (ZMod 2) (ZMod 2 × ZMod 2)).trans (cycSep1 j₀)

/-- **Quantum Markov property at the first separator**: the diagonal embedding of the
junction-tree completion, reshaped along `cycSep1`, has vanishing quantum conditional
mutual information `I(A;C|B)` — the LZ global Markov property (arXiv:2605.19453
Def. 2.7) at the separator `{j₀+2}`. -/
theorem pathCompletion_qcmi_sep1 {r : ℝ} (hr0 : 0 < r) (hr1 : r < 1) (j₀ : Fin 4) :
    qcmi ((MState.ofClassical (pathDist hr0.le hr1.le j₀)).relabel (cycSep1 j₀)) = 0 := by
  rw [relabel_ofClassical]
  set q1 := (pathDist hr0.le hr1.le j₀).relabel (cycSep1 j₀) with hq1
  have hval1 : ∀ y : ZMod 2 × ZMod 2 × ZMod 2 × ZMod 2,
      (q1 y : ℝ) = 1 / 2 * Mfun r (tw (j₀ + 1)) (y.1 + y.2.1)
        * Mfun r (tw (j₀ + 2)) (y.2.1 + y.2.2.1)
        * Mfun r (tw (j₀ + 3)) (y.2.2.1 + y.2.2.2) := by
    intro y
    show pathMass r j₀ ((cycSep1 j₀) y) = _
    unfold cycSep1
    set E := quadChart (j₀ + 1) (j₀ + 2) (j₀ + 3) j₀ _ _ _ _ _ _ _ with hE
    have hq := Equiv.apply_symm_apply E y
    have e1 : E.symm y (j₀ + 1) = y.1 := congrArg Prod.fst hq
    have e2 : E.symm y (j₀ + 2) = y.2.1 := congrArg (fun p => p.2.1) hq
    have e3 : E.symm y (j₀ + 3) = y.2.2.1 := congrArg (fun p => p.2.2.1) hq
    have e4 : E.symm y j₀ = y.2.2.2 := congrArg (fun p => p.2.2.2) hq
    simp only [pathMass, e1, e2, e3, e4]
  have hpos1 : ∀ y, 0 < (q1 y : ℝ) := fun y => pathMass_pos hr0 hr1 j₀ _
  have hAB1 : ∀ a b : ZMod 2, ((margPDab q1) (a, b) : ℝ)
      = 1 / 2 * Mfun r (tw (j₀ + 1)) (a + b) := by
    intro a b
    rw [margPDab_coe,
      Fintype.sum_prod_type (f := fun c : ZMod 2 × ZMod 2 => (q1 (a, b, c) : ℝ)),
      Finset.sum_congr rfl fun c₁ _ => Finset.sum_congr rfl fun c₂ _ =>
        hval1 (a, b, (c₁, c₂)),
      Finset.sum_congr rfl fun c₁ _ =>
        (by rw [← Finset.mul_sum, sum_Mfun_right, mul_one] :
          (∑ c₂, 1 / 2 * Mfun r (tw (j₀ + 1)) (a + b)
            * Mfun r (tw (j₀ + 2)) (b + c₁) * Mfun r (tw (j₀ + 3)) (c₁ + c₂))
          = 1 / 2 * Mfun r (tw (j₀ + 1)) (a + b) * Mfun r (tw (j₀ + 2)) (b + c₁)),
      ← Finset.mul_sum, sum_Mfun_right, mul_one]
  have hBC1 : ∀ (b : ZMod 2) (c : ZMod 2 × ZMod 2), ((margPDbc q1) (b, c) : ℝ)
      = 1 / 2 * Mfun r (tw (j₀ + 2)) (b + c.1) * Mfun r (tw (j₀ + 3)) (c.1 + c.2) := by
    intro b c
    rw [margPDbc_coe,
      Finset.sum_congr rfl fun a _ => hval1 (a, b, c),
      Finset.sum_congr rfl fun a _ => (by ring :
        1 / 2 * Mfun r (tw (j₀ + 1)) (a + b) * Mfun r (tw (j₀ + 2)) (b + c.1)
          * Mfun r (tw (j₀ + 3)) (c.1 + c.2)
        = 1 / 2 * Mfun r (tw (j₀ + 2)) (b + c.1) * Mfun r (tw (j₀ + 3)) (c.1 + c.2)
          * Mfun r (tw (j₀ + 1)) (a + b)),
      ← Finset.mul_sum, sum_Mfun_left, mul_one]
  have hB1 : ∀ b : ZMod 2, ((margPDb q1) b : ℝ) = 1 / 2 := by
    intro b
    rw [margPDb_coe,
      Finset.sum_congr rfl fun a _ => (by
        rw [Fintype.sum_prod_type (f := fun c : ZMod 2 × ZMod 2 => (q1 (a, b, c) : ℝ)),
          Finset.sum_congr rfl fun c₁ _ => Finset.sum_congr rfl fun c₂ _ =>
            hval1 (a, b, (c₁, c₂)),
          Finset.sum_congr rfl fun c₁ _ =>
            (by rw [← Finset.mul_sum, sum_Mfun_right, mul_one] :
              (∑ c₂, 1 / 2 * Mfun r (tw (j₀ + 1)) (a + b)
                * Mfun r (tw (j₀ + 2)) (b + c₁) * Mfun r (tw (j₀ + 3)) (c₁ + c₂))
              = 1 / 2 * Mfun r (tw (j₀ + 1)) (a + b)
                * Mfun r (tw (j₀ + 2)) (b + c₁)),
          ← Finset.mul_sum, sum_Mfun_right, mul_one] :
        (∑ c : ZMod 2 × ZMod 2, (q1 (a, b, c) : ℝ))
          = 1 / 2 * Mfun r (tw (j₀ + 1)) (a + b)),
      Finset.sum_congr rfl fun a _ => (by ring :
        1 / 2 * Mfun r (tw (j₀ + 1)) (a + b)
          = Mfun r (tw (j₀ + 1)) (a + b) * (1 / 2)),
      ← Finset.sum_mul, sum_Mfun_left, one_mul]
  refine qcmi_ofClassical_of_factorization q1 hpos1 fun a b c => ?_
  rw [hval1 (a, b, c), hB1, hAB1, hBC1]
  ring

end HiddenChannelCapacity

namespace HiddenChannelCapacity

/-- **Quantum Markov property at the second separator** (`{j₀+3}`, grouping
`A = {j₀+1, j₀+2}`, `B = {j₀+3}`, `C = {j₀}`). -/
theorem pathCompletion_qcmi_sep2 {r : ℝ} (hr0 : 0 < r) (hr1 : r < 1) (j₀ : Fin 4) :
    qcmi ((MState.ofClassical (pathDist hr0.le hr1.le j₀)).relabel (cycSep2 j₀)) = 0 := by
  rw [relabel_ofClassical]
  set q2 := (pathDist hr0.le hr1.le j₀).relabel (cycSep2 j₀) with hq2
  have hval2 : ∀ y : (ZMod 2 × ZMod 2) × ZMod 2 × ZMod 2,
      (q2 y : ℝ) = 1 / 2 * Mfun r (tw (j₀ + 1)) (y.1.1 + y.1.2)
        * Mfun r (tw (j₀ + 2)) (y.1.2 + y.2.1)
        * Mfun r (tw (j₀ + 3)) (y.2.1 + y.2.2) := by
    intro y
    show pathMass r j₀
      ((cycSep1 j₀) ((Equiv.prodAssoc (ZMod 2) (ZMod 2) (ZMod 2 × ZMod 2)) y)) = _
    unfold cycSep1
    set E := quadChart (j₀ + 1) (j₀ + 2) (j₀ + 3) j₀ _ _ _ _ _ _ _ with hE
    set z := (Equiv.prodAssoc (ZMod 2) (ZMod 2) (ZMod 2 × ZMod 2)) y with hz
    have hq := Equiv.apply_symm_apply E z
    have e1 : E.symm z (j₀ + 1) = y.1.1 := congrArg Prod.fst hq
    have e2 : E.symm z (j₀ + 2) = y.1.2 := congrArg (fun p => p.2.1) hq
    have e3 : E.symm z (j₀ + 3) = y.2.1 := congrArg (fun p => p.2.2.1) hq
    have e4 : E.symm z j₀ = y.2.2 := congrArg (fun p => p.2.2.2) hq
    simp only [pathMass, e1, e2, e3, e4]
  have hpos2 : ∀ y, 0 < (q2 y : ℝ) := fun y => pathMass_pos hr0 hr1 j₀ _
  have hval2' : ∀ (a : ZMod 2 × ZMod 2) (b c : ZMod 2),
      (q2 (a, (b, c)) : ℝ) = 1 / 2 * Mfun r (tw (j₀ + 1)) (a.1 + a.2)
        * Mfun r (tw (j₀ + 2)) (a.2 + b)
        * Mfun r (tw (j₀ + 3)) (b + c) := fun a b c => hval2 (a, (b, c))
  have hAB2 : ∀ (a : ZMod 2 × ZMod 2) (b : ZMod 2), ((margPDab q2) (a, b) : ℝ)
      = 1 / 2 * Mfun r (tw (j₀ + 1)) (a.1 + a.2)
        * Mfun r (tw (j₀ + 2)) (a.2 + b) := by
    intro a b
    rw [margPDab_coe,
      Finset.sum_congr rfl fun c _ => hval2' a b c,
      ← Finset.mul_sum, sum_Mfun_right, mul_one]
  have hBC2 : ∀ b c : ZMod 2, ((margPDbc q2) (b, c) : ℝ)
      = 1 / 2 * Mfun r (tw (j₀ + 3)) (b + c) := by
    intro b c
    rw [margPDbc_coe,
      Fintype.sum_prod_type (f := fun a : ZMod 2 × ZMod 2 => (q2 (a, b, c) : ℝ)),
      Finset.sum_congr rfl fun a₁ _ => Finset.sum_congr rfl fun a₂ _ =>
        hval2 ((a₁, a₂), (b, c)),
      Finset.sum_comm,
      Finset.sum_congr rfl fun a₂ _ =>
        (by
          rw [Finset.sum_congr rfl fun a₁ _ => (by ring :
            1 / 2 * Mfun r (tw (j₀ + 1)) (a₁ + a₂)
              * Mfun r (tw (j₀ + 2)) (a₂ + b) * Mfun r (tw (j₀ + 3)) (b + c)
            = 1 / 2 * Mfun r (tw (j₀ + 2)) (a₂ + b)
              * Mfun r (tw (j₀ + 3)) (b + c) * Mfun r (tw (j₀ + 1)) (a₁ + a₂)),
            ← Finset.mul_sum, sum_Mfun_left, mul_one] :
          (∑ a₁, 1 / 2 * Mfun r (tw (j₀ + 1)) (a₁ + a₂)
            * Mfun r (tw (j₀ + 2)) (a₂ + b) * Mfun r (tw (j₀ + 3)) (b + c))
          = 1 / 2 * Mfun r (tw (j₀ + 2)) (a₂ + b) * Mfun r (tw (j₀ + 3)) (b + c)),
      Finset.sum_congr rfl fun a₂ _ => (by ring :
        1 / 2 * Mfun r (tw (j₀ + 2)) (a₂ + b) * Mfun r (tw (j₀ + 3)) (b + c)
        = 1 / 2 * Mfun r (tw (j₀ + 3)) (b + c) * Mfun r (tw (j₀ + 2)) (a₂ + b)),
      ← Finset.mul_sum, sum_Mfun_left, mul_one]
  have hB2 : ∀ b : ZMod 2, ((margPDb q2) b : ℝ) = 1 / 2 := by
    intro b
    rw [margPDb_coe,
      Finset.sum_congr rfl fun a _ =>
        (by rw [Finset.sum_congr rfl fun c _ => hval2' a b c,
            ← Finset.mul_sum, sum_Mfun_right, mul_one] :
          (∑ c : ZMod 2, (q2 (a, b, c) : ℝ))
          = 1 / 2 * Mfun r (tw (j₀ + 1)) (a.1 + a.2)
            * Mfun r (tw (j₀ + 2)) (a.2 + b)),
      Fintype.sum_prod_type (f := fun a : ZMod 2 × ZMod 2 =>
        1 / 2 * Mfun r (tw (j₀ + 1)) (a.1 + a.2) * Mfun r (tw (j₀ + 2)) (a.2 + b)),
      Finset.sum_comm,
      Finset.sum_congr rfl fun a₂ _ =>
        (by
          rw [Finset.sum_congr rfl fun a₁ _ => (by ring :
            1 / 2 * Mfun r (tw (j₀ + 1)) (a₁ + a₂) * Mfun r (tw (j₀ + 2)) (a₂ + b)
            = 1 / 2 * Mfun r (tw (j₀ + 2)) (a₂ + b) * Mfun r (tw (j₀ + 1)) (a₁ + a₂)),
            ← Finset.mul_sum, sum_Mfun_left, mul_one] :
          (∑ a₁, 1 / 2 * Mfun r (tw (j₀ + 1)) (a₁ + a₂)
            * Mfun r (tw (j₀ + 2)) (a₂ + b))
          = 1 / 2 * Mfun r (tw (j₀ + 2)) (a₂ + b)),
      Finset.sum_congr rfl fun a₂ _ => (by ring :
        1 / 2 * Mfun r (tw (j₀ + 2)) (a₂ + b)
        = Mfun r (tw (j₀ + 2)) (a₂ + b) * (1 / 2)),
      ← Finset.sum_mul, sum_Mfun_left, one_mul]
  refine qcmi_ofClassical_of_factorization q2 hpos2 fun a b c => ?_
  rw [hval2 (a, (b, c)), hB2, hAB2, hBC2]
  ring

/-- **The completions are quantum Markov completions**: at both separators of the path
junction tree, the diagonal embedding of the junction-tree completion satisfies the LZ
global Markov property (arXiv:2605.19453 Def. 2.7). -/
theorem pathCompletion_quantum_markov {r : ℝ} (hr0 : 0 < r) (hr1 : r < 1) (j₀ : Fin 4) :
    qcmi ((MState.ofClassical (pathDist hr0.le hr1.le j₀)).relabel (cycSep1 j₀)) = 0
    ∧ qcmi ((MState.ofClassical (pathDist hr0.le hr1.le j₀)).relabel (cycSep2 j₀)) = 0 :=
  ⟨pathCompletion_qcmi_sep1 hr0 hr1 j₀, pathCompletion_qcmi_sep2 hr0 hr1 j₀⟩

/-- **Full form of the subcover clause**: every proper subcover admits a completion
that is strictly positive, classically Markov, and quantum Markov (at both separators
of its junction tree), yet the full cycle admits no completion at all
(`cycleFam_not_completableC/Q`). No strengthening of the local ends reaches the base
observable that decides the full cycle: base-side sufficiency holds only when the base is
acyclic. -/
theorem subcover_markov_completable {r : ℝ} (hr0 : 0 < r) (hr1 : r < 1)
    (E : Finset (Fin 4)) (hE : E ≠ Finset.univ) :
    ∃ j₀, j₀ ∉ E ∧ ∃ q : ProbDistribution (∀ _i : Fin 4, ZMod 2),
      (∀ x, 0 < (q x : ℝ)) ∧ IsMarkovOnPath q j₀
      ∧ (∀ j ∈ E, q.marginal (cyc j) = edgeDist r hr0.le hr1.le j)
      ∧ qcmi ((MState.ofClassical q).relabel (cycSep1 j₀)) = 0
      ∧ qcmi ((MState.ofClassical q).relabel (cycSep2 j₀)) = 0 := by
  obtain ⟨j₀, hj₀⟩ : ∃ j₀, j₀ ∉ E := by
    by_contra h
    exact hE (Finset.eq_univ_iff_forall.mpr fun j => by_contra fun hj => h ⟨j, hj⟩)
  refine ⟨j₀, hj₀, pathDist hr0.le hr1.le j₀,
    fun x => pathMass_pos hr0 hr1 j₀ x,
    pathDist_isMarkov hr0.le hr1.le j₀,
    fun j hj => pathDist_marginal hr0.le hr1.le j₀ j (fun h => hj₀ (h ▸ hj)),
    pathCompletion_qcmi_sep1 hr0 hr1 j₀,
    pathCompletion_qcmi_sep2 hr0 hr1 j₀⟩

end HiddenChannelCapacity
