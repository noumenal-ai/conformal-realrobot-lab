/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Combinatorial
import ZPM.Measurements.HC.MutualInformation

/-!
# Hidden Channel Capacity — the fibered (shared-coordinate) model

The combinatorial layer (`ZPM.Measurements.HC.Combinatorial`) studies a single
coupling `κ ⊆ α × β` and proves the support-level equivalence
`hcComb κ = 0 ↔ IsRect κ`. This file generalizes to a **shared-coordinate**
(fibered) model `κ ⊆ S × A × B`: each value of the shared coordinate `s : S`
indexes a *fiber* `fiber κ s ⊆ A × B`, and the Five-Way equivalence is asked
fiberwise.

Read base-first: the shared coordinate `S` is the interface, `fiber κ s` is the
base slice it exposes at context `s`, and the fiberwise Five-Way reads each
slice's shape directly. That discovery then pins the information content of the
canonical distribution over the slice (`FiberCI`), the sole fibre-side leg.

In the fibered model the structural legs become genuinely distinct propositions:

* `FiberRect κ` — every fiber factors as a rectangle (iii);
* `Decomposable κ` — the support is closed under cross-recombination *within a
  fiber* (ii): if `(s,a₁,b₁)` and `(s,a₂,b₂)` are admissible so is `(s,a₁,b₂)`;
* `FiberProductSurjective κ` — fiber-product surjectivity (v): if `a` appears in
  fiber `s` and `b` appears in fiber `s`, then `(s,a,b)` is admissible;
* `FiberCI κ` — conditional independence (iv): the uniform distribution on each
  nonempty fiber has zero mutual information between its two coordinates.

The headline results are the three pairwise iff lemmas

* `fiberRect_iff_fps`, `fiberRect_iff_decomposable`, `fiberRect_iff_fiberCI`

and the Four-Way fiberwise `List.TFAE` (`fiveWay_fibered`). The interpolation
leg (i) is added in `ZPM.Measurements.HC.FiberedInterpolation`, completing the
genuine Five-Way equivalence.
-/

namespace HiddenChannelCapacity

section Structural

variable {S A B : Type*} [DecidableEq S] [DecidableEq A] [DecidableEq B]

/-- The **fiber** of `κ` over a shared coordinate `s`: the slice of admissible
`(a, b)` pairs whose shared coordinate is `s`. -/
def fiber (κ : Finset (S × A × B)) (s : S) : Finset (A × B) :=
  (κ.filter (fun t => t.1 = s)).image (fun t => (t.2.1, t.2.2))

/-- `κ` is **decomposable**: each fiber is closed under cross-recombination. If
`(s, a₁, b₁)` and `(s, a₂, b₂)` are admissible then so is the cross element
`(s, a₁, b₂)`. This is the fibered amalgamation / decomposability leg (ii). -/
def Decomposable (κ : Finset (S × A × B)) : Prop :=
  ∀ s a₁ b₁ a₂ b₂, (s, a₁, b₁) ∈ κ → (s, a₂, b₂) ∈ κ → (s, a₁, b₂) ∈ κ

/-- `κ` is **fiber-rectangular**: every fiber factors as the product of its
marginal supports. This is the fibered rectangularity leg (iii). -/
def FiberRect (κ : Finset (S × A × B)) : Prop := ∀ s, IsRect (fiber κ s)

/-- `κ` is **fiber-product surjective**: in each fiber, if `a` appears (with
some right value) and `b` appears (with some left value), then `(s, a, b)` is
admissible. This is the fiber-product surjectivity leg (v). -/
def FiberProductSurjective (κ : Finset (S × A × B)) : Prop :=
  ∀ s a b, (∃ b', (s, a, b') ∈ κ) → (∃ a', (s, a', b) ∈ κ) → (s, a, b) ∈ κ

/-- Membership in the fiber over `s` is membership of the reassembled triple. -/
@[simp] theorem mem_fiber {κ : Finset (S × A × B)} {s : S} {a : A} {b : B} :
    (a, b) ∈ fiber κ s ↔ (s, a, b) ∈ κ := by
  unfold fiber
  rw [Finset.mem_image]
  constructor
  · rintro ⟨t, ht, hpair⟩
    rw [Finset.mem_filter] at ht
    obtain ⟨htk, hts⟩ := ht
    obtain ⟨t1, t2, t3⟩ := t
    -- `hts : t1 = s`; `hpair : (t2, t3) = (a, b)`.
    simp only [Prod.mk.injEq] at hpair
    obtain ⟨ha, hb⟩ := hpair
    subst hts; subst ha; subst hb
    exact htk
  · intro hmem
    refine ⟨(s, a, b), ?_, rfl⟩
    rw [Finset.mem_filter]
    exact ⟨hmem, rfl⟩

/-- `a` lies in the left marginal of the fiber over `s` iff some triple
`(s, a, b)` is admissible. -/
theorem mem_projL_fiber {κ : Finset (S × A × B)} {s : S} {a : A} :
    a ∈ projL (fiber κ s) ↔ ∃ b, (s, a, b) ∈ κ := by
  rw [projL, Finset.mem_image]
  constructor
  · rintro ⟨p, hp, rfl⟩
    refine ⟨p.2, ?_⟩
    rw [← mem_fiber]
    exact hp
  · rintro ⟨b, hb⟩
    exact ⟨(a, b), mem_fiber.mpr hb, rfl⟩

/-- `b` lies in the right marginal of the fiber over `s` iff some triple
`(s, a, b)` is admissible. -/
theorem mem_projR_fiber {κ : Finset (S × A × B)} {s : S} {b : B} :
    b ∈ projR (fiber κ s) ↔ ∃ a, (s, a, b) ∈ κ := by
  rw [projR, Finset.mem_image]
  constructor
  · rintro ⟨p, hp, rfl⟩
    refine ⟨p.1, ?_⟩
    rw [← mem_fiber]
    exact hp
  · rintro ⟨a, ha⟩
    exact ⟨(a, b), mem_fiber.mpr ha, rfl⟩

/-- **Fiber rectangularity ⇔ fiber-product surjectivity** (iii ⇔ v). Each fiber
factors as a rectangle exactly when the support is fiber-product surjective. -/
theorem fiberRect_iff_fps (κ : Finset (S × A × B)) :
    FiberRect κ ↔ FiberProductSurjective κ := by
  unfold FiberRect FiberProductSurjective
  constructor
  · intro h s a b ⟨b', hb'⟩ ⟨a', ha'⟩
    have hcross := (isRect_iff_cross_closed (fiber κ s)).mp (h s)
    have ha : a ∈ projL (fiber κ s) := mem_projL_fiber.mpr ⟨b', hb'⟩
    have hb : b ∈ projR (fiber κ s) := mem_projR_fiber.mpr ⟨a', ha'⟩
    have := hcross a ha b hb
    rwa [mem_fiber] at this
  · intro h s
    rw [isRect_iff_cross_closed]
    intro a ha b hb
    rw [mem_fiber]
    rw [mem_projL_fiber] at ha
    rw [mem_projR_fiber] at hb
    exact h s a b ha hb

omit [DecidableEq S] [DecidableEq A] [DecidableEq B] in
/-- **Decomposability ⇔ fiber-product surjectivity**: direct first-order logic. -/
theorem decomposable_iff_fps (κ : Finset (S × A × B)) :
    Decomposable κ ↔ FiberProductSurjective κ := by
  unfold Decomposable FiberProductSurjective
  constructor
  · intro hdec s a b ⟨b', hb'⟩ ⟨a', ha'⟩
    exact hdec s a b' a' b hb' ha'
  · intro hfps s a₁ b₁ a₂ b₂ h1 h2
    exact hfps s a₁ b₂ ⟨b₁, h1⟩ ⟨a₂, h2⟩

/-- **Fiber rectangularity ⇔ decomposability** (iii ⇔ ii). -/
theorem fiberRect_iff_decomposable (κ : Finset (S × A × B)) :
    FiberRect κ ↔ Decomposable κ :=
  (fiberRect_iff_fps κ).trans (decomposable_iff_fps κ).symm

end Structural

section Information

variable {S A B : Type*} [DecidableEq S]
  [Fintype A] [Fintype B] [DecidableEq A] [DecidableEq B]
  [MeasurableSpace A] [MeasurableSpace B]
  [DiscreteMeasurableSpace A] [DiscreteMeasurableSpace B]

/-- `κ` satisfies **fiber conditional independence**: the uniform distribution on
each nonempty fiber has zero mutual information between its two coordinates. This
is the conditional-independence leg (iv). -/
def FiberCI (κ : Finset (S × A × B)) : Prop :=
  ∀ s (h : (fiber κ s).Nonempty),
    InformationTheory.mutualInformationReal (uniformMeasure (fiber κ s) h) = 0

omit [Fintype A] [Fintype B] [MeasurableSpace A] [MeasurableSpace B]
  [DiscreteMeasurableSpace A] [DiscreteMeasurableSpace B] in
/-- The empty coupling is rectangular: both marginal supports are empty. -/
theorem isRect_empty : IsRect (∅ : Finset (A × B)) := by
  unfold IsRect
  rw [projL, projR, Finset.image_empty, Finset.empty_product]

/-- **Fiber rectangularity ⇔ fiber conditional independence** (iii ⇔ iv). On each
nonempty fiber the mutual-information bridge applies; empty fibers are vacuously
rectangular. -/
theorem fiberRect_iff_fiberCI (κ : Finset (S × A × B)) :
    FiberRect κ ↔ FiberCI κ := by
  unfold FiberRect FiberCI
  constructor
  · intro h s hne
    exact (mutualInformationReal_uniform_eq_zero_iff_isRect (fiber κ s) hne).mpr (h s)
  · intro h s
    by_cases hne : (fiber κ s).Nonempty
    · exact (mutualInformationReal_uniform_eq_zero_iff_isRect (fiber κ s) hne).mp (h s hne)
    · rw [Finset.not_nonempty_iff_eq_empty] at hne
      rw [hne]
      exact isRect_empty

/-- **Four-Way fiberwise equivalence.** The structural and informational legs of
fibered HC are mutually equivalent: fiber rectangularity (iii), decomposability
(ii), fiber-product surjectivity (v), and fiber conditional independence (iv).
The interpolation leg (i) is added in `FiberedInterpolation`. -/
theorem fiveWay_fibered (κ : Finset (S × A × B)) :
    List.TFAE [FiberRect κ, Decomposable κ, FiberProductSurjective κ, FiberCI κ] := by
  tfae_have 1 ↔ 2 := fiberRect_iff_decomposable κ
  tfae_have 1 ↔ 3 := fiberRect_iff_fps κ
  tfae_have 1 ↔ 4 := fiberRect_iff_fiberCI κ
  tfae_finish

end Information

end HiddenChannelCapacity
