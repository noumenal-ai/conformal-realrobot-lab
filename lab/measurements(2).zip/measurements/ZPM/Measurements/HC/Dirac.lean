/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.VorobevConverse

/-!
# Dirac's lemma and the chordal/conformal dichotomy

The final leg of the Vorob'ev converse (CYCLIC_CONVERSE_URS D27). Over the primal graph of a
cover, with the single global hypothesis that NO chordless cycle exists, every nonempty
vertex set has a SIMPLICIAL vertex (`dirac_strong`). The proof is the classical minimal-
separator argument, run entirely over the fixed primal graph so that the induction only
shrinks a `Finset` of vertices: a minimal (a,b)-separator is a clique — two minimal-length
paths through the two sides assemble into a cycle whose chord, forced by the hypothesis, is
killed by path-minimality (splices), side-disjointness, or the assumed non-adjacency.

Consequences: `earFree_dichotomy` — an ear-free cover is non-conformal or has a chordless
cycle (via the one-step GYO collapse `isEarOf_of_simplicial`); and the CAPSTONE
`exists_consistent_not_glues_of_not_acyclic` plus the headline
`acyclic_iff_forall_consistent_glues`, closing the discrete Vorob'ev programme: the cover's base
structure decides what local measurement achieves, acyclicity being exactly the base condition
under which local pairwise consistency forces a global structure.
-/

namespace HiddenChannelCapacity

open Finset

variable {ι : Type*} [DecidableEq ι]

/-! ### Walks, paths, reachability -/

/-- A walk constrained to `P`: chained adjacencies, every vertex satisfies `P`. -/
def IsWalkOn (𝒞 : Finset (Finset ι)) (P : ι → Prop) (p : List ι) : Prop :=
  List.IsChain (Adj 𝒞) p ∧ ∀ v ∈ p, P v

/-- Reachability within `P`: a duplicate-free walk with the given endpoints. -/
def ReachOn (𝒞 : Finset (Finset ι)) (P : ι → Prop) (u v : ι) : Prop :=
  ∃ p : List ι, IsWalkOn 𝒞 P p ∧ p.Nodup ∧ p.head? = some u ∧ p.getLast? = some v

omit [DecidableEq ι] in
private lemma isChain_take {R : ι → ι → Prop} {p : List ι} (h : List.IsChain R p) (n : ℕ) :
    List.IsChain R (p.take n) := by
  rw [List.isChain_iff_getElem] at h ⊢
  intro i hi
  have hlt : i + 1 < p.length := by
    have := hi
    rw [List.length_take] at this
    omega
  have h1 : (p.take n)[i] = p[i]'(by omega) := List.getElem_take
  have h2 : (p.take n)[i + 1]'hi = p[i + 1]'hlt := List.getElem_take
  rw [h1, h2]
  exact h i hlt

omit [DecidableEq ι] in
private lemma isChain_drop {R : ι → ι → Prop} {p : List ι} (h : List.IsChain R p) (n : ℕ) :
    List.IsChain R (p.drop n) := by
  rw [List.isChain_iff_getElem] at h ⊢
  intro i hi
  have hlen : (p.drop n).length = p.length - n := List.length_drop
  have hlt : n + (i + 1) < p.length := by omega
  have h1 : (p.drop n)[i]'(by omega) = p[n + i]'(by omega) := List.getElem_drop
  have h2 : (p.drop n)[i + 1]'hi = p[n + (i + 1)]'hlt := List.getElem_drop
  rw [h1, h2]
  have := h (n + i) (by omega)
  simpa [Nat.add_assoc] using this

omit [DecidableEq ι] in
/-- Every chained walk contains a duplicate-free path with the same endpoints and vertices. -/
lemma reachOn_of_walk {𝒞 : Finset (Finset ι)} {P : ι → Prop} :
    ∀ (p : List ι), IsWalkOn 𝒞 P p → ∀ {u v : ι}, p.head? = some u → p.getLast? = some v →
      ReachOn 𝒞 P u v := by
  intro p
  induction hn : p.length using Nat.strong_induction_on generalizing p with
  | _ n ih =>
    intro hw u v hu hv
    by_cases hnd : p.Nodup
    · exact ⟨p, hw, hnd, hu, hv⟩
    · -- extract a duplicate position pair and splice
      have hdup : ¬ ∀ (i j : ℕ) (hi : i < p.length) (hj : j < p.length), i < j →
          p[i] ≠ p[j] := by
        rw [← List.pairwise_iff_getElem]
        exact hnd
      simp only [not_forall, not_not] at hdup
      obtain ⟨i, j, hi, hj, hij, heq⟩ := hdup
      set q : List ι := p.take (i + 1) ++ p.drop (j + 1) with hq
      have hlen_take : (p.take (i + 1)).length = i + 1 := by
        rw [List.length_take]
        omega
      have hlen_drop : (p.drop (j + 1)).length = p.length - (j + 1) := List.length_drop
      have hqlen : q.length < p.length := by
        rw [hq, List.length_append, hlen_take, hlen_drop]
        omega
      have htake_last : (p.take (i + 1)).getLast? = some (p[i]'hi) := by
        have hb : i < (p.take (i + 1)).length := by omega
        rw [List.getLast?_eq_getElem?, hlen_take, show i + 1 - 1 = i from rfl,
          List.getElem?_eq_getElem hb]
        have h1 : (p.take (i + 1))[i]'hb = p[i]'hi := List.getElem_take
        rw [h1]
      have htake_head : (p.take (i + 1)).head? = p.head? := by
        have hb : 0 < (p.take (i + 1)).length := by omega
        rw [List.head?_eq_getElem?, List.head?_eq_getElem?,
          List.getElem?_eq_getElem hb, List.getElem?_eq_getElem (show 0 < p.length by omega)]
        have h1 : (p.take (i + 1))[0]'hb = p[0]'(by omega) := List.getElem_take
        rw [h1]
      have hchain : List.IsChain (Adj 𝒞) q := by
        rw [hq, List.isChain_append]
        refine ⟨isChain_take hw.1 _, isChain_drop hw.1 _, ?_⟩
        intro x hx y hy
        rw [Option.mem_def, htake_last, Option.some_inj] at hx
        have hjlt : j + 1 < p.length := by
          by_contra hge
          have : p.drop (j + 1) = [] := List.drop_eq_nil_of_le (by omega)
          rw [Option.mem_def, this] at hy
          exact absurd hy (by simp)
        have hyval : y = p[j + 1]'hjlt := by
          have hb : 0 < (p.drop (j + 1)).length := by omega
          rw [Option.mem_def, List.head?_eq_getElem?, List.getElem?_eq_getElem hb] at hy
          have h1 : (p.drop (j + 1))[0]'hb = p[(j + 1) + 0]'(by omega) := List.getElem_drop
          rw [h1] at hy
          simpa using (Option.some_inj.mp hy).symm
        subst hyval
        rw [← hx, heq]
        exact (List.isChain_iff_getElem.mp hw.1) j hjlt
      have hmem : ∀ w ∈ q, P w := by
        intro w hw'
        rw [hq, List.mem_append] at hw'
        rcases hw' with h | h
        · exact hw.2 w (List.mem_of_mem_take h)
        · exact hw.2 w (List.mem_of_mem_drop h)
      have hhead : q.head? = some u := by
        rw [hq, List.head?_append, htake_head, hu]
        rfl
      have hlast : q.getLast? = some v := by
        rw [hq, List.getLast?_append]
        by_cases hdrop : j + 1 < p.length
        · have hdl : (p.drop (j + 1)).getLast? = p.getLast? := by
            rw [List.getLast?_drop, if_neg (by omega)]
          rw [hdl, hv]
          rfl
        · have hdnil : p.drop (j + 1) = [] := List.drop_eq_nil_of_le (by omega)
          rw [hdnil]
          simp only [List.getLast?_nil, Option.none_or]
          have hvv : p.getLast? = some (p[j]'hj) := by
            rw [List.getLast?_eq_getElem?, show p.length - 1 = j from by omega,
              List.getElem?_eq_getElem hj]
          rw [hvv, Option.some_inj] at hv
          rw [htake_last, heq, hv]
      exact ih q.length (by omega) q rfl ⟨hchain, hmem⟩ hhead hlast

/-! ### Reachability combinators -/

omit [DecidableEq ι] in
lemma reachOn_refl {𝒞 : Finset (Finset ι)} {P : ι → Prop} {u : ι} (hu : P u) :
    ReachOn 𝒞 P u u :=
  ⟨[u], ⟨by simp, by simpa⟩, List.nodup_singleton u, rfl, rfl⟩

omit [DecidableEq ι] in
lemma reachOn_symm {𝒞 : Finset (Finset ι)} {P : ι → Prop} {u v : ι} :
    ReachOn 𝒞 P u v → ReachOn 𝒞 P v u := by
  rintro ⟨p, ⟨hch, hP⟩, hnd, hu, hv⟩
  refine ⟨p.reverse, ⟨?_, fun w hw => hP w (List.mem_reverse.mp hw)⟩,
    List.nodup_reverse.mpr hnd, ?_, ?_⟩
  · rw [List.isChain_reverse]
    exact hch.imp (fun {a b} hab => hab.symm')
  · rw [List.head?_reverse, hv]
  · rw [List.getLast?_reverse, hu]

omit [DecidableEq ι] in
lemma reachOn_trans {𝒞 : Finset (Finset ι)} {P : ι → Prop} {u v w : ι} :
    ReachOn 𝒞 P u v → ReachOn 𝒞 P v w → ReachOn 𝒞 P u w := by
  rintro ⟨p, ⟨hchp, hPp⟩, hndp, hup, hvp⟩ ⟨q, ⟨hchq, hPq⟩, -, hvq, hwq⟩
  match q, hvq, hwq with
  | [x], hvq, hwq =>
    have hx : x = v := by simpa using hvq
    have hw' : x = w := by simpa using hwq
    exact ⟨p, ⟨hchp, hPp⟩, hndp, hup, by rw [hvp, ← hw', hx]⟩
  | x :: y :: t, hvq, hwq =>
    have hx : x = v := by simpa using hvq
    have hadj : Adj 𝒞 x y := List.rel_of_isChain_cons_cons hchq
    refine reachOn_of_walk (p ++ y :: t) ⟨?_, ?_⟩ ?_ ?_
    · rw [List.isChain_append]
      refine ⟨hchp, List.isChain_of_isChain_cons hchq, ?_⟩
      intro s hs r hr
      rw [Option.mem_def, hvp, Option.some_inj] at hs
      rw [Option.mem_def] at hr
      have hr' : y = r := by simpa using hr
      rw [← hs, ← hr', ← hx]
      exact hadj
    · intro z hz
      rcases List.mem_append.mp hz with h | h
      · exact hPp z h
      · exact hPq z (List.mem_cons_of_mem x h)
    · rw [List.head?_append, hup]
      rfl
    · rw [List.getLast?_append]
      have : (y :: t).getLast? = some w := by
        rw [← hwq]
        rfl
      rw [this]
      rfl

omit [DecidableEq ι] in
lemma reachOn_extend {𝒞 : Finset (Finset ι)} {P : ι → Prop} {u v w : ι}
    (h : ReachOn 𝒞 P u v) (hadj : Adj 𝒞 v w) (hw : P w) : ReachOn 𝒞 P u w := by
  obtain ⟨p, ⟨hch, hP⟩, -, hu, hv⟩ := h
  refine reachOn_of_walk (p ++ [w]) ⟨?_, ?_⟩ ?_ ?_
  · rw [List.isChain_append]
    refine ⟨hch, by simp, ?_⟩
    intro s hs r hr
    rw [Option.mem_def, hv, Option.some_inj] at hs
    have hr' : w = r := by simpa using hr
    rw [← hs, ← hr']
    exact hadj
  · intro z hz
    rcases List.mem_append.mp hz with h | h
    · exact hP z h
    · rw [List.mem_singleton.mp h]
      exact hw
  · rw [List.head?_append, hu]
    rfl
  · rw [List.getLast?_append]
    rfl

omit [DecidableEq ι] in
/-- Every vertex on a walk is reachable from its head. -/
lemma reachOn_of_mem_walk {𝒞 : Finset (Finset ι)} {P : ι → Prop} {u v : ι} {p : List ι}
    (hwk : IsWalkOn 𝒞 P p) (hu : p.head? = some u) (hv : v ∈ p) : ReachOn 𝒞 P u v := by
  obtain ⟨k, hk, rfl⟩ := List.mem_iff_getElem.mp hv
  refine reachOn_of_walk (p.take (k + 1)) ⟨isChain_take hwk.1 _, ?_⟩ ?_ ?_
  · intro z hz
    exact hwk.2 z (List.mem_of_mem_take hz)
  · have hb : 0 < (p.take (k + 1)).length := by
      rw [List.length_take]
      omega
    rw [List.head?_eq_getElem?, List.getElem?_eq_getElem hb]
    rw [List.head?_eq_getElem?, List.getElem?_eq_getElem (show 0 < p.length by omega)] at hu
    have h1 : (p.take (k + 1))[0]'hb = p[0]'(by omega) := List.getElem_take
    rw [h1]
    exact hu
  · have hlt : (p.take (k + 1)).length = k + 1 := by
      rw [List.length_take]
      omega
    rw [List.getLast?_eq_getElem?, hlt, show k + 1 - 1 = k from rfl,
      List.getElem?_eq_getElem (show k < (p.take (k + 1)).length by omega)]
    have h1 : (p.take (k + 1))[k]'(by omega) = p[k]'hk := List.getElem_take
    rw [h1]

/-! ### Minimal connectors -/

omit [DecidableEq ι] in
private lemma exists_min_path {Q : List ι → Prop} (h : ∃ p, Q p) :
    ∃ p, Q p ∧ ∀ q, Q q → p.length ≤ q.length := by
  obtain ⟨p₀, hp₀⟩ := h
  have hne : {n | ∃ p, Q p ∧ p.length = n}.Nonempty := ⟨p₀.length, p₀, hp₀, rfl⟩
  obtain ⟨p, hp, hlen⟩ := Nat.sInf_mem hne
  exact ⟨p, hp, fun q hq => hlen ▸ Nat.sInf_le ⟨q, hq, rfl⟩⟩

omit [DecidableEq ι] in
/-- A connector: an x-y path with interior inside `Q`, from adjacent entry points and
interior reachability. -/
private lemma exists_connector {𝒞 : Finset (Finset ι)} {Q : ι → Prop} {x y u₁ u₂ : ι}
    (hxy : x ≠ y) (hxu : Adj 𝒞 x u₁) (hyu : Adj 𝒞 y u₂)
    (hreach : ReachOn 𝒞 Q u₁ u₂) (hQx : ¬ Q x) (hQy : ¬ Q y) :
    ∃ p : List ι, List.IsChain (Adj 𝒞) p ∧ p.Nodup ∧ p.head? = some x ∧
      p.getLast? = some y ∧ ∀ v ∈ p, v = x ∨ v = y ∨ Q v := by
  obtain ⟨m, ⟨hch, hQm⟩, hnd, hu₁, hu₂⟩ := hreach
  refine ⟨[x] ++ m ++ [y], ?_, ?_, ?_, ?_, ?_⟩
  · rw [List.isChain_append]
    refine ⟨?_, by simp, ?_⟩
    · rw [List.isChain_append]
      refine ⟨by simp, hch, ?_⟩
      intro s hs r hr
      have hs' : x = s := by simpa using hs
      rw [Option.mem_def, hu₁, Option.some_inj] at hr
      rw [← hs', ← hr]
      exact hxu
    · intro s hs r hr
      rw [List.getLast?_append, hu₂] at hs
      have hs' : u₂ = s := by simpa using hs
      have hr' : y = r := by simpa using hr
      rw [← hs', ← hr']
      exact hyu.symm'
  · rw [List.nodup_append]
    refine ⟨?_, by simp, ?_⟩
    · rw [List.nodup_append]
      refine ⟨by simp, hnd, ?_⟩
      intro s hs r hr
      have hs' : s = x := by simpa using hs
      intro hsr
      rw [hs'] at hsr
      exact hQx (hsr ▸ hQm r hr)
    · intro s hs r hr
      have hr' : r = y := by simpa using hr
      intro hsr
      rw [hsr, hr'] at hs
      rcases List.mem_append.mp hs with h | h
      · have : y = x := by simpa using h
        exact hxy this.symm
      · exact hQy (hQm y h)
  · rw [List.append_assoc, List.head?_append]
    rfl
  · rw [List.getLast?_append]
    rfl
  · intro v hv
    rcases List.mem_append.mp hv with h | h
    · rcases List.mem_append.mp h with h' | h'
      · exact Or.inl (by simpa using h')
      · exact Or.inr (Or.inr (hQm v h'))
    · exact Or.inr (Or.inl (by simpa using h))

omit [DecidableEq ι] in
/-- **Minimality kills chords**: a length-minimal constrained x-y path has no adjacency
between positions at distance ≥ 2. -/
private lemma no_chord_of_minimal {𝒞 : Finset (Finset ι)} {Q : ι → Prop} {x y : ι}
    {p : List ι}
    (hch : List.IsChain (Adj 𝒞) p) (hx : p.head? = some x) (hy : p.getLast? = some y)
    (hvert : ∀ v ∈ p, v = x ∨ v = y ∨ Q v)
    (hmin : ∀ q : List ι, (List.IsChain (Adj 𝒞) q ∧ q.Nodup ∧ q.head? = some x ∧
      q.getLast? = some y ∧ ∀ v ∈ q, v = x ∨ v = y ∨ Q v) → p.length ≤ q.length)
    (hnd : p.Nodup)
    {i j : ℕ} (hi : i < p.length) (hj : j < p.length) (hij : i + 2 ≤ j) :
    ¬ Adj 𝒞 (p[i]'hi) (p[j]'hj) := by
  intro hadj
  set q : List ι := p.take (i + 1) ++ p.drop j with hq
  have hlen_take : (p.take (i + 1)).length = i + 1 := by
    rw [List.length_take]
    omega
  have hqsub : List.Sublist q p := by
    have hdj : p.drop j = (p.drop (i + 1)).drop (j - (i + 1)) := by
      rw [List.drop_drop]
      congr 1
      omega
    have h1 : List.Sublist (p.drop j) (p.drop (i + 1)) := by
      rw [hdj]
      exact List.drop_sublist _ _
    have h2 : List.Sublist q (p.take (i + 1) ++ p.drop (i + 1)) := h1.append_left _
    rwa [List.take_append_drop] at h2
  have htake_last : (p.take (i + 1)).getLast? = some (p[i]'hi) := by
    have hb : i < (p.take (i + 1)).length := by omega
    rw [List.getLast?_eq_getElem?, hlen_take, show i + 1 - 1 = i from rfl,
      List.getElem?_eq_getElem hb]
    have h1 : (p.take (i + 1))[i]'hb = p[i]'hi := List.getElem_take
    rw [h1]
  have hdrop_head : (p.drop j).head? = some (p[j]'hj) := by
    have hb : 0 < (p.drop j).length := by
      rw [List.length_drop]
      omega
    rw [List.head?_eq_getElem?, List.getElem?_eq_getElem hb]
    have h1 : (p.drop j)[0]'hb = p[j + 0]'(by omega) := List.getElem_drop
    rw [h1]
    rfl
  have hchq : List.IsChain (Adj 𝒞) q := by
    rw [hq, List.isChain_append]
    refine ⟨isChain_take hch _, isChain_drop hch _, ?_⟩
    intro s hs r hr
    rw [Option.mem_def, htake_last, Option.some_inj] at hs
    rw [Option.mem_def, hdrop_head, Option.some_inj] at hr
    rw [← hs, ← hr]
    exact hadj
  have hhq : q.head? = some x := by
    have hb : 0 < (p.take (i + 1)).length := by omega
    rw [hq, List.head?_append]
    have : (p.take (i + 1)).head? = p.head? := by
      rw [List.head?_eq_getElem?, List.head?_eq_getElem?, List.getElem?_eq_getElem hb,
        List.getElem?_eq_getElem (show 0 < p.length by omega)]
      have h1 : (p.take (i + 1))[0]'hb = p[0]'(by omega) := List.getElem_take
      rw [h1]
    rw [this, hx]
    rfl
  have hlq : q.getLast? = some y := by
    rw [hq, List.getLast?_append, List.getLast?_drop, if_neg (by omega)]
    rw [hy]
    rfl
  have hvq : ∀ v ∈ q, v = x ∨ v = y ∨ Q v := by
    intro v hv
    exact hvert v (hqsub.subset hv)
  have hlenq : q.length < p.length := by
    rw [hq, List.length_append, hlen_take, List.length_drop]
    omega
  exact absurd (hmin q ⟨hchq, hqsub.nodup hnd, hhq, hlq, hvq⟩) (by omega)

/-! ### The separator is a clique -/

omit [DecidableEq ι] in
/-- Positional form of the head. -/
private lemma head_getElem {p : List ι} {x : ι} (h : p.head? = some x)
    (h0 : 0 < p.length) : p[0]'h0 = x := by
  rw [List.head?_eq_getElem?, List.getElem?_eq_getElem h0, Option.some_inj] at h
  exact h

omit [DecidableEq ι] in
private lemma getLast_getElem {p : List ι} {y : ι} (h : p.getLast? = some y)
    (h0 : 0 < p.length) : p[p.length - 1]'(by omega) = y := by
  rw [List.getLast?_eq_getElem?, List.getElem?_eq_getElem (by omega : p.length - 1 < p.length),
    Option.some_inj] at h
  exact h

set_option maxHeartbeats 1000000 in
/-- **The assembled-cycle contradiction**: two length-minimal x-y connectors through
disjoint, mutually non-adjacent sides cannot coexist with chordless-cycle-freeness when
x and y are non-adjacent. -/
private lemma sep_clique_step {𝒞 : Finset (Finset ι)}
    (hchord : ¬ ∃ l : List ι, IsChordlessCycle 𝒞 l)
    {QA QB : ι → Prop} {x y : ι} (hxy : x ≠ y) (hnadj : ¬ Adj 𝒞 x y)
    (hQBx : ¬ QB x) (hQBy : ¬ QB y)
    (hABdisj : ∀ v, QA v → QB v → False)
    (hABnadj : ∀ u v, QA u → QB v → ¬ Adj 𝒞 u v)
    (pA : List ι)
    (hchA : List.IsChain (Adj 𝒞) pA) (hndA : pA.Nodup) (hxA : pA.head? = some x)
    (hyA : pA.getLast? = some y) (hvA : ∀ v ∈ pA, v = x ∨ v = y ∨ QA v)
    (hminA : ∀ q : List ι, (List.IsChain (Adj 𝒞) q ∧ q.Nodup ∧ q.head? = some x ∧
      q.getLast? = some y ∧ ∀ v ∈ q, v = x ∨ v = y ∨ QA v) → pA.length ≤ q.length)
    (pB : List ι)
    (hchB : List.IsChain (Adj 𝒞) pB) (hndB : pB.Nodup) (hxB : pB.head? = some x)
    (hyB : pB.getLast? = some y) (hvB : ∀ v ∈ pB, v = x ∨ v = y ∨ QB v)
    (hminB : ∀ q : List ι, (List.IsChain (Adj 𝒞) q ∧ q.Nodup ∧ q.head? = some x ∧
      q.getLast? = some y ∧ ∀ v ∈ q, v = x ∨ v = y ∨ QB v) → pB.length ≤ q.length) :
    False := by
  -- both connectors have length ≥ 3
  have hlen3 : ∀ (p : List ι), List.IsChain (Adj 𝒞) p → p.head? = some x →
      p.getLast? = some y → 3 ≤ p.length := by
    intro p hch hx hy
    match p, hx, hy, hch with
    | [a], hx, hy, _ =>
      have h1 : a = x := by simpa using hx
      have h2 : a = y := by simpa using hy
      exact absurd (h1 ▸ h2) hxy
    | [a, b], hx, hy, hch =>
      have h1 : a = x := by simpa using hx
      have h2 : b = y := by simpa using hy
      have := List.isChain_pair.mp hch
      rw [h1, h2] at this
      exact absurd this hnadj
    | a :: b :: d :: t, _, _, _ => simp
  have h3A : 3 ≤ pA.length := hlen3 pA hchA hxA hyA
  have h3B : 3 ≤ pB.length := hlen3 pB hchB hxB hyB
  set nA := pA.length with hnA
  set nB := pB.length with hnB
  have hA0 : pA[0]'(by omega) = x := head_getElem hxA (by omega)
  have hAl : pA[nA - 1]'(by omega) = y := getLast_getElem hyA (by omega)
  have hB0 : pB[0]'(by omega) = x := head_getElem hxB (by omega)
  have hBl : pB[nB - 1]'(by omega) = y := getLast_getElem hyB (by omega)
  have injA : ∀ {s t : ℕ} {hs : s < nA} {ht : t < nA},
      pA[s]'hs = pA[t]'ht → s = t := fun h => (List.Nodup.getElem_inj_iff hndA).mp h
  have injB : ∀ {s t : ℕ} {hs : s < nB} {ht : t < nB},
      pB[s]'hs = pB[t]'ht → s = t := fun h => (List.Nodup.getElem_inj_iff hndB).mp h
  -- interior positions lie in the sides
  have hintA : ∀ t (ht : t < nA), 1 ≤ t → t ≤ nA - 2 → QA (pA[t]'ht) := by
    intro t ht h1 h2
    rcases hvA (pA[t]'ht) (List.getElem_mem ht) with h | h | h
    · exact absurd (injA (show pA[t]'ht = pA[0]'(by omega) by rw [h, hA0])) (by omega)
    · exact absurd (injA (show pA[t]'ht = pA[nA - 1]'(by omega) by rw [h, hAl])) (by omega)
    · exact h
  have hintB : ∀ t (ht : t < nB), 1 ≤ t → t ≤ nB - 2 → QB (pB[t]'ht) := by
    intro t ht h1 h2
    rcases hvB (pB[t]'ht) (List.getElem_mem ht) with h | h | h
    · exact absurd (injB (show pB[t]'ht = pB[0]'(by omega) by rw [h, hB0])) (by omega)
    · exact absurd (injB (show pB[t]'ht = pB[nB - 1]'(by omega) by rw [h, hBl])) (by omega)
    · exact h
  -- general index cast
  have gcast : ∀ (l : List ι) {s t : ℕ} (hs : s < l.length) (ht : t < l.length), s = t →
      l[s]'hs = l[t]'ht := by
    intro l s t hs ht h
    subst h
    rfl
  -- the reversed B-interior and the assembled cycle
  set intB : List ι := ((pB.drop 1).dropLast).reverse with hintBdef
  have hlenI : intB.length = nB - 2 := by
    rw [hintBdef, List.length_reverse, List.length_dropLast, List.length_drop]
    omega
  have hcBpos : ∀ m (hm : m < nB - 2),
      intB[m]'(by omega) = pB[nB - 2 - m]'(by omega) := by
    intro m hm
    show (((pB.drop 1).dropLast).reverse)[m]'(by
        rw [List.length_reverse, List.length_dropLast, List.length_drop]; omega) = _
    have h1 : (((pB.drop 1).dropLast).reverse)[m]'(by
        rw [List.length_reverse, List.length_dropLast, List.length_drop]; omega) =
        ((pB.drop 1).dropLast)[((pB.drop 1).dropLast).length - 1 - m]'(by
        rw [List.length_dropLast, List.length_drop]; omega) := List.getElem_reverse _
    rw [h1]
    have hlen2 : ((pB.drop 1).dropLast).length = nB - 2 := by
      rw [List.length_dropLast, List.length_drop]
      omega
    have h2 : ((pB.drop 1).dropLast)[((pB.drop 1).dropLast).length - 1 - m]'(by omega) =
        (pB.drop 1)[((pB.drop 1).dropLast).length - 1 - m]'(by
          rw [List.length_drop]; rw [hlen2]; omega) := List.getElem_dropLast _
    rw [h2]
    have h3 : (pB.drop 1)[((pB.drop 1).dropLast).length - 1 - m]'(by
        rw [List.length_drop]; rw [hlen2]; omega) =
        pB[1 + (((pB.drop 1).dropLast).length - 1 - m)]'(by rw [hlen2]; omega) :=
      List.getElem_drop
    rw [h3]
    congr 1
    rw [hlen2]
    omega
  set c : List ι := pA ++ intB with hc
  have hNlen : c.length = nA + (nB - 2) := by
    rw [hc, List.length_append, hlenI]
  have hcA : ∀ t (ht : t < nA), c[t]'(by omega) = pA[t]'ht := by
    intro t ht
    show (pA ++ intB)[t]'(by rw [List.length_append, hlenI]; omega) = pA[t]'ht
    exact List.getElem_append_left ht
  have hcB : ∀ m (hm : m < nB - 2), c[nA + m]'(by omega) = pB[nB - 2 - m]'(by omega) := by
    intro m hm
    show (pA ++ intB)[nA + m]'(by rw [List.length_append, hlenI]; omega) = _
    have h1 : (pA ++ intB)[nA + m]'(by rw [List.length_append, hlenI]; omega) =
        intB[nA + m - pA.length]'(by rw [hlenI]; omega) :=
      List.getElem_append_right (by omega)
    rw [h1, gcast intB (by rw [hlenI]; omega) (by rw [hlenI]; omega)
      (show nA + m - pA.length = m from by omega)]
    exact hcBpos m hm
  have hNge : 4 ≤ c.length := by
    rw [hNlen]
    omega
  have hchainA := List.isChain_iff_getElem.mp hchA
  have hchainB := List.isChain_iff_getElem.mp hchB
  -- consecutive adjacency along the cycle, including the wrap
  have hadjc : ∀ t (ht : t < c.length),
      Adj 𝒞 (c[t]'ht) (c[(t + 1) % c.length]'(Nat.mod_lt _ (by omega))) := by
    intro t ht
    rcases mod_succ_cases c.length t ht with ⟨hm, hlt⟩ | ⟨hm, heq⟩
    · have hcast : c[(t + 1) % c.length]'(Nat.mod_lt _ (by omega)) = c[t + 1]'(by omega) :=
        gcast c _ _ hm
      rw [hcast]
      by_cases h1 : t + 1 < nA
      · rw [hcA t (by omega), hcA (t + 1) h1]
        exact hchainA t (by omega)
      · by_cases h2 : t + 1 = nA
        · have hstep := hchainB (nB - 2) (by omega)
          have hy' : pB[nB - 2 + 1]'(by omega) = y := by
            rw [gcast pB (by omega) (by omega) (show nB - 2 + 1 = nB - 1 from by omega), hBl]
          rw [hy'] at hstep
          have hct : c[t]'ht = y := by
            rw [hcA t (by omega), gcast pA (by omega) (by omega)
              (show t = nA - 1 from by omega), hAl]
          have hct1 : c[t + 1]'(by omega) = pB[nB - 2]'(by omega) := by
            rw [gcast c (by omega) (by omega) (show t + 1 = nA + 0 from by omega),
              hcB 0 (by omega)]
            exact gcast pB (by omega) (by omega) (by omega)
          rw [hct, hct1]
          exact hstep.symm'
        · have hm1 : nA ≤ t := by omega
          have hmm : (t - nA) + 1 < nB - 2 := by omega
          have hct : c[t]'ht = pB[nB - 2 - (t - nA)]'(by omega) := by
            rw [gcast c ht (by omega) (show t = nA + (t - nA) from by omega),
              hcB (t - nA) (by omega)]
          have hct1 : c[t + 1]'(by omega) = pB[nB - 2 - ((t - nA) + 1)]'(by omega) := by
            rw [gcast c (by omega) (by omega) (show t + 1 = nA + ((t - nA) + 1) from by omega),
              hcB ((t - nA) + 1) hmm]
          rw [hct, hct1]
          have hstep := hchainB (nB - 2 - ((t - nA) + 1)) (by omega)
          have hidx : pB[nB - 2 - ((t - nA) + 1) + 1]'(by omega) =
              pB[nB - 2 - (t - nA)]'(by omega) :=
            gcast pB _ _ (by omega)
          rw [hidx] at hstep
          exact hstep.symm'
    · have hcast : c[(t + 1) % c.length]'(Nat.mod_lt _ (by omega)) = c[0]'(by omega) :=
        gcast c _ _ hm
      rw [hcast]
      have hc0 : c[0]'(by omega) = x := by
        rw [hcA 0 (by omega), hA0]
      have hct : c[t]'ht = pB[1]'(by omega) := by
        rw [gcast c ht (by omega) (show t = nA + (nB - 2 - 1) from by omega),
          hcB (nB - 2 - 1) (by omega)]
        exact gcast pB _ _ (by omega)
      rw [hc0, hct]
      have hstep := hchainB 0 (by omega)
      rw [hB0] at hstep
      exact hstep.symm'
  -- the cycle is duplicate-free
  have hndI : intB.Nodup := by
    rw [hintBdef, List.nodup_reverse]
    exact (List.dropLast_sublist _).nodup ((List.drop_sublist _ _).nodup hndB)
  have hndc : c.Nodup := by
    rw [hc, List.nodup_append]
    refine ⟨hndA, hndI, ?_⟩
    intro s hs r hr
    obtain ⟨m, hm, rfl⟩ := List.mem_iff_getElem.mp hr
    have hmI : m < nB - 2 := by
      rw [hlenI] at hm
      exact hm
    have hQBr : QB (intB[m]'hm) := by
      rw [hcBpos m hmI]
      exact hintB (nB - 2 - m) (by omega) (by omega) (by omega)
    intro hsr
    rcases hvA s hs with h | h | h
    · rw [hsr] at h
      exact hQBx (h ▸ hQBr)
    · rw [hsr] at h
      exact hQBy (h ▸ hQBr)
    · rw [hsr] at h
      exact hABdisj _ h hQBr
  -- the cycle pairs are hosted
  have hhostc : ∀ w ∈ cyclePairs c, ∃ T ∈ 𝒞, w ⊆ T := by
    intro w hw
    obtain ⟨t, htl, rfl⟩ := List.mem_iff_getElem.mp hw
    have ht : t < c.length := by simpa using htl
    rw [getElem_cyclePairs c (by omega) t htl]
    obtain ⟨-, T, hT, h1, h2⟩ := hadjc t ht
    exact ⟨T, hT, Finset.insert_subset h1 (Finset.singleton_subset_iff.mpr h2)⟩
  -- chordless-cycle-freeness forces a chord
  have hncc : ¬ IsChordlessCycle 𝒞 c := fun hcc => hchord ⟨c, hcc⟩
  rw [IsChordlessCycle] at hncc
  have hchordfail : ¬ ∀ (i j : ℕ) (hi : i < c.length) (hj : j < c.length),
      Adj 𝒞 (c[i]'hi) (c[j]'hj) →
        (i + 1) % c.length = j ∨ (j + 1) % c.length = i ∨ i = j :=
    fun hcf => hncc ⟨hndc, hNge, hhostc, hcf⟩
  simp only [not_forall] at hchordfail
  obtain ⟨ci, cj, hci, hcj, hadj, hndisj⟩ := hchordfail
  simp only [not_or] at hndisj
  obtain ⟨hd1, hd2, hd3⟩ := hndisj
  -- the chord dies in every zone
  have main : ∀ (i j : ℕ) (hi : i < c.length) (hj : j < c.length), i < j →
      Adj 𝒞 (c[i]'hi) (c[j]'hj) → (i + 1) % c.length ≠ j → (j + 1) % c.length ≠ i →
      False := by
    intro i j hi hj hij hadj hn1 hn2
    by_cases hjA : j < nA
    · have hdist : i + 2 ≤ j := by
        rcases mod_succ_cases c.length i (by omega) with ⟨hm', -⟩ | ⟨hm', hieq⟩
        · rw [hm'] at hn1
          omega
        · omega
      have hkill := no_chord_of_minimal (Q := QA) hchA hxA hyA hvA hminA hndA
        (show i < nA from by omega) (show j < nA from hjA) hdist
      rw [hcA i (by omega), hcA j hjA] at hadj
      exact hkill hadj
    · by_cases hiA : i < nA
      · have hmI : j - nA < nB - 2 := by omega
        have he1 : 1 ≤ nB - 2 - (j - nA) := by omega
        have he2 : nB - 2 - (j - nA) ≤ nB - 2 := by omega
        have hcj' : c[j]'hj = pB[nB - 2 - (j - nA)]'(by omega) := by
          rw [gcast c hj (by omega) (show j = nA + (j - nA) from by omega),
            hcB (j - nA) hmI]
        by_cases hi0 : i = 0
        · have hene1 : nB - 2 - (j - nA) ≠ 1 := by
            intro he
            rcases mod_succ_cases c.length j hj with ⟨hm', hlt'⟩ | ⟨hm', -⟩
            · omega
            · rw [hm'] at hn2
              omega
          have hkill := no_chord_of_minimal (Q := QB) hchB hxB hyB hvB hminB hndB
            (show 0 < nB from by omega) (show nB - 2 - (j - nA) < nB from by omega)
            (show 0 + 2 ≤ nB - 2 - (j - nA) from by omega)
          have hxi : c[i]'hi = pB[0]'(by omega) := by
            rw [hcA i (by omega), gcast pA (by omega) (by omega) hi0, hA0, ← hB0]
          rw [hxi, hcj'] at hadj
          exact hkill hadj
        · by_cases hil : i = nA - 1
          · have hene : nB - 2 - (j - nA) ≠ nB - 2 := by
              intro he
              have hjnA : j = nA := by omega
              rcases mod_succ_cases c.length i (by omega) with ⟨hm', -⟩ | ⟨hm', hieq⟩
              · rw [hm'] at hn1
                omega
              · omega
            have hkill := no_chord_of_minimal (Q := QB) hchB hxB hyB hvB hminB hndB
              (show nB - 2 - (j - nA) < nB from by omega)
              (show nB - 1 < nB from by omega)
              (show nB - 2 - (j - nA) + 2 ≤ nB - 1 from by omega)
            have hyi : c[i]'hi = pB[nB - 1]'(by omega) := by
              rw [hcA i (by omega), gcast pA (by omega) (by omega) hil, hAl, ← hBl]
            rw [hyi, hcj'] at hadj
            exact hkill hadj.symm'
          · have hQA' : QA (c[i]'hi) := by
              rw [hcA i (by omega)]
              exact hintA i (by omega) (by omega) (by omega)
            have hQB' : QB (c[j]'hj) := by
              rw [hcj']
              exact hintB (nB - 2 - (j - nA)) (by omega) he1 he2
            exact hABnadj _ _ hQA' hQB' hadj
      · have hmiI : i - nA < nB - 2 := by omega
        have hmjI : j - nA < nB - 2 := by omega
        have hdist : (i - nA) + 2 ≤ j - nA := by
          rcases mod_succ_cases c.length i (by omega) with ⟨hm', -⟩ | ⟨hm', hieq⟩
          · rw [hm'] at hn1
            omega
          · omega
        have hkill := no_chord_of_minimal (Q := QB) hchB hxB hyB hvB hminB hndB
          (show nB - 2 - (j - nA) < nB from by omega)
          (show nB - 2 - (i - nA) < nB from by omega)
          (show nB - 2 - (j - nA) + 2 ≤ nB - 2 - (i - nA) from by omega)
        have hci' : c[i]'hi = pB[nB - 2 - (i - nA)]'(by omega) := by
          rw [gcast c hi (by omega) (show i = nA + (i - nA) from by omega),
            hcB (i - nA) hmiI]
        have hcj' : c[j]'hj = pB[nB - 2 - (j - nA)]'(by omega) := by
          rw [gcast c hj (by omega) (show j = nA + (j - nA) from by omega),
            hcB (j - nA) hmjI]
        rw [hci', hcj'] at hadj
        exact hkill hadj.symm'
  rcases Nat.lt_trichotomy ci cj with hlt | heq | hlt
  · exact main ci cj hci hcj hlt hadj hd1 hd2
  · exact hd3 heq
  · exact main cj ci hcj hci hlt hadj.symm' hd2 hd1

omit [DecidableEq ι] in
private lemma gcast_list (l : List ι) {s t : ℕ} (hs : s < l.length) (ht : t < l.length)
    (h : s = t) : l[s]'hs = l[t]'ht := by
  subst h
  rfl

/-! ### Minimal separators have neighbors on both sides -/

/-- If `x` has no neighbor reachable from `a` off the separator, then erasing `x` still
separates: the first `x`-occurrence on any violating path has its predecessor reachable
from `a` and adjacent to `x`. -/
private lemma erase_separates {𝒞 : Finset (Finset ι)} {S Sep : Finset ι}
    {a b x : ι} (hxa : x ≠ a)
    (hno : ∀ u, (u ∈ S \ Sep ∧ ReachOn 𝒞 (fun v => v ∈ S \ Sep) a u) → ¬ Adj 𝒞 x u)
    (hsep : ¬ ReachOn 𝒞 (fun v => v ∈ S \ Sep) a b) :
    ¬ ReachOn 𝒞 (fun v => v ∈ S \ Sep.erase x) a b := by
  rintro ⟨p, ⟨hch, hP⟩, hnd, hu, hv⟩
  by_cases hxp : x ∈ p
  · -- first occurrence
    have hne : {k : ℕ | p[k]? = some x}.Nonempty := by
      obtain ⟨k, hk, hkx⟩ := List.mem_iff_getElem.mp hxp
      exact ⟨k, show p[k]? = some x by rw [List.getElem?_eq_getElem hk, hkx]⟩
    have hkmem : p[sInf {k : ℕ | p[k]? = some x}]? = some x := Nat.sInf_mem hne
    set k := sInf {k : ℕ | p[k]? = some x} with hkdef
    have hkl : k < p.length := by
      by_contra hge
      rw [List.getElem?_eq_none (by omega)] at hkmem
      exact absurd hkmem (by simp)
    have hkx : p[k]'hkl = x := by
      rw [List.getElem?_eq_getElem hkl] at hkmem
      exact Option.some_inj.mp hkmem
    have hk0 : 0 < k := by
      rcases Nat.eq_zero_or_pos k with h | h
      · exfalso
        have h0 : p[0]'(by omega) = a := head_getElem hu (by omega)
        have hc := gcast_list p hkl (by omega) h
        rw [hc, h0] at hkx
        exact hxa hkx.symm
      · exact h
    -- prefix vertices avoid Sep entirely
    have hpre : ∀ m (hm : m < k), (p[m]'(by omega)) ∈ S \ Sep := by
      intro m hm
      have hPm : p[m]'(by omega) ∈ S \ Sep.erase x :=
        hP _ (List.getElem_mem (by omega : m < p.length))
      rw [Finset.mem_sdiff] at hPm ⊢
      refine ⟨hPm.1, fun hmem => ?_⟩
      by_cases hmx : p[m]'(by omega) = x
      · have : k ≤ m := Nat.sInf_le (show p[m]? = some x by
          rw [List.getElem?_eq_getElem (by omega : m < p.length), hmx])
        omega
      · exact hPm.2 (Finset.mem_erase.mpr ⟨hmx, hmem⟩)
    -- the prefix is a walk from a to p[k-1]
    have hwalk : IsWalkOn 𝒞 (fun v => v ∈ S \ Sep) (p.take k) := by
      refine ⟨isChain_take hch _, ?_⟩
      intro z hz
      obtain ⟨m, hm, rfl⟩ := List.mem_iff_getElem.mp hz
      have hmk : m < k := by
        rw [List.length_take] at hm
        omega
      have hcast : (p.take k)[m]'hm = p[m]'(by omega) := List.getElem_take
      rw [hcast]
      exact hpre m hmk
    have hhead : (p.take k).head? = some a := by
      have hb0 : 0 < (p.take k).length := by
        rw [List.length_take]
        omega
      rw [List.head?_eq_getElem?, List.getElem?_eq_getElem hb0]
      have h1 : (p.take k)[0]'hb0 = p[0]'(by omega) := List.getElem_take
      rw [h1, head_getElem hu (by omega)]
    have hlastp : (p.take k).getLast? = some (p[k - 1]'(by omega)) := by
      have hlt : (p.take k).length = k := by
        rw [List.length_take]
        omega
      rw [List.getLast?_eq_getElem?, hlt,
        List.getElem?_eq_getElem (show k - 1 < (p.take k).length by omega)]
      have h1 : (p.take k)[k - 1]'(by omega) = p[k - 1]'(by omega) := List.getElem_take
      rw [h1]
    have hreach : ReachOn 𝒞 (fun v => v ∈ S \ Sep) a (p[k - 1]'(by omega)) :=
      reachOn_of_walk _ hwalk hhead hlastp
    have hadj : Adj 𝒞 x (p[k - 1]'(by omega)) := by
      have hstep := (List.isChain_iff_getElem.mp hch) (k - 1) (by omega)
      have hcast : p[k - 1 + 1]'(by omega) = p[k]'hkl := gcast_list p _ _ (by omega)
      rw [hcast, hkx] at hstep
      exact hstep.symm'
    exact hno _ ⟨hpre (k - 1) (by omega), hreach⟩ hadj
  · -- the path avoids x entirely, hence avoids Sep.erase x ∪ {x} ⊇ Sep
    apply hsep
    refine ⟨p, ⟨hch, ?_⟩, hnd, hu, hv⟩
    intro z hz
    show z ∈ S \ Sep
    have hPz : z ∈ S \ Sep.erase x := hP z hz
    rw [Finset.mem_sdiff] at hPz ⊢
    refine ⟨hPz.1, fun hmem => ?_⟩
    by_cases hzx : z = x
    · exact hxp (hzx ▸ hz)
    · exact hPz.2 (Finset.mem_erase.mpr ⟨hzx, hmem⟩)

/-! ### Dirac's lemma -/

/-- `v` is simplicial within the vertex set `S`: it lies in `S` and its `𝒞`-neighbors
inside `S` are pairwise adjacent. -/
def SimpIn (𝒞 : Finset (Finset ι)) (S : Finset ι) (v : ι) : Prop :=
  v ∈ S ∧ ∀ x ∈ S, ∀ y ∈ S, Adj 𝒞 v x → Adj 𝒞 v y → x ≠ y → Adj 𝒞 x y

set_option maxHeartbeats 1600000 in
/-- **Dirac's lemma, strong form**: in a chordless-cycle-free adjacency structure, every
vertex set is a clique or contains two nonadjacent simplicial vertices. -/
theorem dirac_strong (𝒞 : Finset (Finset ι))
    (hchord : ¬ ∃ l : List ι, IsChordlessCycle 𝒞 l) (S : Finset ι) :
    (∀ x ∈ S, ∀ y ∈ S, x ≠ y → Adj 𝒞 x y) ∨
    (∃ u w : ι, SimpIn 𝒞 S u ∧ SimpIn 𝒞 S w ∧ u ≠ w ∧ ¬ Adj 𝒞 u w) := by
  classical
  induction S using Finset.strongInduction with
  | _ S ih =>
    by_cases hcomp : ∀ x ∈ S, ∀ y ∈ S, x ≠ y → Adj 𝒞 x y
    · exact Or.inl hcomp
    right
    simp only [not_forall] at hcomp
    obtain ⟨a, ha, b, hb, hab, hnadj⟩ := hcomp
    -- the full complement of {a, b} separates a from b
    have hfull : ¬ ReachOn 𝒞 (fun v => v ∈ S \ (S \ ({a, b} : Finset ι))) a b := by
      rintro ⟨p, ⟨hch, hP⟩, hnd, hu, hv⟩
      have hsub : ∀ v ∈ p, v = a ∨ v = b := by
        intro v hv'
        have h1 : v ∈ S \ (S \ ({a, b} : Finset ι)) := hP v hv'
        rw [Finset.mem_sdiff, Finset.mem_sdiff] at h1
        have h2 : v ∈ ({a, b} : Finset ι) := by
          by_contra h3
          exact h1.2 ⟨h1.1, h3⟩
        simpa using h2
      have hlen2 : p.length ≤ 2 := by
        by_contra h3
        rcases hsub _ (List.getElem_mem (by omega : 0 < p.length)) with h0 | h0 <;>
          rcases hsub _ (List.getElem_mem (by omega : 1 < p.length)) with h1 | h1 <;>
          rcases hsub _ (List.getElem_mem (by omega : 2 < p.length)) with h2 | h2
        all_goals first
          | exact absurd ((List.Nodup.getElem_inj_iff hnd).mp (h0.trans h1.symm)) (by omega)
          | exact absurd ((List.Nodup.getElem_inj_iff hnd).mp (h0.trans h2.symm)) (by omega)
          | exact absurd ((List.Nodup.getElem_inj_iff hnd).mp (h1.trans h2.symm)) (by omega)
      match p, hu, hv, hch, hlen2 with
      | [z], hu, hv, _, _ =>
        have h1 : z = a := by simpa using hu
        have h2 : z = b := by simpa using hv
        exact hab (h1.symm.trans h2)
      | [z, w], hu, hv, hch, _ =>
        have h1 : z = a := by simpa using hu
        have h2 : w = b := by simpa using hv
        have hzw := List.isChain_pair.mp hch
        rw [h1, h2] at hzw
        exact hnadj hzw
    -- a minimum-cardinality separator
    have hSepSet : {n : ℕ | ∃ Sp : Finset ι, Sp ⊆ S \ ({a, b} : Finset ι) ∧
        ¬ ReachOn 𝒞 (fun v => v ∈ S \ Sp) a b ∧ Sp.card = n}.Nonempty :=
      ⟨(S \ ({a, b} : Finset ι)).card,
        S \ ({a, b} : Finset ι), Finset.Subset.refl _, hfull, rfl⟩
    obtain ⟨Sep, hSepsub, hsep, hSepcard⟩ := Nat.sInf_mem hSepSet
    have haSep : a ∉ Sep := fun h => by
      have h' := hSepsub h
      rw [Finset.mem_sdiff] at h'
      exact h'.2 (by simp)
    have hbSep : b ∉ Sep := fun h => by
      have h' := hSepsub h
      rw [Finset.mem_sdiff] at h'
      exact h'.2 (by simp)
    -- the two sides
    set A : Finset ι :=
      (S \ Sep).filter (fun v => ReachOn 𝒞 (fun w => w ∈ S \ Sep) a v) with hAdef
    set B : Finset ι :=
      (S \ Sep).filter (fun v => ReachOn 𝒞 (fun w => w ∈ S \ Sep) b v) with hBdef
    have haA : a ∈ A := by
      rw [hAdef, Finset.mem_filter]
      exact ⟨Finset.mem_sdiff.mpr ⟨ha, haSep⟩,
        reachOn_refl (Finset.mem_sdiff.mpr ⟨ha, haSep⟩)⟩
    have hbB : b ∈ B := by
      rw [hBdef, Finset.mem_filter]
      exact ⟨Finset.mem_sdiff.mpr ⟨hb, hbSep⟩,
        reachOn_refl (Finset.mem_sdiff.mpr ⟨hb, hbSep⟩)⟩
    have hdisjAB : ∀ v, v ∈ A → v ∈ B → False := by
      intro v hvA hvB
      rw [hAdef, Finset.mem_filter] at hvA
      rw [hBdef, Finset.mem_filter] at hvB
      exact hsep (reachOn_trans hvA.2 (reachOn_symm hvB.2))
    have hclosA : ∀ u, u ∈ A → ∀ w, Adj 𝒞 u w → w ∈ S \ Sep → w ∈ A := by
      intro u hu w hadj hw
      rw [hAdef, Finset.mem_filter] at hu ⊢
      exact ⟨hw, reachOn_extend hu.2 hadj hw⟩
    have hclosB : ∀ u, u ∈ B → ∀ w, Adj 𝒞 u w → w ∈ S \ Sep → w ∈ B := by
      intro u hu w hadj hw
      rw [hBdef, Finset.mem_filter] at hu ⊢
      exact ⟨hw, reachOn_extend hu.2 hadj hw⟩
    -- every separator vertex has neighbors on both sides (minimality)
    have hSepNbrA : ∀ z ∈ Sep, ∃ u, (u ∈ S \ Sep ∧
        ReachOn 𝒞 (fun w => w ∈ S \ Sep) a u) ∧ Adj 𝒞 z u := by
      intro z hz
      by_contra hno
      simp only [not_exists, not_and] at hno
      have hkill := erase_separates (show z ≠ a from fun h => haSep (h ▸ hz)) hno hsep
      have hlt : (Sep.erase z).card < Sep.card := Finset.card_erase_lt_of_mem hz
      have hle : sInf {n : ℕ | ∃ Sp : Finset ι, Sp ⊆ S \ ({a, b} : Finset ι) ∧
          ¬ ReachOn 𝒞 (fun v => v ∈ S \ Sp) a b ∧ Sp.card = n} ≤ (Sep.erase z).card :=
        Nat.sInf_le ⟨Sep.erase z, (Finset.erase_subset _ _).trans hSepsub, hkill, rfl⟩
      omega
    have hSepNbrB : ∀ z ∈ Sep, ∃ u, (u ∈ S \ Sep ∧
        ReachOn 𝒞 (fun w => w ∈ S \ Sep) b u) ∧ Adj 𝒞 z u := by
      intro z hz
      by_contra hno
      simp only [not_exists, not_and] at hno
      have hkill := erase_separates (show z ≠ b from fun h => hbSep (h ▸ hz)) hno
        (fun h => hsep (reachOn_symm h))
      have hlt : (Sep.erase z).card < Sep.card := Finset.card_erase_lt_of_mem hz
      have hle : sInf {n : ℕ | ∃ Sp : Finset ι, Sp ⊆ S \ ({a, b} : Finset ι) ∧
          ¬ ReachOn 𝒞 (fun v => v ∈ S \ Sp) a b ∧ Sp.card = n} ≤ (Sep.erase z).card :=
        Nat.sInf_le ⟨Sep.erase z, (Finset.erase_subset _ _).trans hSepsub,
          fun h => hkill (reachOn_symm h), rfl⟩
      omega
    -- the separator is a clique
    have hSepClq : ∀ z ∈ Sep, ∀ w ∈ Sep, z ≠ w → Adj 𝒞 z w := by
      intro z hz w hw hzw
      by_contra hnzw
      obtain ⟨u₁, hu₁, hadj₁⟩ := hSepNbrA z hz
      obtain ⟨u₂, hu₂, hadj₂⟩ := hSepNbrA w hw
      obtain ⟨w₁, hw₁, hadjB₁⟩ := hSepNbrB z hz
      obtain ⟨w₂, hw₂, hadjB₂⟩ := hSepNbrB w hw
      have hzA : ¬ (z ∈ A) := fun h => by
        rw [hAdef, Finset.mem_filter, Finset.mem_sdiff] at h
        exact h.1.2 hz
      have hwA : ¬ (w ∈ A) := fun h => by
        rw [hAdef, Finset.mem_filter, Finset.mem_sdiff] at h
        exact h.1.2 hw
      have hzB : ¬ (z ∈ B) := fun h => by
        rw [hBdef, Finset.mem_filter, Finset.mem_sdiff] at h
        exact h.1.2 hz
      have hwB : ¬ (w ∈ B) := fun h => by
        rw [hBdef, Finset.mem_filter, Finset.mem_sdiff] at h
        exact h.1.2 hw
      have hreachA : ReachOn 𝒞 (fun v => v ∈ A) u₁ u₂ := by
        have h12 : ReachOn 𝒞 (fun v => v ∈ S \ Sep) u₁ u₂ :=
          reachOn_trans (reachOn_symm hu₁.2) hu₂.2
        obtain ⟨p, hwk, hnd, h1, h2⟩ := h12
        refine reachOn_of_walk p ⟨hwk.1, ?_⟩ h1 h2
        intro v hv'
        have hz' : ReachOn 𝒞 (fun v => v ∈ S \ Sep) u₁ v := reachOn_of_mem_walk hwk h1 hv'
        show v ∈ A
        rw [hAdef, Finset.mem_filter]
        exact ⟨hwk.2 v hv', reachOn_trans hu₁.2 hz'⟩
      have hreachB : ReachOn 𝒞 (fun v => v ∈ B) w₁ w₂ := by
        have h12 : ReachOn 𝒞 (fun v => v ∈ S \ Sep) w₁ w₂ :=
          reachOn_trans (reachOn_symm hw₁.2) hw₂.2
        obtain ⟨p, hwk, hnd, h1, h2⟩ := h12
        refine reachOn_of_walk p ⟨hwk.1, ?_⟩ h1 h2
        intro v hv'
        have hz' : ReachOn 𝒞 (fun v => v ∈ S \ Sep) w₁ v := reachOn_of_mem_walk hwk h1 hv'
        show v ∈ B
        rw [hBdef, Finset.mem_filter]
        exact ⟨hwk.2 v hv', reachOn_trans hw₁.2 hz'⟩
      obtain ⟨pA0, hchA0, hndA0, hxA0, hyA0, hvA0⟩ :=
        exists_connector hzw hadj₁ hadj₂ hreachA hzA hwA
      obtain ⟨pB0, hchB0, hndB0, hxB0, hyB0, hvB0⟩ :=
        exists_connector hzw hadjB₁ hadjB₂ hreachB hzB hwB
      obtain ⟨pA, hpA, hminA⟩ := exists_min_path
        (Q := fun q => List.IsChain (Adj 𝒞) q ∧ q.Nodup ∧ q.head? = some z ∧
          q.getLast? = some w ∧ ∀ v ∈ q, v = z ∨ v = w ∨ v ∈ A)
        ⟨pA0, hchA0, hndA0, hxA0, hyA0, hvA0⟩
      obtain ⟨pB, hpB, hminB⟩ := exists_min_path
        (Q := fun q => List.IsChain (Adj 𝒞) q ∧ q.Nodup ∧ q.head? = some z ∧
          q.getLast? = some w ∧ ∀ v ∈ q, v = z ∨ v = w ∨ v ∈ B)
        ⟨pB0, hchB0, hndB0, hxB0, hyB0, hvB0⟩
      obtain ⟨hchA', hndA', hxA', hyA', hvA'⟩ := hpA
      obtain ⟨hchB', hndB', hxB', hyB', hvB'⟩ := hpB
      have hABnadj : ∀ u v, u ∈ A → v ∈ B → ¬ Adj 𝒞 u v := by
        intro u v hu hv hadj
        have hvQ : v ∈ S \ Sep := by
          rw [hBdef, Finset.mem_filter] at hv
          exact hv.1
        exact hdisjAB v (hclosA u hu v hadj hvQ) hv
      exact sep_clique_step hchord hzw hnzw hzB hwB hdisjAB hABnadj
        pA hchA' hndA' hxA' hyA' hvA' hminA
        pB hchB' hndB' hxB' hyB' hvB' hminB
    -- both sides give a simplicial vertex via the induction hypothesis
    have hAS : A ⊆ S := by
      intro v hv'
      rw [hAdef, Finset.mem_filter, Finset.mem_sdiff] at hv'
      exact hv'.1.1
    have hBS : B ⊆ S := by
      intro v hv'
      rw [hBdef, Finset.mem_filter, Finset.mem_sdiff] at hv'
      exact hv'.1.1
    have hSepS : Sep ⊆ S := fun v hv' => (Finset.mem_sdiff.mp (hSepsub hv')).1
    have hbAS : b ∉ A ∪ Sep := by
      rw [Finset.mem_union]
      rintro (h | h)
      · exact hdisjAB b h hbB
      · exact hbSep h
    have haBS : a ∉ B ∪ Sep := by
      rw [Finset.mem_union]
      rintro (h | h)
      · exact hdisjAB a haA h
      · exact haSep h
    have hsubA : A ∪ Sep ⊂ S := by
      rw [Finset.ssubset_iff_of_subset (Finset.union_subset hAS hSepS)]
      exact ⟨b, hb, hbAS⟩
    have hsubB : B ∪ Sep ⊂ S := by
      rw [Finset.ssubset_iff_of_subset (Finset.union_subset hBS hSepS)]
      exact ⟨a, ha, haBS⟩
    have hCQA : ∀ v, v ∈ A → v ∈ S \ Sep := by
      intro v hv'
      rw [hAdef, Finset.mem_filter] at hv'
      exact hv'.1
    have hCQB : ∀ v, v ∈ B → v ∈ S \ Sep := by
      intro v hv'
      rw [hBdef, Finset.mem_filter] at hv'
      exact hv'.1
    have extract : ∀ (C : Finset ι) (c₀ : ι), c₀ ∈ C → C ∪ Sep ⊂ S →
        (∀ u, u ∈ C → ∀ w, Adj 𝒞 u w → w ∈ S \ Sep → w ∈ C) →
        (∀ v, v ∈ C → v ∈ S \ Sep) →
        ∃ u, u ∈ C ∧ SimpIn 𝒞 S u := by
      intro C c₀ hc₀ hsub hclosC hCQ
      have hnbr : ∀ u, u ∈ C → ∀ x', x' ∈ S → Adj 𝒞 u x' → x' ∈ C ∪ Sep := by
        intro u hu x' hx' hadj
        by_cases hxSep : x' ∈ Sep
        · exact Finset.mem_union_right _ hxSep
        · exact Finset.mem_union_left _
            (hclosC u hu x' hadj (Finset.mem_sdiff.mpr ⟨hx', hxSep⟩))
      have hlift : ∀ u, u ∈ C → SimpIn 𝒞 (C ∪ Sep) u → SimpIn 𝒞 S u := by
        intro u huC husimp
        refine ⟨(Finset.mem_sdiff.mp (hCQ u huC)).1, ?_⟩
        intro x' hx' y' hy' hux huy hxy
        exact husimp.2 x' (hnbr u huC x' hx' hux) y' (hnbr u huC y' hy' huy) hux huy hxy
      rcases ih (C ∪ Sep) hsub with hcomp' | ⟨u₁, u₂, hs₁, hs₂, hne', hnadj'⟩
      · exact ⟨c₀, hc₀, hlift c₀ hc₀ ⟨Finset.mem_union_left _ hc₀,
          fun x' hx' y' hy' _ _ hxy => hcomp' x' hx' y' hy' hxy⟩⟩
      · have hone : u₁ ∈ C ∨ u₂ ∈ C := by
          by_contra hno
          rw [not_or] at hno
          have h₁ : u₁ ∈ Sep := by
            rcases Finset.mem_union.mp hs₁.1 with h | h
            · exact absurd h hno.1
            · exact h
          have h₂ : u₂ ∈ Sep := by
            rcases Finset.mem_union.mp hs₂.1 with h | h
            · exact absurd h hno.2
            · exact h
          exact hnadj' (hSepClq u₁ h₁ u₂ h₂ hne')
        rcases hone with h | h
        · exact ⟨u₁, h, hlift u₁ h hs₁⟩
        · exact ⟨u₂, h, hlift u₂ h hs₂⟩
    obtain ⟨uA, huA, hsimpA⟩ := extract A a haA hsubA hclosA hCQA
    obtain ⟨uB, huB, hsimpB⟩ := extract B b hbB hsubB hclosB hCQB
    refine ⟨uA, uB, hsimpA, hsimpB, ?_, ?_⟩
    · intro h
      exact hdisjAB uA huA (h ▸ huB)
    · intro hadj
      exact hdisjAB uB (hclosA uA huA uB hadj (hCQB uB huB)) huB

/-! ### The dichotomy and the capstone -/

/-- An ear-free cover has a shared vertex: every team has nonempty boundary. -/
lemma shared_nonempty_of_earFree {𝒞 : Finset (Finset ι)} (hef : EarFree 𝒞) :
    (shared 𝒞).Nonempty := by
  obtain ⟨⟨T, hT⟩, hne⟩ := hef
  have hnoear := hne T hT
  rw [IsEarOf, not_or] at hnoear
  obtain ⟨hne', hnot⟩ := hnoear
  obtain ⟨T', hT'⟩ := Finset.nonempty_iff_ne_empty.mpr hne'
  have hbne : (T ∩ coverU (𝒞.erase T)).Nonempty := by
    rcases Finset.eq_empty_or_nonempty (T ∩ coverU (𝒞.erase T)) with h | h
    · exact absurd ⟨T', hT', by rw [h]; exact Finset.empty_subset _⟩ hnot
    · exact h
  obtain ⟨v, hv⟩ := hbne
  rw [bndry_eq_inter_shared hT] at hv
  exact ⟨v, (Finset.mem_inter.mp hv).2⟩

/-- **The ear-free dichotomy**: an ear-free cover is non-conformal or contains a chordless
cycle. Dirac's lemma on the shared vertices produces a simplicial shared vertex, and the
one-step GYO collapse turns it into an ear. -/
theorem earFree_dichotomy (𝒞 : Finset (Finset ι)) (hef : EarFree 𝒞) :
    ¬ Conformal 𝒞 ∨ ∃ l : List ι, IsChordlessCycle 𝒞 l := by
  by_contra h
  rw [not_or, not_not] at h
  obtain ⟨hconf, hnl⟩ := h
  obtain ⟨v, hv⟩ := shared_nonempty_of_earFree hef
  have hear : ∃ T ∈ 𝒞, IsEarOf 𝒞 T := by
    rcases dirac_strong 𝒞 hnl (shared 𝒞) with hcomp | ⟨u, w, hu, hw, hne', hnadj⟩
    · exact isEarOf_of_simplicial hconf hv
        (fun x hx y hy _ _ hxy => hcomp x hx y hy hxy)
    · exact isEarOf_of_simplicial hconf hu.1 hu.2
  obtain ⟨T, hT, hearT⟩ := hear
  exact hef.2 T hT hearT

/-- **The CAPSTONE**: a non-acyclic cover hosts a pairwise-consistent family of nonempty
local relations that no global structure realizes: the base structure carries what local
consistency cannot. -/
theorem exists_consistent_not_glues_of_not_acyclic [Fintype ι] (𝒞 : Finset (Finset ι))
    (hna : ¬ Acyclic 𝒞) :
    ∃ fam : List (LocalStruct ι (fun _ => ZMod 2)),
      fam.map (·.team) = 𝒞.toList ∧ Consistent fam ∧
      (∀ L ∈ fam, L.rel.Nonempty) ∧ ¬ Glues fam :=
  capstone_of_dichotomy 𝒞 (fun hg => hna ((acyclic_iff_grahamReducible 𝒞).mpr hg))
    (fun 𝒞' _ hef => earFree_dichotomy 𝒞' hef)

/-- **The discrete Vorob'ev theorem**: a cover's base structure is acyclic exactly when local
pairwise consistency always forces a global structure, i.e. every pairwise-consistent family of
nonempty local relations on it glues. -/
theorem acyclic_iff_forall_consistent_glues [Fintype ι] (𝒞 : Finset (Finset ι)) :
    Acyclic 𝒞 ↔ ∀ fam : List (LocalStruct ι (fun _ => ZMod 2)),
      fam.map (·.team) = 𝒞.toList → Consistent fam →
      (∀ L ∈ fam, L.rel.Nonempty) → Glues fam := by
  constructor
  · intro hacyc fam hteams hcons _
    refine glues_of_acyclic fam hcons ?_ ?_
    · rw [hteams]
      exact 𝒞.nodup_toList
    · rw [hteams, Finset.toList_toFinset]
      exact hacyc
  · intro h
    by_contra hna
    obtain ⟨fam, hteams, hcons, hne, hng⟩ :=
      exists_consistent_not_glues_of_not_acyclic 𝒞 hna
    exact hng (h fam hteams hcons hne)

end HiddenChannelCapacity
