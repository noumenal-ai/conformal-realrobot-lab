/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Marginals
import QuantumInfo.States.Mixed.MState

/-!
# The quantum marginal presheaf: team-indexed partial traces

Rung L0 of the quantum junction tree arc (QJT_URS). This rung builds instruments, not
thesis: the base structure of a quantum scenario is the cover's subset lattice of teams
`S : Finset ι`, and the marginals are the local (fiber-side) ends the base organizes.
QuantumInfo carries only bipartite partial traces (`MState.traceLeft`/`traceRight` over
`d₁ × d₂`); the marginal problem over a COVER needs marginals indexed by teams of a
multipartite carrier `MState (∀ i, X i)`, mirroring the classical `projS` presheaf of
`Marginals.lean`, the support-stratum presheaf over which the base geometry lives.

`ptraceS ρ S` reindexes the carrier along `Equiv.piEquivPiSubtypeProd` to split the
coordinates into `S` and its complement, then traces the complement out. This is the
quantum `projS`. The three L0 obligations, all maximal-generality instruments, land here:

* **The presheaf law** (`qRestrict₂_ptraceS`; the quantum `projS_image_restrict₂`, and
  the team-indexed form of Lauritzen–Zwiernik Lem 2.2 "iterated marginalization
  composes"): `qRestrict₂ hST : MState (∀ i : T, X i) → MState (∀ i : S, X i)` is the
  quantum restriction map (the quantum `Finset.restrict₂`, tracing out the coordinates
  of `T` outside `S`), and restricting the `T`-marginal along `S ⊆ T` is exactly the
  `S`-marginal. The proof reindexes the complement sum along `complMerge`: the
  complement of `S` is the complement-in-`T` joined with the complement-of-`T`.
* **The pull-out lemma** (LZ Lem 2.3, "the most useful identity in the paper"), at
  matrix level over arbitrary (non-normalized) matrices and any `NonAssocSemiring`:
  `Tr_A((1 ⊗ M)ρ) = M · Tr_A(ρ)` and its three siblings
  (`Matrix.traceLeft_one_kron_mul` etc.). Stated on plain matrices because the paper
  applies it to non-state operators; the `MState`/`HermitianMat` forms are one
  projection away when the EASY layer consumes them.
* **The diagonal bridge** (`ptraceS_ofClassical`): the quantum marginal of a
  classically embedded distribution is the embedding of the classical marginal
  (`ProbDistribution.marginal`, the pushforward along `Finset.restrict`). This is the
  substrate of the diagonal transfer of classical non-gluing witnesses (T2a) and of
  QJT-GRADE (the dim → H → S(ρ) grading tower commuting with the diagonal embedding).
-/

/-! ### The pull-out lemma (LZ Lem 2.3), at matrix level -/

namespace Matrix

open Kronecker

variable {R : Type*} [NonAssocSemiring R]
variable {d d₁ d₂ d₃ : Type*} [Fintype d] [Fintype d₂] [DecidableEq d]

/-- **The pull-out lemma** (LZ Lem 2.3): an operator acting only on the untraced factor
pulls out of the partial trace, left-multiplication form.
`Tr_A((1_A ⊗ M) ρ) = M · Tr_A(ρ)`. -/
theorem traceLeft_one_kron_mul (M : Matrix d₁ d₂ R) (ρ : Matrix (d × d₂) (d × d₃) R) :
    ((1 ⊗ₖ M) * ρ).traceLeft = M * ρ.traceLeft := by
  ext a c
  show ∑ x : d, (((1 : Matrix d d R) ⊗ₖ M) * ρ) (x, a) (x, c) = (M * ρ.traceLeft) a c
  have hterm : ∀ x : d, (((1 : Matrix d d R) ⊗ₖ M) * ρ) (x, a) (x, c)
      = ∑ b : d₂, M a b * ρ (x, b) (x, c) := by
    intro x
    rw [Matrix.mul_apply, Fintype.sum_prod_type_right]
    simp only [Matrix.kroneckerMap_apply, Matrix.one_apply, ite_mul, one_mul, zero_mul,
      Finset.sum_ite_eq, Finset.mem_univ, if_true]
  rw [Finset.sum_congr rfl fun x _ => hterm x, Matrix.mul_apply]
  simp only [Matrix.traceLeft, Matrix.of_apply, Finset.mul_sum]
  exact Finset.sum_comm

/-- Pull-out, right-multiplication form: `Tr_A(ρ (1_A ⊗ M)) = Tr_A(ρ) · M`. -/
theorem traceLeft_mul_one_kron (ρ : Matrix (d × d₁) (d × d₂) R) (M : Matrix d₂ d₃ R) :
    (ρ * (1 ⊗ₖ M)).traceLeft = ρ.traceLeft * M := by
  ext a c
  show ∑ x : d, (ρ * ((1 : Matrix d d R) ⊗ₖ M)) (x, a) (x, c) = (ρ.traceLeft * M) a c
  have hterm : ∀ x : d, (ρ * ((1 : Matrix d d R) ⊗ₖ M)) (x, a) (x, c)
      = ∑ b : d₂, ρ (x, a) (x, b) * M b c := by
    intro x
    rw [Matrix.mul_apply, Fintype.sum_prod_type_right]
    simp only [Matrix.kroneckerMap_apply, Matrix.one_apply, ite_mul, mul_ite, one_mul,
      zero_mul, mul_zero, Finset.sum_ite_eq', Finset.mem_univ, if_true]
  rw [Finset.sum_congr rfl fun x _ => hterm x, Matrix.mul_apply]
  simp only [Matrix.traceLeft, Matrix.of_apply, Finset.sum_mul]
  exact Finset.sum_comm

/-- Pull-out for the right partial trace, left-multiplication form:
`Tr_B((M ⊗ 1_B) ρ) = M · Tr_B(ρ)`. -/
theorem traceRight_kron_one_mul (M : Matrix d₁ d₂ R) (ρ : Matrix (d₂ × d) (d₃ × d) R) :
    ((M ⊗ₖ 1) * ρ).traceRight = M * ρ.traceRight := by
  ext a c
  show ∑ z : d, ((M ⊗ₖ (1 : Matrix d d R)) * ρ) (a, z) (c, z) = (M * ρ.traceRight) a c
  have hterm : ∀ z : d, ((M ⊗ₖ (1 : Matrix d d R)) * ρ) (a, z) (c, z)
      = ∑ b : d₂, M a b * ρ (b, z) (c, z) := by
    intro z
    rw [Matrix.mul_apply, Fintype.sum_prod_type]
    simp only [Matrix.kroneckerMap_apply, Matrix.one_apply, mul_ite, mul_one, mul_zero,
      ite_mul, zero_mul, Finset.sum_ite_eq, Finset.mem_univ, if_true]
  rw [Finset.sum_congr rfl fun z _ => hterm z, Matrix.mul_apply]
  simp only [Matrix.traceRight, Matrix.of_apply, Finset.mul_sum]
  exact Finset.sum_comm

/-- Pull-out for the right partial trace, right-multiplication form:
`Tr_B(ρ (M ⊗ 1_B)) = Tr_B(ρ) · M`. -/
theorem traceRight_mul_kron_one (ρ : Matrix (d₁ × d) (d₂ × d) R) (M : Matrix d₂ d₃ R) :
    (ρ * (M ⊗ₖ 1)).traceRight = ρ.traceRight * M := by
  ext a c
  show ∑ z : d, (ρ * (M ⊗ₖ (1 : Matrix d d R))) (a, z) (c, z) = (ρ.traceRight * M) a c
  have hterm : ∀ z : d, (ρ * (M ⊗ₖ (1 : Matrix d d R))) (a, z) (c, z)
      = ∑ b : d₂, ρ (a, z) (b, z) * M b c := by
    intro z
    rw [Matrix.mul_apply, Fintype.sum_prod_type]
    simp only [Matrix.kroneckerMap_apply, Matrix.one_apply, mul_ite, mul_one, mul_zero,
      Finset.sum_ite_eq', Finset.mem_univ, if_true]
  rw [Finset.sum_congr rfl fun z _ => hterm z, Matrix.mul_apply]
  simp only [Matrix.traceRight, Matrix.of_apply, Finset.sum_mul]
  exact Finset.sum_comm

omit [Fintype d] [DecidableEq d] in
/-- Embed an operator on one block of a coordinate split into the whole space (tensor
with the identity, transported along the split): the dual of `MState.traceAlong`, and
the paper's embedding convention ("tensoring with identities BEFORE logs") as a named
primitive. -/
def embedAlong {a b : Type*} [DecidableEq b] (e : d ≃ a × b) (M : Matrix a a R) :
    Matrix d d R :=
  (M ⊗ₖ (1 : Matrix b b R)).submatrix e e

omit [Fintype d] [DecidableEq d] in
/-- The trace is invariant under simultaneous reindexing by an equivalence. -/
private lemma trace_submatrix_equiv {n m : Type*} [Fintype n] [Fintype m]
    (A : Matrix m m R) (e : n ≃ m) : (A.submatrix e e).trace = A.trace := by
  simp only [Matrix.trace, Matrix.diag, Matrix.submatrix_apply]
  exact Equiv.sum_comp e fun j => A j j

end Matrix

/-! ### The classical marginal of a distribution -/

namespace ProbDistribution

variable {ι : Type*} [DecidableEq ι] {X : ι → Type*}
  [∀ i, Fintype (X i)] [∀ i, DecidableEq (X i)]

/-- The classical marginal of a distribution over a sub-team: the pushforward along
`Finset.restrict`. The mass of a local configuration is the total mass of its fiber.
The distribution-level `projS`. -/
noncomputable def marginal [Fintype ι] (p : ProbDistribution (∀ i, X i)) (S : Finset ι) :
    ProbDistribution (∀ i : S, X i) :=
  ProbDistribution.mk'
    (fun g => ∑ f ∈ Finset.univ.filter (fun f => S.restrict f = g), (p f : ℝ))
    (fun _ => Finset.sum_nonneg fun _ _ => Prob.zero_le_coe)
    (by rw [Finset.sum_fiberwise]; exact p.normalized)

/-- The marginal's mass, definitionally: the fiber sum. -/
@[simp] lemma marginal_coe [Fintype ι] (p : ProbDistribution (∀ i, X i)) (S : Finset ι)
    (g : ∀ i : S, X i) :
    ((p.marginal S) g : ℝ)
      = ∑ f ∈ Finset.univ.filter (fun f => S.restrict f = g), (p f : ℝ) :=
  rfl

end ProbDistribution

/-! ### The abstract partial-trace primitive

The abstraction-boundary law (QJT_URS, L0 entry): definitional transparency is
affordable exactly up to the first concrete Pi-subtype carrier, so ALL defeq work
happens here, at abstract carriers, and the team-indexed marginals below are
instances that never re-derive it. -/

namespace MState

variable {d a b : Type*} [Fintype d] [DecidableEq d] [Fintype a] [DecidableEq a]
  [Fintype b] [DecidableEq b]

/-- Trace out the second block of a coordinate split: the abstract partial-trace
primitive of the L0 layer. -/
noncomputable def traceAlong (ρ : MState d) (e : d ≃ a × b) : MState a :=
  (ρ.relabel e.symm).traceRight

/-- The entry calculus: entries of `traceAlong` are complement sums. -/
lemma traceAlong_m (ρ : MState d) (e : d ≃ a × b) (x y : a) :
    (ρ.traceAlong e).m x y = ∑ z, ρ.m (e.symm (x, z)) (e.symm (y, z)) :=
  rfl

/-- **Iterated marginalization composes** (the abstract Lauritzen-Zwiernik Lem 2.2):
tracing along a split and then along a split of the kept block is tracing along any
pointwise-coherent composite split. -/
theorem traceAlong_traceAlong {a' c : Type*} [Fintype a'] [DecidableEq a']
    {b' : Type*} [Fintype b'] [DecidableEq b'] [Fintype c] [DecidableEq c]
    (ρ : MState d) (e₁ : d ≃ a × b) (e₂ : a ≃ a' × b') (e₃ : d ≃ a' × c)
    (W : b' × b ≃ c)
    (hcoh : ∀ (g : a') (h : b') (z : b),
      e₁.symm (e₂.symm (g, h), z) = e₃.symm (g, W (h, z))) :
    (ρ.traceAlong e₁).traceAlong e₂ = ρ.traceAlong e₃ := by
  refine MState.ext_m (funext fun g => funext fun g' => ?_)
  calc ((ρ.traceAlong e₁).traceAlong e₂).m g g'
      = ∑ h, ∑ z, ρ.m (e₁.symm (e₂.symm (g, h), z)) (e₁.symm (e₂.symm (g', h), z)) := by
        simp only [traceAlong_m]
    _ = ∑ h, ∑ z, ρ.m (e₃.symm (g, W (h, z))) (e₃.symm (g', W (h, z))) := by
        simp only [hcoh]
    _ = ∑ p : b' × b, ρ.m (e₃.symm (g, W p)) (e₃.symm (g', W p)) :=
        (Fintype.sum_prod_type
          fun p : b' × b => ρ.m (e₃.symm (g, W p)) (e₃.symm (g', W p))).symm
    _ = ∑ w, ρ.m (e₃.symm (g, w)) (e₃.symm (g', w)) :=
        Equiv.sum_comp W fun w => ρ.m (e₃.symm (g, w)) (e₃.symm (g', w))
    _ = (ρ.traceAlong e₃).m g g' := (traceAlong_m ρ e₃ g g').symm

open scoped Kronecker in
/-- **The partial-trace duality** (LZ eq (2), the defining property of the partial
trace, split-indexed): testing the marginal against an observable is testing the
state against the embedded observable,
`Tr(embedAlong e M · ρ) = Tr(M · traceAlong e ρ)`. -/
theorem traceAlong_duality (ρ : MState d) (e : d ≃ a × b) (M : Matrix a a ℂ) :
    (Matrix.embedAlong e M * ρ.m).trace = (M * (ρ.traceAlong e).m).trace := by
  have hρ : ρ.m = ((ρ.relabel e.symm).m).submatrix e e := by
    ext i j
    simp [MState.relabel_m]
  calc (Matrix.embedAlong e M * ρ.m).trace
      = ((M ⊗ₖ (1 : Matrix b b ℂ)).submatrix e e
          * ((ρ.relabel e.symm).m).submatrix e e).trace := by rw [hρ]; rfl
    _ = (((M ⊗ₖ (1 : Matrix b b ℂ)) * (ρ.relabel e.symm).m).submatrix e e).trace := by
        rw [Matrix.submatrix_mul_equiv]
    _ = ((M ⊗ₖ (1 : Matrix b b ℂ)) * (ρ.relabel e.symm).m).trace :=
        Matrix.trace_submatrix_equiv _ e
    _ = (((M ⊗ₖ (1 : Matrix b b ℂ)) * (ρ.relabel e.symm).m).traceRight).trace :=
        (Matrix.traceRight_trace _).symm
    _ = (M * ((ρ.relabel e.symm).m).traceRight).trace :=
        congrArg Matrix.trace (Matrix.traceRight_kron_one_mul M (ρ.relabel e.symm).m)
    _ = (M * (ρ.traceAlong e).m).trace := rfl

end MState

namespace HiddenChannelCapacity

variable {ι : Type*} [DecidableEq ι] {X : ι → Type*}
  [∀ i, Fintype (X i)] [∀ i, DecidableEq (X i)]

/-- The team-indexed partial trace: the marginal of a multipartite quantum state on the
team `S`. The quantum `projS`. -/
noncomputable def ptraceS [Fintype ι] (ρ : MState (∀ i, X i)) (S : Finset ι) :
    MState (∀ i : S, X i) :=
  ρ.traceAlong (Equiv.piEquivPiSubtypeProd (· ∈ S) X)

/-! ### The quantum restriction map and the presheaf law -/

/-- Split a team's coordinates along a sub-team: the domain-side substrate of the
quantum restriction map. -/
def teamSplit {S T : Finset ι} (hST : S ⊆ T) :
    (∀ i : T, X i) ≃ (∀ i : S, X i) × (∀ i : (T \ S : Finset ι), X i) where
  toFun f := (fun i => f ⟨i, hST i.2⟩, fun i => f ⟨i, (Finset.mem_sdiff.mp i.2).1⟩)
  invFun g := fun j => if hj : (j : ι) ∈ S then g.1 ⟨j, hj⟩
    else g.2 ⟨j, Finset.mem_sdiff.mpr ⟨j.2, hj⟩⟩
  left_inv f := by
    funext j
    by_cases hj : (j : ι) ∈ S
    · exact dif_pos hj
    · exact dif_neg hj
  right_inv g := by
    obtain ⟨g₁, g₂⟩ := g
    refine Prod.ext ?_ ?_
    · funext i
      exact dif_pos i.2
    · funext i
      exact dif_neg (Finset.mem_sdiff.mp i.2).2

omit [∀ i, Fintype (X i)] [∀ i, DecidableEq (X i)] in
@[simp] lemma teamSplit_symm_apply {S T : Finset ι} (hST : S ⊆ T)
    (g : ∀ i : S, X i) (h : ∀ i : (T \ S : Finset ι), X i) (j : T) :
    (teamSplit hST).symm (g, h) j
      = if hj : (j : ι) ∈ S then g ⟨j, hj⟩
        else h ⟨j, Finset.mem_sdiff.mpr ⟨j.2, hj⟩⟩ :=
  rfl

/-- The quantum restriction map along a sub-team inclusion (the quantum
`Finset.restrict₂`): trace out the coordinates of `T` outside `S`. -/
noncomputable def qRestrict₂ {S T : Finset ι} (hST : S ⊆ T)
    (ρ : MState (∀ i : T, X i)) : MState (∀ i : S, X i) :=
  ρ.traceAlong (teamSplit hST)

/-- Merge the two complement blocks of `S ⊆ T` (the complement inside `T` and the
complement of `T`) into the complement of `S`: the trace-side substrate of the
presheaf law. -/
def complMerge {S T : Finset ι} (hST : S ⊆ T) :
    (∀ i : (T \ S : Finset ι), X i) × (∀ i : {x // ¬x ∈ T}, X i)
      ≃ (∀ i : {x // ¬x ∈ S}, X i) where
  toFun p := fun i => if hi : (i : ι) ∈ T
    then p.1 ⟨i, Finset.mem_sdiff.mpr ⟨hi, i.2⟩⟩ else p.2 ⟨i, hi⟩
  invFun w := (fun j => w ⟨j, (Finset.mem_sdiff.mp j.2).2⟩,
    fun j => w ⟨j, fun hS => j.2 (hST hS)⟩)
  left_inv p := by
    obtain ⟨p₁, p₂⟩ := p
    refine Prod.ext ?_ ?_
    · funext j
      exact dif_pos (Finset.mem_sdiff.mp j.2).1
    · funext j
      exact dif_neg j.2
  right_inv w := by
    funext i
    by_cases hi : (i : ι) ∈ T
    · exact dif_pos hi
    · exact dif_neg hi

omit [∀ i, Fintype (X i)] [∀ i, DecidableEq (X i)] in
@[simp] lemma complMerge_apply {S T : Finset ι} (hST : S ⊆ T)
    (h : ∀ i : (T \ S : Finset ι), X i) (z : ∀ i : {x // ¬x ∈ T}, X i)
    (i : {x // ¬x ∈ S}) :
    complMerge hST (h, z) i
      = if hi : (i : ι) ∈ T then h ⟨i, Finset.mem_sdiff.mpr ⟨hi, i.2⟩⟩
        else z ⟨i, hi⟩ :=
  rfl

omit [∀ i, Fintype (X i)] [∀ i, DecidableEq (X i)] in
/-- The merge coherence: splitting off `S` from a `T`-configuration and a
`T`-complement is splitting off `S` directly, with the two complement blocks merged. -/
lemma piSplit_merge {S T : Finset ι} (hST : S ⊆ T)
    (g : ∀ i : S, X i) (h : ∀ i : (T \ S : Finset ι), X i)
    (z : ∀ i : {x // ¬x ∈ T}, X i) :
    (Equiv.piEquivPiSubtypeProd (· ∈ T) X).symm ((teamSplit hST).symm (g, h), z)
      = (Equiv.piEquivPiSubtypeProd (· ∈ S) X).symm (g, complMerge hST (h, z)) := by
  funext i
  by_cases hiT : i ∈ T
  · by_cases hiS : i ∈ S
    · simp [hiT, hiS]
    · simp [hiT, hiS]
  · have hiS : ¬i ∈ S := fun hS => hiT (hST hS)
    simp [hiT, hiS]

/-- **The quantum presheaf law** (the quantum `projS_image_restrict₂`; team-indexed
Lauritzen–Zwiernik Lem 2.2): restricting the `T`-marginal along `S ⊆ T` is the
`S`-marginal. Sub-marginalizing composes, so the team-indexed partial traces form a
presheaf over the subset lattice. An instance of the abstract composition theorem at
the split-coherence witness `piSplit_merge`. -/
theorem qRestrict₂_ptraceS [Fintype ι] (ρ : MState (∀ i, X i)) {S T : Finset ι}
    (hST : S ⊆ T) : qRestrict₂ hST (ptraceS ρ T) = ptraceS ρ S :=
  MState.traceAlong_traceAlong ρ (Equiv.piEquivPiSubtypeProd (· ∈ T) X)
    (teamSplit hST) (Equiv.piEquivPiSubtypeProd (· ∈ S) X) (complMerge hST)
    (piSplit_merge hST)

/-! ### The diagonal bridge -/

/-- The diagonal entries of a classically embedded state. -/
private lemma ofClassical_m {d : Type*} [Fintype d] [DecidableEq d]
    (dist : ProbDistribution d) (x y : d) :
    (MState.ofClassical dist).m x y = if x = y then ((dist x : ℝ) : ℂ) else 0 := by
  have h1 : (MState.ofClassical dist).m
      = Matrix.diagonal (fun x => ((dist x : ℝ) : ℂ)) := by
    rw [show (MState.ofClassical dist).m = (MState.ofClassical dist).M.mat from rfl,
      MState.coe_ofClassical, HermitianMat.diagonal_mat]
    rfl
  rw [h1, Matrix.diagonal_apply]

/-- Summing over the fiber of `Finset.restrict` is summing over the complement
coordinates: the fiber of a local configuration is parameterized by the split. -/
private lemma sum_fiber_restrict [Fintype ι] {M : Type*} [AddCommMonoid M]
    (S : Finset ι) (g : ∀ i : S, X i) (F : (∀ i, X i) → M) :
    ∑ f ∈ Finset.univ.filter (fun f => S.restrict f = g), F f
      = ∑ w : ∀ i : {x // ¬x ∈ S}, X i,
          F ((Equiv.piEquivPiSubtypeProd (· ∈ S) X).symm (g, w)) := by
  refine Finset.sum_nbij' (i := fun f => fun i => f i)
    (j := fun w => (Equiv.piEquivPiSubtypeProd (· ∈ S) X).symm (g, w))
    (fun f _ => Finset.mem_univ _) ?_ ?_ ?_ ?_
  · intro w _
    rw [Finset.mem_filter]
    refine ⟨Finset.mem_univ _, funext fun i => ?_⟩
    show (Equiv.piEquivPiSubtypeProd (· ∈ S) X).symm (g, w) i = g i
    rw [Equiv.piEquivPiSubtypeProd_symm_apply, dif_pos i.2]
  · intro f hf
    have hres : S.restrict f = g := (Finset.mem_filter.mp hf).2
    funext i
    rw [Equiv.piEquivPiSubtypeProd_symm_apply]
    by_cases hi : (i : ι) ∈ S
    · rw [dif_pos hi]
      exact (congrFun hres ⟨i, hi⟩).symm
    · rw [dif_neg hi]
  · intro w _
    funext i
    show (Equiv.piEquivPiSubtypeProd (· ∈ S) X).symm (g, w) i = w i
    rw [Equiv.piEquivPiSubtypeProd_symm_apply, dif_neg i.2]
  · intro f hf
    have hres : S.restrict f = g := (Finset.mem_filter.mp hf).2
    refine congrArg F (funext fun i => ?_)
    rw [Equiv.piEquivPiSubtypeProd_symm_apply]
    by_cases hi : (i : ι) ∈ S
    · rw [dif_pos hi]
      exact congrFun hres ⟨i, hi⟩
    · rw [dif_neg hi]

/-- **The diagonal bridge**: the quantum marginal of a classically embedded
distribution is the classical embedding of the classical marginal,
`ptraceS ∘ ofClassical = ofClassical ∘ marginal`. The substrate of the diagonal
transfer of classical non-gluing witnesses and of QJT-GRADE. -/
theorem ptraceS_ofClassical [Fintype ι] (p : ProbDistribution (∀ i, X i))
    (S : Finset ι) :
    ptraceS (MState.ofClassical p) S = MState.ofClassical (p.marginal S) := by
  refine MState.ext_m (funext fun g => funext fun g' => ?_)
  simp only [ptraceS, MState.traceAlong_m, ofClassical_m]
  by_cases hgg : g = g'
  · subst hgg
    rw [if_pos rfl, ProbDistribution.marginal_coe,
      sum_fiber_restrict S g (fun f => (p f : ℝ))]
    push_cast
    refine Finset.sum_congr rfl fun w _ => ?_
    rw [if_pos rfl]
  · rw [if_neg hgg]
    refine Finset.sum_eq_zero fun w _ => ?_
    exact if_neg fun hc => hgg (congrArg Prod.fst
      ((Equiv.piEquivPiSubtypeProd (· ∈ S) X).symm.injective hc))

end HiddenChannelCapacity
