/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Marginals
import ZPM.Measurements.HC.HigherObstruction

/-!
# The fiber product: joins, the defect decomposition, and two-cover amalgamation

The natural join over a genuine interface: for sub-teams `T₁ T₂ : Finset ι` and structures on
their marginal types, `join T₁ T₂ κ₁ κ₂` is the largest relation whose marginals lie inside the
factors. Three results:

* **The defect decomposition** (`hcCombPi_eq_join_add_gap`): under a cover `T₁ ∪ T₂ = univ`,
  `hcCombPi κ = hcCombPi (join of κ's own marginals) + (|join| − |κ|)` — the base defect splits
  into the part two-local marginal data can already express (the join-level defect) plus the
  RECONSTRUCTION GAP, the base structure no two-team reconstruction recovers. On the parity
  relation the gap is the whole defect (its marginals are full): shadow-blindness, quantified.

* **Two-cover amalgamation** (`projS_join_left`, `projS_join_right`): when two structures share
  an interface (their interface marginals agree), that shared base structure licenses a global
  join realizing both factors exactly. With `specker_not_glues` this fixes the arity asymmetry:
  a two-team cover always licenses the global object; at three teams the cover's cyclic geometry
  can withhold it.

* **Leibniz fails at genuine interfaces** (`hcCombPi_join_ne_leibniz`): the juxtaposition law of
  `ProductLaw` does not survive a shared part — kernel-checked on the diagonal structures of the
  Specker file. The swept one-sided form (the Leibniz expression as an UPPER bound for the
  interfaced defect) is recorded as a conjecture in `FIBER_PRODUCT_URS.md`.
-/

namespace HiddenChannelCapacity

open Finset

variable {ι : Type*} [Fintype ι] [DecidableEq ι] {X : ι → Type*}
  [∀ i, Fintype (X i)] [∀ i, DecidableEq (X i)]

/-- **The natural join**: the largest relation whose `T₁`- and `T₂`-marginals lie inside the
factors. -/
def join (T₁ T₂ : Finset ι) (κ₁ : Finset (∀ i : T₁, X i)) (κ₂ : Finset (∀ i : T₂, X i)) :
    Finset (∀ i, X i) :=
  Finset.univ.filter (fun f => T₁.restrict f ∈ κ₁ ∧ T₂.restrict f ∈ κ₂)

lemma mem_join {T₁ T₂ : Finset ι} {κ₁ : Finset (∀ i : T₁, X i)} {κ₂ : Finset (∀ i : T₂, X i)}
    {f : ∀ i, X i} :
    f ∈ join T₁ T₂ κ₁ κ₂ ↔ T₁.restrict f ∈ κ₁ ∧ T₂.restrict f ∈ κ₂ := by
  simp [join]

/-- Every relation embeds in the join of its own marginals. -/
theorem subset_join_projS (T₁ T₂ : Finset ι) (κ : Finset (∀ i, X i)) :
    κ ⊆ join T₁ T₂ (projS κ T₁) (projS κ T₂) := fun _ hf =>
  mem_join.mpr ⟨Finset.mem_image_of_mem _ hf, Finset.mem_image_of_mem _ hf⟩

/-- Under a cover, the join of a relation's own marginals has the relation's projections. -/
lemma projPi_join_projS {T₁ T₂ : Finset ι} (hcover : T₁ ∪ T₂ = Finset.univ)
    (κ : Finset (∀ i, X i)) (i : ι) :
    projPi (join T₁ T₂ (projS κ T₁) (projS κ T₂)) i = projPi κ i := by
  refine Finset.Subset.antisymm ?_
    (Finset.image_subset_image (subset_join_projS T₁ T₂ κ))
  have hi : i ∈ T₁ ∨ i ∈ T₂ :=
    Finset.mem_union.mp (hcover ▸ Finset.mem_univ i)
  intro a ha
  obtain ⟨f, hf, rfl⟩ := Finset.mem_image.mp ha
  obtain ⟨h1, h2⟩ := mem_join.mp hf
  rcases hi with hi | hi
  · have hmem := Finset.mem_image_of_mem (fun g : ∀ j : T₁, X j => g ⟨i, hi⟩) h1
    rw [show ((projS κ T₁).image fun g : ∀ j : T₁, X j => g ⟨i, hi⟩)
        = projPi (projS κ T₁) ⟨i, hi⟩ from rfl, projPi_projS] at hmem
    exact hmem
  · have hmem := Finset.mem_image_of_mem (fun g : ∀ j : T₂, X j => g ⟨i, hi⟩) h2
    rw [show ((projS κ T₂).image fun g : ∀ j : T₂, X j => g ⟨i, hi⟩)
        = projPi (projS κ T₂) ⟨i, hi⟩ from rfl, projPi_projS] at hmem
    exact hmem

/-- **The defect decomposition along a two-team cover**: the base defect splits into the part a
two-local reconstruction can express plus the reconstruction gap,

`hcCombPi κ = hcCombPi (join own) + (|join own| − |κ|)`.

The gap is the base structure two-locality cannot reach: it vanishes iff `κ` is its own join. On
the parity relation the entire defect is gap. -/
theorem hcCombPi_eq_join_add_gap {T₁ T₂ : Finset ι} (hcover : T₁ ∪ T₂ = Finset.univ)
    (κ : Finset (∀ i, X i)) :
    hcCombPi κ
      = hcCombPi (join T₁ T₂ (projS κ T₁) (projS κ T₂))
        + ((join T₁ T₂ (projS κ T₁) (projS κ T₂)).card - κ.card) := by
  have hsub := subset_join_projS T₁ T₂ κ
  have hhull : hullPi (join T₁ T₂ (projS κ T₁) (projS κ T₂)) = hullPi κ := by
    rw [hullPi, hullPi]
    congr 1
    funext i
    exact projPi_join_projS hcover κ i
  have h1 : κ.card ≤ (join T₁ T₂ (projS κ T₁) (projS κ T₂)).card :=
    Finset.card_le_card hsub
  have h2 : (join T₁ T₂ (projS κ T₁) (projS κ T₂)).card
      ≤ (hullPi (join T₁ T₂ (projS κ T₁) (projS κ T₂))).card :=
    Finset.card_le_card (subset_hullPi _)
  rw [hhull] at h2
  rw [hcCombPi, hcCombPi, hhull]
  omega

/-- The join is symmetric. -/
lemma join_comm (T₁ T₂ : Finset ι) (κ₁ : Finset (∀ i : T₁, X i))
    (κ₂ : Finset (∀ i : T₂, X i)) :
    join T₁ T₂ κ₁ κ₂ = join T₂ T₁ κ₂ κ₁ := by
  ext f
  simp [mem_join, and_comm]

/-- **Two-cover amalgamation, left leg**: under a cover, an agreeing interface is the base
structure that licenses the global join to realize the left factor exactly. Mechanically the
glue takes the left configuration on `T₁` and any interface-compatible right configuration
elsewhere. -/
theorem projS_join_left {T₁ T₂ : Finset ι} (hcover : T₁ ∪ T₂ = Finset.univ)
    {κ₁ : Finset (∀ i : T₁, X i)} {κ₂ : Finset (∀ i : T₂, X i)}
    (hcons : κ₁.image (Finset.restrict₂ (Finset.inter_subset_left : T₁ ∩ T₂ ⊆ T₁))
        = κ₂.image (Finset.restrict₂ (Finset.inter_subset_right : T₁ ∩ T₂ ⊆ T₂))) :
    projS (join T₁ T₂ κ₁ κ₂) T₁ = κ₁ := by
  classical
  refine Finset.Subset.antisymm ?_ ?_
  · intro g hg
    obtain ⟨f, hf, rfl⟩ := Finset.mem_image.mp hg
    exact (mem_join.mp hf).1
  · intro g hg
    -- the interface trace of `g` is realized inside `κ₂`
    have htrace : Finset.restrict₂ (Finset.inter_subset_left : T₁ ∩ T₂ ⊆ T₁) g
        ∈ κ₂.image (Finset.restrict₂ (Finset.inter_subset_right : T₁ ∩ T₂ ⊆ T₂)) := by
      rw [← hcons]
      exact Finset.mem_image_of_mem _ hg
    obtain ⟨h, hh, hhg⟩ := Finset.mem_image.mp htrace
    -- glue: `g` on `T₁`, `h` elsewhere (the cover places the rest in `T₂`)
    set glue : ∀ i, X i := fun i =>
      if hi : i ∈ T₁ then g ⟨i, hi⟩
      else h ⟨i, (Finset.mem_union.mp (hcover ▸ Finset.mem_univ i)).resolve_left hi⟩
      with hglue
    have hres₁ : T₁.restrict glue = g := funext fun i => dif_pos i.2
    have hres₂ : T₂.restrict glue = h := by
      funext i
      by_cases hi : (i : ι) ∈ T₁
      · have hint : (i : ι) ∈ T₁ ∩ T₂ := Finset.mem_inter.mpr ⟨hi, i.2⟩
        have := congrFun hhg ⟨i, hint⟩
        calc T₂.restrict glue i = g ⟨i, hi⟩ := dif_pos hi
          _ = h i := this.symm
      · exact dif_neg hi
    refine Finset.mem_image.mpr ⟨glue, mem_join.mpr ⟨?_, ?_⟩, hres₁⟩
    · rw [hres₁]; exact hg
    · rw [hres₂]; exact hh

/-- **Two-cover amalgamation, right leg** (by symmetry). -/
theorem projS_join_right {T₁ T₂ : Finset ι} (hcover : T₁ ∪ T₂ = Finset.univ)
    {κ₁ : Finset (∀ i : T₁, X i)} {κ₂ : Finset (∀ i : T₂, X i)}
    (hcons : κ₁.image (Finset.restrict₂ (Finset.inter_subset_left : T₁ ∩ T₂ ⊆ T₁))
        = κ₂.image (Finset.restrict₂ (Finset.inter_subset_right : T₁ ∩ T₂ ⊆ T₂))) :
    projS (join T₁ T₂ κ₁ κ₂) T₂ = κ₂ := by
  classical
  refine Finset.Subset.antisymm ?_ ?_
  · intro h hh
    obtain ⟨f, hf, rfl⟩ := Finset.mem_image.mp hh
    exact (mem_join.mp hf).2
  · intro h hh
    -- the interface trace of `h` is realized inside `κ₁`
    have htrace : Finset.restrict₂ (Finset.inter_subset_right : T₁ ∩ T₂ ⊆ T₂) h
        ∈ κ₁.image (Finset.restrict₂ (Finset.inter_subset_left : T₁ ∩ T₂ ⊆ T₁)) := by
      rw [hcons]
      exact Finset.mem_image_of_mem _ hh
    obtain ⟨g, hg, hgh⟩ := Finset.mem_image.mp htrace
    -- glue: `h` on `T₂`, `g` elsewhere (the cover places the rest in `T₁`)
    set glue : ∀ i, X i := fun i =>
      if hi : i ∈ T₂ then h ⟨i, hi⟩
      else g ⟨i, (Finset.mem_union.mp (hcover ▸ Finset.mem_univ i)).resolve_right hi⟩
      with hglue
    have hres₂ : T₂.restrict glue = h := funext fun i => dif_pos i.2
    have hres₁ : T₁.restrict glue = g := by
      funext i
      by_cases hi : (i : ι) ∈ T₂
      · have hint : (i : ι) ∈ T₁ ∩ T₂ := Finset.mem_inter.mpr ⟨i.2, hi⟩
        have := congrFun hgh ⟨i, hint⟩
        calc T₁.restrict glue i = h ⟨i, hi⟩ := dif_pos hi
          _ = g i := this.symm
      · exact dif_neg hi
    refine Finset.mem_image.mpr ⟨glue, mem_join.mpr ⟨?_, ?_⟩, hres₂⟩
    · rw [hres₁]; exact hg
    · rw [hres₂]; exact hh

/-- **The Leibniz law dies at a genuine interface**: the juxtaposition law of `ProductLaw`,
applied verbatim to the join of the two diagonal structures over the interface `{1}`, is false.
Kernel-checked. -/
theorem hcCombPi_join_ne_leibniz :
    hcCombPi (join (X := fun _ : Fin 3 => Fin 2) S01 S12 diag01 diag12)
      ≠ hcCombPi diag01 * (hullPi diag12).card + diag01.card * hcCombPi diag12 := by
  decide

end HiddenChannelCapacity
