/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.InformationTheory.MutualInformation.ZeroIffProduct
import Mathlib.MeasureTheory.Measure.Support
import Mathlib.MeasureTheory.Measure.Prod

/-!
# Leg iv reconnection: the support↔distribution bridge (FOL HC lift)

The independence leg (iv) does not lift cleanly from the finite to the first-order
setting because it changes category: classically `FiberCI` is `MI = 0` w.r.t. the
**uniform** measure, which a finite support pins canonically, so it collapses onto
the support-level `FiberRect`. On an infinite type space there is no uniform measure,
so the information-theoretic statement `mutualInformationReal P = 0 ↔ P` factors
(`FiveWayCI.mi_eq_zero_iff_product`) lives at the **distribution** level and detaches
from the support TFAE.

This file builds the **one-way bridge** that reconnects the two levels and holds for
*any* measure, in the fibre→base direction: zero mutual information forces the support
to be a **rectangle** (the product of the marginal supports). The base→fibre direction
— letting rectangular base support fix the distribution-level factorization — is exactly
what a *canonical* support→measure map would supply (uniform for finite `κ`; the
generically-stable Keisler measure under NIP for infinite `κ`), and is the genuine open
frontier (`Keisler measure` construction is left as the named next step, not built here).

## Main results

* `support_prod` — the topological support of a product measure is the product of the
  supports (a general measure-theory lemma, absent from Mathlib);
* `mi_zero_imp_rectangular_support` — zero mutual information ⇒ rectangular support
  (`P.support = (P.map fst).support ×ˢ (P.map snd).support`). The one-way bridge.
-/

open MeasureTheory Set Filter Topology InformationTheory
open scoped ENNReal

namespace HiddenChannelCapacity.FOL

variable {X Y : Type*} [TopologicalSpace X] [TopologicalSpace Y]
  [MeasurableSpace X] [MeasurableSpace Y] {μ : Measure X} {ν : Measure Y}

/-- **Support of a product measure.** The topological support of `μ.prod ν` is the
product `μ.support ×ˢ ν.support`. A point lies in the support iff every neighborhood
has positive measure; on the basis of open rectangles `prod_prod` factorizes the
measure, so positivity factorizes coordinatewise. -/
theorem support_prod [SFinite ν] :
    (μ.prod ν).support = μ.support ×ˢ ν.support := by
  ext ⟨a, b⟩
  simp only [Set.mem_prod, Measure.mem_support_iff_forall]
  constructor
  · intro h
    refine ⟨fun U hU => ?_, fun V hV => ?_⟩
    · have hpos := h (U ×ˢ univ) (prod_mem_nhds hU univ_mem)
      rw [Measure.prod_prod] at hpos
      exact pos_iff_ne_zero.mpr fun hc => (pos_iff_ne_zero.mp hpos) (by rw [hc, zero_mul])
    · have hpos := h (univ ×ˢ V) (prod_mem_nhds univ_mem hV)
      rw [Measure.prod_prod] at hpos
      exact pos_iff_ne_zero.mpr fun hc => (pos_iff_ne_zero.mp hpos) (by rw [hc, mul_zero])
  · rintro ⟨ha, hb⟩ W hW
    obtain ⟨U, hU, V, hV, hUV⟩ := mem_nhds_prod_iff.mp hW
    calc (0 : ℝ≥0∞) < μ U * ν V := ENNReal.mul_pos (ha U hU).ne' (hb V hV).ne'
      _ = (μ.prod ν) (U ×ˢ V) := (Measure.prod_prod U V).symm
      _ ≤ (μ.prod ν) W := measure_mono hUV

/-- **The one-way support↔distribution bridge.** Zero mutual information forces the
support of `P` to be the rectangle `(P.map fst).support ×ˢ (P.map snd).support`. This
reconnects the distribution-level CI leg to the support-level rectangularity in the
fibre→base direction, for *any* probability measure satisfying the standard regularity.
The base→fibre converse — rectangular base support fixing the distribution — needs a
canonical support→measure map (the open frontier). -/
theorem mi_zero_imp_rectangular_support
    (P : Measure (X × Y)) [IsProbabilityMeasure P]
    (hac : P.AbsolutelyContinuous ((P.map Prod.fst).prod (P.map Prod.snd)))
    (hfin : klDiv P ((P.map Prod.fst).prod (P.map Prod.snd)) ≠ ⊤)
    (hMI : mutualInformationReal P = 0) :
    P.support = (P.map Prod.fst).support ×ˢ (P.map Prod.snd).support := by
  haveI : IsProbabilityMeasure (P.map Prod.snd) :=
    Measure.isProbabilityMeasure_map measurable_snd.aemeasurable
  have hprod := (mutualInformationReal_eq_zero_iff_product P hac hfin).mp hMI
  conv_lhs => rw [hprod]
  exact support_prod

end HiddenChannelCapacity.FOL
