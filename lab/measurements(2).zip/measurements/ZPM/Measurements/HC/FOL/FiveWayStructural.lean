/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import Mathlib.Data.Set.Prod
import Mathlib.Data.Set.Image
import Mathlib.Tactic.TFAE

/-!
# Structural legs of the Five-Way over first-order ignorance (FOL HC lift — R2/R3/R5)

The structured ignorance `κ ⊆ S × A × B`: a shared interface coordinate `S` and two
private coordinates `A`, `B` (for the first-order lift these are *type spaces* of
sublanguages, but the geometry legs hold for **any** coordinate types — that is the
point of stating them Set-based rather than Finset-based, so they apply to the
infinite carrier built in R1–R3).

The three **geometry** legs of the Five-Way and their mutual equivalence:

* `Decomposable` (ii) — each fiber is closed under cross-recombination (amalgamation);
* `FiberRect` (iii) — each fiber equals the product of its marginal projections;
* `FiberProductSurjective` (v) — left- and right-admissibility imply joint admissibility.

These are the base-side (support-level) conditions under which **the ignorance factors
over the shared interface**. `fiveWayStructural_tfae` proves them equivalent. The
remaining two legs — interpolation (i) via the abstract layer, conditional independence
(iv) via a fiber measure — are separate; (iv) is the fibre-side leg and the genuine open
frontier (a canonical Keisler measure under NIP).
-/

namespace HiddenChannelCapacity.FOL

open Set

variable {S A B : Type*}

/-- The **fiber** of the ignorance `κ` over a shared coordinate `s`: the admissible
`(a, b)` whose shared coordinate is `s`. -/
def fiber (κ : Set (S × A × B)) (s : S) : Set (A × B) := {p | (s, p.1, p.2) ∈ κ}

/-- **(ii) Decomposable**: within each fiber, the cross of two admissible pairs is
admissible — the amalgamation form of "the ignorance factors". -/
def Decomposable (κ : Set (S × A × B)) : Prop :=
  ∀ s a₁ b₁ a₂ b₂, (s, a₁, b₁) ∈ κ → (s, a₂, b₂) ∈ κ → (s, a₁, b₂) ∈ κ

/-- **(iii) Fiber-rectangular**: each fiber equals the product of its marginal
projections — the geometric form of "the ignorance factors". -/
def FiberRect (κ : Set (S × A × B)) : Prop :=
  ∀ s, fiber κ s = (Prod.fst '' fiber κ s) ×ˢ (Prod.snd '' fiber κ s)

/-- **(v) Fiber-product surjective**: in each fiber, if `a` appears (with some right
value) and `b` appears (with some left value), then `(s, a, b)` is admissible. -/
def FiberProductSurjective (κ : Set (S × A × B)) : Prop :=
  ∀ s a b, (∃ b', (s, a, b') ∈ κ) → (∃ a', (s, a', b) ∈ κ) → (s, a, b) ∈ κ

@[simp] theorem mem_fiber {κ : Set (S × A × B)} {s : S} {a : A} {b : B} :
    (a, b) ∈ fiber κ s ↔ (s, a, b) ∈ κ := Iff.rfl

/-- **Decomposability ⇔ fiber-product surjectivity** (ii ⇔ v): direct first-order logic. -/
theorem decomposable_iff_fps (κ : Set (S × A × B)) :
    Decomposable κ ↔ FiberProductSurjective κ := by
  constructor
  · rintro h s a b ⟨b', hb'⟩ ⟨a', ha'⟩
    exact h s a b' a' b hb' ha'
  · intro h s a₁ b₁ a₂ b₂ h1 h2
    exact h s a₁ b₂ ⟨b₁, h1⟩ ⟨a₂, h2⟩

/-- **Fiber-rectangular ⇔ fiber-product surjective** (iii ⇔ v). -/
theorem fiberRect_iff_fps (κ : Set (S × A × B)) :
    FiberRect κ ↔ FiberProductSurjective κ := by
  constructor
  · rintro h s a b ⟨b', hb'⟩ ⟨a', ha'⟩
    have ha : a ∈ Prod.fst '' fiber κ s := ⟨(a, b'), hb', rfl⟩
    have hb : b ∈ Prod.snd '' fiber κ s := ⟨(a', b), ha', rfl⟩
    have hmem : (a, b) ∈ fiber κ s := by rw [h s]; exact ⟨ha, hb⟩
    exact hmem
  · intro h s
    apply Set.Subset.antisymm
    · intro p hp
      exact ⟨⟨p, hp, rfl⟩, ⟨p, hp, rfl⟩⟩
    · rintro ⟨a, b⟩ ⟨⟨pa, hpa, rfl⟩, ⟨pb, hpb, rfl⟩⟩
      exact h s pa.1 pb.2 ⟨pa.2, hpa⟩ ⟨pb.1, hpb⟩

/-- **Fiber-rectangular ⇔ decomposable** (iii ⇔ ii). -/
theorem fiberRect_iff_decomposable (κ : Set (S × A × B)) :
    FiberRect κ ↔ Decomposable κ :=
  (fiberRect_iff_fps κ).trans (decomposable_iff_fps κ).symm

/-- **The geometry core of the first-order Five-Way.** The three structural legs —
decomposability (ii), fiber-rectangularity (iii), fiber-product surjectivity (v) — are
mutually equivalent over arbitrary coordinate types: the ignorance `κ` factors over the
shared interface, stated three equivalent ways. -/
theorem fiveWayStructural_tfae (κ : Set (S × A × B)) :
    List.TFAE [Decomposable κ, FiberRect κ, FiberProductSurjective κ] := by
  tfae_have 1 ↔ 3 := decomposable_iff_fps κ
  tfae_have 2 ↔ 3 := fiberRect_iff_fps κ
  tfae_finish

end HiddenChannelCapacity.FOL
