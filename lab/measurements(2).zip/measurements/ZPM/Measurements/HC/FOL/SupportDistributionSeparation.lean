/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.FOL.LegIVBridge
import Mathlib.Probability.ProbabilityMassFunction.Constructions

/-!
# The support↔distribution separation witness (FOL HC lift)

`FOL/LegIVBridge.lean` proved the one-way bridge `mi_zero_imp_rectangular_support`:
zero mutual information ⇒ rectangular support. This file shows the **converse genuinely
fails**, completing the FOL end of leg iv: there is a probability measure with
**rectangular support** that is **not a product**. So the discovered base verdict
"rectangular support" does not, by itself, force the fibre laid over it to factor:
support-level (base) HC and distribution-level (mutual-information) HC are distinct
invariants. The base-side verdict is fixed by the support alone, invariant across every
weighting a local, distribution-side measurement could impose, and non-vacuously disjoint
from what the distribution records; this is the measure-theoretic form of the CHSH Pl-kill.

The witness `Pcorr` on `Bool × Bool` puts mass `3/8` on each diagonal point and `1/8`
on each off-diagonal point. Every point has positive mass, so the support is the full
grid (rectangular); but `Pcorr {(tt,tt)} = 3/8` while the product of its (uniform)
marginals gives `1/2 · 1/2 = 1/4`, so `Pcorr` is not its marginal product.

Paired with the *unification* witness `mutualInformationReal_uniform_eq_zero_iff_isRect`
(support ⇔ distribution at the **canonical/uniform** measure), this pins the gap exactly:
the two levels are separated in general and coincide only at the canonical measure, the
canonical section over the base, with the generically-stable Keisler measure under NIP
being the infinite analogue.

Since `mutualInformationReal P = 0 ↔ P` factors (`mutualInformationReal_eq_zero_iff_product`),
`Pcorr ≠ product` is precisely `mutualInformationReal Pcorr ≠ 0`: rectangular support with
positive mutual information.
-/

open MeasureTheory Set InformationTheory
open scoped ENNReal

namespace HiddenChannelCapacity.FOL

/-- Correlated mass function on `Bool × Bool`: `3/8` on the diagonal, `1/8` off it. -/
def fcorr : Bool × Bool → ℝ≥0∞
  | (true, true) => ENNReal.ofReal 0.375
  | (false, false) => ENNReal.ofReal 0.375
  | (true, false) => ENNReal.ofReal 0.125
  | (false, true) => ENNReal.ofReal 0.125

lemma fcorr_pos (x : Bool × Bool) : 0 < fcorr x := by
  obtain ⟨a, b⟩ := x
  cases a <;> cases b <;> (simp only [fcorr]; exact ENNReal.ofReal_pos.mpr (by norm_num))

lemma fcorr_sum : ∑ x, fcorr x = 1 := by
  rw [Fintype.sum_prod_type, Fintype.sum_bool, Fintype.sum_bool, Fintype.sum_bool]
  simp only [fcorr]
  rw [← ENNReal.ofReal_add (by norm_num) (by norm_num),
      ← ENNReal.ofReal_add (by norm_num) (by norm_num),
      ← ENNReal.ofReal_add (by norm_num) (by norm_num), ← ENNReal.ofReal_one]
  congr 1; norm_num

/-- The correlated probability mass function. -/
noncomputable def pmfCorr : PMF (Bool × Bool) := PMF.ofFintype fcorr fcorr_sum

/-- The correlated probability measure: rectangular support, but not a product. -/
noncomputable def Pcorr : Measure (Bool × Bool) := pmfCorr.toMeasure

instance : IsProbabilityMeasure Pcorr := by unfold Pcorr; infer_instance

lemma Pcorr_apply (x : Bool × Bool) : Pcorr {x} = fcorr x := by
  rw [Pcorr, PMF.toMeasure_apply_singleton _ _ (measurableSet_singleton x)]
  rfl

/-- A discrete measure with all singletons positive has full support. -/
lemma support_univ_of_pos {Z : Type*} [TopologicalSpace Z] [MeasurableSpace Z]
    {μ : Measure Z} (h : ∀ z, 0 < μ {z}) : μ.support = univ := by
  refine Set.eq_univ_of_forall fun z => ?_
  rw [Measure.mem_support_iff_forall]
  exact fun U hU =>
    lt_of_lt_of_le (h z) (measure_mono (Set.singleton_subset_iff.mpr (mem_of_mem_nhds hU)))

lemma Pcorr_support_univ : Pcorr.support = univ :=
  support_univ_of_pos fun x => by rw [Pcorr_apply]; exact fcorr_pos x

lemma Pcorr_map_fst_support_univ : (Pcorr.map Prod.fst).support = univ :=
  support_univ_of_pos fun a => by
    rw [Measure.map_apply measurable_fst (measurableSet_singleton a)]
    refine lt_of_lt_of_le ?_
      (measure_mono (Set.singleton_subset_iff.mpr (show (a, true) ∈ Prod.fst ⁻¹' {a} from rfl)))
    rw [Pcorr_apply]; exact fcorr_pos _

lemma Pcorr_map_snd_support_univ : (Pcorr.map Prod.snd).support = univ :=
  support_univ_of_pos fun b => by
    rw [Measure.map_apply measurable_snd (measurableSet_singleton b)]
    refine lt_of_lt_of_le ?_
      (measure_mono (Set.singleton_subset_iff.mpr (show (true, b) ∈ Prod.snd ⁻¹' {b} from rfl)))
    rw [Pcorr_apply]; exact fcorr_pos _

/-- **Rectangular support.** `Pcorr` satisfies the conclusion of the one-way bridge —
its support is the product of the marginal supports (the full grid). -/
theorem Pcorr_support_rectangular :
    Pcorr.support = (Pcorr.map Prod.fst).support ×ˢ (Pcorr.map Prod.snd).support := by
  rw [Pcorr_support_univ, Pcorr_map_fst_support_univ, Pcorr_map_snd_support_univ,
    Set.univ_prod_univ]

/-- The marginal mass of `true` is `1/2` (the marginals are uniform). -/
lemma Pcorr_map_fst_true : (Pcorr.map Prod.fst) {true} = ENNReal.ofReal 0.5 := by
  have hpre : (Prod.fst ⁻¹' {true} : Set (Bool × Bool)) = {(true, true)} ∪ {(true, false)} := by
    ext ⟨a, b⟩; cases a <;> cases b <;> simp
  rw [Measure.map_apply measurable_fst (measurableSet_singleton true), hpre,
    measure_union (by simp) (measurableSet_singleton _),
    Pcorr_apply, Pcorr_apply]
  simp only [fcorr]
  rw [← ENNReal.ofReal_add (by norm_num) (by norm_num)]; congr 1; norm_num

lemma Pcorr_map_snd_true : (Pcorr.map Prod.snd) {true} = ENNReal.ofReal 0.5 := by
  have hpre : (Prod.snd ⁻¹' {true} : Set (Bool × Bool)) = {(true, true)} ∪ {(false, true)} := by
    ext ⟨a, b⟩; cases a <;> cases b <;> simp
  rw [Measure.map_apply measurable_snd (measurableSet_singleton true), hpre,
    measure_union (by simp) (measurableSet_singleton _),
    Pcorr_apply, Pcorr_apply]
  simp only [fcorr]
  rw [← ENNReal.ofReal_add (by norm_num) (by norm_num)]; congr 1; norm_num

/-- **Not a product.** `Pcorr` differs from the product of its marginals at `(tt, tt)`:
`3/8 ≠ 1/2 · 1/2 = 1/4`. -/
theorem Pcorr_ne_product :
    Pcorr ≠ (Pcorr.map Prod.fst).prod (Pcorr.map Prod.snd) := by
  have hP : Pcorr {(true, true)} = ENNReal.ofReal 0.375 := by rw [Pcorr_apply]; rfl
  have hQ : ((Pcorr.map Prod.fst).prod (Pcorr.map Prod.snd)) {(true, true)} = ENNReal.ofReal 0.25 := by
    rw [show ({(true, true)} : Set (Bool × Bool)) = {true} ×ˢ {true} by
        ext ⟨a, b⟩; simp [Prod.ext_iff], Measure.prod_prod, Pcorr_map_fst_true, Pcorr_map_snd_true,
      ← ENNReal.ofReal_mul (by norm_num)]
    congr 1; norm_num
  intro h
  have hcontra : ENNReal.ofReal 0.375 = ENNReal.ofReal 0.25 := by rw [← hP, h, hQ]
  exact absurd hcontra ((ENNReal.ofReal_lt_ofReal_iff (by norm_num)).mpr (by norm_num)).ne'

/-- **Support↔distribution separation.** There is a probability measure with rectangular
support that is not the product of its marginals. The converse of
`mi_zero_imp_rectangular_support` fails: rectangular support does NOT force the
distribution to factor. Equivalently (via `mutualInformationReal_eq_zero_iff_product`),
this measure has rectangular support yet positive mutual information — support-level and
distribution-level factorization are genuinely distinct invariants. -/
theorem support_distribution_separation :
    ∃ P : Measure (Bool × Bool), IsProbabilityMeasure P ∧
      P.support = (P.map Prod.fst).support ×ˢ (P.map Prod.snd).support ∧
      P ≠ (P.map Prod.fst).prod (P.map Prod.snd) :=
  ⟨Pcorr, inferInstance, Pcorr_support_rectangular, Pcorr_ne_product⟩

end HiddenChannelCapacity.FOL
