/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.FOL.Polish
import ZPM.MeasureTheory.AnalyticMeasurability.NullMeasurable
import ZPM.InformationTheory.MutualInformation.ZeroIffProduct

/-!
# Measurability-obstruction + conditional-independence leg (FOL HC lift — R4)

The conditional-independence leg (iv) of the Five-Way over the first-order type
space: the fibre-side face of the base factorization, phrased as vanishing mutual
information of a distribution. Its core is the **measurability obstruction** — a
descriptive-set-theoretic hurdle to even stating that fibre-side leg over the
infinite carrier. Marginalizing a definable family over the type space is an
existential projection, which produces an **analytic (Suslin) set** — analytic but in
general *not* Borel. The Stone → Polish → Borel carrier (R1–R3) clears this: analytic
subsets of the type space are `NullMeasurableSet` for any finite Borel measure
(Choquet capacitability / descriptive set theory). That is precisely what makes the
information-theoretic leg well-defined.

Connecting directly to the information-theoretic leg: for a Borel probability
measure on the product type space, zero mutual information of the two coordinates
is equivalent to the measure factoring as the product of its marginals — the
fibre-side shadow of the base factorization, its marginals exactly the analytic
projections the obstruction leg makes measurable.

## Main results

* `analytic_nullMeasurable` — analytic subsets of the type space are
  null-measurable (the measurability obstruction, cleared by the carrier);
* `marginal_nullMeasurable` — the projection (marginalization) of a Borel set over
  the product type space is null-measurable (analytic ⇒ null-measurable);
* `mi_eq_zero_iff_product` — zero mutual information ⇔ the measure factors, on the
  product type space (the information-theoretic leg, well-defined via the above).
-/

universe u v w

namespace HiddenChannelCapacity.FOL

open MeasureTheory InformationTheory FirstOrder.Language.Theory
open scoped FirstOrder

variable {L : FirstOrder.Language.{u, v}} {T : L.Theory} {α : Type w}
  [Countable (L[[α]].Sentence)]

/-- **The measurability-obstruction leg.** Analytic subsets of the type space —
including the analytic-but-not-Borel projections of Borel definable families — are
`NullMeasurableSet` for any finite Borel measure. The carrier (R1–R3) supplies the
`PolishSpace`/`BorelSpace` structure; this is the obstruction leg, cleared. -/
theorem analytic_nullMeasurable
    {μ : Measure (CompleteType T α)} [IsFiniteMeasure μ]
    {s : Set (CompleteType T α)} (hs : AnalyticSet s) :
    NullMeasurableSet s μ :=
  hs.nullMeasurableSet

/-- The **marginalization** (coordinate projection) of a Borel set over the product
type space is null-measurable: existential quantification yields an analytic set,
which the carrier makes null-measurable. This is the obstruction that makes the
mutual-information integrand well-defined. -/
theorem marginal_nullMeasurable
    {μ : Measure (CompleteType T α)} [IsFiniteMeasure μ]
    {s : Set (CompleteType T α × CompleteType T α)} (hs : MeasurableSet s) :
    NullMeasurableSet (Prod.snd '' s) μ :=
  (hs.analyticSet_image measurable_snd).nullMeasurableSet

omit [Countable (L[[α]].Sentence)] in
/-- **The information-theoretic leg.** For a Borel probability measure on the
product type space (with the standard absolute-continuity + finite-KL regularity),
zero mutual information of the two coordinates is equivalent to the measure
factoring as the product of its marginals. This is well-defined precisely because
the marginals — analytic projections — are null-measurable (`marginal_nullMeasurable`).
The ignorance factors ⇔ conditional independence of the two coordinates — the
fibre-side face of the base factorization. -/
theorem mi_eq_zero_iff_product
    (P : Measure (CompleteType T α × CompleteType T α)) [IsProbabilityMeasure P]
    (hac : P.AbsolutelyContinuous ((P.map Prod.fst).prod (P.map Prod.snd)))
    (hfin : InformationTheory.klDiv P ((P.map Prod.fst).prod (P.map Prod.snd)) ≠ ⊤) :
    mutualInformationReal P = 0 ↔ P = (P.map Prod.fst).prod (P.map Prod.snd) :=
  mutualInformationReal_eq_zero_iff_product P hac hfin

end HiddenChannelCapacity.FOL
