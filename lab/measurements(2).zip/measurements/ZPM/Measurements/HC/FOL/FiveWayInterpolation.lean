/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.FOL.FiveWayStructural
import ZPM.Measurements.HC.Abstract

/-!
# Interpolation leg of the first-order Five-Way (FOL HC lift — R1)

The interpolation leg (i) of the Five-Way over the structured ignorance
`κ ⊆ S × A × B`, lifted to the **infinite** (Set-based) coordinates of the
first-order type-space carrier: the syntactic face of whether the base ignorance
factors over its shared interface. A shared-vocabulary interpolant across the
interface is exactly the verdict discovered base structure licenses; where the base
carries a hidden channel, no such interpolant exists. This instantiates the
axiom-free abstract interpolation layer (`ZPM.Measurements.HC.Abstract`) at the Set
model: worlds are admissible triples, formulas are predicates on triples,
satisfaction is function application, and the shared/left/right partition is "depends
only on the shared / shared+left / shared+right coordinates".

This is the Set lift of `HiddenChannelCapacity.FiberedInterpolation` (which was
Finset-based); the interpolation proofs are first-order logic over membership and
carry over verbatim, dropping the `DecidableEq` instances they never used.

The shared-definability hypothesis is discharged here at the *finitary witness*
level (the `∃ admissible world with the same shared coordinate` formula). In the
genuine first-order instantiation at the type space this is the **Beth-definability**
hypothesis, related to the base logic's Craig interpolation — that is by design a
hypothesis, not reproved (Craig is not in Mathlib).

## Main results

* `interp_iff_decomposable` — interpolation (i) ⇔ decomposability (ii);
* `fiveWay_fol` — interpolation (i), decomposability (ii), amalgamation (ii′),
  fiber-rectangularity (iii), fiber-product surjectivity (v) are mutually
  equivalent (`List.TFAE`). The conditional-independence leg (iv) is the open
  frontier (a canonical fiber measure) and is omitted here.
-/

namespace HiddenChannelCapacity.FOL

variable {S A B : Type*}

/-- Satisfaction: a formula is a predicate on triples; satisfaction is application. -/
def SatP : (S × A × B) → ((S × A × B) → Prop) → Prop := fun w φ => φ w

/-- Two worlds are **shared-equivalent** when they agree on the shared coordinate. -/
def SharedEqP : (S × A × B) → (S × A × B) → Prop := fun w w' => w.1 = w'.1

/-- A formula is **shared** when it depends only on the shared coordinate. -/
def IsSharedP (φ : (S × A × B) → Prop) : Prop := ∀ w w', w.1 = w'.1 → (φ w ↔ φ w')

/-- A formula is **left** when it depends only on the shared and left coordinates. -/
def IsLeftP (φ : (S × A × B) → Prop) : Prop :=
  ∀ w w', w.1 = w'.1 → w.2.1 = w'.2.1 → (φ w ↔ φ w')

/-- A formula is **right** when it depends only on the shared and right coordinates. -/
def IsRightP (φ : (S × A × B) → Prop) : Prop :=
  ∀ w w', w.1 = w'.1 → w.2.2 = w'.2.2 → (φ w ↔ φ w')

/-- **(i) Interpolation property**: every valid left-to-right entailment over the
admissible worlds has a shared interpolant. -/
def HasInterpolationProperty (κ : Set (S × A × B)) : Prop :=
  ∀ φ ψ, IsLeftP φ → IsRightP ψ →
    (∀ w ∈ Abd SatP κ (∅ : Set _), SatP w φ → SatP w ψ) →
    HasInterpolant SatP IsSharedP κ (∅ : Set _) φ ψ

/-- **(ii′) Amalgamation**: the existential-amalgam form of decomposability,
`Abstract.IsDecomposable` at this model. -/
def Amalgamable (κ : Set (S × A × B)) : Prop :=
  IsDecomposable SatP SharedEqP IsLeftP IsRightP κ (∅ : Set _)

theorem mem_Abd_empty {κ : Set (S × A × B)} {w : S × A × B} :
    w ∈ Abd SatP κ (∅ : Set _) ↔ w ∈ κ := by
  unfold Abd
  constructor
  · rintro ⟨hw, _⟩
    exact hw
  · intro hw
    refine ⟨hw, ?_⟩
    intro φ hφ
    exact absurd hφ (Set.notMem_empty φ)

theorem shared_invariant :
    SharedInvariant (World := S × A × B) SatP SharedEqP IsSharedP := by
  intro χ hχ w₁ w₂ hshared
  exact hχ w₁ w₂ hshared

theorem shared_definability (κ : Set (S × A × B)) :
    HasSharedDefinability SatP SharedEqP IsSharedP IsLeftP κ (∅ : Set _) := by
  intro φ _hφL
  refine ⟨fun w => ∃ w', w' ∈ κ ∧ φ w' ∧ w'.1 = w.1, ?_, ?_, ?_⟩
  · intro w w' hw
    constructor
    · rintro ⟨u, hu, hφu, hu1⟩
      exact ⟨u, hu, hφu, by rw [hu1, hw]⟩
    · rintro ⟨u, hu, hφu, hu1⟩
      exact ⟨u, hu, hφu, by rw [hu1, hw]⟩
  · intro w hw hφw
    rw [mem_Abd_empty] at hw
    exact ⟨w, hw, hφw, rfl⟩
  · intro w hw
    obtain ⟨u, hu, hφu, hu1⟩ := hw
    refine ⟨u, mem_Abd_empty.mpr hu, hφu, ?_⟩
    unfold SharedEqP
    exact hu1

/-- Fibered (Set) decomposability coincides with the abstract decomposability. -/
theorem decomposable_iff_absDecomposable (κ : Set (S × A × B)) :
    Decomposable κ ↔ IsDecomposable SatP SharedEqP IsLeftP IsRightP κ (∅ : Set _) := by
  constructor
  · intro hDec w₁ w₂ hw₁ hw₂ hshared
    rw [mem_Abd_empty] at hw₁ hw₂
    unfold SharedEqP at hshared
    refine ⟨(w₁.1, w₁.2.1, w₂.2.2), ?_, ?_, ?_⟩
    · rw [mem_Abd_empty]
      have h1 : (w₁.1, w₁.2.1, w₁.2.2) ∈ κ := by
        rwa [show (w₁.1, w₁.2.1, w₁.2.2) = w₁ from rfl]
      have h2 : (w₁.1, w₂.2.1, w₂.2.2) ∈ κ := by
        have : (w₂.1, w₂.2.1, w₂.2.2) = w₂ := rfl
        rw [← hshared] at this
        rwa [this]
      exact hDec w₁.1 w₁.2.1 w₁.2.2 w₂.2.1 w₂.2.2 h1 h2
    · intro φ hφL
      unfold SatP
      exact hφL (w₁.1, w₁.2.1, w₂.2.2) w₁ rfl rfl
    · intro φ hφR
      unfold SatP
      exact hφR (w₁.1, w₁.2.1, w₂.2.2) w₂ hshared rfl
  · intro hAbs s a₁ b₁ a₂ b₂ h1 h2
    have hw₁ : (s, a₁, b₁) ∈ Abd SatP κ (∅ : Set _) := mem_Abd_empty.mpr h1
    have hw₂ : (s, a₂, b₂) ∈ Abd SatP κ (∅ : Set _) := mem_Abd_empty.mpr h2
    have hshared : SharedEqP (s, a₁, b₁) (s, a₂, b₂) := rfl
    obtain ⟨w, hw, hL, hR⟩ := hAbs hw₁ hw₂ hshared
    rw [mem_Abd_empty] at hw
    have hLind : IsLeftP (fun u : S × A × B => u.1 = s ∧ u.2.1 = a₁) := by
      intro u u' hu1 hu2
      show (u.1 = s ∧ u.2.1 = a₁) ↔ (u'.1 = s ∧ u'.2.1 = a₁)
      rw [hu1, hu2]
    have hRind : IsRightP (fun u : S × A × B => u.1 = s ∧ u.2.2 = b₂) := by
      intro u u' hu1 hu2
      show (u.1 = s ∧ u.2.2 = b₂) ↔ (u'.1 = s ∧ u'.2.2 = b₂)
      rw [hu1, hu2]
    have hwL : w.1 = s ∧ w.2.1 = a₁ := by
      have := (hL _ hLind)
      unfold SatP at this
      exact this.mpr ⟨rfl, rfl⟩
    have hwR : w.1 = s ∧ w.2.2 = b₂ := by
      have := (hR _ hRind)
      unfold SatP at this
      exact this.mpr ⟨rfl, rfl⟩
    have hwe : w = (s, a₁, b₂) := by
      apply Prod.ext hwL.1
      apply Prod.ext hwL.2 hwR.2
    rwa [hwe] at hw

/-- **Interpolation ⇔ decomposability** (i ⇔ ii) over first-order ignorance. -/
theorem interp_iff_decomposable (κ : Set (S × A × B)) :
    HasInterpolationProperty κ ↔ Decomposable κ := by
  constructor
  · intro hIP s a₁ b₁ a₂ b₂ h1 h2
    by_contra hcon
    let φ : (S × A × B) → Prop := fun w => w.1 = s ∧ w.2.1 = a₁
    let ψ : (S × A × B) → Prop := fun w => ¬(w.1 = s ∧ w.2.2 = b₂)
    have hφL : IsLeftP φ := by
      intro u u' hu1 hu2
      show (u.1 = s ∧ u.2.1 = a₁) ↔ (u'.1 = s ∧ u'.2.1 = a₁)
      rw [hu1, hu2]
    have hψR : IsRightP ψ := by
      intro u u' hu1 hu2
      show (¬(u.1 = s ∧ u.2.2 = b₂)) ↔ (¬(u'.1 = s ∧ u'.2.2 = b₂))
      rw [hu1, hu2]
    have hent : ∀ w ∈ Abd SatP κ (∅ : Set _), SatP w φ → SatP w ψ := by
      intro w hw hφw
      rw [mem_Abd_empty] at hw
      have hφw' : w.1 = s ∧ w.2.1 = a₁ := hφw
      show ¬(w.1 = s ∧ w.2.2 = b₂)
      intro hψw
      apply hcon
      have hwe : w = (s, a₁, b₂) := by
        apply Prod.ext hφw'.1
        exact Prod.ext hφw'.2 hψw.2
      rwa [hwe] at hw
    have hw₁ : (s, a₁, b₁) ∈ Abd SatP κ (∅ : Set _) := mem_Abd_empty.mpr h1
    have hw₂ : (s, a₂, b₂) ∈ Abd SatP κ (∅ : Set _) := mem_Abd_empty.mpr h2
    have hφw₁ : SatP (s, a₁, b₁) φ := ⟨rfl, rfl⟩
    have hψnotw₂ : ¬ SatP (s, a₂, b₂) ψ := fun hc => hc ⟨rfl, rfl⟩
    have hshared : SharedEqP (s, a₁, b₁) (s, a₂, b₂) := rfl
    have hno := reverse_direction SatP SharedEqP IsSharedP κ (∅ : Set _)
      shared_invariant hw₁ hw₂ hshared hφw₁ hψnotw₂ hent
    exact hno (hIP φ ψ hφL hψR hent)
  · intro hDec φ ψ hφL hψR hent
    have hAbs := (decomposable_iff_absDecomposable κ).mp hDec
    exact forward_direction SatP SharedEqP IsSharedP IsLeftP IsRightP κ (∅ : Set _)
      hAbs (shared_definability κ) hφL hψR hent

/-- **The first-order Five-Way (minus the open CI leg).** Interpolation (i),
decomposability (ii), amalgamation (ii′), fiber-rectangularity (iii), and
fiber-product surjectivity (v) are mutually equivalent over the infinite
coordinate ignorance `κ`. The conditional-independence leg (iv) needs a canonical
fiber measure and is the open frontier; it is not part of this equivalence. -/
theorem fiveWay_fol (κ : Set (S × A × B)) :
    List.TFAE
      [ HasInterpolationProperty κ,
        Decomposable κ,
        Amalgamable κ,
        FiberRect κ,
        FiberProductSurjective κ ] := by
  tfae_have 1 ↔ 2 := interp_iff_decomposable κ
  tfae_have 2 ↔ 3 := decomposable_iff_absDecomposable κ
  tfae_have 2 ↔ 4 := (fiberRect_iff_decomposable κ).symm
  tfae_have 2 ↔ 5 := decomposable_iff_fps κ
  tfae_finish

end HiddenChannelCapacity.FOL
