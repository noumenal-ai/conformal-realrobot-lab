/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Abstract
import Mathlib.ModelTheory.Types
import Mathlib.ModelTheory.LanguageMap

/-!
# Genuine first-order amalgamation over the type space (FOL HC lift)

The geometry legs of the Five-Way (`FOL/FiveWayStructural.lean`) are stated over a
bare `κ : Set (S × A × B)` with `{S A B : Type*}` — they are **carrier-agnostic**:
the proofs never touch the type-space structure, so amalgamation there collapses to
the trivial set-recombination `FiberProductSurjective`. That is *not* genuine
first-order amalgamation.

This file gives the genuine version. The worlds are **complete types** over a
parameter type partitioned into a shared block `S` and two private blocks `A`, `B`:
`CompleteType T (S ⊕ A ⊕ B)`. A formula is *shared / left / right* when it comes from
the sub-parameter language `L[[S]] / L[[S⊕A]] / L[[S⊕B]]` — pulled in along the
parameter inclusions via `lhomWithConstantsMap`. Two types are *shared-equivalent*
when they agree on every shared sentence.

Instantiating the axiom-free `Abstract` layer at this carrier, `IsDecomposable`
becomes **genuine type-reduct amalgamation**: two `κ`-types agreeing on their shared
sentences have a common `κ`-type agreeing with the first on left sentences and the
second on right sentences — i.e. a type over `S⊕A⊕B` amalgamating a shared+left type
and a shared+right type over their common shared reduct. Unlike the set version this
**need not hold**: a base-level sentence coupling the private blocks can withhold the
common type, and the shared vocabulary cannot witness that coupling. The coupling — a
base structure the interface ends provably cannot see — is the first-order hidden
channel.

## Main results

* `TypeAmalgamable` — genuine FOL amalgamation (the `Abstract.IsDecomposable`
  instance at the type space);
* `sharedInvariantT` — shared sentences cannot distinguish shared-equivalent types;
* `typeReverse_direction` — the obstruction: two `κ`-types agreeing on shared
  sentences but splitting a valid left⇒right entailment admit **no shared
  interpolant** (shared vocabulary cannot witness the private coupling);
* `typeAmalgamable_imp_interp` — amalgamation **plus Beth shared-definability**
  reconstructs the interpolant. The Beth hypothesis is genuine: unlike the
  carrier-agnostic case (where the witness was a finitary `∃`), over real types the
  shared witness must be an actual `L[[S]]`-sentence, which is exactly Beth
  definability (Craig/Beth are not in Mathlib — so this stays a hypothesis).
-/

universe u v w

namespace HiddenChannelCapacity.FOL

open Set FirstOrder FirstOrder.Language FirstOrder.Language.Theory
open scoped FirstOrder

variable {L : Language.{u, v}} {T : L.Theory} {S A B : Type w}

/-- The full parameter type: a shared block and two private blocks. -/
abbrev Params (S A B : Type w) : Type w := S ⊕ A ⊕ B

/-- Inclusion of the shared parameters into the full parameter type. -/
def incS : S → Params S A B := Sum.inl

/-- Inclusion of the shared+left parameters into the full parameter type. -/
def incSA : S ⊕ A → Params S A B := Sum.elim Sum.inl (fun a => Sum.inr (Sum.inl a))

/-- Inclusion of the shared+right parameters into the full parameter type. -/
def incSB : S ⊕ B → Params S A B := Sum.elim Sum.inl (fun b => Sum.inr (Sum.inr b))

/-- Satisfaction in the type model: a type satisfies a sentence iff it contains it. -/
def SatT (p : CompleteType T (Params S A B)) (φ : (L[[Params S A B]]).Sentence) : Prop :=
  φ ∈ p

/-- A sentence is **shared** when it is pulled in from `L[[S]]` along `incS`. -/
def IsSharedT (φ : (L[[Params S A B]]).Sentence) : Prop :=
  φ ∈ Set.range (L.lhomWithConstantsMap (incS : S → Params S A B)).onSentence

/-- A sentence is **left** when it is pulled in from `L[[S⊕A]]` along `incSA`. -/
def IsLeftT (φ : (L[[Params S A B]]).Sentence) : Prop :=
  φ ∈ Set.range (L.lhomWithConstantsMap (incSA : S ⊕ A → Params S A B)).onSentence

/-- A sentence is **right** when it is pulled in from `L[[S⊕B]]` along `incSB`. -/
def IsRightT (φ : (L[[Params S A B]]).Sentence) : Prop :=
  φ ∈ Set.range (L.lhomWithConstantsMap (incSB : S ⊕ B → Params S A B)).onSentence

/-- Two types are **shared-equivalent** when they agree on every shared sentence. -/
def SharedEqT (p q : CompleteType T (Params S A B)) : Prop :=
  ∀ φ, IsSharedT (L := L) φ → (φ ∈ p ↔ φ ∈ q)

/-- **Genuine first-order amalgamation.** Two admissible types agreeing on their
shared sentences amalgamate into an admissible type agreeing with the first on left
sentences and the second on right sentences — the `Abstract.IsDecomposable` instance
at the type space. The factorization of structured ignorance, in the type category. -/
def TypeAmalgamable (κ : Set (CompleteType T (Params S A B))) : Prop :=
  IsDecomposable SatT SharedEqT IsLeftT IsRightT κ (∅ : Set _)

/-- The interpolation property at the type space: every valid left⇒right entailment
over `κ` has a shared interpolant. -/
def HasTypeInterpolationProperty (κ : Set (CompleteType T (Params S A B))) : Prop :=
  ∀ φ ψ, IsLeftT (L := L) φ → IsRightT (L := L) ψ →
    (∀ w ∈ Abd SatT κ (∅ : Set _), SatT w φ → SatT w ψ) →
    HasInterpolant SatT IsSharedT κ (∅ : Set _) φ ψ

/-- Shared sentences cannot distinguish shared-equivalent types — immediate from the
definition of `SharedEqT`. This discharges the `SharedInvariant` hypothesis of the
abstract layer at the type carrier. -/
theorem sharedInvariantT :
    SharedInvariant (World := CompleteType T (Params S A B)) SatT SharedEqT IsSharedT := by
  intro χ hχ p q hpq
  exact hpq χ hχ

/-- **The first-order hidden channel (reverse direction).** If two admissible types
`p₁`, `p₂` agree on every shared sentence yet `p₁` satisfies a left sentence `φ` while
`p₂` refutes a right sentence `ψ` that `φ` entails over `κ`, then **no shared
interpolant** mediates `φ ⇒ ψ`. The shared vocabulary is blind to the coupling between
the private blocks. -/
theorem typeReverse_direction {κ : Set (CompleteType T (Params S A B))}
    {p₁ p₂ : CompleteType T (Params S A B)}
    (hp₁ : p₁ ∈ Abd SatT κ (∅ : Set _)) (hp₂ : p₂ ∈ Abd SatT κ (∅ : Set _))
    (hshared : SharedEqT p₁ p₂)
    {φ ψ : (L[[Params S A B]]).Sentence} (hφ : SatT p₁ φ) (hψ : ¬ SatT p₂ ψ)
    (hentail : ∀ w ∈ Abd SatT κ (∅ : Set _), SatT w φ → SatT w ψ) :
    ¬ HasInterpolant SatT IsSharedT κ (∅ : Set _) φ ψ :=
  reverse_direction SatT SharedEqT IsSharedT κ (∅ : Set _) sharedInvariantT
    hp₁ hp₂ hshared hφ hψ hentail

/-- **The first-order Maksimova correspondence (forward direction, Beth-conditional).**
Genuine type amalgamation together with Beth shared-definability reconstructs the
interpolant for every valid left⇒right entailment. The Beth hypothesis is the genuine
first-order content: the shared witness must be an actual `L[[S]]`-sentence. -/
theorem typeAmalgamable_imp_interp {κ : Set (CompleteType T (Params S A B))}
    (hAmalg : TypeAmalgamable κ)
    (hBeth : HasSharedDefinability SatT SharedEqT IsSharedT IsLeftT κ (∅ : Set _)) :
    HasTypeInterpolationProperty κ := by
  intro φ ψ hφ hψ hent
  exact forward_direction SatT SharedEqT IsSharedT IsLeftT IsRightT κ (∅ : Set _)
    hAmalg hBeth hφ hψ hent

/-- **The oscillation theorem over the first-order type space.** Along a trajectory of
type-ignorance states `κseq`, if every state is Beth-shared-definable and some state
exhibits a cross-domain discovery (a non-interpolable left⇒right entailment), then the
states cannot all be type-amalgamable: the factorization obstruction must spike
(`HC > 0`) at some step.

This is a *direct instantiation* of the substrate-neutral `oscillation_theorem` at the
genuine type carrier — the proof is `oscillation_theorem` itself. Its one substantive
feature is the **explicit `HasSharedDefinability` (Beth) hypothesis**: that is exactly
where the first-order content enters. In real first-order logic Beth's definability
theorem *holds*, so this hypothesis is always dischargeable and oscillation is
unconditional — but Beth is not in Mathlib, so it is carried as a hypothesis. The same
hypothesis is *false* in full second-order logic, so this is the precise point at which
oscillation could break under the FOL→SOL shift. -/
theorem typeOscillation {Step : Type*}
    (κseq : Step → Set (CompleteType T (Params S A B)))
    (hBeth : ∀ t, HasSharedDefinability SatT SharedEqT IsSharedT IsLeftT (κseq t) (∅ : Set _))
    (hcross : ∃ t, HasCrossDiscovery SatT IsSharedT IsLeftT IsRightT (κseq t) (∅ : Set _)) :
    ¬ ∀ t, TypeAmalgamable (κseq t) :=
  oscillation_theorem SatT SharedEqT IsSharedT IsLeftT IsRightT
    κseq (fun _ => (∅ : Set _)) hBeth hcross

end HiddenChannelCapacity.FOL
