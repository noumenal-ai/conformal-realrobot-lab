/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.FOL.TypeSpaceCompact
import ZPM.Measurements.HC.FOL.TypeSpaceSeparation
import Mathlib.Topology.Metrizable.Urysohn
import Mathlib.Topology.MetricSpace.Polish
import Mathlib.MeasureTheory.Constructions.BorelSpace.Basic

/-!
# Polish + Borel structure on the first-order type space (FOL HC lift — R3)

For a **countable** language (`[Countable (L[[α]].Sentence)]`), the Stone topology
on `CompleteType T α` is **Polish** and carries its **Borel** measurable structure.

The chain: the clopen base `range typesWith` is countable, so the finite-intersection
basis is countable ⇒ `SecondCountableTopology`; compact + T2 (R2) ⇒ T3, so with
second-countability Urysohn metrization gives `MetrizableSpace`; a compact metrizable
space is completely metrizable, so `PolishSpace`. Finally the Borel σ-algebra makes
it a `BorelSpace`.

This lands the carrier for the FOL HC measure leg: `CompleteType T α` is now a Polish
Borel space, exactly the hypotheses ZPM's Choquet/analytic tower and the FLT
borel→analytic bridge consume. The order is base-first: this space is the Stone-dual
carrier of the base stratum, fixed as geometry before any weighting, and the Polish Borel
structure is only what lets a fibre-side (measure) leg later be laid over that base.
-/

universe u v w

namespace FirstOrder.Language.Theory.CompleteType

open Set TopologicalSpace

variable {L : Language.{u, v}} {T : L.Theory} {α : Type w}

section Countable

variable [Countable (L[[α]].Sentence)]

/-- The Stone topology is second-countable for a countable language: the clopen base
`range typesWith` is countable, hence so is the finite-intersection basis. -/
instance instSecondCountableTopology : SecondCountableTopology (T.CompleteType α) := by
  apply (TopologicalSpace.isTopologicalBasis_of_subbasis
    (s := Set.range (T.typesWith)) rfl).secondCountableTopology
  exact (Set.countable_setOf_finite_subset (Set.countable_range _)).image _

/-- The type space is metrizable (compact + T2 ⇒ T3; with second-countability,
Urysohn's metrization theorem applies). -/
instance instMetrizableSpace : TopologicalSpace.MetrizableSpace (T.CompleteType α) :=
  TopologicalSpace.metrizableSpace_of_t3_secondCountable _

/-- A compact metrizable space is completely metrizable (the compatible metric is
complete by compactness). -/
instance instCompletelyMetrizable : IsCompletelyMetrizableSpace (T.CompleteType α) := by
  letI : MetricSpace (T.CompleteType α) :=
    TopologicalSpace.metrizableSpaceMetric (T.CompleteType α)
  infer_instance

/-- The type space is **Polish** (a compact metrizable second-countable space). -/
instance instPolishSpace : PolishSpace (T.CompleteType α) := inferInstance

/-- The Borel σ-algebra on the type space. -/
instance instMeasurableSpace : MeasurableSpace (T.CompleteType α) := borel _

/-- The measurable structure is the Borel one. -/
instance instBorelSpace : BorelSpace (T.CompleteType α) := ⟨rfl⟩

end Countable

end FirstOrder.Language.Theory.CompleteType
