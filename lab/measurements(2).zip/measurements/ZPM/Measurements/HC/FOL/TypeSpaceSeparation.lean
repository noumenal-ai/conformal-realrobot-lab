/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.FOL.TypeSpaceTopology
import Mathlib.Topology.Connected.TotallyDisconnected
import Mathlib.Topology.Connected.Separation

/-!
# Separation of the first-order type space (FOL HC lift — R2, separation half)

The Stone topology on `CompleteType T α` (the Stone-dual carrier of the base
stratum) is **totally separated**: two distinct complete types differ on some
sentence `φ`, and the disjoint clopen partition
`typesWith φ ⊔ typesWith ∼φ` (which covers the whole space by maximality)
separates them. `TotallySeparatedSpace` yields `T2Space` and
`TotallyDisconnectedSpace` for free.

This discharges the **T2 + totally-disconnected** part of R2. The remaining part,
**compactness** (`CompactSpace`), is the FOL compactness theorem in topological
form and is built separately in `TypeSpaceCompact`.
-/

universe u v w

namespace FirstOrder.Language.Theory.CompleteType

open Set

variable {L : Language.{u, v}} {T : L.Theory} {α : Type w}

/-- The type space is **totally separated**: any two distinct complete types are
split by the disjoint clopen partition `typesWith φ ⊔ typesWith ∼φ`, where `φ` is
a sentence on which they differ. -/
instance instTotallySeparatedSpace : TotallySeparatedSpace (T.CompleteType α) := by
  refine ⟨fun p _ q _ hpq => ?_⟩
  -- p ≠ q ⇒ some sentence distinguishes them.
  have hex : ∃ φ : L[[α]].Sentence, ¬ (φ ∈ p ↔ φ ∈ q) := by
    by_contra h
    exact hpq (SetLike.ext fun φ => not_not.mp (not_exists.mp h φ))
  obtain ⟨φ, hφ⟩ := hex
  rcases Classical.em (φ ∈ p) with hp | hp
  · -- φ ∈ p, hence φ ∉ q; separate by `typesWith φ` (∋ p) and `typesWith ∼φ` (∋ q).
    have hq : φ ∉ q := fun hqmem => hφ (iff_of_true hp hqmem)
    refine ⟨T.typesWith φ, T.typesWith ∼φ, isOpen_typesWith φ, isOpen_typesWith ∼φ,
      (mem_typesWith_iff φ p).mpr hp,
      (mem_typesWith_iff ∼φ q).mpr ((not_mem_iff q φ).mpr hq),
      fun r _ => ?_, ?_⟩
    · rcases r.mem_or_not_mem φ with h | h
      · exact Set.mem_union_left _ ((mem_typesWith_iff φ r).mpr h)
      · exact Set.mem_union_right _ ((mem_typesWith_iff ∼φ r).mpr h)
    · rw [typesWith_not]; exact disjoint_compl_right
  · -- φ ∉ p, hence φ ∈ q; separate by `typesWith ∼φ` (∋ p) and `typesWith φ` (∋ q).
    have hq : φ ∈ q := by
      by_contra hqn
      exact hφ (iff_of_false hp hqn)
    refine ⟨T.typesWith ∼φ, T.typesWith φ, isOpen_typesWith ∼φ, isOpen_typesWith φ,
      (mem_typesWith_iff ∼φ p).mpr ((not_mem_iff p φ).mpr hp),
      (mem_typesWith_iff φ q).mpr hq,
      fun r _ => ?_, ?_⟩
    · rcases r.mem_or_not_mem φ with h | h
      · exact Set.mem_union_right _ ((mem_typesWith_iff φ r).mpr h)
      · exact Set.mem_union_left _ ((mem_typesWith_iff ∼φ r).mpr h)
    · rw [typesWith_not]; exact disjoint_compl_left

/-- Consequence: the type space is Hausdorff. -/
theorem t2Space : T2Space (T.CompleteType α) := inferInstance

/-- Consequence: the type space is totally disconnected. -/
theorem totallyDisconnectedSpace : TotallyDisconnectedSpace (T.CompleteType α) :=
  inferInstance

end FirstOrder.Language.Theory.CompleteType
