/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Marginals
import ZPM.Measurements.HC.HigherObstruction

/-!
# The amalgamation leg: running intersection forces gluing

The multipartite amalgamation theorem (the positive Vorob'ev direction, certificate form). The
base structure is the running intersection property of the cover's teams; once that geometry is
present, the natural join of any pairwise-consistent family of local structures realizes every
member exactly (`projS_joinFam`), so the local ends assemble into a single global structure
(`glues_of_rip`). The direction runs base-to-local: the cover's geometry is what suffices, and
pairwise consistency is all the local side is asked to supply.

The grammar: a `LocalStruct` bundles a team with a structure on its marginal type; a family is a
list, its head the last-eliminated team; `RIP` demands each member meet the union of the later
members inside a single later member. The proof is induction along the list: the presheaf law
(`projS_image_restrict₂`) transports the inductive marginal down to the interface, pairwise
consistency matches it with the new member, and the SPLICE (`g` on the new team, the inductive
configuration elsewhere) satisfies every constraint because all older teams meet the new one
inside the interface. Nonempty parts replace any covering condition: uncovered coordinates fill
arbitrarily.

The Specker triangle marks the base-side boundary from below: its cover admits no running-
intersection order (`speckerFam_no_rip`), and that missing base structure is exactly what no
local data can replace. The family is pairwise consistent (`speckerFam_consistent`) yet no
global structure realizes it (`speckerFam_not_glues`, from `specker_not_glues`). Acyclicity as
an order-free cover property and its Graham-reduction decision procedure are the named next edge.
-/

namespace HiddenChannelCapacity

open Finset

variable {ι : Type*} [DecidableEq ι] {X : ι → Type*} [∀ i, DecidableEq (X i)]

/-- A **local structure**: a team of parts together with an ignorance structure on the team's
marginal type. -/
structure LocalStruct (ι : Type*) (X : ι → Type*) where
  /-- The team of parts this local structure constrains. -/
  team : Finset ι
  /-- The admissible local configurations. -/
  rel : Finset (∀ i : team, X i)

/-- The interface marginal of a local structure over a sub-team. -/
def LocalStruct.imarg (L : LocalStruct ι X) {S : Finset ι} (hS : S ⊆ L.team) :
    Finset (∀ i : S, X i) :=
  L.rel.image (Finset.restrict₂ hS)

omit [DecidableEq ι] in
/-- Sub-marginalizing an interface marginal composes. -/
lemma LocalStruct.imarg_image (L : LocalStruct ι X) {S T : Finset ι}
    (hS : S ⊆ T) (hT : T ⊆ L.team) :
    (L.imarg hT).image (Finset.restrict₂ hS) = L.imarg (hS.trans hT) := by
  rw [LocalStruct.imarg, LocalStruct.imarg, Finset.image_image,
    Finset.restrict₂_comp_restrict₂]

/-- **Pairwise consistency**: any two members expose the same interface marginal. -/
def Consistent (fam : List (LocalStruct ι X)) : Prop :=
  ∀ L₁ ∈ fam, ∀ L₂ ∈ fam,
    L₁.imarg (Finset.inter_subset_left : L₁.team ∩ L₂.team ⊆ L₁.team)
      = L₂.imarg (Finset.inter_subset_right : L₁.team ∩ L₂.team ⊆ L₂.team)

/-- **Gluing**: some global structure realizes every member exactly. -/
def Glues [Fintype ι] (fam : List (LocalStruct ι X)) : Prop :=
  ∃ κ : Finset (∀ i, X i), ∀ L ∈ fam, projS κ L.team = L.rel

/-- The **natural join** of a family: all global configurations passing every local test. -/
def joinFam [Fintype ι] [∀ i, Fintype (X i)] (fam : List (LocalStruct ι X)) :
    Finset (∀ i, X i) :=
  Finset.univ.filter (fun f => ∀ L ∈ fam, L.team.restrict f ∈ L.rel)

lemma mem_joinFam [Fintype ι] [∀ i, Fintype (X i)] {fam : List (LocalStruct ι X)}
    {f : ∀ i, X i} :
    f ∈ joinFam fam ↔ ∀ L ∈ fam, L.team.restrict f ∈ L.rel := by
  simp [joinFam]

/-- The union of a family's teams. -/
def famCover : List (LocalStruct ι X) → Finset ι
  | [] => ∅
  | L :: rest => L.team ∪ famCover rest

omit [∀ i, DecidableEq (X i)] in
lemma team_subset_famCover {fam : List (LocalStruct ι X)} {L : LocalStruct ι X}
    (hL : L ∈ fam) : L.team ⊆ famCover fam := by
  induction fam with
  | nil => exact absurd hL (List.not_mem_nil)
  | cons L₀ rest ih =>
    rcases List.mem_cons.mp hL with rfl | hL'
    · exact Finset.subset_union_left
    · exact (ih hL').trans Finset.subset_union_right

/-- **Running intersection property**: each member meets the union of the later members inside a
single later member (the head is the last-eliminated team). -/
def RIP : List (LocalStruct ι X) → Prop
  | [] => True
  | L :: rest => (rest = [] ∨ ∃ L' ∈ rest, L.team ∩ famCover rest ⊆ L'.team) ∧ RIP rest

instance decidableRIP : ∀ fam : List (LocalStruct ι X), Decidable (RIP fam)
  | [] => .isTrue trivial
  | L :: rest =>
    haveI : Decidable (RIP rest) := decidableRIP rest
    inferInstanceAs (Decidable
      ((rest = [] ∨ ∃ L' ∈ rest, L.team ∩ famCover rest ⊆ L'.team) ∧ RIP rest))

omit [DecidableEq ι] [∀ i, DecidableEq (X i)] in
/-- Any local configuration extends to a global one, on nonempty parts. -/
lemma exists_restrict_eq [∀ i, Nonempty (X i)] (T : Finset ι) (g : ∀ i : T, X i) :
    ∃ f : ∀ i, X i, T.restrict f = g := by
  classical
  exact ⟨fun i => if hi : i ∈ T then g ⟨i, hi⟩ else Classical.arbitrary (X i),
    funext fun i => dif_pos i.2⟩

/-- **The amalgamation theorem** (positive Vorob'ev, certificate form): once the cover carries
the running intersection property, the natural join of any pairwise-consistent family realizes
every member exactly, so the base geometry licenses the global structure. -/
theorem projS_joinFam [Fintype ι] [∀ i, Fintype (X i)] [∀ i, Nonempty (X i)]
    (fam : List (LocalStruct ι X)) (hrip : RIP fam) (hcons : Consistent fam) :
    ∀ L ∈ fam, projS (joinFam fam) L.team = L.rel := by
  classical
  induction fam with
  | nil => exact fun L hL => absurd hL (List.not_mem_nil)
  | cons L₀ rest ih =>
    obtain ⟨hhead, hripr⟩ := hrip
    have hconsr : Consistent rest := fun A hA B hB =>
      hcons A (List.mem_cons_of_mem _ hA) B (List.mem_cons_of_mem _ hB)
    have ih' := ih hripr hconsr
    -- the inclusion `projS (joinFam fam) L.team ⊆ L.rel` holds for every member outright
    have hsub : ∀ L ∈ L₀ :: rest, projS (joinFam (L₀ :: rest)) L.team ⊆ L.rel := by
      intro L hL g hg
      obtain ⟨f, hf, rfl⟩ := Finset.mem_image.mp hg
      exact mem_joinFam.mp hf L hL
    rcases hhead with rfl | ⟨L', hL', hint⟩
    · -- base: a single team; realize by arbitrary extension
      intro L hL
      have hL0 : L = L₀ := by simpa using hL
      subst hL0
      refine Finset.Subset.antisymm (hsub L (by simp)) ?_
      intro g hg
      obtain ⟨f, hf⟩ := exists_restrict_eq L.team g
      refine Finset.mem_image.mpr ⟨f, mem_joinFam.mpr ?_, hf⟩
      intro L' hL'
      have : L' = L := by simpa using hL'
      subst this
      rw [hf]
      exact hg
    · -- inductive step: the interface S sits inside the later member L'
      set S : Finset ι := L₀.team ∩ famCover rest with hSdef
      have hSL₀ : S ⊆ L₀.team := Finset.inter_subset_left
      have hSL' : S ⊆ L'.team := hint
      have hSint : S ⊆ L₀.team ∩ L'.team :=
        Finset.subset_inter hSL₀ (hSL'.trans (fun _ h => h))
      -- pairwise consistency, pushed down to the interface `S`
      have hcons₀ := hcons L₀ (List.mem_cons_self) L' (List.mem_cons_of_mem _ hL')
      have hSagree : L₀.imarg hSL₀ = L'.imarg hSL' := by
        have h := congrArg (Finset.image (Finset.restrict₂ hSint)) hcons₀
        rwa [LocalStruct.imarg_image, LocalStruct.imarg_image] at h
      -- the key: the join of the tail exposes exactly `L₀`'s interface marginal on `S`
      have hkey : projS (joinFam rest) S = L₀.imarg hSL₀ := by
        rw [← projS_image_restrict₂ (joinFam rest) hSL',
          show projS (joinFam rest) L'.team = L'.rel from ih' L' hL',
          show L'.rel.image (Finset.restrict₂ hSL') = L'.imarg hSL' from rfl, hSagree]
      -- the splice: `g` on the head's team, an inductive configuration elsewhere
      have hsplice : ∀ f ∈ joinFam rest, ∀ g ∈ L₀.rel,
          S.restrict f = Finset.restrict₂ hSL₀ g →
          ∃ f' ∈ joinFam (L₀ :: rest),
            L₀.team.restrict f' = g ∧ ∀ T : Finset ι, T ⊆ famCover rest →
              T.restrict f' = T.restrict f := by
        intro f hf g hg htrace
        set f' : ∀ i, X i := fun i =>
          if hi : i ∈ L₀.team then g ⟨i, hi⟩ else f i with hf'def
        have hres₀ : L₀.team.restrict f' = g := funext fun i => dif_pos i.2
        have hagree : ∀ (i : ι) (hiL : i ∈ L₀.team), i ∈ famCover rest →
            g ⟨i, hiL⟩ = f i := by
          intro i hiL hiR
          have hiS : i ∈ S := Finset.mem_inter.mpr ⟨hiL, hiR⟩
          have := congrFun htrace ⟨i, hiS⟩
          exact this.symm
        have hrestT : ∀ T : Finset ι, T ⊆ famCover rest → T.restrict f' = T.restrict f := by
          intro T hT
          funext i
          by_cases hi : (i : ι) ∈ L₀.team
          · calc T.restrict f' i = g ⟨i, hi⟩ := dif_pos hi
              _ = f i := hagree i hi (hT i.2)
          · exact dif_neg hi
        refine ⟨f', mem_joinFam.mpr ?_, hres₀, hrestT⟩
        intro L hL
        rcases List.mem_cons.mp hL with rfl | hL'
        · rw [hres₀]; exact hg
        · rw [hrestT L.team (team_subset_famCover hL')]
          exact mem_joinFam.mp hf L hL'
      -- both legs
      intro L hL
      refine Finset.Subset.antisymm (hsub L hL) ?_
      rcases List.mem_cons.mp hL with rfl | hLr
      · -- leg (a): realize the head
        intro g hg
        have htr : Finset.restrict₂ hSL₀ g ∈ projS (joinFam rest) S := by
          rw [hkey]
          exact Finset.mem_image_of_mem _ hg
        obtain ⟨f, hf, htrace⟩ := Finset.mem_image.mp htr
        obtain ⟨f', hf', hres₀, _⟩ := hsplice f hf g hg htrace
        exact Finset.mem_image.mpr ⟨f', hf', hres₀⟩
      · -- leg (b): preserve the tail
        intro h hh
        have hrealize := ih' L hLr
        have : h ∈ projS (joinFam rest) L.team := hrealize ▸ hh
        obtain ⟨f, hf, hres⟩ := Finset.mem_image.mp this
        have htr : S.restrict f ∈ L₀.imarg hSL₀ := by
          rw [← hkey]
          exact Finset.mem_image_of_mem _ hf
        obtain ⟨g, hg, htrace⟩ := Finset.mem_image.mp htr
        obtain ⟨f', hf', _, hrestT⟩ := hsplice f hf g hg htrace.symm
        refine Finset.mem_image.mpr ⟨f', hf', ?_⟩
        rw [hrestT L.team (team_subset_famCover hLr)]
        exact hres

/-- **The amalgamation leg**: over a running-intersection cover, a pairwise-consistent family
glues: the base geometry forces the global structure. -/
theorem glues_of_rip [Fintype ι] [∀ i, Fintype (X i)] [∀ i, Nonempty (X i)]
    (fam : List (LocalStruct ι X)) (hrip : RIP fam) (hcons : Consistent fam) :
    Glues fam :=
  ⟨joinFam fam, projS_joinFam fam hrip hcons⟩

/-! ### The Specker triangle closes the leg from below -/

/-- The Specker triangle as a family of local structures. -/
def speckerFam : List (LocalStruct (Fin 3) (fun _ => Fin 2)) :=
  [⟨S01, diag01⟩, ⟨S12, diag12⟩, ⟨S02, anti02⟩]

instance decidableConsistent (fam : List (LocalStruct ι X)) :
    Decidable (Consistent fam) := by
  unfold Consistent
  infer_instance

/-- The Specker family is pairwise consistent. -/
theorem speckerFam_consistent : Consistent speckerFam := by decide

/-- The six orderings of the Specker family. -/
def speckerOrders : List (List (LocalStruct (Fin 3) (fun _ => Fin 2))) :=
  [[⟨S01, diag01⟩, ⟨S12, diag12⟩, ⟨S02, anti02⟩],
   [⟨S01, diag01⟩, ⟨S02, anti02⟩, ⟨S12, diag12⟩],
   [⟨S12, diag12⟩, ⟨S01, diag01⟩, ⟨S02, anti02⟩],
   [⟨S12, diag12⟩, ⟨S02, anti02⟩, ⟨S01, diag01⟩],
   [⟨S02, anti02⟩, ⟨S01, diag01⟩, ⟨S12, diag12⟩],
   [⟨S02, anti02⟩, ⟨S12, diag12⟩, ⟨S01, diag01⟩]]

/-- The Specker family admits no running-intersection order: every one of its six orderings
fails `RIP`. (The order-free `Perm`-quantified form arrives with the Graham-reduction tick.) -/
theorem speckerFam_no_rip : ∀ fam ∈ speckerOrders, ¬ RIP fam := by decide

/-- The Specker family does not glue (from the concrete non-realization). -/
theorem speckerFam_not_glues : ¬ Glues speckerFam := by
  rintro ⟨κ, hκ⟩
  exact specker_not_glues ⟨κ,
    hκ ⟨S01, diag01⟩ (by simp [speckerFam]),
    hκ ⟨S12, diag12⟩ (by simp [speckerFam]),
    hκ ⟨S02, anti02⟩ (by simp [speckerFam])⟩

end HiddenChannelCapacity
