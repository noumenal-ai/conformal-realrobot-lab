/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Dirac

/-!
# The PR box as a cycle obstruction: possibilistic CHSH contextuality

The quantum leg of the discrete Vorob'ev programme (FLAGSHIP_COHOMOLOGY_URS, Q-CHSH). The
CHSH measurement scenario is a COVER: four observables `A = 0`, `B = 1`, `A' = 2`, `B' = 3`
with jointly measurable pairs forming the 4-cycle `{A,B}, {B,A'}, {A',B'}, {B',A}`. The
explanation runs base-first, from the cover's geometry to what local measurement can do. The
cover is not acyclic (`chshCover_not_acyclic`, by `decide`), and that cyclicity of the base
alone licenses a global observable, the cyclic parity pairing around the 4-cycle, that no
local end can reproduce. The capstone applies with no experiment and no chosen distribution:
purely from the cover's shape the scenario hosts a pairwise-consistent family of nonempty
local relations that supports no global section (`chsh_hosts_nonglue`). The base geometry
forces the possibility of contextuality before any per-context data is fixed.

The canonical witness is written out explicitly: the **possibilistic PR box** `prBox`,
the parity relations `x_i + x_j = c_ij` with an odd constant sum, exactly the affine
engine's odd-hosted-dependency datum on the 4-cycle. The kernel facts read from the base
structure to the failure of every local end. It is pairwise consistent (`prBox_consistent`)
and locally nonempty (`prBox_rels_nonempty`), so each local end is impeccable, yet the
global pairing the base licenses admits **no global section at all**
(`prBox_no_global_section` : `joinFam prBox = ∅`, strong contextuality in the
Abramsky–Brandenburger possibilistic sense), so no global relation restricts onto the
contexts (`prBox_not_glues`). The impossibility is a property of the cover's geometry, not a
deficiency of the local data, which is maximal.

In the flagship's terms the PR box is the paradigm nonzero class: the 1-cochain of
per-context parities whose cyclic sum is `1`, a global invariant of the base non-splittable
because the cover's restriction maps telescope every variable twice, the base-side quantity
no amount of local measurement carries. This file pins the instance the candidate cohomology
must detect (URS kill-criterion T2).
-/

namespace HiddenChannelCapacity

open Finset

/-- The CHSH cover: observables `A = 0`, `B = 1`, `A' = 2`, `B' = 3`; contexts are the
jointly measurable pairs, forming a 4-cycle. -/
def chshCover : Finset (Finset (Fin 4)) :=
  {{0, 1}, {1, 2}, {2, 3}, {3, 0}}

/-- The CHSH cover is cyclic: the shape that hosts contextuality. -/
theorem chshCover_not_acyclic : ¬ Acyclic chshCover := by decide

/-- **The base geometry forces contextuality**: purely from the cover's cyclic shape, the
CHSH scenario hosts a pairwise-consistent family of nonempty local relations with no global
section, before any local data is chosen. -/
theorem chsh_hosts_nonglue :
    ∃ fam : List (LocalStruct (Fin 4) (fun _ => ZMod 2)),
      fam.map (·.team) = chshCover.toList ∧ Consistent fam ∧
      (∀ L ∈ fam, L.rel.Nonempty) ∧ ¬ Glues fam :=
  exists_consistent_not_glues_of_not_acyclic _ chshCover_not_acyclic

/-- The parity support on a context: outcomes summing to `c`. -/
def prRel (T : Finset (Fin 4)) (c : ZMod 2) : Finset (↥T → ZMod 2) :=
  Finset.univ.filter (fun f => (∑ i, f i) = c)

/-- **The possibilistic PR box**: perfectly correlated on three contexts, anticorrelated on
the fourth — the odd affine datum on the 4-cycle. -/
def prBox : List (LocalStruct (Fin 4) (fun _ => ZMod 2)) :=
  [⟨{0, 1}, prRel {0, 1} 0⟩, ⟨{1, 2}, prRel {1, 2} 0⟩,
   ⟨{2, 3}, prRel {2, 3} 0⟩, ⟨{3, 0}, prRel {3, 0} 1⟩]

/-- The PR box lives on the CHSH cover. -/
theorem prBox_teams : (prBox.map (·.team)).toFinset = chshCover := by decide

/-- The PR box is pairwise consistent: every context marginalizes identically on overlaps
(each single observable looks uniform). -/
theorem prBox_consistent : Consistent prBox := by decide

/-- Every context's local relation is nonempty. -/
theorem prBox_rels_nonempty : ∀ L ∈ prBox, L.rel.Nonempty := by decide

/-- **Strong contextuality**: the global pairing the cover licenses admits no global
section whatsoever. No deterministic assignment to all four observables is compatible with
every context's local relation. The parity telescope: each observable appears in exactly
two contexts, so the four constraints the base imposes sum to `0 = 1`. -/
theorem prBox_no_global_section : joinFam prBox = ∅ := by decide

/-- The PR box does not glue: no global relation projects exactly onto its contexts. -/
theorem prBox_not_glues : ¬ Glues prBox := by
  rintro ⟨κ, hκ⟩
  have hne : κ.Nonempty := by
    rcases Finset.eq_empty_or_nonempty κ with rfl | h
    · have h1 : projS (∅ : Finset (Fin 4 → ZMod 2)) ({0, 1} : Finset (Fin 4)) =
          prRel {0, 1} 0 :=
        hκ _ (List.mem_cons_self ..)
      rw [projS, Finset.image_empty] at h1
      have h2 : (prRel ({0, 1} : Finset (Fin 4)) 0).Nonempty := by decide
      rw [← h1] at h2
      exact absurd h2 (by simp)
    · exact h
  obtain ⟨f, hf⟩ := hne
  have hjoin : f ∈ joinFam prBox := by
    rw [mem_joinFam]
    intro L hL
    rw [← hκ L hL]
    exact Finset.mem_image_of_mem _ hf
  rw [prBox_no_global_section] at hjoin
  exact absurd hjoin (Finset.notMem_empty f)

/-! ### The acyclic control: no contextuality without the cycle -/

/-- The Bell path scenario: the CHSH contexts with the closing pair removed. -/
def bellPathCover : Finset (Finset (Fin 4)) :=
  {{0, 1}, {1, 2}, {2, 3}}

/-- Removing one context makes the scenario acyclic. -/
theorem bellPathCover_acyclic : Acyclic bellPathCover := by decide

/-- **No contextuality without the cycle**: when the base is acyclic (the Bell path), the
geometry licenses base-side reconstruction, so every pairwise-consistent family of nonempty
local relations glues to a global hidden-variable relation. Contextuality of the CHSH
scenario is exactly its cover's cyclicity, a property of the base alone. -/
theorem bellPath_no_contextuality :
    ∀ fam : List (LocalStruct (Fin 4) (fun _ => ZMod 2)),
      fam.map (·.team) = bellPathCover.toList → Consistent fam →
      (∀ L ∈ fam, L.rel.Nonempty) → Glues fam :=
  (acyclic_iff_forall_consistent_glues bellPathCover).mp bellPathCover_acyclic

end HiddenChannelCapacity
