/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Combinatorial
import Mathlib.Data.Fintype.Prod
import Mathlib.Data.Fin.Basic

/-!
# Hidden Channel Capacity — Spekkens toy-model instance

The combinatorial HC computed on Spekkens' bipartite epistemic states over the
ontic space `Fin 4 × Fin 4` (Spekkens 2007). An epistemic state is a
`Finset (Fin 4 × Fin 4)`; it is *separable* iff rectangular (`hcComb = 0`),
*entangled* iff non-rectangular (`hcComb > 0`).

The four maximally entangled (permutation-correlated) states each have
`hcComb = 12`; separable states and full ignorance have `hcComb = 0`; the
partial state has the intermediate `hcComb = 10`. Read from the ontic support
alone (base structure, prior to any weighting), HC grades and refines that binary
entangled/separable label, predicting:

* **shared evidence cannot resolve** — restricting the right wing to a pair keeps
  `hcComb = 2 > 0` (`kId_restrictR_pair_unresolved`);
* **private singleton resolves** — restricting the left wing to one value gives
  `hcComb = 0` (`kId_restrictL_singleton_resolves`, via the general theorem);
* **private pair does not resolve** — a left-pair restriction keeps `hcComb = 2`.

This is an illustrative instance of the support layer, not core pure
mathematics. The decidable computations are discharged by `decide` (kernel
evaluation), keeping them axiom-clean.
-/

namespace HiddenChannelCapacity.Spekkens

open HiddenChannelCapacity

/-- One elementary system's ontic states (two bits). -/
abbrev Ontic := Fin 4

/-- A bipartite ontic configuration. -/
abbrev BiOntic := Ontic × Ontic

/-- Identity correlation `(i, i)` — maximally entangled. -/
def kId : Finset BiOntic := {(0, 0), (1, 1), (2, 2), (3, 3)}

/-- `X`-flip correlation — maximally entangled. -/
def kX : Finset BiOntic := {(0, 1), (1, 0), (2, 3), (3, 2)}

/-- `Z`-flip correlation — maximally entangled. -/
def kZ : Finset BiOntic := {(0, 2), (1, 3), (2, 0), (3, 1)}

/-- `Y`-flip correlation — maximally entangled. -/
def kY : Finset BiOntic := {(0, 3), (1, 2), (2, 1), (3, 0)}

/-- A separable (product) state `{0,1} × {0,1}`. -/
def kSep : Finset BiOntic := {(0, 0), (0, 1), (1, 0), (1, 1)}

/-- Full ignorance: every configuration admissible. -/
def kFull : Finset BiOntic := Finset.univ

/-- A partially entangled state (`hcComb = 10`, intermediate). -/
def kPartial : Finset BiOntic := {(0, 0), (1, 1), (2, 2), (2, 3), (3, 2), (3, 3)}

/-! ### Combinatorial HC of the named states -/

theorem kId_hcComb : hcComb kId = 12 := by decide
theorem kX_hcComb : hcComb kX = 12 := by decide
theorem kZ_hcComb : hcComb kZ = 12 := by decide
theorem kY_hcComb : hcComb kY = 12 := by decide
theorem kSep_hcComb : hcComb kSep = 0 := by decide
theorem kFull_hcComb : hcComb kFull = 0 := by decide
theorem kPartial_hcComb : hcComb kPartial = 10 := by decide

/-- The identity-correlated state does not factor (is entangled). Derived from
the measured capacity `hcComb kId = 12 ≠ 0`. -/
theorem kId_not_isRect : ¬ IsRect kId := by
  intro h
  have h0 : hcComb kId = 0 := (hcComb_eq_zero_iff_isRect kId).mpr h
  rw [kId_hcComb] at h0
  omega

/-- The separable state factors. Derived from `hcComb kSep = 0`. -/
theorem kSep_isRect : IsRect kSep :=
  (hcComb_eq_zero_iff_isRect kSep).mp kSep_hcComb

/-! ### Predictions beyond Spekkens' binary classification -/

/-- **Shared evidence cannot resolve.** Restricting the right wing of the
identity state to the pair `{0,1}` leaves a non-rectangular support with
`hcComb = 2 > 0`. -/
theorem kId_restrictR_pair_unresolved : hcComb (restrictR kId {0, 1}) = 2 := by decide

/-- **Private pair does not resolve.** A left-wing pair restriction likewise keeps
`hcComb = 2`. -/
theorem kId_restrictL_pair_unresolved : hcComb (restrictL kId {0, 1}) = 2 := by decide

/-- **Private singleton resolves**, for every left value — obtained from the
general structural theorem `isRect_restrictL_singleton`, not by computation. -/
theorem kId_restrictL_singleton_resolves (a : Ontic) :
    hcComb (restrictL kId {a}) = 0 :=
  hcComb_restrictL_singleton kId a

/-! ### Witness to the oscillation theorem

The measurement trajectory from full ignorance, through the learned identity
correlation, to a resolved (single-row) state realizes the necessary
`HC : 0 → >0 → 0` shape of `HiddenChannelCapacity.oscillation_theorem`: one
cannot pass from an unstructured state to a resolved state *through* genuine
cross-correlation without a transient rise in the factorization obstruction. -/

/-- The four-step oscillation trajectory
`κ_full → κ_id → κ_id|_(A∈{0,1}) → κ_id|_(A=0)`. -/
def oscillationTrajectory : List (Finset BiOntic) :=
  [kFull, kId, restrictL kId {0, 1}, restrictL kId {0}]

/-- The combinatorial capacity profile along the trajectory: `0 → 12 → 2 → 0`. -/
theorem oscillationTrajectory_profile :
    oscillationTrajectory.map hcComb = [0, 12, 2, 0] := by decide

/-- **Spekkens witnesses oscillation.** Both endpoints of the trajectory factor
(`hcComb = 0`) yet the interior states do not (`hcComb > 0`): the rise and the
fall are both realized, so the `0 → >0 → 0` shape is non-vacuous. -/
theorem spekkens_oscillation_witness :
    hcComb kFull = 0 ∧ 0 < hcComb kId ∧ 0 < hcComb (restrictL kId {0, 1}) ∧
      hcComb (restrictL kId {0}) = 0 :=
  ⟨kFull_hcComb, by rw [kId_hcComb]; omega,
    by rw [kId_restrictL_pair_unresolved]; omega, kId_restrictL_singleton_resolves 0⟩

/-- Mirror of `oscillation_theorem`'s conclusion at the support level: the
trajectory is not rectangular at every step (the identity-correlated state is the
non-factoring witness, exactly as the abstract theorem forces). -/
theorem spekkens_not_perpetually_rectangular :
    ¬ ∀ κ ∈ oscillationTrajectory, IsRect κ := fun h =>
  kId_not_isRect (h kId (by simp [oscillationTrajectory]))

end HiddenChannelCapacity.Spekkens
