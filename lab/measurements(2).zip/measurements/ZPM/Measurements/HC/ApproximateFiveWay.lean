/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Multipartite
import ZPM.Measurements.HC.MutualInformation
import ZPM.InformationTheory.TotalCorrelation.Def
import ZPM.InformationTheory.Pinsker.Basic
import ZPM.InformationTheory.KullbackLeibler.FiniteSupport

/-!
# The approximate five-way: quantitative hidden-channel capacity

The value-level bridge across the support↔distribution fork, run base-to-fibre. The exact
five-way (`fiveWay_uniform`, `fiveWay_full`) ties the zero sets of the combinatorial defect and
the information functional together; this file relates their values: from the discovered base
defect `hcCombPi κ` alone, the total correlation of any distribution supported on the multipartite
relation `κ` is bounded below by an explicit function of that defect (at any fixed marginal
floor) — shape forces information.

* `le_totalCorrelationReal_of_marginal_le` — the lower leg. For any probability measure `P`
  supported on `κ` whose marginals are floored by `c : ι → ℝ≥0` on the exposed values,
  `2 (hcCombPi κ · ∏ᵢ cᵢ)² ≤ TC(P)`. The floor family is the knob: one monoid-valued parameter
  grading the weighting and scaling the count, the minimal exercised form of the graded
  signature. The proof is the Pinsker set bound (`two_sq_sub_le_klDivReal`) at the forbidden
  region `hullPi κ \ κ`: the supported measure puts no mass there, while the product of the
  marginals puts at least `hcCombPi κ · ∏ᵢ cᵢ`.
* `lower_totalCorrelationReal_uniform`, `totalCorrelationReal_uniform_pos` — the canonical
  section instance (`cᵢ = 1/|κ|`): a nonzero defect forces strictly positive total correlation
  of the uniform distribution, quantitatively.
* `mutualInformationReal_uniform_image_lower` — the bipartite member witness: over `Fin 2` the
  lower leg lands on the bipartite module's own objects (`hcComb`, `uniformMeasure`,
  `mutualInformationReal`), transported along `MeasurableEquiv.piFinTwo`.
-/

open MeasureTheory ProbabilityTheory InformationTheory Finset
open scoped ENNReal NNReal

noncomputable section

namespace HiddenChannelCapacity

variable {ι : Type*} [Fintype ι] [DecidableEq ι] {X : ι → Type*}
  [∀ i, Fintype (X i)] [∀ i, DecidableEq (X i)]
  [∀ i, MeasurableSpace (X i)] [∀ i, DiscreteMeasurableSpace (X i)]

/-! ### The canonical measure on a multipartite relation -/

/-- The canonical (uniform) probability measure on a multipartite relation. -/
def uniformMeasurePi (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty) : Measure (∀ i, X i) :=
  (PMF.uniformOfFinset κ hκ).toMeasure

instance (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty) :
    IsProbabilityMeasure (uniformMeasurePi κ hκ) := by
  unfold uniformMeasurePi; infer_instance

omit [DecidableEq ι] [∀ i, DecidableEq (X i)] in
/-- The canonical measure is supported on the relation. -/
lemma uniformMeasurePi_coe (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty) :
    uniformMeasurePi κ hκ ↑κ = 1 := by
  unfold uniformMeasurePi
  rw [PMF.toMeasure_apply_eq_one_iff _ κ.measurableSet, PMF.support_uniformOfFinset]

/-- Marginal mass of the canonical measure on a singleton: the coordinate multiplicity over the
size of the relation. -/
lemma marginalPi_singleton (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty) (i : ι) (a : X i) :
    (uniformMeasurePi κ hκ).map (fun f => f i) {a}
      = (countPi κ i a : ℝ≥0∞) * (κ.card : ℝ≥0∞)⁻¹ := by
  classical
  unfold uniformMeasurePi
  rw [Measure.map_apply (measurable_pi_apply i) MeasurableSet.of_discrete,
    PMF.toMeasure_apply_fintype]
  -- Each indicator term is `1/|κ|` on the coordinate fiber of `a`, `0` elsewhere.
  have hterm : ∀ x : ∀ j, X j,
      ((fun f : ∀ j, X j => f i) ⁻¹' {a}).indicator (PMF.uniformOfFinset κ hκ) x
        = if x ∈ κ.filter (fun f => f i = a) then (κ.card : ℝ≥0∞)⁻¹ else 0 := by
    intro x
    rw [Set.indicator_apply, PMF.uniformOfFinset_apply]
    by_cases hxa : x i = a
    · simp [Set.mem_preimage, Finset.mem_filter, hxa]
    · simp [Set.mem_preimage, Finset.mem_filter, hxa]
  simp_rw [hterm]
  rw [Finset.sum_ite_mem, Finset.univ_inter, Finset.sum_const, countPi, nsmul_eq_mul]

/-! ### The lower leg: shape forces information -/

omit [DecidableEq ι] [∀ i, DecidableEq (X i)] in
/-- A probability measure on a finite discrete product is absolutely continuous with respect to
the product of its own marginals: a positive singleton forces every coordinate marginal
positive. -/
private lemma absolutelyContinuous_pi_marginal
    (P : Measure (∀ i, X i)) [IsProbabilityMeasure P] :
    P ≪ Measure.pi (fun i => P.map (fun f => f i)) := by
  refine Measure.AbsolutelyContinuous.mk fun s _ hQs => ?_
  -- Singleton masses of the product vanish on `s`.
  have hQx : ∀ x ∈ s, Measure.pi (fun i => P.map (fun f => f i)) {x} = 0 := fun x hx =>
    nonpos_iff_eq_zero.mp ((measure_mono (Set.singleton_subset_iff.mpr hx)).trans hQs.le)
  -- Hence the `P`-singletons vanish on `s`.
  have hPx : ∀ x ∈ s, P {x} = 0 := by
    intro x hx
    by_contra hP0
    have hmarg : ∀ i, 0 < P.map (fun f => f i) {x i} := by
      intro i
      rw [Measure.map_apply (measurable_pi_apply i) MeasurableSet.of_discrete]
      refine lt_of_lt_of_le (pos_iff_ne_zero.mpr hP0) (measure_mono fun y hy => ?_)
      rw [Set.mem_singleton_iff] at hy
      simp [Set.mem_preimage, hy]
    have hpos : 0 < Measure.pi (fun i => P.map (fun f => f i)) {x} := by
      rw [← Set.univ_pi_singleton x, Measure.pi_pi]
      exact CanonicallyOrderedAdd.prod_pos.mpr fun i _ => hmarg i
    exact absurd (hQx x hx) hpos.ne'
  -- Sum the vanishing singletons over the (finite) set.
  have hfin : s.Finite := Set.toFinite s
  calc P s = P ↑hfin.toFinset := by rw [Set.Finite.coe_toFinset]
    _ = ∑ x ∈ hfin.toFinset, P {x} := sum_measure_singleton.symm
    _ = 0 := Finset.sum_eq_zero fun x hx => hPx x (hfin.mem_toFinset.mp hx)

/-- **The lower leg of the approximate five-way** (shape forces information). For any probability
measure `P` supported on the multipartite relation `κ` whose coordinate marginals are floored by
`c : ι → ℝ≥0` on the exposed values,

`2 · (hcCombPi κ · ∏ᵢ cᵢ)² ≤ totalCorrelationReal P`.

The floor family `c` is the knob: one monoid-valued parameter whose fold `∏ᵢ cᵢ` grades the
weighting and scales the count in the same expression. The proof applies the Pinsker set bound to
the forbidden region `hullPi κ \ κ`, where `P` puts no mass and the product of the marginals puts
at least `hcCombPi κ · ∏ᵢ cᵢ`. -/
theorem le_totalCorrelationReal_of_marginal_le
    (κ : Finset (∀ i, X i)) (P : Measure (∀ i, X i)) [IsProbabilityMeasure P]
    (hsupp : P ↑κ = 1) (c : ι → ℝ≥0)
    (hfloor : ∀ i, ∀ a ∈ projPi κ i, (c i : ℝ≥0∞) ≤ P.map (fun f => f i) {a}) :
    2 * ((hcCombPi κ : ℝ) * ∏ i, (c i : ℝ)) ^ 2 ≤ totalCorrelationReal P := by
  classical
  haveI : ∀ i, IsProbabilityMeasure (P.map (fun f => f i)) :=
    fun i => Measure.isProbabilityMeasure_map (measurable_pi_apply i).aemeasurable
  set Q : Measure (∀ i, X i) := Measure.pi (fun i => P.map (fun f => f i)) with hQdef
  haveI : IsProbabilityMeasure Q := by rw [hQdef]; infer_instance
  have hac : P ≪ Q := absolutelyContinuous_pi_marginal P
  have hint : Integrable (llr P Q) P := .of_finite
  set F : Finset (∀ i, X i) := hullPi κ \ κ with hFdef
  -- The supported measure puts no mass on the forbidden region.
  have hPF : P ↑F = 0 := by
    have hzero : P (↑κ : Set (∀ i, X i))ᶜ = 0 := by
      rw [prob_compl_eq_one_sub κ.measurableSet, hsupp, tsub_self]
    refine measure_mono_null ?_ hzero
    intro x hx hk
    exact (Finset.mem_sdiff.mp (Finset.mem_coe.mp hx)).2 (Finset.mem_coe.mp hk)
  -- The product of the marginals puts at least `hcCombPi κ · ∏ c` there.
  have hQF : (hcCombPi κ : ℝ≥0∞) * ∏ i, (c i : ℝ≥0∞) ≤ Q ↑F := by
    have hsingle : ∀ f ∈ F, (∏ i, (c i : ℝ≥0∞)) ≤ Q {f} := by
      intro f hf
      have hproj : ∀ i, f i ∈ projPi κ i :=
        Fintype.mem_piFinset.mp (Finset.mem_sdiff.mp hf).1
      rw [hQdef, ← Set.univ_pi_singleton f, Measure.pi_pi]
      exact Finset.prod_le_prod' fun i _ => hfloor i (f i) (hproj i)
    calc (hcCombPi κ : ℝ≥0∞) * ∏ i, (c i : ℝ≥0∞)
        = ∑ _f ∈ F, ∏ i, (c i : ℝ≥0∞) := by
          rw [Finset.sum_const, ← card_hullPi_sdiff κ, ← hFdef, nsmul_eq_mul]
      _ ≤ ∑ f ∈ F, Q {f} := Finset.sum_le_sum hsingle
      _ = Q ↑F := sum_measure_singleton
  -- Pinsker's set bound at the forbidden region.
  have key := two_sq_sub_le_klDivReal P Q hac hint ↑F F.measurableSet
  have hPFr : P.real ↑F = 0 := by simp [Measure.real, hPF]
  have hQFr : (hcCombPi κ : ℝ) * ∏ i, (c i : ℝ) ≤ Q.real ↑F := by
    have h := ENNReal.toReal_mono (measure_ne_top Q ↑F) hQF
    rw [ENNReal.toReal_mul, ENNReal.toReal_natCast, ENNReal.toReal_prod] at h
    simp only [ENNReal.coe_toReal] at h
    simpa [Measure.real] using h
  have hnn : 0 ≤ (hcCombPi κ : ℝ) * ∏ i, (c i : ℝ) := by positivity
  calc 2 * ((hcCombPi κ : ℝ) * ∏ i, (c i : ℝ)) ^ 2
      ≤ 2 * (Q.real ↑F) ^ 2 := by gcongr
    _ = 2 * (P.real ↑F - Q.real ↑F) ^ 2 := by rw [hPFr, zero_sub, neg_sq]
    _ ≤ klDivReal P Q := key
    _ = totalCorrelationReal P := by unfold totalCorrelationReal; rw [hQdef]

/-- **The canonical section instance**: the uniform distribution on `κ` has total correlation at
least `2 (hcCombPi κ / |κ|ⁿ)²`, with `n` the number of parts. -/
theorem lower_totalCorrelationReal_uniform (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty) :
    2 * ((hcCombPi κ : ℝ) / (κ.card : ℝ) ^ Fintype.card ι) ^ 2
      ≤ totalCorrelationReal (uniformMeasurePi κ hκ) := by
  have hcard0 : (κ.card : ℝ≥0∞) ≠ 0 := by exact_mod_cast Finset.card_ne_zero.mpr hκ
  -- the uniform marginal floor: each exposed value has multiplicity at least one
  have hfloor : ∀ i, ∀ a ∈ projPi κ i,
      (((κ.card : ℝ≥0)⁻¹ : ℝ≥0) : ℝ≥0∞) ≤ (uniformMeasurePi κ hκ).map (fun f => f i) {a} := by
    intro i a ha
    rw [marginalPi_singleton κ hκ i a,
      show (((κ.card : ℝ≥0)⁻¹ : ℝ≥0) : ℝ≥0∞) = (κ.card : ℝ≥0∞)⁻¹ by
        rw [ENNReal.coe_inv (by exact_mod_cast Finset.card_ne_zero.mpr hκ)]; norm_cast]
    exact le_mul_of_one_le_left (by positivity)
      (by exact_mod_cast Nat.one_le_iff_ne_zero.mpr (countPi_pos κ i ha).ne')
  have h := le_totalCorrelationReal_of_marginal_le κ (uniformMeasurePi κ hκ)
    (uniformMeasurePi_coe κ hκ) (fun _ => (κ.card : ℝ≥0)⁻¹) hfloor
  have hprod : (∏ _i : ι, (((κ.card : ℝ≥0)⁻¹ : ℝ≥0) : ℝ))
      = ((κ.card : ℝ) ^ Fintype.card ι)⁻¹ := by
    rw [Finset.prod_const, Finset.card_univ]
    push_cast
    rw [inv_pow]
  rwa [hprod, ← div_eq_mul_inv] at h

/-- **A nonzero defect forces strictly positive total correlation** of the canonical measure:
the quantitative form of the five-way's information leg. -/
theorem totalCorrelationReal_uniform_pos (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty)
    (h : hcCombPi κ ≠ 0) :
    0 < totalCorrelationReal (uniformMeasurePi κ hκ) := by
  refine lt_of_lt_of_le ?_ (lower_totalCorrelationReal_uniform κ hκ)
  have h1 : (0 : ℝ) < (hcCombPi κ : ℝ) := by exact_mod_cast Nat.pos_of_ne_zero h
  have h2 : (0 : ℝ) < (κ.card : ℝ) ^ Fintype.card ι :=
    pow_pos (by exact_mod_cast Finset.card_pos.mpr hκ) _
  positivity

/-! ### The upper leg: the counting bound -/

section Upper

omit [Fintype ι] [DecidableEq ι] [∀ i, Fintype (X i)] [∀ i, MeasurableSpace (X i)]
  [∀ i, DiscreteMeasurableSpace (X i)] in
/-- Unexposed values have zero multiplicity. -/
lemma countPi_eq_zero (κ : Finset (∀ i, X i)) (i : ι) {a : X i} (ha : a ∉ projPi κ i) :
    countPi κ i a = 0 := by
  rw [countPi, Finset.card_eq_zero, Finset.filter_eq_empty_iff]
  intro f hf hfa
  exact ha (Finset.mem_image.mpr ⟨f, hf, hfa⟩)

omit [DecidableEq ι] in
/-- Real singleton mass of the canonical measure. -/
lemma uniformMeasurePi_real_singleton (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty)
    (x : ∀ i, X i) :
    (uniformMeasurePi κ hκ).real {x} = if x ∈ κ then ((κ.card : ℝ))⁻¹ else 0 := by
  unfold uniformMeasurePi
  rw [Measure.real, PMF.toMeasure_apply_singleton _ _ (measurableSet_singleton x),
    PMF.uniformOfFinset_apply]
  split
  · simp [ENNReal.toReal_inv]
  · simp

/-- Real marginal mass of the canonical measure: `countPi / |κ|`. -/
lemma marginalPi_real_singleton (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty) (i : ι) (a : X i) :
    ((uniformMeasurePi κ hκ).map (fun f => f i)).real {a} = (countPi κ i a : ℝ) / κ.card := by
  rw [Measure.real, marginalPi_singleton κ hκ i a, ENNReal.toReal_mul, ENNReal.toReal_natCast,
    ENNReal.toReal_inv, ENNReal.toReal_natCast, div_eq_mul_inv]

omit [Fintype ι] [DecidableEq ι] [∀ i, DecidableEq (X i)] in
/-- The real singleton masses of a marginal sum to one. -/
private lemma sum_marginalPi_real (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty) (i : ι) :
    ∑ a : X i, ((uniformMeasurePi κ hκ).map (fun f => f i)).real {a} = 1 := by
  haveI : IsProbabilityMeasure ((uniformMeasurePi κ hκ).map (fun f => f i)) :=
    Measure.isProbabilityMeasure_map (measurable_pi_apply i).aemeasurable
  have h : ∑ a : X i, ((uniformMeasurePi κ hκ).map (fun f => f i)) {a} = 1 := by
    rw [sum_measure_singleton, Finset.coe_univ, measure_univ]
  calc ∑ a : X i, ((uniformMeasurePi κ hκ).map (fun f => f i)).real {a}
      = (∑ a : X i, ((uniformMeasurePi κ hκ).map (fun f => f i)) {a}).toReal :=
        (ENNReal.toReal_sum fun a _ => measure_ne_top _ _).symm
    _ = 1 := by rw [h, ENNReal.toReal_one]

/-- **The per-part maximum-entropy bound, in Gibbs form**: the negated log of the projection size
bounds the marginal's `∑ m log m` from below. This is `klDivReal_nonneg` (Gibbs' inequality)
applied to the marginal against the uniform distribution on the projection. -/
private lemma neg_log_card_le_sum_mul_log (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty) (i : ι) :
    -Real.log ((projPi κ i).card : ℝ)
      ≤ ∑ a : X i, ((uniformMeasurePi κ hκ).map (fun f => f i)).real {a}
          * Real.log (((uniformMeasurePi κ hκ).map (fun f => f i)).real {a}) := by
  haveI : IsProbabilityMeasure ((uniformMeasurePi κ hκ).map (fun f => f i)) :=
    Measure.isProbabilityMeasure_map (measurable_pi_apply i).aemeasurable
  set m := (uniformMeasurePi κ hκ).map (fun f => f i) with hm
  have hproj : (projPi κ i).Nonempty := hκ.image _
  have hprojcard : (0 : ℝ) < ((projPi κ i).card : ℝ) := by
    exact_mod_cast Finset.card_pos.mpr hproj
  set u : Measure (X i) := (PMF.uniformOfFinset (projPi κ i) hproj).toMeasure with hu
  haveI : IsProbabilityMeasure u := by rw [hu]; infer_instance
  have hu_mem : ∀ a ∈ projPi κ i, u {a} = ((projPi κ i).card : ℝ≥0∞)⁻¹ := fun a ha => by
    rw [hu, PMF.toMeasure_apply_singleton _ _ (measurableSet_singleton a),
      PMF.uniformOfFinset_apply, if_pos ha]
  have hu_notmem : ∀ a ∉ projPi κ i, u {a} = 0 := fun a ha => by
    rw [hu, PMF.toMeasure_apply_singleton _ _ (measurableSet_singleton a),
      PMF.uniformOfFinset_apply, if_neg ha]
  -- the marginal is supported on the projection, hence AC with respect to its uniform measure
  have hac : m ≪ u := by
    refine absolutelyContinuous_of_forall_singleton fun a ha => ?_
    by_cases hmem : a ∈ projPi κ i
    · rw [hu_mem a hmem] at ha
      exact absurd ha (ENNReal.inv_ne_zero.mpr (by simp))
    · rw [hm, marginalPi_singleton κ hκ i a, countPi_eq_zero κ i hmem]
      simp
  -- Gibbs: the divergence against the uniform reference is nonnegative
  have hkl := klDivReal_nonneg m u
  rw [klDivReal_fintype m u hac] at hkl
  -- expand the log-ratio; off-projection terms vanish
  have hterm : ∀ a : X i, m.real {a} * Real.log (m.real {a} / u.real {a})
      = m.real {a} * Real.log (m.real {a})
        + m.real {a} * Real.log ((projPi κ i).card : ℝ) := by
    intro a
    by_cases hmem : a ∈ projPi κ i
    · have hu_real : u.real {a} = (((projPi κ i).card : ℝ))⁻¹ := by
        rw [Measure.real, hu_mem a hmem]
        simp [ENNReal.toReal_inv]
      by_cases hm0 : m.real {a} = 0
      · rw [hm0]; ring
      · rw [hu_real, div_eq_mul_inv, inv_inv, Real.log_mul hm0 hprojcard.ne']
        ring
    · have hzero : m.real {a} = 0 := by
        rw [hm, marginalPi_real_singleton κ hκ i a, countPi_eq_zero κ i hmem]
        simp
      rw [hzero]; ring
  have hsplit : ∑ a : X i, m.real {a} * Real.log (m.real {a} / u.real {a})
      = (∑ a : X i, m.real {a} * Real.log (m.real {a}))
        + Real.log ((projPi κ i).card : ℝ) := by
    calc ∑ a : X i, m.real {a} * Real.log (m.real {a} / u.real {a})
        = ∑ a : X i, (m.real {a} * Real.log (m.real {a})
            + m.real {a} * Real.log ((projPi κ i).card : ℝ)) :=
          Finset.sum_congr rfl fun a _ => hterm a
      _ = (∑ a : X i, m.real {a} * Real.log (m.real {a}))
          + (∑ a : X i, m.real {a}) * Real.log ((projPi κ i).card : ℝ) := by
          rw [Finset.sum_add_distrib, Finset.sum_mul]
      _ = _ := by rw [hm, sum_marginalPi_real κ hκ i, one_mul]
  rw [hsplit] at hkl
  linarith

/-- **The upper (counting) leg of the approximate five-way**: the total correlation of the
canonical measure is at most the log-ratio of the hull to the relation,
`TC(unif κ) ≤ log (|hullPi κ| / |κ|)`. The fibre-side direction: marginal entropies bounded by
the projection sizes (Gibbs), no structural content. -/
theorem totalCorrelationReal_uniform_le (κ : Finset (∀ i, X i)) (hκ : κ.Nonempty) :
    totalCorrelationReal (uniformMeasurePi κ hκ)
      ≤ Real.log (((hullPi κ).card : ℝ) / κ.card) := by
  classical
  haveI : ∀ i, IsProbabilityMeasure ((uniformMeasurePi κ hκ).map (fun f => f i)) :=
    fun i => Measure.isProbabilityMeasure_map (measurable_pi_apply i).aemeasurable
  set P := uniformMeasurePi κ hκ with hP
  set Qu : Measure (∀ i, X i) := Measure.pi (fun i => P.map (fun f => f i)) with hQu
  haveI : IsProbabilityMeasure Qu := by rw [hQu]; infer_instance
  have hcard : (0 : ℝ) < (κ.card : ℝ) := by exact_mod_cast Finset.card_pos.mpr hκ
  -- positivity of marginal masses at admissible configurations
  have hmpos : ∀ (i : ι), ∀ x ∈ κ, (0:ℝ) < (P.map (fun f => f i)).real {x i} := by
    intro i x hx
    rw [hP, marginalPi_real_singleton κ hκ i (x i)]
    have h0 : 0 < countPi κ i (x i) := countPi_pos κ i (Finset.mem_image_of_mem _ hx)
    positivity
  -- the pointwise expansion on the relation
  have hpt : ∀ x ∈ κ, P.real {x} * Real.log (P.real {x} / Qu.real {x})
      = (κ.card : ℝ)⁻¹ * -Real.log (κ.card : ℝ)
        - ∑ i, (κ.card : ℝ)⁻¹ * Real.log ((P.map (fun f => f i)).real {x i}) := by
    intro x hx
    have hPreal : P.real {x} = (κ.card : ℝ)⁻¹ := by
      rw [hP, uniformMeasurePi_real_singleton κ hκ x, if_pos hx]
    have hQreal : Qu.real {x} = ∏ i, (P.map (fun f => f i)).real {x i} := by
      rw [hQu, Measure.real, ← Set.univ_pi_singleton x, Measure.pi_pi, ENNReal.toReal_prod]
      rfl
    rw [hPreal, hQreal,
      Real.log_div (inv_ne_zero hcard.ne')
        (Finset.prod_ne_zero_iff.mpr fun i _ => (hmpos i x hx).ne'),
      Real.log_inv, Real.log_prod (fun i _ => (hmpos i x hx).ne'),
      mul_sub, Finset.mul_sum]
  -- the per-part, per-fiber regrouping into marginal entropy sums
  have hregroup : ∀ i : ι,
      ∑ x ∈ κ, (κ.card : ℝ)⁻¹ * Real.log ((P.map (fun f => f i)).real {x i})
        = ∑ a : X i, (P.map (fun f => f i)).real {a}
            * Real.log ((P.map (fun f => f i)).real {a}) := by
    intro i
    have hcomp := Finset.sum_comp (s := κ)
      (fun a : X i => Real.log ((P.map (fun f => f i)).real {a})) (fun x => x i)
    have hrestrict : (∑ a : X i, (P.map (fun f => f i)).real {a}
          * Real.log ((P.map (fun f => f i)).real {a}))
        = ∑ a ∈ projPi κ i, (P.map (fun f => f i)).real {a}
            * Real.log ((P.map (fun f => f i)).real {a}) :=
      (Finset.sum_subset (Finset.subset_univ _) (fun a _ haproj => by
        rw [hP, marginalPi_real_singleton κ hκ i a, countPi_eq_zero κ i haproj]
        simp)).symm
    rw [← Finset.mul_sum, hcomp, Finset.mul_sum, hrestrict]
    refine Finset.sum_congr rfl fun a _ => ?_
    rw [nsmul_eq_mul, hP, marginalPi_real_singleton κ hκ i a]
    simp only [countPi]
    ring
  -- the mass term collapses
  have hmass : (κ.card : ℝ) * ((κ.card : ℝ)⁻¹ * -Real.log (κ.card : ℝ))
      = -Real.log (κ.card : ℝ) := by
    field_simp
  -- the per-part entropy bound and the final log identity
  have hprojpos : ∀ i : ι, (0 : ℝ) < ((projPi κ i).card : ℝ) := fun i => by
    exact_mod_cast Finset.card_pos.mpr (hκ.image _)
  have hhullpos : (0 : ℝ) < ((hullPi κ).card : ℝ) := by
    exact_mod_cast Finset.card_pos.mpr (hκ.mono (subset_hullPi κ))
  have hlog : -Real.log (κ.card : ℝ) - ∑ i, (-Real.log ((projPi κ i).card : ℝ))
      = Real.log (((hullPi κ).card : ℝ) / κ.card) := by
    have hprod : (∏ i, ((projPi κ i).card : ℝ)) = ((hullPi κ).card : ℝ) := by
      rw [card_hullPi]
      push_cast
      rfl
    rw [Finset.sum_neg_distrib, sub_neg_eq_add,
      ← Real.log_prod (fun i _ => (hprojpos i).ne'), hprod,
      Real.log_div hhullpos.ne' hcard.ne']
    ring
  have hbound : ∑ i, (-Real.log ((projPi κ i).card : ℝ))
      ≤ ∑ i, ∑ a : X i, (P.map (fun f => f i)).real {a}
          * Real.log ((P.map (fun f => f i)).real {a}) := by
    refine Finset.sum_le_sum fun i _ => ?_
    rw [hP]
    exact neg_log_card_le_sum_mul_log κ hκ i
  -- assemble
  calc totalCorrelationReal P
      = klDivReal P Qu := by unfold totalCorrelationReal; rw [hQu]
    _ = ∑ x : ∀ i, X i, P.real {x} * Real.log (P.real {x} / Qu.real {x}) :=
        klDivReal_fintype P Qu (absolutelyContinuous_pi_marginal P)
    _ = ∑ x ∈ κ, P.real {x} * Real.log (P.real {x} / Qu.real {x}) :=
        (Finset.sum_subset κ.subset_univ (fun x _ hxκ => by
          rw [hP, uniformMeasurePi_real_singleton κ hκ x, if_neg hxκ, zero_mul])).symm
    _ = ∑ x ∈ κ, ((κ.card : ℝ)⁻¹ * -Real.log (κ.card : ℝ)
          - ∑ i, (κ.card : ℝ)⁻¹ * Real.log ((P.map (fun f => f i)).real {x i})) :=
        Finset.sum_congr rfl hpt
    _ = (κ.card : ℝ) * ((κ.card : ℝ)⁻¹ * -Real.log (κ.card : ℝ))
        - ∑ x ∈ κ, ∑ i, (κ.card : ℝ)⁻¹ * Real.log ((P.map (fun f => f i)).real {x i}) := by
        rw [Finset.sum_sub_distrib, Finset.sum_const, nsmul_eq_mul]
    _ = -Real.log (κ.card : ℝ)
        - ∑ i, ∑ x ∈ κ, (κ.card : ℝ)⁻¹ * Real.log ((P.map (fun f => f i)).real {x i}) := by
        rw [hmass, Finset.sum_comm]
    _ = -Real.log (κ.card : ℝ)
        - ∑ i, ∑ a : X i, (P.map (fun f => f i)).real {a}
            * Real.log ((P.map (fun f => f i)).real {a}) := by
        simp only [hregroup]
    _ ≤ -Real.log (κ.card : ℝ) - ∑ i, (-Real.log ((projPi κ i).card : ℝ)) := by
        linarith
    _ = Real.log (((hullPi κ).card : ℝ) / κ.card) := hlog

end Upper

/-! ### The bipartite member witness -/

section Witness

variable {Y : Fin 2 → Type*} [∀ i, Fintype (Y i)] [∀ i, DecidableEq (Y i)]
  [∀ i, MeasurableSpace (Y i)] [∀ i, DiscreteMeasurableSpace (Y i)]

omit [∀ i, Fintype (Y i)] [∀ i, DiscreteMeasurableSpace (Y i)] in
/-- Over `Fin 2` the multipartite defect is the bipartite `hcComb` of the paired relation. -/
lemma hcCombPi_fin_two (κ : Finset (∀ i, Y i)) :
    hcCombPi κ = hcComb (κ.image (MeasurableEquiv.piFinTwo Y)) := by
  classical
  have hL : projL (κ.image (MeasurableEquiv.piFinTwo Y)) = projPi κ 0 := by
    rw [projL, Finset.image_image, projPi]
    rfl
  have hR : projR (κ.image (MeasurableEquiv.piFinTwo Y)) = projPi κ 1 := by
    rw [projR, Finset.image_image, projPi]
    rfl
  rw [hcCombPi, hcComb, hL, hR, Finset.card_product,
    Finset.card_image_of_injective _ (MeasurableEquiv.piFinTwo Y).injective,
    card_hullPi, Fin.prod_univ_two]

/-- The canonical measure transports along the pairing to the bipartite canonical measure of the
paired relation. -/
lemma map_uniformMeasurePi_piFinTwo (κ : Finset (∀ i, Y i)) (hκ : κ.Nonempty) :
    (uniformMeasurePi κ hκ).map (MeasurableEquiv.piFinTwo Y)
      = uniformMeasure (κ.image (MeasurableEquiv.piFinTwo Y))
          (hκ.image (MeasurableEquiv.piFinTwo Y)) := by
  classical
  have hmem : ∀ y : Y 0 × Y 1, ((MeasurableEquiv.piFinTwo Y).symm y ∈ κ
      ↔ y ∈ κ.image (MeasurableEquiv.piFinTwo Y)) := by
    intro y
    constructor
    · intro hk
      exact Finset.mem_image.mpr ⟨_, hk, (MeasurableEquiv.piFinTwo Y).apply_symm_apply y⟩
    · intro hk
      obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hk
      rwa [(MeasurableEquiv.piFinTwo Y).symm_apply_apply x]
  refine Measure.ext_of_singleton fun y => ?_
  have hpre : ⇑(MeasurableEquiv.piFinTwo Y) ⁻¹' {y}
      = {(MeasurableEquiv.piFinTwo Y).symm y} := by
    ext f
    simp only [Set.mem_preimage, Set.mem_singleton_iff]
    constructor
    · intro h
      rw [← h, (MeasurableEquiv.piFinTwo Y).symm_apply_apply]
    · intro h
      rw [h, (MeasurableEquiv.piFinTwo Y).apply_symm_apply]
  rw [Measure.map_apply (MeasurableEquiv.piFinTwo Y).measurable (measurableSet_singleton y),
    hpre]
  unfold uniformMeasurePi uniformMeasure
  rw [PMF.toMeasure_uniformOfFinset_apply hκ _ (measurableSet_singleton _),
    PMF.toMeasure_uniformOfFinset_apply (hκ.image _) _ (measurableSet_singleton _),
    Finset.card_image_of_injective _ (MeasurableEquiv.piFinTwo Y).injective]
  congr 1
  norm_cast
  simp only [Set.mem_singleton_iff]
  rw [Finset.filter_eq', Finset.filter_eq']
  by_cases hk : (MeasurableEquiv.piFinTwo Y).symm y ∈ κ
  · have hk' := (hmem y).mp hk
    simp only [MeasurableEquiv.piFinTwo_symm_apply] at hk
    simp only [Finset.mem_image, MeasurableEquiv.piFinTwo_apply] at hk'
    simp [hk, hk']
  · have hk' : y ∉ κ.image (MeasurableEquiv.piFinTwo Y) := fun h => hk ((hmem y).mpr h)
    simp only [MeasurableEquiv.piFinTwo_symm_apply] at hk
    simp only [Finset.mem_image, MeasurableEquiv.piFinTwo_apply] at hk'
    simp [hk, hk']

/-- **The bipartite member witness.** Over a two-element index the multipartite lower leg lands
on the bipartite module's own objects: the mutual information of the uniform distribution on the
paired relation is bounded below by its combinatorial defect. -/
theorem mutualInformationReal_uniform_image_lower (κ : Finset (∀ i, Y i)) (hκ : κ.Nonempty) :
    2 * ((hcComb (κ.image (MeasurableEquiv.piFinTwo Y)) : ℝ) / (κ.card : ℝ) ^ 2) ^ 2
      ≤ mutualInformationReal
          (uniformMeasure (κ.image (MeasurableEquiv.piFinTwo Y))
            (hκ.image (MeasurableEquiv.piFinTwo Y))) := by
  have h := lower_totalCorrelationReal_uniform κ hκ
  rw [totalCorrelationReal_fin_two, map_uniformMeasurePi_piFinTwo κ hκ,
    hcCombPi_fin_two, Fintype.card_fin] at h
  exact h

end Witness

end HiddenChannelCapacity

end
