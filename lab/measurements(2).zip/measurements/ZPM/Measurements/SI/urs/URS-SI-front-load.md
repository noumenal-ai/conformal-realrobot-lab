# URS — SI (structural ignorance) primitive for sample compression at the base

Private discovery trace. URT/HC language permitted HERE ONLY; shipping artifacts carry
none of it. Session 2026-07-29. Protocol: front-load (this file) → UK floor → Lean prop
file → grind residuals → async ultraconservative reviewer at every claim boundary.

PROBLEM (one line): abduce the representation of ignorance-about-structure that defines
the base of the sample compression problem, such that the no-side-information O(d)
scheme (LW at full strength) becomes a short theorem of the representation's calculus.

Standing constraints (A of the problem URS):
- Target statement: kernel size O(d), side-information index trivial (|I| = 1).
- Grammar for all shipping artifacts: Yaël Set-grammar (`Shatters`, `HasVCDimLE`,
  `vcGrowth`, `ncard`, finite windows). Zero URT vocabulary in anything that ships.
- Base discipline: every defined object must be invariant under (i) class closure
  (classes with equal trace functors are indistinguishable to schemes), (ii) label
  twists (coordinate flips), (iii) ground-set symmetry. Distribution-level objects are
  forbidden inside definitions; they may appear only in glue theorems (T4).
- No literature. Corpus + Mathlib only. CCMW corner-peeling lookup: permitted by Dhruv,
  DECLINED this phase (engaging it would fold the native primitive into corner-peeling
  vocabulary before its own form is fixed; reversible later). Ample-completion lookup:
  PERMANENTLY FORBIDDEN (Dhruv: open problem, negative results in certain scopes; that
  is all we carry, and the negative-scope fact is itself load-bearing — see KU8).
- A4/A5 strict. Every derived law below is conjecture-grade (KU) until kernel-checked
  or reviewer-confirmed; nothing self-generated is banked as KK (noological 2.3 gate).
  Verifiers present: Dhruv in loop, async opus reviewer, Lean kernel (next phase),
  decide-checked examples.

════════════════════════════════════════════════════════════════════
## 1. OBJECT AXIS (γ) — the problem URS
════════════════════════════════════════════════════════════════════

### 1.1 Derivation record (five passes; three kills; two forced enrichments)

**Pass 1 — the base object and the elimination of the compression map.**
A scheme only sees traces: if 𝒜 and ℬ have the same trace family on every finite
window, every scheme for one is a scheme for the other. So the base object is the
window-indexed trace assignment A ↦ (A ∩ ·) '' 𝒜 with its restriction maps (all
surjective), NOT the class. Classes are fiber-side presentations of this object.

Reformulation that eliminates κ: fix the reconstruction convention ρ FIRST (a total
function (Z, W) ↦ hypothesis ⊆ α). Then a size-k scheme exists iff every realizable
sample (A, T) CONTAINS a k-point generating kernel: ∃ Z ⊆ A, |Z| ≤ k,
ρ(Z, Z ∩ T) ∩ A = T. Both directions checked: a (κ, ρ) scheme's ρ is such a
convention (κ's output is the witness Z); a convention plus choice of witness is a
scheme. Fiber-coherence bookkeeping disappears because ρ is a function.

Side information recovered as a derived quantity, not a primitive: for a compression
map κ, a correct reconstruction exists iff every κ-fiber is pairwise compatible
(T₁ ∩ A₂ = T₂ ∩ A₁ for same-output samples); with an index set I, iff each fiber's
incompatibility graph is |I|-colorable. Side information = the chromatic number of
what the kernel choice fails to make compatible. It is a purchase of determination,
bit by bit. (Union of pairwise-compatible partial labelings is a partial labeling;
extend totally; so pairwise compatibility per color class suffices.)

**Pass 2 — KILL K1 (polarity law).** Candidate law: "at every stage, every free point
has a label whose conditioning strictly drops residual VC-rank." Killed by the free
cube pair: ground C ⊔ {x} ⊔ C', |C| = |C'| = d; members: (free on C, x = 0, fixed
pattern on C') ∪ (fixed pattern on C, x = 1, free on C'). VC = d (a shattered set
cannot cross x since each side fixes the far block; count 2^d + 1 < 2^{d+1}).
Conditioning on x = 0 keeps rank d (free C); on x = 1 keeps rank d (free C').
Both labels rank-preserving. Rank-as-potential is dead; the split structure, not the
max-rank, carries the information. Enrichment forced: track the full skeleton through
splits (→ Pass 4).

**Pass 3 — KILL K2 (determination coherence) → enrichment E1 (cascade/addressing).**
Candidate mechanism for the flat case: "kernel = minimal determining set" (a Z whose
labels pin all of A's labels within the class). Killed by the singleton class
𝒜 = {∅} ∪ {{y} : y ∈ α}: the all-zero sample on a window A is determined by NO
bounded Z (each y ∈ A ∖ Z leaves {y} alive), yet a size-1 scheme exists: convention
ρ(∅, ∅) = ∅ (default), ρ({y}, {y}) = {y}. Coherence does not require determination;
it requires compatibility of same-kernel samples, and a DEFAULT absorbs the
undetermined bulk. Enrichment: the kernel is a deviation record relative to a cascade
of defaults, not a determining set. Worked on the chain class {∅, {x}, {x,y}}
(window-flat, VC 1): addresses ∅ ↦ ∅, {x} ↦ {x}, {x,y} ↦ {y} — each member named by
where it deviates from the default cascade (default ∅; after x = 1 the default
becomes {x}); kernels = address ∩ window with labels; all fibers compatible; k = 1.
The flat bijection (class ↔ skeleton, forced by defect 0) is what makes ≤ d
addresses even countable — skeleton members have size ≤ d.

**Pass 4 — the split calculus (L2 derivation, three steps; the load-bearing one).**
Window A finite, x ∈ A. Children 𝒜₀ = {S ∈ 𝒜 : x ∉ S}, 𝒜₁ = {S ∈ 𝒜 : x ∈ S}.
(a) Trace additivity, EXACT: |Tr_A(𝒜)| = |Tr_{A∖x}(𝒜₀)| + |Tr_{A∖x}(𝒜₁)|.
    The x-label partitions Tr_A; on each part, T ↦ T ∖ {x} is a bijection onto the
    child's trace family (x ∈ A makes the x-label of A ∩ S read off x ∈ S).
(b) Skeleton superadditivity: |sh_A(𝒜)| ≥ |sh_{A∖x}(𝒜₀)| + |sh_{A∖x}(𝒜₁)|.
    Two disjoint injections into sh_A(𝒜): (i) sh₀ ∪ sh₁ maps in as-is (children are
    subclasses; shattering is monotone; B ⊆ A ∖ x); (ii) sh₀ ∩ sh₁ maps in as
    B ↦ B ∪ {x}: a pattern C ⊆ B ∪ {x} with x ∉ C is realized by an 𝒜₀-witness of
    C ∩ B; with x ∈ C by an 𝒜₁-witness of C ∖ {x}. Images disjoint by x-membership.
    |sh₀ ∪ sh₁| + |sh₀ ∩ sh₁| = |sh₀| + |sh₁|.
(c) Subtract (all subtractions genuine by L1/Pajor): defect_A(𝒜) ≥
    defect_{A∖x}(𝒜₀) + defect_{A∖x}(𝒜₁). Define twist_x := the slack. Twist ≥ 0.
Reading: twist_x counts freedom visible only to the union — shattered sets whose
patterns are realized partly by x = 0 members and partly by x = 1 members, invisible
to each conditioned world alone. Case analysis silently consumes exactly this much
defect. Corollary (L3, immediate): defect 0 propagates to all residual stages inside
the window — flatness is hereditary, one condition, no extra hypothesis.

**Pass 5 — KILL K3 (defect mass as price) → enrichment E2 (alignment).**
Even-prefix class over x₁ < … < x_n: members = prefixes of even length. VC = 1
(pattern out-then-in impossible; in-then-out realized). Window-defect ≈ n/2:
unbounded defect at fixed VC. Yet k = 2 suffices: kernel = {last labeled-in point,
first labeled-out point}; convention = a fixed prefix consistent with that boundary;
correctness checked directly (points ≤ boundary are in, points ≥ are out, gap points
are outside the window). Twist here is spread along a deep serial chain, ONE unit per
stage, and a single global orientation (the linear order) lets two boundary points
pay for the whole chain. So: total twist mass is NOT the compression price; global
flattening number is NOT bounded by f(d) (this class needs ~n/2 conditionings to kill
all defect). What matters is whether the twist field can be ORIENTED coherently so
that per-sample crossings are few. Enrichment: the primitive is the twist field
TOGETHER WITH an alignment structure; the price of a class is the residual after its
best alignment. Fiber-side proofs impose an exogenous alignment (a weighting induces
a priority order oblivious to the field) — which is exactly why they overpay.

**KILL K4 (methodological).** Mis-recalled "circular arcs VC = 2" during a twist hunt;
recount gave VC = 3 (wrap-around realizes in-out-in; in-out-in-out impossible).
Caught before use. Rule admitted to A: every example enters the corpus as a
decide-checked Lean term, never as recalled fact.

### 1.2 The proposition set (complete; method-prose verbalization + typing)

Grammar: α a type; 𝒜 : Set (Set α); windows A : Set α with A.Finite; her `Shatters`,
`HasVCDimLE`. All ncard. Names below are working names, final spelling at Lean time.

**D-layer (definitions).**

- D1 `IsSample 𝒜 A T := A.Finite ∧ T ∈ (A ∩ ·) '' 𝒜`. [T-Prop, crisp]
- D2 `residual 𝒜 Z W := {S ∈ 𝒜 | Z ∩ S = W}` — the subclass consistent with the
  labeled pair (Z, W). This is the version-space object in set grammar (cslib
  VersionSpace convergence; floor confirms). [T-Abbrev]
- D3 `Convention α := Set α → Set α → Set α` — reconstruction as a total function
  ρ Z W. [T-Abbrev. COUNTERDEF C3: dependent domain (Z : Finset α) → (W : Set α) →
  W ⊆ Z → Set α, swap iff totality-junk pollutes coherence lemmas. BP3.]
- D4 `IsKernel ρ k A T Z := Z ⊆ A ∧ Z.ncard ≤ k ∧ ρ Z (Z ∩ T) ∩ A = T`.
- D5 `HasKernelScheme 𝒜 k := ∃ ρ, ∀ A T, IsSample 𝒜 A T → ∃ Z, IsKernel ρ k A T Z`.
  [T-Prop; the quantifier structure IS the content. COUNTERDEF C5: bundled
  structure Scheme (compress/reconstruct/size fields), swap iff T4 glue needs
  field projection; then L0 states the equivalence. BP-adjacent.]
- D5' `price 𝒜 k : ℕ∞` := least index cardinality c such that a (κ, ρ, I)-scheme
  with kernel ≤ k and |I| = c exists (∞ if none). price = 1 means no side
  information. [T-Parametric]
- D6 `freeSets 𝒜 Z W A := {B | B ⊆ A ∧ Shatters (residual 𝒜 Z W) B}` — the freedom
  skeleton at a stage, through a window. [T-Abbrev]
- D7 `defect 𝒜 A := (freeSets 𝒜 ∅ ∅ A).ncard − ((A ∩ ·) '' 𝒜).ncard` — skeleton
  count minus trace count, per window. [ℕ with truncated subtraction. COUNTERDEF C7:
  ℤ-valued, swap iff L2's rearrangement fights ℕ-sub. BP2. Precedent: hcComb is ℕ
  with positivity-first discipline; mirror it.]
- D8 `twist 𝒜 A x := defect 𝒜 A − defect 𝒜₀ (A∖{x}) − defect 𝒜₁ (A∖{x})` where
  𝒜ᵢ are the x-children. [derived; ℕ by L2]
- D9 Alignment: NOT YET TYPED — this is BP1, the genuine break point, and the
  abduction target. Candidate forms, all recorded, none committed:
  (i) a priority order on each twisted split pair, commuting with restriction;
  (ii) an orientation field on twists such that cascade-defaults compose;
  (iii) a pointed skeleton: a distinguished section (default member) per stage,
       with kernels as deviation records (E1's shape made global).
  The even-prefix class is the calibration instance: its alignment is the linear
  order; k pays only at orientation boundaries.

**L-layer (calculus; each a Lean target).**

- L0 (scheme ⟺ convention; side info = coloring). The (κ, ρ) form, the convention
  form, and — with index I — the fiber-coloring form are equivalent. Status: derived
  Pass 1, KU until kernel. [reviewer item 1]
- L1 (defect ≥ 0 per window). KK_kernel: this is the shipped native Pajor bound
  (`ncard_image_inter_le_ncard_shatters`, mean-fourier branch `sauer-shelah`),
  applied to residuals.
- L2 (split superadditivity; twist ≥ 0). Derived Pass 4 (a)(b)(c). KU_high.
  [reviewer item 2 — first target: if this fails, everything downstream re-audits]
- L3 (hereditary flatness). defect 𝒜 A = 0 forces defect 0 for every residual stage
  inside A. Corollary of L1 + L2, no new hypothesis. KU_high.
- L4 (join Leibniz; twists scale, never mix). For disjoint grounds and the join
  class {S₁ ∪ S₂}: trace and skeleton counts are multiplicative, hence
  defect(join) = defect₁·|sh₂| + |Tr₁|·defect₂, and
  twist_join(x ∈ side 1) = twist₁(x)·|sh₂| (exactly; uses trace additivity).
  Derived; KU_high. [reviewer item 3. Same derivation law as hcCombPi_sumRel —
  operator-class evidence, private note only.]
- L5 (rank inheritance). HasVCDimLE d bounds every freeSets member's ncard at every
  stage (residual ⊆ class; Shatters monotone). KK-adjacent.
- L6 (skeleton growth). |freeSets| ≤ Σ_{i ≤ d} C(n, i) on n-windows. KK_kernel
  (shipped counting lemma + L5).

**T-layer (theorem targets; the conjecture set proper).**

- T1 (flat case: addressing theorem). (a) Every window-flat-everywhere class admits
  an addressing: a per-sample kernel of size ≤ d realizing the scheme under a cascade
  convention (defaults per stage; kernel = deviation record). (b) Hence flat ⟹
  HasKernelScheme 𝒜 d ∧ price 𝒜 d = 1. Status: KU2. Instances verified by hand:
  singleton, chain, free cube, initial segments. The cascade's canonicity is the open
  sub-question (gauge freedom; if canonical choice fails, quotient the gauge in T5).
- T2 (THE BUDGET LAW — KU1, central abduction target). Every class with
  HasVCDimLE d admits an alignment of its twist field in which every sample has a
  kernel paying ≤ f(d) orientation-boundary crossings, f linear. Candidate shapes:
  boundary-pairs per free direction (even-prefix pattern generalized: 2 per
  direction → f = 2d). Known-dead shape: global flattening number ≤ f(d) (K3).
- T3 (necessity / price lower bound). The residual mis-alignment of the twist field
  lower-bounds price: a twist configuration that no alignment orients coherently
  forces price > 1 at the corresponding kernel size. Exact statement = KU4. This leg
  makes the primitive the obstruction, not merely a sufficient device.
- T4 (fiber gluing). From any (κ, ρ, I)-scheme extract an alignment purchased
  pointwise: |I| colors = an exogenous priority structure. Corpus instance to glue:
  FLT `CompressionSchemeWithInfo0` / `fundamental_vc_compression` (typing = KU5).
  Reading: existing proofs are sections of the base construction with the alignment
  imposed from outside; T4 ∘ T2 recovers them and locates their overpayment.
- T5 (LW at the base). HasVCDimLE d 𝒜 → HasKernelScheme 𝒜 (C·d) with price 1.
  Route: T1 (flat core) + T2 (aligned crossings) + a PER-SAMPLE surgery from general
  to flat along aligned twists. The surgery must be local (per sample), not a global
  embedding of the class into a flat class — the global form is exactly the move
  Dhruv flagged as having negative results in scopes (KU8 records the constraint,
  not the literature).
- T6 (dichotomy / witness extraction). At every (d, k): either the alignment of T2
  exists, or a FINITE witness configuration (a cyclically mis-aligned twist cluster)
  is extractable that forces price > 1 at kernel k. The falsifiability leg: it would
  either prove LW or produce the counterexample class. KU-shaped after T3.
- KU-cal (calibration gate, first grind target). d = 1 total: every VC-1 class has
  HasKernelScheme with k ≤ 3 and price 1, by explicit alignment. If VC-1 resists,
  the alignment type (D9/BP1) is under-specified and must be enriched BEFORE any
  general-d attempt.

**Price-function panel (calibration points, no proofs imported).**
price 𝒜 k is antitone in k. d = 0: price = 1 at k = 0. Flat: price = 1 at k = d
(T1). General d: price = 1 at some exponential kernel (external calibration; corpus
glue via T4 only). LW: price = 1 at k = C·d. The entire conjecture is a statement
about where the price function hits 1.

### 1.3 Typing measurement summary (task-urs derivation)

Break-point budget (5): BP1 alignment type (genuine, the abduction target — ad-hoc
choice IS the content); BP2 ℕ vs ℤ defect; BP3 convention totality; BP4 per-sample
vs global surgery in T5; BP5 witness-configuration type in T6.
Joints with HC > 0 (scheme-vocabulary ↔ skeleton-vocabulary): the alignment joint —
until T2-LAW's form is fixed, scheme-side and skeleton-side types do not compose;
counterdefs C3/C5/C7 pre-compute the falls. Profile distribution: 4 T-Abbrev,
2 T-Prop, 2 T-Parametric, 1 T-Break — no homogeneity warning.

### 1.4 Ignorance geometry (object)

KK (kernel-verified): L1 (native Pajor, mean-fourier), L6 counting, her grammar
  (Shatters/HasVCDimLE/vcGrowth + our four shipped lemmas).
KK (hand, decide-check pending): diagonal class (defect 1, twist 1, VC 1); chain
  class addressing; singleton scheme; free-cube-pair (K1); even-prefix scheme k = 2
  (K3); circular-arcs recount (K4).
KU (numbered): KU1 T2 budget-law form; KU2 T1a cascade canonicity; KU3 d = 1
  calibration; KU4 T3 exact statement; KU5 T4 typing vs CompressionSchemeWithInfo0;
  KU6 ℕ-subtraction discipline for L2; KU7 L0 coloring form in Lean; KU8 locality
  constraint on T5 surgery; KU9 window monotonicity of defect (direction unknown —
  A ⊆ A' comparison; the projection-monotone analogue suggests one direction).
UK (floor targets): cslib VersionSpace/VersionSpaces (stage poset = version-space
  lattice — his own #730); FLT IndependentVC infrastructure (shifting/extremal-like
  machinery under native names?); FLT Compression types; TLT router-forest addresses
  (tree-address shape for E1?); Mathlib Shatters API (Finset-side), minimal-witness
  choice lemmas.
UU: alignment obstructions of higher degree (does mis-alignment stratify beyond one
  level?); decidability of price; what the R-expansion does to the learnability ↔
  compression joint once stated at the base.

### 1.5 Forward counterfactual table (what kills what, and what each kill forces)

- L2 fails in Lean → derivation error → full calculus re-audit (reviewer first).
- KU-cal (VC-1) resists k ≤ O(1) → D9 under-specified → promote a UU (second-order
  alignment structure) to KU; do NOT weaken the target (A5).
- T1a cascade needs choice incompatible with twist-equivariance → pointed-skeleton
  gauge admitted; T5 quotients the gauge.
- T6 witness constructible at small d with unbounded price at k = C·d → LW is FALSE
  → the programme's output flips to the witness class (a Pl-kill of LW itself is a
  discovery, A4).
- L4 twist-scaling fails → alignment cannot be built componentwise → join calculus
  re-derived before T2.

════════════════════════════════════════════════════════════════════
## 2. AGENT AXIS (Γ) — noological record
════════════════════════════════════════════════════════════════════

A (Will snapshot): LW R-expansion arc under Dhruv's Will. Strict A4/A5. No-literature
vow (scope: papers/results external to corpus; corpus + Mathlib searches licensed).
CCMW permission held unused. Ample-completion lookup permanently renounced. Base-not-
fiber. Primitive-first. Shipping artifacts URT-free. Every example decide-checked (K4).

R-moves this session (all conjecture-grade until verified; 2.3 gate honored):
base reformulation (convention form, eliminating κ); freedom skeleton as stage-indexed
representation; defect as its counting shadow; twist as the split-invisible remainder;
alignment as the orientation stratum (BP1, deliberately left untyped); price function
as the graded target. Askability change (Γ): LW restated as an alignment-existence
statement at the base; side information retyped as purchased determination; the
conjecture becomes "where does the price function hit 1".

M-moves: split calculus (window recursion); join calculus (Leibniz + twist scaling);
per-sample surgery (posed, KU8); addressing cascade (E1).

Γ_core: Coh_ens↔Will — the front-load engineers ignorance (3 object-kills + 1 method-
kill, 2 forced enrichments, 9 numbered KUs, 5 break points) and answers nothing ahead
of its verifiers; matches the instructed shape. Pl_imagine — gated by four verifiers;
nothing self-generated banked as KK; L2/L3/L4 marked KU_high explicitly.

γ ledger: no new KK banked this session (L1/L6 were prior kernel work).
Γ ledger: the retyping of the conjecture (above); the kill ledger as boundary content.
η: three kills + two enrichments + a complete typed proposition set, pre-verification.

## 3. Reviewer handoff spec (async, ultraconservative, ML-theory)

Verify by direct derivation only (no literature): (1) L0 equivalences, both
directions, and the coloring form; (2) L2 steps (a)(b)(c) — first target; (3) L3
collapse logic; (4) L4 multiplicativity and twist-scaling computation; (5) each
worked instance's arithmetic (diagonal; chain addressing; singleton scheme;
free-cube-pair VC = d and double rank-preservation; even-prefix VC = 1, defect
growth, k = 2 scheme correctness; circular-arcs VC = 3); (6) A4 audit: vacuity,
decorative hypotheses, definition-engineering in D1–D8. Report numbered verdicts
with derivations, CONFIRMED / REFUTED / GAP per item.

## 4. Floor results (loogle target `learning-theory` + session KK; 2026-07-29)

**F0 — the conjecture is already stated in the kernel.** `CompressionPipeline.LWAt f`,
`LittlestoneWarmuthLinear` (∃ K, LWAt (fun d => K*(d+1))), `LittlestoneWarmuthWeak`
(IR.lean:149-160); `Open_NoInfoCompressionStrengthening` (Structures.lean:268) ≡ the
weak form. T5's final statement MUST imply `LittlestoneWarmuthLinear` through the
grammar bridge (→ KU10): Set-grammar classes ↔ `ConceptClass X Bool` via indicators;
`Fin m → X × Bool` realizable samples ↔ (A, T) window pairs (repeats harmless under
realizability, contradictions excluded by it).

**F1 — the kernel's `CompressionScheme.reconstruct` is already the convention.**
Structures.lean:40-56: reconstruction depends on the compressed Finset alone (the
Γ₇₃ definition-repair guarded correctness by realizability). L0's convention form is
a re-packaging (∃-eliminated κ), not a new object. `CompressionSchemeWithInfo`
(Structures.lean:215, size = kernelSize + |Info|) types the price function's info
axis. `FractionalCompressionScheme` (IR.lean:103) is the fiber IR: distribution over
`kernelCandidates`, margin > 1/2, NO info — with the kernel's own audit finding that
side information enters ONLY at the dual-VC sparsification backend ("incidence
gluing of blocks"), which matches Pass 1's independent derivation (side info =
chromatic number of fiber incompatibility). T4's glue targets are exactly:
`FractionalMY`, `moran_yehudayoff_forward_construction`, `fundamental_vc_compression`.

**F2 — prior attack R5 (process frame) is CLOSED with kill verdicts that constrain D9.**
ProcessFrame.lean: Kill A1 `AppendOnlyForcedGrowth` — on `thresholdClass` (ℚ, VC 1)
append-only anytime-valid selectors are forced to unbounded kernels (bisection makes
every new point the version-space boundary). Kill A2 — `OnePassCompression.
toCompressionScheme`: eviction-streaming reduces to offline, no added power.
`StreamingLW` recorded as the frame's surviving new question (above weak LW via
`streamingLW_implies_weak`). CONSEQUENCE FOR D9: the alignment is an OFFLINE/GLOBAL
structure — per-sample kernels may depend on the whole sample as a set; any
prefix-committed monotone mechanism dies at VC 1. The even-prefix k = 2 scheme (whole-
sample boundary) already has this shape. The cascade of E1 is address-computation,
not stream-commitment; A1 does not touch it, and now must never be allowed to.

**F3 — thresholdClass is flat.** Traces on an n-window: n + 1; shattered sets:
∅ + singletons = n + 1; defect 0 at VC 1. His canonical adversarial VC-1 instance is
window-flat everywhere, so KU-cal's first instances are: thresholdClass (flat leg,
addressing must produce k ≤ 1-2), diagonal class (twist 1 leg), even-prefix class
(serial-twist leg). Also floors: flatness gives offline schemes, NOT streaming ones —
alignment strictly offline (agrees with F2).

**F4 — counting side.** `CountingCertificate`/`CountingBarrier`/`CountingSound`
(Obstruction.lean, unread this session — pointer only): the kernel's betting/counting
lower-bound machinery caps at d per the R5 verdict text. Price-panel calibration:
counting-type lower bounds are linear-capped; T3's lower bound must come from the
twist configuration, not counting (or it will hit the same cap).

**F5 — session-KK floors (no new search needed).** cslib `VersionSpaces` lattice
(#730, read this session): D2's stage poset is literally his version-space lattice
(meet law = `versionSpace_append`). Mathlib: `Finset.Shatters`/`shatterer`/`vcDim`
(Finset grammar; the PR #38319 base). Yaël grammar + our four shipped lemmas
(`ncard_image_inter_le_ncard_shatters` = L1's engine, `HasVCDimLE.ncard_image_inter_le`
= L6, `vcGrowth_le`, exp bound) on mean-fourier branch `sauer-shelah`.

**KU10 (new, from F0).** The grammar bridge: state the base objects in Set-grammar
(Yaël types, shipping-clean), prove T5 there, then a bridge file mapping to
`ConceptClass X Bool` + `CompressionScheme` to discharge `LittlestoneWarmuthLinear`.
Bridge direction fixed: base → kernel (ZPM discipline: kernels never import ZPM;
the bridge lives in FLT, importing nothing from staging).

**Floor lesson for D9 candidates (i)-(iii):** all three survive F2 only in offline
form; candidate (i) (priority order per twisted split) must NOT be presented as a
stream priority. The alignment's type carries a set-functional signature.

════════════════════════════════════════════════════════════════════
## 5. THE BET (banked 2026-07-29, BEFORE the Lean file; fulfilment graded after build)
════════════════════════════════════════════════════════════════════

Architecture bet: the calculus lives on `Finset (Finset α)` (a finite trace family as
the primitive object, HC-substrate pattern); the scheme layer lives on `Set (Set α)`
(arbitrary classes, finite windows); ZPM home `ZPM/Measurements/SI/` with four files
(Combinatorial / Scheme / Conjectures / Instances) + barrel; Mathlib's
`Finset.Shatters`/`Finset.shatterer` carries the skeleton, and Mathlib's Pajor
(`card_le_card_shatterer`-shaped decl, exact name to floor) discharges L1 for free.
Unproved conjectures enter as `def _ : Prop` conjecture-roots (the kernel's own
LWAt/AppendOnlyForcedGrowth pattern), NEVER as sorry-theorems. D9 (alignment) is NOT
typed — held as a documented break-point comment; typing it now would be
definition-engineering (A4).

- B1: the module compiles green under ZPM, zero sorry, zero URT language, every
  definition's source cited in its docstring. PREDICT: fulfilled.
- B2 (kernel-proved THIS turn): L1 wrap (cite Mathlib), L2 as three lemmas — exact
  trace additivity `card = card₀ + card₁`, skeleton superadditivity
  `sh₀.card + sh₁.card ≤ sh.card`, defect superadditivity
  `d₀ + d₁ ≤ d` — plus L3 hereditary flatness, L0(a) (index-1 scheme ⟺ kernel
  scheme), and ≥ 4 decide-checked instance facts including diagonal splitLoss = 1
  and a flat-class defect 0. PREDICT: fulfilled; risk concentrated in the x-lift
  injection bookkeeping and in whether `decide` evaluates `shatterer`.
- B3 (conjecture-roots stated): flat compression (T1b), base LW (T5 linear form),
  d = 1 calibration (KU3). PREDICT: fulfilled.
- B4 (STRETCH, graded separately): L4 join Leibniz in Finset grammar this same turn.
  PREDICT: attempted; uncertain to land within the turn — recorded so the miss, if
  it happens, is a calibration datum, not a silent drop.

Working-vocabulary map (private → shipping): twist → `splitLoss`; freedom skeleton →
`shatterer` (Mathlib's own); defect → `shatterDefect`; stage → labeled pair via
`zeroSide`/`oneSide` children. "Structural ignorance" appears only as the module's
object-level name (HC-precedent), never process vocabulary.

════════════════════════════════════════════════════════════════════
## 6. BET FULFILMENT (graded same-day, build `8757 jobs` green)
════════════════════════════════════════════════════════════════════

Home: `ZPM/Measurements/SI/{Combinatorial,Join,Scheme,Conjectures,Instances}.lean`
+ barrel, wired into `ZPM.lean`. Children realized as Mathlib's own
`Finset.memberSubfamily/nonMemberSubfamily` (found at floor time — better than the
planned bespoke `zeroSide/oneSide`).

- B1 ✔ FULFILLED. Green, zero sorry; axiom audit on 11 key theorems: only
  [propext, Classical.choice, Quot.sound], no sorryAx. Zero URT language; every
  definition docstring cites its source (Mathlib decls; LW 1986; MY 2016).
- B2 ✔ FULFILLED. `shatterDefect_add_card` (L1 wrap, cites
  `Finset.card_le_card_shatterer` — Mathlib itself labels it Pajor);
  trace additivity fulfilled BY CITATION (it already exists:
  `Finset.card_memberSubfamily_add_card_nonMemberSubfamily`); NEW kernel proofs:
  `card_shatterer_split_le` (skeleton superadditivity, the two-injection
  argument), `shatterDefect_split_le`, `splitLoss` + `splitLoss_add_shatterDefects`
  (exact accounting), both hereditary-zero theorems, `hasIndexedScheme_one_iff`
  (L0(a)). Five decide facts green: diagonal defect 1, diagonal splitLoss at 0
  = 1, chain defect 0, initial-segment defect 0, even-prefix-4 defect 2. The
  `decide`-evaluates-`shatterer` risk did not materialize.
- B3 ✔ FULFILLED. `FlatCompression`, `BaseLW`, `CalibrationVCOne` as
  conjecture-root Props; alignment held as the documented break point.
- B4 ✔ LANDED (predicted uncertain — exceeded). `join`, `mem_join`, `card_join`,
  `shatters_join_iff`, `shatterer_join` (an EQUALITY of families: the shatterer of
  the join is the join of the shatterers), `shatterDefect_join` (the Leibniz
  rule). Two build iterations: `ring` absent from the import closure → explicit
  `Nat.mul_add`/`Nat.add_mul` rewrites; a rewrite-chain mis-association → rw-at-
  hypothesis form. Mathlib's `Finset.disjSum`/`toLeft`/`toRight` API carried it.

Calibration note (Pl_imagine): 4/4 banked components fulfilled, stretch included;
the two failure predictions I flagged (x-lift bookkeeping, decide-on-shatterer)
both compiled first try; the actual friction was import-closure (`ring`) and
rewrite associativity — neither predicted. Loogle reindexed post-build (SI decls
now searchable under target `measurements`).

════════════════════════════════════════════════════════════════════
## 7. REVIEWER INTEGRATION (REVIEW-SI-front-load.md, async opus, same day)
════════════════════════════════════════════════════════════════════

Verdicts: L0(a,b,c) CONFIRMED (with the two load-bearing conditions made explicit:
fibers over (Z,W) not Z; improper reconstruction; infinite fibers fine — union of
pairwise-compatible partial labelings, no compactness). L2(a,b,c) CONFIRMED and
upgradeable to an EXACT identity. L4 CONFIRMED including twist scaling. Instances
5a-5f CONFIRMED (5d scoped to d ≥ 1; at d = 0 the free-cube-pair has VC 1).
thresholdClass flat CONFIRMED. Kills K1/K2/K3 stand.

Corrections adopted:
- **L3 IS SCOPED (KU11, new).** Hereditary flatness holds for conditioning INSIDE
  the window; out-of-window conditioning can RAISE window defect (reviewer
  witness: 𝒜 = {{x},{y},{z},{x,y,z}}, A = {x,y}: defect 0; condition z = 1 →
  defect 1). The compiled Lean theorems are the family-level (scoped) form —
  correct as stated. CONSEQUENCE: T1's cascade must condition only inside the
  sample window; `WindowFlat` is NOT stable under out-of-window residuals. This
  is a genuine design constraint on D9, discovered by the audit, not by me.
- **Twist retype (KU12, new).** Reviewer's exact identity: splitLoss a 𝒜 =
  #{B : a ∉ B, 𝒜 shatters B, neither child shatters B}. Retypes the ℕ-subtraction
  into a cardinality of an explicit family — kills the Nat.zero_le-triviality
  concern permanently. Next Lean target.
- **KU9 RESOLVED → KU13 (Lean-ization pending).** Defect is MONOTONE in the
  window (A ⊆ A' ⟹ defect_A ≤ defect_{A'}); reviewer proof via Pajor on the
  intersection of child trace families.
- **KU1 sharpened.** Even-prefix pays k = 1, not 2 (reviewer scheme: single
  anchored max-in point + rounding convention). My "2 per direction, f = 2d" was
  fitted to a non-tight instance; the live candidate is one kernel point per
  crossed direction, f = d exactly.
- price edge semantics: empty class has price 0 (vacuously); record, harmless.
- Front-load prose A4 items (ncard unguarded on infinite sets in D4/D7): moot in
  the Lean typing (Finset windows throughout); prose annotations corrected here.

**OUTSIDE FINDING — FLT kernel bug (surface to Dhruv, his file, his call).**
`CompressionPipeline.AppendOnlyForcedGrowth` (ProcessFrame.lean:170) is FALSE AS
TYPED: quantifier order `∀ k, ∃ l, ... ∀ sel` lets the stream be chosen before
the selector, and the reviewer exhibits a refuting selector (offline, sees all of
`l`). The intended kill (adversarial bisection) needs `∀ sel, ∃ l`. The F2 floor
lesson (alignment must be offline) survives under the intended reading; the
conjecture-root Prop needs the quantifier swap. NOT edited — FLT is out of this
session's write scope without direction.

KU ledger after this tick: KU1 (sharpened: f = d candidate), KU2, KU3 (next
grind: d = 1 with the k = 1 anchor insight), KU4, KU5, KU6 RETIRED (add_card
forms eliminated ℕ-sub), KU7, KU8, KU9 RESOLVED, KU10, KU11 (in-window scope),
KU12 (twist-as-cardinality), KU13 (window monotonicity in Lean).

════════════════════════════════════════════════════════════════════
## 8. THE d = 1 GRIND — front-load and bet (banked 2026-07-29 before Lean)
════════════════════════════════════════════════════════════════════

Derivation record (deepen-then-attack passes, this front-load):

**Kill K5 (of my OWN prior kill).** In the design passes I "proved" k = 1 death
for the star class {{x,a},{y,a},{x,y,a}} (VC 1) via fiber conflicts on window
{x,y}. The argument is INVALID: it only considered 1-labeled anchors (Z ⊆ T) and
forgot 0-LABELED kernels (Z = {y}, W = ∅). With them the star has a k = 1 scheme:
route T = {x} samples to ({y}, ∅) ↦ {x,a}; T = {x,y} to ({x},{x}) ↦ {x,y,a};
T = {y} to ({y},{y}) ↦ {y,a}. Lesson admitted: kernel case analyses must always
cover the 0-labeled half of the pair alphabet. CONSEQUENCE: no counterexample to
k = 1 at VC-1 survived this front-load's attacks → KU14 (new): is k = 1 UNIVERSAL
at VC dimension 1? (Also retro-sharpens KU1: per-direction cost might be exactly 1.)

**Kill K6 (min-member cascade).** The chain-class convention "reconstruct the
⊆-minimal member containing the anchor" dies on DENSE chains: rational thresholds
{q ≤ θ} have no minimal member containing x. Fix forced: IMPROPER reconstruction
— the intersection of all members containing the anchor, which is not a member.
The convention that survives: ρ(Z, W) = ⋂₀ {S ∈ 𝒜 | W ⊆ S}, one formula, no
case split (W = ∅ gives ⋂₀ 𝒜, which handles all-zero samples).

**The splitting law (deepened).** At vcBounded 1, no point y is singleton-
shattered in BOTH residuals of another point x: the four assembled patterns
would shatter {x, y}. This is the semantic d = 1 face of "freedom does not mix
across a split" (the splitLoss calculus's Set-side shadow).

**The anchor order.** For a ⊆-chain class, a ≼ b iff every member containing b
contains a. Totality needs NO side hypothesis (two witnesses of failure are
⊆-incomparable members — contradiction with the chain); transitivity is direct;
a finite nonempty labeled set has a ≼-maximum by induction. Correctness of the
⋂-convention at the ≼-max anchor: upper bound via the realizing member, lower
bound via maximality. Dense-safe, minimum-free.

**Crossing probe.** 𝒜 = {∅, {x,u}, {y,u}} (VC 1): the u-anchor is ambiguous
(pointwise-minimal disagreement not achieved — two incomparable minimals), yet
k = 1 routing exists via x/y-anchors and 0-labeled kernels; k = 2 composite
kernels trivialize it. Kept as reviewer item and as the simplest instance where
the ALIGNMENT (routing choice) is genuinely non-canonical — the d = 1 shadow of
BP1.

**Typing (task-urs pass).** New file SI/VCOne.lean: `memOrder` (T-Abbrev,
relation), `memOrder_total_of_isChain` + `exists_memOrder_max` (T-lemmas; NO
decorative hypotheses — totality holds bare), `interConvention` (T-Abbrev; the
improper reconstruction), `vcBounded_one_of_isChain`, `hasKernelScheme_one_of_isChain`,
`singleton_shatters_at_most_one_residual` (splitting law). Plus `mem_residual`
unfold lemma added to Scheme.lean. Cites: `IsChain` (Mathlib Order.Chain);
LW 1986 for the scheme notion; improperness noted explicitly in the docstring.

**THE BET (C-series):**
- C-I: FLT `AppendOnlyForcedGrowth` quantifier fix (∀ sel ∀ k ∃ l) compiles;
  no downstream references break (grep: definition-only). PREDICT fulfilled.
  [GRADED: fulfilled same tick — FLT_Proofs green, 3265 jobs.]
- C-II: `vcBounded_one_of_isChain` AND `hasKernelScheme_one_of_isChain` (k = 1
  for ⊆-chain classes, arbitrary α, dense-safe, improper ⋂-convention)
  kernel-green this tick. PREDICT fulfilled; risk in Finset/Set coercion
  plumbing at the ext-case-bashes.
- C-III: `singleton_shatters_at_most_one_residual` kernel-green this tick.
  PREDICT fulfilled.
- C-IV (declared boundary, not bet): full `CalibrationVCOne` stays OPEN this
  tick — the general VC-1 routing is BP1's d = 1 shadow (see crossing probe);
  attacking it before the reviewer rules on KU14 would fix the alignment
  grammar prematurely.

Reviewer handoff (async, this tick): verify K5 (the star k = 1 scheme as routed
above, all fibers); K6 (dense-chain death of min-member; correctness of the
⋂-convention: both inclusion legs, T = ∅ leg, edge 𝒜 = ∅); memOrder totality
(bare, no common-member hypothesis) and max-extraction; the splitting law
assembly (all four patterns, coercion-level); the crossing probe's k = 1 routing
INCLUDING 0-labeled kernels; and an adversarial hunt for a VC-1 class where
k = 1 fails (KU14 probe) — 0-labeled kernels now in the attacker's alphabet.

**C-SERIES FULFILMENT (same tick, build 8758 jobs green).**
- C-I ✔ FULFILLED: FLT `AppendOnlyForcedGrowth` now `∀ sel ∀ k ∃ l`, with a
  docstring recording why the swapped order is false; FLT_Proofs green (3265
  jobs); the name is referenced nowhere else (grep).
- C-II ✔ FULFILLED: `vcBounded_one_of_isChain` and
  `hasKernelScheme_one_of_isChain` kernel-green in SI/VCOne.lean — the
  programme's first actual compression theorem: every inclusion-chain class,
  dense or not, over any ground type, compresses at kernel size ONE with no
  side information, via the improper `interConvention` and the `memOrder`
  maximum anchor. Supporting: `memOrder_refl/trans`, bare-hypothesis
  `memOrder_total_of_isChain`, `exists_memOrder_max`
  (`Finset.Nonempty.cons_induction`), `mem_residual` added to Scheme.lean.
- C-III ✔ FULFILLED: `singleton_shatters_at_most_one_residual` kernel-green —
  the d = 1 splitting law, four-pattern assembly, closing on `card_pair`.
- C-IV held as declared: `CalibrationVCOne` remains open; d = 1 general routing
  awaits the reviewer's KU14 verdict (async, pending — not predicted here).
- Axiom audit: all five new theorems at [propext, Classical.choice, Quot.sound],
  no sorryAx. Loogle `measurements` reindexed (VCOne decls searchable).
- Friction ledger (calibration): three build iterations — `induction T, hT`
  joint-target syntax invalid (plain `induction hT using` works);
  `simpa`-vs-`simp at` on a False-typed hypothesis; `mem_cons_self` explicit
  args. Predicted risk (coercion plumbing at ext-bashes) partially materialized
  in the T = ∅ leg simp-set; the `Set.ext_iff`-pointwise extraction pattern for
  membership facts worked everywhere first try.

════════════════════════════════════════════════════════════════════
## 9. CLOSING d = 1 AND THE CALCULUS — front-load and bet (banked before Lean)
════════════════════════════════════════════════════════════════════

Derivation record (passes; kills; the KU14 state change):

**K7 (kill of the crossing suspicion).** The crossing probe {∅, {x,u}, {y,u}}
HAS a complete k = 1 scheme: ρ({x},{x}) = {x,u}, ρ({y},{y}) = {y,u},
ρ({u},{u}) = {u} (IMPROPER — not a member), ρ(∅,∅) = ∅. Fiber checks: x-in
fibers mix T = {x} and T = {x,u} samples, compatible because u is never shared
with a 0-label; the u-in fiber's samples all label every non-u point 0, so the
improper {u} serves all of them. My earlier "incoherence" assumed reconstruction
values must be members. Improperness resolves the u-anchor ambiguity.

**The signature kill (improperness is ESSENTIAL, not a convenience).** Any
design with injective "signature" symbols per closed-class member (fibers =
one member's restrictions) needs every realized singleton symbol (x, b) to sign
a consistent member; chains realize 2n such symbols with only n + 1 members —
impossible. So proper/single-member-fiber designs provably fail on chains,
while the improper ⋂-convention succeeds. The value of a symbol is in general
NO member's trace.

**The priority normal form (BP1 typed).** Fix any priority assignment
prio : symbols → hypotheses and route each sample to a symbol whose prio-value
realizes it; fibers are then coherent BY CONSTRUCTION (a single fixed value per
symbol). Scheme existence ⟺ every realizable sample has an UNSHADOWED symbol
(one whose global value happens to realize this sample). D9's type, forced by
this pass: a priority structure (choice of symbol values, e.g. least-consistent
member under a well-order of the closed class, or improper intersections) plus
the unshadowing condition. Alignment = the priority design.

**The compactness reduction (KU14 → KU14').** k = 1 existence is a
list-coloring of the sample-conflict graph (colors = symbols, palettes = the
sample's own ≤ 2|A| + 1 symbols, finite). By compactness (finite palettes),
existence for every FINITE subfamily suffices; finite subfamilies live on
finite supports, and only the trace family on the support matters. KU14' :
every finite VC-1 trace family on a finite ground admits a k = 1 scheme ⟺
KU14. Within-window conflicts always admit distinct symbols (n + 1 traces vs
2n + 1 symbols); the open content is cross-window symbol reuse. No kill found:
pairwise-conflict cliques stay under the symbol count (clique growth is
VC-capped); no Hall-type violation constructed after adversarial passes.

**KU12 derivation (twist as cardinality, exactness of the lift).** From the
split proof: x-containing parent-shattered sets biject with sh₁ ∩ sh₀ — the
NEW direction: 𝒜 shatters insert x B (x ∉ B) ⟹ BOTH children shatter B
(0-side witnesses land in the nonMember child; 1-side witnesses erase to the
member child). Hence the lift is a bijection, the x-free part contains
sh₁ ∪ sh₀, and splitLoss = #{B ∈ sh(𝒜) : x ∉ B, neither child shatters B} —
the second reviewer's identity, now re-derived independently.

**KU13 derivation (window monotonicity).** For x ∉ A: the two point-children of
windowTrace 𝒜 (insert x A) ARE window traces of the residuals on A (bridge
lemmas — the missing Scheme↔Combinatorial glue), their union is windowTrace 𝒜 A,
so #Tr' = #Tr + #I with I the two residual traces' intersection; and
#sh' ≥ #sh + #sh(I) ≥ #sh + #I by the x-free transfer, the insert-lift through
the children, and PAJOR APPLIED TO I. Defect gains at least 0 per added point;
induct via A ∪ D.

**d = 0 rung.** vcBounded 0 forces all members equal (a difference point is a
shattered singleton), so k = 0 with ρ ≡ ⋃₀ 𝒜.

**THE BET (E-series):**
- E-I: `shatters_insert_iff` (x ∉ B: parent shatters insert x B ↔ both children
  shatter B) + `splitLoss_eq_card` kernel-green in Combinatorial.lean, with a
  decide instance. PREDICT fulfilled; risk: the erase/insert bijection
  bookkeeping (card_bij').
- E-II: SI/Window.lean: `nonMemberSubfamily_windowTrace`,
  `memberSubfamily_windowTrace`, `windowTrace_eq_union_residuals`,
  `windowDefect_le_insert`, `windowDefect_mono` kernel-green. PREDICT
  fulfilled; the largest piece — risk concentrated in coercion volume at the
  bridge exts.
- E-III: d = 0 rung: `eq_of_vcBounded_zero`, `hasKernelScheme_zero_of_vcBounded_zero`
  in VCOne.lean. PREDICT fulfilled.
- E-IV (the honest d = 1 closure): KU14 is NOT closed by a kernel proof this
  tick. It is closed as a STATE: reduced to KU14' (finite grounds) with BP1
  typed, the crossing suspicion killed (K7), and improperness proved essential
  (signature kill). Second reviewer's report pending at banking time — to be
  integrated on arrival, and its KU14 verdict may supersede this state.

**K8 (mid-turn, Dhruv's catch — the priority form was a fiber re-import).**
The "priority normal form" I typed BP1 with is an exogenous global tie-break —
the same move T4 attributes to the weighted fiber proofs — and the
list-coloring frame is assignment-level. RETYPING (base grammar, from the HC
library): the symbols are a COVER's teams, the samples are the shared
interface, a scheme is a glued global section over the cover, and existence
rides on the cover's SHAPE:

- KU14' restated: does every finite VC-1 sample cover admit ear elimination to
  empty (the `IsEarOf`/`GrahamReducible`/`Acyclic` grammar,
  `acyclic_iff_grahamReducible`)? Positive leg → scheme by the
  `glues_of_acyclic` analogue; negative leg → a hosted clean cycle
  (`cycle_obstruction`, Specker-shape) = the FIRST price obstruction, which is
  T6 arriving early. The priority form survives only as a normal form (every
  scheme induces one), never as the deciding structure.
- BP1/D9 retyped: alignment = an ear-elimination order of the symbol cover —
  offline (F2-consistent), structural, base-level. The chain theorem's
  memOrder-max anchor is an ear-selection rule in disguise; the within-window
  symbol slack (n + 1 traces vs 2n + 1 symbols) is ear-abundance.
- The compactness reduction is retained (it is trace-level, base-safe) and now
  load-bearing for a new reason: it delivers FINITE covers, the exact regime of
  the HC machinery (Fintype). SI may import ZPM.Measurements.HC inside ZPM —
  the one-way rule constrains external kernels, not intra-ZPM imports.
- KU15 (new, next front-load): the LocalStruct dictionary — the instantiation
  ι/X/teams for the sample cover (candidate: variables = interface points or
  samples, teams = symbols; the design must keep X finite via the finite
  reduction). NOT rushed this tick; it deserves its own banked bet.

**E-SERIES FULFILMENT (same tick; build 8759 jobs green; axiom audit clean on
all eight new theorems).**
- E-I ✔ FULFILLED: `notMem_of_shatters_of_forall`, `shatters_insert_iff` (the
  bijection direction: parent shatters insert x B ⟺ both worlds shatter B),
  `splitLoss_eq_card` — the twist retyped as the cardinality of the explicit
  family {B ∈ sh(𝒜) : a ∉ B, neither world shatters B}; decide instance: on
  the diagonal pair at 0 that family IS {{1}}. KU12 CLOSED.
- E-II ✔ FULFILLED: SI/Window.lean green — `nonMemberSubfamily_windowTrace`,
  `memberSubfamily_windowTrace` (the point-worlds of a window trace ARE window
  traces of the residuals), `windowTrace_eq_union_residuals`,
  `windowDefect_le_insert` (adding a point adds #I traces and ≥ #I.shatterer ≥
  #I shattered sets — Pajor on the residual-trace intersection),
  `windowDefect_union_le`, `windowDefect_mono`. KU13 CLOSED: the defect is
  monotone in the window — structural ignorance accumulates with observation.
- E-III ✔ FULFILLED: `eq_of_vcBounded_zero` (VC 0 ⟹ all members equal) and
  `hasKernelScheme_zero_of_vcBounded_zero` (k = 0, ρ ≡ ⋃₀ 𝒜). The zero rung of
  the ladder is kernel-fact.
- E-IV as declared + K8 amendment: KU14 → KU14' (finite grounds) with the
  covering/ear retype; kernel proof deferred to the KU15 front-load. d = 1
  reviewer report still pending at fulfilment time.
- Friction ledger: four build iterations — `h∀` is an illegal identifier;
  anonymous ⟨⟩ does not construct Finset-∩ membership (use mem_inter.2);
  `filter_card_add_filter_neg_card_eq_card` deprecated to
  `card_filter_add_card_filter_not` (predicate-first signature); one grind
  needed the pointwise hSA instance normalized (Set.mem_inter_iff + mem_coe at
  the hypothesis) before the subst branch. All grind assemblies over add-form
  counting identities closed first try, including the five-hypothesis linear
  chain in `splitLoss_eq_card` and `windowDefect_le_insert`.
- Loogle `measurements` reindexed post-build.

════════════════════════════════════════════════════════════════════
## 10. d = 1 CLOSED AS A THEOREM — reviewer integration + the F-series bet
════════════════════════════════════════════════════════════════════

REVIEW-SI-d1-grind.md landed after §9's fulfilment. Headline: **KU14 is a
theorem, not a hunt** — `vcBounded 𝒜 1 → HasKernelScheme 𝒜 1`, arbitrary α,
arbitrary (infinite) class, no ∅, no ⊤, no chain hypothesis, and k = 1 is EXACT
(k = 0 impossible on {∅,{p}}). Proof route (reviewer's, to be kernel-ized):
Lemma A — label twists 𝒜 ∆ S₀ preserve shattering (pattern involution
C ↦ C ∆ (B ∩ S₀)), realizability, and schemes with the SAME kernels
(ρ(Z,W) := ρ'(Z, W ∆ (Z ∩ S₀)) ∆ S₀); Lemma B — with ∅ in the class, VC 1
forces co-member points ≼-comparable (the four assembled patterns shatter the
pair), so every label set is a finite ≼-chain; then the UNCHANGED
interConvention anchored at the ≼-max closes both legs, the ∅-leg now via
⋂₀ℬ = ∅ from ∅ ∈ ℬ. Machine-corroborated exhaustively at N = 4 (1944 classes,
62039 samples) and randomized N = 6, 8 (2.8M samples), zero failures.
Consequences: `CalibrationVCOne` is provable this tick; chains become a
corollary (kept — the direct proof carries the ⋂-convention); at d = 1 the
alignment D9 is EXPLICIT: twist to a base member, anchor at the ≼-maximum of
the twisted label set. Lemma B is d = 1-specific: calibration, NOT evidence
for T2.

Reviewer corrections adopted (item 6 + items 1–2):
- K6's printed dense witness was FALSE: closed rays {q ≤ θ} DO have minimal
  containing members; the correct witness is OPEN rays {q < θ}. The shipped
  VCOne docstring carries the false claim — MUST FIX (F-I).
- K5's printed 3-line star routing is not a scheme (no T = ∅, no a-windows,
  ({x},{x}) uncovered on A = {x}); the reviewer supplies a complete 7-fiber
  convention. Existence stands; the exhibit was mine and wrong.
- `interConvention` reads only W: all 0-labeled anchors collapse into the
  default — proved insufficient on the star as a general VC-1 convention. The
  general convention depends on Z; in the theorem the Z-dependence enters
  through the twist wrapper. Design fact recorded at D3/BP3.
- The splitting law's x ≠ y is DECORATIVE (statement true at x = y) — A4 fix
  shipped this tick (F-I). `SetShatters` class-monotonicity was an unlisted
  prerequisite — added (F-I).
- Crossing probe: TWO complete inequivalent k = 1 schemes (one with no
  0-labeled kernel at all); on A = {u} a u-anchor is compulsory and any
  u-anchor serving both x- and y-windows must be improper. Alignment freedom
  at d = 1 is real, and improperness is forced exactly where the reviewer said.

**THE BET (F-series, banked before the Lean):**
- F-I (corrections): docstring falsehood fixed ({q < θ}); splitting law
  de-decorated (x = y case proved directly); `SetShatters.mono_left` and
  `HasKernelScheme.mono` (kernel-size monotone) added to Scheme.lean.
  PREDICT fulfilled.
- F-II (twist layer, SI/Twist.lean): `twistClass`, `twistConvention`,
  `IsSample.twist`, `vcBounded_twistClass` (via the shatters transport with the
  pattern involution), `HasKernelScheme.of_twistClass` (same kernels),
  `empty_mem_twistClass`. PREDICT fulfilled; risk concentrated in symmDiff
  distributivity spellings and Finset/Set coe mixing — the heaviest plumbing
  of the arc.
- F-III (the theorem): `memOrder_total_of_vcBounded_one` (Lemma B),
  `exists_memOrder_max_of_total` (generalized max; chain version becomes an
  instance), `isKernel_interConvention_anchor` (extracted anchor leg),
  **`hasKernelScheme_one_of_vcBounded_one`** (KU14, kernel-grade), and
  `calibrationVCOne : CalibrationVCOne` discharging the conjecture root.
  PREDICT fulfilled conditional on F-II.
- F-IV (STRETCH, exactness): `not_hasKernelScheme_zero` on {∅,{p}} — k = 1
  cannot be improved. PREDICT attempted.

**F-SERIES FULFILMENT (same tick; build 8760 jobs green; axiom audit clean on
all nine checked declarations).**
- F-I ✔: docstring corrected to open rays {q < θ}; splitting law de-decorated
  (x = y case: the 1-residual's ∅-pattern witness both contains and avoids x);
  `SetShatters.mono_left` and `HasKernelScheme.mono` in Scheme.lean.
- F-II ✔: SI/Twist.lean green — `twistClass`, `empty_mem_twistClass`,
  `baseLabels`/`coe_baseLabels`, `IsSample.twist`, `SetShatters.of_twistClass`
  (untwist via the pattern involution + cancel), `vcBounded_twistClass`,
  `twistConvention`, `HasKernelScheme.of_twistClass` (same kernels).
- F-III ✔: `memOrder_total_of_vcBounded_one` (Lemma B),
  `exists_memOrder_max_of_total` (chain version now an instance),
  `isKernel_interConvention_anchor` (extracted; chain theorem rewired),
  **`hasKernelScheme_one_of_vcBounded_one` — KU14 KERNEL-CLOSED: every VC-1
  class over any type compresses at kernel size one with no side
  information** — and `calibrationVCOne : CalibrationVCOne` — the first
  conjecture root of the programme DISCHARGED.
- F-IV ✔ LANDED (stretch): `not_hasKernelScheme_zero` + `vcBounded_pair_singleton`
  — k = 1 is exact at d = 1.
- Friction ledger: three build iterations — `h∅`/`hB∅` illegal identifiers
  (∅ in a name; the h∀ lesson generalizes: NO symbol glyphs in hypothesis
  names); the `← Set.inf_eq_inter` rewrite chain failed to match under ∆
  (replaced with ext+grind private distributivity lemmas — deterministic ext
  beats algebraic rewrite chains in mixed Finset/Set contexts); simp's partial
  normalization of `u = u ∨ u = v` (True ∨ _ is NOT collapsed by simp-only
  lists) needed `Or.inl trivial`; `interConvention _` under-determined (made
  explicit).
- Post-tick state: d = 1 is CLOSED at full strength (theorem + exactness +
  discharged calibration root). The reviewer's d = 1 report is fully
  integrated; its Lemma A/B route is now kernel fact. BP1 at d = 1 is
  explicit: twist to a base member, anchor at the ≼-maximum. The alignment
  question lives ONLY at d ≥ 2 now, where the covering/ear grammar (K8, KU15)
  takes over.
