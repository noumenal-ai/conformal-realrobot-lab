# REVIEW: the d = 1 grind (§8 of URS-SI-front-load.md)

Ultraconservative referee pass, async. No literature, no corpus authority, no
deference to REVIEW-SI-front-load.md. A verdict of CONFIRMED means I re-derived the
statement from the definitions below and can exhibit every step; anything I could not
close myself is REFUTED (error located) or GAP (missing step named).

## 0. Definitions in force (the only things assumed)

Ground type `α`; class `𝒜 : Set (Set α)`; windows `A` and label sets `T` finite.

- realizable sample: `IsSample 𝒜 A T := ∃ S ∈ 𝒜, A ∩ S = T` (so `T ⊆ A`, and points
  of `A ∖ T` carry label 0).
- `residual 𝒜 Z W := {S ∈ 𝒜 : Z ∩ S = W}`.
- `SetShatters 𝒜 B := ∀ C ⊆ B, ∃ S ∈ 𝒜, B ∩ S = C`.
- `vcBounded 𝒜 d := ∀ B, SetShatters 𝒜 B → #B ≤ d`. VC 1 = `vcBounded 𝒜 1`.
- convention `ρ : Finset α → Finset α → Set α` (total, improper allowed);
  `IsKernel ρ k A T Z := Z ⊆ A ∧ #Z ≤ k ∧ ρ Z (Z ∩ T) ∩ A = T`;
  `HasKernelScheme 𝒜 k := ∃ ρ, ∀ (A,T) realizable, ∃ Z, IsKernel ρ k A T Z`.

Two facts used throughout, both proved here once.

**(F-mono) Shattering is downward closed.** If `SetShatters 𝒜 B` and `B' ⊆ B`, then
`SetShatters 𝒜 B'`. Proof: for `C ⊆ B'` pick `S` with `B ∩ S = C` (legal, `C ⊆ B`);
then `B' ∩ S = B' ∩ (B ∩ S) = B' ∩ C = C`. ∎
Consequence: `vcBounded 𝒜 1` ⟺ no 2-element set is shattered.

**(F-fiber) The k = 1 scheme, unpacked.** A convention restricted to kernels of size
≤ 1 is exactly a triple of families of sets: `D := ρ ∅ ∅`, `P_p := ρ {p} {p}`
(1-labeled anchor at `p`), `N_p := ρ {p} ∅` (0-labeled anchor at `p`). Then
`HasKernelScheme 𝒜 1` holds iff there exist such `D, (P_p), (N_p)` with: for every
realizable `(A,T)`,
`D ∩ A = T`, or `∃ p ∈ T, P_p ∩ A = T`, or `∃ p ∈ A ∖ T, N_p ∩ A = T`.
Proof: `Z ⊆ A` with `#Z ≤ 1` is `∅` or `{p}`, `p ∈ A`, and then `Z ∩ T = {p}` iff
`p ∈ T`, `= ∅` iff `p ∈ A ∖ T`. ∎
This is the form in which I check every scheme below: a hypothesis may serve a sample
only if it is *consistent* with it (`H ∩ A = T`) **and** *anchored* in it (its index
point lies in `A` with the matching label).

**(F-default) The empty kernel absorbs every all-zero sample.** Setting `D = ∅`,
every realizable `(A, ∅)` is served: `∅ ∩ A = ∅`. Used silently below. More generally
`⋂₀𝒜 ∩ A = ∅` for every realizable `(A,∅)`: the realizer `S₀` satisfies
`⋂₀𝒜 ⊆ S₀` and `S₀ ∩ A = ∅`.

---

## 1. K5: the star class {{x,a},{y,a},{x,y,a}}

**VERDICT: CONFIRMED for the existence claim (k = 1 holds, VC = 1 holds); the printed
routing is INCOMPLETE as a scheme: it covers one window. Repaired below; the repair
is forced only in part, and I say which part.**

Fix `x, y, a` distinct, `α ⊇ {x,y,a}` arbitrary; write `S₁ = {x,a}`, `S₂ = {y,a}`,
`S₃ = {x,y,a}`; `E` denotes points of `α ∖ {x,y,a}` ("extraneous"), which lie in no
member and are therefore always 0-labeled.

### 1.1 VC = 1 (verified, not assumed)

By (F-mono) it suffices to check every 2-element `B`.

- `a ∈ B`: every member contains `a`, so the pattern `∅` is unrealizable on `B`. Not
  shattered.
- `B = {x,y}`: patterns realized are `{x}` (via `S₁`), `{y}` (via `S₂`), `{x,y}` (via
  `S₃`). `∅` is missing. Not shattered.
- `B = {x,e}`, `e ∈ E`: realized `{x}` (S₁, S₃), `∅` (S₂). `{e}` and `{x,e}` missing.
  Not shattered. Symmetrically `B = {y,e}`.
- `B = {e,e'}`: only `∅`. Not shattered.

So no 2-set is shattered, hence `vcBounded 𝒜 1`. It is exactly 1: `{x}` is shattered
(`∅` via `S₂`, `{x}` via `S₁`).

### 1.2 The printed routing is incomplete

The URS routes `T = {x} → ({y},∅) ↦ {x,a}`, `T = {x,y} → ({x},{x}) ↦ {x,y,a}`,
`T = {y} → ({y},{y}) ↦ {y,a}`. Three fibers, and the routing is indexed by the
*label pattern* alone. That is not a scheme, for four independent reasons:

1. **Windows missing the anchor.** `A = {x}`, `T = {x}` is realizable (`A ∩ S₁ = {x}`).
   The prescribed route for `T = {x}` is the kernel `{y}`, but `{y} ⊄ A`. No kernel is
   named for this sample.
2. **All-zero windows.** `A = {e}` (or `A = ∅`), `T = ∅` is realizable (`A ∩ S₁ = ∅`).
   No route is given for `T = ∅` at all; the `(∅,∅)` fiber is never assigned.
3. **Windows containing `a`.** `A = {x,y,a}` has traces `{x,a}`, `{y,a}`, `{x,y,a}`,
   none of which is one of the three printed patterns. `A = {a}` has trace `{a}`.
4. **The pattern-indexed routing is not even well defined as printed**: `T = {x}` occurs
   both on `A = {x,y}` (realizer `S₁`) and on `A = {x}`; the prescribed fiber value
   `{x,a}` happens to be correct for both, but the *kernel* `{y}` is not available on
   the second.

None of this is an error in the K5 *conclusion*; it is an omission in the exhibit. The
conclusion survives, as follows.

### 1.3 A complete convention, and the verification of every realizable sample

```
ρ(∅ , ∅ )  = ∅
ρ({x},{x}) = {x,y,a} = S₃
ρ({x}, ∅ ) = {y,a}   = S₂
ρ({y},{y}) = {y,a}   = S₂
ρ({y}, ∅ ) = {x,a}   = S₁
ρ({a},{a}) = {a}                 (improper: {a} ∉ 𝒜)
everything else       = ∅        (never read)
```

Routing (a total function of the sample, not of the pattern):

| case | kernel `Z` | fiber value | why `ρ ∩ A = T` |
|---|---|---|---|
| `T = ∅` | `∅` | `∅` | `∅ ∩ A = ∅` |
| `y ∈ A`, `y ∉ T` | `{y}` | `S₁` | realizer must be `S₁` (S₂,S₃ ∋ y), so `T = A ∩ S₁` |
| `y ∈ T`, `x ∉ T` | `{y}` | `S₂` | realizer ∈ {S₂,S₃}; `x ∉ T` forces `T = A ∩ S₂` (see below) |
| `x ∈ T`, `y ∈ T` | `{x}` | `S₃` | only `S₃` contains both, so `T = A ∩ S₃` |
| `x ∈ T`, `y ∉ A` | `{x}` | `S₃` | `T = A ∩ S₁ = A ∩ S₃` since `y ∉ A` |
| `x ∈ A`, `x ∉ T`, `T ≠ ∅` | `{x}` | `S₂` | realizer must be `S₂`, so `T = A ∩ S₂` |
| `x,y ∉ A`, `a ∈ A` | `{a}` | `{a}` | all traces equal `A ∩ {a} = {a}` |

Justification of the third row: `y ∈ T` forces the realizer into `{S₂,S₃}`. If the
realizer is `S₃` and `x ∈ A`, then `x ∈ A ∩ S₃ = T`, contradicting `x ∉ T`; if
`x ∉ A` then `A ∩ S₃ = A ∩ S₂`. Either way `T = A ∩ S₂ = S₂ ∩ A`, which is what the
fiber value `S₂` delivers.

Exhaustiveness. Let `(A,T)` be realizable. If `T = ∅`, row 1. Otherwise `T ≠ ∅` and
`T ⊆ A ∩ {x,y,a}`. If `y ∈ A` and `y ∉ T`, row 2. If `y ∈ T`: rows 3 or 4 by whether
`x ∈ T`. If `y ∉ A`: if `x ∈ T` row 5; if `x ∈ A ∖ T` row 6; if `x ∉ A` too, then
`T ⊆ {a}` and `T ≠ ∅` gives `a ∈ A`, row 7. The seven rows are exhaustive and their
fiber demands are pairwise consistent, because in each row the fiber value `H`
satisfies `H ∩ A = T` for *every* sample routed to it (each row's justification is a
statement about all its samples, not about one window).

Fiber-consistency spot checks, i.e. the same fiber under different windows:
`({y},∅) ↦ S₁` receives `A = {x,y}` `T = {x}`; `A = {x,y,a}` `T = {x,a}`;
`A = {y,a}` `T = {a}`; `A = {y}` `T = ∅` (also routable by row 1; overlap is harmless,
pick row 2 or row 1, both give `∅`). In each `S₁ ∩ A = T` ✔.
`({x},{x}) ↦ S₃` receives `A = {x,y}` `T = {x,y}`; `A = {x}` `T = {x}`;
`A = {x,a}` `T = {x,a}`; `A = {x,e}` `T = {x}` ✔.
`({a},{a}) ↦ {a}` receives only windows with `x,y ∉ A`; `{a} ∩ A = {a}` ✔.

Extraneous points are handled uniformly: every fiber value above is a subset of
`{x,y,a}`, hence meets `A` in a subset of `A ∩ {x,y,a}` and never puts a 1-label on a
point of `E`. Windows consisting only of `E` fall into row 1.

Hence `HasKernelScheme 𝒜 1` for the star class. **The K5 conclusion (that the earlier
"k = 1 death" proof was invalid because it ignored 0-labeled kernels) is CONFIRMED**,
and the standing lesson ("kernel case analyses must cover the 0-labeled half") is
correct. What is *not* established by the printed exhibit is the scheme itself.

### 1.4 What was forced and what was free

`ρ({y},∅) = S₁` is forced up to sets meeting every relevant window identically: the
fiber receives all windows with `y ∈ A ∖ T`, and for the family of those windows
(`A ∩ {x,a}` ranging over all four subsets of `{x,a}`) any admissible value must agree
with `S₁` on `{x,a}` and avoid `y` and all of `E`. So `ρ({y},∅) ∈ {S₁}` exactly, once
extraneous points are quantified over. Same for `ρ({x},∅) = S₂`.
`ρ({a},{a})` is free in `{{a}, S₁, S₂, S₃}`: it is only ever read on windows disjoint
from `{x,y}`, where all four agree. `ρ({x},{x})` is forced to `S₃` given the routing
above but is not forced *tout court*: the alternative routing (`T = {x,y}` anchored at
`y` with value `S₃`, `T = {y}` anchored at `x` with label 0) is equally correct. The
alignment freedom is real here; see items 4 and 5.

---

## 2. K6 and the chain theorem

**VERDICT: CONFIRMED for (b) (c) (d) (e). The chain theorem is true as claimed,
dense-safe, minimum-free, and I re-derived both inclusion legs and all four edge cases.
(a) as printed is REFUTED: the exhibited dense-chain witness `{q ≤ θ}` HAS a minimal
member containing any anchor. The phenomenon is real; the corrected witness is the
strict-ray family, supplied below.**

### 2.1 (a) The min-member convention: printed witness is wrong

Printed: "rational thresholds `{q ≤ θ}` have no minimal member containing `x`".

Take `α = ℚ` and `𝒜 = {S_θ : θ ∈ ℚ}` with `S_θ = {q ∈ ℚ : q ≤ θ}`. Fix an anchor
`x ∈ ℚ`. The members containing `x` are exactly `{S_θ : θ ≥ x}`, and `S_x` is one of
them, and `S_x ⊆ S_θ` for every `θ ≥ x`. **`S_x` is the ⊆-minimum member containing
`x`.** The convention "reconstruct the ⊆-minimal member containing the anchor" is
therefore perfectly well defined on this class, and it is even correct on it (it is
the `⋂`-convention, since `⋂{S : x ∈ S} = S_x` here).

The same failure of the witness occurs under the other natural readings: `θ` ranging
over `ℝ` with ground `ℚ` (still `S_x ∈ 𝒜` for `x ∈ ℚ`, still the minimum), and ground
`ℝ` with closed rays `(-∞,θ]` (minimum `(-∞,x]`). Density of the index set is not what
breaks minimality; **half-openness is**.

Corrected witness (verified): `α = ℚ`, `𝒜 = {R_θ : θ ∈ ℚ}` with
`R_θ = {q ∈ ℚ : q < θ}`. This is a ⊆-chain (`θ ≤ θ' ⟹ R_θ ⊆ R_θ'`). Fix `x ∈ ℚ`. The
members containing `x` are `{R_θ : θ > x}`. For any such `θ`, density gives `θ''` with
`x < θ'' < θ`, and then `x ∈ R_θ''` and `R_θ'' ⊊ R_θ` (the point `θ''` itself lies in
`R_θ ∖ R_θ''`). So `{S ∈ 𝒜 : x ∈ S}` has **no** ⊆-minimal element, and the min-member
convention is undefined at every anchor. Note also `⋂{R_θ : θ > x} = {q : q ≤ x}`,
which is **not** a member, so improperness is forced here, exactly as K6 claims.

So: the *claim* of K6 (min-member dies on dense chains; improper `⋂` is forced) is
correct and I confirm it with the corrected witness. The *witness as printed* is a
false statement and must be replaced in the URS (and must not be transcribed into a
Lean instance file, where it would be a false `example`).

### 2.2 (b) `memOrder` totality, bare

Define `a ≼ b :⟺ ∀ S ∈ 𝒜, b ∈ S → a ∈ S`.

Claim: if `𝒜` is a ⊆-chain then `∀ a b : α, a ≼ b ∨ b ≼ a`. No further hypothesis.

Proof. Suppose both fail. `¬(a ≼ b)` gives `S ∈ 𝒜` with `b ∈ S`, `a ∉ S`. `¬(b ≼ a)`
gives `S' ∈ 𝒜` with `a ∈ S'`, `b ∉ S'`. If `S ⊆ S'` then `b ∈ S'`, contradiction; if
`S' ⊆ S` then `a ∈ S`, contradiction. So `S`, `S'` are ⊆-incomparable members, refuting
the chain hypothesis. ∎

Degenerate cases, all checked (this is where a "common member" hypothesis would have
been smuggled in, and it is not needed):

- `a = b`: `a ≼ a` holds by definition (reflexivity), so totality is immediate. The
  proof above also survives: it never assumes `a ≠ b`.
- `a` in no member ("memoryless"): then `b ≼ a` holds **vacuously** (`a ∈ S` is never
  true), so totality holds; and typically `¬(a ≼ b)`, which is fine, since totality is a
  disjunction. The pair is comparable in exactly one direction. No hypothesis that `a`
  and `b` share a member is used anywhere.
- both memoryless: `a ≼ b` and `b ≼ a`, both vacuous. `≼` is a preorder, not a partial
  order; antisymmetry genuinely fails (any two points lying in exactly the same members
  are `≼`-equivalent). Nothing downstream uses antisymmetry.
- `𝒜 = ∅`: every `≼` holds vacuously.

So the URS's "totality needs NO side hypothesis (two witnesses of failure are
⊆-incomparable members)" is CONFIRMED, and its one-line justification is exactly the
proof. Caveat for the Lean statement: totality does need `IsChain (· ⊆ ·) 𝒜`, which
the planned name `memOrder_total_of_isChain` carries.

### 2.3 (c) Transitivity, and reflexivity

`a ≼ b`, `b ≼ c`, `S ∋ c` ⟹ `b ∈ S` ⟹ `a ∈ S`. So `a ≼ c`. Reflexivity is immediate.
Neither uses the chain hypothesis. ∎ CONFIRMED. (`≼` is thus a preorder always, and a
total preorder on chains.)

### 2.4 (d) Finite nonempty `T` has a `≼`-maximum

Claim: if `≼` is total and transitive and `T` is finite nonempty, then `∃ p ∈ T,
∀ t ∈ T, t ≼ p`.

Induction on `#T`. `#T = 1`, `T = {p}`: `p ≼ p`. Step: `T = insert t T'` with `T'`
nonempty; let `m` be a max of `T'`. By totality either `m ≼ t` or `t ≼ m`.
- If `m ≼ t`: for `u ∈ T'`, `u ≼ m ≼ t` gives `u ≼ t` by transitivity; and `t ≼ t`. So
  `t` is a max of `T`.
- Else `t ≼ m`: `m` is a max of `T`. ∎ CONFIRMED.

Note the maximum need not be unique (preorder), and no antisymmetry is used.

### 2.5 (e) The `⋂`-convention is a correct size-1 scheme on chains

Convention: `ρ(Z,W) := ⋂₀ {S ∈ 𝒜 : W ⊆ S}` (a function of `W` alone; total; `⋂₀∅ =
univ` by convention, and I check that branch is never read).

Let `(A,T)` be realizable, witnessed by `S₀ ∈ 𝒜` with `A ∩ S₀ = T`.

**Case `T = ∅`.** Take `Z = ∅`, so `W = Z ∩ T = ∅` and `ρ(∅,∅) = ⋂₀𝒜`. The family is
nonempty (`S₀ ∈ 𝒜`), so `⋂₀𝒜 ⊆ S₀`, hence `⋂₀𝒜 ∩ A ⊆ S₀ ∩ A = T = ∅`. Equality with
`∅` follows. `Z ⊆ A` and `#Z = 0 ≤ 1` ✔. (This is (F-default) with the `⋂₀`
value in place of `∅`; both work.)

**Case `T ≠ ∅`.** By (d) pick `x ∈ T` a `≼`-max of `T`. Take `Z = {x}`; then
`x ∈ T ⊆ A` so `Z ⊆ A`, `#Z = 1 ≤ 1`, and `W = Z ∩ T = {x}`. So
`ρ(Z,W) = ⋂ {S ∈ 𝒜 : x ∈ S} =: M_x`, an intersection over a **nonempty** family
(`x ∈ T = A ∩ S₀ ⟹ x ∈ S₀`), so the `univ` branch is not read.

- `T ⊆ M_x ∩ A`: `T ⊆ A` by realizability. For `t ∈ T`, maximality gives `t ≼ x`, i.e.
  every member containing `x` contains `t`; hence `t ∈ M_x`.
- `M_x ∩ A ⊆ T`: `x ∈ S₀` puts `S₀` in the intersected family, so `M_x ⊆ S₀`, hence
  `M_x ∩ A ⊆ S₀ ∩ A = T`.

Both inclusions ⟹ `M_x ∩ A = T` ⟹ `IsKernel ρ 1 A T {x}`. ∎

**Where each hypothesis is used.** The chain hypothesis is used *only* through (d),
i.e. only to produce a `≼`-max of `T`. The upper-bound leg uses only realizability;
the lower-bound leg uses only maximality. No minimality, no density assumption, no
finiteness of `𝒜`, no `∅ ∈ 𝒜`, no `⊤`. Dense-safe and minimum-free: CONFIRMED.

**Edge cases (all four requested, plus two).**

- `𝒜 = ∅`: `IsSample` is unsatisfiable, so `HasKernelScheme 𝒜 k` holds vacuously for
  every `k` (including `0`). `∅` is a chain vacuously. The convention returns
  `⋂₀∅ = univ` on every fiber and is never read. Consistent, but note the Lean
  statement is *trivially* true here; non-vacuity of `hasKernelScheme_one_of_isChain`
  must come from the nonempty instances, see item 6.
- `𝒜 = {∅}`: chain. Only `T = ∅` is realizable; `ρ(∅,∅) = ⋂₀{∅} = ∅`; `∅ ∩ A = ∅` ✔.
- `x` lies in no member other than the realizer `S₀`: then `M_x = S₀` and
  `M_x ∩ A = T` directly. No degeneracy.
- `⊤ = univ ∈ 𝒜`: a chain may contain `univ` (it is comparable with everything). It
  never affects `M_x` (it is a superset, so it drops out of the intersection), and for
  `T = ∅` the argument only needs `⋂₀𝒜 ⊆ S₀`. If `A ≠ ∅`, `T = A` is realizable via
  `univ`, its `≼`-max `x` gives `M_x ∩ A = T` by the same two legs. ✔
- chain without `∅`: the `T = ∅` case still goes through, since it needs a realizer, not a
  least member. E.g. `𝒜 = {[a,∞) : a ∈ ℝ}`, `A = {0}`, `T = ∅` realized by `[1,∞)`;
  `⋂₀𝒜 = ∅` here anyway.
- dense chain (2.1's corrected witness): `M_x = {q ≤ x} ∉ 𝒜`. Improper, correct,
  and the two legs are unaffected. This is the case that kills min-member and that the
  `⋂`-convention survives: K6's actual content, CONFIRMED.

**Also verified (needed for the companion Lean statement).** A ⊆-chain has VC ≤ 1: if
`{p,q}` (`p ≠ q`) were shattered there would be `S` with `{p,q} ∩ S = {p}` and `S'`
with `{p,q} ∩ S' = {q}`; then `p ∈ S ∖ S'` and `q ∈ S' ∖ S`, so `S`, `S'` are
incomparable. With (F-mono) no set of size ≥ 2 is shattered, so `vcBounded 𝒜 1`. ∎

---

## 3. The splitting law

**VERDICT: CONFIRMED. The four-pattern assembly is exact and hits `#B = 2` against
`vcBounded 𝒜 1`, with no off-by-one. One A4 note: the hypothesis `x ≠ y` is
decorative: the statement is true without it.**

Statement under review: `vcBounded 𝒜 1` → for `x ≠ y`, not both `residual 𝒜 {x} ∅`
and `residual 𝒜 {x} {x}` shatter `{y}`.

### 3.1 Unfolding

`residual 𝒜 {x} ∅ = {S ∈ 𝒜 : {x} ∩ S = ∅} = {S ∈ 𝒜 : x ∉ S}` (call it `𝒜₀`);
`residual 𝒜 {x} {x} = {S ∈ 𝒜 : {x} ∩ S = {x}} = {S ∈ 𝒜 : x ∈ S}` (call it `𝒜₁`).
`SetShatters ℬ {y}` unfolds to: `∃ S ∈ ℬ, {y} ∩ S = ∅` **and** `∃ S ∈ ℬ, {y} ∩ S =
{y}`, i.e. some member of `ℬ` misses `y` and some member of `ℬ` contains `y` (the two
subsets `C ⊆ {y}` are `∅` and `{y}`; there are no others).

### 3.2 The assembly

Assume both shatter `{y}`. Extract four members of `𝒜`:

| name | from | `x` | `y` |
|---|---|---|---|
| `S₀₀` | `𝒜₀` shatters `{y}`, pattern `∅` | ∉ | ∉ |
| `S₀₁` | `𝒜₀` shatters `{y}`, pattern `{y}` | ∉ | ∈ |
| `S₁₀` | `𝒜₁` shatters `{y}`, pattern `∅` | ∈ | ∉ |
| `S₁₁` | `𝒜₁` shatters `{y}`, pattern `{y}` | ∈ | ∈ |

Put `B = {x,y}`. For each `C ⊆ B` the corresponding row gives `S` with `B ∩ S = C`:
`B ∩ S₀₀ = ∅`, `B ∩ S₀₁ = {y}`, `B ∩ S₁₀ = {x}`, `B ∩ S₁₁ = {x,y}`, and each is exact,
since membership of `x` and of `y` in `S` is precisely what the table records and `B`
has no other elements. Hence `SetShatters 𝒜 {x,y}`. Since `x ≠ y`, `#B = 2`, and
`vcBounded 𝒜 1` gives `2 ≤ 1`, false. ∎ CONFIRMED.

### 3.3 Off-by-one check

`vcBounded 𝒜 d := ∀ B, SetShatters 𝒜 B → #B ≤ d` with `d = 1`. Singletons are
harmless: `SetShatters 𝒜 {y}` yields `1 ≤ 1` ✔, so the law can be violated only at
`#B = 2`, which is exactly what the assembly produces. There is no version of this in
which a shattered singleton already contradicts the hypothesis, i.e. the law is not
vacuously true by an off-by-one in the VC definition. Non-vacuity is real: for
`𝒜 = {∅,{y}}` and any `x` in no member, `𝒜₀ = 𝒜` **does** shatter `{y}` while
`𝒜₁ = ∅` shatters nothing (`SetShatters ∅ B` fails even for `B = ∅`, since it demands
a member). So "at most one residual" is attained, not vacuous.

### 3.4 `x ≠ y` is decorative

If `x = y`: `𝒜₀` consists of members missing `x`, so it cannot realize the pattern
`{x}` on `{x}`; `𝒜₁` consists of members containing `x`, so it cannot realize `∅`.
Neither residual shatters `{x}`, so "not both" holds, with no VC hypothesis at all.
Hence the statement is true for all `x, y` and `hxy : x ≠ y` may be dropped from
`singleton_shatters_at_most_one_residual` (the proof then splits: `x = y` by the above,
`x ≠ y` by 3.2). Keeping it is not an error, but by A4 it is a hypothesis that does no
work in the theorem, only in one branch of the proof. Flagged in item 6.

---

## 4. The crossing probe 𝒜 = {∅, {x,u}, {y,u}}

**VERDICT: CONFIRMED that a k = 1 scheme exists. I construct a complete one, and a
second inequivalent one. The URS's account of *why* it exists is corrected: 0-labeled
kernels are NOT what saves it (my primary scheme uses none). What is forced is
improperness at the `u`-anchor whenever that anchor serves a window containing `x` or
`y`, and a genuine binary choice on the window `{u}`.**

`x, y, u` distinct; `E` = points outside `{x,y,u}` (in no member).

### 4.1 VC = 1 (verified)

By (F-mono), check pairs.
- `{x,y}`: realized `∅` (via `∅`), `{x}` (via `{x,u}`), `{y}` (via `{y,u}`); `{x,y}`
  needs a member containing both, and there is none. Not shattered.
- `{x,u}`: realized `∅`, `{x,u}`, `{u}` (via `{y,u}`); `{x}` needs a member with `x`
  and without `u`, and there is none. Not shattered. Symmetrically `{y,u}`.
- `{x,e}`: realized `∅`, `{x}`; `{e}` unrealizable. Not shattered. Same for `{y,e}`,
  `{u,e}`, `{e,e'}`.
So `vcBounded 𝒜 1`, and `{x}` is shattered (`∅` via `∅`, `{x}` via `{x,u}`), so VC = 1.

### 4.2 Traces

For a window `A`, the three traces are `∅`, `A ∩ {x,u}`, `A ∩ {y,u}`. Consequences used
below: `x ∈ T ⟹ T = A ∩ {x,u}` (only `{x,u}` contains `x`); `y ∈ T ⟹ T = A ∩ {y,u}`;
`x` and `y` are never both in `T`; and `T = {u}` is realizable only when `x ∉ A` or
`y ∉ A` (on `A ⊇ {x,y,u}` the traces are `∅`, `{x,u}`, `{y,u}`, none equal to `{u}`).

### 4.3 Scheme I (complete; no 0-labeled kernel)

```
ρ(∅ , ∅ )  = ∅
ρ({x},{x}) = {x,u}
ρ({y},{y}) = {y,u}
ρ({u},{u}) = {u}          (improper: {u} ∉ 𝒜)
all other fibers = ∅      (never read)
```

Routing and verification, for realizable `(A,T)`:

1. `T = ∅` → `Z = ∅`: `∅ ∩ A = ∅` ✔.
2. `x ∈ T` → `Z = {x}` (`x ∈ T ⊆ A`, `W = {x}`): `T = A ∩ {x,u}` by 4.2, and the fiber
   value is `{x,u}`, so `ρ ∩ A = {x,u} ∩ A = T` ✔.
3. `y ∈ T` → `Z = {y}`, symmetric ✔.
4. `T ≠ ∅`, `x ∉ T`, `y ∉ T` → `T ⊆ {u}` and `T ≠ ∅`, so `T = {u}` and `u ∈ A`. Take
   `Z = {u}`, `W = {u}`: `{u} ∩ A = {u} = T` ✔ for **every** such window, whatever `A`
   is. This is the case the URS previously called incoherent (windows containing both
   `x` and `u` with `T = {u}`): it is resolved by an improper value, with no
   0-labeled kernel and no case split.

Cases 1–4 are exhaustive and mutually consistent (2 and 3 cannot co-occur), and each
fiber's value is correct for all samples routed to it. Hence `HasKernelScheme 𝒜 1`.

### 4.4 Scheme II (complete; uses 0-labeled kernels, the URS's route)

```
ρ(∅ , ∅ )  = ∅ ;  ρ({x},{x}) = {x,u} ;  ρ({y},{y}) = {y,u}
ρ({x}, ∅ ) = {y,u} ;  ρ({y}, ∅ ) = {x,u} ;  ρ({u},{u}) = {x,u}
```
Routing: `T = ∅` → `Z = ∅`; `x ∈ T` → `({x},{x})`; `y ∈ T` → `({y},{y})`;
`T = {u}` with `y ∈ A` → `({y},∅) ↦ {x,u}` (then `x ∉ A` by 4.2, so
`{x,u} ∩ A = {u}` ✔); `T = {u}` with `x ∈ A` → `({x},∅) ↦ {y,u}` (then `y ∉ A`, so
`{y,u} ∩ A = {u}` ✔); `T = {u}` with `x,y ∉ A` → `({u},{u}) ↦ {x,u}`, and
`{x,u} ∩ A = {u}` ✔ because `x ∉ A`. Fiber `({x},∅)` receives only `T ≠ ∅` samples
(all-zero ones go to the default), so its value `{y,u}` is never contradicted.
Both schemes are correct; they are not related by relabeling.

### 4.5 Forced vs free: the calibration the item asks for

Forced:

- **On the window `A = {u}`** both `T = ∅` and `T = {u}` are realizable (via `∅` and
  via `{x,u}`), and the only kernels available are `∅` and `{u}`. The fiber `(∅,∅)`
  cannot serve both. So *at least one* of the two samples must be served by a
  `u`-anchor: either `({u},∅)` for the all-zero sample or `({u},{u})` for `T = {u}`.
  A `k = 1` scheme cannot route both through the default. (This is a genuine forcing,
  and it survives the addition of extraneous points, since `E` may be empty.)
- **If the fiber `({u},{u})` serves any window containing `x`** (i.e. some `A ⊇ {x,u}`
  with `T = {u}`, which is realizable when `y ∉ A`), then its value `H` must satisfy
  `H ∩ A = {u}`, so `x ∉ H`; symmetrically serving a window containing `y` forces
  `y ∉ H`. Serving both forces `H ∩ {x,y} = ∅`, and since `H ∋ u`, `H` is **not a
  member** of `𝒜`. So improper reconstruction is forced for scheme I's routing;
  properness is recoverable only by moving those windows to 0-labeled anchors
  (scheme II). Improperness and 0-labeled kernels are *alternative* repairs.
- The values `ρ({x},{x})` and `ρ({y},{y})`, if used at all, must agree with `{x,u}`
  resp. `{y,u}` on `{x,y,u}` and avoid all of `E` (quantify over windows
  `A = {x,u,y}`, `{x,u}`, `{x}`, `{x,e}`), so they are pinned to the member.

Free:

- Which of the two samples on `{u}` takes the `u`-anchor (both completions extend to
  full schemes: scheme I takes `T = {u}`; the mirror image sets `ρ(∅,∅) = {u}` and
  routes all-zero windows containing `u` to `({u},∅) ↦ ∅`, which is also consistent;
  note `(A,T) = (∅,∅)` forces the `(∅,∅)` fiber to be *used*, but with `A = ∅` any
  value is correct, so this does not obstruct).
- Whether `T = {u}` on `x`-containing windows is anchored at `u` (improperly) or at
  `x` with label 0 (properly).
- In scheme II, `ρ({u},{u})` may be `{x,u}` or `{y,u}` or `{u}`.

So the "alignment" freedom at `d = 1` is real and not a bookkeeping artifact: the
crossing probe admits at least two structurally different correct routings, and the
choice is not determined by any ⊆-canonical datum (the two minimal members containing
`u` are incomparable, exactly as the URS says). The URS's *claim* about the probe is
CONFIRMED; its *explanation* ("via x/y-anchors and 0-labeled kernels") names only one
of the two repairs and misses that improperness alone suffices.

---

## 5. KU14: the adversarial hunt, and its outcome

**VERDICT: CONFIRMED, and stronger than the URS asks. There is no VC-1 counterexample,
because `k = 1` is UNIVERSAL at VC dimension 1. I give a complete proof below. KU14 is
resolved positively; `CalibrationVCOne` (kernel size 3) follows a fortiori; the C-IV
boundary declaration ("full CalibrationVCOne stays OPEN") is obsolete.**

The hunt failed in an informative way: every family I built collapsed under the same
structural fact, which I then isolated and turned into the theorem. I record the
theorem first, then the probe families and why each dies.

### 5.1 Two preliminary lemmas

**Lemma A (label twists preserve everything).** Fix `S₀ ⊆ α` and put
`𝒜 Δ S₀ := {S Δ S₀ : S ∈ 𝒜}`. Then
(i) `B` is shattered by `𝒜` iff it is shattered by `𝒜 Δ S₀`;
(ii) `(A,T)` is realizable for `𝒜` iff `(A, T Δ (A ∩ S₀))` is realizable for `𝒜 Δ S₀`;
(iii) `HasKernelScheme (𝒜 Δ S₀) k → HasKernelScheme 𝒜 k`, with the *same* kernels.

Proof. (i) `B ∩ (S Δ S₀) = (B ∩ S) Δ (B ∩ S₀)` and `C ↦ C Δ (B ∩ S₀)` is an involution
of the subsets of `B`; so the pattern sets correspond bijectively.
(ii) `(S Δ S₀) ∩ A = (S ∩ A) Δ (S₀ ∩ A)`; take `S` the realizer.
(iii) Let `ρ'` be a convention for `ℬ := 𝒜 Δ S₀`. Define
`ρ(Z,W) := ρ'(Z, W Δ (Z ∩ S₀)) Δ S₀`. Let `(A,T)` be realizable for `𝒜`, put
`T' := T Δ (A ∩ S₀)`, realizable for `ℬ` by (ii). Take `Z ⊆ A`, `#Z ≤ k`, with
`ρ'(Z, Z ∩ T') ∩ A = T'`. Since `Z ⊆ A`,
`Z ∩ T' = Z ∩ (T Δ (A ∩ S₀)) = (Z ∩ T) Δ (Z ∩ S₀)`, hence
`ρ(Z, Z ∩ T) = ρ'(Z, Z ∩ T') Δ S₀` and
`ρ(Z,Z∩T) ∩ A = (ρ'(Z,Z∩T') ∩ A) Δ (S₀ ∩ A) = T' Δ (A ∩ S₀) = T`. ∎

**Lemma B (VC 1 with `∅` in the class is a forest).** Let `vcBounded ℬ 1` and `∅ ∈ ℬ`.
Define `x ≼ y :⟺ ∀ R ∈ ℬ, y ∈ R → x ∈ R`. Then for all `x, y` lying in a common member
of `ℬ`, `x ≼ y` or `y ≼ x`.

Proof. If `x = y` this is reflexivity. Let `x ≠ y`, `R ∈ ℬ` with `x, y ∈ R`, and
suppose both fail: `R₁ ∈ ℬ` with `y ∈ R₁`, `x ∉ R₁`; `R₂ ∈ ℬ` with `x ∈ R₂`,
`y ∉ R₂`. Then on `B = {x,y}`: `B ∩ ∅ = ∅`, `B ∩ R₂ = {x}`, `B ∩ R₁ = {y}`,
`B ∩ R = {x,y}`, all four patterns, so `SetShatters ℬ {x,y}` and `2 ≤ 1`. ∎

(Corollaries, not needed below but they are the structure: every member of `ℬ` is a
`≼`-chain, and every member is `≼`-downward closed, so `ℬ` is a family of root-paths of
the forest preorder `≼`. This is the exact sense in which "VC 1 = trees", derived here,
not imported.)

### 5.2 The theorem

**Theorem (d = 1 universality).** For every type `α` and every `𝒜 : Set (Set α)` with
`vcBounded 𝒜 1`: `HasKernelScheme 𝒜 1`. No finiteness of `α` or `𝒜`, no `∅ ∈ 𝒜`, no
`⊤ ∈ 𝒜`, no chain hypothesis.

Proof. If `𝒜 = ∅` there are no realizable samples and any convention works. Otherwise
fix `S₀ ∈ 𝒜` and put `ℬ := 𝒜 Δ S₀`, so `∅ = S₀ Δ S₀ ∈ ℬ` and `vcBounded ℬ 1` by
Lemma A(i). By Lemma A(iii) it suffices to give a size-1 scheme for `ℬ`. Take
```
ρ'(Z, W) := ⋂₀ {R ∈ ℬ : W ⊆ R}        (the interConvention, unchanged)
```
Let `(A, T')` be realizable for `ℬ`, with realizer `R₀ ∈ ℬ`, `A ∩ R₀ = T'`.

*Case `T' = ∅`.* Take `Z = ∅`. Then `ρ'(∅,∅) = ⋂₀ℬ = ∅` because `∅ ∈ ℬ`, and
`∅ ∩ A = ∅ = T'`. ✔

*Case `T' ≠ ∅`.* All elements of `T'` lie in the common member `R₀`, so by Lemma B they
are pairwise `≼`-comparable; `T'` is finite and nonempty, so by the induction of §2.4
it has a `≼`-maximum `p ∈ T'`. Take `Z = {p}`: `p ∈ T' ⊆ A` so `Z ⊆ A`, `#Z = 1`, and
`W = Z ∩ T' = {p}`, so `ρ'(Z,W) = ⋂ {R ∈ ℬ : p ∈ R} =: H_p` (a nonempty intersection,
as `p ∈ R₀`).
- `T' ⊆ H_p ∩ A`: `T' ⊆ A`; and for `t ∈ T'`, maximality gives `t ≼ p`, i.e. every
  member containing `p` contains `t`, so `t ∈ H_p`.
- `H_p ∩ A ⊆ T'`: `p ∈ R₀` puts `R₀` in the family, so `H_p ⊆ R₀` and
  `H_p ∩ A ⊆ R₀ ∩ A = T'`.
So `ρ'(Z, Z ∩ T') ∩ A = T'` and `IsKernel ρ' 1 A T' {p}`. ∎

**The convention on `𝒜` in closed form** (no twist wrapper needed in Lean). Unfolding
Lemma A(iii) with `ℱ_{(Z,W)} := {S ∈ 𝒜 : W Δ (Z ∩ S₀) ⊆ S Δ S₀}`, the reconstruction
is
```
ρ(Z,W) = (S₀ ∩ ⋃ ℱ) ∪ (⋂ ℱ ∖ S₀)
```
i.e. *follow `S₀` wherever the surviving family is not unanimous against it, and follow
the family wherever it is*. For the useful fibers: `ρ(∅,∅) = S₀`; for `p ∉ S₀`,
`ρ({p},{p})` is built from `ℱ = {S ∈ 𝒜 : p ∈ S}`; for `p ∈ S₀`, `ρ({p},∅)` is built
from `ℱ = {S ∈ 𝒜 : p ∉ S}`. Checked against §1: with `S₀ = {x,a}` in the star class and
`p = y`, `ℱ = {{y,a},{x,y,a}}`, `⋃ℱ = {x,y,a}`, `⋂ℱ = {y,a}`, giving
`ρ({y},{y}) = {x,a} ∪ {y} = {x,y,a}`, a correct anchor value for `(A,T) =
({x,y},{x,y})`, matching §1.4's remark that anchoring `T = {x,y}` at `y` is equally
valid. Note this convention *does* depend on `Z` and not on `W` alone; see item 6.

**Optimality.** `k = 1` cannot be improved to `k = 0`: for `𝒜 = {∅,{p}}` (VC 1) the
window `A = {p}` carries the two realizable samples `T = ∅` and `T = {p}`, both of
which a size-0 scheme must serve from the single fiber `(∅,∅)`, forcing
`ρ(∅,∅) ∩ A` to take two values. So the answer to KU14 is exactly `k = 1`.

**Machine corroboration (not the authority; the proof above is).** I enumerated every
nonempty class over a 4-point ground with no shattered pair (1944 of them), and for each
one twisted by a base member, computed `≼`, and checked the construction on **every**
window and **every** realizer: 62039 nonempty-label samples, zero failures, and in every
case *all* `≼`-maxima of the label set work, not merely one. Randomized sweeps at
`N = 6` (8934 VC-1 classes, 608962 samples) and `N = 8` (8129 classes, 2207740 samples),
with the base member drawn at random rather than fixed, also gave zero failures. The
same script confirms §6.3: on the star class the three fibers available to
`(A,T) = ({x,y},{x,y})` under `interConvention` meet `A` in `∅`, `{x}`, `{y}`.

**Consequences for the shipped statements.**
- `CalibrationVCOne` (`vcBounded 𝒜 1 → HasKernelScheme 𝒜 3`) is now a corollary:
  `#Z ≤ 1 → #Z ≤ 3`. It is provable this tick, not a conjecture root.
- `hasKernelScheme_one_of_isChain` is a corollary too (chains are VC 1, §2.5), though
  the direct chain proof is shorter and worth keeping as the lemma that carries the
  `⋂`-convention.
- price 1 at `k = 1` for every VC-1 class, via the shipped `hasIndexedScheme_one_iff`.
- KU1's "one kernel point per crossed direction, `f = d`" survives at `d = 1` with the
  constant exactly 1, and the mechanism now has a name that is not "alignment": *twist
  to a base member, then anchor at the `≼`-maximum of the twisted label set*. At
  `d = 1` the alignment structure D9 was groping for is fully explicit: a preorder
  induced by containment, made total on each member by the absence of a shattered pair.

### 5.3 The probe families, and why each fails to be a counterexample

Each was attempted before the theorem was found; each is now explained by it.

1. **Many pairwise-crossing members with a common core.** `α = C ⊔ P`,
   `𝒜 = {C ∪ {p} : p ∈ P}`, `|P| ≥ 3`. VC 1: a pair inside `P` misses the all-1
   pattern; a pair meeting `C` misses the all-0 pattern. Twisting by `C ∪ {p₀}` gives
   `ℬ = {∅} ∪ {{p₀,p} : p ≠ p₀}`, a depth-2 forest with `p₀` at the root; anchor at the
   deep point. `k = 1`. The "crossing" was an artifact of the base point: all crossings
   are simultaneously undone by one twist.
2. **Infinite ground, no `∅`, no `⊤`.** E.g. `𝒜 = {[a,∞) : a ∈ ℝ}` (chain, no empty
   member, no `univ`), or the star over an infinite ground, or the strict-ray dense
   chain of §2.1. Absence of `∅` is not an obstruction *at all*: the twist manufactures
   it, and Lemma A(iii) transports the scheme back. This probe family cannot work in
   principle.
3. **Two dense chains crossing.** The natural instance (left rays `{q < θ}` together
   with right rays `{q > s}` over `ℚ`) is **not admissible**: for `x < y` the four
   patterns on `{x,y}` are realized (`∅` by a low left ray, `{x}` by a middle left ray,
   `{y}` by a middle right ray, `{x,y}` by a low right ray), so its VC dimension is 2.
   Generally, if `S₁`, `S₂` are ⊆-incomparable with witnesses `x ∈ S₁ ∖ S₂`,
   `y ∈ S₂ ∖ S₁`, then `{x},{y}` are realized on `{x,y}`, so VC 1 forces *no member to
   contain both `x` and `y`* or *no member to avoid both*. Crossing is therefore never
   free; it is exactly the forest branching of Lemma B (after a twist). A genuinely
   VC-1 "two crossing dense chains" instance is the disjoint-ground union
   `{ {q < θ} ⊆ ℚ×{0} } ∪ { {q < θ} ⊆ ℚ×{1} }` (no `∅`, no `⊤`, every pair of members
   from different sides incomparable). I checked it by hand: twist by one member, the
   `≼`-max anchor gives `H_p ∩ A = T` with `H_p` improper (an intersection of a
   strictly decreasing family), `k = 1`.
4. **Every point's containing-members and avoiding-members both large.** Dense chains
   have this property already (each `x` has a continuum of members on both sides) and
   are `k = 1`. The property is invisible to the mechanism: the anchor value `H_p` is
   an intersection over the whole containing family, however large, and the two
   inclusion legs never count members.
5. **My own earlier candidate: iterate the star.** `𝒜 = {A_i ∪ {c}}` with the `A_i`
   pairwise crossing and `c` common, same as (1). And "star of stars" constructions
   fail VC 1 as soon as two branch points co-occur with two incomparable leaves.

**The obstruction that would have been needed, and why it cannot exist.** By (F-fiber),
a failure at `k = 1` requires a family of realizable samples that cannot be
consistently distributed over the fibers `{(∅,∅)} ∪ {({p},ε)}`, i.e. a set of samples
pairwise incompatible (disagreeing on a shared point) such that every one of them has
all of its admissible anchors already claimed. The theorem shows the anchor map
`(A,T) ↦ ` (`≼`-max of the twisted label set) is always available and always
conflict-free, because the fiber value `H_p` is defined *without reference to the
window* and is correct for every sample it receives. Any impossibility argument by
fiber counting is therefore dead at `d = 1`: it would have to contradict an explicit
construction.

**Warning for `d ≥ 2` (the reason this does not immediately generalize).** Lemma B is a
`d = 1` phenomenon: it needs the all-0 pattern (from `∅ ∈ ℬ`) plus a shattered pair to
be *forbidden*. At `d = 2` the analogous statement would need a forbidden shattered
triple, and the two "missing patterns" no longer force comparability of the label set:
a label set need not be a chain, so there is no canonical anchor. The twist trick
survives (Lemma A is dimension-free); the ordering does not. This is a real boundary,
and the URS should not read the `d = 1` result as evidence for T2 beyond calibration.

---

## 6. A4 audit of §8

**VERDICT: GAP. The section's claims are true but two of its exhibits are not, one
planned definition cannot carry the load its docstring will imply, and one planned
statement carries a hypothesis that does no work. Five items, each actionable.**

### 6.1 Decorative hypotheses

- `memOrder_total_of_isChain`: **clean**. Totality genuinely needs no common-member
  hypothesis (§2.2), and the degenerate cases (`a = b`, memoryless points, `𝒜 = ∅`)
  are handled by the same two-line argument rather than by side conditions. The URS's
  self-assessment (no decorative hypotheses; totality holds bare) is CONFIRMED.
  `IsChain` itself is load-bearing (drop it and totality is false: `𝒜 = {{x},{y}}`
  makes `x`, `y` `≼`-incomparable).
- `singleton_shatters_at_most_one_residual`: **`x ≠ y` is decorative** (§3.4). The
  statement holds for `x = y` too, for a different and shorter reason. Either drop the
  hypothesis and case-split in the proof, or keep it and record in the docstring that
  it is a proof convenience, not a truth condition.
- `hasKernelScheme_one_of_isChain`: `IsChain` is load-bearing for *this proof*, but it
  is no longer the natural hypothesis: §5.2 proves the conclusion from `vcBounded 𝒜 1`,
  which is strictly weaker (chains are VC 1; VC-1 classes need not be chains). Not a
  defect, but the file should state the general theorem and derive the chain case, or
  say explicitly why it keeps the special case (the `⋂`-convention is genuinely simpler
  and twist-free).
- Do **not** add `∅ ∈ 𝒜` or "𝒜 nonempty" to the chain theorem: §2.5's `T = ∅` branch
  needs only the realizer. Adding it would be decorative and would also hide the one
  place where realizability is doing work.

### 6.2 Vacuity risks in the planned Lean statements

The grammar has three vacuity sinks, all reachable:

1. `IsSample 𝒜 A T` requires `∃ S ∈ 𝒜`, so **`HasKernelScheme ∅ k` is true for every
   `k`, including `k = 0`**. Any theorem of the form `hyp → HasKernelScheme 𝒜 1` is
   trivially true on `𝒜 = ∅`, and `IsChain` and `vcBounded _ 1` both hold there.
2. `SetShatters ℬ B` requires a member for every pattern, so **the empty class shatters
   nothing, not even `∅`**. Every statement of the form "… does not shatter …" is free
   whenever the residual is empty, and `residual 𝒜 {x} {x} = ∅` exactly when `x` is in
   no member, `residual 𝒜 {x} ∅ = ∅` exactly when `x` is in every member. So the
   splitting law is automatic on both degenerate anchors.
3. `vcBounded 𝒜 d` quantifies over shattered sets only, so a class that shatters
   nothing satisfies every VC bound.

Consequently the three planned statements are individually fine but **need paired
non-vacuity witnesses in `Instances.lean`**, or the audit trail is empty:

- `vcBounded_one_of_isChain`. Witness: the dense strict-ray chain of §2.1, or the
  finite chain `{∅,{x},{x,y}}`, together with a `decide`-checked *shattered singleton*
  (`SetShatters 𝒜 {x}`), which shows the bound 1 is attained and not vacuous.
- `hasKernelScheme_one_of_isChain`. Witness: a chain with at least two distinct
  realizable samples on one window (e.g. `𝒜 = {∅,{x}}`, `A = {x}`, `T ∈ {∅,{x}}`),
  which also witnesses that `k = 0` is impossible (§5.2 optimality), so the `1` is not
  slack.
- `singleton_shatters_at_most_one_residual`. Witness with **both residuals nonempty**
  and one of them shattering: `𝒜 = {∅,{x},{y}}` gives `residual 𝒜 {x} ∅ = {∅,{y}}`
  (shatters `{y}`) and `residual 𝒜 {x} {x} = {{x}}` (does not). Without such an
  instance the theorem is indistinguishable from the vacuous reading in sink 2.

One further proof-obligation, easy to skip and not derivable by `simp`:
`vcBounded_one_of_isChain` needs **subset-monotonicity of `SetShatters`** ((F-mono):
`SetShatters 𝒜 B → B' ⊆ B → SetShatters 𝒜 B'`) to get from "no 2-element set is
shattered" to "every shattered set has `#B ≤ 1`". I do not find that lemma in
`Scheme.lean`; it must be added (it is three lines, and it is used again in §3, §5).

### 6.3 `interConvention` as a single formula: the fiber-discipline question

`interConvention Z W := ⋂₀ {S ∈ 𝒜 : W ⊆ S}` reads `W` only.

**Which fibers can collide across windows.** Two samples `(A,T)`, `(A',T')` land in the
same fiber iff they use the same `Z` and `Z ∩ T = Z ∩ T'`. At `k = 1`:
- `Z = ∅` is a *single global fiber* `(∅,∅)` shared by every sample routed to the
  default, across all windows. Any two such samples must be compatible
  (`T ∩ A' = T' ∩ A`), and in fact all of them must satisfy `T = ρ(∅,∅) ∩ A` for one
  fixed set.
- `Z = {p}` gives two fibers per point, `({p},{p})` and `({p},∅)`, each shared by every
  window containing `p` with the matching label on `p`. Windows not containing `p`
  cannot collide there. So the collision structure is exactly "same anchor point, same
  anchor label", and window size, extraneous points, and the identity of the realizer
  are all invisible to it. This is why every scheme in this review is verified fiber by
  fiber, never window by window.

**Does the `W = ∅` branch misbehave?** No, and the reason is general, not chain-specific:
whenever `(A,∅)` is realizable with realizer `S₀`, `⋂₀𝒜 ⊆ S₀` gives
`⋂₀𝒜 ∩ A ⊆ S₀ ∩ A = ∅`. So the `W = ∅` value is correct for *every* all-zero sample in
*every* class. Nothing is silently wrong there.

**But the formula collapses the whole 0-labeled half of the alphabet.** Because it
ignores `Z`, `interConvention {p} ∅ = interConvention ∅ ∅ = ⋂₀𝒜` for every `p`: all
0-labeled anchors carry the same value as the default. The chain scheme never notices,
because its routing uses only `Z = ∅` (for `T = ∅`) and 1-labeled anchors. The
consequence is sharp and should be in the docstring:

> `interConvention` is **not** a general VC-1 convention. On the star class
> `{{x,a},{y,a},{x,y,a}}` its values are `ρ(·,∅) = {a}`, `ρ(·,{x}) = {x,a}`,
> `ρ(·,{y}) = {y,a}`. The realizable sample `A = {x,y}`, `T = {x,y}` has
> `A ∖ T = ∅`, so only the fibers `(∅,∅)`, `({x},{x})`, `({y},{y})` are available, with
> values meeting `A` in `∅`, `{x}`, `{y}` respectively, none equal to `T`. So
> `interConvention` admits **no** size-1 kernel for that sample, although a size-1
> scheme exists (§1.3).

That is a proof, not a caution: a `W`-only convention cannot be the general `d = 1`
reconstruction, and the general convention of §5.2 genuinely depends on `Z` (through
`Z ∩ S₀`). If `VCOne.lean` states `interConvention` with a docstring implying it is
"the" reconstruction for VC-1, that is an overclaim (A4). Its correct scope is: classes
containing `∅` (where the general theorem's twist is the identity), of which chains
with a least member are one case, and where `⋂₀𝒜 = ∅` makes the default branch
degenerate to `(F-default)`.

### 6.4 Exhibits that do not support their claims

- **K6's dense-chain witness is a false statement** (§2.1): `{q ≤ θ}` has a ⊆-minimum
  member containing any rational anchor. Must be replaced by the strict-ray family
  before it reaches an `example` in `Instances.lean`, where it would fail to compile as
  stated or, worse, compile as an unrelated true statement.
- **K5's routing is not a scheme** (§1.2): three fibers, one window, no `T = ∅` case, no
  `a`-containing windows, and one route (`T = {x} → ({y},∅)`) that is unavailable on the
  window `A = {x}`. The K5 *conclusion* and its *lesson* stand; the exhibit needs §1.3.
- Minor: "k = 2 composite kernels trivialize it" (crossing probe) is true but
  uninformative, since `HasKernelScheme` is monotone in `k` and the class is `k = 1`.
- Minor: C-IV's declared boundary ("full `CalibrationVCOne` stays OPEN this tick …
  attacking it before the reviewer rules on KU14 would fix the alignment grammar
  prematurely") is now obsolete: §5.2 proves it, and the proof fixes no alignment
  grammar: it uses a twist and a preorder, both of which are `d = 1` specific and
  neither of which commits D9 (see the `d ≥ 2` warning in §5.2).

### 6.5 What the section got right (recorded so the audit is not one-sided)

The three load-bearing mathematical claims of §8 (the star has a size-1 scheme, the
`⋂`-convention at a `≼`-max anchor is correct on arbitrary chains including dense ones,
and no `y` is singleton-shattered in both residuals of `x` at VC 1) are all true, and
I re-derived each from the definitions. The attribution of the two inclusion legs
("upper bound via the realizing member, lower bound via maximality") is exactly right.
The K5 lesson (0-labeled kernels belong in every case analysis) is the correct
generalization of its own failure, and it is what made the `d = 1` question answerable.

---

## 7. Summary

| # | item | verdict | substance |
|---|---|---|---|
| 1 | K5, star class `{{x,a},{y,a},{x,y,a}}` | **CONFIRMED** (existence); exhibit incomplete, repaired | VC = 1 verified on every pair. `k = 1` holds: complete 7-fiber convention + total routing given in §1.3, checked on every window shape (missing `x`/`y`/`a`, extraneous points, all-zero). The printed 3-line routing is not a scheme (no `T = ∅`, no `a`-windows, and `T = {x}` on `A = {x}` has no kernel). |
| 2 | K6 + the chain theorem | **CONFIRMED** (b)(c)(d)(e); **(a) REFUTED as printed** | `{q ≤ θ}` *does* have a ⊆-minimum member containing any anchor, so the printed dense-chain witness is false; corrected witness `{q < θ}` supplied. `≼` totality holds bare (all degenerate cases checked), transitivity direct, finite max by induction, and `⋂₀{S : W ⊆ S}` is a correct size-1 scheme: `⊆` leg from the realizer, `⊇` leg from maximality; edge cases `𝒜 = ∅`, `{∅}`, unique-container anchor, `⊤ ∈ 𝒜`, no-`∅` chains all discharged. Chains are VC 1 (needs (F-mono)). |
| 3 | splitting law | **CONFIRMED** | The four assembled patterns shatter `{x,y}` exactly, hitting `#B = 2 ≤ 1`; no off-by-one, since shattered singletons are harmless by construction of `vcBounded _ 1`. `x ≠ y` is decorative (statement true at `x = y`). Non-vacuous: `𝒜 = {∅,{x},{y}}` attains "exactly one residual shatters". |
| 4 | crossing probe `{∅,{x,u},{y,u}}` | **CONFIRMED** (`k = 1`); URS explanation corrected | VC = 1 verified. Two complete inequivalent schemes: one with **no** 0-labeled kernel (improper `ρ({u},{u}) = {u}`), one with 0-labeled anchors (`ρ({x},∅) = {y,u}`). Forced: on `A = {u}` the default cannot serve both realizable samples, so a `u`-anchor is compulsory; and any `u`-anchor serving an `x`- and a `y`-window must be improper. Free: which sample takes the `u`-anchor, and the improper-vs-0-labeled repair. Alignment freedom at `d = 1` is real. |
| 5 | KU14 adversarial probe | **CONFIRMED as a theorem; no counterexample exists** | `vcBounded 𝒜 1 → HasKernelScheme 𝒜 1`, for arbitrary `α`, arbitrary (infinite) `𝒜`, no `∅`, no `⊤`, no chain hypothesis. Proof: twist by any member (Lemma A: twists preserve VC, realizability, and schemes with the same kernels), then VC 1 with `∅` in the class forces co-occurring points to be `≼`-comparable (Lemma B), so every label set is a finite chain with a `≼`-max; anchor there and reconstruct by `⋂{R : p ∈ R}`. `k = 0` is impossible, so 1 is exact. Kills all four suggested probe families (one of them, crossing dense left/right rays, is VC 2, hence inadmissible). `CalibrationVCOne` is a corollary; C-IV is obsolete. Does not extend to `d ≥ 2`: Lemma B is dimension-specific. |
| 6 | A4 audit of §8 | **GAP** (five actionable defects) | (i) K6's dense witness is a false statement; (ii) K5's routing is not a scheme; (iii) `interConvention` reads `W` only, so all 0-labeled anchors collapse into the default, proved insufficient on the star class, hence **not** a general VC-1 convention (the general one depends on `Z` through the twist); (iv) `x ≠ y` decorative in the splitting law, and `IsChain` is no longer the natural hypothesis for the `k = 1` theorem; (v) `SetShatters` subset-monotonicity is an unlisted prerequisite, and all three planned statements need non-vacuity witnesses (`HasKernelScheme ∅ k` and "the empty class shatters nothing" are live vacuity sinks). `memOrder` totality with no side hypothesis: clean, CONFIRMED. |

