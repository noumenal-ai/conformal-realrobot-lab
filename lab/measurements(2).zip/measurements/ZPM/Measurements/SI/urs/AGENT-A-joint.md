# AGENT A — Reading A (the paradigm joint). Working record.

STATUS: COMPLETE. Lean compiles, axiom-clean, zero sorries.

Private discovery record. URT vocabulary permitted HERE ONLY; the shipped Lean file
carries none of it.

## 0. Assignment

Reading A. P1 = combinatorial premise atoms (shattering structure, the VC condition).
P2 = induction atoms (kernels, reconstruction, the compression scheme). S = the
sample/trace interface. Kappa = the premise-to-conclusion relation of the conjecture
itself, not the concept class.

## 1. Insight audit (latter transcript + URS + corpus), non-trivial only

1. **The joint is quantifier-shaped, not atom-shaped.** The premise of LW is a uniform
   bound over all windows; the conclusion is a single global function; the interface is
   one labeled window at a time. Non-trivial because it locates the difficulty in the
   *arity of the interface* rather than in either side, and it predicts that every
   per-instance measurement reads zero. Now kernel-checked (see section 2).

2. **Side information is the chromatic number of fiber incompatibility.** For a fixed
   compression map a correct reconstruction exists iff same-kernel samples are pairwise
   compatible; with an index of size c, iff each fiber's incompatibility graph is
   c-colourable. Non-trivial because it retypes an information-theoretic quantity as a
   combinatorial invariant of the routing, and the FLT kernel's own audit note (side
   information enters only at the dual-VC sparsification, as incidence gluing of blocks)
   corroborates it independently.

3. **Improperness is essential, not a convenience.** Proper single-member-fiber designs
   provably fail on chains: a chain realizes 2n singleton symbols with only n+1 members.
   Non-trivial as a counting impossibility for an entire design family; it survives the
   defect kill and forces reconstruction to be a structural surrogate.

4. **K3 stands: defect mass is not the price.** Even-prefix has VC 1, unbounded window
   defect, and compresses at kernel size 1. Non-trivial because one machine-checkable
   family refutes the whole within-window counting programme. It is also the kill that
   was logged and then ignored for three ticks.

5. **Counting-type lower bounds cap at d** (FLT `CountingBarrier`). Non-trivial because
   it rules out in advance any obstruction expressible as the cardinality of a
   window-local family. With 4, this is the structural reason the defect layer stalled
   exactly where the classical theory already was.

6. **The carrier-agnostic collapse is the corpus's own diagnosis.** Over a bare
   `kappa : Set (S x A x B)` the legs are carrier-agnostic and amalgamation collapses to
   `FiberProductSurjective`. Non-trivial because it supplies an a priori test every
   proposed carrier must pass; the defect arc failed exactly this test.

7. **Vorob'ev and the type space are two legs, not successive objects.** Acyclicity is
   the criterion on the base geometry; the type space is the vocabulary it is expressed
   in. Non-trivial as bookkeeping content: the drift that retired the Vorob'ev leg is the
   drift that let the defect calculus run after K3 had killed it.

8. **k = 1 is exact at VC 1, k = 0 at VC 0.** The ladder reads d = 0 -> 0, d = 1 -> 1,
   ruling out any budget law with a constant offset. Explicitly not evidence for the
   general case: the comparability lemma is d = 1 specific.

9. **The routing structure is offline.** Prefix-committed monotone selectors die at VC 1;
   eviction-streaming reduces to offline. Non-trivial because it removes a class of
   candidate mechanisms before they are attempted.

### Coherence check

No pair conflicts. Two near-conflicts resolved.

- 4 vs 8: K3 refutes defect *mass* as a price function; 8 is a positive compression fact.
  Even-prefix is VC 1 and pays 1, which is what both say.
- 2 vs 3: fiber colouring is about a fixed compression map's fibers; improperness is about
  the reconstruction's values. Independent axes; the crossing probe exhibits both at once.

## 2. Collapse test (run FIRST)

**Verdict: reading A collapses at every atomic carrier, and the collapse is intrinsic.**

Kernel-checked as `jointDecomposable` in `SI/JointBase.lean`: worlds are pairs (family,
reconstruction rule); assertions are trace (shared), freedom (premise side), routing
(conclusion side); admissible worlds are those whose rule serves every sample of their
family. `IsDecomposable` holds unconditionally, the amalgam being literally
`(w1.family, w2.rule)`.

Three independent reasons, only the first of which is specific to my formalization.

(a) Shattering is definable from traces, so the intended premise-private atoms are in
fact shared. With P1 shared, the triple degenerates.
(b) With worlds as (family, rule) pairs, trace-equivalence fixes the family and the rule
is unconstrained by the premise side.
(c) At the single-sample carrier the premise-side and induction-side constraints are
independent given the sample, so kappa is rectangular over S.

**Carrier level: trivial (carrier-agnostic).** The forced lift is from points to covers.
What is private to each side is a *quantifier*, not a fact, so the non-degenerate carrier
is the diagram of local interfaces with its restriction maps, where the premise is a
bound on fibers and the conclusion is a global section. This is exactly the regime the
Vorob'ev leg measures, which is why the two legs compose rather than supersede.

This also explains, structurally, why the defect arc produced counting: a cardinality of a
window-local family is a measurement at the collapsed level, and at that level a count is
all there is.

## 3. The proposition

Problem: the reconstruction rule is one global object and the condition on it is stated
one sample at a time; every known proof buys the missing global-to-global mediation with
information-theoretic currency at the crossing.

Mechanism, one sentence: index the reconstruction rule by the labeled subsamples it can
be asked about, let each realizable sample contribute a constraint on the subsamples of
at most k of its own points, and require the resulting hypergraph of constraint scopes to
be ear-eliminable.

Reading: when the scopes are ear-eliminable, pairwise consistent local routings assemble
into one global rule, so the rule is read off the cover rather than searched for; when
they are not, the extracted cycle is a named obstruction, which is what side information
pays for.

Hedged claim: this reduces LW at kernel size k to a decidable property of a hypergraph
determined by the class's traces and k alone. It does not show that a VC bound of d
yields such a hypergraph at k = O(d); that is stated as `AcyclicLocalSystemExists` and
left open. The gluing mathematics is borrowed from `glues_of_acyclic`; what is proper to
this tick is the encoding.

## 4. Kills produced this tick

**K11 (the collapse kill).** The literal reading-A instantiation at the assertion level
carries no coupling: `jointDecomposable` is kernel fact. Forces the lift to covers.

**K12 (the Beth kill, sharper than the brief's).** `typeAmalgamable_imp_interp` needs
shared definability on top of amalgamation. Since amalgamation already holds at the
atomic carrier, interpolation there is automatic and carries no content, so a
bounded-parameter Beth statement at that carrier is not merely relocated search but
vacuous. The FOL layer earns its place as the vocabulary in which a *cover-level*
geometry is expressed, not as a place to look an answer up.

**K10 (the consistency kill, the operative one).** The canonical scheme-free local
system, whose relation at a sample is the full routing disjunction, fails pairwise
consistency. Mechanism: scopes are nested along sample restriction
(`scope_subset_scope`, strict already on a two-point ground by
`scope_ssubset_of_two_points`). When one scope sits strictly inside another, the larger
member can always place its witness outside the intersection, so its marginal is
everything, while the smaller member's marginal is its own relation, which is a proper
subset. Consistency then demands that every assignment serve the smaller sample, which is
false. Sub-samples are samples, so nesting is unavoidable.

What K10 forces: the base geometry must supply local relations that survive nesting. Two
named directions, neither taken this tick: filter the relations before gluing (remove
values that cannot extend), or re-index the cover so nesting is absent. Both are
structure-additions, not simplifications.

## 5. Audits

**Classical reduction.** `Subsample`, `scope`, `Serves` are Littlestone and Warmuth's own
objects under working names; no novelty is claimed for them. `Acyclic`,
`GrahamReducible`, `LocalStruct`, `Consistent`, `glues_of_acyclic` are the corpus's
Vorob'ev leg and are classical acyclicity for constraint systems; the gluing theorem is
borrowed wholesale. What is proper to this tick is the encoding and the two negative
results. On corner peeling: the cover here is indexed by samples with vertices the
labeled subsamples, including 0-labeled ones, and has no cube structure or notion of a
corner, so it is a different object; I have observed this and have not proved
inequivalence.

**External non-vacuity.** Acyclicity is applied to `sampleCover k S`, one scope per
sample, in which no reconstruction rule occurs; it is decidable through
`decidableAcyclic`. The judgement is therefore made without reference to whether a scheme
exists. Verdict this tick: the criterion is intact, but the *consistency* leg fails for
the canonical relations (K10), so the positive leg does not fire yet.

**Vacuity.** `exists_localSystem_of_singleton` is a kernel-checked instance where all
premises hold simultaneously. Dropping `hacyc` loses `glues_of_acyclic` and Specker's
triangle is a pairwise-consistent nodup family that does not glue; dropping `hcons` lets
two members demand different values at a shared subsample and the join is empty; dropping
`hne` makes `Glues` hold vacuously with an empty global family and no rule is extractable
(the proof uses it literally); dropping `hsound` severs the only link to the class;
`hnd` is required by the borrowed theorem's permutation lift.

**A4 flags, stated rather than hidden.** `jointDecomposable` is a short proof. It is short
because the collapse is structural; its value is as a negative measurement, not as
difficulty. `hasKernelScheme_of_acyclic_localSystem` is about ten lines of plumbing on a
borrowed theorem; its non-triviality is inherited, not produced.

**Circularity.** `scope`, `sampleCover`, `Subsample` contain no occurrence of a
reconstruction rule. The risk lives in `fam`: local relations are arbitrary finite sets,
so a system whose relations are singletons read off an existing rule satisfies all five
premises, and for such a system `Consistent` says precisely that the singletons come from
one global assignment, which is the conclusion. So the theorem is not yet a non-circular
reduction, and `hcons` is where that has to be fixed.

## 6. Ledgers

Object axis. KK gained: the atomic-carrier collapse; the nesting of scopes; the joint
satisfiability of the gluing premises at VC 0; the axiom-clean status of all of it. KU
articulated: `AcyclicLocalSystemExists`; whether pairwise consistency is checkable from
traces after filtering. UK moved to KU: the private/shared split is about quantifiers, so
the carrier is a cover.

Agent axis. R-moves: retyping the joint from a relation between assertions to a relation
between global sections over a cover of local interfaces; retyping the alignment break
point from an untyped choice into a decidable property of a hypergraph. Askability change:
"is there a hidden channel between premise and induction" became "does the cover of
labeled subsamples admit ear elimination", which is decidable and has a converse machine.
Bookkeeping repaired: both legs carried forward, neither retired.

Turn transitions: audit NULL; collapse test KU to KK; the lift UK to KU; K10 KU to KK
(kernel-checked at the nesting step, prose at the consistency step); the residual a new
KU replacing the untyped break point.

## 6b. The arity boundary, and what it does to the collapse result

Added after the coordinator flagged that the bipartite carrier in my brief was an error
rather than a feature of the thesis: the corpus is explicitly multipartite (`Multipartite`
and `hcCombPi` at arity n, `FiveWayPi`, `ParityFamily` at every arity, `HigherObstruction`
stating that the base defect is irreducibly higher-degree and invisible to the local ends,
and Specker being three teams).

I checked the arity claim against the corpus definition of `RIPCover` before adopting it,
then proved it, so my side of the agreement is kernel fact rather than assent:

`acyclic_pair : Acyclic ({T1, T2} : Finset (Finset iota))` — every cover of at most two
scopes admits a running-intersection order, in either direction, since the two scopes meet
inside the second one. Against `speckerCover_not_acyclic`, three scopes is where it can
first fail.

This subsumes section 2. `IsDecomposable` in `HC/Abstract.lean` IS a two-team gluing
problem: the left reduct and the right reduct are two local structures meeting in the
shared block. So `jointDecomposable` holding unconditionally is an instance of
`acyclic_pair`, and the vocabulary-side reason for the collapse and the arity-side reason
are one reason. A bipartite schema cannot host this obstruction whatever vocabulary it is
given.

Convergence with the independent agent on the other reading: it derived the same boundary
by a different route (the nerve of a two-block split is a single edge; every two-team cover
is acyclic; `glues_of_acyclic` therefore discharges every pairwise consistent family at
arity 2). Two readings landing on the same arity fact through different objects is stronger
than either derivation alone. Combined with the compiled ladder, d = 0 at k = 0 and d = 1
at k = 1, the natural reading is that the easy rungs are easy because their nerves cannot
host a cycle: the d = 1 mechanism is a total order on the sample's label set, and a chain of
scopes is ear-eliminable. Held as conjecture, not result. It would become a result by
rebuilding `hasKernelScheme_one_of_vcBounded_one` as an instance of
`hasKernelScheme_of_acyclic_localSystem`, with the comparability lemma supplying the
running-intersection order. Until then the correspondence is suggestive.

Consequence for where effort belongs: arity three, i.e. d = 2, is the first rung where the
cover can be genuinely cyclic and therefore the first place the conjecture has content.

## 7. What did not happen

`mathlib-search` was unavailable for the whole tick: the daemon binds its port only
outside the sandbox and then serves 503 while loading the 374 MB `measurements` index,
and it exited before becoming ready. Names were resolved by reading the corpus source
directly and by `lake build`, which is kernel-authoritative for every name actually used.
No name in the shipped file is pattern-guessed.
