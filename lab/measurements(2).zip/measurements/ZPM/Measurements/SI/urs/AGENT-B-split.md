# AGENT B — READING B (THE GROUND SPLIT) — running checkpoint

STATUS: IN PROGRESS. This file is written incrementally; the JSON companion
(`AGENT-B-split.json`) is the authoritative deliverable.

## CHECKPOINT 1 — the collapse test (run FIRST, per failure mode (d))

**Question.** Reading B's carrier is `κ ⊆ S × A × B`: a shared interface `S` and two
private blocks. `HC/FOL/Amalgamation.lean` warns that amalgamation over a bare
`κ : Set (S × A × B)` "collapses to the trivial set-recombination
`FiberProductSurjective` — that is not genuine first-order amalgamation."

**Answer: IT COLLAPSES, and the collapse is a theorem about the cover, not an
artifact of the proof.**

Two independent pieces of evidence, both from the corpus:

1. `HC/Fibered.lean:138` — `decomposable_iff_fps` proves
   `Decomposable κ ↔ FiberProductSurjective κ` in four lines of pure quantifier
   shuffling (`intro`/`exact`, no structure touched). By A4 this is a
   definition-unfold, not a theorem. Amalgamation at this carrier IS set
   recombination.

2. The deeper reason, which is new here: **the nerve of a two-block ground split is
   a single edge, and every two-team cover is acyclic.** The cover induced by the
   split is `{S ∪ P₁, S ∪ P₂}`; its running-intersection order is immediate
   (`(S∪P₁) ∩ (S∪P₂) ⊆ S∪P₂`). Hence `Acyclic` holds, hence `glues_of_acyclic`
   (`HC/GrahamBridge.lean:236`) applies and **every** pairwise-consistent family
   over a two-block split glues. There is no gluing obstruction to find at arity 2.
   The corpus already contains the concrete witness: `pathCover_acyclic`
   (`GrahamBridge.lean:254`, `by decide`) is exactly the two-block split
   `{{0,1},{1,2}}` with interface `{1}` and privates `{0}`, `{2}`.

**Consequence (this is the forcing, not a lament).** The two-private-block reading
cannot host a support-level obstruction. Either
  (a) lift the carrier to the FOL type space — but that route ends in "now find a
      bounded-parameter Beth interpolant", which is failure mode (e), search
      relocation; or
  (b) **enlarge the base geometry until the nerve can host a cycle** — which needs
      at least three blocks, and for which the corpus supplies both the negative
      witness (`speckerCover_not_acyclic`, `by decide`) and the extraction machine
      (`exists_earFree_core`, `cycle_obstruction`).

Route (b) is taken. The ground split is therefore not `(S, P₁, P₂)` but a **cover of
the ground domain by local windows with a nontrivial nerve**, and the two-block
split is exactly its degenerate, obstruction-free case.

(Sections below filled in as the tick proceeds.)
