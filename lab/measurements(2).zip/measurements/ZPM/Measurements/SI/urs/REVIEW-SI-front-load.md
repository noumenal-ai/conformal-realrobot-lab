# REVIEW of URS-SI-front-load.md

Ultraconservative referee report. Standard applied: a claim is CONFIRMED only where a
complete derivation is given below; otherwise REFUTED (with the error located) or GAP
(with the missing step named). No literature was consulted. Pajor's inequality
|Tr_A(𝒜)| ≤ |sh_A(𝒜)| is assumed, as licensed. Everything else is re-derived.

## Conventions fixed for this report

* α a type, 𝒜 ⊆ P(α) a class, A ⊆ α a finite window.
* Tr_A(𝒜) := {A ∩ S : S ∈ 𝒜}. sh_A(𝒜) := {B ⊆ A : 𝒜 shatters B}.
* 𝒜 shatters B iff ∀ C ⊆ B, ∃ S ∈ 𝒜, B ∩ S = C. In particular ∅ ∈ sh_A(𝒜) iff 𝒜 ≠ ∅,
  and sh_A(∅) = ∅. Both conventions are used below and both matter at the edge cases.
* defect_A(𝒜) := |sh_A(𝒜)| − |Tr_A(𝒜)|, computed in ℤ throughout this report. The ℕ
  truncation of D7/D8 is audited separately in item 6.
* A' abbreviates A ∖ {x}. 𝒜₀ := {S ∈ 𝒜 : x ∉ S}, 𝒜₁ := {S ∈ 𝒜 : x ∈ S}.
* Shattering is monotone in the class: 𝒫 ⊆ 𝒬 and 𝒫 shatters B implies 𝒬 shatters B.
  Used repeatedly without further comment.
* For B ⊆ A: 𝒜 shatters B iff Tr_A(𝒜) shatters B (since B ∩ (A ∩ S) = B ∩ S). Used
  whenever a trace family is treated as a class in its own right.

---

## Item 1. L0 equivalences

**Verdict: CONFIRMED for (a), (b), (c), under two precision conditions that the file
does not state and that are load-bearing.** The two conditions are (i) the fiber must be
taken over the *labeled* compressed sample (Z, W), not over Z alone, and (ii) the
reconstruction must be allowed to output an arbitrary hypothesis, not necessarily a
member of 𝒜. Under the Z-only reading (b) and (c) are false; under a properness
requirement (b) and (c) are false. Counterexamples for both are given below.

### 1(a) two-map form ⟺ convention-first form

Fix k. Write R(𝒜) for the set of realizable samples, i.e. pairs (A, T) with A finite and
T ∈ Tr_A(𝒜).

Two-map form: ∃ κ : R(𝒜) → P(α) and ∃ ρ : P(α) → P(α) → P(α) with, for every
(A,T) ∈ R(𝒜), κ(A,T) ⊆ A, |κ(A,T)| ≤ k, and ρ(κ(A,T), κ(A,T) ∩ T) ∩ A = T.

Convention form: ∃ ρ, ∀ (A,T) ∈ R(𝒜), ∃ Z ⊆ A with |Z| ≤ k and ρ(Z, Z ∩ T) ∩ A = T.

(⟹) Given (κ, ρ), take the same ρ and put Z := κ(A,T). All three conjuncts hold by
hypothesis. If in the source formulation ρ is only partially defined (on the image of κ),
extend it by any junk value, e.g. ρ(Z,W) := ∅ off the image; the correctness condition is
only ever evaluated on the image, so the extension is harmless.

(⟸) Given ρ and the ∀∃ statement, R(𝒜) is a set (a subset of P(α) × P(α)), so the axiom
of choice yields κ : R(𝒜) → P(α) selecting for each sample one witness Z. The three
conjuncts are exactly the witness conditions. In Lean this is `Classical.choice`; nothing
constructive is claimed and nothing constructive is needed.

The move is precisely the ∀∃ to ∃∀ Skolemisation, and the file's "Fiber-coherence
bookkeeping disappears because ρ is a function" is accurate: ρ is quantified *outside* the
∀ over samples in both forms, so no coherence side condition is created or destroyed by
the reformulation. CONFIRMED.

One remark that the file does state correctly and that I re-derived: schemes see only
traces. If 𝒜 and ℬ have Tr_A(𝒜) = Tr_A(ℬ) for every finite A, then R(𝒜) = R(ℬ), and
both forms quantify over nothing else, so the scheme sets coincide. The restriction maps
Tr_A(𝒜) → Tr_{A'}(𝒜), T ↦ T ∩ A' for A' ⊆ A are surjective, since A' ∩ S = (A ∩ S) ∩ A'.
CONFIRMED.

### 1(b) fixed κ: correct ρ exists iff every fiber is pairwise compatible

Let the fiber be F = κ⁻¹(Z, W) = {(A_i, T_i)}_{i ∈ I}, indexed by an arbitrary (possibly
infinite, possibly uncountable) set I. ρ(Z,W) is a single hypothesis H that must satisfy
H ∩ A_i = T_i for all i ∈ I.

*Necessity.* If H works then for all i, j:
T_i ∩ A_j = (H ∩ A_i) ∩ A_j = H ∩ (A_i ∩ A_j) = (H ∩ A_j) ∩ A_i = T_j ∩ A_i.

*Sufficiency.* Assume T_i ∩ A_j = T_j ∩ A_i for all i, j. Put H := ⋃_{i ∈ I} T_i. Then
for each j:
* T_j ⊆ H and T_j ⊆ A_j, so T_j ⊆ H ∩ A_j.
* If a ∈ H ∩ A_j then a ∈ T_i for some i and a ∈ A_j, so a ∈ T_i ∩ A_j = T_j ∩ A_i ⊆ T_j.

Hence H ∩ A_j = T_j for every j. This settles the question the handoff spec raises
explicitly: **pairwise compatibility of a possibly infinite family of partial labelings
does suffice, and no compactness, Zorn, or finite-character argument is needed.** The
union is the witness outright. The reason is that the compatibility relation here is
agreement of partial functions on overlaps, whose union is directly a function; note
T_i ⊆ A_i gives T_i ∩ A_j = T_i ∩ (A_i ∩ A_j) and likewise for j, so the stated condition
is literally "T_i and T_j agree on A_i ∩ A_j".

Since distinct fibers are disjoint and ρ's value on one fiber's index (Z,W) constrains no
other fiber, the per-fiber criterion assembles into the global one. CONFIRMED.

**Precision condition (i), load-bearing.** If "κ-fiber" is read as the preimage of Z alone
rather than of the labeled pair (Z, Z ∩ T), the claim is FALSE. Counterexample: 𝒜 = P({x}),
k = 1, κ(A,T) = A for the window A = {x}. Samples ({x}, ∅) and ({x}, {x}) share Z = {x} but
have W = ∅ and W = {x}; they are incompatible (T₁ ∩ A₂ = ∅ ≠ {x} = T₂ ∩ A₁), yet ρ handles
them with no side information at all because ρ receives W. The Lean statement of L0 must
fiber over (Z, W). This is exactly the shape of hazard KU7 flags, so it should be recorded
concretely.

**Precision condition (ii), load-bearing.** If the reconstruction is required to output a
member of 𝒜 (a *proper* scheme), sufficiency fails. Counterexample: α = {a,b},
𝒜 = {{a},{b}}. The samples ({a},{a}) and ({b},{b}) are pairwise compatible
(T₁ ∩ A₂ = ∅ = T₂ ∩ A₁), and the union {a,b} works as a hypothesis, but no member of 𝒜
works: {a} ∩ {b} = ∅ ≠ {b} and {b} ∩ {a} = ∅ ≠ {a}. So L0(b) is a statement about improper
schemes. D3 (`Convention α := Set α → Set α → Set α`) is improper, so the file is
internally consistent here; the risk is at the T4 glue, where the kernel's
`CompressionScheme.reconstruct : Finset (X × Y) → (X → Y)` is also improper, so the glue
survives, but any future "proper compression" variant would break L0(b) silently.

### 1(c) index set I: correct ρ exists iff each fiber's incompatibility graph is |I|-colorable

Read the claim as: the kernel-selection map (A,T) ↦ (Z, W) is fixed; the question is
whether an index assignment (A,T) ↦ i ∈ I and a ρ : (Z, W, i) ↦ H exist making the scheme
correct.

Define, on each fiber F over (Z,W), the graph G_F with vertex set F and an edge between
distinct samples exactly when they are incompatible. G_F is a genuine graph: the
compatibility relation T₁ ∩ A₂ = T₂ ∩ A₁ is symmetric, and it is reflexive (T ∩ A = T ∩ A),
so incompatibility is irreflexive and symmetric.

(⟹) If (index assignment, ρ) is correct, then two samples in F with the same index share
the hypothesis ρ(Z,W,i), hence by 1(b) necessity they are compatible. So the index
assignment restricted to F is a proper colouring of G_F with at most |I| colours.

(⟸) Given a proper |I|-colouring per fiber, each colour class is pairwise compatible, so
by the union construction of 1(b) there is a hypothesis H_{(Z,W,i)} := ⋃ {T : (A,T) in
class i of F}. Setting ρ(Z,W,i) := H_{(Z,W,i)} (and junk elsewhere) gives correctness.

Colourings are chosen independently per fiber because ρ's arguments include (Z,W). No
finiteness of the fiber is used, and no de Bruijn/Erdős step is needed: the criterion is
existence of a proper colouring of a possibly infinite graph, which is what is asserted.
CONFIRMED, with precision conditions (i) and (ii) as above.

The derived reading "side information = chromatic number of what the kernel choice fails
to make compatible" is then exact, with price 𝒜 k = min over kernel maps of the supremum
over fibers of χ(G_F). See item 6 for two typing hazards in D5' that this exposes.

---

## Item 2. L2 split superadditivity (Pass 4)

**Verdict: CONFIRMED, all three steps, all edge cases, plus an exact strengthening of
(b) that the file does not state.**

### 2(a) exact trace additivity

x ∈ A, A' = A ∖ {x}. Since x ∈ A, for any S: x ∈ A ∩ S iff x ∈ S. Therefore
Tr_A(𝒜) = P₀ ⊔ P₁ with P₀ := {T ∈ Tr_A(𝒜) : x ∉ T} and P₁ := {T ∈ Tr_A(𝒜) : x ∈ T},
and moreover P₀ = Tr_A(𝒜₀), P₁ = Tr_A(𝒜₁) (if x ∉ A ∩ S then x ∉ S so S ∈ 𝒜₀, and
conversely).

* P₀ = Tr_{A'}(𝒜₀) as sets, not merely in bijection: for S ∈ 𝒜₀ we have x ∉ S, so
  A ∩ S = A' ∩ S.
* P₁ → Tr_{A'}(𝒜₁), T ↦ T ∖ {x} is a bijection: for S ∈ 𝒜₁, A ∩ S = (A' ∩ S) ∪ {x}, so the
  map is well defined and surjective; it is injective because every element of P₁ contains
  x, so T = (T ∖ {x}) ∪ {x} recovers T.

Hence |Tr_A(𝒜)| = |Tr_{A'}(𝒜₀)| + |Tr_{A'}(𝒜₁)|, exactly. Finiteness is automatic: all
three families are subsets of P(A) with A finite. No hypothesis on 𝒜 (finite, nonempty)
is used. CONFIRMED.

Edge cases. x in every member: 𝒜₀ = ∅, Tr_{A'}(∅) = ∅ of size 0, and the identity reduces
to |Tr_A(𝒜)| = |Tr_{A'}(𝒜)|, correct since A ∩ S = (A' ∩ S) ∪ {x} is then a bijection.
x in no member: symmetric. 𝒜 = ∅: 0 = 0 + 0. A = {x}: A' = ∅, Tr_∅(𝒜_b) = {∅} if
𝒜_b ≠ ∅ and ∅ otherwise, so the right side is [𝒜₀ ≠ ∅] + [𝒜₁ ≠ ∅]; the left side is
|{∅ : 𝒜₀ ≠ ∅} ∪ {{x} : 𝒜₁ ≠ ∅}|, the same number.

### 2(b) skeleton superadditivity

Write sh₀ := sh_{A'}(𝒜₀), sh₁ := sh_{A'}(𝒜₁), both families of subsets of A'.

*First injection.* sh₀ ∪ sh₁ ⊆ sh_A(𝒜): B ∈ sh_b means B ⊆ A' ⊆ A and 𝒜_b shatters B;
𝒜_b ⊆ 𝒜 and shattering is monotone in the class, so 𝒜 shatters B.

*Second injection.* For B ∈ sh₀ ∩ sh₁ I claim B ∪ {x} ∈ sh_A(𝒜). B ∪ {x} ⊆ A holds. Let
C ⊆ B ∪ {x}.
* If x ∉ C then C ⊆ B; 𝒜₀ shatters B, so pick S ∈ 𝒜₀ with B ∩ S = C. Then
  (B ∪ {x}) ∩ S = (B ∩ S) ∪ ({x} ∩ S) = C ∪ ∅ = C, using x ∉ S.
* If x ∈ C put C' := C ∖ {x} ⊆ B; 𝒜₁ shatters B, so pick S ∈ 𝒜₁ with B ∩ S = C'. Then
  (B ∪ {x}) ∩ S = C' ∪ {x} = C, using x ∈ S.
The map B ↦ B ∪ {x} is injective on subsets of A' since x ∉ A'.

*Disjointness of images.* Every element of the first image is a subset of A', hence omits
x; every element of the second image contains x.

*Count.* |sh_A(𝒜)| ≥ |sh₀ ∪ sh₁| + |sh₀ ∩ sh₁| = |sh₀| + |sh₁| by inclusion and exclusion,
all sets finite as subfamilies of P(A'). CONFIRMED.

**Exact strengthening (derived here, not in the file).** The converse of the second
injection also holds: if x ∈ B and 𝒜 shatters B, then every pattern C ⊆ B with x ∉ C must
be realized by a member omitting x, i.e. by 𝒜₀, and every pattern with x ∈ C by 𝒜₁; hence
B ∖ {x} ∈ sh₀ ∩ sh₁. So the second image is *all* of {B ∈ sh_A(𝒜) : x ∈ B}, and

  twist_x(𝒜, A) = |sh_A(𝒜)| − |sh₀| − |sh₁|
                = # { B ⊆ A ∖ {x} : 𝒜 shatters B, and neither 𝒜₀ nor 𝒜₁ shatters B }.

This is an exact combinatorial identity, and it validates the file's informal reading
("freedom visible only to the union ... realized partly by x = 0 members and partly by
x = 1 members") as literally correct rather than merely suggestive. I recommend it as the
Lean statement of L2, since it subsumes both (b) and the twist definition and removes the
subtraction entirely. Checks: diagonal class on {x,y} gives the single set B = {y}, twist
1; even-prefix class with n = 4 split at x₁ gives the single set B = {x₂}, twist 1.

### 2(c) subtraction

By Pajor applied to 𝒜 on A, to 𝒜₀ on A', and to 𝒜₁ on A', all three defects are ≥ 0 and
all three subtractions are genuine. Combining (a) and (b) in ℤ:

  defect_A(𝒜) = |sh_A| − |Tr_A| ≥ (|sh₀| + |sh₁|) − (|Tr₀| + |Tr₁|)
              = defect_{A'}(𝒜₀) + defect_{A'}(𝒜₁).

Since each of the three defects is a genuine (nonnegative) difference, the ℕ-truncated
reading agrees with the ℤ reading. CONFIRMED. Twist ≥ 0 follows, but see item 6: in ℕ that
consequence is contentless and must not be the statement one proves.

Edge cases. A = {x}, both children nonempty: sh = Tr = {∅,{x}}, defect 0 ≥ 0 + 0. A = {x},
one child empty: sh = Tr = {∅}, defect 0 ≥ 0 + 0 (defect_∅ of the empty class is 0 − 0).
𝒜 = ∅: 0 ≥ 0. x in every member: defect_A(𝒜) ≥ 0 + defect_{A'}(𝒜₁), and in fact equality
holds since both counts are preserved. Also defect_∅(𝒜) = 0 for every 𝒜, which is the
induction base used in item 3.

---

## Item 3. L3 hereditary flatness

**Verdict: CONFIRMED as scoped in the file (conditioning on points inside the window).
The unscoped reading is REFUTED by explicit counterexample, so the Lean statement must
carry Z ⊆ A as a hypothesis; the file's "no new hypothesis" (line 171) is inaccurate.**

### One step

If defect_A(𝒜) = 0 then by 2(c), 0 ≥ defect_{A'}(𝒜₀) + defect_{A'}(𝒜₁) with both summands
≥ 0 by Pajor, so both are 0.

### Conditioning equals passing to a child

residual 𝒜 {x} ∅ = {S ∈ 𝒜 : {x} ∩ S = ∅} = {S : x ∉ S} = 𝒜₀, and
residual 𝒜 {x} {x} = {S : x ∈ S} = 𝒜₁. Identical, no gap.

### Composition of residuals

For x ∉ Z' and Z = Z' ⊔ {x}, W ⊆ Z:
Z ∩ S = W iff (Z' ∩ S = W ∩ Z') and ({x} ∩ S = W ∩ {x}). Hence
residual 𝒜 Z W = residual (𝒜_b) Z' (W ∖ {x}) with b = 1 if x ∈ W and b = 0 otherwise.
Exact, no gap between "children" and "residuals".

### Iteration

By induction on |Z| for Z ⊆ A. Base Z = ∅: W = ∅ forced, residual = 𝒜, defect_A(𝒜) = 0.
Step: split off x ∈ Z ⊆ A, get defect_{A∖{x}}(𝒜_b) = 0 for both b, apply the inductive
hypothesis with window A ∖ {x}, class 𝒜_b, and set Z' = Z ∖ {x} ⊆ A ∖ {x}, obtaining
defect_{(A∖{x})∖Z'}(residual) = defect_{A∖Z}(residual 𝒜 Z W) = 0. Terminates since Z is
finite. CONFIRMED.

### The window on which the residual is measured does not matter (derived here)

For Z ⊆ A and 𝒞 := residual 𝒜 Z W:
* T ↦ T ∖ Z is a bijection Tr_A(𝒞) → Tr_{A∖Z}(𝒞), because A ∩ S = ((A∖Z) ∩ S) ∪ W for
  every S ∈ 𝒞, with inverse T' ↦ T' ∪ W.
* sh_A(𝒞) = sh_{A∖Z}(𝒞): no B meeting Z is shattered, since a point z ∈ Z has the same
  label (z ∈ W or not) in every member of 𝒞, so the two required patterns on z cannot
  both occur.
Hence defect_A(𝒞) = defect_{A∖Z}(𝒞) and the two possible readings of L3 coincide. This is
worth having in Lean: it removes an ambiguity in the informal statement.

### The unscoped version is false

**Counterexample.** α = {x,y,z}, 𝒜 = {{x}, {y}, {z}, {x,y,z}}, window A = {x,y}.
* Tr_A(𝒜) = {{x}, {y}, ∅, {x,y}}, so |Tr_A| = 4.
* sh_A(𝒜) = {∅, {x}, {y}, {x,y}} (all four patterns on {x,y} occur, as listed), so
  |sh_A| = 4. defect_A(𝒜) = 0.
* Condition on z = 1, a point **outside** A: 𝒞 = {{z}, {x,y,z}}. Tr_A(𝒞) = {∅, {x,y}},
  size 2. sh_A(𝒞) = {∅, {x}, {y}}, size 3 ({x,y} is not shattered since the pattern {x}
  does not occur). defect_A(𝒞) = 1 > 0.

So flatness on a window is destroyed by conditioning on a point outside that window.
Consequently L3 must carry Z ⊆ A. The correct global statement, which I do confirm, is:

**If 𝒜 is window-flat on every finite window, then so is every residual.** Proof: given a
residual at (Z,W) with Z finite and a target finite window A, apply the in-window L3 inside
the window A ∪ Z to get defect_{(A∪Z)∖Z} = 0, then use window monotonicity of defect
(derived in the Addendum below) to descend from (A∪Z)∖Z ⊇ A ∖ Z to A ∖ Z, and the previous
paragraph to move between A and A ∖ Z. This is the form T1 actually needs, since T1's
hypothesis is flat-everywhere.

---

## Item 4. L4 join Leibniz

**Verdict: CONFIRMED, all four parts, including the twist-scaling identity re-derived
from scratch.**

Setting: α₁, α₂ disjoint, 𝒜ᵢ ⊆ P(αᵢ), join 𝒜 = {S₁ ∪ S₂ : S₁ ∈ 𝒜₁, S₂ ∈ 𝒜₂},
A = A₁ ⊔ A₂ with Aᵢ ⊆ αᵢ finite.

### Trace multiplicativity

A ∩ (S₁ ∪ S₂) = (A₁ ∩ S₁) ∪ (A₂ ∩ S₂), because A₁ ∩ S₂ = A₂ ∩ S₁ = ∅ by disjointness of
the grounds. The map Tr_{A₁}(𝒜₁) × Tr_{A₂}(𝒜₂) → Tr_A(𝒜), (T₁,T₂) ↦ T₁ ∪ T₂ is therefore
surjective, and injective because Tᵢ = (T₁ ∪ T₂) ∩ αᵢ. Hence
|Tr_A(𝒜)| = |Tr_{A₁}(𝒜₁)| · |Tr_{A₂}(𝒜₂)|. If either 𝒜ᵢ = ∅ then 𝒜 = ∅ and both sides are
0. CONFIRMED.

### Skeleton multiplicativity, both directions

Claim: for B ⊆ A with B₁ := B ∩ α₁, B₂ := B ∩ α₂, the join shatters B iff 𝒜₁ shatters B₁
and 𝒜₂ shatters B₂.

(⟸) Let C ⊆ B, Cᵢ := C ∩ αᵢ ⊆ Bᵢ. Choose Sᵢ ∈ 𝒜ᵢ with Bᵢ ∩ Sᵢ = Cᵢ. Then
B ∩ (S₁ ∪ S₂) = (B₁ ∩ S₁) ∪ (B₂ ∩ S₂) ∪ (B₁ ∩ S₂) ∪ (B₂ ∩ S₁) = C₁ ∪ C₂ = C, the two
cross terms being empty.

(⟹) Let C₁ ⊆ B₁. Since C₁ ⊆ B, there is S₁ ∪ S₂ with B ∩ (S₁ ∪ S₂) = C₁. Intersect with
α₁: B₁ ∩ S₁ = C₁. So 𝒜₁ shatters B₁; symmetrically for 𝒜₂.

Hence B ↦ (B₁, B₂) is a bijection sh_A(𝒜) → sh_{A₁}(𝒜₁) × sh_{A₂}(𝒜₂), with inverse
(B₁,B₂) ↦ B₁ ∪ B₂, so |sh_A(𝒜)| = |sh₁| · |sh₂|. Empty-class edge: if 𝒜₁ = ∅ then both
sides are 0. CONFIRMED.

### Defect identity

defect(𝒜) = |sh₁||sh₂| − |Tr₁||Tr₂|
          = (|sh₁| − |Tr₁|)|sh₂| + |Tr₁|(|sh₂| − |Tr₂|)
          = defect₁ · |sh₂| + |Tr₁| · defect₂.
The middle line telescopes exactly (the two terms −|Tr₁||sh₂| and +|Tr₁||sh₂| cancel).
All quantities are nonnegative integers with |shᵢ| ≥ |Trᵢ| by Pajor, so the ℕ reading is
also sound. CONFIRMED.

### Twist scaling

Let x ∈ A₁. The x-children of the join are joins of the x-children of side 1 with the
whole of side 2:
𝒜_0 = {S ∈ 𝒜 : x ∉ S} = join(𝒜₁_0, 𝒜₂) and 𝒜_1 = join(𝒜₁_1, 𝒜₂), because x ∈ α₁ implies
x ∉ S₂ automatically. Also A ∖ {x} = (A₁ ∖ {x}) ⊔ A₂. Apply the defect identity to each
child:

  defect_{A∖x}(𝒜_b) = defect_{A₁∖x}(𝒜₁_b) · |sh₂| + |Tr_{A₁∖x}(𝒜₁_b)| · defect₂.

Subtract both from defect_A(𝒜):

  twist_join(x) = |sh₂| · [ defect₁ − defect_{1,0} − defect_{1,1} ]
                + defect₂ · [ |Tr₁| − |Tr_{1,0}| − |Tr_{1,1}| ]
                = |sh₂| · twist₁(x) + defect₂ · 0
                = twist₁(x) · |sh₂|.

The second bracket vanishes **exactly** by trace additivity (item 2(a)) applied to 𝒜₁ on
A₁ at x. So the file's parenthetical "uses trace additivity" is correct and essential: if
traces were only superadditive, a defect₂ cross term would survive and twists would mix.
CONFIRMED.

Numerical check. 𝒜₁ = {∅,{x,y}} on A₁ = {x,y} (|Tr₁| = 2, |sh₁| = 3, defect₁ = 1,
twist₁(x) = 1); 𝒜₂ = {∅,{u}} on A₂ = {u} (|Tr₂| = |sh₂| = 2, defect₂ = 0). Join
= {∅,{u},{x,y},{x,y,u}} on {x,y,u}: |Tr| = 4 = 2·2, sh = {∅,{x},{y},{u},{x,u},{y,u}} of
size 6 = 3·2, defect 2 = 1·2 + 2·0. Children at x: {∅,{u}} and {{x,y},{x,y,u}} on {y,u},
each of defect 0, so twist_join(x) = 2 = 1·2. Matches.

---

## Item 5. Worked instances

### 5(a) Diagonal class {∅,{x,y}} on window {x,y}

**Verdict: CONFIRMED.**
Tr = {∅,{x,y}}, size 2. Shattered: ∅ yes; {x} yes (∅ gives ∅, {x,y} gives {x}); {y} yes;
{x,y} no (the pattern {x} would need a member containing x but not y). So |sh| = 3 and
defect = 1. Split at x: 𝒜₀ = {∅} on {y} has |Tr| = |sh| = 1, defect 0; 𝒜₁ = {{x,y}} on {y}
has Tr = {{y}}, sh = {∅}, sizes 1 and 1, defect 0. twist_x = 1 − 0 − 0 = 1. Maximum
shattered set size 1, so VC = 1. All three numbers confirmed. (Cross-check against the
exact twist formula of item 2: the unique B ⊆ {y} shattered by 𝒜 but by neither child is
B = {y}, count 1.)

### 5(b) Chain class {∅,{x},{x,y}} on window {x,y}

**Verdict: CONFIRMED** for defect 0, VC 1, and the existence of a size-1 scheme with the
stated addressing. **One gap in the narrative**: "kernels = address ∩ window" is not by
itself a correct compression rule; it needs a member-selection rule, and the natural one
(the ⊆-least consistent member) works. The proposition D5 is ∃-quantified over Z, so the
proposition itself is unaffected.

Counts. Tr on {x,y} = {∅,{x},{x,y}}, size 3. Shattered: ∅ yes; {x} yes; {y} yes (∅ gives
∅, {x,y} gives {y}); {x,y} no (pattern {y} needs y in, x out). |sh| = 3, defect 0. Max
shattered size 1, VC = 1.

Convention from the addressing ∅ ↦ ∅, {x} ↦ {x}, {x,y} ↦ {y}:
ρ(∅,∅) = ∅, ρ({x},{x}) = {x}, ρ({y},{y}) = {x,y}, ρ({x},∅) = ∅, ρ({y},∅) = ∅ (junk).

Every realizable sample on every subwindow, with the kernel Z = addr(S*) ∩ A where S* is
the ⊆-least member consistent with the sample:

| A | T | S* | Z | W | ρ(Z,W) | ρ ∩ A | ok |
|---|---|----|---|---|--------|-------|----|
| ∅ | ∅ | ∅ | ∅ | ∅ | ∅ | ∅ | yes |
| {x} | ∅ | ∅ | ∅ | ∅ | ∅ | ∅ | yes |
| {x} | {x} | {x} | {x} | {x} | {x} | {x} | yes |
| {y} | ∅ | ∅ | ∅ | ∅ | ∅ | ∅ | yes |
| {y} | {y} | {x,y} | {y} | {y} | {x,y} | {y} | yes |
| {x,y} | ∅ | ∅ | ∅ | ∅ | ∅ | ∅ | yes |
| {x,y} | {x} | {x} | {x} | {x} | {x} | {x} | yes |
| {x,y} | {x,y} | {x,y} | {y} | {y} | {x,y} | {x,y} | yes |

Fiber compatibility, checked as requested:
* Fiber (∅,∅) = {(∅,∅), ({x},∅), ({y},∅), ({x,y},∅)}. All labels empty, so
  T_i ∩ A_j = ∅ = T_j ∩ A_i pairwise. Union = ∅ = ρ(∅,∅).
* Fiber ({x},{x}) = {({x},{x}), ({x,y},{x})}. T₁ ∩ A₂ = {x} ∩ {x,y} = {x};
  T₂ ∩ A₁ = {x} ∩ {x} = {x}. Compatible. Union = {x} = ρ({x},{x}).
* Fiber ({y},{y}) = {({y},{y}), ({x,y},{x,y})}. T₁ ∩ A₂ = {y}; T₂ ∩ A₁ = {y}. Compatible.
  Union = {x,y} = ρ({y},{y}).

Where the selection rule bites: for the sample ({x},{x}), choosing S = {x,y} instead of
S = {x} would give Z = {y} ∩ {x} = ∅, W = ∅, ρ(∅,∅) ∩ {x} = ∅ ≠ {x}. So the address map
alone is not a compression map. Recording the ⊆-least rule (equivalently, the cascade
default) in D-layer terms is required before T1a can be stated.

### 5(c) Singleton class {∅} ∪ {{y} : y ∈ α}, α infinite

**Verdict: CONFIRMED, all three parts.**

Flatness. On a window A with |A| = n: Tr_A = {∅} ∪ {{y} : y ∈ A} (members {y} with y ∉ A
trace to ∅), so |Tr_A| = n + 1. Shattered sets: ∅ yes; every {y} with y ∈ A yes (∅ and {y}
give both patterns); no pair {y,y'} (no member contains two points, so the full pattern
fails). |sh_A| = n + 1, defect 0 for every window. VC = 1.

Size-1 scheme. ρ(∅,∅) := ∅, ρ({y},{y}) := {y}, ρ({y},∅) := ∅. Realizable samples are
(A,∅) and (A,{y}) with y ∈ A. First: Z = ∅, ρ(∅,∅) ∩ A = ∅. Second: Z = {y}, W = {y},
ρ ∩ A = {y} ∩ A = {y}. Correct.

K2 (no bounded determining set). Call Z ⊆ A determining for (A,T) if every S ∈ 𝒜 with
Z ∩ S = Z ∩ T satisfies A ∩ S = T. Take T = ∅ and any Z ⊆ A with |Z| ≤ k < |A|. Pick
y ∈ A ∖ Z. Then S := {y} satisfies Z ∩ S = ∅ = Z ∩ T but A ∩ S = {y} ≠ ∅. So Z is not
determining. Since α is infinite, windows of every size exist, so no bound k works. The
kill stands: compressibility does not imply determination, and the file's conclusion
("coherence requires compatibility of same-kernel samples, and a DEFAULT absorbs the
undetermined bulk") is exactly what the union construction of item 1(b) formalizes.

### 5(d) Free cube pair

**Verdict: CONFIRMED for d ≥ 1. REFUTED at d = 0 (VC is 1, not 0). The file's one-line
justification is incomplete: its count 2^d + 1 < 2^{d+1} covers only the shattered sets
containing x; the sets avoiding x need a separate argument, which at d = 1 is not a
counting argument at all.** The claim itself is true for d ≥ 1; the derivation in the file
is not sufficient as written.

Setup: ground C ⊔ {x} ⊔ C', |C| = |C'| = d, fixed P ⊆ C and P' ⊆ C',
𝒜₀ = {D ∪ P' : D ⊆ C} and 𝒜₁ = {P ∪ {x} ∪ D' : D' ⊆ C'}, 𝒜 = 𝒜₀ ∪ 𝒜₁.

Lower bound. 𝒜₀ shatters C: C ∩ (D ∪ P') = D since P' ⊆ C' is disjoint from C. So VC ≥ d.

Children have rank exactly d. In 𝒜₀ every point of C' ∪ {x} has a constant label, so no
shattered set may meet C' ∪ {x}; hence sh(𝒜₀) = P(C) and VC(𝒜₀) = d. Symmetrically
VC(𝒜₁) = d. This is the rank-preservation half of K1: conditioning on x = 0 gives 𝒜₀ of
rank d, conditioning on x = 1 gives 𝒜₁ of rank d, so **neither label drops the rank** and
the polarity law is dead. CONFIRMED.

Upper bound, case x ∈ B, |B| = d + 1. Put B' = B ∖ {x}. Every pattern omitting x must be
realized inside 𝒜₀ and every pattern containing x inside 𝒜₁, so 𝒜₀ shatters B' and 𝒜₁
shatters B'. By the previous paragraph B' ⊆ C and B' ⊆ C', so B' = ∅ and d = 0. For d ≥ 1
this is a contradiction. (Equivalently the file's count: with |B' ∩ C| = a and
|B' ∩ C'| = b, a + b = d, the available traces number at most 2^a + 2^b ≤ 2^d + 1 < 2^{d+1}
for d ≥ 1.)

Upper bound, case x ∉ B, |B| = d + 1. Put B₁ = B ∩ C, B₂ = B ∩ C', a = |B₁|, b = |B₂|,
a + b = d + 1 with a, b ≤ d, hence a, b ≥ 1. Traces:
Tr_B(𝒜₀) = {Q₁ ∪ (B₂ ∩ P') : Q₁ ⊆ B₁} (free on B₁, frozen on B₂), of size 2^a;
Tr_B(𝒜₁) = {(B₁ ∩ P) ∪ Q₂ : Q₂ ⊆ B₂} (frozen on B₁, free on B₂), of size 2^b.
Shattering needs 2^{a+b} ≤ 2^a + 2^b, i.e. (2^a − 1)(2^b − 1) ≤ 1, which for a,b ≥ 1 forces
a = b = 1 with equality. So only d = 1 survives the count, and there it must be checked by
hand. With B = {b₁, b₂}: Tr_B(𝒜₀) is a pair of sets agreeing on b₂, i.e. {∅,{b₁}} or
{{b₂},{b₁,b₂}}; Tr_B(𝒜₁) is a pair agreeing on b₁, i.e. {∅,{b₂}} or {{b₁},{b₁,b₂}}. All
four combinations give a union of size 3, never 4. So no such B is shattered. Hence
VC(𝒜) = d for d ≥ 1.

d = 0 refutation. C = C' = ∅ forces P = P' = ∅, so 𝒜 = {∅, {x}}, which shatters {x}:
VC = 1 ≠ 0 = d. The file's own inequality 2^d + 1 < 2^{d+1} already fails at d = 0
(2 < 2 is false), so this is a stated-scope omission rather than a hidden error, but the
Lean statement must carry 1 ≤ d.

### 5(e) Even-prefix class

**Verdict: CONFIRMED on all four counts (VC = 1, exact window defect, k = 2 correctness,
K3 unboundedness of the flattening number), with one substantive additional finding:
k = 1 already suffices, so the instance used to calibrate T2's candidate shape
"2 boundary points per free direction" in fact demands only 1.**

Setup: x₁ < ... < x_n, members P_{2j} = {x₁,...,x_{2j}} for 0 ≤ 2j ≤ n. Let m = ⌊n/2⌋, so
|𝒜| = m + 1.

VC = 1 (n ≥ 2). No pair {x_i, x_j} with i < j is shattered: members are prefixes, so
x_j ∈ S implies x_i ∈ S, and the pattern (out, in) never occurs. {x₁} is shattered (∅ and
P₂). For n ≤ 1 the class is {∅} and VC = 0, so the statement needs n ≥ 2.

Exact window defect on the full window A = {x₁,...,x_n}.
|Tr_A(𝒜)| = |𝒜| = m + 1 (all members are subsets of A and are pairwise distinct).
sh_A: ∅ is shattered; {x_i} is shattered iff some member contains x_i (i.e. i ≤ 2m) and
some member omits it (∅ always works); no 2-set is shattered. So |sh_A| = 1 + 2m and

  **defect on the full n-window = ⌊n/2⌋ exactly** (n/2 for even n, (n−1)/2 for odd n).

Spot checks: n = 2 gives the diagonal class and defect 1; n = 3 gives Tr 2, sh 3, defect 1;
n = 4 gives Tr 3, sh 5, defect 2. Unbounded defect at VC 1, as claimed.

The k = 2 scheme. Given a realizable sample (A,T) with T = A ∩ P_{2j}, note T is an
order-prefix of A. Let ℓ = index of the largest element of T (if T ≠ ∅) and f = index of
the smallest element of A ∖ T (if A ≠ T); then ℓ < f. Kernel Z = {x_ℓ, x_f} where both
exist, else the single available one, else ∅. Convention:
* ρ({x_p, x_q}, {x_p}) with p < q := P_{e(q)} where e(q) := largest even integer ≤ q − 1;
* ρ({x_q}, ∅) := P_{e(q)};
* ρ({x_p}, {x_p}) := P_{o(p)} where o(p) := smallest even integer ≥ p;
* ρ(∅,∅) := ∅.

Correctness, case by case.
* Mixed sample. The true member is P_{2j} with ℓ ≤ 2j ≤ f − 1, so an even number lies in
  [ℓ, f−1] and hence ℓ ≤ 2j ≤ e(f) ≤ f − 1. Now P_{e(f)} ∩ A = {x_i ∈ A : i ≤ e(f)}. Every
  x_i ∈ T has i ≤ ℓ ≤ e(f), so T ⊆ P_{e(f)} ∩ A. Every x_i ∈ A ∖ T has i ≥ f > e(f), so
  the reverse inclusion holds. Equal.
* All-out sample (T = ∅, A ≠ ∅). f = min index of A. P_{e(f)} ∩ A = ∅ since every index in
  A is ≥ f > e(f). Correct. (e(f) ≥ 0 always, with P₀ = ∅ when f = 1.)
* All-in sample (T = A ≠ ∅). ℓ = max index of A. Realizability gives an even 2j ≥ ℓ with
  2j ≤ n, so o(ℓ) ≤ n and P_{o(ℓ)} is a member. Every index of A is ≤ ℓ ≤ o(ℓ), so
  P_{o(ℓ)} ∩ A = A. Correct.
* Empty window. Trivial.
* "Sample missing boundary points" is not a separate case: the kernel is defined from
  points present in A, and points of the ground strictly between x_ℓ and x_f are outside
  the window, so their labels are unconstrained. This is precisely the file's "gap points
  are outside the window". Correct.

Worked instance (n = 6, 𝒜 = {∅, P₂, P₄, P₆}): A = {x₂,x₃,x₅} with true member P₄ gives
T = {x₂,x₃}, f = 5, e(5) = 4, P₄ ∩ A = {x₂,x₃}. With P₂: T = {x₂}, f = 3, e(3) = 2,
P₂ ∩ A = {x₂}. With P₆: all-in, ℓ = 5, o(5) = 6, P₆ ∩ A = A. With ∅: f = 2, e(2) = 0,
∅ ∩ A = ∅. All correct.

**Additional finding: k = 1 suffices.** In the mixed case the reconstruction above uses
only f, never ℓ. So take Z := {x_f} when an out-point exists in the sample, Z := {x_ℓ}
when the sample is nonempty and all-in, and Z := ∅ when A = ∅, with the same ρ (which is
already a function of (Z,W) alone, the label W distinguishing the two singleton cases).
The three verifications above are unchanged. Hence HasKernelScheme 𝒜 1 for the even-prefix
class. This does not refute anything the file says (it claims only that k = 2 suffices,
which is implied), but it does undercut the calibration in T2: line 194 proposes
"boundary-pairs per free direction (even-prefix pattern generalized: 2 per direction
→ f = 2d)", and the calibrating instance actually pays 1 per direction. The proposed
constant is inflated by the example it was read off. Recommend recomputing the T2 shape
against an instance where 2 per direction is provably necessary, or the shape is being
fitted to a non-tight datum.

**K3, global flattening number.** Take "flattening" to mean: a set Z of conditioning
points such that for every labeling W, the residual {S ∈ 𝒜 : Z ∩ S = W} is window-flat.
First, characterize flat subchains. For 𝒞 = {P_{2j} : j ∈ J}, J ⊆ {0,...,m}, on the full
window: |Tr| = |J|, and {x_i} is shattered iff 2·min J < i ≤ 2·max J, so
|sh| = 1 + 2(max J − min J) and defect = 1 + 2Δ − |J| with Δ := max J − min J. Since
|J| ≤ Δ + 1, defect ≥ Δ, so **defect = 0 forces Δ = 0, i.e. |J| ≤ 1**. So every residual
must be a single member (or empty). Hence Z must separate all m + 1 members, i.e.
|Tr_Z(𝒜)| = m + 1. Separating P_{2j} from P_{2j+2} requires a point x_i ∈ Z with
2j < i ≤ 2j + 2; these m intervals are pairwise disjoint, so |Z| ≥ m. Conversely
Z = {x₂, x₄, ..., x_{2m}} separates all members. **The global flattening number is exactly
⌊n/2⌋**, unbounded at VC 1. K3 CONFIRMED, and with it both stated consequences: total
twist mass is not the compression price (mass ⌊n/2⌋ versus kernel 1), and the global
flattening number is not bounded by any f(d).

### 5(f) Circular arcs on n ≥ 4 cyclic points

**Verdict: CONFIRMED, VC = 3.** Class: all arcs (sets of cyclically consecutive points),
including ∅ and the full circle.

VC ≥ 3, exhibited at n = 4 on B = {p₀,p₁,p₂}: ∅ from arc {p₃}; {p₀} from [p₀,p₀];
{p₁} from [p₁,p₁]; {p₂} from [p₂,p₂]; {p₀,p₁} from [p₀,p₁]; {p₁,p₂} from [p₁,p₂];
**{p₀,p₂} from the wrap-around arc [p₂,p₀] = {p₂,p₃,p₀}**, which realizes the pattern
(1,0,1); {p₀,p₁,p₂} from [p₀,p₂], the pattern (1,1,1). All 8 patterns, so B is shattered.
For general n ≥ 4 take any three points that are not all consecutive-with-no-gap in the
sense that some gap exists between p₂ and p₀; with n ≥ 4 a gap point always exists, so the
same argument runs.

VC ≤ 3. Let q₁,q₂,q₃,q₄ be any four points, indexed in cyclic order. The alternating
pattern {q₁,q₃} is unrealizable. Suppose an arc S has q₁,q₃ ∈ S and q₂,q₄ ∉ S. Then S is
neither ∅ nor the full circle, so its complement is also an arc, and it contains q₂ and
q₄. Any arc containing two points contains all the points on at least one of the two
circular paths between them; the path from q₂ to q₄ one way contains q₃, the other way
contains q₁. Either way the complement meets {q₁,q₃}, contradiction. So no 4-set is
shattered, and VC = 3 exactly. The K4 correction in the file is right and the discarded
"VC = 2" was indeed wrong.

---

## Item 6. A4 audit of D1 to D8

**Verdict: GAP.** No definition is vacuous and no hypothesis is decorative in the D-layer,
but three L-layer propositions are **trivially true as typed**, and two definitions are
**ill-typed without finiteness side conditions** because of `Set.ncard`'s behaviour on
infinite sets. Each is concrete and fixable; none is cosmetic.

### The two questions asked directly

**Is twist as defined actually equal to the slack when L2 holds?** Yes. In ℕ,
a ∸ b ∸ c = a ∸ (b + c). L2 gives defect_A ≥ defect₀ + defect₁, so the truncation is
inactive and D8 equals the integer slack defect_A − defect₀ − defect₁. Combined with the
exact identity derived in item 2, D8 also equals
#{B ⊆ A∖{x} : 𝒜 shatters B and neither child does}.

**What does it read as when it would be negative?** Exactly 0. This is the danger: any
failure of L2 is silently rendered as twist = 0 rather than as a contradiction, so "twist
≥ 0" cannot be used as a check on L2, and a Lean proof of "twist ≥ 0" would be
`Nat.zero_le _` and would prove nothing.

### Concrete flags

**F-a. `Set.ncard` returns 0 on infinite sets. D4 and D7 are unguarded.**
D4 (`IsKernel`) asserts `Z.ncard ≤ k`. If Z is infinite, `Z.ncard = 0 ≤ k` holds, so D4
accepts infinite kernels. It is rescued only through D5, where `IsSample` supplies
`A.Finite` and `Z ⊆ A`. D4 in isolation, or D4 reused in any lemma that does not carry
`A.Finite`, is wrong. Same hazard in D7: with A infinite both `ncard`s can be 0 and
`defect 𝒜 A = 0` becomes trivially true, so a class quantified as "window-flat for all A"
gets free wins on infinite windows. Fix: put `A.Finite` into D7 (or index defect by a
`Finset`), and put `Z.Finite` or `Z ⊆ A` with `A.Finite` into D4.

**F-b. L1 as phrased is contentless.** "L1 (defect ≥ 0 per window)" with D7's ℕ-valued
defect is `Nat.zero_le _`. The content of Pajor is `|Tr_A(𝒜)| ≤ |sh_A(𝒜)|` and that is
what must be stated and used. The file's own annotation says the shipped lemma is
`ncard_image_inter_le_ncard_shatters`, which has the right shape, so this is a phrasing
defect in the L-layer line, but it is the kind that survives into a Lean file and then
gets cited as if it carried the inequality.

**F-c. L2 as phrased is half contentless.** "L2 (split superadditivity; twist ≥ 0)": the
second conjunct is again `Nat.zero_le`. State L2 as
`defect_{A∖x}(𝒜₀) + defect_{A∖x}(𝒜₁) ≤ defect_A(𝒜)` (nontrivial in ℕ, since the addition
is on the right of the ≤ and no truncation occurs), or better as the exact identity from
item 2. Recommendation for BP2: keeping ℕ is fine, but only if every L-layer statement is
written as an inequality between sums, never as a statement about a difference.

**F-d. D8 needs `x ∈ A`.** Nothing in D8 requires x ∈ A. For x ∉ A the children still
partition 𝒜 but trace additivity fails (the two children can produce the same trace on A),
the slack can be genuinely negative, and D8 then reads 0 by truncation. Concretely, with
the counterexample of item 3 (𝒜 = {{x},{y},{z},{x,y,z}}, A = {x,y}, split at z ∉ A) the
integer slack is 0 − 0 − 1 = −1 and D8 reads 0. Junk value, silently.

**F-e. D5' `price` has two edge defects.** (1) "least c such that a scheme with |I| = c
exists": for 𝒜 = ∅ (or any class with no realizable samples other than the empty window)
c = 0 is achievable with I = ∅, so `price = 0`, contradicting the panel's "d = 0:
price = 1 at k = 0". Either require `1 ≤ c` or restrict to nonempty classes. (2) The value
is a *cardinal* (the supremum over fibers of a chromatic number), and ℕ∞ collapses all
infinite chromatic numbers to one point; if T3 is ever to give a quantitative lower bound
above ℵ₀ this is lossy. Both are minor but both are the kind of thing that makes a
"price = 1" theorem statement not mean what it should.

**F-f. D9 untyped means T2, T3, T6 currently have no formal content.** The file says this
plainly (BP1), which is A4-honest, but the consequence should be recorded: KU1 and KU4 are
not yet statuses of propositions, they are statuses of prose. The one thing that can be
done before D9 exists is the calibration gate (KU-cal), and I would add: state and prove
the exact twist identity (item 2) first, since any alignment structure will be a structure
*on that set of B's*, and its type is currently unconstrained partly because the set has
not been named.

**F-g. Non-vacuity checks that pass.** D1 is not trivially true (fails for 𝒜 = ∅ or
T ⊄ A) and not trivially false. D2 is a genuine subclass, empty exactly when no member is
consistent, and correctly degenerate (empty) when W ⊄ Z. D5 is not trivially true: for
𝒜 = P({a,b}) and k = 1 there are four samples on the window {a,b} but only three usable
(Z,W) pairs of size ≤ 1 whose reconstructions are forced pairwise distinct, so no size-1
scheme exists; and it is not trivially false, by 5(c). D6's `freeSets 𝒜 ∅ ∅ A` does reduce
to `sh_A(𝒜)` since `residual 𝒜 ∅ ∅ = 𝒜`, so D7 measures what it claims. The hypothesis
`Z ⊆ A` in D4 is load-bearing, not decorative: without it the labeling `Z ∩ T` would report
"out" for kernel points outside the window, which is not information the sample carries.
L5 and L6 are correct as stated (residual ⊆ 𝒜 plus monotone shattering gives the size
bound; freeSets ⊆ {B ⊆ A : |B| ≤ d} gives the binomial sum).

**F-h. Bookkeeping.** Section 1.3 reports "4 T-Abbrev, 2 T-Prop, 2 T-Parametric,
1 T-Break", but the annotations in 1.2 mark 3 T-Abbrev (D2, D3, D6), 2 T-Prop (D1, D5),
1 T-Parametric (D5'), 1 T-Break (D9), and leave D4, D7, D8 unmarked. The tally does not
match the list. Non-mathematical, but the profile-distribution claim ("no homogeneity
warning") is derived from the tally.

---

## Item 7. F3, thresholdClass window-flatness

**Verdict: CONFIRMED.** I checked the definition in the corpus:
`thresholdClass : ConceptClass ℚ Bool := Set.range fun θ : ℚ => fun x : ℚ => decide (x ≤ θ)`
(ProcessFrame.lean:160), i.e. in set grammar 𝒜 = {(-∞, θ] ∩ ℚ : θ ∈ ℚ}.

Let A = {q₁ < q₂ < ... < q_n} ⊆ ℚ.

Traces. A ∩ {x ≤ θ} = {q_i : q_i ≤ θ}, an order-prefix of A. Every prefix occurs: θ = q_j
gives the prefix of length j, and θ = q₁ − 1 gives ∅ (ℚ has no least element, and this is
where the choice of ℚ as ground matters). So |Tr_A| = n + 1.

Shattered sets. ∅ is shattered. Each {q_i} is shattered: θ = q_i gives the pattern {q_i},
θ = q_i − 1 gives ∅. No pair {q_i, q_j} with i < j is shattered: the pattern {q_j} needs
q_j ≤ θ < q_i, impossible since q_i < q_j. So |sh_A| = 1 + n.

Hence defect = 0 on every finite window (window-flat everywhere) and VC = 1 exactly
(for n ≥ 1 some singleton is shattered; no pair ever is). Both stated counts are n + 1,
as claimed. CONFIRMED.

---

## Addendum: two results derived during this review that the file does not have

### A1. The exact twist identity (repairs and strengthens L2)

twist_x(𝒜, A) = #{ B ⊆ A ∖ {x} : 𝒜 shatters B, 𝒜₀ does not shatter B, 𝒜₁ does not
shatter B }, for x ∈ A finite. Derivation in item 2. This converts L2 from an inequality
with a ℕ-subtraction into an identity between two counts, which is both easier to prove in
Lean and immune to flag F-c.

### A2. Window monotonicity of defect: KU9 is resolved, with direction

**Claim. For A ⊆ A' finite, defect_A(𝒜) ≤ defect_{A'}(𝒜).**

Proof. It suffices to add one point x ∉ A, with A' = A ∪ {x}.
* Traces: |Tr_{A'}(𝒜)| = |Tr_A(𝒜₀)| + |Tr_A(𝒜₁)| by item 2(a), while
  Tr_A(𝒜) = Tr_A(𝒜₀) ∪ Tr_A(𝒜₁) since 𝒜 = 𝒜₀ ⊔ 𝒜₁. Inclusion and exclusion give
  |Tr_{A'}(𝒜)| − |Tr_A(𝒜)| = |Tr_A(𝒜₀) ∩ Tr_A(𝒜₁)|.
* Skeletons: sets in sh_{A'}(𝒜) omitting x are exactly sh_A(𝒜); sets containing x are
  exactly {B ∪ {x} : B ∈ sh_A(𝒜₀) ∩ sh_A(𝒜₁)} by the two-way characterization proved in
  item 2. So |sh_{A'}(𝒜)| − |sh_A(𝒜)| = |sh_A(𝒜₀) ∩ sh_A(𝒜₁)|.
* Therefore defect_{A'}(𝒜) − defect_A(𝒜) = |sh_A(𝒜₀) ∩ sh_A(𝒜₁)| − |Tr_A(𝒜₀) ∩ Tr_A(𝒜₁)|.
* Put 𝒯 := Tr_A(𝒜₀) ∩ Tr_A(𝒜₁), a family of subsets of A, viewed as a class on ground A.
  Pajor applied to 𝒯 on the window A gives |𝒯| = |Tr_A(𝒯)| ≤ |sh_A(𝒯)|. And 𝒯 ⊆ Tr_A(𝒜_b)
  for b = 0,1, so by monotonicity of shattering sh_A(𝒯) ⊆ sh_A(Tr_A(𝒜_b)) = sh_A(𝒜_b).
  Hence |𝒯| ≤ |sh_A(𝒜₀) ∩ sh_A(𝒜₁)| and the difference is ≥ 0. QED

Checks: 𝒜 = {∅,{x,z}} with A = {x} (defect 0) and A' = {x,z} (defect 1): the formula gives
1 − 0 = 1. Full cube on {x,z}: 2 − 2 = 0, and both defects are 0.

Consequences. (i) KU9's "direction unknown" is answered: defect is monotone
non-decreasing in the window, so flatness is inherited downward by subwindows. (ii) For a
finite ground, flatness on the full ground implies window-flat everywhere, which makes
"window-flat everywhere" checkable in one shot on finite grounds. (iii) The repaired global
L3 of item 3 follows. (iv) Note this does **not** rescue the unscoped L3: monotonicity
compares different windows for the *same* class, whereas the item-3 counterexample compares
the same window for a class and its residual.

---

## Summary table

| # | Claim | Verdict | Locator / condition |
|---|-------|---------|---------------------|
| 1a | two-map form ⟺ convention form | CONFIRMED | uses AC (Skolemisation) and total extension of ρ by junk |
| 1b | fixed κ: correct ρ iff fibers pairwise compatible | CONFIRMED | witness is H = ⋃ T_i; works for infinite fibers, no compactness. Requires fiber over (Z,W) not Z, and improper reconstruction. Both readings otherwise false (counterexamples given) |
| 1c | with I: correct ρ iff each fiber's incompatibility graph is \|I\|-colorable | CONFIRMED | same two conditions; graph is irreflexive and symmetric; colourings chosen per fiber |
| 2a | exact trace additivity | CONFIRMED | equality of families on the x = 0 part, bijection T ↦ T∖{x} on the x = 1 part |
| 2b | skeleton superadditivity via two injections | CONFIRMED | both images verified inside sh_A(𝒜), disjoint by x-membership; strengthened to an exact identity (Addendum A1) |
| 2c | defect superadditivity by subtraction | CONFIRMED | all three subtractions genuine by Pajor on parent and both children |
| 3 | defect 0 propagates to children and to all in-window residuals | CONFIRMED as scoped | needs Z ⊆ A. Unscoped version REFUTED: 𝒜 = {{x},{y},{z},{x,y,z}}, A = {x,y}, condition on z = 1 takes defect 0 to 1. "No new hypothesis" is inaccurate |
| 4 | join trace and skeleton multiplicativity, Leibniz defect, twist scaling | CONFIRMED | both directions of skeleton multiplicativity proved; twist scaling exact, and the cross term vanishes precisely by 2(a) |
| 5a | diagonal: defect 1, twist 1, VC 1 | CONFIRMED | Tr 2, sh 3 |
| 5b | chain: defect 0, VC 1, size-1 scheme | CONFIRMED | Tr 3, sh 3; all 8 sample/subwindow cases and all 3 fibers tabulated. Narrative gap: "address ∩ window" needs the ⊆-least-member selection rule |
| 5c | singleton class: flat, size-1 scheme, K2 | CONFIRMED | Tr = sh = n+1; determining sets need \|Z\| ≥ \|A\| |
| 5d | free cube pair: VC = d, both labels rank-preserving | CONFIRMED for d ≥ 1; REFUTED at d = 0 (VC = 1) | file's count 2^d+1 < 2^{d+1} covers only x ∈ B; the x ∉ B case at d = 1 needs a hand check, supplied |
| 5e | even-prefix: VC 1, defect growth, k = 2 scheme, K3 | CONFIRMED | defect on the n-window is exactly ⌊n/2⌋; flattening number exactly ⌊n/2⌋. Additional finding: k = 1 already suffices, so T2's "2 per direction" is calibrated on a non-tight instance |
| 5f | circular arcs, n ≥ 4: VC = 3 | CONFIRMED | (1,0,1) via wrap-around, (1,1,1) direct; (1,0,1,0) impossible since the complement of an arc is an arc |
| 6 | A4 audit of D1 to D8 | GAP | ncard-on-infinite-sets makes D4 and D7 unguarded; "L1: defect ≥ 0" and "L2: twist ≥ 0" are `Nat.zero_le` as typed; D8 needs x ∈ A; D5' price has an edge value 0 and a cardinal collapse; D9 untyped means T2/T3/T6 are not yet propositions; section 1.3 tally does not match the annotations |
| 7 | thresholdClass window-flat everywhere, VC 1 | CONFIRMED | Tr = sh = n+1 on every n-window; uses that ℚ has no least element to realize the empty trace |
| A1 | exact twist identity (new) | DERIVED HERE | twist counts B shattered by the parent and by neither child |
| A2 | defect is monotone in the window (new) | DERIVED HERE | resolves KU9 with direction; proof is Pajor applied to the intersection of the two child trace families |

---

## Claims outside items 1 to 7 that I consider wrong or gapped

Scanned the whole file once for this purpose. Corpus pointers were checked against the
working tree at `learning-theory/` (not the `sauer-shelah` branch of mean-fourier, which is
not present here).

**O1. F2's "Kill A1" is not a kill, and the Prop it names is FALSE as typed.**
`AppendOnlyForcedGrowth` (ProcessFrame.lean:170) reads

    ∀ k, ∃ l, realizable l ∧ ∀ sel : AppendOnlyKernelSelector ℚ thresholdClass,
              k < (sel.select l).card

The quantifier order is ∃ l ∀ sel. The adversarial-bisection argument in its own docstring
is adaptive: the adversary must see `reconstruct (select l_i)` before choosing the next
label, which establishes ∀ sel ∃ l, not ∃ l ∀ sel. And the ∃ l ∀ sel form is refutable.
Given any realizable list l₀, realized by the threshold c_{θ*}, define
select l := ∅ if l is a prefix of l₀, else l.toFinset; and
reconstruct K x := if (x,true) ∈ K then true else if (x,false) ∈ K then false else c_{θ*} x.
Then `select_sub` holds (∅ ⊆ anything, l.toFinset ⊆ l.toFinset); `append_only` holds (the
prefix predicate is prefix-closed, so the only transitions are ∅ ⊆ ∅, ∅ ⊆ anything, and
points(l) ⊆ points(l ++ [p])); `anytime_correct` holds (on prefixes of l₀ the
reconstruction is c_{θ*}, which realizes l₀ hence every prefix; off l₀ the kernel carries
every labeled point of l, consistent by realizability). This selector has
`(select l₀).card = 0`, so the inner ∀ sel fails at k = 0 for every candidate l₀. Hence
`AppendOnlyForcedGrowth` is false. Note also that the Lean docstring itself says
"proof = adversarial bisection, scheduled", i.e. unproved; the URS nevertheless reports R5
as "CLOSED with kill verdicts" and derives a **consequence for D9** ("the alignment is an
OFFLINE/GLOBAL structure; any prefix-committed monotone mechanism dies at VC 1"). That
consequence is currently resting on a false proposition. The intended kill (∀ sel ∃ l) is,
by my sketch above, very likely provable and would support the same D9 conclusion, but it
is a different statement and has to be restated before it can be cited.

**O2. F0's "`Open_NoInfoCompressionStrengthening` (Structures.lean:268) ≡ the weak form"
is a GAP, and the Prop has a decorative binder.** As typed,

    ∀ X (C : ConceptClass X Bool), VCDim X C < ⊤ → ∃ (k : ℕ) (cs : CompressionScheme X Bool C), cs.size = k

The `∃ k` is vacuous: `∃ k, ∃ cs, cs.size = k` is equivalent to
`Nonempty (CompressionScheme X Bool C)`. So the Prop carries **no size content at all**,
whereas `LittlestoneWarmuthWeak = ∃ f, ∀ X C d, VCDim ≤ d → ∃ cs, cs.size ≤ f d` demands a
bound uniform in d across all classes and all ground types. Weak ⟹ Open_NoInfo is
immediate; the converse needs a uniformisation argument (given classes C_n of VC ≤ d
needing size > n, form the one-hot disjoint-union class over Σ_{n} X_n, check its VC is
still ≤ d, and restrict a scheme for it to each component). That argument is available and
uses countable choice at `Type u`, but it is not stated, and "≡" should not be asserted
until it is. This is the same class of A4 defect as F-b and F-e in item 6: a Prop that
reads as a theorem statement but whose binder carries nothing.

**O3. Pass 3's "the flat bijection (class ↔ skeleton, forced by defect 0)" overstates what
defect 0 gives.** defect_A(𝒜) = 0 gives |Tr_A(𝒜)| = |sh_A(𝒜)|, an equality of
cardinalities. A *canonical* bijection, and in particular one coherent under restriction
(which is what an addressing needs), is not forced by a count. The file half-admits this
one line later in T1 ("The cascade's canonicity is the open sub-question"), but the Pass 3
sentence reads as though the bijection were derived. It is not; it is precisely the content
of T1a. Also, the object in bijection with the skeleton is the trace family on the window,
not the class (a class may have many members per trace).

**O4. The set/sequence bridge in F0 is a surjection, not a correspondence, and the safe
direction should be recorded.** The kernel's `CompressionScheme.compress` takes
`Fin m → X × Y` (an ordered sample with repeats) and its `reconstruct` takes a
`Finset (X × Y)`, so the compressed object is order-free. Good. But the compression map may
still depend on the order and multiplicity of the sample, while a set-grammar scheme sees
only (A,T). So set-grammar schemes inject into sequence-grammar schemes and not
conversely. T5 ⟹ `LittlestoneWarmuthLinear` is therefore the safe direction, which is the
direction the file wants, so nothing is broken; but "realizable samples ↔ (A,T) window
pairs" should not be written as a two-way correspondence, and "repeats harmless" is true
only for the direction being used.

**O5. Pass 5's "ONE unit per stage" and "two boundary points pay for the whole chain" are
both off by the finding in 5(e).** One boundary point pays. The per-stage twist of 1 is
correct (verified at n = 4, split at x₁). The kernel count is not.

**O6. Line 195's "Known-dead shape: global flattening number ≤ f(d) (K3)" is correct, but
the price panel's "Flat: price = 1 at k = d (T1)" is a conjecture presented in a table of
"calibration points".** The panel does label it (T1), so this is a presentation risk
rather than an error: three of the four panel entries (flat, general d, LW) are not
established at the base, and only "d = 0: price = 1 at k = 0" is, which I verified
(VC ≤ 0 with 𝒜 nonempty forces all members equal, since any point in a symmetric
difference would be shattered; then k = 0 and ρ(∅,∅) = the unique member). Subject to
flag F-e(1) about 𝒜 = ∅.

**O7. F5's lemma names could not be checked here.** `ncard_image_inter_le_ncard_shatters`
and `HasVCDimLE.ncard_image_inter_le` do not appear anywhere in the design-lab working
tree. The file attributes them to the `sauer-shelah` branch of mean-fourier, which is not
checked out, so this is an unverified pointer rather than a wrong one. Since L1 is the
engine of everything in item 2 and item 3, its shipped statement should be quoted verbatim
in the URS (in the form |Tr| ≤ |sh|, per flag F-b) rather than referred to by name.

**O8. Not audited, by scope.** F1's reading of the kernel audit ("side information enters
ONLY at the dual-VC sparsification backend"), F4's counting-barrier cap at d, and the
claim that `FractionalMY` / `moran_yehudayoff_forward_construction` /
`fundamental_vc_compression` are the right glue targets are statements about proofs I did
not re-derive. I confirm only that `FractionalCompressionScheme` (IR.lean:103),
`LWAt`/`LittlestoneWarmuthLinear`/`LittlestoneWarmuthWeak` (IR.lean, near the stated
lines), `CompressionSchemeWithInfo` (Structures.lean:215) and
`CompressionScheme.reconstruct : Finset (X × Y) → (X → Y)` (Structures.lean, near 40 to 56)
exist with the shapes the URS reports. F1's central claim, that the kernel's reconstruction
already depends on the compressed Finset alone, is correct.
