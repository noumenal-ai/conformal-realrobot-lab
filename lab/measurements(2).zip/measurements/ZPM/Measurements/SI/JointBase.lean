/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Abstract
import ZPM.Measurements.HC.GrahamBridge
import ZPM.Measurements.SI.Scheme

/-!
# Reconstruction as a global section over the labeled-subsample cover

Sample compression (Littlestone and Warmuth, 1986) asks for one reconstruction rule,
fixed before any sample is seen, under which every realizable sample is regenerated
from at most `k` of its own labeled points. The rule is a single global object; the
condition on it is stated one sample at a time. This file types that gap.

Two statements, one negative and one positive.

The negative one measures the joint between the conjecture's premise and its
conclusion at the level of individual assertions. Worlds are pairs (a family, a
reconstruction rule); assertions are of three kinds, trace assertions shared by both
sides, freedom assertions on the premise side, and routing assertions on the
conclusion side; and the admissible worlds are those whose rule serves every sample of
their family. `jointDecomposable` shows that this class of worlds amalgamates
outright: any two admissible worlds agreeing on every trace assertion have a common
admissible world agreeing with the first on freedom assertions and the second on
routing assertions. Freedom is definable from traces, so the assertion-level split
carries no coupling, and no measurement at that level can separate the two sides.

The positive one works one level up, on the cover rather than on points. Each
realizable sample carries a scope, the labeled subsamples of at most `k` of its own
points, and a reconstruction rule is an assignment of a value to every labeled
subsample. `hasKernelScheme_of_acyclic_localSystem` states that a pairwise consistent
family of local constraints whose scopes form an acyclic cover assembles into one
global rule, hence into a kernel scheme. The mathematical weight is carried by the
amalgamation theorem for acyclic covers (`glues_of_acyclic`, after Vorob'ev and
Graham); what is stated here is the encoding: which hypergraph the compression problem
puts on the labeled subsamples.

`scope_subset_scope` records the obstacle that encoding meets. A sample sitting inside
another sample has its scope inside the other's scope, so the cover is nested, and
nested scopes are what pairwise consistency of disjunctive local relations fails on.

Main declarations:

* `Subsample`, `scope`, `mem_scope`: labeled subsamples and the scope of a sample.
* `scope_subset_scope`: scopes are monotone along sample restriction.
* `Serves`, `hasKernelScheme_of_serves`: a global assignment serving every realizable
  sample is a kernel scheme.
* `JointFormula`, `jointSat`, `jointKappa`, `jointDecomposable`: the assertion-level
  premise-to-conclusion relation and its unconditional amalgamation.
* `hasKernelScheme_of_acyclic_localSystem`: acyclic scopes plus pairwise consistency
  give a scheme.
* `AcyclicLocalSystemExists`: the statement that a class of bounded VC dimension
  admits such a local system at kernel size linear in the bound. Stated, not proved.
-/

namespace StructuralIgnorance

open Finset HiddenChannelCapacity

variable {α : Type*} [DecidableEq α]

/-! ### Labeled subsamples and scopes -/

/-- A **labeled subsample**: a finite set of kept points together with the part of them
labeled 1. This is the datum a reconstruction rule reads (Littlestone and Warmuth,
1986). -/
abbrev Subsample (α : Type*) := Finset α × Finset α

/-- The **scope** of the sample `(A, T)` at kernel budget `k`: the labeled subsamples of
at most `k` of the sample's own points, with the labels the sample gives them. These are
the only data a size-`k` scheme may read on this sample. -/
def scope (k : ℕ) (A T : Finset α) : Finset (Subsample α) :=
  (A.powerset.filter fun Z => #Z ≤ k).image fun Z => (Z, Z ∩ T)

theorem mem_scope {k : ℕ} {A T : Finset α} {i : Subsample α} :
    i ∈ scope k A T ↔ ∃ Z ⊆ A, #Z ≤ k ∧ i = (Z, Z ∩ T) := by
  constructor
  · intro hi
    obtain ⟨Z, hZ, hZi⟩ := Finset.mem_image.mp hi
    obtain ⟨hZA, hZk⟩ := Finset.mem_filter.mp hZ
    exact ⟨Z, Finset.mem_powerset.mp hZA, hZk, hZi.symm⟩
  · rintro ⟨Z, hZA, hZk, rfl⟩
    exact Finset.mem_image.mpr
      ⟨Z, Finset.mem_filter.mpr ⟨Finset.mem_powerset.mpr hZA, hZk⟩, rfl⟩

/-- The empty labeled subsample is in every scope. -/
theorem empty_mem_scope {k : ℕ} {A T : Finset α} : ((∅ : Finset α), (∅ : Finset α)) ∈
    scope k A T :=
  mem_scope.mpr ⟨∅, Finset.empty_subset _, by simp, by simp⟩

private theorem inter_inter_of_subset {Z T A : Finset α} (h : Z ⊆ A) :
    Z ∩ (T ∩ A) = Z ∩ T := by
  ext x
  simp only [Finset.mem_inter]
  exact ⟨fun hx => ⟨hx.1, hx.2.1⟩, fun hx => ⟨hx.1, hx.2, h hx.1⟩⟩

/-- **Scopes are nested along sample restriction.** A sample sitting inside another
sample, with the labels inherited, has its scope inside the other's scope. -/
theorem scope_subset_scope {k : ℕ} {A₁ T₁ A₂ T₂ : Finset α}
    (hA : A₁ ⊆ A₂) (hT : T₁ = T₂ ∩ A₁) : scope k A₁ T₁ ⊆ scope k A₂ T₂ := by
  intro i hi
  obtain ⟨Z, hZA, hZk, rfl⟩ := mem_scope.mp hi
  refine mem_scope.mpr ⟨Z, hZA.trans hA, hZk, ?_⟩
  rw [hT, inter_inter_of_subset (hZA)]

/-- The nesting is already strict on a two-point ground, so the cover of scopes is a
genuinely nested family rather than an antichain. -/
theorem scope_ssubset_of_two_points :
    scope 1 ({0} : Finset (Fin 2)) {0} ⊂ scope 1 ({0, 1} : Finset (Fin 2)) {0} := by
  decide

/-- The cover a class puts on labeled subsamples at budget `k`: one scope per sample.
Only the samples and `k` occur in it, so acyclicity of this cover is a property of the
class's traces alone. It is decidable through `HiddenChannelCapacity.decidableAcyclic`. -/
def sampleCover (k : ℕ) (S : List (Finset α × Finset α)) :
    Finset (Finset (Subsample α)) :=
  (S.map fun p => scope k p.1 p.2).toFinset

/-! ### Serving a sample, and the scheme it induces -/

/-- The assignment `f` **serves** the sample `(A, T)` at budget `k`: some labeled
subsample in the sample's scope carries a value meeting the window in exactly `T`. -/
def Serves (k : ℕ) (f : Subsample α → Finset α) (A T : Finset α) : Prop :=
  ∃ i ∈ scope k A T, f i ∩ A = T

/-- A single assignment serving every realizable sample is a kernel scheme of size `k`
with no side information. -/
theorem hasKernelScheme_of_serves {𝒜 : Set (Set α)} {k : ℕ}
    (f : Subsample α → Finset α)
    (hf : ∀ A T : Finset α, IsSample 𝒜 A T → Serves k f A T) :
    HasKernelScheme 𝒜 k := by
  refine ⟨fun Z W => ↑(f (Z, W)), fun A T hAT => ?_⟩
  obtain ⟨i, hi, hival⟩ := hf A T hAT
  obtain ⟨Z, hZA, hZk, rfl⟩ := mem_scope.mp hi
  refine ⟨Z, hZA, hZk, ?_⟩
  rw [← Finset.coe_inter, hival]

/-! ### The assertion-level premise-to-conclusion relation -/

/-- The three kinds of assertion the conjecture makes: a **trace** assertion, that a
label pattern occurs on a window, which both sides read; a **freedom** assertion, that a
set is shattered, on the premise side; and a **routing** assertion, that the rule serves
a sample, on the conclusion side. -/
inductive JointFormula (α : Type*)
  /-- The pattern `T` occurs on the window `A`. -/
  | trace (A T : Finset α)
  /-- The set `B` is shattered. -/
  | free (B : Finset α)
  /-- The rule serves the sample `(A, T)`. -/
  | routes (A T : Finset α)

/-- Satisfaction for a world, a family together with a reconstruction rule. -/
def jointSat (k : ℕ) (w : Finset (Finset α) × (Subsample α → Finset α)) :
    JointFormula α → Prop
  | .trace A T => ∃ S ∈ w.1, S ∩ A = T
  | .free B => ∀ C ⊆ B, ∃ S ∈ w.1, S ∩ B = C
  | .routes A T => Serves k w.2 A T

/-- Trace assertions are the shared vocabulary. -/
def IsSharedJ : JointFormula α → Prop
  | .trace _ _ => True
  | .free _ => False
  | .routes _ _ => False

/-- The premise side reads trace and freedom assertions. -/
def IsLeftJ : JointFormula α → Prop
  | .trace _ _ => True
  | .free _ => True
  | .routes _ _ => False

/-- The conclusion side reads trace and routing assertions. -/
def IsRightJ : JointFormula α → Prop
  | .trace _ _ => True
  | .free _ => False
  | .routes _ _ => True

/-- Two worlds are **trace-equivalent** when they satisfy the same trace assertions. -/
def SharedEqJ (k : ℕ) (w₁ w₂ : Finset (Finset α) × (Subsample α → Finset α)) : Prop :=
  ∀ φ : JointFormula α, IsSharedJ φ → (jointSat k w₁ φ ↔ jointSat k w₂ φ)

/-- The **premise-to-conclusion relation**: the worlds whose rule serves every
realizable sample of their family. -/
def jointKappa (k : ℕ) : Set (Finset (Finset α) × (Subsample α → Finset α)) :=
  {w | ∀ A T : Finset α, (∃ S ∈ w.1, S ∩ A = T) → Serves k w.2 A T}

/-- Trace assertions cannot distinguish trace-equivalent worlds. -/
theorem sharedInvariantJ (k : ℕ) :
    SharedInvariant (World := Finset (Finset α) × (Subsample α → Finset α))
      (jointSat k) (SharedEqJ k) IsSharedJ :=
  fun _ hφ _ _ h => h _ hφ

/-- **The assertion-level joint carries no coupling.** Any two admissible worlds
agreeing on every trace assertion have a common admissible world agreeing with the
first on the premise side and with the second on the conclusion side. Amalgamation is
unconditional here, so at this level the premise-to-conclusion relation factors and no
measurement of the joint can be nonzero. The reason is that freedom is definable from
traces: the family component is fixed by the shared vocabulary, and the rule component
is unconstrained by the premise side. -/
theorem jointDecomposable (k : ℕ) :
    IsDecomposable (jointSat k) (SharedEqJ k) IsLeftJ IsRightJ
      (jointKappa (α := α) k) (∅ : Set (JointFormula α)) := by
  rintro w₁ w₂ ⟨hw₁, -⟩ ⟨hw₂, -⟩ hEq
  refine ⟨(w₁.1, w₂.2), ⟨?_, by simp⟩, ?_, ?_⟩
  · intro A T hT
    exact hw₂ A T (hEq (.trace A T) trivial |>.mp hT)
  · rintro (⟨A, T⟩ | ⟨B⟩ | ⟨A, T⟩) hφ
    · exact Iff.rfl
    · exact Iff.rfl
    · exact absurd hφ not_false
  · rintro (⟨A, T⟩ | ⟨B⟩ | ⟨A, T⟩) hφ
    · exact hEq (.trace A T) trivial
    · exact absurd hφ not_false
    · exact Iff.rfl

/-! ### The cover of scopes, and gluing -/

section Cover

variable [Fintype α]

/-- A single scope is an acyclic cover. -/
theorem acyclic_singleton {ι : Type*} [DecidableEq ι] (T : Finset ι) :
    Acyclic ({T} : Finset (Finset ι)) :=
  ⟨[T], List.nodup_singleton T, by simp, ⟨Or.inl rfl, trivial⟩⟩

/-- **A cover of at most two scopes is acyclic.** The pair is a running-intersection
order in either direction, since the two scopes meet inside the second one. Together with
`HiddenChannelCapacity.speckerCover_not_acyclic`, which exhibits three scopes admitting
no such order, this places the first possible obstruction at three scopes: below that
arity, pairwise consistent local data always assemble. -/
theorem acyclic_pair {ι : Type*} [DecidableEq ι] (T₁ T₂ : Finset ι) :
    Acyclic ({T₁, T₂} : Finset (Finset ι)) := by
  by_cases h : T₁ = T₂
  · subst h
    simpa using acyclic_singleton T₁
  · refine ⟨[T₁, T₂], by simp [h], by simp, ?_, Or.inl rfl, trivial⟩
    refine Or.inr ⟨T₂, List.mem_singleton_self _, ?_⟩
    simp [listCover]

/-- **A pairwise consistent local system with acyclic scopes assembles into a kernel
scheme.** Each member of `fam` constrains an assignment on its own scope; the scopes sit
inside the scopes the samples themselves provide, and every assignment a member admits
already serves the corresponding sample. When the scopes form an acyclic cover, the
amalgamation theorem for acyclic covers produces one global assignment realizing every
member, and that assignment is a reconstruction rule of kernel size `k` with no side
information.

The gluing step is `glues_of_acyclic` (Vorob'ev's condition in Graham's ear form); what
is proper to compression here is the encoding of the problem as constraints on labeled
subsamples. -/
theorem hasKernelScheme_of_acyclic_localSystem {𝒜 : Set (Set α)} {k : ℕ}
    (fam : List (LocalStruct (Subsample α) (fun _ => Finset α)))
    (hne : ∀ L ∈ fam, L.rel.Nonempty)
    (hsound : ∀ A T : Finset α, IsSample 𝒜 A T →
      ∃ L ∈ fam, L.team ⊆ scope k A T ∧
        ∀ g ∈ L.rel, ∃ i : {x // x ∈ L.team}, g i ∩ A = T)
    (hcons : Consistent fam)
    (hnd : (fam.map (·.team)).Nodup)
    (hacyc : Acyclic (fam.map (·.team)).toFinset) :
    HasKernelScheme 𝒜 k := by
  classical
  obtain ⟨κ, hκ⟩ := glues_of_acyclic fam hcons hnd hacyc
  rcases fam with _ | ⟨L₀, rest⟩
  · refine ⟨fun _ _ => ∅, fun A T hAT => ?_⟩
    obtain ⟨L, hL, -⟩ := hsound A T hAT
    exact absurd hL (List.not_mem_nil)
  · obtain ⟨g₀, hg₀⟩ := hne L₀ List.mem_cons_self
    rw [← hκ L₀ List.mem_cons_self] at hg₀
    obtain ⟨f, hfκ, -⟩ := Finset.mem_image.mp hg₀
    refine hasKernelScheme_of_serves f fun A T hAT => ?_
    obtain ⟨L, hL, hLscope, hLsound⟩ := hsound A T hAT
    obtain ⟨i, hival⟩ := hLsound (L.team.restrict f)
      (by rw [← hκ L hL]; exact Finset.mem_image_of_mem _ hfκ)
    exact ⟨(i : Subsample α), hLscope i.2, hival⟩

omit [Fintype α] in
/-- **The hypotheses are jointly satisfiable.** A class with a single member carries the
local system built from one constraint on the empty labeled subsample, so the gluing
statement above is not vacuous: its premises hold together, and its conclusion is the
compression of a class of VC dimension 0. -/
theorem exists_localSystem_of_singleton (C : Finset α) (k : ℕ) :
    ∃ fam : List (LocalStruct (Subsample α) (fun _ => Finset α)),
      (∀ L ∈ fam, L.rel.Nonempty) ∧
      (∀ A T : Finset α, IsSample {(C : Set α)} A T →
        ∃ L ∈ fam, L.team ⊆ scope k A T ∧
          ∀ g ∈ L.rel, ∃ i : {x // x ∈ L.team}, g i ∩ A = T) ∧
      Consistent fam ∧ (fam.map (·.team)).Nodup ∧
      Acyclic (fam.map (·.team)).toFinset := by
  classical
  refine ⟨[⟨{((∅ : Finset α), (∅ : Finset α))}, {fun _ => C}⟩], ?_, ?_, ?_, ?_, ?_⟩
  · intro L hL
    rw [List.mem_singleton.mp hL]
    exact Finset.singleton_nonempty _
  · intro A T hAT
    refine ⟨_, List.mem_singleton_self _,
      Finset.singleton_subset_iff.mpr empty_mem_scope, fun g hg => ?_⟩
    refine ⟨⟨((∅ : Finset α), (∅ : Finset α)), Finset.mem_singleton_self _⟩, ?_⟩
    rw [Finset.mem_singleton.mp hg]
    obtain ⟨S, hS, hSA⟩ := hAT
    rw [Set.mem_singleton_iff] at hS
    subst hS
    rw [Finset.inter_comm]
    exact_mod_cast hSA
  · intro L₁ h₁ L₂ h₂
    rw [List.mem_singleton.mp h₁, List.mem_singleton.mp h₂]
  · exact List.nodup_singleton _
  · simpa using acyclic_singleton ({((∅ : Finset α), (∅ : Finset α))} : Finset (Subsample α))

/-- **The residual statement.** Some universal `K` gives every class of VC dimension at
most `d`, over every finite ground, a local system of the kind above at kernel size
`K * (d + 1)`: scopes inside the samples' own scopes, every admitted assignment already
serving its sample, pairwise consistent, with an acyclic cover. This is what the base
geometry would have to supply; it is stated here and not proved. -/
def AcyclicLocalSystemExists : Prop :=
  ∃ K : ℕ, ∀ (α : Type) [Fintype α] [DecidableEq α] (𝒜 : Set (Set α)) (d : ℕ),
    vcBounded 𝒜 d →
    ∃ fam : List (LocalStruct (Subsample α) (fun _ => Finset α)),
      (∀ L ∈ fam, L.rel.Nonempty) ∧
      (∀ A T : Finset α, IsSample 𝒜 A T →
        ∃ L ∈ fam, L.team ⊆ scope (K * (d + 1)) A T ∧
          ∀ g ∈ L.rel, ∃ i : {x // x ∈ L.team}, g i ∩ A = T) ∧
      Consistent fam ∧ (fam.map (·.team)).Nodup ∧
      Acyclic (fam.map (·.team)).toFinset

/-- The residual statement gives the linear compression conjecture over finite grounds
with no side information. -/
theorem hasKernelScheme_of_acyclicLocalSystemExists (h : AcyclicLocalSystemExists) :
    ∃ K : ℕ, ∀ (α : Type) [Fintype α] [DecidableEq α] (𝒜 : Set (Set α)) (d : ℕ),
      vcBounded 𝒜 d → HasKernelScheme 𝒜 (K * (d + 1)) := by
  obtain ⟨K, hK⟩ := h
  refine ⟨K, fun α _ _ 𝒜 d hd => ?_⟩
  obtain ⟨fam, hne, hsound, hcons, hnd, hacyc⟩ := hK α 𝒜 d hd
  exact hasKernelScheme_of_acyclic_localSystem fam hne hsound hcons hnd hacyc

end Cover

end StructuralIgnorance
