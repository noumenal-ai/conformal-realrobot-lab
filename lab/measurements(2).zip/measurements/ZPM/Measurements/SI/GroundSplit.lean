/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.CyclicConverse
import ZPM.Measurements.SI.Scheme

/-!
# Ground covers, window presentations, and the two-block degeneracy

A concept class over a finite ground domain, viewed as a set of global label
assignments, carries a *window presentation*: a list of local structures whose
teams cover the domain and whose relations are the class's own window traces. Two
properties of such a presentation are read off the cover alone and never mention a
compression scheme: the cover's **acyclicity** (decidable through the Graham
bridge) and its **width**. Two further properties compare the presentation to the
class: **constraint completeness** (the class is exactly what its windows allow)
and **interface pinning** (the labels on a window determine the state on it).

The first result is negative and bounds the arity from below.
`acyclic_pair` shows that *every* two-team cover admits a running-intersection
order, so `glues_of_twoBlockSplit` makes every pairwise-consistent family over a
shared interface with two private blocks glue. A ground split into two private
halves therefore hosts no gluing obstruction at all: the whole positive Vorob'ev
machinery discharges it for free, and any measurement taken there reports on the
marginals rather than on a coupling. `tripleCover_fin4_not_acyclic` marks the other
side: the cover by all three-point windows of a four-point domain is already
ear-free, so the arity-three local closure is where cycles begin.

The second result is the anti-inflation guard on vocabulary extension. Enlarging
the state alphabet at each ground point can turn a cyclic cover acyclic, and
nothing stops it from also smuggling the answer into the alphabet.
`eq_of_labels_eq` closes that door: once every window's interface is pinned by its
labels and the teams cover the domain, a class member is determined by its labels,
so the enlarged alphabet is a re-encoding carrying no information the labels did
not already carry. Geometry changes; the class does not.

`sweepConvention` is the reconstruction rule an elimination order supplies: return
the labels of the first enumerated member consistent with the kept labeled points.
`ReadOffAtWidth` and `GroundGeometryLW` name the open claims that a presentation of
bounded width delivers a kernel scheme of size linear in the VC dimension, and that
every VC-bounded class admits such a presentation. Neither is proved here.
-/

namespace StructuralIgnorance.GroundSplit

open Finset HiddenChannelCapacity

/-! ### The two-block degeneracy -/

section Pair

variable {ι : Type*} [DecidableEq ι]

/-- Every two-team cover admits a running-intersection order: the first team meets
the second inside the second. A ground split into a shared interface and two
private blocks therefore has an acyclic nerve. -/
theorem acyclic_pair (T₁ T₂ : Finset ι) : Acyclic ({T₁, T₂} : Finset (Finset ι)) := by
  by_cases h : T₁ = T₂
  · subst h
    exact ⟨[T₁], by simp, by simp, Or.inl rfl, trivial⟩
  · refine ⟨[T₁, T₂], by simp [h], by simp, ⟨Or.inr ⟨T₂, by simp, ?_⟩, Or.inl rfl, trivial⟩⟩
    simp only [listCover, Finset.union_empty]
    exact Finset.inter_subset_right

end Pair

section PairFamily

variable {ι : Type*} [DecidableEq ι] [Fintype ι]
variable {X : ι → Type*} [∀ i, DecidableEq (X i)] [∀ i, Fintype (X i)] [∀ i, Nonempty (X i)]

/-- **The two-block collapse.** Over a ground split into a shared interface and two
private blocks, every pairwise-consistent family of local structures glues. The
positive Vorob'ev theorem discharges the split outright, so no gluing obstruction
can live at this arity. -/
theorem glues_of_twoBlockSplit (L₁ L₂ : LocalStruct ι X) (hne : L₁.team ≠ L₂.team)
    (hcons : Consistent [L₁, L₂]) : Glues [L₁, L₂] := by
  refine glues_of_acyclic _ hcons (by simpa using hne) ?_
  simpa using acyclic_pair L₁.team L₂.team

end PairFamily

/-- The cover of a four-point domain by all three-point windows is ear-free, hence
not acyclic. The arity-three local closure of a class — the cover the
Sauer/shattering vocabulary hands you for VC dimension two — already hosts a cycle
on the smallest domain that admits one. -/
theorem tripleCover_fin4_not_acyclic :
    ¬ Acyclic ((Finset.univ : Finset (Fin 4)).powersetCard 3) := by decide

/-! ### Window presentations -/

section Presentation

variable {ι : Type*} [DecidableEq ι] [Fintype ι]
variable {X : ι → Type*} [∀ i, DecidableEq (X i)] [∀ i, Fintype (X i)] [∀ i, Nonempty (X i)]

/-- The observable label carried by each state at each ground point. -/
abbrev Readout (X : ι → Type*) := ∀ i, X i → Bool

/-- The class as the labels display it: each state assignment yields the set of
ground points it labels `true`. -/
def observedClass (κ : Finset (∀ i, X i)) (lab : Readout X) : Set (Set ι) :=
  {S | ∃ f ∈ κ, S = {i | lab i (f i) = true}}

/-- The local relations are the class's own window traces: the cover displays what
the class does on each window and adds nothing. -/
def TracedByWindows (κ : Finset (∀ i, X i)) (fam : List (LocalStruct ι X)) : Prop :=
  ∀ L ∈ fam, L.rel = projS κ L.team

/-- The cover sees every constraint: the class is exactly the assignments passing
every window test, so no coupling survives that the windows cannot express. -/
def ConstraintComplete (κ : Finset (∀ i, X i)) (fam : List (LocalStruct ι X)) : Prop :=
  joinFam fam = κ

/-- Every window of the cover holds at most `w` ground points. -/
def WindowWidth (fam : List (LocalStruct ι X)) (w : ℕ) : Prop := ∀ L ∈ fam, #L.team ≤ w

/-- The labels pin the interface: on every window, two class traces carrying the
same labels are the same trace. This is what the enlarged alphabet must pay back
for the geometry it buys. -/
def LabelsPinInterface (κ : Finset (∀ i, X i)) (lab : Readout X)
    (fam : List (LocalStruct ι X)) : Prop :=
  ∀ L ∈ fam, ∀ g₁ ∈ projS κ L.team, ∀ g₂ ∈ projS κ L.team,
    (∀ i : L.team, lab i (g₁ i) = lab i (g₂ i)) → g₁ = g₂

/-- The teams reach every ground point. -/
def CoversGround (fam : List (LocalStruct ι X)) : Prop := famCover fam = Finset.univ

/-! Every base-geometry premise is decidable: it is settled by inspecting the cover
and the class, with no reference to any reconstruction rule. -/

instance decidableTracedByWindows (κ : Finset (∀ i, X i)) (fam : List (LocalStruct ι X)) :
    Decidable (TracedByWindows κ fam) := by
  unfold TracedByWindows; infer_instance

instance decidableConstraintComplete (κ : Finset (∀ i, X i))
    (fam : List (LocalStruct ι X)) : Decidable (ConstraintComplete κ fam) := by
  unfold ConstraintComplete; infer_instance

instance decidableWindowWidth (fam : List (LocalStruct ι X)) (w : ℕ) :
    Decidable (WindowWidth fam w) := by
  unfold WindowWidth; infer_instance

instance decidableCoversGround (fam : List (LocalStruct ι X)) :
    Decidable (CoversGround fam) := by
  unfold CoversGround; infer_instance

instance decidableLabelsPinInterface (κ : Finset (∀ i, X i)) (lab : Readout X)
    (fam : List (LocalStruct ι X)) : Decidable (LabelsPinInterface κ lab fam) := by
  unfold LabelsPinInterface; infer_instance

omit [Fintype ι] [∀ i, DecidableEq (X i)] [∀ i, Fintype (X i)] [∀ i, Nonempty (X i)] in
/-- A ground point lies in the cover exactly when some team holds it. -/
lemma mem_famCover {fam : List (LocalStruct ι X)} {i : ι} :
    i ∈ famCover fam ↔ ∃ L ∈ fam, i ∈ L.team := by
  induction fam with
  | nil => simp [famCover]
  | cons L rest ih => simp [famCover, Finset.mem_union, ih]

omit [∀ i, Fintype (X i)] [∀ i, Nonempty (X i)] in
/-- **The vocabulary extension carries no information.** Once the teams cover the
domain and every window's interface is pinned by its labels, two class members with
the same labels everywhere are the same member. Enlarging the state alphabet to buy
acyclicity therefore cannot smuggle the answer into the alphabet: the enlarged
object is a re-encoding of the class, not an enrichment of it. -/
theorem eq_of_labels_eq {κ : Finset (∀ i, X i)} {lab : Readout X}
    {fam : List (LocalStruct ι X)} (hcover : CoversGround fam)
    (hpin : LabelsPinInterface κ lab fam)
    {f g : ∀ i, X i} (hf : f ∈ κ) (hg : g ∈ κ)
    (h : ∀ i, lab i (f i) = lab i (g i)) : f = g := by
  funext i
  have hi : i ∈ famCover fam := by rw [hcover]; exact Finset.mem_univ i
  obtain ⟨L, hL, hiL⟩ := mem_famCover.mp hi
  have hfr : L.team.restrict f ∈ projS κ L.team := Finset.mem_image_of_mem _ hf
  have hgr : L.team.restrict g ∈ projS κ L.team := Finset.mem_image_of_mem _ hg
  have := hpin L hL _ hfr _ hgr (fun j => h j)
  exact congrFun this ⟨i, hiL⟩

omit [DecidableEq ι] [Fintype ι] [∀ i, Fintype (X i)] [∀ i, Nonempty (X i)] in
/-- When each point's readout is injective on states, every interface is pinned. The
Boolean vocabulary pins itself for free; an enlarged alphabet pays for the geometry
it buys precisely by losing this injectivity. -/
theorem labelsPinInterface_of_injective {κ : Finset (∀ i, X i)} {lab : Readout X}
    (hinj : ∀ i, Function.Injective (lab i)) (fam : List (LocalStruct ι X)) :
    LabelsPinInterface κ lab fam := by
  intro L _ g₁ _ g₂ _ h
  funext i
  exact hinj i (h i)

/-- A kept labeled pair is consistent with a state assignment when the assignment's
labels on the kept points match the kept positive part. -/
def consistentWith (lab : Readout X) (Z W : Finset ι) (f : ∀ i, X i) : Bool :=
  decide (∀ i ∈ Z, (lab i (f i) = true ↔ i ∈ W))

/-- **The reconstruction rule an elimination order supplies.** Return the labels of
the first enumerated member consistent with the kept labeled points; on a kept pair
no member explains, return the kept positive part. The order is the datum: an
acyclic cover's running-intersection order enumerates the class, and that
enumeration is the well-order a least-member convention needs. -/
def sweepConvention (lab : Readout X) (enum : List (∀ i, X i)) : Convention ι :=
  fun Z W =>
    match enum.find? (consistentWith lab Z W) with
    | some f => {i | lab i (f i) = true}
    | none => (W : Set ι)

end Presentation

/-! ### The open claims -/

/-- **The read-off claim at width `w`.** A class presented by an acyclic ground
cover of width `w`, complete for its constraints and pinned by its labels,
compresses at kernel size `w * (d + 1)` whenever the class it displays has VC
dimension at most `d`. The acyclicity is not asked for gluing — the class itself
already realizes its own traces — but for the elimination order: the well-order the
convention runs along, and the tree along which the join factorizes so that the
class's free choices are detectable one window at a time. -/
def ReadOffAtWidth (w : ℕ) : Prop :=
  ∀ (ι : Type) [DecidableEq ι] [Fintype ι] (X : ι → Type)
    [∀ i, DecidableEq (X i)] [∀ i, Fintype (X i)] [∀ i, Nonempty (X i)]
    (κ : Finset (∀ i, X i)) (lab : Readout X) (fam : List (LocalStruct ι X)) (d : ℕ),
    CoversGround fam →
    TracedByWindows κ fam →
    ConstraintComplete κ fam →
    (fam.map (·.team)).Nodup →
    Acyclic (fam.map (·.team)).toFinset →
    WindowWidth fam w →
    LabelsPinInterface κ lab fam →
    vcBounded (observedClass κ lab) d →
    HasKernelScheme (observedClass κ lab) (w * (d + 1))

/-- **The base-geometry replacement for the compression conjecture.** Every
VC-bounded class over a finite ground domain admits a label-faithful re-encoding
whose window cover is acyclic at width linear in the VC dimension. The quantifier
over reconstruction rules — an uncountable function space — is replaced by a
quantifier over state alphabets and covers, of which the cover half is decidable
instance by instance through the Graham bridge. -/
def GroundGeometryLW : Prop :=
  ∃ K : ℕ, ∀ (ι : Type) [DecidableEq ι] [Fintype ι] (𝒜 : Set (Set ι)) (d : ℕ),
    vcBounded 𝒜 d →
    ∃ (X : ι → Type) (_ : ∀ i, DecidableEq (X i)) (_ : ∀ i, Fintype (X i))
      (_ : ∀ i, Nonempty (X i)) (κ : Finset (∀ i, X i)) (lab : Readout X)
      (fam : List (LocalStruct ι X)),
      observedClass κ lab = 𝒜 ∧
      CoversGround fam ∧
      TracedByWindows κ fam ∧
      ConstraintComplete κ fam ∧
      (fam.map (·.team)).Nodup ∧
      Acyclic (fam.map (·.team)).toFinset ∧
      WindowWidth fam (K * (d + 1)) ∧
      LabelsPinInterface κ lab fam

/-! ### A ground domain that satisfies every base-geometry premise -/

/-- The monotone class on a four-point chain: the assignments that never label a
point `true` and a later point `false`. Its observed form is the threshold class. -/
def chainClass : Finset (∀ _ : Fin 4, Bool) :=
  Finset.univ.filter fun f => ∀ i j : Fin 4, i ≤ j → f i = true → f j = true

/-- The Boolean readout: the state at a point is its label. -/
def chainLab : Readout (fun _ : Fin 4 => Bool) := fun _ b => b

/-- The consecutive-pair cover of the chain, carrying the class's own window
traces. -/
def chainFam : List (LocalStruct (Fin 4) (fun _ => Bool)) :=
  [⟨{0, 1}, projS chainClass {0, 1}⟩,
   ⟨{1, 2}, projS chainClass {1, 2}⟩,
   ⟨{2, 3}, projS chainClass {2, 3}⟩]

theorem chain_traced : TracedByWindows chainClass chainFam := by decide

theorem chain_covers : CoversGround chainFam := by decide

theorem chain_nodup : (chainFam.map (·.team)).Nodup := by decide

theorem chain_acyclic : Acyclic (chainFam.map (·.team)).toFinset := by decide

theorem chain_width : WindowWidth chainFam 2 := by decide

theorem chain_pin : LabelsPinInterface chainClass chainLab chainFam :=
  labelsPinInterface_of_injective (fun _ _ _ h => h) chainFam

/-- The consecutive-pair cover is complete for the chain's constraints: an
assignment passing every adjacent test is monotone. The cover, three windows of two
points each, sees every constraint of a class whose defining condition ranges over
all six ordered pairs. -/
theorem chain_complete : ConstraintComplete chainClass chainFam := by decide

/-- Two ordered points of the chain are never shattered: the pattern that labels the
earlier point `true` and the later one `false` is unrealizable. -/
private theorem chain_no_shatter {B : Finset (Fin 4)} {x y : Fin 4}
    (hB : SetShatters (observedClass chainClass chainLab) B)
    (hx : x ∈ B) (hy : y ∈ B) (hlt : x < y) : False := by
  obtain ⟨S, hS, hBS⟩ := hB {x} (Finset.singleton_subset_iff.mpr hx)
  obtain ⟨f, hf, rfl⟩ := hS
  have hmono : ∀ i j : Fin 4, i ≤ j → f i = true → f j = true :=
    (Finset.mem_filter.mp hf).2
  have hxS : chainLab x (f x) = true := by
    have hx' : (x : Fin 4) ∈ ((({x} : Finset (Fin 4)) : Set (Fin 4))) := by simp
    rw [← hBS] at hx'
    exact hx'.2
  have hyS : chainLab y (f y) = true := hmono x y hlt.le hxS
  have hy' : (y : Fin 4) ∈ ((({x} : Finset (Fin 4)) : Set (Fin 4))) := by
    rw [← hBS]
    exact ⟨Finset.mem_coe.mpr hy, hyS⟩
  simp only [Finset.coe_singleton, Set.mem_singleton_iff] at hy'
  exact absurd hy'.symm (ne_of_lt hlt)

/-- The chain's observed class has VC dimension at most one: no two points are
shattered, because a member labelling the earlier point `true` labels the later one
`true` as well. -/
theorem chain_vcBounded : vcBounded (observedClass chainClass chainLab) 1 := by
  intro B hB
  rw [Finset.card_le_one]
  intro x hx y hy
  rcases lt_trichotomy x y with hlt | heq | hgt
  · exact (chain_no_shatter hB hx hy hlt).elim
  · exact heq
  · exact (chain_no_shatter hB hy hx hgt).elim

/-! ### Where the premises pull against each other

The chain satisfies every premise at width two. The interval class on the same four
points does not, and the three ways it fails are the three ways a presentation can
be bought. Each is settled by `decide` on the cover and the class alone. -/

/-- The interval class on a four-point chain: the assignments whose `true` points are
contiguous. Its VC dimension is two. -/
def intervalClass : Finset (∀ _ : Fin 4, Bool) :=
  Finset.univ.filter fun f =>
    ∀ i j k : Fin 4, i ≤ j → j ≤ k → f i = true → f k = true → f j = true

/-- The consecutive-triple cover: two windows, hence acyclic. -/
def intervalNarrow : List (LocalStruct (Fin 4) (fun _ => Bool)) :=
  [⟨{0, 1, 2}, projS intervalClass {0, 1, 2}⟩,
   ⟨{1, 2, 3}, projS intervalClass {1, 2, 3}⟩]

/-- The cover by all three-point windows: complete for the contiguity constraint,
since every violating triple sits inside a window. -/
def intervalWide : List (LocalStruct (Fin 4) (fun _ => Bool)) :=
  [⟨{0, 1, 2}, projS intervalClass {0, 1, 2}⟩,
   ⟨{0, 1, 3}, projS intervalClass {0, 1, 3}⟩,
   ⟨{0, 2, 3}, projS intervalClass {0, 2, 3}⟩,
   ⟨{1, 2, 3}, projS intervalClass {1, 2, 3}⟩]

theorem intervalNarrow_acyclic : Acyclic (intervalNarrow.map (·.team)).toFinset := by decide

/-- The acyclic cover is blind to a constraint: the assignment labelling only the two
endpoints `true` passes both consecutive triples and is not an interval. -/
theorem intervalNarrow_not_complete : ¬ ConstraintComplete intervalClass intervalNarrow := by
  decide

theorem intervalWide_complete : ConstraintComplete intervalClass intervalWide := by decide

/-- The complete cover hosts a cycle: no ordering of the four three-point windows is
a running-intersection order. -/
theorem intervalWide_not_acyclic : ¬ Acyclic (intervalWide.map (·.team)).toFinset := by
  decide

/-- The three-state re-encoding: each point records whether it sits before, inside, or
after the interval, and the sequence of states is nondecreasing. -/
def intervalStates : Finset (∀ _ : Fin 4, Fin 3) :=
  Finset.univ.filter fun f => ∀ i j : Fin 4, i ≤ j → f i ≤ f j

/-- The readout of the three-state encoding: a point is labelled `true` when its state
is the middle one. -/
def intervalStateLab : Readout (fun _ : Fin 4 => Fin 3) := fun _ s => decide (s = 1)

/-- The consecutive-pair cover of the three-state encoding. -/
def intervalStateFam : List (LocalStruct (Fin 4) (fun _ => Fin 3)) :=
  [⟨{0, 1}, projS intervalStates {0, 1}⟩,
   ⟨{1, 2}, projS intervalStates {1, 2}⟩,
   ⟨{2, 3}, projS intervalStates {2, 3}⟩]

/-- The re-encoding displays exactly the interval class. -/
theorem intervalStates_displays :
    intervalStates.image (fun f i => intervalStateLab i (f i)) = intervalClass := by decide

theorem intervalStates_acyclic :
    Acyclic (intervalStateFam.map (·.team)).toFinset := by decide

theorem intervalStates_complete :
    ConstraintComplete intervalStates intervalStateFam := by decide

/-- The price of the re-encoding: the labels no longer pin the interface. The states
`before` and `after` carry the same label, so a window's label pattern leaves the
state undetermined, and a reconstruction rule reading labels alone cannot tell which
side of the interval it is on. -/
theorem intervalStates_not_pinned :
    ¬ LabelsPinInterface intervalStates intervalStateLab intervalStateFam := by decide

/-! ### The layered claim

The trilemma above rules out asking one cover to carry a whole class. What survives
is a cover of the class by pieces: the seed's labels select the piece, and the piece
carries the acyclic cover. The interval class is the threshold class once its left
endpoint is named, and naming that endpoint costs one labelled ground point rather
than one bit of side information. -/

/-- The Boolean readout: the state at a point is its label. -/
def boolReadout {ι : Type} : Readout (fun _ : ι => Bool) := fun _ b => b

/-- The piece of the class cut out by a labelled seed: the members whose labels on the
seed match the seed's positive part. This is the seed's version space. -/
def piece {ι : Type} [DecidableEq ι] [Fintype ι] (κ : Finset (∀ _ : ι, Bool))
    (Z W : Finset ι) : Finset (∀ _ : ι, Bool) :=
  κ.filter fun f => ∀ i ∈ Z, (f i = true ↔ i ∈ W)

/-- **The layered read-off claim.** Suppose every realizable window pattern contains a
seed of at most `k` labelled points whose version space carries an acyclic ground
cover of width `w`, complete for that version space's constraints. Then the class
compresses at kernel size `k` with no side information: the seed is the kernel, and
the reconstruction is the sweep the version space's elimination order supplies.

Nothing in the premise mentions a reconstruction rule. The seed is chosen after the
sample, the version space is cut from the class by the seed's labels alone, and both
acyclicity and completeness are decided by inspecting the cover. The side information
of the known constructions is what appears when the piece cannot be named by labelled
ground points and must be named by an index instead. -/
def LayeredReadOff (k w : ℕ) : Prop :=
  ∀ (ι : Type) [DecidableEq ι] [Fintype ι] (κ : Finset (∀ _ : ι, Bool)),
    (∀ A T : Finset ι, IsSample (observedClass κ boolReadout) A T →
      ∃ Z ⊆ A, #Z ≤ k ∧
        ∃ fam : List (LocalStruct ι (fun _ => Bool)),
          CoversGround fam ∧
          TracedByWindows (piece κ Z (Z ∩ T)) fam ∧
          ConstraintComplete (piece κ Z (Z ∩ T)) fam ∧
          (fam.map (·.team)).Nodup ∧
          Acyclic (fam.map (·.team)).toFinset ∧
          WindowWidth fam w) →
    HasKernelScheme (observedClass κ boolReadout) k

/-- **The base-geometry replacement for the compression conjecture, layered form.**
Every VC-`d` class over a finite ground domain has, for each realizable window
pattern, a seed of at most `K * (d + 1)` labelled points whose version space carries
an acyclic Boolean ground cover of the same width. The quantifier over reconstruction
rules is replaced by a quantifier over seeds and covers, and the cover half is
decidable instance by instance through the Graham bridge. -/
def LayeredGroundGeometryLW : Prop :=
  ∃ K : ℕ, ∀ (ι : Type) [DecidableEq ι] [Fintype ι] (κ : Finset (∀ _ : ι, Bool)) (d : ℕ),
    vcBounded (observedClass κ boolReadout) d →
    ∀ A T : Finset ι, IsSample (observedClass κ boolReadout) A T →
      ∃ Z ⊆ A, #Z ≤ K * (d + 1) ∧
        ∃ fam : List (LocalStruct ι (fun _ => Bool)),
          CoversGround fam ∧
          TracedByWindows (piece κ Z (Z ∩ T)) fam ∧
          ConstraintComplete (piece κ Z (Z ∩ T)) fam ∧
          (fam.map (·.team)).Nodup ∧
          Acyclic (fam.map (·.team)).toFinset ∧
          WindowWidth fam (K * (d + 1))

/-! ### The converse leg on the ground side -/

/-- **The named obstruction.** A clean hosted cycle in the ground cover licenses
window-local label families that agree on every overlap yet no global assignment
realizes. Local data alone cannot fix the reconstruction, so the rule must be told
which branch it is on, and that message is the side information. This is
`cycle_obstruction` read at the ground cover; it is a re-export, not a new proof. -/
theorem groundCycle_blocks_reconstruction {ι : Type*} [DecidableEq ι] [Fintype ι]
    (𝒞 : Finset (Finset ι)) (l : List ι) (hnd : l.Nodup) (h3 : 3 ≤ l.length)
    (hhost : ∀ w ∈ cyclePairs l, ∃ V ∈ 𝒞, w ⊆ V)
    (hclean : ∀ V ∈ 𝒞, ∀ w₁ ∈ cyclePairs l, ∀ w₂ ∈ cyclePairs l,
      w₁ ⊆ V → w₂ ⊆ V → w₁ = w₂) :
    ∃ fam : List (LocalStruct ι (fun _ => ZMod 2)),
      fam.map (·.team) = 𝒞.toList ∧ Consistent fam ∧
      (∀ L ∈ fam, L.rel.Nonempty) ∧ ¬ Glues fam :=
  cycle_obstruction 𝒞 l hnd h3 hhost hclean

end StructuralIgnorance.GroundSplit
