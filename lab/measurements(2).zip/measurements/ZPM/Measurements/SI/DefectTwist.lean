/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.SI.DefectTwist.Combinatorial
import ZPM.Measurements.SI.DefectTwist.Join
import ZPM.Measurements.SI.DefectTwist.Window
import ZPM.Measurements.SI.DefectTwist.Twist
import ZPM.Measurements.SI.DefectTwist.VCOne
import ZPM.Measurements.SI.DefectTwist.Instances

/-!
# Defect and twist formalizations

The shatter defect of a finite set family (`shatterDefect`, the gap of Pajor's
inequality, classically the defect-Sauer quantity), its split calculus
(`splitLoss`, superadditivity, hereditary flatness), the join Leibniz rule, the
window layer (`windowDefect`, `windowDefect_mono`), symmetric-difference label
twists, and the compression results these yield at VC dimension zero and one
(`hasKernelScheme_zero_of_vcBounded_zero`, `hasKernelScheme_one_of_vcBounded_one`,
`calibrationVCOne`).
-/
