/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.SI.Scheme

/-!
# The compression conjectures at the class level

Conjecture-root propositions: `Prop`-valued definitions naming precise open
targets, with no proof obligations in this file. The pattern follows the graded
statement style of the FLT kernel's compression pipeline (`LWAt`,
`LittlestoneWarmuthLinear`).

* `BaseLW` — the linear Littlestone–Warmuth conjecture (1986) in `Set` grammar:
  some universal `K` compresses every VC-`d` class at kernel size `K * (d + 1)`
  with no side information.
* `CalibrationVCOne` — the `d = 1` gate: every VC-1 class compresses at kernel
  size 3 with no side information.

The alignment structure these statements were meant to be discharged through is
not typed here: the mechanism is under revision.
-/

namespace StructuralIgnorance

universe u

/-- The linear Littlestone–Warmuth conjecture (1986) in `Set` grammar: a universal
`K` compresses every VC-`d` class at kernel size `K * (d + 1)` with no side
information. Corresponds to the FLT kernel's `LittlestoneWarmuthLinear` through
the indicator identification of `Set (Set α)` with concept classes `α → Bool`. -/
def BaseLW : Prop :=
  ∃ K : ℕ, ∀ (α : Type u) [DecidableEq α] (𝒜 : Set (Set α)) (d : ℕ),
    vcBounded 𝒜 d → HasKernelScheme 𝒜 (K * (d + 1))

/-- The `d = 1` calibration gate: every VC-1 class compresses at kernel size 3
with no side information. -/
def CalibrationVCOne : Prop :=
  ∀ (α : Type u) [DecidableEq α] (𝒜 : Set (Set α)),
    vcBounded 𝒜 1 → HasKernelScheme 𝒜 3

end StructuralIgnorance
