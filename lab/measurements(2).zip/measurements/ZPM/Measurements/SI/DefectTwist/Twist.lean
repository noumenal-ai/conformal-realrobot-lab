/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.SI.Scheme

/-!
# Label twists

The symmetric-difference twist by a base set relabels every point of the base:
`twistClass 𝒜 S₀ = {S ∆ S₀ : S ∈ 𝒜}`. Twisting preserves shattering — patterns
correspond through the involution `C ↦ C ∆ (B ∩ S₀)` — hence VC bounds
(`vcBounded_twistClass`); it transports realizable samples with the label set
twisted inside the window (`IsSample.twist`); and it transports kernel schemes
back WITH THE SAME KERNELS (`HasKernelScheme.of_twistClass`): the reconstruction
conjugates by the twist, `ρ(Z, W) = ρ'(Z, W ∆ (Z ∩ S₀)) ∆ S₀`. Twisting by a
member manufactures `∅` in the class (`empty_mem_twistClass`) — the
normalization step for anchor arguments over the membership order.
-/

namespace StructuralIgnorance

open Finset
open scoped symmDiff

variable {α : Type*} [DecidableEq α]

omit [DecidableEq α] in
/-- The class relabeled by symmetric difference with a base set. -/
def twistClass (𝒜 : Set (Set α)) (S₀ : Set α) : Set (Set α) :=
  (· ∆ S₀) '' 𝒜

omit [DecidableEq α] in
/-- Twisting by a member places the empty set in the class. -/
theorem empty_mem_twistClass {𝒜 : Set (Set α)} {S₀ : Set α} (h : S₀ ∈ 𝒜) :
    ∅ ∈ twistClass 𝒜 S₀ :=
  ⟨S₀, h, by simp⟩

open scoped Classical in
/-- The part of a finite window lying in the base set. -/
noncomputable def baseLabels (S₀ : Set α) (Z : Finset α) : Finset α :=
  Z.filter (· ∈ S₀)

omit [DecidableEq α] in
theorem coe_baseLabels (S₀ : Set α) (Z : Finset α) :
    (↑(baseLabels S₀ Z) : Set α) = ↑Z ∩ S₀ := by
  classical
  ext z
  simp [baseLabels, Set.mem_inter_iff]

/-- Realizability transports through the twist, with the label set twisted
inside the window. -/
theorem IsSample.twist {𝒜 : Set (Set α)} {A T : Finset α}
    (h : IsSample 𝒜 A T) (S₀ : Set α) :
    IsSample (twistClass 𝒜 S₀) A (T ∆ baseLabels S₀ A) := by
  obtain ⟨S, hS𝒜, hSA⟩ := h
  refine ⟨S ∆ S₀, ⟨S, hS𝒜, rfl⟩, ?_⟩
  rw [Finset.coe_symmDiff, coe_baseLabels, ← hSA, Set.inter_symmDiff_distrib_left]

/-- Shattering transports from the twisted class back to the original: the
witnesses untwist, and the patterns correspond through the involution
`C ↦ C ∆ (B ∩ S₀)`. -/
theorem SetShatters.of_twistClass {𝒜 : Set (Set α)} {S₀ : Set α} {B : Finset α}
    (h : SetShatters (twistClass 𝒜 S₀) B) : SetShatters 𝒜 B := by
  intro C hC
  classical
  have hC' : C ∆ baseLabels S₀ B ⊆ B := by
    intro z hz
    rcases Finset.mem_symmDiff.1 hz with ⟨hz1, _⟩ | ⟨hz1, _⟩
    · exact hC hz1
    · exact (Finset.mem_filter.1 hz1).1
  obtain ⟨S', hS', hBS'⟩ := h (C ∆ baseLabels S₀ B) hC'
  obtain ⟨S, hS𝒜, rfl⟩ := hS'
  refine ⟨S, hS𝒜, ?_⟩
  have hBS : ((↑B : Set α) ∩ S) ∆ ((↑B : Set α) ∩ S₀) = ↑C ∆ ((↑B : Set α) ∩ S₀) := by
    rw [← Set.inter_symmDiff_distrib_left, hBS', Finset.coe_symmDiff, coe_baseLabels]
  have h2 := congrArg (fun Y => Y ∆ ((↑B : Set α) ∩ S₀)) hBS
  simpa only [symmDiff_symmDiff_cancel_right] using h2

/-- VC bounds are twist-invariant (the direction needed for normalization). -/
theorem vcBounded_twistClass {𝒜 : Set (Set α)} {d : ℕ} (h : vcBounded 𝒜 d)
    (S₀ : Set α) : vcBounded (twistClass 𝒜 S₀) d :=
  fun B hB => h B hB.of_twistClass

omit [DecidableEq α] in
private theorem set_symmDiff_inter_right (s t u : Set α) :
    (s ∆ t) ∩ u = (s ∩ u) ∆ (t ∩ u) := by
  ext z
  simp only [Set.mem_symmDiff, Set.mem_inter_iff]
  grind

private theorem finset_inter_symmDiff (Z T F : Finset α) :
    Z ∩ (T ∆ F) = (Z ∩ T) ∆ (Z ∩ F) := by
  ext z
  simp only [Finset.mem_symmDiff, mem_inter]
  grind

open scoped Classical in
/-- The conjugated convention: untwist the kernel's labels, reconstruct in the
twisted class, twist the hypothesis back. -/
noncomputable def twistConvention (S₀ : Set α) (ρ : Convention α) : Convention α :=
  fun Z W => ρ Z (W ∆ baseLabels S₀ Z) ∆ S₀

/-- Kernel schemes transport back through a twist, with the same kernels. -/
theorem HasKernelScheme.of_twistClass {𝒜 : Set (Set α)} {S₀ : Set α} {k : ℕ}
    (h : HasKernelScheme (twistClass 𝒜 S₀) k) : HasKernelScheme 𝒜 k := by
  classical
  obtain ⟨ρ', hρ'⟩ := h
  refine ⟨twistConvention S₀ ρ', fun A T hAT => ?_⟩
  obtain ⟨Z, hZA, hZk, hZ⟩ := hρ' A (T ∆ baseLabels S₀ A) (hAT.twist S₀)
  refine ⟨Z, hZA, hZk, ?_⟩
  have h1 : Z ∩ baseLabels S₀ A = baseLabels S₀ Z := by
    ext z
    simp only [baseLabels, mem_inter, mem_filter]
    exact ⟨fun ⟨hz, _, hs⟩ => ⟨hz, hs⟩, fun ⟨hz, hs⟩ => ⟨hz, hZA hz, hs⟩⟩
  have hlab : Z ∩ (T ∆ baseLabels S₀ A) = (Z ∩ T) ∆ baseLabels S₀ Z := by
    calc Z ∩ (T ∆ baseLabels S₀ A)
        = (Z ∩ T) ∆ (Z ∩ baseLabels S₀ A) := finset_inter_symmDiff ..
      _ = (Z ∩ T) ∆ baseLabels S₀ Z := by rw [h1]
  have hval : twistConvention S₀ ρ' Z (Z ∩ T)
      = ρ' Z (Z ∩ (T ∆ baseLabels S₀ A)) ∆ S₀ := by
    rw [twistConvention, hlab]
  rw [hval]
  have hcoe : (↑(T ∆ baseLabels S₀ A) : Set α) = ↑T ∆ ((↑A : Set α) ∩ S₀) := by
    rw [Finset.coe_symmDiff, coe_baseLabels]
  calc (ρ' Z (Z ∩ (T ∆ baseLabels S₀ A)) ∆ S₀) ∩ (↑A : Set α)
      = (ρ' Z (Z ∩ (T ∆ baseLabels S₀ A)) ∩ (↑A : Set α)) ∆ (S₀ ∩ ↑A) :=
        set_symmDiff_inter_right ..
    _ = (↑(T ∆ baseLabels S₀ A) : Set α) ∆ (S₀ ∩ ↑A) := by rw [hZ]
    _ = (↑T ∆ ((↑A : Set α) ∩ S₀)) ∆ ((↑A : Set α) ∩ S₀) := by
        rw [hcoe, Set.inter_comm S₀]
    _ = ↑T := symmDiff_symmDiff_cancel_right _ _

end StructuralIgnorance
