/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.SI.DefectTwist.Combinatorial

/-!
# Kernel-checked instances of the defect calculus

Small families over `Fin n`, each fact discharged by `decide`.

* The diagonal pair `{∅, {0,1}}`: defect 1, entirely consumed by the split at `0`
  (both label-worlds are defect-0 singletons) — the minimal family whose
  shattered structure exceeds it.
* The chain `{∅, {0}, {0,1}}`: defect 0 — as many patterns as shattered sets.
* The initial-segment family `{∅, {0}, {0,1}, {0,1,2}}`: defect 0 on a 3-point
  window.
* The two-block even-prefix family `{∅, {0,1}, {0,1,2,3}}`: defect 2 on a 4-point
  window — the defect grows with the window while every shattered set stays a
  singleton or empty.
-/

namespace StructuralIgnorance

example : shatterDefect ({∅, {0, 1}} : Finset (Finset (Fin 2))) = 1 := by decide

example : splitLoss 0 ({∅, {0, 1}} : Finset (Finset (Fin 2))) = 1 := by decide

example : shatterDefect ({∅, {0}, {0, 1}} : Finset (Finset (Fin 2))) = 0 := by decide

example : shatterDefect ({∅, {0}, {0, 1}, {0, 1, 2}} : Finset (Finset (Fin 3))) = 0 := by
  decide

example : shatterDefect ({∅, {0, 1}, {0, 1, 2, 3}} : Finset (Finset (Fin 4))) = 2 := by
  decide

/-- The split loss of the diagonal pair at `0`, located: the single parent-
shattered set invisible to both label-worlds is `{1}` (`splitLoss_eq_card`). -/
example : ({B ∈ ({∅, {0, 1}} : Finset (Finset (Fin 2))).shatterer |
    (0 : Fin 2) ∉ B ∧ ¬(Finset.memberSubfamily 0 ({∅, {0, 1}} :
      Finset (Finset (Fin 2)))).Shatters B ∧
    ¬(Finset.nonMemberSubfamily 0 ({∅, {0, 1}} :
      Finset (Finset (Fin 2)))).Shatters B}) = {{1}} := by
  decide

end StructuralIgnorance
