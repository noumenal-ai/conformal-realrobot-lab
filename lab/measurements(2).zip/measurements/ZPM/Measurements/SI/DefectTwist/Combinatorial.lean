/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import Mathlib.Combinatorics.SetFamily.Shatter
import Mathlib.Combinatorics.SetFamily.Compression.Down

/-!
# The shatter defect and its split calculus

A finite set family `𝒜 : Finset (Finset α)` — read: the family of label patterns a
class realizes on a finite window — satisfies Pajor's inequality
`#𝒜 ≤ #𝒜.shatterer` (`Finset.card_le_card_shatterer`, Mathlib
`Combinatorics.SetFamily.Shatter`): a family never outnumbers the sets it shatters.
This file measures the gap of that inequality and how the gap moves under the case
split at a point.

* `shatterDefect 𝒜` — `#𝒜.shatterer - #𝒜`, the number of shattered sets in excess
  of the family's size. Zero exactly when the family is as large as its shattered
  structure.
* The split at `a` is Mathlib's `Finset.memberSubfamily a 𝒜` /
  `Finset.nonMemberSubfamily a 𝒜` (`Combinatorics.SetFamily.Compression.Down`):
  the two label-worlds of `a`, with
  `Finset.card_memberSubfamily_add_card_nonMemberSubfamily` giving exact
  additivity of family sizes.
* `card_shatterer_split_le` — the shattered structures of the two worlds jointly
  fit inside the parent's: either world's shattered sets transfer as they stand,
  sets shattered by both worlds lift through `insert a`, and the two contributions
  are disjoint by membership of `a`.
* `shatterDefect_split_le` — the defect is superadditive under the split: case
  analysis never creates defect.
* `splitLoss a 𝒜` — the exact remainder: the amount of defect the split at `a`
  consumes. It counts shattered structure visible to the parent that neither
  label-world carries alone. `splitLoss_add_shatterDefects` reconstructs the
  parent defect.
* `shatterDefect_memberSubfamily_eq_zero` / `..._nonMemberSubfamily_...` — zero
  defect is hereditary under conditioning.
-/

namespace StructuralIgnorance

open Finset

variable {α : Type*} [DecidableEq α] {𝒜 : Finset (Finset α)} {a : α} {s : Finset α}

/-- The gap of Pajor's inequality (`Finset.card_le_card_shatterer`): the number of
shattered sets in excess of the family's size. `shatterDefect 𝒜 = 0` says the
family is exactly as large as its shattered structure. -/
def shatterDefect (𝒜 : Finset (Finset α)) : ℕ := #𝒜.shatterer - #𝒜

/-- The subtraction in `shatterDefect` is genuine: adding the family's size back
recovers the shatterer's size. -/
theorem shatterDefect_add_card (𝒜 : Finset (Finset α)) :
    shatterDefect 𝒜 + #𝒜 = #𝒜.shatterer :=
  Nat.sub_add_cancel (card_le_card_shatterer 𝒜)

/-- A set shattered by the `a ∉ ·` world does not contain `a`. -/
theorem notMem_of_shatters_nonMemberSubfamily
    (h : (𝒜.nonMemberSubfamily a).Shatters s) : a ∉ s := fun ha => by
  obtain ⟨u, hu, hsu⟩ := h.exists_superset
  exact (mem_nonMemberSubfamily.1 hu).2 (hsu ha)

/-- A set shattered by the `a ∈ ·` world does not contain `a`. -/
theorem notMem_of_shatters_memberSubfamily
    (h : (𝒜.memberSubfamily a).Shatters s) : a ∉ s := fun ha => by
  obtain ⟨u, hu, hsu⟩ := h.exists_superset
  exact (mem_memberSubfamily.1 hu).2 (hsu ha)

/-- The `a ∉ ·` world is a subfamily of the parent. -/
theorem nonMemberSubfamily_subset : 𝒜.nonMemberSubfamily a ⊆ 𝒜 :=
  fun _ hs => (mem_nonMemberSubfamily.1 hs).1

/-- Sets shattered by the `a ∉ ·` world are shattered by the parent. -/
theorem Shatters.of_nonMemberSubfamily
    (h : (𝒜.nonMemberSubfamily a).Shatters s) : 𝒜.Shatters s :=
  h.mono_left nonMemberSubfamily_subset

/-- Sets shattered by the `a ∈ ·` world are shattered by the parent: reinsert `a`
into each witness. -/
theorem Shatters.of_memberSubfamily
    (h : (𝒜.memberSubfamily a).Shatters s) : 𝒜.Shatters s := by
  have has : a ∉ s := notMem_of_shatters_memberSubfamily h
  intro t ht
  obtain ⟨u, hu, hsu⟩ := h ht
  obtain ⟨hau, hna⟩ := mem_memberSubfamily.1 hu
  refine ⟨insert a u, hau, ?_⟩
  rw [← hsu]
  ext x
  simp only [mem_inter, mem_insert]
  grind

/-- A set shattered by both worlds lifts through `insert a` to a parent-shattered
set: patterns containing `a` are realized through the `a ∈ ·` world's witnesses,
patterns avoiding `a` through the `a ∉ ·` world's. -/
theorem shatters_insert_of_both
    (h0 : (𝒜.nonMemberSubfamily a).Shatters s)
    (h1 : (𝒜.memberSubfamily a).Shatters s) :
    𝒜.Shatters (insert a s) := by
  have has : a ∉ s := notMem_of_shatters_nonMemberSubfamily h0
  intro t ht
  by_cases hat : a ∈ t
  · have ht' : t.erase a ⊆ s := by
      intro x hx
      obtain ⟨hxa, hxt⟩ := mem_erase.1 hx
      rcases mem_insert.1 (ht hxt) with h | h
      · exact absurd h hxa
      · exact h
    obtain ⟨u, hu, hsu⟩ := h1 ht'
    obtain ⟨hau, hna⟩ := mem_memberSubfamily.1 hu
    refine ⟨insert a u, hau, ?_⟩
    have hins : insert a s ∩ insert a u = insert a (s ∩ u) := by
      ext x
      simp only [mem_inter, mem_insert]
      grind
    rw [hins, hsu, insert_erase hat]
  · have hts : t ⊆ s := by
      intro x hx
      rcases mem_insert.1 (ht hx) with h | h
      · exact absurd (h ▸ hx) hat
      · exact h
    obtain ⟨u, hu, hsu⟩ := h0 hts
    obtain ⟨huA, hnu⟩ := mem_nonMemberSubfamily.1 hu
    refine ⟨u, huA, ?_⟩
    rw [← hsu]
    ext x
    simp only [mem_inter, mem_insert]
    grind

/-- **Skeleton superadditivity.** The shattered structures of the two label-worlds
jointly fit inside the parent's: transfers as they stand for either world, the
`insert a` lift for sets shattered by both, disjointness by membership of `a`. -/
theorem card_shatterer_split_le (a : α) (𝒜 : Finset (Finset α)) :
    #(𝒜.memberSubfamily a).shatterer + #(𝒜.nonMemberSubfamily a).shatterer
      ≤ #𝒜.shatterer := by
  set S1 := (𝒜.memberSubfamily a).shatterer with hS1
  set S0 := (𝒜.nonMemberSubfamily a).shatterer with hS0
  have havoid : ∀ s ∈ S1 ∪ S0, a ∉ s := by
    intro s hs
    rcases mem_union.1 hs with h | h
    · exact notMem_of_shatters_memberSubfamily (mem_shatterer.1 h)
    · exact notMem_of_shatters_nonMemberSubfamily (mem_shatterer.1 h)
  have hU : S1 ∪ S0 ⊆ 𝒜.shatterer := by
    intro s hs
    rw [mem_shatterer]
    rcases mem_union.1 hs with h | h
    · exact Shatters.of_memberSubfamily (mem_shatterer.1 h)
    · exact Shatters.of_nonMemberSubfamily (mem_shatterer.1 h)
  have hI : (S1 ∩ S0).image (insert a) ⊆ 𝒜.shatterer := by
    intro s hs
    obtain ⟨t, ht, rfl⟩ := mem_image.1 hs
    rw [mem_shatterer]
    exact shatters_insert_of_both
      (mem_shatterer.1 (mem_inter.1 ht).2) (mem_shatterer.1 (mem_inter.1 ht).1)
  have hdisj : Disjoint (S1 ∪ S0) ((S1 ∩ S0).image (insert a)) := by
    rw [disjoint_right]
    intro s hs hsU
    obtain ⟨t, _, rfl⟩ := mem_image.1 hs
    exact havoid _ hsU (mem_insert_self a t)
  have hinj : #((S1 ∩ S0).image (insert a)) = #(S1 ∩ S0) := by
    apply card_image_of_injOn
    intro s hs s' hs' h
    have h1 : a ∉ s := havoid s (mem_union_left _ (mem_inter.1 (mem_coe.1 hs)).1)
    have h2 : a ∉ s' := havoid s' (mem_union_left _ (mem_inter.1 (mem_coe.1 hs')).1)
    rw [← erase_insert h1, h, erase_insert h2]
  calc #S1 + #S0
      = #(S1 ∪ S0) + #(S1 ∩ S0) := (card_union_add_card_inter S1 S0).symm
    _ = #(S1 ∪ S0) + #((S1 ∩ S0).image (insert a)) := by rw [hinj]
    _ = #((S1 ∪ S0) ∪ (S1 ∩ S0).image (insert a)) := (card_union_of_disjoint hdisj).symm
    _ ≤ #𝒜.shatterer := card_le_card (union_subset hU hI)

/-- **Defect superadditivity.** Case-splitting at a point never creates defect: the
two label-worlds jointly retain at most the parent's defect. With
`Finset.card_memberSubfamily_add_card_nonMemberSubfamily` (exact additivity of
family sizes) and `card_shatterer_split_le`, the subtraction bookkeeping closes. -/
theorem shatterDefect_split_le (a : α) (𝒜 : Finset (Finset α)) :
    shatterDefect (𝒜.memberSubfamily a) + shatterDefect (𝒜.nonMemberSubfamily a)
      ≤ shatterDefect 𝒜 := by
  have h1 := shatterDefect_add_card (𝒜.memberSubfamily a)
  have h0 := shatterDefect_add_card (𝒜.nonMemberSubfamily a)
  have h := shatterDefect_add_card 𝒜
  have hc := card_memberSubfamily_add_card_nonMemberSubfamily a 𝒜
  have hs := card_shatterer_split_le a 𝒜
  grind

/-- The defect consumed by the case split at `a`: the parent defect minus what the
two label-worlds retain. It counts shattered structure visible to the parent family
that neither world carries alone. Nonnegative and exact by
`splitLoss_add_shatterDefects`. -/
def splitLoss (a : α) (𝒜 : Finset (Finset α)) : ℕ :=
  shatterDefect 𝒜 - shatterDefect (𝒜.memberSubfamily a)
    - shatterDefect (𝒜.nonMemberSubfamily a)

/-- The split's accounting is exact: the two worlds' defects plus the split loss
reconstruct the parent defect. -/
theorem splitLoss_add_shatterDefects (a : α) (𝒜 : Finset (Finset α)) :
    shatterDefect (𝒜.memberSubfamily a) + shatterDefect (𝒜.nonMemberSubfamily a)
      + splitLoss a 𝒜 = shatterDefect 𝒜 := by
  have h := shatterDefect_split_le a 𝒜
  unfold splitLoss
  grind

/-- Zero defect is hereditary: the `a ∈ ·` world of a defect-zero family has zero
defect. -/
theorem shatterDefect_memberSubfamily_eq_zero (a : α) (h : shatterDefect 𝒜 = 0) :
    shatterDefect (𝒜.memberSubfamily a) = 0 := by
  have := shatterDefect_split_le a 𝒜
  grind

/-- Zero defect is hereditary: the `a ∉ ·` world of a defect-zero family has zero
defect. -/
theorem shatterDefect_nonMemberSubfamily_eq_zero (a : α) (h : shatterDefect 𝒜 = 0) :
    shatterDefect (𝒜.nonMemberSubfamily a) = 0 := by
  have := shatterDefect_split_le a 𝒜
  grind

/-- A family all of whose members avoid `a` shatters only `a`-free sets. -/
theorem notMem_of_shatters_of_forall {𝒜 : Finset (Finset α)} {a : α} {s : Finset α}
    (hall : ∀ t ∈ 𝒜, a ∉ t) (hs : 𝒜.Shatters s) : a ∉ s := fun ha => by
  obtain ⟨u, hu, hsu⟩ := hs.exists_superset
  exact hall u hu (hsu ha)

/-- The split reading of shattering an inserted point: for `x ∉ B`, the parent
shatters `insert x B` exactly when BOTH label-worlds shatter `B`. The 0-side
patterns are witnessed inside the `x ∉ ·` world; the 1-side patterns erase into
the `x ∈ ·` world. With `shatters_insert_of_both` this makes the insert-lift of
`card_shatterer_split_le` a bijection onto the `x`-containing shattered sets. -/
theorem shatters_insert_iff {𝒜 : Finset (Finset α)} {x : α} {B : Finset α}
    (hxB : x ∉ B) :
    𝒜.Shatters (insert x B) ↔
      (𝒜.memberSubfamily x).Shatters B ∧ (𝒜.nonMemberSubfamily x).Shatters B := by
  constructor
  · intro h
    constructor
    · intro C hC
      obtain ⟨u, hu, huC⟩ := h (insert_subset_insert x hC)
      have hxu : x ∈ u := by
        have hmem : x ∈ insert x B ∩ u := by
          rw [huC]
          exact mem_insert_self x C
        exact (mem_inter.1 hmem).2
      have hxC' : x ∉ C := fun h' => hxB (hC h')
      refine ⟨u.erase x,
        mem_memberSubfamily.2 ⟨by rwa [insert_erase hxu], notMem_erase x u⟩, ?_⟩
      ext z
      simp only [mem_inter, mem_erase]
      constructor
      · rintro ⟨hzB, _, hzu⟩
        have hmem : z ∈ insert x B ∩ u := mem_inter.2 ⟨mem_insert_of_mem hzB, hzu⟩
        rw [huC] at hmem
        rcases mem_insert.1 hmem with rfl | h'
        · exact absurd hzB hxB
        · exact h'
      · intro hzC
        have hmem : z ∈ insert x B ∩ u := by
          rw [huC]
          exact mem_insert_of_mem hzC
        obtain ⟨hz1, hz2⟩ := mem_inter.1 hmem
        have hzB : z ∈ B := by
          rcases mem_insert.1 hz1 with rfl | h'
          · exact absurd hzC hxC'
          · exact h'
        exact ⟨hzB, fun h' => hxC' (h' ▸ hzC), hz2⟩
    · intro C hC
      obtain ⟨u, hu, huC⟩ := h (hC.trans (subset_insert x B))
      have hxu : x ∉ u := fun hxu => by
        have hmem : x ∈ insert x B ∩ u := mem_inter.2 ⟨mem_insert_self x B, hxu⟩
        rw [huC] at hmem
        exact hxB (hC hmem)
      refine ⟨u, mem_nonMemberSubfamily.2 ⟨hu, hxu⟩, ?_⟩
      rw [← huC]
      ext z
      simp only [mem_inter, mem_insert]
      grind
  · rintro ⟨h1, h0⟩
    exact shatters_insert_of_both h0 h1

/-- **The split loss, exactly.** The defect consumed by the split at `a` counts
the parent-shattered sets, avoiding `a`, that NEITHER label-world shatters. The
`a`-containing shattered sets biject with the sets both worlds shatter
(`shatters_insert_iff`), so no loss hides there: all of it is concentrated on
`a`-free sets invisible to both worlds. Retypes `splitLoss` from a truncated
subtraction into the cardinality of an explicit family. -/
theorem splitLoss_eq_card (a : α) (𝒜 : Finset (Finset α)) :
    splitLoss a 𝒜 =
      #({B ∈ 𝒜.shatterer | a ∉ B ∧ ¬(𝒜.memberSubfamily a).Shatters B ∧
        ¬(𝒜.nonMemberSubfamily a).Shatters B}) := by
  have hpart : #({B ∈ 𝒜.shatterer | a ∈ B}) + #({B ∈ 𝒜.shatterer | a ∉ B})
      = #𝒜.shatterer := card_filter_add_card_filter_not (fun B => a ∈ B)
  have hbij : #({B ∈ 𝒜.shatterer | a ∈ B}) =
      #((𝒜.memberSubfamily a).shatterer ∩ (𝒜.nonMemberSubfamily a).shatterer) := by
    apply card_nbij' (i := fun B => B.erase a) (j := fun B => insert a B)
    · intro B hB
      simp only [mem_coe, mem_filter] at hB
      obtain ⟨hBs, haB⟩ := hB
      have hsh : 𝒜.Shatters (insert a (B.erase a)) := by
        rw [insert_erase haB]
        exact mem_shatterer.1 hBs
      rw [shatters_insert_iff (notMem_erase a B)] at hsh
      simp only [mem_coe, mem_inter, mem_shatterer]
      exact ⟨hsh.1, hsh.2⟩
    · intro B hB
      simp only [mem_coe, mem_inter, mem_shatterer] at hB
      have hx : a ∉ B := notMem_of_shatters_memberSubfamily hB.1
      simp only [mem_coe, mem_filter]
      refine ⟨mem_shatterer.2 ?_, mem_insert_self a B⟩
      rw [shatters_insert_iff hx]
      exact hB
    · intro B hB
      simp only [mem_coe, mem_filter] at hB
      exact insert_erase hB.2
    · intro B hB
      simp only [mem_coe, mem_inter, mem_shatterer] at hB
      exact erase_insert (notMem_of_shatters_memberSubfamily hB.1)
  have hsub : (𝒜.memberSubfamily a).shatterer ∪ (𝒜.nonMemberSubfamily a).shatterer
      ⊆ {B ∈ 𝒜.shatterer | a ∉ B} := by
    intro B hB
    rcases mem_union.1 hB with h | h
    · exact mem_filter.2 ⟨mem_shatterer.2 (Shatters.of_memberSubfamily
        (mem_shatterer.1 h)), notMem_of_shatters_memberSubfamily (mem_shatterer.1 h)⟩
    · exact mem_filter.2 ⟨mem_shatterer.2 (Shatters.of_nonMemberSubfamily
        (mem_shatterer.1 h)), notMem_of_shatters_nonMemberSubfamily (mem_shatterer.1 h)⟩
  have hcount := card_sdiff_add_card_eq_card hsub
  have hrest : {B ∈ 𝒜.shatterer | a ∉ B} \
      ((𝒜.memberSubfamily a).shatterer ∪ (𝒜.nonMemberSubfamily a).shatterer) =
      {B ∈ 𝒜.shatterer | a ∉ B ∧ ¬(𝒜.memberSubfamily a).Shatters B ∧
        ¬(𝒜.nonMemberSubfamily a).Shatters B} := by
    ext B
    simp only [mem_sdiff, mem_filter, mem_union, mem_shatterer, not_or]
    grind
  rw [hrest] at hcount
  have huni := card_union_add_card_inter (𝒜.memberSubfamily a).shatterer
    (𝒜.nonMemberSubfamily a).shatterer
  have hd1 := shatterDefect_add_card (𝒜.memberSubfamily a)
  have hd0 := shatterDefect_add_card (𝒜.nonMemberSubfamily a)
  have hd := shatterDefect_add_card 𝒜
  have hc := card_memberSubfamily_add_card_nonMemberSubfamily a 𝒜
  have hsplit := splitLoss_add_shatterDefects a 𝒜
  grind

end StructuralIgnorance
