/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.SI.DefectTwist.Combinatorial
import ZPM.Measurements.SI.Scheme

/-!
# Window defects: residual bridges and monotonicity

The bridge between the class layer and the family calculus: the two point-worlds
of a window trace ARE window traces of the residuals —

* `nonMemberSubfamily_windowTrace` / `memberSubfamily_windowTrace`: for
  `x ∉ A`, the `x ∉ ·` (resp. `x ∈ ·`) world of `windowTrace 𝒜 (insert x A)` is
  `windowTrace (residual 𝒜 {x} ∅) A` (resp. `windowTrace (residual 𝒜 {x} {x}) A`);
* `windowTrace_eq_union_residuals`: the trace through a window is the union of
  the two residual traces at any point.

Consequence (`windowDefect_mono`): the window defect is monotone in the window.
Adding a point `x` adds exactly `#I` traces, where `I` is the intersection of
the two residual traces (the patterns extending both ways), while the shattered
structure grows by at least `#I.shatterer ≥ #I` — the transfer of `x`-free
shattered sets plus the `insert x` lift through the two worlds, with Pajor's
inequality (`Finset.card_le_card_shatterer`) applied to `I`. Defect never
decreases as the window grows.
-/

namespace StructuralIgnorance

open Finset

variable {α : Type*} [DecidableEq α]

/-- The shatter defect of the class through the window `A`. -/
noncomputable def windowDefect (𝒜 : Set (Set α)) (A : Finset α) : ℕ :=
  shatterDefect (windowTrace 𝒜 A)

/-- Through every finite window, the class realizes exactly as many label patterns
as it shatters sets: zero defect everywhere. -/
def WindowFlat (𝒜 : Set (Set α)) : Prop :=
  ∀ A : Finset α, windowDefect 𝒜 A = 0

omit [DecidableEq α] in
private theorem singleton_inter_eq_self {S : Set α} {x : α} (hxS : x ∈ S) :
    (↑({x} : Finset α) : Set α) ∩ S = ↑({x} : Finset α) := by
  ext z
  simp only [coe_singleton, Set.mem_inter_iff, Set.mem_singleton_iff]
  constructor
  · rintro ⟨rfl, _⟩
    rfl
  · rintro rfl
    exact ⟨rfl, hxS⟩

omit [DecidableEq α] in
private theorem singleton_inter_eq_empty {S : Set α} {x : α} (hxS : x ∉ S) :
    (↑({x} : Finset α) : Set α) ∩ S = ↑(∅ : Finset α) := by
  ext z
  simp only [coe_singleton, coe_empty, Set.mem_inter_iff, Set.mem_singleton_iff,
    Set.mem_empty_iff_false, iff_false, not_and]
  rintro rfl
  exact hxS

omit [DecidableEq α] in
private theorem mem_of_singleton_inter_self {S : Set α} {x : α}
    (h : (↑({x} : Finset α) : Set α) ∩ S = ↑({x} : Finset α)) : x ∈ S := by
  have h' := Set.ext_iff.1 h x
  simpa using h'

omit [DecidableEq α] in
private theorem notMem_of_singleton_inter_empty {S : Set α} {x : α}
    (h : (↑({x} : Finset α) : Set α) ∩ S = ↑(∅ : Finset α)) : x ∉ S := by
  have h' := Set.ext_iff.1 h x
  simpa using h'

/-- The `x ∉ ·` world of the trace through `insert x A` is the trace of the
`x = 0` residual through `A`. -/
theorem nonMemberSubfamily_windowTrace {𝒜 : Set (Set α)} {x : α} {A : Finset α}
    (hx : x ∉ A) :
    (windowTrace 𝒜 (insert x A)).nonMemberSubfamily x
      = windowTrace (residual 𝒜 {x} ∅) A := by
  ext T
  simp only [mem_nonMemberSubfamily, mem_windowTrace]
  constructor
  · rintro ⟨⟨hTsub, hSample⟩, hxT⟩
    obtain ⟨S, hS𝒜, hSA⟩ := hSample
    have hxS : x ∉ S := by
      intro hxS
      have hmem : (x : α) ∈ (↑(insert x A) : Set α) ∩ S := ⟨by simp, hxS⟩
      rw [hSA] at hmem
      exact hxT (by exact_mod_cast hmem)
    have hTA : T ⊆ A := by
      intro z hz
      rcases mem_insert.1 (hTsub hz) with rfl | h
      · exact absurd hz hxT
      · exact h
    refine ⟨hTA, S, ⟨hS𝒜, singleton_inter_eq_empty hxS⟩, ?_⟩
    rw [← hSA]
    ext z
    by_cases hzx : z = x
    · subst hzx
      simp only [Set.mem_inter_iff, mem_coe, coe_insert, Set.mem_insert_iff]
      grind
    · simp only [Set.mem_inter_iff, mem_coe, coe_insert, Set.mem_insert_iff]
      grind
  · rintro ⟨hTA, hSample⟩
    obtain ⟨S, hSres, hSA⟩ := hSample
    obtain ⟨hS𝒜, hSx⟩ := hSres
    have hxS : x ∉ S := notMem_of_singleton_inter_empty hSx
    have hxT : x ∉ T := fun hxT => hx (hTA hxT)
    refine ⟨⟨hTA.trans (subset_insert x A), S, hS𝒜, ?_⟩, hxT⟩
    rw [← hSA]
    ext z
    by_cases hzx : z = x
    · subst hzx
      simp only [Set.mem_inter_iff, mem_coe, coe_insert, Set.mem_insert_iff]
      grind
    · simp only [Set.mem_inter_iff, mem_coe, coe_insert, Set.mem_insert_iff]
      grind

/-- The `x ∈ ·` world of the trace through `insert x A` is the trace of the
`x = 1` residual through `A`. -/
theorem memberSubfamily_windowTrace {𝒜 : Set (Set α)} {x : α} {A : Finset α}
    (hx : x ∉ A) :
    (windowTrace 𝒜 (insert x A)).memberSubfamily x
      = windowTrace (residual 𝒜 {x} {x}) A := by
  ext T
  simp only [mem_memberSubfamily, mem_windowTrace]
  constructor
  · rintro ⟨⟨hTsub, hSample⟩, hxT⟩
    obtain ⟨S, hS𝒜, hSA⟩ := hSample
    have hxS : x ∈ S := by
      have h' := Set.ext_iff.1 hSA x
      simpa using h'
    have hTA : T ⊆ A := by
      intro z hz
      have hz' := hTsub (mem_insert_of_mem hz)
      rcases mem_insert.1 hz' with rfl | h
      · exact absurd hz hxT
      · exact h
    refine ⟨hTA, S, ⟨hS𝒜, singleton_inter_eq_self hxS⟩, ?_⟩
    have hpt := Set.ext_iff.1 hSA
    ext z
    by_cases hzx : z = x
    · subst hzx
      simp only [Set.mem_inter_iff, mem_coe]
      constructor
      · rintro ⟨hzA, _⟩
        exact absurd (by exact_mod_cast hzA) hx
      · intro hzT
        exact absurd (by exact_mod_cast hzT) hxT
    · have h := hpt z
      simp only [coe_insert, Set.mem_inter_iff, Set.mem_insert_iff, mem_coe] at h ⊢
      grind
  · rintro ⟨hTA, hSample⟩
    obtain ⟨S, hSres, hSA⟩ := hSample
    obtain ⟨hS𝒜, hSx⟩ := hSres
    have hxS : x ∈ S := mem_of_singleton_inter_self hSx
    have hxT : x ∉ T := fun hxT => hx (hTA hxT)
    refine ⟨⟨insert_subset_insert x hTA, S, hS𝒜, ?_⟩, hxT⟩
    have hpt := Set.ext_iff.1 hSA
    ext z
    by_cases hzx : z = x
    · subst hzx
      simp only [coe_insert, Set.mem_inter_iff, Set.mem_insert_iff, mem_coe]
      grind
    · have h := hpt z
      simp only [coe_insert, Set.mem_inter_iff, Set.mem_insert_iff, mem_coe] at h ⊢
      grind

/-- The trace through a window is the union of the two residual traces at any
point: every realizing member carries one of the two labels. -/
theorem windowTrace_eq_union_residuals (𝒜 : Set (Set α)) (x : α) (A : Finset α) :
    windowTrace 𝒜 A
      = windowTrace (residual 𝒜 {x} ∅) A ∪ windowTrace (residual 𝒜 {x} {x}) A := by
  ext T
  simp only [mem_union, mem_windowTrace]
  constructor
  · rintro ⟨hTA, S, hS𝒜, hSA⟩
    by_cases hxS : x ∈ S
    · exact Or.inr ⟨hTA, S, ⟨hS𝒜, singleton_inter_eq_self hxS⟩, hSA⟩
    · exact Or.inl ⟨hTA, S, ⟨hS𝒜, singleton_inter_eq_empty hxS⟩, hSA⟩
  · rintro (⟨hTA, S, hSres, hSA⟩ | ⟨hTA, S, hSres, hSA⟩)
    · exact ⟨hTA, S, hSres.1, hSA⟩
    · exact ⟨hTA, S, hSres.1, hSA⟩

private theorem shatters_windowTrace_insert {𝒜 : Set (Set α)} {x : α}
    {A B : Finset α} (hxB : x ∉ B)
    (h : (windowTrace 𝒜 A).Shatters B) :
    (windowTrace 𝒜 (insert x A)).Shatters B := by
  intro C hC
  obtain ⟨T, hT, hBT⟩ := h hC
  obtain ⟨hTA, S, hS𝒜, hSA⟩ := mem_windowTrace.1 hT
  by_cases hxS : x ∈ S
  · refine ⟨insert x T, mem_windowTrace.2 ⟨insert_subset_insert x hTA, S, hS𝒜, ?_⟩, ?_⟩
    · have hpt := Set.ext_iff.1 hSA
      ext z
      by_cases hzx : z = x
      · subst hzx
        simp only [coe_insert, Set.mem_inter_iff, Set.mem_insert_iff, mem_coe]
        grind
      · have h' := hpt z
        simp only [coe_insert, Set.mem_inter_iff, Set.mem_insert_iff, mem_coe] at h' ⊢
        grind
    · rw [← hBT]
      ext z
      simp only [mem_inter, mem_insert]
      grind
  · refine ⟨T, mem_windowTrace.2 ⟨hTA.trans (subset_insert x A), S, hS𝒜, ?_⟩, hBT⟩
    have hpt := Set.ext_iff.1 hSA
    ext z
    by_cases hzx : z = x
    · subst hzx
      have h' := hpt z
      simp only [Set.mem_inter_iff, mem_coe] at h'
      simp only [coe_insert, Set.mem_inter_iff, Set.mem_insert_iff, mem_coe]
      grind
    · have h' := hpt z
      simp only [coe_insert, Set.mem_inter_iff, Set.mem_insert_iff, mem_coe] at h' ⊢
      grind

private theorem card_shatterer_windowTrace_insert_ge {𝒜 : Set (Set α)} {x : α}
    {A : Finset α} (hx : x ∉ A) :
    #(windowTrace 𝒜 A).shatterer
      + #(windowTrace (residual 𝒜 {x} ∅) A ∩ windowTrace (residual 𝒜 {x} {x}) A)
      ≤ #(windowTrace 𝒜 (insert x A)).shatterer := by
  have hfreeTr : ∀ t ∈ windowTrace 𝒜 A, x ∉ t :=
    fun t ht hxt => hx ((mem_windowTrace.1 ht).1 hxt)
  have hfreeI : ∀ t ∈ windowTrace (residual 𝒜 {x} ∅) A ∩
      windowTrace (residual 𝒜 {x} {x}) A, x ∉ t :=
    fun t ht hxt => hx ((mem_windowTrace.1 (mem_inter.1 ht).1).1 hxt)
  have hU : (windowTrace 𝒜 A).shatterer ⊆ (windowTrace 𝒜 (insert x A)).shatterer := by
    intro B hB
    have hxB : x ∉ B := notMem_of_shatters_of_forall hfreeTr (mem_shatterer.1 hB)
    exact mem_shatterer.2 (shatters_windowTrace_insert hxB (mem_shatterer.1 hB))
  have hI : ((windowTrace (residual 𝒜 {x} ∅) A ∩
      windowTrace (residual 𝒜 {x} {x}) A).shatterer).image (insert x)
      ⊆ (windowTrace 𝒜 (insert x A)).shatterer := by
    intro B hB
    obtain ⟨t, ht, rfl⟩ := mem_image.1 hB
    have hsh := mem_shatterer.1 ht
    have h0 : (windowTrace (residual 𝒜 {x} ∅) A).Shatters t :=
      hsh.mono_left inter_subset_left
    have h1 : (windowTrace (residual 𝒜 {x} {x}) A).Shatters t :=
      hsh.mono_left inter_subset_right
    rw [← nonMemberSubfamily_windowTrace (𝒜 := 𝒜) hx] at h0
    rw [← memberSubfamily_windowTrace (𝒜 := 𝒜) hx] at h1
    exact mem_shatterer.2 (shatters_insert_of_both h0 h1)
  have hdisj : Disjoint ((windowTrace 𝒜 A).shatterer)
      (((windowTrace (residual 𝒜 {x} ∅) A ∩
        windowTrace (residual 𝒜 {x} {x}) A).shatterer).image (insert x)) := by
    rw [disjoint_right]
    intro B hB hBU
    obtain ⟨t, _, rfl⟩ := mem_image.1 hB
    exact notMem_of_shatters_of_forall hfreeTr (mem_shatterer.1 hBU)
      (mem_insert_self x t)
  have hinj : #(((windowTrace (residual 𝒜 {x} ∅) A ∩
      windowTrace (residual 𝒜 {x} {x}) A).shatterer).image (insert x))
      = #((windowTrace (residual 𝒜 {x} ∅) A ∩
        windowTrace (residual 𝒜 {x} {x}) A).shatterer) := by
    apply card_image_of_injOn
    intro s hs s' hs' h
    have h1 : x ∉ s := notMem_of_shatters_of_forall hfreeI
      (mem_shatterer.1 (mem_coe.1 hs))
    have h2 : x ∉ s' := notMem_of_shatters_of_forall hfreeI
      (mem_shatterer.1 (mem_coe.1 hs'))
    rw [← erase_insert h1, h, erase_insert h2]
  have hcard : #(windowTrace 𝒜 A).shatterer
      + #((windowTrace (residual 𝒜 {x} ∅) A ∩
        windowTrace (residual 𝒜 {x} {x}) A).shatterer)
      ≤ #(windowTrace 𝒜 (insert x A)).shatterer := by
    calc #(windowTrace 𝒜 A).shatterer
        + #((windowTrace (residual 𝒜 {x} ∅) A ∩
          windowTrace (residual 𝒜 {x} {x}) A).shatterer)
        = #(windowTrace 𝒜 A).shatterer
          + #(((windowTrace (residual 𝒜 {x} ∅) A ∩
            windowTrace (residual 𝒜 {x} {x}) A).shatterer).image (insert x)) := by
          rw [hinj]
      _ = #((windowTrace 𝒜 A).shatterer
          ∪ ((windowTrace (residual 𝒜 {x} ∅) A ∩
            windowTrace (residual 𝒜 {x} {x}) A).shatterer).image (insert x)) :=
          (card_union_of_disjoint hdisj).symm
      _ ≤ #(windowTrace 𝒜 (insert x A)).shatterer := card_le_card (union_subset hU hI)
  have hpajor := card_le_card_shatterer (windowTrace (residual 𝒜 {x} ∅) A ∩
    windowTrace (residual 𝒜 {x} {x}) A)
  grind

/-- Adding a point never decreases the window defect. -/
theorem windowDefect_le_insert {𝒜 : Set (Set α)} {x : α} {A : Finset α}
    (hx : x ∉ A) : windowDefect 𝒜 A ≤ windowDefect 𝒜 (insert x A) := by
  have h0 := nonMemberSubfamily_windowTrace (𝒜 := 𝒜) hx
  have h1 := memberSubfamily_windowTrace (𝒜 := 𝒜) hx
  have hc' := card_memberSubfamily_add_card_nonMemberSubfamily x
    (windowTrace 𝒜 (insert x A))
  rw [h0, h1] at hc'
  have hcu : #(windowTrace 𝒜 A) = #(windowTrace (residual 𝒜 {x} ∅) A
      ∪ windowTrace (residual 𝒜 {x} {x}) A) := by
    rw [← windowTrace_eq_union_residuals]
  have huni := card_union_add_card_inter (windowTrace (residual 𝒜 {x} ∅) A)
    (windowTrace (residual 𝒜 {x} {x}) A)
  have hsh := card_shatterer_windowTrace_insert_ge (𝒜 := 𝒜) hx
  have hd := shatterDefect_add_card (windowTrace 𝒜 A)
  have hd' := shatterDefect_add_card (windowTrace 𝒜 (insert x A))
  unfold windowDefect
  grind

/-- The window defect is monotone under window union. -/
theorem windowDefect_union_le (𝒜 : Set (Set α)) (A D : Finset α) :
    windowDefect 𝒜 A ≤ windowDefect 𝒜 (A ∪ D) := by
  induction D using Finset.induction_on with
  | empty => simp
  | insert y D _hy ih =>
    rw [union_insert]
    by_cases h : y ∈ A ∪ D
    · rwa [insert_eq_self.2 h]
    · exact ih.trans (windowDefect_le_insert h)

/-- **Window monotonicity of the defect.** Growing the window never loses
defect: structural ignorance accumulates with what is observed of the class. -/
theorem windowDefect_mono {𝒜 : Set (Set α)} {A A' : Finset α} (h : A ⊆ A') :
    windowDefect 𝒜 A ≤ windowDefect 𝒜 A' := by
  have hle := windowDefect_union_le 𝒜 A A'
  rwa [union_eq_right.2 h] at hle

/-- Zero window defect compresses at the VC bound with no side information: on
window-flat classes the kernel scheme of size `d` exists outright. Conditioned on
the defect layer, so retired with it. -/
def FlatCompression : Prop :=
  ∀ (α : Type u_1) [DecidableEq α] (𝒜 : Set (Set α)) (d : ℕ),
    vcBounded 𝒜 d → WindowFlat 𝒜 → HasKernelScheme 𝒜 d

end StructuralIgnorance
