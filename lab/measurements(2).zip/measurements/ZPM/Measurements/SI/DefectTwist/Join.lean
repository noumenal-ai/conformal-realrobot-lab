/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.SI.DefectTwist.Combinatorial

/-!
# The defect Leibniz rule for joins over disjoint grounds

The join of two families over disjoint grounds realizes every pattern of the first
alongside every pattern of the second. Family size and shattered structure are both
multiplicative under this operation — the shatterer of the join IS the join of the
shatterers (`shatterer_join`, an equality of families) — and consequently the
shatter defect obeys a Leibniz rule with respect to the (shatterer-size,
family-size) bigrading:

`shatterDefect (join 𝒜 ℬ) = shatterDefect 𝒜 * #ℬ.shatterer + #𝒜 * shatterDefect ℬ`.

Independent components do not mix defect: each side's defect enters scaled by the
other side's shattered structure, and no cross term appears. Sum-type plumbing is
Mathlib's `Finset.disjSum` / `toLeft` / `toRight` (`Data.Finset.Sum`).
-/

namespace StructuralIgnorance

open Finset Sum

variable {α β : Type*} [DecidableEq α] [DecidableEq β]

/-- The join of two families over disjoint grounds: memberwise disjoint sums
(`Finset.disjSum`, Mathlib `Data.Finset.Sum`). -/
def join (𝒜 : Finset (Finset α)) (ℬ : Finset (Finset β)) :
    Finset (Finset (α ⊕ β)) :=
  (𝒜 ×ˢ ℬ).image fun p => p.1.disjSum p.2

/-- Membership in the join reads off the two components. -/
theorem mem_join {𝒜 : Finset (Finset α)} {ℬ : Finset (Finset β)}
    {u : Finset (α ⊕ β)} :
    u ∈ join 𝒜 ℬ ↔ u.toLeft ∈ 𝒜 ∧ u.toRight ∈ ℬ := by
  constructor
  · intro hu
    obtain ⟨p, hp, rfl⟩ := mem_image.1 hu
    obtain ⟨h1, h2⟩ := mem_product.1 hp
    simp [h1, h2]
  · rintro ⟨h1, h2⟩
    exact mem_image.2
      ⟨(u.toLeft, u.toRight), mem_product.2 ⟨h1, h2⟩, toLeft_disjSum_toRight⟩

/-- Family size is multiplicative under the join. -/
theorem card_join (𝒜 : Finset (Finset α)) (ℬ : Finset (Finset β)) :
    #(join 𝒜 ℬ) = #𝒜 * #ℬ := by
  rw [join, card_image_of_injOn, card_product]
  intro p _ q _ h
  obtain ⟨h1, h2⟩ := disjSum_inj.1 h
  exact Prod.ext h1 h2

private theorem disjSum_inter_disjSum (s₁ B₁ : Finset α) (s₂ B₂ : Finset β) :
    s₁.disjSum s₂ ∩ B₁.disjSum B₂ = (s₁ ∩ B₁).disjSum (s₂ ∩ B₂) := by
  ext x
  cases x <;> simp

/-- The join shatters a set exactly when each component family shatters the
corresponding component: patterns split and recombine along the sum. -/
theorem shatters_join_iff {𝒜 : Finset (Finset α)} {ℬ : Finset (Finset β)}
    {B : Finset (α ⊕ β)} :
    (join 𝒜 ℬ).Shatters B ↔ 𝒜.Shatters B.toLeft ∧ ℬ.Shatters B.toRight := by
  constructor
  · intro h
    refine ⟨fun c hc => ?_, fun c hc => ?_⟩
    · have hsub : c.disjSum (∅ : Finset β) ⊆ B := by
        rw [disjSum_subset]
        exact ⟨hc, empty_subset _⟩
      obtain ⟨u, hu, huc⟩ := h hsub
      obtain ⟨huL, _⟩ := mem_join.1 hu
      refine ⟨u.toLeft, huL, ?_⟩
      rw [← toLeft_disjSum_toRight (u := B), ← toLeft_disjSum_toRight (u := u),
        disjSum_inter_disjSum] at huc
      exact (disjSum_inj.1 huc).1
    · have hsub : (∅ : Finset α).disjSum c ⊆ B := by
        rw [disjSum_subset]
        exact ⟨empty_subset _, hc⟩
      obtain ⟨u, hu, huc⟩ := h hsub
      obtain ⟨_, huR⟩ := mem_join.1 hu
      refine ⟨u.toRight, huR, ?_⟩
      rw [← toLeft_disjSum_toRight (u := B), ← toLeft_disjSum_toRight (u := u),
        disjSum_inter_disjSum] at huc
      exact (disjSum_inj.1 huc).2
  · rintro ⟨hL, hR⟩ t ht
    obtain ⟨s, hs, hsL⟩ := hL (toLeft_subset_toLeft ht)
    obtain ⟨r, hr, hrR⟩ := hR (toRight_subset_toRight ht)
    refine ⟨s.disjSum r, mem_join.2 ⟨by simpa using hs, by simpa using hr⟩, ?_⟩
    calc B ∩ s.disjSum r
        = B.toLeft.disjSum B.toRight ∩ s.disjSum r := by
          rw [toLeft_disjSum_toRight]
      _ = (B.toLeft ∩ s).disjSum (B.toRight ∩ r) := disjSum_inter_disjSum _ _ _ _
      _ = t.toLeft.disjSum t.toRight := by rw [hsL, hrR]
      _ = t := toLeft_disjSum_toRight

/-- The shattered structure is multiplicative as an equality of families: the
shatterer of the join is the join of the shatterers. -/
theorem shatterer_join (𝒜 : Finset (Finset α)) (ℬ : Finset (Finset β)) :
    (join 𝒜 ℬ).shatterer = join 𝒜.shatterer ℬ.shatterer := by
  ext B
  rw [mem_shatterer, shatters_join_iff, mem_join, mem_shatterer, mem_shatterer]

/-- **The Leibniz rule.** Over disjoint grounds the shatter defect is a derivation
with respect to the (shatterer-size, family-size) bigrading: each side's defect
enters scaled by the other side's shattered structure, with no cross term.
Independent components do not mix defect. -/
theorem shatterDefect_join (𝒜 : Finset (Finset α)) (ℬ : Finset (Finset β)) :
    shatterDefect (join 𝒜 ℬ)
      = shatterDefect 𝒜 * #ℬ.shatterer + #𝒜 * shatterDefect ℬ := by
  have h2 := shatterDefect_add_card 𝒜
  have h3 := shatterDefect_add_card ℬ
  have hs : #(join 𝒜 ℬ).shatterer = #𝒜.shatterer * #ℬ.shatterer := by
    rw [shatterer_join, card_join]
  have expand : shatterDefect 𝒜 * #ℬ.shatterer + #𝒜 * shatterDefect ℬ + #𝒜 * #ℬ
      = #𝒜.shatterer * #ℬ.shatterer := by
    calc shatterDefect 𝒜 * #ℬ.shatterer + #𝒜 * shatterDefect ℬ + #𝒜 * #ℬ
        = shatterDefect 𝒜 * #ℬ.shatterer + #𝒜 * (shatterDefect ℬ + #ℬ) := by
          rw [Nat.mul_add, add_assoc]
      _ = shatterDefect 𝒜 * #ℬ.shatterer + #𝒜 * #ℬ.shatterer := by rw [h3]
      _ = (shatterDefect 𝒜 + #𝒜) * #ℬ.shatterer := by rw [Nat.add_mul]
      _ = #𝒜.shatterer * #ℬ.shatterer := by rw [h2]
  have hadd := shatterDefect_add_card (join 𝒜 ℬ)
  rw [card_join, hs, ← expand] at hadd
  exact Nat.add_right_cancel hadd

end StructuralIgnorance
