/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import Mathlib.Order.Preorder.Chain
import ZPM.Measurements.SI.Scheme
import ZPM.Measurements.SI.DefectTwist.Twist
import ZPM.Measurements.SI.Conjectures

/-!
# VC dimension one: the splitting law and compression of chains

Two results at the lowest nontrivial VC bound.

**The splitting law** (`singleton_shatters_at_most_one_residual`): under
`vcBounded 𝒜 1`, no point is singleton-shattered in both residuals of another
point — the four label patterns assembled from the two residuals would shatter
the pair. Conditioning at a point splits the class's freedom into two worlds
that share none of it.

**Compression of chains** (`hasKernelScheme_one_of_isChain`): a class totally
ordered by inclusion (`IsChain (· ⊆ ·)`, Mathlib `Order.Preorder.Chain`) has a
kernel scheme of size one with no side information. The reconstruction
`interConvention` is improper: it returns the intersection of all members
containing the kernel's 1-labeled part, an intersection that need not be a
member — which is exactly what dense chains require (among rational thresholds
`{q | q < θ}` no minimal member contains a given point). The anchor is a
maximum of the sample's 1-labeled part in the membership order `memOrder`
(`a` below `b` when every member containing `b` contains `a`): total for
chains with no side hypothesis, transitive outright, so finite nonempty label
sets have maxima. Inclusion-chains also satisfy `vcBounded 𝒜 1`
(`vcBounded_one_of_isChain`), placing them inside the `CalibrationVCOne`
scope with a kernel budget of one.
-/

namespace StructuralIgnorance

open Finset

variable {α : Type*} [DecidableEq α]

/-! ## The splitting law -/

/-- Under a VC bound of one, no point `y` is singleton-shattered in both
residuals of a point `x`: the four assembled patterns would shatter `{x, y}`.
Freedom does not survive on both sides of a split. -/
theorem singleton_shatters_at_most_one_residual {𝒜 : Set (Set α)}
    (h : vcBounded 𝒜 1) {x y : α} :
    ¬(SetShatters (residual 𝒜 {x} ∅) {y} ∧
      SetShatters (residual 𝒜 {x} {x}) {y}) := by
  rintro ⟨h0, h1⟩
  rcases eq_or_ne x y with rfl | hxy
  · obtain ⟨S, hS, hSy⟩ := h1 ∅ (empty_subset _)
    obtain ⟨hS𝒜, hSx⟩ := hS
    have hx : x ∈ S := by
      have h' := Set.ext_iff.1 hSx x
      simpa using h'
    have hx' : x ∉ S := by
      have h' := Set.ext_iff.1 hSy x
      simpa using h'
    exact hx' hx
  have hshat : SetShatters 𝒜 {x, y} := by
    intro C hC
    have hCsub : ∀ z ∈ C, z = x ∨ z = y := by
      intro z hz
      have := hC hz
      simpa [mem_insert, mem_singleton] using this
    by_cases hxC : x ∈ C
    · obtain ⟨S, hS, hSy⟩ := h1 (C ∩ {y}) inter_subset_right
      obtain ⟨hS𝒜, hSx⟩ := hS
      have hx : x ∈ S := by
        have h' := Set.ext_iff.1 hSx x
        simpa using h'
      have hy : y ∈ S ↔ y ∈ C := by
        have h' := Set.ext_iff.1 hSy y
        simpa using h'
      refine ⟨S, hS𝒜, ?_⟩
      ext z
      simp only [coe_insert, coe_singleton, Set.mem_inter_iff, Set.mem_insert_iff,
        Set.mem_singleton_iff, mem_coe]
      constructor
      · rintro ⟨hz1 | hz1, hz2⟩
        · exact hz1 ▸ hxC
        · exact hz1 ▸ hy.1 (hz1 ▸ hz2)
      · intro hzC
        rcases hCsub z hzC with rfl | rfl
        · exact ⟨Or.inl rfl, hx⟩
        · exact ⟨Or.inr rfl, hy.2 hzC⟩
    · obtain ⟨S, hS, hSy⟩ := h0 (C ∩ {y}) inter_subset_right
      obtain ⟨hS𝒜, hSx⟩ := hS
      have hx : x ∉ S := by
        have h' := Set.ext_iff.1 hSx x
        simpa using h'
      have hy : y ∈ S ↔ y ∈ C := by
        have h' := Set.ext_iff.1 hSy y
        simpa using h'
      refine ⟨S, hS𝒜, ?_⟩
      ext z
      simp only [coe_insert, coe_singleton, Set.mem_inter_iff, Set.mem_insert_iff,
        Set.mem_singleton_iff, mem_coe]
      constructor
      · rintro ⟨hz1 | hz1, hz2⟩
        · exact absurd (hz1 ▸ hz2) hx
        · exact hz1 ▸ hy.1 (hz1 ▸ hz2)
      · intro hzC
        rcases hCsub z hzC with rfl | rfl
        · exact absurd hzC hxC
        · exact ⟨Or.inr rfl, hy.2 hzC⟩
  have hle := h _ hshat
  rw [card_pair hxy] at hle
  exact absurd hle (by decide)

/-! ## Compression of chains -/

/-- The membership order of a class: `a` lies below `b` when every member
containing `b` contains `a`. -/
def memOrder (𝒜 : Set (Set α)) (a b : α) : Prop :=
  ∀ S ∈ 𝒜, b ∈ S → a ∈ S

omit [DecidableEq α] in
theorem memOrder_refl (𝒜 : Set (Set α)) (a : α) : memOrder 𝒜 a a :=
  fun _ _ h => h

omit [DecidableEq α] in
theorem memOrder_trans {𝒜 : Set (Set α)} {a b c : α}
    (hab : memOrder 𝒜 a b) (hbc : memOrder 𝒜 b c) : memOrder 𝒜 a c :=
  fun S hS hc => hab S hS (hbc S hS hc)

omit [DecidableEq α] in
/-- On an inclusion-chain the membership order is total, with no side
hypothesis: two failure witnesses would be inclusion-incomparable members. -/
theorem memOrder_total_of_isChain {𝒜 : Set (Set α)}
    (h𝒜 : IsChain (· ⊆ ·) 𝒜) (a b : α) :
    memOrder 𝒜 a b ∨ memOrder 𝒜 b a := by
  rcases Classical.em (memOrder 𝒜 a b) with h | h
  · exact Or.inl h
  · refine Or.inr fun S hS haS => ?_
    rw [memOrder] at h
    push Not at h
    obtain ⟨Sb, hSb𝒜, hbSb, haSb⟩ := h
    rcases eq_or_ne S Sb with rfl | hne
    · exact absurd haS haSb
    · rcases h𝒜 hS hSb𝒜 hne with hsub | hsub
      · exact absurd (hsub haS) haSb
      · exact hsub hbSb

omit [DecidableEq α] in
/-- A finite nonempty set on which the membership order is total has a maximum. -/
theorem exists_memOrder_max_of_total {𝒜 : Set (Set α)} {T : Finset α}
    (htot : ∀ a ∈ T, ∀ b ∈ T, memOrder 𝒜 a b ∨ memOrder 𝒜 b a)
    (hT : T.Nonempty) : ∃ x ∈ T, ∀ a ∈ T, memOrder 𝒜 a x := by
  induction T using Finset.cons_induction with
  | empty => exact absurd hT (by simp)
  | cons b T hb ih =>
    rcases T.eq_empty_or_nonempty with rfl | hT'
    · refine ⟨b, mem_cons_self b ∅, fun a ha => ?_⟩
      rcases mem_cons.1 ha with rfl | ha'
      · exact memOrder_refl 𝒜 a
      · exact absurd ha' (by simp)
    · obtain ⟨x, hxT, hmax⟩ := ih
        (fun a ha c hc => htot a (mem_cons_of_mem ha) c (mem_cons_of_mem hc)) hT'
      rcases htot b (mem_cons_self b T) x (mem_cons_of_mem hxT) with h | h
      · refine ⟨x, mem_cons_of_mem hxT, fun a ha => ?_⟩
        rcases mem_cons.1 ha with rfl | ha'
        · exact h
        · exact hmax a ha'
      · refine ⟨b, mem_cons_self b T, fun a ha => ?_⟩
        rcases mem_cons.1 ha with rfl | ha'
        · exact memOrder_refl 𝒜 a
        · exact memOrder_trans (hmax a ha') h

omit [DecidableEq α] in
/-- A finite nonempty set has a maximum in the membership order of a chain. -/
theorem exists_memOrder_max {𝒜 : Set (Set α)} (h𝒜 : IsChain (· ⊆ ·) 𝒜)
    {T : Finset α} (hT : T.Nonempty) :
    ∃ x ∈ T, ∀ a ∈ T, memOrder 𝒜 a x :=
  exists_memOrder_max_of_total (fun a _ b _ => memOrder_total_of_isChain h𝒜 a b) hT

/-- Reconstruction by intersection: the hypothesis is the intersection of all
members containing the kernel's 1-labeled part. Improper — the output need not
be a member — which is what dense chains require; the kernel's point set is not
consulted beyond its labels. -/
def interConvention (𝒜 : Set (Set α)) : Convention α :=
  fun _Z W => ⋂₀ {S ∈ 𝒜 | (W : Set α) ⊆ S}

/-- The anchor leg of the intersection convention: a maximum of the label set in
the membership order is a size-1 kernel. The upper inclusion comes from the
realizing member, the lower from maximality. -/
theorem isKernel_interConvention_anchor {𝒜 : Set (Set α)} {A T : Finset α}
    (hAT : IsSample 𝒜 A T) {x : α} (hxT : x ∈ T)
    (hmax : ∀ a ∈ T, memOrder 𝒜 a x) :
    IsKernel (interConvention 𝒜) 1 A T {x} := by
  have hTA : T ⊆ A := hAT.subset
  obtain ⟨S, hS𝒜, hSA⟩ := hAT
  have hxA : x ∈ A := hTA hxT
  have hxS : x ∈ S := by
    have hmem : (x : α) ∈ (A : Set α) ∩ S := by
      rw [hSA]
      exact_mod_cast hxT
    exact hmem.2
  refine ⟨singleton_subset_iff.2 hxA, by simp, ?_⟩
  rw [singleton_inter_of_mem hxT]
  ext z
  simp only [interConvention, coe_singleton, Set.singleton_subset_iff,
    Set.mem_inter_iff, Set.mem_sInter, Set.mem_setOf_eq, mem_coe]
  constructor
  · rintro ⟨hz, hzA⟩
    have hzS : z ∈ S := hz S ⟨hS𝒜, hxS⟩
    have hmem : z ∈ (A : Set α) ∩ S := ⟨hzA, hzS⟩
    rw [hSA] at hmem
    exact_mod_cast hmem
  · intro hzT
    refine ⟨fun S' hS' => hmax z hzT S' hS'.1 hS'.2, ?_⟩
    exact_mod_cast hTA hzT

omit [DecidableEq α] in
/-- Inclusion-chains satisfy the VC bound of one: a member containing `u` and
avoiding `v` and a member containing `v` and avoiding `u` are inclusion-
incomparable. -/
theorem vcBounded_one_of_isChain {𝒜 : Set (Set α)}
    (h𝒜 : IsChain (· ⊆ ·) 𝒜) : vcBounded 𝒜 1 := by
  intro B hB
  by_contra hcard
  push Not at hcard
  obtain ⟨u, hu, v, hv, huv⟩ := one_lt_card.1 hcard
  obtain ⟨S₁, hS₁, hS₁eq⟩ := hB {u} (singleton_subset_iff.2 hu)
  obtain ⟨S₂, hS₂, hS₂eq⟩ := hB {v} (singleton_subset_iff.2 hv)
  have hmem₁ := fun z => Set.ext_iff.1 hS₁eq z
  have hmem₂ := fun z => Set.ext_iff.1 hS₂eq z
  simp only [Set.mem_inter_iff, mem_coe, coe_singleton, Set.mem_singleton_iff] at hmem₁ hmem₂
  have huS₁ : u ∈ S₁ := ((hmem₁ u).2 rfl).2
  have hvS₂ : v ∈ S₂ := ((hmem₂ v).2 rfl).2
  have hvS₁ : v ∉ S₁ := fun hvS => huv.symm ((hmem₁ v).1 ⟨hv, hvS⟩)
  have huS₂ : u ∉ S₂ := fun huS => huv ((hmem₂ u).1 ⟨hu, huS⟩)
  rcases eq_or_ne S₁ S₂ with rfl | hne
  · exact hvS₁ hvS₂
  · rcases h𝒜 hS₁ hS₂ hne with hsub | hsub
    · exact huS₂ (hsub huS₁)
    · exact hvS₁ (hsub hvS₂)

/-- **Chains compress at size one.** A class totally ordered by inclusion has a
kernel scheme of size one with no side information: a nonempty sample is
anchored at a maximum of its 1-labeled part in the membership order and
reconstructed by `interConvention`; all-zero samples use the empty kernel
(Littlestone–Warmuth 1986 for the scheme notion; the reconstruction is
improper). Dense chains are covered — no minimal member is required. -/
theorem hasKernelScheme_one_of_isChain {𝒜 : Set (Set α)}
    (h𝒜 : IsChain (· ⊆ ·) 𝒜) : HasKernelScheme 𝒜 1 := by
  refine ⟨interConvention 𝒜, fun A T hAT => ?_⟩
  have hTA : T ⊆ A := hAT.subset
  obtain ⟨S, hS𝒜, hSA⟩ := hAT
  rcases T.eq_empty_or_nonempty with rfl | hT
  · refine ⟨∅, empty_subset A, by simp, ?_⟩
    have hW : ((∅ : Finset α) ∩ (∅ : Finset α)) = ∅ := by simp
    rw [hW]
    ext z
    simp only [interConvention, coe_empty, Set.empty_subset, and_true,
      Set.mem_inter_iff, Set.mem_sInter, Set.mem_setOf_eq,
      Set.mem_empty_iff_false, iff_false, not_and]
    intro hz hzA
    have hzS : z ∈ S := hz S hS𝒜
    have hmem : z ∈ (A : Set α) ∩ S := ⟨hzA, hzS⟩
    rw [hSA] at hmem
    simp at hmem
  · obtain ⟨x, hxT, hmax⟩ := exists_memOrder_max h𝒜 hT
    exact ⟨{x}, isKernel_interConvention_anchor ⟨S, hS𝒜, hSA⟩ hxT hmax⟩

/-! ## d = 1 universality -/

/-- With the empty set in the class, a VC bound of one makes any two points of a
common member comparable in the membership order: otherwise the four assembled
patterns shatter the pair. -/
theorem memOrder_total_of_vcBounded_one {𝒜 : Set (Set α)} (h : vcBounded 𝒜 1)
    (hemp : ∅ ∈ 𝒜) {a b : α} (hab : ∃ S ∈ 𝒜, a ∈ S ∧ b ∈ S) :
    memOrder 𝒜 a b ∨ memOrder 𝒜 b a := by
  rcases eq_or_ne a b with rfl | hne
  · exact Or.inl (memOrder_refl 𝒜 a)
  by_contra hcon
  push Not at hcon
  obtain ⟨hab', hba'⟩ := hcon
  rw [memOrder] at hab' hba'
  push Not at hab' hba'
  obtain ⟨R₁, hR₁, hbR₁, haR₁⟩ := hab'
  obtain ⟨R₂, hR₂, haR₂, hbR₂⟩ := hba'
  obtain ⟨R, hR, haR, hbR⟩ := hab
  have hshat : SetShatters 𝒜 {a, b} := by
    intro C hC
    have hCab : ∀ z ∈ C, z = a ∨ z = b := by
      intro z hz
      simpa [mem_insert, mem_singleton] using hC hz
    by_cases haC : a ∈ C <;> by_cases hbC : b ∈ C
    · refine ⟨R, hR, ?_⟩
      ext z
      simp only [coe_insert, coe_singleton, Set.mem_inter_iff, Set.mem_insert_iff,
        Set.mem_singleton_iff, mem_coe]
      constructor
      · rintro ⟨hz1 | hz1, _⟩
        · exact hz1 ▸ haC
        · exact hz1 ▸ hbC
      · intro hzC
        rcases hCab z hzC with rfl | rfl
        · exact ⟨Or.inl rfl, haR⟩
        · exact ⟨Or.inr rfl, hbR⟩
    · refine ⟨R₂, hR₂, ?_⟩
      ext z
      simp only [coe_insert, coe_singleton, Set.mem_inter_iff, Set.mem_insert_iff,
        Set.mem_singleton_iff, mem_coe]
      constructor
      · rintro ⟨hz1 | hz1, hz2⟩
        · exact hz1 ▸ haC
        · exact absurd (hz1 ▸ hz2) hbR₂
      · intro hzC
        rcases hCab z hzC with rfl | rfl
        · exact ⟨Or.inl rfl, haR₂⟩
        · exact absurd hzC hbC
    · refine ⟨R₁, hR₁, ?_⟩
      ext z
      simp only [coe_insert, coe_singleton, Set.mem_inter_iff, Set.mem_insert_iff,
        Set.mem_singleton_iff, mem_coe]
      constructor
      · rintro ⟨hz1 | hz1, hz2⟩
        · exact absurd (hz1 ▸ hz2) haR₁
        · exact hz1 ▸ hbC
      · intro hzC
        rcases hCab z hzC with rfl | rfl
        · exact absurd hzC haC
        · exact ⟨Or.inr rfl, hbR₁⟩
    · refine ⟨∅, hemp, ?_⟩
      ext z
      simp only [coe_insert, coe_singleton, Set.mem_inter_iff, Set.mem_insert_iff,
        Set.mem_singleton_iff, mem_coe, Set.mem_empty_iff_false]
      constructor
      · rintro ⟨_, h'⟩
        exact h'.elim
      · intro hzC
        rcases hCab z hzC with rfl | rfl
        · exact absurd hzC haC
        · exact absurd hzC hbC
  have hle := h _ hshat
  rw [card_pair hne] at hle
  exact absurd hle (by decide)

/-- **d = 1 universality: every VC-1 class compresses at kernel size one, with
no side information.** No finiteness, no distinguished member, no chain
hypothesis. Twist the class by any member to place `∅` in it; there the VC
bound makes co-member points comparable in the membership order, so every label
set is a finite chain; anchor at its maximum, reconstruct with
`interConvention`, and transport the scheme back with the same kernels. -/
theorem hasKernelScheme_one_of_vcBounded_one {𝒜 : Set (Set α)}
    (h : vcBounded 𝒜 1) : HasKernelScheme 𝒜 1 := by
  rcases Set.eq_empty_or_nonempty 𝒜 with rfl | ⟨S₀, hS₀⟩
  · exact ⟨fun _ _ => ∅, fun A T hAT => absurd hAT (by rintro ⟨S, hS, -⟩; exact hS)⟩
  · refine HasKernelScheme.of_twistClass (S₀ := S₀) ?_
    have hB1 : vcBounded (twistClass 𝒜 S₀) 1 := vcBounded_twistClass h S₀
    have hBemp : ∅ ∈ twistClass 𝒜 S₀ := empty_mem_twistClass hS₀
    refine ⟨interConvention (twistClass 𝒜 S₀), fun A T hAT => ?_⟩
    have hAT' := hAT
    obtain ⟨S, hS𝒜, hSA⟩ := hAT'
    rcases T.eq_empty_or_nonempty with rfl | hT
    · refine ⟨∅, empty_subset A, by simp, ?_⟩
      have hW : ((∅ : Finset α) ∩ (∅ : Finset α)) = ∅ := by simp
      rw [hW]
      have hsub : interConvention (twistClass 𝒜 S₀) ∅ ∅ ⊆ (∅ : Set α) := by
        intro z hz
        have hempmem : (∅ : Set α) ∈
            {R ∈ twistClass 𝒜 S₀ | (↑(∅ : Finset α) : Set α) ⊆ R} :=
          ⟨hBemp, by simp⟩
        exact Set.sInter_subset_of_mem hempmem hz
      ext z
      simp only [Set.mem_inter_iff, coe_empty, Set.mem_empty_iff_false,
        iff_false, not_and]
      intro hz _
      exact absurd (hsub hz) (Set.notMem_empty z)
    · have htot : ∀ a ∈ T, ∀ b ∈ T,
          memOrder (twistClass 𝒜 S₀) a b ∨ memOrder (twistClass 𝒜 S₀) b a := by
        intro a ha b hb
        refine memOrder_total_of_vcBounded_one hB1 hBemp ⟨S, hS𝒜, ?_, ?_⟩
        · have hmem : (a : α) ∈ (↑A : Set α) ∩ S := by
            rw [hSA]
            exact_mod_cast ha
          exact hmem.2
        · have hmem : (b : α) ∈ (↑A : Set α) ∩ S := by
            rw [hSA]
            exact_mod_cast hb
          exact hmem.2
      obtain ⟨x, hxT, hmax⟩ := exists_memOrder_max_of_total htot hT
      exact ⟨{x}, isKernel_interConvention_anchor ⟨S, hS𝒜, hSA⟩ hxT hmax⟩

/-- The `d = 1` calibration gate, discharged: kernel size one suffices, and one
is at most three. -/
theorem calibrationVCOne : CalibrationVCOne.{u_1} :=
  fun _α _ _𝒜 h => (hasKernelScheme_one_of_vcBounded_one h).mono (by decide)

/-- Kernel size one is exact at VC dimension one: the two-member class
`{∅, {p}}` admits no size-0 scheme, since both realizable samples on the window
`{p}` would ride the empty kernel. -/
theorem not_hasKernelScheme_zero (p : α) :
    ¬ HasKernelScheme ({∅, {p}} : Set (Set α)) 0 := by
  rintro ⟨ρ, hρ⟩
  obtain ⟨Z₁, hZ₁A, hZ₁k, hZ₁⟩ := hρ {p} ∅ ⟨∅, by simp, by simp⟩
  obtain ⟨Z₂, hZ₂A, hZ₂k, hZ₂⟩ := hρ {p} {p} ⟨{p}, by simp, by simp⟩
  have hZ₁e : Z₁ = ∅ := card_eq_zero.1 (Nat.le_zero.1 hZ₁k)
  have hZ₂e : Z₂ = ∅ := card_eq_zero.1 (Nat.le_zero.1 hZ₂k)
  subst hZ₁e
  subst hZ₂e
  have e1 : ((∅ : Finset α) ∩ (∅ : Finset α)) = ∅ := by simp
  have e2 : ((∅ : Finset α) ∩ ({p} : Finset α)) = ∅ := by simp
  rw [e1] at hZ₁
  rw [e2] at hZ₂
  have hp := Set.ext_iff.1 (hZ₁.symm.trans hZ₂) p
  simp at hp

/-- The exactness witness is admissible: `{∅, {p}}` has VC bound one. -/
theorem vcBounded_pair_singleton (p : α) :
    vcBounded ({∅, {p}} : Set (Set α)) 1 := by
  intro B hB
  by_contra hcard
  push Not at hcard
  obtain ⟨u, hu, v, hv, huv⟩ := one_lt_card.1 hcard
  have hsub : ({u, v} : Finset α) ⊆ B := by
    intro z hz
    rcases mem_insert.1 hz with rfl | hz'
    · exact hu
    · exact (mem_singleton.1 hz') ▸ hv
  obtain ⟨S, hS, hBS⟩ := hB {u, v} hsub
  have huS : u ∈ S := by
    have h' := Set.ext_iff.1 hBS u
    simp only [Set.mem_inter_iff, mem_coe, coe_insert, coe_singleton,
      Set.mem_insert_iff, Set.mem_singleton_iff] at h'
    exact (h'.2 (Or.inl trivial)).2
  have hvS : v ∈ S := by
    have h' := Set.ext_iff.1 hBS v
    simp only [Set.mem_inter_iff, mem_coe, coe_insert, coe_singleton,
      Set.mem_insert_iff, Set.mem_singleton_iff] at h'
    exact (h'.2 (Or.inr trivial)).2
  rcases hS with rfl | hS'
  · exact huS
  · rw [Set.mem_singleton_iff.1 hS'] at huS hvS
    exact huv (huS.trans hvS.symm)

/-! ## The zero rung -/

omit [DecidableEq α] in
/-- At VC bound zero any two members are equal: a difference point is a
shattered singleton. -/
theorem eq_of_vcBounded_zero {𝒜 : Set (Set α)} (h : vcBounded 𝒜 0)
    {S S' : Set α} (hS : S ∈ 𝒜) (hS' : S' ∈ 𝒜) : S = S' := by
  have key : ∀ T T' : Set α, T ∈ 𝒜 → T' ∈ 𝒜 →
      ∀ z, z ∈ T → z ∉ T' → False := by
    intro T T' hT hT' z hzT hzT'
    have hshat : SetShatters 𝒜 {z} := by
      intro C hC
      rcases Finset.subset_singleton_iff.1 hC with rfl | rfl
      · refine ⟨T', hT', ?_⟩
        ext w
        simp only [coe_singleton, coe_empty, Set.mem_inter_iff,
          Set.mem_singleton_iff, Set.mem_empty_iff_false, iff_false, not_and]
        rintro rfl
        exact hzT'
      · refine ⟨T, hT, ?_⟩
        ext w
        simp only [coe_singleton, Set.mem_inter_iff, Set.mem_singleton_iff]
        constructor
        · rintro ⟨rfl, _⟩
          rfl
        · rintro rfl
          exact ⟨rfl, hzT⟩
    have hle := h _ hshat
    simp at hle
  ext z
  constructor
  · intro hz
    by_contra hz'
    exact key S S' hS hS' z hz hz'
  · intro hz
    by_contra hz'
    exact key S' S hS' hS z hz hz'

/-- At VC bound zero the class compresses at kernel size zero: the union of the
class reconstructs every realizable sample from the empty kernel (all members
coincide by `eq_of_vcBounded_zero`). -/
theorem hasKernelScheme_zero_of_vcBounded_zero {𝒜 : Set (Set α)}
    (h : vcBounded 𝒜 0) : HasKernelScheme 𝒜 0 := by
  refine ⟨fun _ _ => ⋃₀ 𝒜, fun A T hAT => ?_⟩
  obtain ⟨S, hS𝒜, hSA⟩ := hAT
  refine ⟨∅, empty_subset A, by simp, ?_⟩
  have hU : ⋃₀ 𝒜 = S := by
    apply Set.Subset.antisymm
    · intro z hz
      obtain ⟨S', hS', hzS'⟩ := Set.mem_sUnion.1 hz
      rwa [eq_of_vcBounded_zero h hS' hS𝒜] at hzS'
    · exact fun z hz => Set.mem_sUnion_of_mem hz hS𝒜
  show (⋃₀ 𝒜) ∩ (A : Set α) = ↑T
  rw [hU, Set.inter_comm]
  exact hSA

end StructuralIgnorance
