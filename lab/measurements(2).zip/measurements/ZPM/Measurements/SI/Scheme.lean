/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import Mathlib.Data.ENat.Lattice

/-!
# Kernel schemes, side-information price, and window defects

Sample compression in the sense of Littlestone and Warmuth (1986): a scheme keeps
at most `k` labeled points of a realizable sample and must regenerate every label
of the sample from the kept part alone. The side-information variant
(Moran–Yehudayoff 2016) lets the compressor transmit an extra index from a finite
set alongside the kept points.

Objects, over an arbitrary class `𝒜 : Set (Set α)` (labels carried by membership):

* `IsSample 𝒜 A T` — the labeled window `(A, T)` is realizable: some member of `𝒜`
  meets `A` in exactly `T`.
* `residual 𝒜 Z W` — the members consistent with every label of the pair `(Z, W)`.
* `Convention α`, `IsKernel`, `HasKernelScheme 𝒜 k` — reconstruction as a total
  function of the kept labeled pair alone, and the kernel scheme as: one
  reconstruction rule under which every realizable sample contains a generating
  kernel of at most `k` points. This is the compression-map-free form of the
  two-map definition of Littlestone and Warmuth: the compression map's only role
  is to select the kernel, so it is existentially absorbed.
* `HasIndexedScheme 𝒜 k c` — the same with an index in `Fin c` transmitted with
  the kernel; `hasIndexedScheme_one_iff` identifies index size one with the
  index-free scheme.
* `price 𝒜 k` — the least index size making kernel size `k` feasible (`⊤` if
  none): the side-information price of compressing at `k`. Kernel size and index
  size are accounted separately, following the size split of Moran–Yehudayoff.
* `windowTrace 𝒜 A` — the label patterns `𝒜` realizes on the finite window `A`.
* `SetShatters 𝒜 B`, `vcBounded 𝒜 d` — shattering of a finite set by a class of
  sets and the resulting VC bound: the `Set`-grammar port of `Finset.Shatters`
  and `Finset.vcDim` (Mathlib `Combinatorics.SetFamily.Shatter`).
-/

namespace StructuralIgnorance

open Finset

variable {α : Type*} [DecidableEq α]

/-- The labeled window `(A, T)` is realizable in `𝒜`: some member meets `A` in
exactly `T`. Points of `T` are labeled 1, points of `A \ T` are labeled 0
(Littlestone–Warmuth 1986, realizable samples). -/
def IsSample (𝒜 : Set (Set α)) (A T : Finset α) : Prop :=
  ∃ S ∈ 𝒜, (A : Set α) ∩ S = ↑T

omit [DecidableEq α] in
/-- Realizable label patterns are supported inside their window. -/
theorem IsSample.subset {𝒜 : Set (Set α)} {A T : Finset α} (h : IsSample 𝒜 A T) :
    T ⊆ A := by
  obtain ⟨S, _, hS⟩ := h
  intro x hx
  have hx' : (x : α) ∈ (A : Set α) ∩ S := by
    rw [hS]
    exact_mod_cast hx
  exact_mod_cast hx'.1

/-- The residual class of a labeled pair: members consistent with every label of
`(Z, W)`. This is the version space of the pair (Mitchell's version spaces; the
`VersionSpace` of cslib's `MachineLearning.PACLearning`, in `Set` grammar). -/
def residual (𝒜 : Set (Set α)) (Z W : Finset α) : Set (Set α) :=
  {S ∈ 𝒜 | (Z : Set α) ∩ S = ↑W}

omit [DecidableEq α] in
/-- Membership in the residual unfolds to class membership plus label
consistency. -/
theorem mem_residual {𝒜 : Set (Set α)} {Z W : Finset α} {S : Set α} :
    S ∈ residual 𝒜 Z W ↔ S ∈ 𝒜 ∧ (Z : Set α) ∩ S = ↑W :=
  Iff.rfl

/-- A reconstruction rule: from a kept labeled pair — kernel points and their
1-labeled part — to a total hypothesis. Total by convention; only values on
realizable pairs matter. -/
abbrev Convention (α : Type*) := Finset α → Finset α → Set α

/-- `ρ` regenerates the sample `(A, T)` from the kernel `Z`: the kernel is kept
inside the sample, has at most `k` points, and the reconstructed hypothesis meets
`A` in exactly `T`. -/
def IsKernel (ρ : Convention α) (k : ℕ) (A T Z : Finset α) : Prop :=
  Z ⊆ A ∧ #Z ≤ k ∧ ρ Z (Z ∩ T) ∩ (A : Set α) = ↑T

/-- A kernel scheme of size `k` with no side information: one reconstruction rule
under which every realizable sample contains a generating kernel of at most `k`
points (Littlestone–Warmuth 1986, in compression-map-free form). -/
def HasKernelScheme (𝒜 : Set (Set α)) (k : ℕ) : Prop :=
  ∃ ρ : Convention α, ∀ A T : Finset α, IsSample 𝒜 A T → ∃ Z, IsKernel ρ k A T Z

/-- A kernel scheme of size `k` with side information from `Fin c`
(Moran–Yehudayoff 2016): the compressor additionally transmits an index, and
reconstruction may read it. -/
def HasIndexedScheme (𝒜 : Set (Set α)) (k c : ℕ) : Prop :=
  ∃ ρ : Fin c → Convention α, ∀ A T : Finset α, IsSample 𝒜 A T →
    ∃ (i : Fin c) (Z : Finset α), IsKernel (ρ i) k A T Z

/-- Index size one is exactly no side information. -/
theorem hasIndexedScheme_one_iff {𝒜 : Set (Set α)} {k : ℕ} :
    HasIndexedScheme 𝒜 k 1 ↔ HasKernelScheme 𝒜 k := by
  constructor
  · rintro ⟨ρ, hρ⟩
    refine ⟨ρ 0, fun A T hAT => ?_⟩
    obtain ⟨i, Z, hZ⟩ := hρ A T hAT
    exact ⟨Z, by rwa [Subsingleton.elim (0 : Fin 1) i]⟩
  · rintro ⟨ρ, hρ⟩
    exact ⟨fun _ => ρ, fun A T hAT => ⟨0, hρ A T hAT⟩⟩

/-- The side-information price of compressing `𝒜` at kernel size `k`: the least
index size for which a scheme exists, `⊤` if none. `price 𝒜 k = 1` is compression
with no side information. -/
noncomputable def price (𝒜 : Set (Set α)) (k : ℕ) : ℕ∞ :=
  ⨅ (c : ℕ) (_ : HasIndexedScheme 𝒜 k c), (c : ℕ∞)

open scoped Classical in
/-- The label patterns `𝒜` realizes on the finite window `A`, as a finite family:
the trace of the class through the window. Classically decidable filter; a
computable refinement is deferred to Mathlib preparation. -/
noncomputable def windowTrace (𝒜 : Set (Set α)) (A : Finset α) : Finset (Finset α) :=
  A.powerset.filter fun T => IsSample 𝒜 A T

omit [DecidableEq α] in
/-- Membership in the window trace unfolds to realizability. -/
theorem mem_windowTrace {𝒜 : Set (Set α)} {A T : Finset α} :
    T ∈ windowTrace 𝒜 A ↔ T ⊆ A ∧ IsSample 𝒜 A T := by
  classical
  simp [windowTrace, mem_filter, mem_powerset]

/-- The class `𝒜` shatters the finite set `B`: every sub-pattern of `B` is realized
by a member. `Set`-grammar port of `Finset.Shatters` (Mathlib
`Combinatorics.SetFamily.Shatter`). -/
def SetShatters (𝒜 : Set (Set α)) (B : Finset α) : Prop :=
  ∀ C ⊆ B, ∃ S ∈ 𝒜, (B : Set α) ∩ S = ↑C

/-- VC bound in `Set` grammar: no shattered set exceeds `d` points (the port of
`Finset.vcDim ≤ d`, Mathlib `Combinatorics.SetFamily.Shatter`). -/
def vcBounded (𝒜 : Set (Set α)) (d : ℕ) : Prop :=
  ∀ B : Finset α, SetShatters 𝒜 B → #B ≤ d

omit [DecidableEq α] in
/-- Shattering is monotone in the class: a larger class has more witnesses. -/
theorem SetShatters.mono_left {𝒜 ℬ : Set (Set α)} {B : Finset α}
    (h𝒜ℬ : 𝒜 ⊆ ℬ) (h : SetShatters 𝒜 B) : SetShatters ℬ B :=
  fun C hC => let ⟨S, hS, hBS⟩ := h C hC; ⟨S, h𝒜ℬ hS, hBS⟩

/-- Kernel schemes are monotone in the kernel size: the same convention and the
same kernels work at any larger bound. -/
theorem HasKernelScheme.mono {𝒜 : Set (Set α)} {k k' : ℕ}
    (h : HasKernelScheme 𝒜 k) (hkk : k ≤ k') : HasKernelScheme 𝒜 k' := by
  obtain ⟨ρ, hρ⟩ := h
  refine ⟨ρ, fun A T hAT => ?_⟩
  obtain ⟨Z, hZA, hZk, hZ⟩ := hρ A T hAT
  exact ⟨Z, hZA, hZk.trans hkk, hZ⟩

end StructuralIgnorance
