/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.Measurements.HC.Abstract
import ZPM.Measurements.HC.Combinatorial
import ZPM.Measurements.HC.MutualInformation
import ZPM.Measurements.HC.Fibered
import ZPM.Measurements.HC.FiberedInterpolation
import ZPM.Measurements.HC.Spekkens
import ZPM.Measurements.HC.Multipartite
import ZPM.Measurements.HC.ApproximateFiveWay
import ZPM.Measurements.HC.Marginals
import ZPM.Measurements.HC.HigherObstruction
import ZPM.Measurements.HC.ParityFamily
import ZPM.Measurements.HC.FiveWayPi
import ZPM.Measurements.HC.ProductLaw
import ZPM.Measurements.HC.FiberProduct
import ZPM.Measurements.HC.Amalgamation
import ZPM.Measurements.HC.GrahamBridge
import ZPM.Measurements.HC.AffineEngine
import ZPM.Measurements.HC.CyclicConverse
import ZPM.Measurements.HC.VorobevConverse
import ZPM.Measurements.HC.Dirac
import ZPM.Measurements.HC.PRBox
import ZPM.Measurements.HC.QuantumMarginal
import ZPM.Measurements.HC.QJTTwoClique
import ZPM.Measurements.HC.QJTOpenProblem
import ZPM.Measurements.HC.CechCycle
import ZPM.Measurements.HC.CechNerve
import ZPM.Measurements.HC.CechK
import ZPM.Measurements.HC.Keystone
import ZPM.Measurements.HC.FOL.Polish
import ZPM.Measurements.HC.FOL.TypeSpaceTopology
import ZPM.Measurements.HC.FOL.TypeSpaceCompact
import ZPM.Measurements.HC.FOL.TypeSpaceSeparation
import ZPM.Measurements.HC.FOL.SupportDistributionSeparation
import ZPM.Measurements.HC.FOL.Amalgamation
import ZPM.Measurements.HC.FOL.FiveWayCI
import ZPM.Measurements.HC.FOL.FiveWayInterpolation
import ZPM.Measurements.HC.FOL.FiveWayStructural
import ZPM.Measurements.HC.FOL.LegIVBridge

/-!
# Hidden Channel Capacity

Barrel for the HC measurement. HC is a measurement instrument for the BASE structure of an
admissible class: the global, geometric structure of which joint configurations are
co-admissible over a shared interface, read prior to any local weighting. `HC = 0` exactly
when that base structure is trivial, the class being a product over the interface
(decomposable, fiber-product surjective, conditionally independent), so the local ends
already determine the whole; when `HC > 0` the base carries a global observable
non-vacuously disjoint from what any amount of local (fiber-side) measurement can provide.
The direction of explanation runs from discovered base structure to what local measurement
can and cannot achieve. Twenty-eight layers, plus the first-order stratum (FOL/), each an instrument reading base structure:

* `Abstract` — substrate-neutral interpolation–amalgamation biconditional and the
  oscillation theorem;
* `Combinatorial` — the finite support-level defect `hcComb` and the
  factorization characterizations;
* `MutualInformation` — the information-theoretic leg on a single fiber, where the
  base rectangularity of `κ` decides the fiber quantity: the uniform distribution
  on `κ` has zero mutual information iff `κ` is rectangular;
* `Fibered` — the shared-coordinate model `κ ⊆ S × A × B`, where decomposability
  (ii), rectangularity (iii), fiber-product surjectivity (v), and conditional
  independence (iv) become distinct propositions (`fiveWay_fibered`);
* `FiberedInterpolation` — the interpolation leg (i), instantiating the abstract
  layer at the fibered model, giving the genuine five-leg `fiveWay_full`;
* `Spekkens` — the quantum-foundational instance over `Fin 4 × Fin 4`, witnessing
  the oscillation theorem;
* `Multipartite` — the arity-`n` substrate: projections, the rectangular hull,
  and the defect `hcCombPi`;
* `ApproximateFiveWay` — the quantitative five-way: two-sided bounds between the
  defect and the total correlation of the canonical measure (lower leg: shape
  forces information; upper leg: the counting bound), with the bipartite member
  witness;
* `Marginals` — sub-team marginals as a presheaf over the subset lattice
  (`projS`, the `restrict₂` compatibility, hull-marginal commutation);
* `HigherObstruction` — the base defect is irreducibly higher-degree, invisible to
  the local ends: the parity relation's marginals are all blind to its defect and
  the Specker triangle fails to amalgamate, the acceptance tests of the
  cohomological-roots programme;
* `ParityFamily` — the theorem schema: at every arity `n ≥ 2` the parity
  relation's proper marginals are all full while the defect is `2^(n-1)`;
* `FiveWayPi` — the exact five-way at arity `n`: rectangularity, vanishing
  defect, vanishing total correlation of the canonical measure, cross-closure,
  and the counting identity, with the factorization of the canonical measure;
* `ProductLaw` — juxtaposition: size and hull are multiplicative, and the
  defect obeys the Leibniz rule — a derivation over the (hull, size)
  bi-grading, not a homomorphism;
* `FiberProduct` — the natural join over a genuine interface: the defect
  decomposition along a two-team cover (defect = join-level defect +
  reconstruction gap), two-cover amalgamation (consistent pairs always glue),
  and the kernel-checked failure of the Leibniz law at a shared part;
* `Amalgamation` — the amalgamation leg, where an acyclic base licenses base-side
  reconstruction: local structures, families, pairwise consistency, the natural
  join, and the positive Vorob'ev theorem (a running-intersection, pairwise-
  consistent family always glues), with the Specker triangle as the cyclic-base
  converse instance (consistent, no RIP order, no glue);
* `GrahamBridge` — the decidability face: order-free acyclicity, nondeterministic
  ear elimination, the bridge `acyclic_iff_grahamReducible` making `Acyclic`
  decidable, the order-free amalgamation theorem `glues_of_acyclic`, and the
  kernel facts that the Specker cover is not acyclic while the path cover is;
* `AffineEngine` — the affine obstruction engine: F2-linear constraint systems
  with per-vector constants and the uniform replication rule, the elementary
  Gaussian solvability core, the exact marginal computation (interfaces see
  precisely the visible constraints), and the packaged obstruction theorem —
  a closed coherent system with a hosted odd dependency yields a consistent
  family of nonempty local relations that does not glue;
* `CyclicConverse` — the converse machine: ear-free core extraction from a
  non-Graham-reducible cover, the cycle-pair F2 algebra (consecutive pairs of a
  cyclic vertex list telescope to `∅`), and the cycle rung `cycle_obstruction` —
  a clean hosted cycle yields a consistent non-gluing family over the cover;
* `VorobevConverse` — the converse finders and assembly: the parity bridge
  `mem_xorSum`, the primal grammar (adjacency, cliques, conformality), the
  clique datum from a minimal non-covered clique, the one-step GYO collapse
  (a simplicial shared vertex of a conformal cover yields an ear), the
  chordless-cycle datum (chordlessness is cleanliness), the chained core
  extraction with the cleanliness transfer, and `capstone_of_dichotomy` —
  the full converse modulo the chordal/conformal dichotomy (Dirac's lemma);
* `Dirac` — the final leg: a bespoke path grammar (`List.IsChain`-based walks,
  reachability, minimal paths and connectors) over the primal graph, the
  minimal-separator clique argument `sep_clique_step` (two shortest side-paths
  assemble into a cycle whose chord is killed by splice-minimality, side-
  disjointness, or assumed non-adjacency), Dirac's lemma `dirac_strong` (a
  chordless-cycle-free vertex set is complete or holds two nonadjacent
  simplicial vertices), the discharged dichotomy `earFree_dichotomy`, and the
  unconditional capstone `exists_consistent_not_glues_of_not_acyclic` with the
  headline equivalence `acyclic_iff_forall_consistent_glues` — a cover is
  acyclic exactly when pairwise consistency forces gluing;
* `PRBox` — the quantum leg, read base-first: the CHSH scenario as the 4-cycle
  cover (not acyclic, by `decide`), whose cyclic shape alone licenses a global
  observable no local end can emulate. The capstone instance `chsh_hosts_nonglue`
  forces the possibility of contextuality from the cover's geometry, and the
  explicit possibilistic PR box is pairwise consistent and locally nonempty yet
  has no global section at all (`prBox_no_global_section`, strong contextuality
  in the Abramsky–Brandenburger sense) and no gluing (`prBox_not_glues`);
* `QuantumMarginal` — L0 of the quantum junction tree arc, the base-side marginal
  presheaf over the cover's subset lattice: the abstract
  partial-trace primitive `MState.traceAlong` with its entry calculus and the
  abstract composition theorem (iterated marginalization composes, the
  Lauritzen–Zwiernik Lem 2.2 shape); the team-indexed partial trace `ptraceS`
  (the quantum `projS`) and quantum restriction `qRestrict₂` as instances; the
  presheaf law `qRestrict₂_ptraceS`; the four matrix-level pull-out lemmas
  (Lem 2.3); and the diagonal bridge `ptraceS_ofClassical` through the
  classical distribution marginal `ProbDistribution.marginal`;
* `QJTTwoClique` — L2a banked, the ACYCLIC control where the base licenses
  reconstruction: the COMPLETE two-clique quantum junction tree
  theorem (Lauritzen–Zwiernik arXiv:2605.19453, Thm 3.1): the logarithmic
  candidate `T(R)`, the trace bound `trC_le_one` proved WITHOUT Lieb's
  three-matrix inequality (the eq. 13 route specialized to two cliques), the
  normalized divergence identity `lem_3_2`, existence
  (`sigT_markov_of_trC_eq_one`), uniqueness (`markov_completion_eq_sigT`), and
  the assembled `lz_theorem_3_1`; plus the two pieces the vendored corpus
  lacked: the shared-eigenbasis double sum `HermitianMat.inner_cfc_cfc` and the
  FAITHFULNESS of quantum relative entropy `inner_log_faithful` (the equality
  case of Klein's inequality);
* `QJTOpenProblem` — the open problem, resolved base-first in the kernel: the
  non-chordal 4-cycle base licenses a global observable no local end can emulate.
  The quantization arrow (`MState.diagDist` with both naturality squares over the
  one marginal presheaf; the transport theorem `completionQ_diag_iff`: quantum
  completability of classically-embedded families = classical completability, any
  cover, any arity) makes the base structure quantization-invariant; the
  support-obstruction lift `no_completionC_of_empty_join` (a base obstruction
  kills every fibre); and the information-level witness: the smoothed cycle family
  at `r = 7/8` (`edgeDist`) has full-support local ends (`edgeDist_full_support`,
  so the support-stratum obstruction vanishes) and is pairwise consistent
  (`edgeDist_site_uniform`), yet admits no classical and no quantum completion
  (`cycleFam_not_completableC/Q`, via the base's cycle correlation bound
  `cycle_bound` and the kernel sign-product contradiction `one_le_disag`). The
  deciding quantity for the Lauritzen–Zwiernik completion problem off chordal
  covers is a strictly GLOBAL base observable, unreachable from the support
  stratum: the PR-box parity class (`r = 1`) descended to the information stratum.
  The base-geometry resolution is COMPLETE (`qjt_not_local`,
  `subcover_markov_completable`): every proper subcover has an acyclic base, so
  base-side sufficiency gives a strictly positive junction-tree completion
  (`pathDist`, `pathDist_marginal`) that is classically Markov (`pathDist_isMarkov`,
  factorization CI at both separators) and quantum Markov
  (`pathCompletion_quantum_markov`: vanishing qcmi at both separators, via the
  general bridge `qcmi_ofClassical_of_factorization`, classical conditional
  independence embedding to quantum Markov chains, and the new diagonal bridges
  `relabel_ofClassical`, `traceLeft_ofClassical`, `traceRight_ofClassical`);
  yet the full cyclic base admits no completion at all: a witness family refuting
  every sufficient locality criterion at or below that strength (full support,
  pairwise consistency, strictly positive Markov completability of all proper
  subcovers do not jointly imply global completability off chordal covers);
* `CechCycle` — the Čech objects made first-class at cycle-nerve scope: the
  functor law `completion_gives_section` (completions map to sections of the
  support family; the support lift is its contrapositive); the B3 closure
  `prBox_fibre_obstruction(_quantum)` through the banked `joinFam prBox = ∅`;
  the concrete H¹ computation (`coboundary`, `holF2`, `holF2_coboundary`,
  `coboundary_range`: im δ = ker hol, so `H¹(cycle nerve; F₂) ≅ F₂`); the
  support stratum AS cohomology (`parityBox_joinFam_empty_iff`: empty join iff
  nonzero class; `prBox_class_nonzero`); the H¹-graded facet system of the
  information stratum (`cycle_bound_gen` for every nonzero-class cochain,
  FAILING at zero classes: `cycle_bound_fails_of_hol_zero` — the grading is
  non-vacuous both ways); and the exact moduli of the class
  (`cycleFam_completable_iff`, quantum face `cycleFam_completableQ_iff`): the
  smoothed family is completable iff `1/4 ≤ r ≤ 3/4`, forward by the two
  facets, backward by the disagreement-strata mixture `mixDist`. The
  support/information gap is the kernel of the change of coefficients
  Boolean ← real over one nerve, with its exact extent kernel-verified;
* `CechNerve` — the general-cover Čech machinery: the degree-1 data of the
  parity local system over ANY cover of ANY site type is the incidence complex
  (site cochains → team cochains by `parityOn`; the simplicial δ⁰ of the nerve
  for graph covers), its 1-cycles the even subcovers (`xorSum D = ∅`), and the
  obstruction computed by the Fredholm alternative
  (`exists_section_iff_even_orthogonal`: realizable twists = cycle-orthogonal
  twists), CONSUMING the affine engine's Gaussian core; the support stratum at
  full generality (`parityFamG_joinFam_nonempty_iff`), the information stratum
  at full generality (`evenSubcover_bound`: cycle inequalities for every even
  subcover with odd pairing, `evenSubcover_bound_attained`: sharp at realizable
  twists — the facet system of the marginal polytope graded by the even-subcover
  pairing, non-vacuous both ways, automatically stable under cover enlargement);
  the derivation instances (4-cycle `chshCover_section_iff` re-deriving the
  banked holonomy criterion, Specker triangle `specker_odd_no_section`
  discharging the HigherObstruction acceptance test cohomologically, n-cycle
  `nCycle_section_iff` for every arity with constructive prefix-sum sections);
  and the functor leg (`section_iff_of_equiv`: verdict transport along site
  equivalences);
* `CechK` — field-general coefficients: the finite-dimensional Fredholm
  alternative for ARBITRARY matrices over ARBITRARY fields
  (`range_mulVecLin_eq_orthogonal_ker_transpose`: `range M = (ker Mᵀ)ᗮ` under
  the nondegenerate dot form `dotB`; membership and solvability forms), the
  incidence instance (`incidenceM`, `incidence_section_iff_K`: prescribed team
  sums over any field realizable iff orthogonal to every cocycle of the
  transpose), and the TWO-ENGINE CROSS-VALIDATION
  (`even_orthogonal_iff_cocycle_orthogonal`): the Gaussian-elimination criterion
  of the affine engine and the rank-argument criterion of the Fredholm
  alternative agree at `ZMod 2` — proved by chaining the two engines through the
  section space, so the consistency of the two computations of the degree-1
  obstruction is itself a theorem. Next rungs stated, not claimed:
  non-invertible cover morphisms, degrees ≥ 2, presheaf coefficients;
* `Keystone` — the thesis-level statements, read from base structure outward:
  base-side sufficiency (`completability_class_functional`: the verdict is a
  functional of one base-class evaluation) paired with local-end blindness
  (`completability_not_support_functional`: identical local supports, opposite
  verdicts, so extendability is not a functional of the local support family),
  and one-class-three-strata (`three_strata_one_class`: the same degree-1 base
  class decides the possibilistic, distributional, and quantum verdicts). The
  Lauritzen–Zwiernik resolution is the quantum-stratum shadow of this base
  structure.
-/
