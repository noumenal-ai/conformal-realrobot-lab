/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.InformationTheory.KullbackLeibler.Real
import Mathlib.MeasureTheory.Measure.Decomposition.RadonNikodym
import Mathlib.InformationTheory.KullbackLeibler.Basic

/-!
# KL divergence is invariant under measurable equivalences

The Kullback-Leibler divergence is unchanged by a relabelling of the underlying measurable space:
for a measurable equivalence `e : α ≃ᵐ β`, both the real-valued `klDivReal` and the `ℝ≥0∞`-valued
`klDiv` satisfy `D (P.map e) (Q.map e) = D P Q`. The Radon-Nikodym derivative transports by
`MeasurableEmbedding.rnDeriv_map` and the integral by the change-of-variables formula
`integral_map`; the auxiliary `llr_map_equiv` records the same invariance for the log-likelihood
ratio. This is the change-of-variables engine behind the whitening reduction of the multivariate
Gaussian KL closed form.
-/

noncomputable section

open MeasureTheory

namespace InformationTheory

variable {α β : Type*} [MeasurableSpace α] [MeasurableSpace β]

/-- **KL invariance under a measurable equivalence.** For `σ`-finite measures `P`, `Q` on `α`
and a measurable equivalence `e : α ≃ᵐ β`, `klDivReal (P.map e) (Q.map e) = klDivReal P Q`. -/
theorem klDivReal_map_measurableEquiv (e : α ≃ᵐ β) (P Q : Measure α)
    [SigmaFinite P] [SigmaFinite Q] :
    klDivReal (P.map e) (Q.map e) = klDivReal P Q := by
  have he : MeasurableEmbedding e := e.measurableEmbedding
  -- Absolute continuity transfers across the equivalence (push back through `e.symm`).
  have hac_iff : (P.map e).AbsolutelyContinuous (Q.map e) ↔ P.AbsolutelyContinuous Q := by
    constructor
    · intro h
      have : (P.map e).map e.symm |>.AbsolutelyContinuous ((Q.map e).map e.symm) :=
        h.map e.symm.measurable
      simpa [Measure.map_map, e.symm.measurable, e.measurable] using this
    · exact fun h => h.map e.measurable
  unfold klDivReal
  by_cases hac : P.AbsolutelyContinuous Q
  · rw [if_pos (hac_iff.mpr hac), if_pos hac]
    -- Change of variables in the integral over `P.map e`.
    rw [integral_map e.measurable.aemeasurable]
    swap
    · exact (Measurable.aestronglyMeasurable
        (by fun_prop : Measurable
          (fun y => Real.log ((P.map e).rnDeriv (Q.map e) y).toReal)))
    refine integral_congr_ae ?_
    -- The pushed-forward Radon-Nikodym derivative, precomposed with `e`, agrees a.e.-`P` with the
    -- original one.
    have hrn : (fun x => ((P.map e).rnDeriv (Q.map e) (e x))) =ᵐ[Q] P.rnDeriv Q :=
      he.rnDeriv_map P Q
    have hrnP : (fun x => ((P.map e).rnDeriv (Q.map e) (e x))) =ᵐ[P] P.rnDeriv Q :=
      hac.ae_le hrn
    filter_upwards [hrnP] with x hx
    show Real.log ((P.map e).rnDeriv (Q.map e) (e x)).toReal
      = Real.log (P.rnDeriv Q x).toReal
    rw [hx]
  · rw [if_neg (fun h => hac (hac_iff.mp h)), if_neg hac]

/-- The log-likelihood ratio is invariant (a.e.) under pushforward by a measurable equivalence:
`llr (μ.map e) (ν.map e) (e x) =ᵐ[ν] llr μ ν x`. -/
lemma llr_map_equiv (e : α ≃ᵐ β) (μ ν : Measure α) [SigmaFinite μ] [SigmaFinite ν] :
    (fun x => llr (μ.map e) (ν.map e) (e x)) =ᵐ[ν] llr μ ν := by
  have h := e.measurableEmbedding.rnDeriv_map μ ν
  filter_upwards [h] with x hx
  simp only [llr]
  rw [hx]

/-- **KL invariance under a measurable equivalence** (`ℝ≥0∞`-valued). For finite measures `μ`, `ν`
and a measurable equivalence `e : α ≃ᵐ β`, `klDiv (μ.map e) (ν.map e) = klDiv μ ν`. -/
theorem klDiv_map_equiv (e : α ≃ᵐ β) (μ ν : Measure α)
    [IsFiniteMeasure μ] [IsFiniteMeasure ν] :
    klDiv (μ.map e) (ν.map e) = klDiv μ ν := by
  have hac_iff : (μ.map e) ≪ (ν.map e) ↔ μ ≪ ν := by
    constructor
    · intro h
      have := e.symm.measurableEmbedding.absolutelyContinuous_map h
      rwa [Measure.map_map e.symm.measurable e.measurable,
        Measure.map_map e.symm.measurable e.measurable,
        e.symm_comp_self, Measure.map_id, Measure.map_id] at this
    · exact e.measurableEmbedding.absolutelyContinuous_map
  by_cases hac : μ ≪ ν
  · have hint_iff : Integrable (llr (μ.map e) (ν.map e)) (μ.map e) ↔
        Integrable (llr μ ν) μ := by
      rw [integrable_map_equiv e]
      exact integrable_congr (llr_map_equiv e μ ν |>.filter_mono hac.ae_le)
    by_cases hint : Integrable (llr μ ν) μ
    · rw [klDiv_of_ac_of_integrable (hac_iff.2 hac) (hint_iff.2 hint),
        klDiv_of_ac_of_integrable hac hint]
      have hmass : (μ.map e).real Set.univ = μ.real Set.univ := by
        rw [measureReal_def, measureReal_def, e.map_apply, Set.preimage_univ]
      have hmassν : (ν.map e).real Set.univ = ν.real Set.univ := by
        rw [measureReal_def, measureReal_def, e.map_apply, Set.preimage_univ]
      have hintegral : ∫ y, llr (μ.map e) (ν.map e) y ∂(μ.map e) = ∫ x, llr μ ν x ∂μ := by
        rw [integral_map_equiv e (llr (μ.map e) (ν.map e))]
        exact integral_congr_ae (llr_map_equiv e μ ν |>.filter_mono hac.ae_le)
      rw [hmass, hmassν, hintegral]
    · rw [klDiv_of_not_integrable (hint_iff.not.2 hint), klDiv_of_not_integrable hint]
  · rw [klDiv_of_not_ac (hac_iff.not.2 hac), klDiv_of_not_ac hac]

end InformationTheory
