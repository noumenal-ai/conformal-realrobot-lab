/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.InformationTheory.KullbackLeibler.MapEquiv
import Mathlib.InformationTheory.KullbackLeibler.ChainRule
import Mathlib.MeasureTheory.Constructions.Pi

/-!
# KL tensorization over finite product measures

For finitely many independent coordinates the Kullback-Leibler divergence of a product measure
splits as a sum of the coordinate-wise divergences:
`klDiv (Measure.pi P) (Measure.pi Q) = ∑ᵢ klDiv (P i) (Q i)`, and the same for the real-valued
`klDivReal` under per-coordinate absolute continuity and finiteness. Both the `Fin n`-indexed form
and its reindexing to an arbitrary `Fintype` are provided. This is the step that lets a
diagonalized multivariate Gaussian KL split into its `d` one-dimensional Gaussian-Gaussian factors.

The proofs reduce to Mathlib's KL chain rule (`klDiv_compProd_eq_add`, `klDiv_compProd_left`) using
the invariance of KL under measurable equivalences (`klDiv_map_equiv`).
-/

noncomputable section

open MeasureTheory ProbabilityTheory

namespace InformationTheory

variable {α β : Type*} {mα : MeasurableSpace α} {mβ : MeasurableSpace β}

/-- Two products sharing the same first marginal reduce to the second-coordinate KL:
`klDiv (μ.prod ν) (μ.prod ν') = klDiv ν ν'`. -/
lemma klDiv_prod_same_left (μ : Measure α) (ν ν' : Measure β)
    [IsProbabilityMeasure μ] [IsFiniteMeasure ν] [IsFiniteMeasure ν'] :
    klDiv (μ.prod ν) (μ.prod ν') = klDiv ν ν' := by
  let e : α × β ≃ᵐ β × α := MeasurableEquiv.prodComm
  have hcoe : ⇑e = Prod.swap := by
    rw [← MeasurableEquiv.coe_toEquiv]; rfl
  have hswap := klDiv_map_equiv e (μ.prod ν) (μ.prod ν')
  rw [show ((μ.prod ν).map e) = ν.prod μ by
        rw [hcoe]; exact Measure.prod_swap,
      show ((μ.prod ν').map e) = ν'.prod μ by
        rw [hcoe]; exact Measure.prod_swap] at hswap
  rw [← hswap]
  rw [← Measure.compProd_const (ν := μ) (μ := ν),
      ← Measure.compProd_const (ν := μ) (μ := ν')]
  exact klDiv_compProd_left ν ν' (Kernel.const β μ)

/-- **Binary KL tensorization.** For probability measures,
`klDiv (μ.prod ν) (μ'.prod ν') = klDiv μ μ' + klDiv ν ν'`. -/
theorem klDiv_prod (μ μ' : Measure α) (ν ν' : Measure β)
    [IsProbabilityMeasure μ] [IsProbabilityMeasure μ']
    [IsProbabilityMeasure ν] [IsProbabilityMeasure ν'] :
    klDiv (μ.prod ν) (μ'.prod ν') = klDiv μ μ' + klDiv ν ν' := by
  rw [← Measure.compProd_const (ν := ν) (μ := μ),
      ← Measure.compProd_const (ν := ν') (μ := μ')]
  rw [klDiv_compProd_eq_add μ μ' (Kernel.const α ν) (Kernel.const α ν')]
  rw [Measure.compProd_const, Measure.compProd_const]
  rw [klDiv_prod_same_left μ ν ν']

/-- **KL tensorization over a finite product**, indexed by `Fin (n+1)`:
`klDiv (Measure.pi P) (Measure.pi Q) = ∑ i, klDiv (P i) (Q i)`. -/
theorem klDiv_pi {n : ℕ} {X : Fin n → Type*} {mX : ∀ i, MeasurableSpace (X i)}
    (P Q : ∀ i, Measure (X i)) [∀ i, IsProbabilityMeasure (P i)]
    [∀ i, IsProbabilityMeasure (Q i)] :
    klDiv (Measure.pi P) (Measure.pi Q) = ∑ i, klDiv (P i) (Q i) := by
  induction n with
  | zero =>
    simp only [Finset.univ_eq_empty, Finset.sum_empty]
    have hPQ : Measure.pi P = Measure.pi Q := by
      rw [Measure.pi_of_empty P, Measure.pi_of_empty Q]
    rw [hPQ, klDiv_self]
  | succ m ih =>
    -- Peel off the first coordinate: `piFinSuccAbove` splits `Measure.pi` as a binary product of
    -- the `0`th factor with the product over the remaining coordinates.
    set eP := MeasurableEquiv.piFinSuccAbove X 0
    have hP := measurePreserving_piFinSuccAbove P (0 : Fin (m + 1))
    have hQ := measurePreserving_piFinSuccAbove Q (0 : Fin (m + 1))
    have key : klDiv (Measure.pi P) (Measure.pi Q)
        = klDiv ((P 0).prod (Measure.pi fun j => P ((0 : Fin (m+1)).succAbove j)))
            ((Q 0).prod (Measure.pi fun j => Q ((0 : Fin (m+1)).succAbove j))) := by
      have hmapP : (Measure.pi P).map eP
          = (P 0).prod (Measure.pi fun j => P ((0 : Fin (m+1)).succAbove j)) := hP.map_eq
      have hmapQ : (Measure.pi Q).map eP
          = (Q 0).prod (Measure.pi fun j => Q ((0 : Fin (m+1)).succAbove j)) := hQ.map_eq
      rw [← hmapP, ← hmapQ, klDiv_map_equiv eP (Measure.pi P) (Measure.pi Q)]
    rw [key]
    -- Binary tensorization on the split, the inductive hypothesis on the tail, and reindexing of
    -- the resulting sum over `Fin.succAbove`.
    rw [klDiv_prod (P 0) (Q 0)
        (Measure.pi fun j => P ((0 : Fin (m+1)).succAbove j))
        (Measure.pi fun j => Q ((0 : Fin (m+1)).succAbove j))]
    rw [ih (fun j => P ((0 : Fin (m+1)).succAbove j))
        (fun j => Q ((0 : Fin (m+1)).succAbove j))]
    rw [Fin.sum_univ_succAbove (fun i => klDiv (P i) (Q i)) 0]

/-- **KL tensorization for the real-valued `klDivReal`.** Under per-coordinate absolute continuity
and finiteness, `klDivReal (Measure.pi P) (Measure.pi Q) = ∑ i, klDivReal (P i) (Q i)`. -/
theorem klDivReal_pi {n : ℕ} {X : Fin n → Type*} {mX : ∀ i, MeasurableSpace (X i)}
    (P Q : ∀ i, Measure (X i)) [∀ i, IsProbabilityMeasure (P i)]
    [∀ i, IsProbabilityMeasure (Q i)]
    (hac : ∀ i, (P i).AbsolutelyContinuous (Q i))
    (hfin : ∀ i, klDiv (P i) (Q i) ≠ ⊤) :
    klDivReal (Measure.pi P) (Measure.pi Q)
      = ∑ i, klDivReal (P i) (Q i) := by
  have hfin_pi : klDiv (Measure.pi P) (Measure.pi Q) ≠ ⊤ := by
    rw [klDiv_pi P Q]
    exact ENNReal.sum_ne_top.mpr fun i _ => hfin i
  have hac_pi : (Measure.pi P).AbsolutelyContinuous (Measure.pi Q) :=
    (klDiv_ne_top_iff.mp hfin_pi).1
  rw [klDivReal_eq_toReal_klDiv _ _ hac_pi, klDiv_pi P Q]
  rw [ENNReal.toReal_sum fun i _ => hfin i]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [klDivReal_eq_toReal_klDiv _ _ (hac i)]

/-- **KL tensorization over an arbitrary finite product** (general `Fintype` index). Reduces to the
`Fin`-indexed `klDiv_pi` by reindexing through `ι ≃ Fin (card ι)`. -/
theorem klDiv_pi' {ι : Type*} [Fintype ι] {X : ι → Type*} {mX : ∀ i, MeasurableSpace (X i)}
    (P Q : ∀ i, Measure (X i)) [∀ i, IsProbabilityMeasure (P i)]
    [∀ i, IsProbabilityMeasure (Q i)] :
    klDiv (Measure.pi P) (Measure.pi Q) = ∑ i, klDiv (P i) (Q i) := by
  -- Transport along a bijection `ι ≃ Fin (card ι)`: both products correspond under
  -- `piCongrLeft`, KL is invariant under that measurable equivalence, and the `Fin`-indexed sum
  -- reindexes back to `ι`.
  let e := Fintype.equivFin ι
  have hP : Measure.pi P
      = (Measure.pi fun j ↦ P (e.symm j)).map (MeasurableEquiv.piCongrLeft X e.symm) :=
    (Measure.pi_map_piCongrLeft e.symm P).symm
  have hQ : Measure.pi Q
      = (Measure.pi fun j ↦ Q (e.symm j)).map (MeasurableEquiv.piCongrLeft X e.symm) :=
    (Measure.pi_map_piCongrLeft e.symm Q).symm
  rw [hP, hQ, klDiv_map_equiv, klDiv_pi (fun j ↦ P (e.symm j)) (fun j ↦ Q (e.symm j))]
  exact Equiv.sum_comp e.symm (fun i ↦ klDiv (P i) (Q i))

/-- **KL tensorization for `klDivReal` over an arbitrary finite product** (general `Fintype`
index): the real-valued analogue of `klDiv_pi'`. -/
theorem klDivReal_pi' {ι : Type*} [Fintype ι] {X : ι → Type*} {mX : ∀ i, MeasurableSpace (X i)}
    (P Q : ∀ i, Measure (X i)) [∀ i, IsProbabilityMeasure (P i)]
    [∀ i, IsProbabilityMeasure (Q i)]
    (hac : ∀ i, (P i).AbsolutelyContinuous (Q i))
    (hfin : ∀ i, klDiv (P i) (Q i) ≠ ⊤) :
    klDivReal (Measure.pi P) (Measure.pi Q) = ∑ i, klDivReal (P i) (Q i) := by
  have hfin_pi : klDiv (Measure.pi P) (Measure.pi Q) ≠ ⊤ := by
    rw [klDiv_pi' P Q]
    exact ENNReal.sum_ne_top.mpr fun i _ => hfin i
  have hac_pi : (Measure.pi P).AbsolutelyContinuous (Measure.pi Q) :=
    (klDiv_ne_top_iff.mp hfin_pi).1
  rw [klDivReal_eq_toReal_klDiv _ _ hac_pi, klDiv_pi' P Q]
  rw [ENNReal.toReal_sum fun i _ => hfin i]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [klDivReal_eq_toReal_klDiv _ _ (hac i)]

end InformationTheory
