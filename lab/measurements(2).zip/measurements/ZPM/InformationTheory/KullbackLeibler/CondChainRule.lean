/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.InformationTheory.KullbackLeibler.Real
import Mathlib.InformationTheory.KullbackLeibler.ChainRule
import Mathlib.Probability.Kernel.RadonNikodym
import Mathlib.Probability.Kernel.CompProdEqIff

/-!
# Integral form of the conditional Kullback-Leibler chain rule

For a prior `μ`, two Markov kernels `κ, η : D →ₖ O`, and the compositions `μ ⊗ₘ κ`, `μ ⊗ₘ η`
sharing the first marginal `μ`, the Kullback-Leibler divergence of the joints is the average of
the pointwise divergences of the kernels:

`klDivReal (μ ⊗ₘ κ) (μ ⊗ₘ η) = ∫ x, klDivReal (κ x) (η x) ∂μ`,

and, for a constant second kernel (`η = const Q`),
`klDivReal (μ ⊗ₘ κ) (μ.prod Q) = ∫ x, klDivReal (κ x) Q ∂μ`.

This is the *integral form of the conditional KL divergence* — the direction that the additive
chain rule `InformationTheory.klDiv_compProd_eq_add` does not provide (it is vacuous on a shared
first marginal). It disintegrates the joint divergence through the fact that the Radon-Nikodym
derivative of the joints is the pointwise kernel derivative (`rnDeriv_compProd_right`).
-/

open MeasureTheory ProbabilityTheory InformationTheory Filter

variable {D O : Type*} {mD : MeasurableSpace D} {mO : MeasurableSpace O}
  {μ : Measure D} {κ η : Kernel D O}

namespace ProbabilityTheory

/-- **The Radon-Nikodym derivative of a shared-first-marginal `compProd` is the pointwise kernel
derivative.** For Markov kernels with `μ ⊗ₘ κ ≪ μ ⊗ₘ η`,
`∂(μ ⊗ₘ κ)/∂(μ ⊗ₘ η) (x, y) = κ.rnDeriv η x y` almost everywhere. -/
lemma rnDeriv_compProd_right [IsFiniteMeasure μ] [IsMarkovKernel κ] [IsMarkovKernel η]
    [MeasurableSpace.CountableOrCountablyGenerated D O]
    (hac : (μ ⊗ₘ κ) ≪ (μ ⊗ₘ η)) :
    (μ ⊗ₘ κ).rnDeriv (μ ⊗ₘ η) =ᵐ[μ ⊗ₘ η] fun p ↦ κ.rnDeriv η p.1 p.2 := by
  -- Pointwise absolute continuity of the kernels, `μ`-a.e., from the joint one.
  have hac_x : ∀ᵐ x ∂μ, (κ x) ≪ (η x) := (Measure.absolutelyContinuous_compProd_iff'.mp hac).2
  -- `μ ⊗ₘ κ` agrees with `μ ⊗ₘ (η.withDensity (∂κ/∂η))`, since `κ x = (η.withDensity …) x` a.e.
  have hcongr : μ ⊗ₘ κ = μ ⊗ₘ (η.withDensity (κ.rnDeriv η)) := by
    refine Measure.compProd_congr ?_
    filter_upwards [hac_x] with x hx
    exact (Kernel.withDensity_rnDeriv_eq hx).symm
  -- Push `withDensity` through the `compProd` and read off the derivative.
  have hmeas : Measurable (Function.uncurry (κ.rnDeriv η)) := κ.measurable_rnDeriv η
  rw [hcongr, Measure.compProd_withDensity hmeas]
  exact Measure.rnDeriv_withDensity (μ ⊗ₘ η) hmeas

end ProbabilityTheory

namespace InformationTheory

/-- **Integral form of the conditional KL chain rule.** For Markov kernels `κ, η` with
`μ ⊗ₘ κ ≪ μ ⊗ₘ η` and the joint log-likelihood ratio integrable, the KL divergence of the joints
is the `μ`-average of the pointwise KL divergences of the kernels:
`klDivReal (μ ⊗ₘ κ) (μ ⊗ₘ η) = ∫ x, klDivReal (κ x) (η x) ∂μ`. -/
theorem klDivReal_compProd (μ : Measure D) [IsProbabilityMeasure μ] (κ η : Kernel D O)
    [IsMarkovKernel κ] [IsMarkovKernel η] [MeasurableSpace.CountableOrCountablyGenerated D O]
    (hac : (μ ⊗ₘ κ) ≪ (μ ⊗ₘ η)) (hint : Integrable (llr (μ ⊗ₘ κ) (μ ⊗ₘ η)) (μ ⊗ₘ κ)) :
    klDivReal (μ ⊗ₘ κ) (μ ⊗ₘ η) = ∫ x, klDivReal (κ x) (η x) ∂μ := by
  have hac_x : ∀ᵐ x ∂μ, (κ x) ≪ (η x) := (Measure.absolutelyContinuous_compProd_iff'.mp hac).2
  -- The joint log-derivative agrees a.e. with the pointwise kernel log-derivative.
  have hbridge : (fun p ↦ Real.log ((μ ⊗ₘ κ).rnDeriv (μ ⊗ₘ η) p).toReal)
      =ᵐ[μ ⊗ₘ κ] fun p ↦ Real.log ((κ.rnDeriv η) p.1 p.2).toReal := by
    filter_upwards [hac.ae_le (rnDeriv_compProd_right hac)] with p hp
    rw [hp]
  have hint' : Integrable (fun p ↦ Real.log ((κ.rnDeriv η) p.1 p.2).toReal) (μ ⊗ₘ κ) :=
    hint.congr hbridge
  -- Rewrite `klDivReal` as an integral of the log-derivative and disintegrate the joint integral.
  rw [show klDivReal (μ ⊗ₘ κ) (μ ⊗ₘ η)
        = ∫ p, Real.log ((μ ⊗ₘ κ).rnDeriv (μ ⊗ₘ η) p).toReal ∂(μ ⊗ₘ κ) from by
      simp only [klDivReal, if_pos hac],
    integral_congr_ae hbridge, Measure.integral_compProd hint']
  -- The inner integral over `κ x` is the pointwise divergence `klDivReal (κ x) (η x)`.
  refine integral_congr_ae ?_
  filter_upwards [hac_x] with x hx
  rw [show klDivReal (κ x) (η x) = ∫ y, Real.log ((κ x).rnDeriv (η x) y).toReal ∂(κ x) from by
      simp only [klDivReal, if_pos hx]]
  refine integral_congr_ae ?_
  filter_upwards [hx.ae_le (Kernel.rnDeriv_eq_rnDeriv_measure (κ := κ) (η := η) (a := x))] with y hy
  rw [hy]

/-- **Integral form of the conditional KL chain rule against a fixed reference** (`η = const Q`).
`klDivReal (μ ⊗ₘ κ) (μ.prod Q) = ∫ x, klDivReal (κ x) Q ∂μ`; the shape consumed by the
PAC-privacy variational bound `mutualInformationReal_le_condKL`. -/
theorem klDivReal_compProd_prod (μ : Measure D) [IsProbabilityMeasure μ] (κ : Kernel D O)
    [IsMarkovKernel κ] (Q : Measure O) [IsProbabilityMeasure Q]
    [MeasurableSpace.CountableOrCountablyGenerated D O]
    (hac : (μ ⊗ₘ κ) ≪ μ.prod Q) (hint : Integrable (llr (μ ⊗ₘ κ) (μ.prod Q)) (μ ⊗ₘ κ)) :
    klDivReal (μ ⊗ₘ κ) (μ.prod Q) = ∫ x, klDivReal (κ x) Q ∂μ := by
  have hconst : μ.prod Q = μ ⊗ₘ Kernel.const D Q := Measure.compProd_const.symm
  rw [hconst] at hac hint ⊢
  rw [klDivReal_compProd μ κ (Kernel.const D Q) hac hint]
  simp only [Kernel.const_apply]

end InformationTheory
