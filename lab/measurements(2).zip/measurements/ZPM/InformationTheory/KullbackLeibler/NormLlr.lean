/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.InformationTheory.KullbackLeibler.Real
import Mathlib.InformationTheory.KullbackLeibler.ChainRule

/-!
# An L¹ bound on the log-likelihood ratio

For a finite measure `P` absolutely continuous with respect to a probability measure `R`, with
integrable log-likelihood ratio, the `L¹(P)` norm of the ratio is controlled by the KL divergence:

`∫ x, ‖llr P R x‖ ∂P ≤ klDivReal P R + 2`.

The signed integral of `llr` is `klDivReal P R`; the norm adds twice the integral of the negative
part, and a change of measure to `R` turns that into `∫ (dP/dR)·(−log (dP/dR))⁺ ∂R`, whose integrand
is bounded by `1` (from `log t ≤ t − 1`, so `-f log f ≤ 1 − f ≤ 1`) against the unit-mass `R`.

This is the tool that upgrades finiteness of a conditional KL divergence to genuine `L¹`
integrability of its integrand: composed over a Markov kernel it dominates the per-input `∫‖llr‖`
by a divergence-plus-constant that is integrable in the input. Mathlib has the finiteness criterion
(`klDiv_ne_top_iff`) but not this quantitative `L¹` control.
-/

open MeasureTheory Real

namespace InformationTheory

variable {α : Type*} {mα : MeasurableSpace α} {P R : Measure α}

/-- The density weighted by the negative part of its log is bounded by `1`:
`f · (−log f)⁺ ≤ 1` for `f ≥ 0`. On `f ≥ 1` the negative part vanishes; on `0 < f < 1`,
`−log f = log f⁻¹ ≤ f⁻¹ − 1`, so `f·(−log f) ≤ 1 − f ≤ 1`. -/
private lemma mul_negPart_log_le_one {f : ℝ} (hf : 0 ≤ f) : f * max (-Real.log f) 0 ≤ 1 := by
  rcases eq_or_lt_of_le hf with rfl | hf'
  · simp
  rcases le_total 1 f with h1 | h1
  · rw [max_eq_right (neg_nonpos.mpr (Real.log_nonneg h1)), mul_zero]; exact zero_le_one
  · have hmax : max (-Real.log f) 0 = -Real.log f :=
      max_eq_left (by linarith [Real.log_nonpos hf'.le h1])
    have hbound : -Real.log f ≤ f⁻¹ - 1 := by
      have := Real.log_le_sub_one_of_pos (inv_pos.mpr hf'); rwa [Real.log_inv] at this
    rw [hmax]
    calc f * (-Real.log f) ≤ f * (f⁻¹ - 1) := mul_le_mul_of_nonneg_left hbound hf
      _ = 1 - f := by rw [mul_sub, mul_inv_cancel₀ hf'.ne', mul_one]
      _ ≤ 1 := by linarith

/-- **`L¹` bound on the log-likelihood ratio.** For a finite measure `P` absolutely continuous with
respect to a probability measure `R`, with integrable log-likelihood ratio,
`∫ x, ‖llr P R x‖ ∂P ≤ klDivReal P R + 2`. -/
theorem integral_norm_llr_le_klDivReal_add [IsFiniteMeasure P] [IsProbabilityMeasure R]
    (hPR : P ≪ R) (hint : Integrable (llr P R) P) :
    ∫ x, ‖llr P R x‖ ∂P ≤ klDivReal P R + 2 := by
  -- `‖t‖ = t + 2·(−t)⁺`, so `∫‖llr‖ = klDivReal + 2·∫ (−llr)⁺`.
  have hpt : ∀ x, ‖llr P R x‖ = llr P R x + 2 * max (-llr P R x) 0 := by
    intro x
    rw [Real.norm_eq_abs]
    rcases le_total 0 (llr P R x) with h | h
    · rw [abs_of_nonneg h, max_eq_right (by linarith)]; ring
    · rw [abs_of_nonpos h, max_eq_left (by linarith)]; ring
  have hkl : ∫ x, llr P R x ∂P = klDivReal P R := by
    simp only [klDivReal, if_pos hPR]; rfl
  rw [integral_congr_ae (Filter.Eventually.of_forall hpt),
    integral_add hint (hint.neg_part.const_mul 2), integral_const_mul, hkl]
  -- Reduce to `∫ (−llr)⁺ ∂P ≤ 1` via a change of measure to `R`.
  have hcrux : ∫ x, max (-llr P R x) 0 ∂P ≤ 1 := by
    rw [← integral_rnDeriv_smul hPR]
    refine (integral_mono_of_nonneg (.of_forall fun x => ?_) (integrable_const 1)
      (.of_forall fun x => ?_)).trans ?_
    · exact smul_nonneg ENNReal.toReal_nonneg (le_max_right _ _)
    · -- `(dP/dR)·(−log (dP/dR))⁺ ≤ 1`, since `llr P R x = log (dP/dR x)`.
      simpa [smul_eq_mul, llr] using mul_negPart_log_le_one (ENNReal.toReal_nonneg (a := P.rnDeriv R x))
    · simp
  linarith

end InformationTheory
