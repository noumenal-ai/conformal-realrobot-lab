/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.InformationTheory.KullbackLeibler.Real
import Mathlib.InformationTheory.KullbackLeibler.ChainRule

/-!
# The Kullback-Leibler divergence on a finite discrete space

On a finite space with measurable singletons the divergence is the finite sum
`klDivReal P Q = ∑ x, P{x} · log (P{x}/Q{x})` (`klDivReal_fintype`), through the explicit
Radon-Nikodym density `x ↦ P{x}/Q{x}`. Absolute continuity on such a space reduces to the
singleton masses (`absolutelyContinuous_of_forall_singleton`).

These are the computation rules that turn divergence bounds on finite supports into explicit
weighted sums — the engine of the quantitative (approximate) five-way's counting leg.
-/

open MeasureTheory Real

namespace InformationTheory

variable {α : Type*} [MeasurableSpace α] [MeasurableSingletonClass α] [Fintype α]

/-- On a finite space with measurable singletons, absolute continuity follows from the
singleton masses. -/
theorem absolutelyContinuous_of_forall_singleton {P Q : Measure α}
    (h : ∀ x, Q {x} = 0 → P {x} = 0) : P ≪ Q := by
  refine Measure.AbsolutelyContinuous.mk fun s _ hQs => ?_
  have hfin : s.Finite := Set.toFinite s
  rw [← Set.Finite.coe_toFinset hfin, ← sum_measure_singleton]
  refine Finset.sum_eq_zero fun x hx => h x ?_
  exact nonpos_iff_eq_zero.mp
    ((measure_mono (Set.singleton_subset_iff.mpr (hfin.mem_toFinset.mp hx))).trans hQs.le)

/-- **The Kullback-Leibler divergence on a finite discrete space** is the weighted log-ratio sum
`klDivReal P Q = ∑ x, P{x} · log (P{x}/Q{x})`. The Radon-Nikodym derivative is the explicit
singleton-mass ratio, identified through `withDensity`. -/
theorem klDivReal_fintype (P Q : Measure α)
    [IsProbabilityMeasure P] [IsProbabilityMeasure Q] (hac : P ≪ Q) :
    klDivReal P Q = ∑ x, P.real {x} * Real.log (P.real {x} / Q.real {x}) := by
  have hf : Measurable fun x => P {x} / Q {x} := measurable_of_countable _
  -- `P` has the explicit density `x ↦ P{x}/Q{x}` with respect to `Q`.
  have hdens : P = Q.withDensity (fun x => P {x} / Q {x}) := by
    refine Measure.ext_of_singleton fun x => ?_
    rw [withDensity_apply _ (measurableSet_singleton x), lintegral_singleton]
    by_cases hQ : Q {x} = 0
    · rw [hac hQ, hQ, mul_zero]
    · rw [ENNReal.div_mul_cancel hQ (measure_ne_top Q _)]
  have hrn : P.rnDeriv Q =ᵐ[Q] fun x => P {x} / Q {x} := by
    have h := Measure.rnDeriv_withDensity Q hf
    rwa [← hdens] at h
  have hrnP : P.rnDeriv Q =ᵐ[P] fun x => P {x} / Q {x} := hac.ae_le hrn
  -- Unfold the divergence to the log-derivative integral and evaluate it as a finite sum.
  have hkl : klDivReal P Q = ∫ x, Real.log ((P.rnDeriv Q x).toReal) ∂P := by
    simp only [klDivReal, if_pos hac]
  rw [hkl,
    integral_congr_ae (by filter_upwards [hrnP] with x hx; rw [hx]),
    integral_fintype .of_finite]
  refine Finset.sum_congr rfl fun x _ => ?_
  rw [smul_eq_mul, ENNReal.toReal_div]
  rfl

end InformationTheory
