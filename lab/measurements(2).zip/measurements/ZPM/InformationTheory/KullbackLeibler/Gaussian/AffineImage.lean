/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import Mathlib.Probability.Distributions.Gaussian.Multivariate

/-!
# Affine images of the standard Gaussian as multivariate Gaussians

The affine pushforward `z ↦ a + B z` of the standard Gaussian on `EuclideanSpace ℝ ι` is the
multivariate Gaussian with mean `a` and covariance `B * Bᴴ`. This is the foundation of the
whitening reduction used to derive the closed form of the Kullback-Leibler divergence between
multivariate Gaussian measures.

## References

* T. M. Cover and J. A. Thomas, *Elements of Information Theory*, 2nd ed., Wiley, 2006.
* For the operator / infinite-dimensional generalization (covariance operators on Hilbert
  spaces), see H. Q. Minh, *Regularized Divergences Between Covariance Operators and Gaussian
  Measures on Hilbert Spaces*, J. Theoret. Probab. **34** (2021), arXiv:1904.05352.
-/

open MeasureTheory Matrix
open scoped MatrixOrder

namespace ProbabilityTheory

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The adjoint of `toEuclideanCLM B` is `toEuclideanCLM Bᴴ`: `toEuclideanCLM` is a star
algebra equivalence, so it carries the matrix conjugate transpose to the operator adjoint. -/
lemma adjoint_toEuclideanCLM (B : Matrix ι ι ℝ) :
    (toEuclideanCLM (𝕜 := ℝ) B).adjoint = toEuclideanCLM (𝕜 := ℝ) Bᴴ := by
  rw [← ContinuousLinearMap.star_eq_adjoint, ← map_star]
  rfl

/-- The real inner product of the two adjoint images `(toEuclideanCLM B)ᴴ x` and
`(toEuclideanCLM B)ᴴ y` equals the quadratic form `x ⬝ᵥ (B * Bᴴ) *ᵥ y`. -/
lemma inner_adjoint_toEuclideanCLM (B : Matrix ι ι ℝ) (x y : EuclideanSpace ℝ ι) :
    inner ℝ ((toEuclideanCLM (𝕜 := ℝ) B).adjoint x) ((toEuclideanCLM (𝕜 := ℝ) B).adjoint y)
      = x.ofLp ⬝ᵥ (B * Bᴴ) *ᵥ y.ofLp := by
  rw [ContinuousLinearMap.adjoint_inner_left, adjoint_toEuclideanCLM,
    ← ContinuousLinearMap.comp_apply, ← ContinuousLinearMap.mul_def, ← map_mul, inner_toEuclideanCLM]

/-- The affine image `z ↦ a + B z` of the standard Gaussian on `EuclideanSpace ℝ ι` is the
multivariate Gaussian with mean `a` and covariance `B * Bᴴ`. -/
lemma map_stdGaussian_affine (a : EuclideanSpace ℝ ι) (B : Matrix ι ι ℝ) :
    (stdGaussian (EuclideanSpace ℝ ι)).map (fun z ↦ a + toEuclideanCLM (𝕜 := ℝ) B z)
      = multivariateGaussian a (B * Bᴴ) := by
  have hPSD : (B * Bᴴ).PosSemidef := posSemidef_self_mul_conjTranspose B
  have hcomp : (fun z : EuclideanSpace ℝ ι ↦ a + toEuclideanCLM (𝕜 := ℝ) B z)
      = (fun x ↦ a + x) ∘ (toEuclideanCLM (𝕜 := ℝ) B) := rfl
  haveI hgauss : IsGaussian ((stdGaussian (EuclideanSpace ℝ ι)).map
      (fun z ↦ a + toEuclideanCLM (𝕜 := ℝ) B z)) := by
    rw [hcomp, ← Measure.map_map (measurable_const_add a) (by fun_prop)]
    infer_instance
  refine IsGaussian.ext ?_ ?_
  · -- means: both equal `a`
    simp only [id_eq]
    rw [integral_id_multivariateGaussian, integral_map (by fun_prop) (by fun_prop),
      integral_add (integrable_const _), integral_const]
    · simp [ContinuousLinearMap.integral_comp_comm _ IsGaussian.integrable_fun_id]
    · exact IsGaussian.integrable_id.comp_measurable (by fun_prop)
  · -- covariances: both equal `x ⬝ᵥ (B * Bᴴ) *ᵥ y`
    ext x y
    rw [covarianceBilin_multivariateGaussian hPSD, hcomp,
      ← Measure.map_map (measurable_const_add a) (by fun_prop), covarianceBilin_map_const_add,
      covarianceBilin_map, covarianceBilin_stdGaussian]
    · exact inner_adjoint_toEuclideanCLM B x y
    · exact IsGaussian.memLp_two_id

/-- **General affine image of a multivariate Gaussian.** For positive-semidefinite covariance `S`,
the affine pushforward `x ↦ a + B x` of `multivariateGaussian μ S` is the multivariate Gaussian
with transported mean `a + B μ` and congruent covariance `B * S * Bᴴ`. This is the covariance-
transport engine of the diagonalization step: an orthogonal `B = Uᵀ` sends the whitened covariance
to its eigenvalue diagonal `Uᵀ S U`. Proved by composing the two affine maps and reducing to the
standard-Gaussian image `map_stdGaussian_affine`, using `√S · √Sᴴ = √S · √S = S`. -/
lemma map_multivariateGaussian_affine (a μ : EuclideanSpace ℝ ι) (B S : Matrix ι ι ℝ)
    (hS : S.PosSemidef) :
    (multivariateGaussian μ S).map (fun x ↦ a + toEuclideanCLM (𝕜 := ℝ) B x)
      = multivariateGaussian (a + toEuclideanCLM (𝕜 := ℝ) B μ) (B * S * Bᴴ) := by
  have hherm : (CFC.sqrt S)ᴴ = CFC.sqrt S := by
    rw [← Matrix.star_eq_conjTranspose]; exact (CFC.sqrt_nonneg S).isSelfAdjoint
  -- The covariance of the composite map is `(B √S)(B √S)ᴴ = B (√S √S) Bᴴ = B S Bᴴ`.
  have hcov : (B * CFC.sqrt S) * (B * CFC.sqrt S)ᴴ = B * S * Bᴴ := by
    have h1 : (B * CFC.sqrt S)ᴴ = CFC.sqrt S * Bᴴ := by
      rw [Matrix.conjTranspose_mul, hherm]
    rw [h1, show B * CFC.sqrt S * (CFC.sqrt S * Bᴴ) = B * (CFC.sqrt S * CFC.sqrt S) * Bᴴ by
        simp only [Matrix.mul_assoc], CFC.sqrt_mul_sqrt_self S hS.nonneg]
  -- Composing `z ↦ μ + √S z` with `x ↦ a + B x` gives the single affine map `z ↦ (a + B μ) + B√S z`.
  have hfun : ((fun x : EuclideanSpace ℝ ι ↦ a + toEuclideanCLM (𝕜 := ℝ) B x)
        ∘ fun z ↦ μ + toEuclideanCLM (𝕜 := ℝ) (CFC.sqrt S) z)
      = (fun z ↦ (a + toEuclideanCLM (𝕜 := ℝ) B μ)
          + toEuclideanCLM (𝕜 := ℝ) (B * CFC.sqrt S) z) := by
    funext z
    simp only [Function.comp_apply, map_add, ← ContinuousLinearMap.comp_apply,
      ← ContinuousLinearMap.mul_def, ← map_mul]
    abel
  -- Unfold `multivariateGaussian μ S` as an image of the standard Gaussian, compose, and apply the
  -- standard-Gaussian image lemma.
  rw [show multivariateGaussian μ S
        = (stdGaussian (EuclideanSpace ℝ ι)).map
            (fun z ↦ μ + toEuclideanCLM (𝕜 := ℝ) (CFC.sqrt S) z) from rfl,
      Measure.map_map (by fun_prop) (by fun_prop), hfun, map_stdGaussian_affine, hcov]

end ProbabilityTheory
