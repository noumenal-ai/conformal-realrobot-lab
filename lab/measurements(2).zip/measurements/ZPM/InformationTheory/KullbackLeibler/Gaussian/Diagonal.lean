/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.InformationTheory.KullbackLeibler.Gaussian.AffineImage
import ZPM.InformationTheory.KullbackLeibler.Gaussian.OneDim
import ZPM.InformationTheory.KullbackLeibler.Tensorization
import ZPM.InformationTheory.KullbackLeibler.MapEquiv
import Mathlib.MeasureTheory.Constructions.Pi

/-!
# A diagonal multivariate Gaussian is a product of one-dimensional Gaussians

For a diagonal covariance `diagonal d` (with `d ≥ 0` entrywise), the multivariate Gaussian
`multivariateGaussian μ (diagonal d)` on `EuclideanSpace ℝ ι` is the pushforward, under the
Euclidean identification `toLp 2 : (ι → ℝ) → EuclideanSpace ℝ ι`, of the product of the scalar
Gaussians `∏ᵢ N(μᵢ, dᵢ)`. This is the "coordinates are independent" fact for a diagonal covariance,
and it is the leg that lets the diagonalized multivariate KL split into `d` scalar Gaussian KLs.

The proof avoids computing `CFC.sqrt (diagonal d)` directly: `map_stdGaussian_affine` turns the
affine image `μ + diagonal √d · x` of the standard Gaussian into `multivariateGaussian μ` with
covariance `(diagonal √d)(diagonal √d)ᴴ = diagonal d`, and `map_pi_eq_stdGaussian` /
`Measure.pi_map_pi` transport the product structure coordinatewise.
-/

open MeasureTheory ProbabilityTheory InformationTheory Matrix WithLp
open scoped ENNReal NNReal

noncomputable section

namespace ProbabilityTheory

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- **A diagonal multivariate Gaussian is a pushed-forward product of scalar Gaussians.**
For `d ≥ 0`, `multivariateGaussian μ (diagonal d)` is the image under `toLp 2` of the product
measure `∏ᵢ gaussianReal μᵢ dᵢ`. -/
lemma multivariateGaussian_diagonal_eq_map_pi (μ : EuclideanSpace ℝ ι) (d : ι → ℝ)
    (hd : ∀ i, 0 ≤ d i) :
    multivariateGaussian μ (Matrix.diagonal d)
      = (Measure.pi fun i ↦ gaussianReal (ofLp μ i) (d i).toNNReal).map (toLp 2) := by
  set s : ι → ℝ := fun i ↦ Real.sqrt (d i) with hs
  -- covariance factorization `(diagonal √d)(diagonal √d)ᴴ = diagonal d`
  have hcov : Matrix.diagonal s * (Matrix.diagonal s)ᴴ = Matrix.diagonal d := by
    rw [Matrix.diagonal_conjTranspose, Matrix.diagonal_mul_diagonal]
    refine congrArg Matrix.diagonal (funext fun i ↦ ?_)
    simp only [Pi.star_apply, star_trivial, hs]
    rw [Real.mul_self_sqrt (hd i)]
  -- express the diagonal Gaussian as an affine image of the standard Gaussian
  have h1 : multivariateGaussian μ (Matrix.diagonal d)
      = (stdGaussian (EuclideanSpace ℝ ι)).map
          (fun x ↦ μ + toEuclideanCLM (𝕜 := ℝ) (Matrix.diagonal s) x) := by
    rw [map_stdGaussian_affine, hcov]
  have hmeas_aff : Measurable
      (fun x : EuclideanSpace ℝ ι ↦ μ + toEuclideanCLM (𝕜 := ℝ) (Matrix.diagonal s) x) := by
    fun_prop
  have hmeas_toLp : Measurable (toLp 2 : (ι → ℝ) → EuclideanSpace ℝ ι) := by fun_prop
  have hmeas_coord : Measurable (fun (y : ι → ℝ) i ↦ ofLp μ i + s i * y i) := by fun_prop
  -- the affine map conjugated by `toLp 2` is the coordinatewise affine map
  have hmap : (fun x : EuclideanSpace ℝ ι ↦ μ + toEuclideanCLM (𝕜 := ℝ) (Matrix.diagonal s) x)
        ∘ (toLp 2 : (ι → ℝ) → EuclideanSpace ℝ ι)
      = (toLp 2 : (ι → ℝ) → EuclideanSpace ℝ ι) ∘ (fun y i ↦ ofLp μ i + s i * y i) := by
    funext y
    simp only [Function.comp_apply, toEuclideanCLM_toLp]
    have hv : (Matrix.diagonal s *ᵥ y) = fun i ↦ s i * y i := by
      funext i; rw [Matrix.mulVec_diagonal]
    rw [hv, show (fun i ↦ ofLp μ i + s i * y i) = ofLp μ + fun i ↦ s i * y i from rfl,
      WithLp.toLp_add, WithLp.toLp_ofLp]
  -- each scalar factor: push `N(0,1)` by `t ↦ μᵢ + √dᵢ · t` to get `N(μᵢ, dᵢ)`
  have hQ : ∀ i, (gaussianReal (0 : ℝ) 1).map (fun t ↦ ofLp μ i + s i * t)
      = gaussianReal (ofLp μ i) (d i).toNNReal := by
    intro i
    rw [show (fun t : ℝ ↦ ofLp μ i + s i * t)
          = (fun t ↦ ofLp μ i + t) ∘ (fun t ↦ s i * t) from rfl,
      ← Measure.map_map (by fun_prop) (by fun_prop),
      gaussianReal_map_const_mul, gaussianReal_map_const_add]
    congr 1
    · rw [mul_zero, zero_add]
    · rw [mul_one]
      ext
      simp only [NNReal.coe_mk, hs]
      rw [Real.sq_sqrt (hd i), Real.coe_toNNReal _ (hd i)]
  haveI hsf : ∀ i, SigmaFinite ((gaussianReal (0 : ℝ) 1).map (fun t ↦ ofLp μ i + s i * t)) :=
    fun i ↦ by rw [hQ i]; infer_instance
  have haem : ∀ i, AEMeasurable (fun t : ℝ ↦ ofLp μ i + s i * t) (gaussianReal (0 : ℝ) 1) :=
    fun i ↦ by fun_prop
  rw [h1, ← map_pi_eq_stdGaussian, Measure.map_map hmeas_aff hmeas_toLp, hmap,
    ← Measure.map_map hmeas_toLp hmeas_coord, Measure.pi_map_pi haem, funext hQ]

/-- The Euclidean identification `toLp 2 : (ι → ℝ) → EuclideanSpace ℝ ι` as a measurable
equivalence, used to transport the tensorization of `Measure.pi` onto `EuclideanSpace`. -/
noncomputable def toLpMeasurableEquiv : (ι → ℝ) ≃ᵐ EuclideanSpace ℝ ι :=
  (EuclideanSpace.equiv ι ℝ).symm.toHomeomorph.toMeasurableEquiv

omit [DecidableEq ι] in
/-- `toLpMeasurableEquiv` acts as the identification `toLp 2`. -/
@[simp] lemma coe_toLpMeasurableEquiv :
    ⇑(toLpMeasurableEquiv (ι := ι)) = (toLp 2 : (ι → ℝ) → EuclideanSpace ℝ ι) := rfl

/-- **KL of a diagonal multivariate Gaussian against the standard Gaussian, tensorized.**
For strictly positive diagonal covariance `d > 0`,
`klDivReal (mvG μ (diagonal d)) stdGaussian = ∑ᵢ ½(-log dᵢ + dᵢ + μᵢ² - 1)`, the coordinatewise
sum of the scalar Gaussian-Gaussian KL closed forms. This is the diagonalized-and-tensorized leg
of the multivariate Gaussian KL closed form. -/
theorem klDivReal_multivariateGaussian_diagonal_stdGaussian (μ : EuclideanSpace ℝ ι) (d : ι → ℝ)
    (hd : ∀ i, 0 < d i) :
    klDivReal (multivariateGaussian μ (Matrix.diagonal d)) (stdGaussian (EuclideanSpace ℝ ι))
      = ∑ i, (1 / 2) * (-Real.log (d i) + d i + (ofLp μ i) ^ 2 - 1) := by
  have hvd : ∀ i, (d i).toNNReal ≠ 0 := fun i ↦ (Real.toNNReal_pos.mpr (hd i)).ne'
  -- reduce the KL of the two `toLp 2`-pushed products to the KL of the products
  have hred : klDivReal
        ((Measure.pi fun i ↦ gaussianReal (ofLp μ i) (d i).toNNReal).map (toLp 2))
        ((Measure.pi fun _ : ι ↦ gaussianReal (0 : ℝ) 1).map (toLp 2))
      = klDivReal (Measure.pi fun i ↦ gaussianReal (ofLp μ i) (d i).toNNReal)
        (Measure.pi fun _ : ι ↦ gaussianReal (0 : ℝ) 1) := by
    simp only [← coe_toLpMeasurableEquiv]
    exact klDivReal_map_measurableEquiv toLpMeasurableEquiv _ _
  rw [multivariateGaussian_diagonal_eq_map_pi μ d (fun i ↦ (hd i).le), ← map_pi_eq_stdGaussian,
    hred,
    klDivReal_pi' _ _
      (fun i ↦ (gaussianReal_absolutelyContinuous (ofLp μ i) (hvd i)).trans
        (gaussianReal_absolutelyContinuous' 0 one_ne_zero))
      (fun i ↦ klDiv_gaussianReal_ne_top (hvd i) one_ne_zero)]
  -- Evaluate each coordinate by the scalar closed form `klDivReal_gaussianReal` and simplify.
  refine Finset.sum_congr rfl fun i _ ↦ ?_
  have hc : ((d i).toNNReal : ℝ) = d i := Real.coe_toNNReal (d i) (hd i).le
  rw [klDivReal_gaussianReal (hvd i) one_ne_zero]
  simp only [NNReal.coe_one, hc, sub_zero, div_one, one_div, Real.log_inv]
  ring

end ProbabilityTheory

end
