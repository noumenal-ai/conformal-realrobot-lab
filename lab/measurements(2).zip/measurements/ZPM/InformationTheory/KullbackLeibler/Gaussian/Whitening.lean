/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.InformationTheory.KullbackLeibler.Gaussian.AffineImage
import ZPM.InformationTheory.KullbackLeibler.MapEquiv
import Mathlib.LinearAlgebra.Matrix.NonsingularInverse
import Mathlib.MeasureTheory.Constructions.BorelSpace.Basic
import Mathlib.MeasureTheory.Group.Arithmetic

/-!
# Whitening: invertible matrices as equivalences on `EuclideanSpace`

Building blocks for the whitening reduction of the multivariate Gaussian KL divergence.
An invertible real matrix acts on `EuclideanSpace ℝ ι` as a continuous linear equivalence
(via `Matrix.toEuclideanCLM`, a star algebra equivalence, and the matrix inverse), and hence
as a measurable equivalence. Positive-definite covariances are invertible
(`Matrix.PosDef.det_pos`), so their functional-calculus square roots give the whitening map.
-/

open Matrix MeasureTheory InformationTheory
open scoped MatrixOrder

namespace ProbabilityTheory

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- An invertible matrix as a linear equivalence on `EuclideanSpace ℝ ι`, with inverse given
by the matrix inverse through `toEuclideanCLM`. -/
noncomputable def toEuclideanLE (M : Matrix ι ι ℝ) (hM : IsUnit M.det) :
    EuclideanSpace ℝ ι ≃ₗ[ℝ] EuclideanSpace ℝ ι :=
  { (toEuclideanCLM (𝕜 := ℝ) M).toLinearMap with
    invFun := toEuclideanCLM (𝕜 := ℝ) M⁻¹
    left_inv := fun x => by
      show toEuclideanCLM (𝕜 := ℝ) M⁻¹ (toEuclideanCLM (𝕜 := ℝ) M x) = x
      rw [← ContinuousLinearMap.comp_apply, ← ContinuousLinearMap.mul_def, ← map_mul,
        nonsing_inv_mul M hM, map_one, one_apply_eq_self]
    right_inv := fun x => by
      show toEuclideanCLM (𝕜 := ℝ) M (toEuclideanCLM (𝕜 := ℝ) M⁻¹ x) = x
      rw [← ContinuousLinearMap.comp_apply, ← ContinuousLinearMap.mul_def, ← map_mul,
        mul_nonsing_inv M hM, map_one, one_apply_eq_self] }

/-- An invertible matrix as a continuous linear equivalence on `EuclideanSpace ℝ ι`. -/
noncomputable def toEuclideanCLE (M : Matrix ι ι ℝ) (hM : IsUnit M.det) :
    EuclideanSpace ℝ ι ≃L[ℝ] EuclideanSpace ℝ ι :=
  (toEuclideanLE M hM).toContinuousLinearEquiv

/-- `toEuclideanCLE M hM` acts as the continuous linear map `toEuclideanCLM M`. -/
@[simp] lemma toEuclideanCLE_apply (M : Matrix ι ι ℝ) (hM : IsUnit M.det) (x : EuclideanSpace ℝ ι) :
    toEuclideanCLE M hM x = toEuclideanCLM (𝕜 := ℝ) M x := rfl

/-- For a positive-definite matrix `S`, the functional-calculus square root has invertible
determinant: `(CFC.sqrt S).det ^ 2 = S.det > 0`, so the sqrt is itself invertible. -/
lemma isUnit_det_cfcSqrt (S : Matrix ι ι ℝ) (hS : S.PosDef) :
    IsUnit (CFC.sqrt S).det := by
  have hsq : CFC.sqrt S * CFC.sqrt S = S := CFC.sqrt_mul_sqrt_self S hS.posSemidef.nonneg
  have hdet : (CFC.sqrt S).det ^ 2 = S.det := by rw [sq, ← Matrix.det_mul, hsq]
  have hne : (CFC.sqrt S).det ≠ 0 := by
    intro h0
    have hS0 : S.det = 0 := by rw [← hdet, h0]; ring
    linarith [hS.det_pos]
  exact isUnit_iff_ne_zero.mpr hne

/-- The defining affine map `z ↦ m + √S z` of `multivariateGaussian m S`, as a measurable
equivalence for positive-definite `S` (whose functional-calculus square root is invertible). -/
noncomputable def gaussianAffineEquiv (m : EuclideanSpace ℝ ι) {S : Matrix ι ι ℝ} (hS : S.PosDef) :
    EuclideanSpace ℝ ι ≃ᵐ EuclideanSpace ℝ ι :=
  ((toEuclideanCLE (CFC.sqrt S) (isUnit_det_cfcSqrt S hS)).toHomeomorph.toMeasurableEquiv).trans
    (MeasurableEquiv.addLeft m)

/-- `gaussianAffineEquiv m hS` is the affine map `z ↦ m + √S z`. -/
@[simp] lemma gaussianAffineEquiv_apply (m : EuclideanSpace ℝ ι) {S : Matrix ι ι ℝ} (hS : S.PosDef)
    (z : EuclideanSpace ℝ ι) :
    gaussianAffineEquiv m hS z = m + toEuclideanCLM (𝕜 := ℝ) (CFC.sqrt S) z := by
  simp [gaussianAffineEquiv]

/-- `multivariateGaussian m S` is the pushforward of the standard Gaussian by the affine
equivalence `gaussianAffineEquiv m hS`. -/
lemma multivariateGaussian_eq_map_gaussianAffineEquiv (m : EuclideanSpace ℝ ι)
    {S : Matrix ι ι ℝ} (hS : S.PosDef) :
    multivariateGaussian m S
      = (stdGaussian (EuclideanSpace ℝ ι)).map (gaussianAffineEquiv m hS) := by
  rw [multivariateGaussian]
  refine Measure.map_congr ?_
  filter_upwards with z
  exact (gaussianAffineEquiv_apply m hS z).symm

/-- The inverse of `toEuclideanCLE M hM` acts as `toEuclideanCLM M⁻¹`. -/
@[simp] lemma toEuclideanCLE_symm_apply (M : Matrix ι ι ℝ) (hM : IsUnit M.det)
    (x : EuclideanSpace ℝ ι) :
    (toEuclideanCLE M hM).symm x = toEuclideanCLM (𝕜 := ℝ) M⁻¹ x := rfl

/-- The whitening map: the inverse of `gaussianAffineEquiv m hS` is `z ↦ √S⁻¹ (z - m)`. -/
@[simp] lemma gaussianAffineEquiv_symm_apply (m : EuclideanSpace ℝ ι) {S : Matrix ι ι ℝ}
    (hS : S.PosDef) (z : EuclideanSpace ℝ ι) :
    (gaussianAffineEquiv m hS).symm z = toEuclideanCLM (𝕜 := ℝ) (CFC.sqrt S)⁻¹ (z - m) := by
  simp [gaussianAffineEquiv, sub_eq_neg_add]

/-- **Whitening reduction of the multivariate Gaussian KL.** For positive-definite `S₂`, pushing
both measures through the whitening equivalence `(gaussianAffineEquiv m₂ hS₂).symm` reduces the KL
divergence of two multivariate Gaussians to a KL against the standard Gaussian, with whitened mean
`√S₂⁻¹ (m₁ − m₂)` and covariance `(√S₂⁻¹ √S₁)(√S₂⁻¹ √S₁)ᴴ`. -/
theorem klDivReal_multivariateGaussian_whiten (m₁ m₂ : EuclideanSpace ℝ ι)
    (S₁ S₂ : Matrix ι ι ℝ) (hS₂ : S₂.PosDef) :
    klDivReal (multivariateGaussian m₁ S₁) (multivariateGaussian m₂ S₂)
      = klDivReal
          (multivariateGaussian (toEuclideanCLM (𝕜 := ℝ) (CFC.sqrt S₂)⁻¹ (m₁ - m₂))
            ((CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁ * ((CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁)ᴴ))
          (stdGaussian (EuclideanSpace ℝ ι)) := by
  rw [← klDivReal_map_measurableEquiv (gaussianAffineEquiv m₂ hS₂).symm
    (multivariateGaussian m₁ S₁) (multivariateGaussian m₂ S₂)]
  congr 1
  · -- image of `mvG m₁ S₁` under the whitening is the whitened multivariate Gaussian
    rw [show multivariateGaussian m₁ S₁ = (stdGaussian (EuclideanSpace ℝ ι)).map
          (fun z => m₁ + toEuclideanCLM (𝕜 := ℝ) (CFC.sqrt S₁) z) from rfl,
      Measure.map_map (gaussianAffineEquiv m₂ hS₂).symm.measurable (by fun_prop),
      ← map_stdGaussian_affine (toEuclideanCLM (𝕜 := ℝ) (CFC.sqrt S₂)⁻¹ (m₁ - m₂))
        ((CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁)]
    congr 1
    funext z
    simp only [Function.comp, gaussianAffineEquiv_symm_apply]
    rw [show (m₁ + toEuclideanCLM (𝕜 := ℝ) (CFC.sqrt S₁) z) - m₂
          = toEuclideanCLM (𝕜 := ℝ) (CFC.sqrt S₁) z + (m₁ - m₂) from by abel,
      map_add, ← ContinuousLinearMap.comp_apply, ← ContinuousLinearMap.mul_def, ← map_mul]
    abel
  · -- image of `mvG m₂ S₂` under the whitening is the standard Gaussian
    rw [multivariateGaussian_eq_map_gaussianAffineEquiv m₂ hS₂,
      Measure.map_map (gaussianAffineEquiv m₂ hS₂).symm.measurable
        (gaussianAffineEquiv m₂ hS₂).measurable,
      MeasurableEquiv.symm_comp_self, Measure.map_id]

end ProbabilityTheory
