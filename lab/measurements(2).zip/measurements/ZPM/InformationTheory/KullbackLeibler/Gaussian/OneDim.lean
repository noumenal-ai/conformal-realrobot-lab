/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import Mathlib.Probability.Distributions.Gaussian.Real
import Mathlib.MeasureTheory.Measure.Decomposition.RadonNikodym
import ZPM.InformationTheory.KullbackLeibler.Real

/-!
# Closed form of the 1-D Gaussian-Gaussian KL divergence

`KL( N(m₁, v₁) ‖ N(m₂, v₂) ) = ½ ( log(v₂/v₁) + (v₁ + (m₁ - m₂)²)/v₂ - 1 )`, where `vᵢ` is the
variance parameter of `ProbabilityTheory.gaussianReal`. This is the one-dimensional atom of the
diagonalized route to the multivariate Gaussian KL closed form; the finiteness of the divergence
(`klDiv_gaussianReal_ne_top`), consumed by the tensorization step, is proved alongside it.

Reference: T. M. Cover and J. A. Thomas, *Elements of Information Theory*, 2nd ed., Wiley, 2006.
-/

open MeasureTheory ProbabilityTheory Real Filter
open scoped ENNReal NNReal

noncomputable section

namespace InformationTheory

variable {m₁ m₂ : ℝ} {v₁ v₂ : ℝ≥0}

/-- The Radon-Nikodym derivative of one real Gaussian w.r.t. another is, volume-a.e., the ratio
of their densities. -/
private lemma rnDeriv_gaussianReal_ratio (_hv₁ : v₁ ≠ 0) (hv₂ : v₂ ≠ 0) :
    ((gaussianReal m₁ v₁).rnDeriv (gaussianReal m₂ v₂)) =ᵐ[volume]
      (fun x => gaussianPDF m₁ v₁ x / gaussianPDF m₂ v₂ x) := by
  have hvolQ : volume ≪ gaussianReal m₂ v₂ := gaussianReal_absolutelyContinuous' m₂ hv₂
  have hQvol : gaussianReal m₂ v₂ ≪ volume := gaussianReal_absolutelyContinuous m₂ hv₂
  have hchain :
      (gaussianReal m₁ v₁).rnDeriv volume * volume.rnDeriv (gaussianReal m₂ v₂)
        =ᵐ[volume] (gaussianReal m₁ v₁).rnDeriv (gaussianReal m₂ v₂) :=
    Measure.rnDeriv_mul_rnDeriv' hvolQ
  have hinv : volume.rnDeriv (gaussianReal m₂ v₂)
      =ᵐ[volume] (fun x => ((gaussianReal m₂ v₂).rnDeriv volume x)⁻¹) :=
    hvolQ.ae_eq (Measure.inv_rnDeriv hQvol).symm
  have hP : (gaussianReal m₁ v₁).rnDeriv volume =ᵐ[volume] gaussianPDF m₁ v₁ :=
    rnDeriv_gaussianReal m₁ v₁
  have hQ : (gaussianReal m₂ v₂).rnDeriv volume =ᵐ[volume] gaussianPDF m₂ v₂ :=
    rnDeriv_gaussianReal m₂ v₂
  filter_upwards [hchain, hinv, hP, hQ] with x hx hxinv hxP hxQ
  rw [← hx, Pi.mul_apply, hxinv, hxP, hxQ, div_eq_mul_inv]

/-- `log (gaussianPDFReal m v x) = -½ log(2πv) - (x - m)²/(2v)` for `v ≠ 0`. -/
private lemma log_gaussianPDFReal (hv : v₁ ≠ 0) (x : ℝ) :
    Real.log (gaussianPDFReal m₁ v₁ x)
      = -(1 / 2) * Real.log (2 * π * v₁) - (x - m₁) ^ 2 / (2 * v₁) := by
  have hvpos : (0 : ℝ) < (v₁ : ℝ) := by
    have : (0 : ℝ≥0) < v₁ := pos_iff_ne_zero.mpr hv
    exact_mod_cast this
  have h2pv : (0 : ℝ) < 2 * π * v₁ := by positivity
  rw [gaussianPDFReal, Real.log_mul (by positivity) (by positivity), Real.log_inv,
    Real.log_sqrt (le_of_lt h2pv), Real.log_exp]
  ring

/-- `∫ (x - m₁) ∂gaussianReal m₁ v₁ = 0`. -/
private lemma integral_sub_mean_self :
    ∫ x, (x - m₁) ∂(gaussianReal m₁ v₁) = 0 := by
  have hid : Integrable (fun x => x) (gaussianReal m₁ v₁) :=
    (memLp_id_gaussianReal 1).integrable le_rfl
  rw [integral_sub hid (integrable_const m₁)]
  simp [integral_id_gaussianReal]

/-- `∫ (x - m₁)² ∂gaussianReal m₁ v₁ = v₁`. -/
private lemma integral_sq_sub_mean_self :
    ∫ x, (x - m₁) ^ 2 ∂(gaussianReal m₁ v₁) = (v₁ : ℝ) := by
  have hvar : Var[id; gaussianReal m₁ v₁] = (v₁ : ℝ) := variance_id_gaussianReal
  rw [variance_eq_integral (by fun_prop)] at hvar
  simpa only [id_eq, integral_id_gaussianReal] using hvar

/-- `∫ (x - m₂)² ∂gaussianReal m₁ v₁ = v₁ + (m₁ - m₂)²` (bias-variance split). -/
private lemma integral_sq_sub_const :
    ∫ x, (x - m₂) ^ 2 ∂(gaussianReal m₁ v₁) = (v₁ : ℝ) + (m₁ - m₂) ^ 2 := by
  have hsub : MemLp (fun x => x - m₁) 2 (gaussianReal m₁ v₁) :=
    (memLp_id_gaussianReal 2).sub (memLp_const m₁)
  have hsq : Integrable (fun x => (x - m₁) ^ 2) (gaussianReal m₁ v₁) := hsub.integrable_sq
  have hlin : Integrable (fun x => x - m₁) (gaussianReal m₁ v₁) := hsub.integrable (by norm_num)
  have hpoint : (fun x => (x - m₂) ^ 2)
      = (fun x => (x - m₁) ^ 2 + 2 * (m₁ - m₂) * (x - m₁) + (m₁ - m₂) ^ 2) := by
    funext x; ring
  rw [hpoint]
  rw [integral_add (by exact hsq.add (hlin.const_mul _)) (integrable_const _)]
  rw [integral_add hsq (hlin.const_mul _)]
  rw [integral_const_mul]
  rw [integral_sq_sub_mean_self, integral_sub_mean_self]
  simp

/-- **Closed form of the 1-D Gaussian-Gaussian KL divergence.** For variance parameters
`v₁ ≠ 0`, `v₂ ≠ 0`, `KL( N(m₁, v₁) ‖ N(m₂, v₂) ) = ½ ( log(v₂/v₁) + (v₁ + (m₁-m₂)²)/v₂ - 1 )`. -/
theorem klDivReal_gaussianReal (hv₁ : v₁ ≠ 0) (hv₂ : v₂ ≠ 0) :
    klDivReal (gaussianReal m₁ v₁) (gaussianReal m₂ v₂)
      = (1 / 2) * (Real.log ((v₂ : ℝ) / v₁) + ((v₁ : ℝ) + (m₁ - m₂) ^ 2) / v₂ - 1) := by
  have hv₁pos : (0 : ℝ) < (v₁ : ℝ) := by
    have : (0 : ℝ≥0) < v₁ := pos_iff_ne_zero.mpr hv₁
    exact_mod_cast this
  have hv₂pos : (0 : ℝ) < (v₂ : ℝ) := by
    have : (0 : ℝ≥0) < v₂ := pos_iff_ne_zero.mpr hv₂
    exact_mod_cast this
  have hPvol : gaussianReal m₁ v₁ ≪ volume := gaussianReal_absolutelyContinuous m₁ hv₁
  have hvolQ : volume ≪ gaussianReal m₂ v₂ := gaussianReal_absolutelyContinuous' m₂ hv₂
  have hPQ : gaussianReal m₁ v₁ ≪ gaussianReal m₂ v₂ := hPvol.trans hvolQ
  unfold klDivReal
  rw [if_pos hPQ]
  have hintegrand :
      (fun x => Real.log ((gaussianReal m₁ v₁).rnDeriv (gaussianReal m₂ v₂) x).toReal)
        =ᵐ[gaussianReal m₁ v₁]
      (fun x => (-(1 / 2) * Real.log (2 * π * v₁) - (x - m₁) ^ 2 / (2 * v₁))
                  - (-(1 / 2) * Real.log (2 * π * v₂) - (x - m₂) ^ 2 / (2 * v₂))) := by
    filter_upwards [hPvol.ae_eq (rnDeriv_gaussianReal_ratio hv₁ hv₂)] with x hx
    rw [hx, ENNReal.toReal_div, toReal_gaussianPDF, toReal_gaussianPDF,
      Real.log_div (gaussianPDFReal_pos m₁ v₁ x hv₁).ne' (gaussianPDFReal_pos m₂ v₂ x hv₂).ne',
      log_gaussianPDFReal hv₁, log_gaussianPDFReal hv₂]
  rw [integral_congr_ae hintegrand]
  have hsq₁ : MemLp (fun x => x - m₁) 2 (gaussianReal m₁ v₁) :=
    (memLp_id_gaussianReal 2).sub (memLp_const m₁)
  have hsq₂ : MemLp (fun x => x - m₂) 2 (gaussianReal m₁ v₁) :=
    (memLp_id_gaussianReal 2).sub (memLp_const m₂)
  have hI₁ : Integrable
      (fun x => -(1 / 2) * Real.log (2 * π * v₁) - (x - m₁) ^ 2 / (2 * v₁)) (gaussianReal m₁ v₁) :=
    (integrable_const _).sub ((hsq₁.integrable_sq).div_const _)
  have hI₂ : Integrable
      (fun x => -(1 / 2) * Real.log (2 * π * v₂) - (x - m₂) ^ 2 / (2 * v₂)) (gaussianReal m₁ v₁) :=
    (integrable_const _).sub ((hsq₂.integrable_sq).div_const _)
  rw [integral_sub hI₁ hI₂]
  rw [integral_sub (integrable_const _) ((hsq₁.integrable_sq).div_const _),
      integral_sub (integrable_const _) ((hsq₂.integrable_sq).div_const _)]
  rw [integral_div, integral_div, integral_const, integral_const,
      integral_sq_sub_mean_self, integral_sq_sub_const]
  simp only [measureReal_def, measure_univ, ENNReal.toReal_one, smul_eq_mul, one_mul]
  rw [Real.log_div hv₂pos.ne' hv₁pos.ne', Real.log_mul (by positivity) hv₂pos.ne',
      Real.log_mul (by positivity) hv₁pos.ne']
  field_simp
  ring

/-- **Finiteness of the one-dimensional Gaussian-Gaussian KL divergence.** For variance parameters
`v₁ ≠ 0`, `v₂ ≠ 0`, the `ℝ≥0∞`-valued `klDiv (N(m₁, v₁)) (N(m₂, v₂))` is finite. This is the
integrability side-condition that `klDivReal_pi` requires per coordinate: the log-likelihood ratio
is `P`-a.e. an explicit quadratic, whose square-integrability against `P = N(m₁, v₁)` is the
finiteness of the second moment. -/
theorem klDiv_gaussianReal_ne_top (hv₁ : v₁ ≠ 0) (hv₂ : v₂ ≠ 0) :
    klDiv (gaussianReal m₁ v₁) (gaussianReal m₂ v₂) ≠ ⊤ := by
  have hPvol : gaussianReal m₁ v₁ ≪ volume := gaussianReal_absolutelyContinuous m₁ hv₁
  have hvolQ : volume ≪ gaussianReal m₂ v₂ := gaussianReal_absolutelyContinuous' m₂ hv₂
  have hPQ : gaussianReal m₁ v₁ ≪ gaussianReal m₂ v₂ := hPvol.trans hvolQ
  apply klDiv_ne_top hPQ
  have hllr : llr (gaussianReal m₁ v₁) (gaussianReal m₂ v₂) =ᵐ[gaussianReal m₁ v₁]
      (fun x => (-(1 / 2) * Real.log (2 * π * v₁) - (x - m₁) ^ 2 / (2 * v₁))
                  - (-(1 / 2) * Real.log (2 * π * v₂) - (x - m₂) ^ 2 / (2 * v₂))) := by
    filter_upwards [hPvol.ae_eq (rnDeriv_gaussianReal_ratio hv₁ hv₂)] with x hx
    simp only [llr]
    rw [hx, ENNReal.toReal_div, toReal_gaussianPDF, toReal_gaussianPDF,
      Real.log_div (gaussianPDFReal_pos m₁ v₁ x hv₁).ne' (gaussianPDFReal_pos m₂ v₂ x hv₂).ne',
      log_gaussianPDFReal hv₁, log_gaussianPDFReal hv₂]
  rw [integrable_congr hllr]
  have hsq₁ : MemLp (fun x => x - m₁) 2 (gaussianReal m₁ v₁) :=
    (memLp_id_gaussianReal 2).sub (memLp_const m₁)
  have hsq₂ : MemLp (fun x => x - m₂) 2 (gaussianReal m₁ v₁) :=
    (memLp_id_gaussianReal 2).sub (memLp_const m₂)
  have hI₁ : Integrable
      (fun x => -(1 / 2) * Real.log (2 * π * v₁) - (x - m₁) ^ 2 / (2 * v₁)) (gaussianReal m₁ v₁) :=
    (integrable_const _).sub ((hsq₁.integrable_sq).div_const _)
  have hI₂ : Integrable
      (fun x => -(1 / 2) * Real.log (2 * π * v₂) - (x - m₂) ^ 2 / (2 * v₂)) (gaussianReal m₁ v₁) :=
    (integrable_const _).sub ((hsq₂.integrable_sq).div_const _)
  exact hI₁.sub hI₂

end InformationTheory
