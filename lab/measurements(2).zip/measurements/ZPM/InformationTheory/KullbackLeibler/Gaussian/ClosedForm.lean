/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.InformationTheory.KullbackLeibler.Gaussian.Diagonal
import ZPM.InformationTheory.KullbackLeibler.Gaussian.Whitening
import Mathlib.Analysis.Matrix.Spectrum
import Mathlib.Analysis.Matrix.PosDef

/-!
# Closed form of the multivariate Gaussian KL divergence against the standard Gaussian

For a positive-definite covariance `C`, the Kullback-Leibler divergence of the multivariate
Gaussian `N(w, C)` against the standard Gaussian `N(0, I)` on `EuclideanSpace ℝ ι` is

`klDivReal (N(w, C)) (N(0, I)) = ½ ( -log det C + tr C + ‖w‖² - d )`,  `d = dim`.

This is the reduced (whitened) form of the multivariate Gaussian KL closed form. It is proved by
the **diagonalize-and-tensorize** route: the spectral theorem diagonalizes `C = U diag(λ) Uᴴ`, the
orthogonal change of variables `x ↦ Uᴴ x` (a measurable equivalence leaving the standard Gaussian
invariant) reduces the divergence to a diagonal one (`map_multivariateGaussian_affine`), which
tensorizes into `d` scalar Gaussian KLs (`klDivReal_multivariateGaussian_diagonal_stdGaussian`),
and the sum reassembles via `∑ log λᵢ = log ∏ λᵢ = log det C`, `∑ λᵢ = tr C`, and the isometry
`‖Uᴴ w‖ = ‖w‖`.
-/

open MeasureTheory ProbabilityTheory InformationTheory Matrix WithLp
open scoped ENNReal NNReal RealInnerProductSpace MatrixOrder

noncomputable section

namespace ProbabilityTheory

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- An orthogonal change of variables preserves the Euclidean norm: if `Mᴴ M = 1` then
`‖toEuclideanCLM M w‖² = ‖w‖²`. -/
private lemma normSq_toEuclideanCLM_of_isometry {M : Matrix ι ι ℝ} (hM : Mᴴ * M = 1)
    (w : EuclideanSpace ℝ ι) :
    ‖toEuclideanCLM (𝕜 := ℝ) M w‖ ^ 2 = ‖w‖ ^ 2 := by
  rw [← real_inner_self_eq_norm_sq, ← real_inner_self_eq_norm_sq,
    ← ContinuousLinearMap.adjoint_inner_right, adjoint_toEuclideanCLM,
    ← ContinuousLinearMap.comp_apply, ← ContinuousLinearMap.mul_def, ← map_mul, hM, map_one]
  rfl

/-- **Closed form of the multivariate Gaussian KL against the standard Gaussian.** For a
positive-definite covariance `C`,
`klDivReal (N(w, C)) (stdGaussian) = ½ ( -log det C + tr C + ‖w‖² - d )`. -/
theorem klDivReal_multivariateGaussian_stdGaussian (w : EuclideanSpace ℝ ι) {C : Matrix ι ι ℝ}
    (hC : C.PosDef) :
    klDivReal (multivariateGaussian w C) (stdGaussian (EuclideanSpace ℝ ι))
      = (1 / 2) * (-Real.log C.det + C.trace + ‖w‖ ^ 2 - Fintype.card ι) := by
  classical
  have hH : C.IsHermitian := hC.1
  set U : Matrix ι ι ℝ := (hH.eigenvectorUnitary : Matrix ι ι ℝ)
  set e : ι → ℝ := hH.eigenvalues with hedef
  have he_pos : ∀ i, 0 < e i := fun i ↦ hC.eigenvalues_pos i
  -- unitary identities
  have hsmul : star U * U = 1 := Matrix.UnitaryGroup.star_mul_self hH.eigenvectorUnitary
  have hmsul : U * star U = 1 := mul_eq_one_comm.mp hsmul
  have hstarH : (star U)ᴴ = U := by rw [← Matrix.star_eq_conjTranspose, star_star]
  -- spectral diagonalization `star U * C * U = diagonal e`
  have hdiag : star U * C * U = Matrix.diagonal e := by
    have h := hH.conjStarAlgAut_star_eigenvectorUnitary
    rw [Unitary.conjStarAlgAut_star_apply, RCLike.ofReal_real_eq_id, Function.id_comp] at h
    exact h
  -- invertibility of `star U` (for the change-of-variables equivalence)
  have hUdet : IsUnit (star U).det := by
    rw [isUnit_iff_ne_zero]
    intro h0
    have h1 : (star U).det * U.det = 1 := by rw [← Matrix.det_mul, hsmul, Matrix.det_one]
    rw [h0, zero_mul] at h1
    exact one_ne_zero h1.symm
  -- the orthogonal change of variables as a measurable equivalence
  set eqv : EuclideanSpace ℝ ι ≃ᵐ EuclideanSpace ℝ ι :=
    (toEuclideanCLE (star U) hUdet).toHomeomorph.toMeasurableEquiv
  have heqv : ⇑eqv = fun x ↦ (0 : EuclideanSpace ℝ ι) + toEuclideanCLM (𝕜 := ℝ) (star U) x := by
    funext x
    show toEuclideanCLM (𝕜 := ℝ) (star U) x = 0 + toEuclideanCLM (𝕜 := ℝ) (star U) x
    rw [zero_add]
  -- Isometry `‖Uᴴ w‖ = ‖w‖`, since `(star U)ᴴ (star U) = U (star U) = 1`.
  have hnorm : ‖toEuclideanCLM (𝕜 := ℝ) (star U) w‖ ^ 2 = ‖w‖ ^ 2 :=
    normSq_toEuclideanCLM_of_isometry (by rw [hstarH]; exact hmsul) w
  -- transport the divergence through the change of variables
  rw [← klDivReal_map_measurableEquiv eqv (multivariateGaussian w C)
      (stdGaussian (EuclideanSpace ℝ ι)), heqv, ← multivariateGaussian_zero_one (ι := ι),
    map_multivariateGaussian_affine (hS := hC.posSemidef),
    map_multivariateGaussian_affine (hS := Matrix.PosSemidef.one)]
  -- simplify the two transported Gaussians
  have hcovC : star U * C * (star U)ᴴ = Matrix.diagonal e := by rw [hstarH]; exact hdiag
  have hcovI : star U * (1 : Matrix ι ι ℝ) * (star U)ᴴ = 1 := by
    rw [Matrix.mul_one, hstarH]; exact hsmul
  simp only [map_zero, zero_add]
  rw [hcovC, hcovI, multivariateGaussian_zero_one,
    klDivReal_multivariateGaussian_diagonal_stdGaussian _ e he_pos]
  -- reassemble the sum into the closed form
  have hdet : C.det = ∏ i, e i := by
    rw [hH.det_eq_prod_eigenvalues, ← hedef]; simp only [RCLike.ofReal_real_eq_id, id_eq]
  have htr : C.trace = ∑ i, e i := by
    rw [hH.trace_eq_sum_eigenvalues, ← hedef]; simp only [RCLike.ofReal_real_eq_id, id_eq]
  have hsum_log : ∑ i, Real.log (e i) = Real.log C.det := by
    rw [hdet, Real.log_prod (fun i _ ↦ (he_pos i).ne')]
  have hsum_sq : ∑ i, (ofLp (toEuclideanCLM (𝕜 := ℝ) (star U) w) i) ^ 2 = ‖w‖ ^ 2 := by
    rw [← hnorm]; exact (EuclideanSpace.real_norm_sq_eq _).symm
  -- combine the four sums (only additive/subtractive distribution, closed per-summand by `ring`)
  have hexpand : ∑ i, (-Real.log (e i) + e i + (ofLp (toEuclideanCLM (𝕜 := ℝ) (star U) w) i) ^ 2 - 1)
      = (∑ i, e i + ∑ i, (ofLp (toEuclideanCLM (𝕜 := ℝ) (star U) w) i) ^ 2)
          - (∑ i, Real.log (e i) + ∑ _i : ι, (1 : ℝ)) := by
    rw [← Finset.sum_add_distrib, ← Finset.sum_add_distrib, ← Finset.sum_sub_distrib]
    exact Finset.sum_congr rfl (fun i _ ↦ by ring)
  rw [← Finset.mul_sum, hexpand, ← htr, hsum_sq, hsum_log]
  simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, mul_one]
  ring

/-! ### Invariants of the whitened covariance

The multivariate Gaussian KL closed form below reduces, via `klDivReal_multivariateGaussian_whiten`,
to a KL against the standard Gaussian whose three scalar arguments are the determinant, the trace
and the mean-norm of the whitened covariance `C(S₁,S₂) = (√S₂⁻¹ √S₁)(√S₂⁻¹ √S₁)ᴴ`. These are the
supporting facts, kept separate so the closed form reads as an assembly. -/

/-- The functional-calculus square root of a matrix is self-adjoint. -/
private lemma conjTranspose_cfcSqrt (S : Matrix ι ι ℝ) : (CFC.sqrt S)ᴴ = CFC.sqrt S := by
  rw [← Matrix.star_eq_conjTranspose]; exact (CFC.sqrt_nonneg S).isSelfAdjoint

/-- The inverse of a functional-calculus square root is self-adjoint. -/
private lemma conjTranspose_cfcSqrt_inv (S : Matrix ι ι ℝ) :
    ((CFC.sqrt S)⁻¹)ᴴ = (CFC.sqrt S)⁻¹ := by
  rw [Matrix.conjTranspose_nonsing_inv, conjTranspose_cfcSqrt]

/-- `(√S)⁻¹ (√S)⁻¹ = S⁻¹` for positive-definite `S`. -/
private lemma cfcSqrt_inv_mul_self {S : Matrix ι ι ℝ} (hS : S.PosDef) :
    (CFC.sqrt S)⁻¹ * (CFC.sqrt S)⁻¹ = S⁻¹ := by
  rw [← Matrix.mul_inv_rev, CFC.sqrt_mul_sqrt_self S hS.posSemidef.nonneg]

/-- The whitened covariance `(√S₂⁻¹ √S₁)(√S₂⁻¹ √S₁)ᴴ` is positive-definite (its factor is
invertible). -/
private lemma posDef_whitened {S₁ S₂ : Matrix ι ι ℝ} (hS₁ : S₁.PosDef) (hS₂ : S₂.PosDef) :
    (((CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁) * ((CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁)ᴴ).PosDef := by
  have hR2unit : IsUnit ((CFC.sqrt S₂)⁻¹) := by
    rw [Matrix.isUnit_iff_isUnit_det, Matrix.det_nonsing_inv, Ring.inverse_eq_inv]
    exact isUnit_iff_ne_zero.mpr (inv_ne_zero (isUnit_det_cfcSqrt S₂ hS₂).ne_zero)
  have hAunit : IsUnit ((CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁) :=
    hR2unit.mul ((Matrix.isUnit_iff_isUnit_det _).mpr (isUnit_det_cfcSqrt S₁ hS₁))
  simpa using Matrix.PosDef.mul_mul_conjTranspose_same (A := (1 : Matrix ι ι ℝ))
    Matrix.PosDef.one (Matrix.vecMul_injective_iff_isUnit.mpr hAunit)

/-- `det C(S₁,S₂) = det S₁ / det S₂`. -/
private lemma det_whitened {S₁ S₂ : Matrix ι ι ℝ} (hS₁ : S₁.PosDef) (hS₂ : S₂.PosDef) :
    (((CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁) * ((CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁)ᴴ).det = S₁.det / S₂.det := by
  have ha2 : (CFC.sqrt S₂).det ^ 2 = S₂.det := by
    rw [sq, ← Matrix.det_mul, CFC.sqrt_mul_sqrt_self S₂ hS₂.posSemidef.nonneg]
  have hb2 : (CFC.sqrt S₁).det ^ 2 = S₁.det := by
    rw [sq, ← Matrix.det_mul, CFC.sqrt_mul_sqrt_self S₁ hS₁.posSemidef.nonneg]
  have hane : (CFC.sqrt S₂).det ≠ 0 := (isUnit_det_cfcSqrt S₂ hS₂).ne_zero
  simp only [Matrix.det_mul, Matrix.det_conjTranspose, star_trivial, Matrix.det_nonsing_inv,
    Ring.inverse_eq_inv]
  rw [← ha2, ← hb2]; field_simp

/-- `tr C(S₁,S₂) = tr(S₂⁻¹ S₁)`. -/
private lemma trace_whitened {S₁ S₂ : Matrix ι ι ℝ} (hS₁ : S₁.PosDef) (hS₂ : S₂.PosDef) :
    (((CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁) * ((CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁)ᴴ).trace
      = (S₂⁻¹ * S₁).trace := by
  have hCeq : (CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁ * ((CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁)ᴴ
      = (CFC.sqrt S₂)⁻¹ * S₁ * (CFC.sqrt S₂)⁻¹ := by
    rw [Matrix.conjTranspose_mul, conjTranspose_cfcSqrt_inv, conjTranspose_cfcSqrt,
      Matrix.mul_assoc ((CFC.sqrt S₂)⁻¹) (CFC.sqrt S₁) (CFC.sqrt S₁ * (CFC.sqrt S₂)⁻¹),
      ← Matrix.mul_assoc (CFC.sqrt S₁) (CFC.sqrt S₁) ((CFC.sqrt S₂)⁻¹),
      CFC.sqrt_mul_sqrt_self S₁ hS₁.posSemidef.nonneg, ← Matrix.mul_assoc]
  rw [hCeq, Matrix.trace_mul_cycle, cfcSqrt_inv_mul_self hS₂]

/-- The whitening map preserves the quadratic form: `‖√S₂⁻¹ v‖² = ⟪v, S₂⁻¹ v⟫`. -/
private lemma normSq_cfcSqrt_inv_apply {S₂ : Matrix ι ι ℝ} (hS₂ : S₂.PosDef)
    (v : EuclideanSpace ℝ ι) :
    ‖toEuclideanCLM (𝕜 := ℝ) ((CFC.sqrt S₂)⁻¹) v‖ ^ 2 = v ⬝ᵥ S₂⁻¹ *ᵥ v := by
  rw [← real_inner_self_eq_norm_sq, ← ContinuousLinearMap.adjoint_inner_right,
    adjoint_toEuclideanCLM, ← ContinuousLinearMap.comp_apply, ← ContinuousLinearMap.mul_def,
    ← map_mul, conjTranspose_cfcSqrt_inv, cfcSqrt_inv_mul_self hS₂, inner_toEuclideanCLM]

/-- **Closed form of the multivariate Gaussian KL divergence** (M3b). For positive-definite
covariances `S₁, S₂`,
`KL(N(m₁,S₁) ‖ N(m₂,S₂)) = ½ ( log(det S₂ / det S₁) + tr(S₂⁻¹ S₁) + ⟪m₁-m₂, S₂⁻¹(m₁-m₂)⟫ - d )`.

The whitening reduction (`klDivReal_multivariateGaussian_whiten`) sends the pair to a KL against
the standard Gaussian (`klDivReal_multivariateGaussian_stdGaussian`); the three scalar invariants
of the whitened covariance (`det_whitened`, `trace_whitened`, `normSq_cfcSqrt_inv_apply`) then
identify the arguments. -/
theorem klDivReal_multivariateGaussian (m₁ m₂ : EuclideanSpace ℝ ι) {S₁ S₂ : Matrix ι ι ℝ}
    (hS₁ : S₁.PosDef) (hS₂ : S₂.PosDef) :
    klDivReal (multivariateGaussian m₁ S₁) (multivariateGaussian m₂ S₂)
      = (1 / 2) * (Real.log (S₂.det / S₁.det) + (S₂⁻¹ * S₁).trace
          + (m₁ - m₂) ⬝ᵥ S₂⁻¹ *ᵥ (m₁ - m₂) - Fintype.card ι) := by
  rw [klDivReal_multivariateGaussian_whiten m₁ m₂ S₁ S₂ hS₂,
    klDivReal_multivariateGaussian_stdGaussian _ (posDef_whitened hS₁ hS₂),
    det_whitened hS₁ hS₂, trace_whitened hS₁ hS₂, normSq_cfcSqrt_inv_apply hS₂ (m₁ - m₂),
    ← Real.log_inv, inv_div]
  simp only [WithLp.ofLp_sub]

end ProbabilityTheory

end
