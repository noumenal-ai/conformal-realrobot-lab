/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.InformationTheory.KullbackLeibler.Gaussian.Whitening
import ZPM.InformationTheory.KullbackLeibler.Gaussian.Diagonal
import ZPM.InformationTheory.KullbackLeibler.MapEquiv
import Mathlib.InformationTheory.KullbackLeibler.ChainRule

/-!
# Absolute continuity and KL finiteness for multivariate Gaussians

For positive-definite covariances `S₁, S₂`, the multivariate Gaussians `N(m₁, S₁)` and `N(m₂, S₂)`
on `EuclideanSpace ℝ ι` are mutually absolutely continuous with finite Kullback-Leibler divergence:

`klDiv (N(m₁, S₁)) (N(m₂, S₂)) ≠ ⊤`,  hence  `N(m₁, S₁) ≪ N(m₂, S₂)`  and  `llr` is integrable.

Mathlib records neither the multivariate-Gaussian density nor its absolute continuity, so these
facts are proved here by the same whitening-and-diagonalization reduction that underlies the KL
closed form: transport through the whitening equivalence (`gaussianAffineEquiv`) and the spectral
change of variables (`Matrix.IsHermitian.eigenvectorUnitary`) — both `klDiv`-preserving
(`klDiv_map_equiv`) — collapses the divergence to the standard Gaussian, then to a product of
one-dimensional Gaussian divergences (`multivariateGaussian_diagonal_eq_map_pi`, `klDiv_pi`), where
the scalar finiteness `klDiv_gaussianReal_ne_top` closes it. Absolute continuity and log-likelihood
integrability then fall out of `InformationTheory.klDiv_ne_top_iff`.

These are the analytic side-conditions the PAC-privacy variational bound
(`mutualInformationReal_le_condKL`) and the conditional-KL chain rule (`klDivReal_compProd_prod`)
require of the additive-Gaussian-noise mechanism against its marginal-matching Gaussian reference.
-/

open MeasureTheory ProbabilityTheory InformationTheory Matrix WithLp
open scoped ENNReal NNReal MatrixOrder

noncomputable section

namespace ProbabilityTheory

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The whitened covariance `((√S₂)⁻¹ √S₁)(·)ᴴ` is positive definite: it is a congruence of the
identity by the invertible matrix `(√S₂)⁻¹ √S₁`. -/
private lemma posDef_whitened {S₁ S₂ : Matrix ι ι ℝ} (hS₁ : S₁.PosDef) (hS₂ : S₂.PosDef) :
    (((CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁) * ((CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁)ᴴ).PosDef := by
  have hR2unit : IsUnit ((CFC.sqrt S₂)⁻¹) := by
    rw [Matrix.isUnit_iff_isUnit_det, Matrix.det_nonsing_inv, Ring.inverse_eq_inv]
    exact isUnit_iff_ne_zero.mpr (inv_ne_zero (isUnit_det_cfcSqrt S₂ hS₂).ne_zero)
  have hAunit : IsUnit ((CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁) :=
    hR2unit.mul ((Matrix.isUnit_iff_isUnit_det _).mpr (isUnit_det_cfcSqrt S₁ hS₁))
  simpa using Matrix.PosDef.mul_mul_conjTranspose_same (A := (1 : Matrix ι ι ℝ))
    Matrix.PosDef.one (Matrix.vecMul_injective_iff_isUnit.mpr hAunit)

/-- **Finiteness of the diagonal-vs-standard multivariate Gaussian KL.** For strictly positive
diagonal covariance `d > 0`, `klDiv (N(μ, diagonal d)) (stdGaussian) ≠ ⊤`. Reduces the two
`toLp 2`-pushed products to `Measure.pi`, tensorizes (`klDiv_pi`), and closes each coordinate with
the scalar `klDiv_gaussianReal_ne_top`. -/
private theorem klDiv_multivariateGaussian_diagonal_stdGaussian_ne_top (μ : EuclideanSpace ℝ ι)
    (d : ι → ℝ) (hd : ∀ i, 0 < d i) :
    klDiv (multivariateGaussian μ (Matrix.diagonal d)) (stdGaussian (EuclideanSpace ℝ ι)) ≠ ⊤ := by
  have hvd : ∀ i, (d i).toNNReal ≠ 0 := fun i ↦ (Real.toNNReal_pos.mpr (hd i)).ne'
  rw [multivariateGaussian_diagonal_eq_map_pi μ d (fun i ↦ (hd i).le), ← map_pi_eq_stdGaussian]
  simp only [← coe_toLpMeasurableEquiv]
  rw [klDiv_map_equiv toLpMeasurableEquiv, klDiv_pi' _ _]
  exact ENNReal.sum_ne_top.mpr fun i _ => klDiv_gaussianReal_ne_top (hvd i) one_ne_zero

/-- **Finiteness of the multivariate Gaussian KL against the standard Gaussian.** For a
positive-definite covariance `C`, `klDiv (N(w, C)) (stdGaussian) ≠ ⊤`. Diagonalizes `C` by its
eigenvector unitary and transports the divergence (`klDiv_map_equiv`) to the diagonal case. -/
theorem klDiv_multivariateGaussian_stdGaussian_ne_top (w : EuclideanSpace ℝ ι) {C : Matrix ι ι ℝ}
    (hC : C.PosDef) :
    klDiv (multivariateGaussian w C) (stdGaussian (EuclideanSpace ℝ ι)) ≠ ⊤ := by
  classical
  have hH : C.IsHermitian := hC.1
  set U : Matrix ι ι ℝ := (hH.eigenvectorUnitary : Matrix ι ι ℝ)
  set e : ι → ℝ := hH.eigenvalues with hedef
  have he_pos : ∀ i, 0 < e i := fun i ↦ hC.eigenvalues_pos i
  have hsmul : star U * U = 1 := Matrix.UnitaryGroup.star_mul_self hH.eigenvectorUnitary
  have hstarH : (star U)ᴴ = U := by rw [← Matrix.star_eq_conjTranspose, star_star]
  have hdiag : star U * C * U = Matrix.diagonal e := by
    have h := hH.conjStarAlgAut_star_eigenvectorUnitary
    rw [Unitary.conjStarAlgAut_star_apply, RCLike.ofReal_real_eq_id, Function.id_comp] at h
    exact h
  have hUdet : IsUnit (star U).det := by
    rw [isUnit_iff_ne_zero]
    intro h0
    have h1 : (star U).det * U.det = 1 := by rw [← Matrix.det_mul, hsmul, Matrix.det_one]
    rw [h0, zero_mul] at h1
    exact one_ne_zero h1.symm
  set eqv : EuclideanSpace ℝ ι ≃ᵐ EuclideanSpace ℝ ι :=
    (toEuclideanCLE (star U) hUdet).toHomeomorph.toMeasurableEquiv
  have heqv : ⇑eqv = fun x ↦ (0 : EuclideanSpace ℝ ι) + toEuclideanCLM (𝕜 := ℝ) (star U) x := by
    funext x
    show toEuclideanCLM (𝕜 := ℝ) (star U) x = 0 + toEuclideanCLM (𝕜 := ℝ) (star U) x
    rw [zero_add]
  rw [← klDiv_map_equiv eqv (multivariateGaussian w C) (stdGaussian (EuclideanSpace ℝ ι)), heqv,
    ← multivariateGaussian_zero_one (ι := ι),
    map_multivariateGaussian_affine (hS := hC.posSemidef),
    map_multivariateGaussian_affine (hS := Matrix.PosSemidef.one)]
  have hcovC : star U * C * (star U)ᴴ = Matrix.diagonal e := by rw [hstarH]; exact hdiag
  have hcovI : star U * (1 : Matrix ι ι ℝ) * (star U)ᴴ = 1 := by
    rw [Matrix.mul_one, hstarH]; exact hsmul
  simp only [map_zero, zero_add]
  rw [hcovC, hcovI, multivariateGaussian_zero_one]
  exact klDiv_multivariateGaussian_diagonal_stdGaussian_ne_top _ e he_pos

/-- **Finiteness of the multivariate Gaussian KL divergence.** For positive-definite covariances
`S₁, S₂`, `klDiv (N(m₁, S₁)) (N(m₂, S₂)) ≠ ⊤`. Whitens by `(gaussianAffineEquiv m₂ hS₂).symm`
(sending `N(m₂, S₂)` to the standard Gaussian and `N(m₁, S₁)` to the whitened Gaussian, both
`klDiv`-preserving) and applies the standard-Gaussian finiteness. -/
theorem klDiv_multivariateGaussian_ne_top (m₁ m₂ : EuclideanSpace ℝ ι) {S₁ S₂ : Matrix ι ι ℝ}
    (hS₁ : S₁.PosDef) (hS₂ : S₂.PosDef) :
    klDiv (multivariateGaussian m₁ S₁) (multivariateGaussian m₂ S₂) ≠ ⊤ := by
  rw [← klDiv_map_equiv (gaussianAffineEquiv m₂ hS₂).symm
      (multivariateGaussian m₁ S₁) (multivariateGaussian m₂ S₂),
    show (multivariateGaussian m₂ S₂).map (gaussianAffineEquiv m₂ hS₂).symm
        = stdGaussian (EuclideanSpace ℝ ι) from by
      rw [multivariateGaussian_eq_map_gaussianAffineEquiv m₂ hS₂,
        Measure.map_map (gaussianAffineEquiv m₂ hS₂).symm.measurable
          (gaussianAffineEquiv m₂ hS₂).measurable,
        MeasurableEquiv.symm_comp_self, Measure.map_id],
    show (multivariateGaussian m₁ S₁).map (gaussianAffineEquiv m₂ hS₂).symm
        = multivariateGaussian (toEuclideanCLM (𝕜 := ℝ) (CFC.sqrt S₂)⁻¹ (m₁ - m₂))
            ((CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁ * ((CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁)ᴴ) from by
      rw [show multivariateGaussian m₁ S₁ = (stdGaussian (EuclideanSpace ℝ ι)).map
            (fun z => m₁ + toEuclideanCLM (𝕜 := ℝ) (CFC.sqrt S₁) z) from rfl,
        Measure.map_map (gaussianAffineEquiv m₂ hS₂).symm.measurable (by fun_prop),
        ← map_stdGaussian_affine (toEuclideanCLM (𝕜 := ℝ) (CFC.sqrt S₂)⁻¹ (m₁ - m₂))
          ((CFC.sqrt S₂)⁻¹ * CFC.sqrt S₁)]
      congr 1
      funext z
      simp only [Function.comp, gaussianAffineEquiv_symm_apply]
      rw [show (m₁ + toEuclideanCLM (𝕜 := ℝ) (CFC.sqrt S₁) z) - m₂
            = toEuclideanCLM (𝕜 := ℝ) (CFC.sqrt S₁) z + (m₁ - m₂) from by abel,
        map_add, ← ContinuousLinearMap.comp_apply, ← ContinuousLinearMap.mul_def, ← map_mul]
      abel]
  exact klDiv_multivariateGaussian_stdGaussian_ne_top _ (posDef_whitened hS₁ hS₂)

/-- **Absolute continuity of multivariate Gaussians.** For positive-definite covariances,
`N(m₁, S₁) ≪ N(m₂, S₂)` (from finite KL via `klDiv_ne_top_iff`). -/
theorem multivariateGaussian_absolutelyContinuous (m₁ m₂ : EuclideanSpace ℝ ι)
    {S₁ S₂ : Matrix ι ι ℝ} (hS₁ : S₁.PosDef) (hS₂ : S₂.PosDef) :
    (multivariateGaussian m₁ S₁).AbsolutelyContinuous (multivariateGaussian m₂ S₂) :=
  (klDiv_ne_top_iff.mp (klDiv_multivariateGaussian_ne_top m₁ m₂ hS₁ hS₂)).1

/-- **Integrability of the multivariate Gaussian log-likelihood ratio.** For positive-definite
covariances, `llr (N(m₁, S₁)) (N(m₂, S₂))` is integrable against `N(m₁, S₁)`. -/
theorem integrable_llr_multivariateGaussian (m₁ m₂ : EuclideanSpace ℝ ι)
    {S₁ S₂ : Matrix ι ι ℝ} (hS₁ : S₁.PosDef) (hS₂ : S₂.PosDef) :
    Integrable (llr (multivariateGaussian m₁ S₁) (multivariateGaussian m₂ S₂))
      (multivariateGaussian m₁ S₁) :=
  (klDiv_ne_top_iff.mp (klDiv_multivariateGaussian_ne_top m₁ m₂ hS₁ hS₂)).2

end ProbabilityTheory

end
