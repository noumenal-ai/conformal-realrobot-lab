/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import ZPM.InformationTheory.MutualInformation.Def
import ZPM.InformationTheory.KullbackLeibler.MapEquiv
import Mathlib.MeasureTheory.Constructions.Pi

/-!
# Total correlation

`totalCorrelationReal P = klDivReal P (∏ᵢ P.map (eval i))`, the Kullback-Leibler divergence of a
joint law on a finite product against the product of its own marginals: the multivariate
generalization of mutual information (Watanabe's total correlation). Over a two-element index it
is the mutual information of the paired law (`totalCorrelationReal_fin_two`), transported along
`MeasurableEquiv.piFinTwo`.
-/

open MeasureTheory ProbabilityTheory

noncomputable section

namespace InformationTheory

variable {ι : Type*} [Fintype ι] {X : ι → Type*} [∀ i, MeasurableSpace (X i)]

/-- The **total correlation** of a joint law `P` on a finite product: the KL divergence of `P`
against the product of its own marginals. The multivariate mutual information. -/
def totalCorrelationReal (P : Measure (∀ i, X i)) : ℝ :=
  klDivReal P (Measure.pi fun i => P.map (fun f => f i))

/-- **Total correlation over a two-element index is mutual information** of the paired law.
The pairing `MeasurableEquiv.piFinTwo` carries the product of marginals to the binary product
(`measurePreserving_piFinTwo`), and `klDivReal` is invariant under the equivalence. -/
theorem totalCorrelationReal_fin_two {X : Fin 2 → Type*} [∀ i, MeasurableSpace (X i)]
    (P : Measure (∀ i, X i)) [IsProbabilityMeasure P] :
    totalCorrelationReal P = mutualInformationReal (P.map (MeasurableEquiv.piFinTwo X)) := by
  haveI : ∀ i, IsProbabilityMeasure (P.map (fun f => f i)) :=
    fun i => Measure.isProbabilityMeasure_map (measurable_pi_apply i).aemeasurable
  haveI : IsProbabilityMeasure (P.map (MeasurableEquiv.piFinTwo X)) :=
    Measure.isProbabilityMeasure_map (MeasurableEquiv.piFinTwo X).measurable.aemeasurable
  -- The marginals of the paired law are the coordinate marginals.
  have h0 : (P.map (MeasurableEquiv.piFinTwo X)).map Prod.fst = P.map (fun f => f 0) := by
    rw [Measure.map_map measurable_fst (MeasurableEquiv.piFinTwo X).measurable]
    congr 1
  have h1 : (P.map (MeasurableEquiv.piFinTwo X)).map Prod.snd = P.map (fun f => f 1) := by
    rw [Measure.map_map measurable_snd (MeasurableEquiv.piFinTwo X).measurable]
    congr 1
  -- The product of the marginals transports to the binary product of the marginals.
  have hpi : (Measure.pi fun i => P.map (fun f => f i)).map (MeasurableEquiv.piFinTwo X)
      = (P.map (fun f => f 0)).prod (P.map (fun f => f 1)) :=
    (measurePreserving_piFinTwo _).map_eq
  unfold totalCorrelationReal mutualInformationReal
  rw [← klDivReal_map_measurableEquiv (MeasurableEquiv.piFinTwo X) P
      (Measure.pi fun i => P.map (fun f => f i)), hpi, h0, h1]

end InformationTheory

end
