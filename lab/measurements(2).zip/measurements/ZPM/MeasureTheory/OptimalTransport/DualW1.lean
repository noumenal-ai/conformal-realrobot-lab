/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import Mathlib.MeasureTheory.Integral.Lebesgue.Basic
import Mathlib.MeasureTheory.Integral.Lebesgue.Map
import Mathlib.Data.ENNReal.BigOperators
import Mathlib.MeasureTheory.Measure.Typeclasses.Probability

/-!
# Dual-form Kantorovich transport discrepancy over a measurable space

`dualW1 d μ ν` is the dual-form transport discrepancy between two measures over an arbitrary
ground structure `d : α → α → ℝ≥0∞`: the supremum over the measurable `d`-Lipschitz test class
of the symmetrized, truncated lower-integral gap. When `d` is the 0/1 structure of a setoid
(`setoidDist`) this is a total-variation-type quantity; when `d = edist` of a pseudo-emetric
space it is the classical dual Kantorovich–Rubinstein functional.

The definition places no hypotheses on `α` beyond `[MeasurableSpace α]` and none on the
measures; individual lemmas state exactly what they consume (`IsProbabilityMeasure` and
`Nonempty α` appear only in the boundedness lemma). `dualW1` is a genuine extended
pseudometric on measures for every fixed `d`: reflexivity (`dualW1_self`), symmetry
(`dualW1_comm`), and the triangle inequality (`dualW1_triangle`) are proved below, the last
because a pointwise supremum of pseudometrics is a pseudometric. It is monotone in the ground
structure (`dualW1_mono`) and bounded by any bound on `d` (`dualW1_le_of_le_const`).

The primal (coupling) form and the Kantorovich–Rubinstein duality between the two are not
developed here; nothing in this file asserts them.
-/

noncomputable section

namespace MeasureTheory

open scoped ENNReal Classical

variable {α : Type*} [MeasurableSpace α]

/-- The `d`-Lipschitz predicate, one-sided ENNReal form (pair-symmetric by swapping `a b`).
For `d = edist` this is `LipschitzWith 1` in truncated-subtraction form. -/
def Lip1 (d : α → α → ℝ≥0∞) (f : α → ℝ≥0∞) : Prop :=
  ∀ a b, f a ≤ f b + d a b

/-- **Dual-form transport discrepancy** over ground structure `d`: supremum over measurable
`d`-Lipschitz observables of the symmetrized lower-integral gap. -/
def dualW1 (d : α → α → ℝ≥0∞) (μ ν : Measure α) : ℝ≥0∞ :=
  ⨆ f ∈ {g : α → ℝ≥0∞ | Measurable g ∧ Lip1 d g},
    (∫⁻ a, f a ∂μ - ∫⁻ a, f a ∂ν) ⊔ (∫⁻ a, f a ∂ν - ∫⁻ a, f a ∂μ)

/-- The 0/1 ground structure of a setoid: related pairs at distance 0, unrelated at 1. -/
def setoidDist (r : Setoid α) : α → α → ℝ≥0∞ :=
  fun a b => if r a b then 0 else 1

omit [MeasurableSpace α] in
/-- A `setoidDist`-Lipschitz observable is constant on classes. -/
theorem eq_of_rel_of_lip1 {r : Setoid α} {f : α → ℝ≥0∞} (hf : Lip1 (setoidDist r) f)
    {x y : α} (hxy : r x y) : f x = f y := by
  have h1 := hf x y
  have h2 := hf y x
  simp only [setoidDist, if_pos hxy, if_pos (r.iseqv.symm hxy), add_zero] at h1 h2
  exact le_antisymm h1 h2

theorem dualW1_self (d : α → α → ℝ≥0∞) (μ : Measure α) : dualW1 d μ μ = 0 := by
  refine le_antisymm ?_ zero_le
  unfold dualW1
  exact iSup₂_le fun f _ => by simp

theorem dualW1_comm (d : α → α → ℝ≥0∞) (μ ν : Measure α) :
    dualW1 d μ ν = dualW1 d ν μ := by
  unfold dualW1
  exact iSup_congr fun f => iSup_congr fun _ => sup_comm _ _

/-- Monotonicity in the ground structure: a smaller `d` admits fewer tests. -/
theorem dualW1_mono {d d' : α → α → ℝ≥0∞} (h : ∀ a b, d a b ≤ d' a b)
    (μ ν : Measure α) : dualW1 d μ ν ≤ dualW1 d' μ ν := by
  unfold dualW1
  refine iSup₂_le fun f hf => ?_
  refine le_iSup₂ (f := fun f _ =>
      (∫⁻ a, f a ∂μ - ∫⁻ a, f a ∂ν) ⊔ (∫⁻ a, f a ∂ν - ∫⁻ a, f a ∂μ)) f ?_
  exact ⟨hf.1, fun a b => le_trans (hf.2 a b) (by gcongr; exact h a b)⟩

/-- **Pushforward contraction** (naturality in the base space): if `φ` contracts the ground
structures (`d' (φ a) (φ b) ≤ d a b`), the discrepancy of the pushforwards is dominated by the
discrepancy upstairs — every downstream test pulls back to an upstream test. This is the
transport analogue of the Fisher–Rao data-processing inequality. -/
theorem dualW1_map_le {β : Type*} [MeasurableSpace β] {φ : α → β} (hφ : Measurable φ)
    {d : α → α → ℝ≥0∞} {d' : β → β → ℝ≥0∞} (hd : ∀ a b, d' (φ a) (φ b) ≤ d a b)
    (μ ν : Measure α) : dualW1 d' (μ.map φ) (ν.map φ) ≤ dualW1 d μ ν := by
  unfold dualW1
  refine iSup₂_le fun g hg => ?_
  rw [lintegral_map hg.1 hφ, lintegral_map hg.1 hφ]
  refine le_iSup₂ (f := fun f _ =>
      (∫⁻ a, f a ∂μ - ∫⁻ a, f a ∂ν) ⊔ (∫⁻ a, f a ∂ν - ∫⁻ a, f a ∂μ)) (g ∘ φ) ?_
  refine ⟨hg.1.comp hφ, fun a b => ?_⟩
  simp only [Function.comp_apply]
  exact le_trans (hg.2 (φ a) (φ b)) (by gcongr; exact hd a b)

/-- **Triangle inequality**: `dualW1 d` is an extended pseudometric on measures — a pointwise
supremum of pseudometrics is a pseudometric. -/
theorem dualW1_triangle (d : α → α → ℝ≥0∞) (μ ν ρ : Measure α) :
    dualW1 d μ ρ ≤ dualW1 d μ ν + dualW1 d ν ρ := by
  unfold dualW1
  refine iSup₂_le fun f hf => ?_
  have h1 : (∫⁻ a, f a ∂μ - ∫⁻ a, f a ∂ν) ⊔ (∫⁻ a, f a ∂ν - ∫⁻ a, f a ∂μ)
      ≤ ⨆ g ∈ {g : α → ℝ≥0∞ | Measurable g ∧ Lip1 d g},
        (∫⁻ a, g a ∂μ - ∫⁻ a, g a ∂ν) ⊔ (∫⁻ a, g a ∂ν - ∫⁻ a, g a ∂μ) :=
    le_iSup₂ (f := fun g _ =>
      (∫⁻ a, g a ∂μ - ∫⁻ a, g a ∂ν) ⊔ (∫⁻ a, g a ∂ν - ∫⁻ a, g a ∂μ)) f hf
  have h2 : (∫⁻ a, f a ∂ν - ∫⁻ a, f a ∂ρ) ⊔ (∫⁻ a, f a ∂ρ - ∫⁻ a, f a ∂ν)
      ≤ ⨆ g ∈ {g : α → ℝ≥0∞ | Measurable g ∧ Lip1 d g},
        (∫⁻ a, g a ∂ν - ∫⁻ a, g a ∂ρ) ⊔ (∫⁻ a, g a ∂ρ - ∫⁻ a, g a ∂ν) :=
    le_iSup₂ (f := fun g _ =>
      (∫⁻ a, g a ∂ν - ∫⁻ a, g a ∂ρ) ⊔ (∫⁻ a, g a ∂ρ - ∫⁻ a, g a ∂ν)) f hf
  refine le_trans (sup_le ?_ ?_) (add_le_add h1 h2)
  · exact le_trans tsub_le_tsub_add_tsub (add_le_add le_sup_left le_sup_left)
  · exact le_trans tsub_le_tsub_add_tsub
      (le_trans (add_le_add le_sup_right le_sup_right) (add_comm _ _).le)

/-- **Boundedness**: a `C`-bounded ground structure gives a `C`-bounded discrepancy between
probability measures. -/
theorem dualW1_le_of_le_const [Nonempty α] {d : α → α → ℝ≥0∞} {C : ℝ≥0∞}
    (hd : ∀ a b, d a b ≤ C) (μ ν : Measure α)
    [IsProbabilityMeasure μ] [IsProbabilityMeasure ν] : dualW1 d μ ν ≤ C := by
  have side : ∀ κ₁ κ₂ : Measure α, κ₁ Set.univ = 1 → κ₂ Set.univ = 1 →
      ∀ f : α → ℝ≥0∞, Lip1 d f → (∫⁻ a, f a ∂κ₁) - (∫⁻ a, f a ∂κ₂) ≤ C := by
    intro κ₁ κ₂ hκ₁ hκ₂ f hf
    have hpt : ∀ a, f a ≤ (⨅ b, f b) + C := by
      intro a
      rw [show (⨅ b, f b) + C = ⨅ b, (f b + C) from by rw [ENNReal.iInf_add]]
      exact le_iInf fun b => (hf a b).trans (by gcongr; exact hd a b)
    have hub : ∫⁻ a, f a ∂κ₁ ≤ C + ⨅ b, f b := by
      calc ∫⁻ a, f a ∂κ₁ ≤ ∫⁻ _, (⨅ b, f b) + C ∂κ₁ := lintegral_mono hpt
        _ = (⨅ b, f b) + C := by rw [lintegral_const, hκ₁, mul_one]
        _ = C + ⨅ b, f b := add_comm _ _
    have hlb : (⨅ b, f b) ≤ ∫⁻ a, f a ∂κ₂ := by
      calc (⨅ b, f b) = ∫⁻ _, ⨅ b, f b ∂κ₂ := by rw [lintegral_const, hκ₂, mul_one]
        _ ≤ ∫⁻ a, f a ∂κ₂ := lintegral_mono fun a => iInf_le _ a
    exact tsub_le_iff_right.mpr (hub.trans (by gcongr))
  unfold dualW1
  exact iSup₂_le fun f hf =>
    sup_le (side μ ν measure_univ measure_univ f hf.2)
      (side ν μ measure_univ measure_univ f hf.2)

end MeasureTheory
