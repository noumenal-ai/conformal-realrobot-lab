/-
Copyright (c) 2026 Dhruv Gupta. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Dhruv Gupta
-/
import Mathlib.Topology.ContinuousMap.StoneWeierstrass
import Mathlib.Topology.ContinuousMap.Algebra
import Mathlib.Analysis.SpecialFunctions.Pow.Real

/-!
# Universal approximation by ReLU networks, via lattice rigidity

`ReLUNet ι` is an inductive syntax for arbitrary-depth ReLU networks over inputs `ι → ℝ`:
affine maps, ReLU, sums, scalar multiples. The main theorem `relu_uat` exhibits, for every
continuous target on a compact `K ⊆ ι → ℝ` and every `ε > 0`, an actual network term
uniformly `ε`-close to the target — ReLU networks as literal witnesses of universal
approximation.

The proof is the lattice Stone–Weierstrass route
(`ContinuousMap.sublattice_closure_eq_top`): the network class is a vector sublattice with
constants — and the lattice operations are CONSTRUCTIONS in the syntax, each costing exactly
one additional ReLU layer (`netAbs`, `netSup`, `netInf`: `|t| = relu t + relu (−t)`,
`max = (a+b+|a−b|)/2`). Depth is the price of lattice closure; lattice closure plus
point-separation (affine maps) is all that universal approximation needs.

Scope: arbitrary-depth networks. Nothing here concerns single-hidden-layer networks (a
different theorem, not claimed).
-/

noncomputable section

namespace ZPM.ReLU

open ContinuousMap

variable {ι : Type*} [Fintype ι]

/-- Inductive syntax of arbitrary-depth ReLU networks on inputs `ι → ℝ`. -/
inductive ReLUNet (ι : Type*) : Type _
  | affine (w : ι → ℝ) (b : ℝ) : ReLUNet ι
  | relu (N : ReLUNet ι) : ReLUNet ι
  | add (N M : ReLUNet ι) : ReLUNet ι
  | smul (c : ℝ) (N : ReLUNet ι) : ReLUNet ι

namespace ReLUNet

/-- Semantics: the function a network computes. -/
def eval : ReLUNet ι → (ι → ℝ) → ℝ
  | affine w b, x => (∑ i, w i * x i) + b
  | relu N, x => max (eval N x) 0
  | add N M, x => eval N x + eval M x
  | smul c N, x => c * eval N x

theorem eval_continuous (N : ReLUNet ι) : Continuous (eval N) := by
  induction N with
  | affine w b =>
    exact (continuous_finsetSum _ fun i _ =>
      (continuous_const.mul (continuous_apply i))).add continuous_const
  | relu N ih => exact ih.max continuous_const
  | add N M ihN ihM => exact ihN.add ihM
  | smul c N ih => exact continuous_const.mul ih

/-! ## Lattice operations as constructions: depth is the price of closure -/

/-- Negation: a scalar layer. -/
def neg (N : ReLUNet ι) : ReLUNet ι := smul (-1) N

/-- Difference. -/
def sub (N M : ReLUNet ι) : ReLUNet ι := add N (neg M)

/-- Absolute value: `|t| = relu t + relu (−t)` — one extra ReLU layer. -/
def abs (N : ReLUNet ι) : ReLUNet ι := add (relu N) (relu (neg N))

/-- Pointwise maximum: `max a b = (a + b + |a − b|)/2` — one extra ReLU layer. -/
def netSup (N M : ReLUNet ι) : ReLUNet ι :=
  smul (1 / 2) (add (add N M) (abs (sub N M)))

/-- Pointwise minimum: `min a b = (a + b − |a − b|)/2` — one extra ReLU layer. -/
def netInf (N M : ReLUNet ι) : ReLUNet ι :=
  smul (1 / 2) (sub (add N M) (abs (sub N M)))

@[simp] theorem eval_neg (N : ReLUNet ι) (x : ι → ℝ) : eval (neg N) x = -eval N x := by
  simp [neg, eval]

@[simp] theorem eval_sub (N M : ReLUNet ι) (x : ι → ℝ) :
    eval (sub N M) x = eval N x - eval M x := by
  simp [sub, eval]; ring

@[simp] theorem eval_abs (N : ReLUNet ι) (x : ι → ℝ) : eval (abs N) x = |eval N x| := by
  simp only [abs, eval, eval_neg]
  rcases le_total (eval N x) 0 with h | h
  · rw [abs_of_nonpos h]; rw [max_eq_right h, max_eq_left (by linarith)]; ring
  · rw [abs_of_nonneg h]; rw [max_eq_left h, max_eq_right (by linarith)]; ring

theorem eval_netSup (N M : ReLUNet ι) (x : ι → ℝ) :
    eval (netSup N M) x = max (eval N x) (eval M x) := by
  simp only [netSup, eval, eval_abs, eval_sub]
  rcases le_total (eval N x) (eval M x) with h | h
  · rw [max_eq_right h, abs_of_nonpos (by linarith)]; ring
  · rw [max_eq_left h, abs_of_nonneg (by linarith)]; ring

theorem eval_netInf (N M : ReLUNet ι) (x : ι → ℝ) :
    eval (netInf N M) x = min (eval N x) (eval M x) := by
  simp only [netInf, eval, eval_abs, eval_sub]
  rcases le_total (eval N x) (eval M x) with h | h
  · rw [min_eq_left h, abs_of_nonpos (by linarith)]; ring
  · rw [min_eq_right h, abs_of_nonneg (by linarith)]; ring

end ReLUNet

/-! ## The network class on a compact domain -/

variable (K : Set (ι → ℝ))

open ReLUNet

/-- A network as a continuous map on the domain. -/
def toC (N : ReLUNet ι) : C(K, ℝ) :=
  ⟨fun x => eval N x, (eval_continuous N).comp continuous_subtype_val⟩

/-- The class of network-computable functions on `K`. -/
def netClass : Set C(K, ℝ) := Set.range (toC K)

theorem netClass_nonempty : (netClass K).Nonempty := ⟨toC K (affine 0 0), Set.mem_range_self _⟩

theorem sup_mem_netClass {f g : C(K, ℝ)} (hf : f ∈ netClass K) (hg : g ∈ netClass K) :
    f ⊔ g ∈ netClass K := by
  obtain ⟨N, rfl⟩ := hf
  obtain ⟨M, rfl⟩ := hg
  refine ⟨netSup N M, ?_⟩
  ext x
  simp [toC, eval_netSup]

theorem inf_mem_netClass {f g : C(K, ℝ)} (hf : f ∈ netClass K) (hg : g ∈ netClass K) :
    f ⊓ g ∈ netClass K := by
  obtain ⟨N, rfl⟩ := hf
  obtain ⟨M, rfl⟩ := hg
  refine ⟨netInf N M, ?_⟩
  ext x
  simp [toC, eval_netInf]

/-- Affine networks realize two-point interpolation: the class separates points strongly. -/
theorem netClass_separatesPointsStrongly :
    (netClass K).SeparatesPointsStrongly := by
  classical
  intro v x y
  by_cases hxy : x = y
  · refine ⟨toC K (affine 0 (v x)), Set.mem_range_self _, ?_, ?_⟩ <;>
      simp [toC, ReLUNet.eval, hxy]
  · have hne : (x : ι → ℝ) ≠ (y : ι → ℝ) := fun h => hxy (Subtype.ext h)
    obtain ⟨i, hi⟩ := Function.ne_iff.mp hne
    -- the coordinate network separates; solve the 2×2 interpolation affinely
    set gx : ℝ := (x : ι → ℝ) i with hgx
    set gy : ℝ := (y : ι → ℝ) i with hgy
    have hgne : gx - gy ≠ 0 := sub_ne_zero_of_ne hi
    set a : ℝ := (v x - v y) / (gx - gy) with ha
    set b : ℝ := v x - a * gx with hb
    refine ⟨toC K (affine (fun j => if j = i then a else 0) b), Set.mem_range_self _, ?_, ?_⟩
    · show (∑ j, (if j = i then a else 0) * (x : ι → ℝ) j) + b = v x
      simp only [ite_mul, zero_mul]
      rw [Finset.sum_ite_eq' Finset.univ i]
      simp only [Finset.mem_univ, if_true]
      rw [hb]; ring
    · show (∑ j, (if j = i then a else 0) * (y : ι → ℝ) j) + b = v y
      simp only [ite_mul, zero_mul]
      rw [Finset.sum_ite_eq' Finset.univ i]
      simp only [Finset.mem_univ, if_true]
      rw [hb, ha]
      field_simp
      ring

/-! ## The theorem -/

variable [CompactSpace K]

/-- **Density**: the network class is dense in `C(K, ℝ)` — lattice Stone–Weierstrass applied
to a class whose lattice structure is built from ReLU layers. -/
theorem netClass_closure_eq_top : closure (netClass K) = ⊤ :=
  ContinuousMap.sublattice_closure_eq_top (netClass K) (netClass_nonempty K)
    (fun _ hf _ hg => inf_mem_netClass K hf hg)
    (fun _ hf _ hg => sup_mem_netClass K hf hg)
    (netClass_separatesPointsStrongly K)

/-- **Universal approximation, with the network as a literal witness**: for every continuous
target on a compact domain and every `ε > 0` there EXISTS a ReLU network term uniformly
`ε`-close to it. -/
theorem relu_uat (T : C(K, ℝ)) {ε : ℝ} (hε : 0 < ε) :
    ∃ N : ReLUNet ι, ∀ x : K, |T x - ReLUNet.eval N x| < ε := by
  have hT : T ∈ closure (netClass K) := by
    rw [netClass_closure_eq_top K]; trivial
  obtain ⟨f, hfL, hfd⟩ := Metric.mem_closure_iff.mp hT ε hε
  obtain ⟨N, rfl⟩ := hfL
  refine ⟨N, fun x => ?_⟩
  have := ContinuousMap.dist_apply_le_dist (f := T) (g := toC K N) x
  have hd : dist (T x) (toC K N x) < ε := lt_of_le_of_lt this hfd
  simpa [toC, Real.dist_eq] using hd

end ZPM.ReLU
